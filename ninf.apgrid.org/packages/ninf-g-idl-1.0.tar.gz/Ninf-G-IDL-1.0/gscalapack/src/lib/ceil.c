/* ceil(inum,idenom) mainly returns a number the node has. */
int Ciceil(int inum, int idenom) {
  int iceil;
  iceil = (inum+idenom-1) / idenom;
  return iceil;
}
