#define _WRAPPER_
/* $Id: pdlauu2_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define DOUBLE
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n
void  pdlauu2_ninf(	 char uplo,
		 int n,
		 double global_a[],
		 int lda,
		 int *info
	)
/* "pdlauu2 computes the product U * U' or L' * L, where the triangular factor U or L is stored in the upper or lower triangular part of the matrix A." */
/* OPTIONS */
{
	int maxldd;

	int maxlda;
	double *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
	int row_loca, col_loca;

	INITIALIZE();

	SCALAR( "char", uplo);
	SCALAR( "int", n);
	SCALAR("int", lda);

	ROW( a);
	COL( a);
	MAXLDD( maxldd, a );
	maxlda = maxldd;

	MATRIX( "double", a, ROW_a, COL_a);
	DISTRIBUTE( "double", a, ROW_a, COL_a);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pdlauu2)( &uplo, &n, loca, &one, &one, desca);

	GATHER( "double", a, ROW_a, COL_a);

	if( mypnum == 0 ){
	} else {
	}

	FREE_MATRIX(a);
}

