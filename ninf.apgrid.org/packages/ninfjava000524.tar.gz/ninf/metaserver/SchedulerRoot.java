package ninf.metaserver;
import ninf.basic.*;
import ninf.scheduler.*;
import ninf.common.*;
import ninf.cproxy.aggregate.*;
import ninf.client.*;
import java.io.*;
import java.util.Vector;
import java.util.Hashtable;

public class SchedulerRoot {
  static CommandParser serversParser = 
     new CommandParser(new CommandRepresent("servers", 1));
  static CommandParser serverInfoParser = 
     new CommandParser(new CommandRepresent("serverInfo", 2));
  static CommandParser funcNodesParser = 
     new CommandParser(new CommandRepresent("funcNodes", 1));
  static CommandParser dataNodesParser = 
     new CommandParser(new CommandRepresent("dataNodes", 1));
  static CommandParser endScheduleParser = 
     new CommandParser(new CommandRepresent("endSchedule",0));
  static NinfLog dbg = new NinfLog("SchedulerRoot");

  static String packageString = "ninf.scheduler";

  Scheduler scheduler;
  AggregateScheduler aggregateScheduler;
  public DirectoryService service;
  Predictor predictor;

  SchedulerRoot(String schedulerString, DirectoryService service){
    this.scheduler = getScheduler(schedulerString);
    if (this.scheduler == null){
      dbg.log("cannot get scheduler. aborting ...");
      System.exit(3);
    }
    this.service = service;
    initPredictor(MetaServer.conf.predictors);
    initAggregateScheduler(MetaServer.conf.aggregateSchedulerString);
  }

  static Scheduler getScheduler(String str){
    str = packageString + "." + str;
    try {
      Class schedulerClass = Class.forName(str);
      return (Scheduler)schedulerClass.newInstance();
    } catch (ClassCastException e){
      dbg.log("failed to set scheduler");
      dbg.log("the class '" + str + "' is not a Scheduler.");
      return null;
    } catch (ClassNotFoundException e){
      dbg.log("failed to set scheduler");
      dbg.log("Cannot Find class named: " + str);
      return null;
    } catch (InstantiationException e){
      dbg.log("failed to set scheduler");
      dbg.log("got InstantiationException: for " + str);
      return null;
    } catch (IllegalAccessException e){
      dbg.log("failed to set scheduler");
      dbg.log("got IllegalAccessException: for " + str);
      return null;
    }
  }

  static AggregateScheduler getAggregateScheduler(String str){
    str = packageString + "." + str;
    try {
      Class schedulerClass = Class.forName(str);
      return (AggregateScheduler)schedulerClass.newInstance();
    } catch (ClassCastException e){
      dbg.log("failed to set aggregateScheduler");
      dbg.log("the class '" + str + "' is not a AggregateScheduler.");
      return null;
    } catch (ClassNotFoundException e){
      dbg.log("failed to set aggregateScheduler");
      dbg.log("Cannot Find class named: " + str);
      return null;
    } catch (InstantiationException e){
      dbg.log("failed to set aggregateScheduler");
      dbg.log("got InstantiationException: for " + str);
      return null;
    } catch (IllegalAccessException e){
      dbg.log("failed to set aggregateScheduler");
      dbg.log("got IllegalAccessException: for " + str);
      return null;
    }
  }

  String getCurrentScheduler(){
    if (scheduler == null)
      return null;
    return scheduler.getClass().getName();
  }
  String getCurrentAggregateScheduler(){
    if (aggregateScheduler == null)
      return null;
    return aggregateScheduler.getClass().getName();
  }

  void readEndSchedule(DataInputStream is) throws NinfException {
    endScheduleParser.readCommand(is);
  }

  ServerIndex[] getServerIndexes(DataInputStream is, FunctionName funcName,
			     RequestID request) throws NinfException {
    NinfCommand com = serversParser.readCommand(is);
    int n = new Integer(com.args[0]).intValue();
    
    Vector v = new Vector();
    for (int i = 0; i < n; i++){
      NinfServerStruct tmp = readServerInfo(is, request);
      if (tmp != null)
	v.addElement(tmp);
    }
    ServerIndex[] serverIndexes = new ServerIndex[v.size()];
    for (int i = 0; i < v.size(); i++){
      serverIndexes[i] = 
	getServerIndex((NinfServerStruct)(v.elementAt(i)), funcName);
    }
    return serverIndexes;
  }

  NinfServerStruct[] readServerInfos(DataInputStream is, RequestID request) 
  throws NinfException{
    NinfCommand com = serversParser.readCommand(is);
    int n = new Integer(com.args[0]).intValue();
    NinfServerStruct[] tmp = new NinfServerStruct[n];
    for (int i = 0; i < n; i++)
      tmp[i] = readServerInfo(is, request);
    return tmp;
  }

  NinfServerStruct readServerInfo(DataInputStream is, RequestID request) 
  throws NinfException {
    NinfCommand com = serverInfoParser.readCommand(is);
    String host = com.args[0];
    int port = new Integer(com.args[1]).intValue();
    CommunicationInformation throughput = new CommunicationInformation(is);
    CommunicationInformation latency    = new CommunicationInformation(is);
    NinfServerStruct struct = new NinfServerStruct(host, port);
    ServerID id = new ServerID(host, port);
    NinfServerHolder holder = service.getHolder(struct);
    if (holder == null)
      return null;
    ServerID cproxy = new ServerID(request.cproxyHost, request.cproxyPort);
    holder.updateCProxy(cproxy, throughput, latency);
    service.addInterServerInfo(cproxy, id, 
			       new InterServerInfo(throughput, latency));
    return struct;
  }    

  public ServerIndex getServerIndex(NinfServerStruct struct, FunctionName funcName){
    return service.getServerIndex(funcName, struct);
  }

  synchronized boolean newScheduler(String str, PrintStream os){
    Scheduler newScheduler;
    if ((newScheduler = getScheduler(str)) != null){
      scheduler = newScheduler;
      os.println("+OK");
    } else {
      os.println("-ERR");
    }
    return true;
  }

  synchronized boolean newAggregateScheduler(String str, PrintStream os){
    AggregateScheduler newScheduler;
    if ((newScheduler = getAggregateScheduler(str)) != null){
      aggregateScheduler = newScheduler;
      os.println("+OK");
    } else {
      os.println("-ERR");
    }
    return true;
  }

  boolean initPredictor(PrintStream os){
    initPredictor();
    os.println("+OK");
    return true;
  }

  boolean pushPredictor(String str, PrintStream os){
    if (pushPredictor(str)){
      os.println("+OK");
    } else {
      os.println("-ERR");
    }
    return true;
  }


  synchronized boolean getPredictors(PrintStream os){
    os.println("+OK");
    Predictor[] predictors = predictor.getPredictors();
    for (int i = 0; i < predictors.length; i++)
      os.print(predictors[i].getClass().getName() +  " ");
    os.println("");
    return true;
  }

  boolean doSchedule(DataInputStream is, PrintStream os, 
				  RequestID request)
       throws NinfException{
    ServerIndex serverIndex = schedule(is, request);

    NinfCommand com;
    if (serverIndex == null)
      com = new NinfCommand("noServerAvailable");
    else 
      com = new NinfCommand("serverIndex", serverIndex.server.host, 
			    ""+serverIndex.server.port, ""+serverIndex.index);
    com.send(os);
    return true;
  }

  boolean doAggregateSchedule(DataInputStream is, PrintStream os, 
				  RequestID request)
       throws NinfException{
    AggregateScheduled result = aggregateSchedule(is, request);

    if (result == null)
      (new NinfCommand("noServerAvailable")).send(os);
    else{
      (new NinfCommand("aggregateScheduled")).send(os);
      result.send(os);
    } 
    return true;
  }

  Hashtable callInfoTable = new Hashtable();
  Hashtable resultTable   = new Hashtable();
  Hashtable nameTable     = new Hashtable();

  synchronized boolean jobDone(RequestID request){
    dbg.log("Job["+request+"] done.");

    /******    give information predictor    ********/
    if (predictor != null){
      CallInformation callInfo = (CallInformation)callInfoTable.get(request);
      ScheduleResult result = (ScheduleResult)resultTable.get(request);
      FunctionName name = (FunctionName)nameTable.get(request);
      request.funcName = name;
      predictor.done(request, callInfo, result);
      callInfoTable.remove(request);
      resultTable  .remove(request);
      nameTable .remove(request);
    }

    /******  release waiting thread *****/
    this.release();

    return true;
  }

  synchronized void scheduled(RequestID request, CallInformation callInfo, ScheduleResult result){
    predictor.scheduled(request, callInfo, result);
  }

  FuncNode[] readFuncNodes(DataInputStream is) throws NinfException{
    NinfCommand com = funcNodesParser.readCommand(is);
    FuncNode funcNodes[] = new FuncNode[com.intVal(0)];
    for (int i = 0; i < com.intVal(0); i++)
      funcNodes[i] = new FuncNode(is);
    return funcNodes;
  }

  DataNode[] readDataNodes(DataInputStream is) throws NinfException{
    NinfCommand com = dataNodesParser.readCommand(is);
    DataNode dataNodes[] = new DataNode[com.intVal(0)];
    for (int i = 0; i < com.intVal(0); i++)
      dataNodes[i] = new DataNode(is);
    return dataNodes;
  }

  AggregateScheduled aggregateSchedule(DataInputStream is, RequestID request)
  throws NinfException {
    FuncNode funcNodes[] = readFuncNodes(is);
    DataNode dataNodes[] = readDataNodes(is);
    NinfServerStruct servers[] = readServerInfos(is, request);
    readEndSchedule(is);

    StringBuffer sb = new StringBuffer();
    AggregateScheduled result;
    ServerID cproxy = new ServerID(request.cproxyHost, request.cproxyPort);
    try {
      result = aggregateScheduler.schedule(
		new DataFlow(cproxy, funcNodes, dataNodes, service, servers),
		servers, this, cproxy, sb);
    } catch (NinfException e){
      dbg.log("Job["+ request + "] failed to be scheduled.");
      dbg.printStack(e);
      return null;
    }

    if (MetaServer.conf.scheduleLogStream != null)
      MetaServer.conf.scheduleLogStream.println(FormatString.format(
		"%.2lf %3d %s %s", 
		new Double(System.currentTimeMillis() / 1000.0),
		new Integer(request.serial),
		aggregateScheduler.getClass().getName(),
                sb));
    return result;
  }



  ServerIndex schedule(DataInputStream is, RequestID request) throws NinfException {
    FunctionName funcName = new FunctionName(is);
    request.funcName = funcName;
    CallInformation callInfo = new CallInformation(is);
    ServerIndex serverIndexes[] = getServerIndexes(is, funcName, request);
    readEndSchedule(is);

    StringBuffer sb = new StringBuffer();
    ScheduleResult result;
    try {
      result = scheduler.schedule(callInfo, serverIndexes, this, 
	new ServerID(request.cproxyHost, request.cproxyPort), sb);
    } catch (NinfException e){
      dbg.log("Job["+ request + "](" + funcName.toString()+ ") failed to be scheduled.");
      dbg.printStack(e);
      return null;
    }

    /******    give information predictor    ********/
    if (predictor != null){                 
      callInfoTable.put(request, callInfo);
      resultTable  .put(request, result);
      nameTable    .put(request, request.funcName);
      scheduled(request, callInfo, result);
    }

    dbg.log("Job["+ request + "](" + funcName.toString()+ ") scheduled " 
           + result.serverInfo.serverIndex.server + ".");

    if (MetaServer.conf.scheduleLogStream != null)
      MetaServer.conf.scheduleLogStream.println(FormatString.format(
		"%.2lf %3d %s %s %s %s", 
		new Double(System.currentTimeMillis() / 1000.0),
		new Integer(request.serial),
		result.serverInfo.serverIndex.server,
		callInfo.logString(),
		scheduler.getClass().getName(),
                sb));
    return result.serverInfo.serverIndex; 
  }

  void initAggregateScheduler(String className){
    aggregateScheduler = getAggregateScheduler(className);
  }



  /******************* Predictor ***********************/
  
  synchronized void initPredictor(String predictors[]){
    initPredictor();
    if (predictors == null) return;
    for (int i = 0; i < predictors.length; i++)
      if (!pushPredictor(predictors[i])){
	System.err.println("failed to push Predictor named " + predictors[i]);
	System.exit(3); 
      }
  }

  void initPredictor(){
    predictor = new VanillaPredictor(service);
  }

  synchronized boolean pushPredictor(String predictorName){
    Predictor tmpPredictor = getPredictor(predictorName);
    if (tmpPredictor == null)
      return false;
    tmpPredictor.setService(service);
    tmpPredictor.pushOn(predictor);
    predictor = tmpPredictor;
    return true;
  }

  synchronized static Predictor getPredictor(String str){
    str = packageString + "." + str;
    try {
      Class predictorClass = Class.forName(str);
      return (Predictor)predictorClass.newInstance();
    } catch (ClassCastException e){
      dbg.println("the class '" + str + "' is not a Predictor.");
      return null;
    } catch (ClassNotFoundException e){
      dbg.println("Cannot Find class named: " + str);
      return null;
    } catch (InstantiationException e){
      dbg.println("got InstantiationException: for " + str);
      return null;
    } catch (IllegalAccessException e){
      dbg.println("got IllegalAccessException: for " + str);
      return null;
    }
  }
  
  synchronized public LoadInformation getLoad(NinfServerStruct server)
  throws NinfException {
    return predictor.getLoadInformation(server);
  }

  synchronized public CommunicationInformation 
    getThroughput(NinfServerStruct server, ServerID cproxy)
    throws NinfException {
    return predictor.getThroughput(server, cproxy);
  }

  synchronized public CommunicationInformation 
    getLatency(NinfServerStruct server, ServerID cproxy)
    throws NinfException {
    return predictor.getLatency(server, cproxy);
  }

  synchronized public ServerCharacter getServerChar(NinfServerStruct server)
  throws NinfException {
    return service.getServerCharacter(server);
  }


  /********************* QUEHANDLE **********************/

  WaitQue waitQue = new WaitQue();

  public void enque(){
    waitQue.enque();
  }
  public void release(){
    waitQue.release();
  }
}

class WaitQue {
  static NinfLog dbg = new NinfLog("WaitQue");
  int counter = 0;

  synchronized void enque(){
    try {
      dbg.println("enque: " + (counter++));
      wait();
      dbg.println("deque: " + (--counter));
    } catch (InterruptedException e){
      dbg.println("interrupted: " + (--counter));
      enque();
    }
  }
  synchronized void release(){
    dbg.println("release");
    notify();
  }
}
