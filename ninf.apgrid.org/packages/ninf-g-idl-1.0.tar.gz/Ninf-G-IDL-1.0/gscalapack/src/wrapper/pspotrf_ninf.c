#define _WRAPPER_
/* $Id: pspotrf_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define FLOAT
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n
void  pspotrf_ninf(	 char uplo,
		 int n,
		 float global_a[],
		 int lda,
		 int *info
)
/* "pspotrf computes the Cholesky factorization of an N-by-N real symmetric positive definite distributed matrix A." */
/* OPTIONS */
{
    extern void FortranCall(pspotrf)( char*, int*, float*, int*, int*, int*, int*);

	int maxldd;

	int maxlda;
	float *loca;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
	int row_loca, col_loca;

	INITIALIZE();

	SCALAR( "char", uplo);
	SCALAR( "int", n);
        SCALAR( "int", lda);

	ROW( a);
	COL( a);
	MAXLDD( maxldd, a );
	maxlda = maxldd;

	trMATRIX( uplo, "float", a, ROW_a, COL_a);
	trDISTRIBUTE( uplo, "float", a, ROW_a, COL_a);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pspotrf)( &uplo, &n, loca, &one, &one, desca, &linfo);

	trGATHER( uplo, "float", a, ROW_a, COL_a);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
		*info = linfo;
	} else {
		
	}

	FREE_MATRIX(a);

	
}

