package ninf.cproxy;
import ninf.basic.*;
import ninf.client.*;
import ninf.common.*;

public class StubCallableFactory implements CallableFactory{
  public Callable generate(NinfStub stub, int index, ScheduleProvider master){
    if (CProxy.conf.latchUp)
      return new LatchStubCallable(stub, index, master);
    else
      return new StubCallable(stub, index, master);
  }
}
