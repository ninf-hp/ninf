#define _WRAPPER_
/* $Id: pctrti2_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define SCOMPLEX
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n
void  pctrti2_ninf(	 char uplo,
		 char diag,
		 int n,
		 scomplex global_a[],
		 int lda,
		 int *info
)
/* "pctrti2 computes the inverse of a complex upper or lower triangular block matrix A. " */
/* OPTIONS */
{
	int maxldd;

	int maxlda;
	scomplex *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
	int row_loca, col_loca;

	INITIALIZE();

	SCALAR( "char", uplo);
	SCALAR( "char", diag);
	SCALAR( "int", n);
	SCALAR( "int", lda);

	ROW( a);
	COL( a);
	MAXLDD( maxldd, a );
	maxlda = maxldd;

	trMATRIX( uplo, "scomplex", a, ROW_a, COL_a);
	trDISTRIBUTE( uplo, "scomplex", a, ROW_a  , COL_a);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pctrti2)( &uplo, &diag, &n, loca, &one, &one, desca, &linfo);

	GATHER( "scomplex", a, ROW_a  , COL_a);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
		*info = linfo;
	} else {
	}

	FREE_MATRIX(a);
}

