package org.gridforum.gridrpc;

public interface GrpcExecInfo {
  public double getLookupTime();
  public double getInvokeTime();
  public double getForeTime();
  public double getExecTime();
  public double getBackTime();
}
