#define _WRAPPER_
/* $Id: psdbsv_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define _DISTRIBUTE_1D_
#define FLOAT
#define NO_PIVOT
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n
#define ROW_b ldb
#define COL_b nrhs
static	int worklen(int n, int nrhs, int bwl, int bwu) {
	  int ret=1;
	  ret =  n*(bwl+bwu)+6*max(bwl,bwu)*max(bwl,bwu)
		  +max((max(bwl,bwu)*nrhs), max(bwl,bwu)*max(bwl,bwu));
	  if NEED_BUFF {
	    ret =   blocsize*(bwl+bwu)+6*max(bwl,bwu)*max(bwl,bwu)
	      +max((max(bwl,bwu)*nrhs), max(bwl,bwu)*max(bwl,bwu));
	  }
          return ret;
}


void  psdbsv_ninf(	 int n,
		 int bwl,
		 int bwu,
		 int nrhs,
		 float global_a[],
		 int lda,
		 float global_b[],
		 int ldb,
		 float work[],
		 int lwork,
		 int *info
)
/* "psdbsv solves a system of linear equations A * X = B where A is an N-by-N real banded diagonally dominant-like distributed matrix with bandwidth BWL, BWU." */
/* OPTIONS */
{
    extern void FortranCall(psdbsv)( int*, int*, int*, int*,
                              float*, int*, int*,
                              float*, int*, int*,
                              float*, int*, int*);

	int maxldd;

	float *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];

	int maxldb;
	float *locb=NULL;
	int descb[DESCLEN];
	int desc_gb[DESCLEN];
	int row_locb;
	int col_locb;

	float *locwork=NULL;
	int llocwork;

	INITIALIZE();

	SCALAR( "int", n);
	SCALAR( "int", bwl);
	SCALAR( "int", bwu);
	SCALAR( "int", nrhs);
	SCALAR("int",lda);
	SCALAR("int",ldb);
	SCALAR("int", lwork);

	SIZE(n);

	ROW(b);
	COL(b);
	MAXLDD( maxldd, b);
	maxldb=maxldd;
	
	bandMATRIX("float", a, bwl, bwu, n);
	MATRIX("float", b, ROW_b, COL_b);
	bandDISTRIBUTE("float", a, bwl, bwu, n);
	DISTRIBUTE("float", b, ROW_b, COL_b);

	llocwork = worklen(n,nrhs, bwl, bwu);
        llocwork = max(lwork,llocwork);
	WORK(locwork,llocwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(psdbsv)( &n, &bwl, &bwu, &nrhs,
                              loca, &one, desca,
                              locb, &one, descb,
                              locwork, &llocwork, &linfo);

	bandGATHER("float", a, bwl, bwu, n);
	GATHER("float", b, ROW_b, COL_b);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
	  *info = linfo;
	} else {
	}
	FREE_MATRIX(a);
	FREE_MATRIX(b);
        FREE(locwork);
	
}
