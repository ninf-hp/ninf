package ninf.metaserver;
import ninf.basic.*;
import ninf.common.*;
import ninf.client.*;
import java.io.DataInputStream;
import java.util.Observable;

public class NinfServerHolder extends Observable{
  static final CommandRepresent acceptCommands[] = {new CommandRepresent("serverInfo", 2)};
  static CommandParser parser = new CommandParser(acceptCommands);

  public NinfServerStruct struct;
  long updateTime;
  public LoadInformation load;
  public ServerCharacter serverChar;
  Set cproxys;

  NinfServerHolder(String str) {
    struct = new NinfServerStruct(str);
    cproxys = new Set();
  }
  public NinfServerHolder(String h, int p) {
    struct = new NinfServerStruct(h,p);
    cproxys = new Set();
  }
  public NinfServerHolder(String h, String port) {
    struct = new NinfServerStruct(h,port);
    cproxys = new Set();
  }
  NinfServerHolder(NinfPacketInputStream is) throws NinfException {
    struct = new NinfServerStruct(is);
    cproxys = new Set();
  }

  NinfServerHolder(DataInputStream is) throws NinfException {
    NinfCommand com =parser.readCommand(is);
    struct = new NinfServerStruct(com.args[0], com.args[1]);
    cproxys = new Set();
  }

  public NinfServerHolder(NinfServerStruct struct, LoadInformation load){
    this.struct = struct;
    this.load = load;
    cproxys = new Set();
  }

  public void setLoad(LoadInformation load){
    this.load = load;
    setChanged();
    notifyObservers();
  }

  public CommunicationInformation getThroughput(ServerID cproxy){
    CProxyInformation cproxyInfo = (CProxyInformation)
      cproxys.match(new CProxyMatch(cproxy));
    if (cproxyInfo == null) return null;
    return cproxyInfo.throughput;
  }

  public CommunicationInformation getLatency(ServerID cproxy){
    CProxyInformation cproxyInfo = (CProxyInformation)
      cproxys.match(new CProxyMatch(cproxy));
    if (cproxyInfo == null) return null;
    return cproxyInfo.latency;
  }

  void updateCProxy(ServerID cproxy,
		    CommunicationInformation throughput, 
		    CommunicationInformation latency){
    CProxyInformation cproxyInfo = (CProxyInformation)
      cproxys.match(new CProxyMatch(cproxy));
    if (cproxyInfo == null){
      cproxyInfo = new CProxyInformation(cproxy.host, cproxy.port);
      cproxys.add(cproxyInfo);
    }
    cproxyInfo.updateInfo(throughput, latency);
  }



/***************** OTHER FUNCTIONS *******************/

  public String toString() {
    return struct.toString();
  }
  public NinfCommand toCommand() {
    return struct.toCommand();
  }
  public int hashCode(){
    return struct.hashCode();
  }
  public boolean equals(Object o){
    if (!(o instanceof NinfServerHolder))
      return false;
    return (struct.equals(((NinfServerHolder)o).struct));
  }
}

class CProxyMatch implements BooleanFunction{
  ServerID cproxy;
  public boolean eval(Object o){
    CProxyInformation c = (CProxyInformation)o;
    return (c.hostname.equals(cproxy.host) && c.port == cproxy.port);
  }
  CProxyMatch(ServerID cproxyID){
    this.cproxy = cproxyID;
  }
}
