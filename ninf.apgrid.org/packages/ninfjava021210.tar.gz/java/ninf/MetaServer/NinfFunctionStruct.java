//
// NinfFunction.java
//

package ninf.MetaServer;
import ninf.basic.*;
import ninf.client.*;

import java.util.Vector;
import java.io.IOException;

/**
  NinfFunction holds several information about stub of NinfServer.
  To call a stub on a NinfServer, construct object from this class,
  and invoke the call() method.
*/
public class NinfFunctionStruct implements ninf.MetaServer.CallableStruct{

  /** the name */
  public FunctionName name;
   
  /** stub information */
  public NinfStub stub;

  /** servers */
  Vector servers = new Vector();

  /** FunctionManager */
  protected FunctionManager funcManager;

  /**
    Connect 'srv' and get stub 'name' information.
    */
  public NinfFunctionStruct(NinfServerStruct server, FunctionName name)
    throws NinfException {
    this.name = name;
    NinfServerConnection con = new NinfServerConnection(server);
    stub = con.getStub(name.entry_name);
    int index = con.currentIndex;
    servers.addElement(new ServerIndex(server, index));
    con.close();
  }

  public NinfFunctionStruct(NinfServerStruct server, NinfStub stub, int index){
    name = new FunctionName(stub.module_name, stub.entry_name);
    this.stub = stub;
    servers.addElement(new ServerIndex(server, index));
  }

  public void addManager(FunctionManager f){
    funcManager = f;
  }

/********************************************************/

  public void addServer(NinfServerStruct server, int index){
    servers.addElement(new ServerIndex(server, index));
  }

  public void addServer(NinfServerStruct server, FunctionName name) {
    try {
      NinfServerConnection con = new NinfServerConnection(server);
      int index = con.currentIndex;
      servers.addElement(new ServerIndex(server, index));
    } catch (Exception e){}
  }

  public void rmServer(NinfServerStruct s){
    Vector tmp = new Vector();
    for (int i = 0; i < servers.size(); i++){
      if (!((ServerIndex)servers.elementAt(i)).server.equals(s))
	tmp.addElement(servers.elementAt(i));
    }     
    servers = tmp;
  }

  /*
  public int cost(NinfExpression exp) {
    return server.rtt + server.performance * stub.getOrder(exp);
  }
  */
  
  public NinfStub stub() {
    return stub;
  }

  public String toString(){
    return stub.module_name + stub.entry_name;
  }

  public ServerIndex getProperStruct(int max) throws NinfException {
    ServerIndex ans = null;
    int lowest = Integer.MAX_VALUE;
    if (servers.size() == 0)
      throw new NinfNoServerException();
    for (int i = 0; i < servers.size(); i++){
      ServerIndex tmp = ((ServerIndex)servers.elementAt(i));
      int tmpload;
      if ((tmpload = tmp.server.load()) < lowest){
	ans = tmp;
	lowest = tmpload;
      }
    }
    if (lowest > max)
      return null;
    return ans;
  }

  public ServerIndex getProperStruct() throws NinfException{
    return getProperStruct(1000);
  }

  public ServerIndex getServerLock()  throws NinfException {
    return getProperStruct(0);
  }

  /**   to implement CallableStruct */
  public NinfCallable getCallable(){
//    return new NinfFunction(this, funcManager);
    return new CallLatch(this, funcManager);
  }

  public NinfNativeCallable getNativeCallable(){
    return new NinfFunction(this, funcManager);    
  }

  public NinfStub getStub(){return stub;}

}

// end of NinfFunctionStruct.java
