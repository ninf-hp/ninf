package bricks.util;
import java.util.*;

public class TraceFileStringsCreator extends SubComponentCreator {

    public String usage() {
	return "TraceFileStrings(<String fileName>)";
    }

    public SubComponent create(StringTokenizer st) throws BricksParseException{
	try {
	    String fileName = st.nextToken(" \t,()");
	    TraceFileStrings strings = new TraceFileStrings(fileName);
	    strings.initialize();
	    return strings;

	} catch (NoSuchElementException e) {
	    e.printStackTrace();
	    throw new BricksParseException(usage());
	}
    }
}

