package ninf.cproxy.aggregate;
import ninf.cproxy.*;
import ninf.basic.*;
import ninf.common.*;
import ninf.scheduler.*;
import ninf.client.*;
import java.io.*;

/* 
	funcname MODULE ENTRY
	calcOrder ORDER
  */

public class AggregateScheduled {
  public ServerIndex serverIndexes[];
  public ServerID    dataLocations[];

  static CommandParser serverIndexesParser = 
    new CommandParser(new CommandRepresent("serverIndexes",    1));
  static CommandParser dataLocationsParser = 
    new CommandParser(new CommandRepresent("dataLocations",    1));
		   
  public AggregateScheduled(ServerIndex serverIndexes[],
			    ServerID    dataLocations[]){
       this.serverIndexes = serverIndexes;
       this.dataLocations = dataLocations;
  }

  public AggregateScheduled(DataFlow dataFlow)throws NinfException {
    FuncNode[] funcNodes = dataFlow.funcNodes;
    DataNode[] dataNodes = dataFlow.dataNodes;

    dataLocations = new ServerID[dataNodes.length];
    serverIndexes = new ServerIndex[funcNodes.length];

    for (int i = 0; i < dataNodes.length; i++){
      dataLocations[i] = dataNodes[i].location;
      if (dataLocations[i] == null)
	throw new IncompleteScheduleException();	
    }

    for (int i = 0; i < funcNodes.length; i++){
      serverIndexes[i] = funcNodes[i].serverIndex;
      if (serverIndexes[i] == null)
	throw new IncompleteScheduleException();
    }
  }

  public AggregateScheduled(DataInputStream is) throws NinfException{
    NinfCommand com = serverIndexesParser.readCommand(is);
    int num = new Integer(com.args[0]).intValue();
    serverIndexes = new ServerIndex[num];
    for (int i = 0; i < num; i++)
      serverIndexes[i] = new ServerIndex(is);
    com = dataLocationsParser.readCommand(is);
    num = new Integer(com.args[0]).intValue();
    dataLocations = new ServerID[num];
    for (int i = 0; i < num; i++){
      dataLocations[i] = new ServerID(is);
    }
  }

  public void send(PrintStream ps) throws NinfException{
    (new NinfCommand("serverIndexes", ""+serverIndexes.length)).send(ps);
    for (int i = 0; i < serverIndexes.length; i++)
      serverIndexes[i].toCommand().send(ps);
    (new NinfCommand("dataLocations", ""+dataLocations.length)).send(ps);
    for (int i = 0; i < dataLocations.length; i++)
      dataLocations[i].toCommand().send(ps);
  }

}
