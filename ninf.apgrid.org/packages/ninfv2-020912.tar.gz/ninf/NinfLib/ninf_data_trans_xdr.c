/***************************
  ninf_data_trans  using XDR 
  ***************************/


void trans_dataTrans_sub(dataTrans * dt, char * buffer, DATA_TYPE type, int items){
  trans_dataTrans_sub_xdr(dt, buffer, type, items);
}
