#include <stdio.h>
#include <math.h>
#include "ninf_stub.h"

#define SIZE 100
int N[SIZE];
int M[SIZE];

extern int ninf_debug_flag;
int verbose = FALSE;


void init_array(int * A){
  int i;
  for (i = 0; i < SIZE; i++)
    A[i] = i;
}

int  test_array(int * A, int * B){
  int i;
  for (i = 0; i < SIZE; i++){
    if (A[i] != B[i])
      return FALSE;
  }
  return TRUE;
}

int group_test(){
  Ninf_group_t * gr;
  int i;

  printf("group testing: ");
  init_array(N);

  gr = Ninf_group_init("test/int_test_segv");
  if (gr == NULL){
    if (verbose) printf("group_init failed");    
    return FALSE;
  }
  for (i = 0; i < SIZE; i++){
    if (verbose) printf("----------------------------------%d\n", i);   
    if (Ninf_group_call_async(gr, i, 1, &(N[i]), &(M[i])) == NINF_ERROR){
      if (verbose) printf("call_async failed");
      return FALSE;
    }
  }
  Ninf_group_wait_all(gr);
  if (!test_array(N, M))
    return FALSE;
  return TRUE;
}

main(int argc, char ** argv)
{
  argc = Ninf_parse_arg(argc, argv);
  while (argc > 1){
    argv++;
    if (strcasecmp(*(argv), "-verbose") == 0)
      verbose = TRUE;
    if (strcasecmp(*(argv), "-debug") == 0)
      ninf_debug_flag = TRUE;
    argc--;
  }
  if (group_test())  {printf("\tOK\n");} else { printf("\tfailed\n");} 
}
