#ifndef __NINF_COMM_LIB__
#define __NINF_COMM_LIB__
#include "session.h"

int ninf_get_value(VALUE_TYPE value_type,int value,
		   NINF_EXPRESSION * exp, NINF_STUB_INFO *sp,
		   any_t *args, int default_value);
int ninf_get_arg(va_list * app, NINF_STUB_INFO * stub_info, 
		 any_t ninf_args[], struct callback callbacks[], resource rsc[]);
int ninf_send_args(ninf_session * session);

#endif
