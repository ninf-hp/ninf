#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>

#include "ninf_macros.h"
#include "ninf_comm_lib.h"
#include "callback.h"
#include "ninf_error.h"
#include "session.h"


#include "ninf_cim.h"

any_t          * new_arg(int num);

int type_size[] = {
  0,
  0,
  sizeof(char),
  sizeof(short),
  sizeof(int),
  sizeof(long),
  0,
  sizeof(unsigned char),
  sizeof(unsigned short),
  sizeof(unsigned int),
  sizeof(unsigned long),
  0,
  sizeof(float),
  sizeof(double)
};

char * cim_error_string[] = {
  "CIM OK",
};

int (*ninf_cim_init_hook)(obj_handler);
int (*ninf_cim_finalize_hook)(obj_handler);
int (*ninf_cim_proceed_hook)(obj_handler, int, int);
int (*ninf_cim_get_hook)(obj_handler, void *, DATA_TYPE);
int (*ninf_cim_put_hook)(obj_handler, void *, DATA_TYPE);
int (*ninf_cim_destruct_hook)(obj_handler);

int ninf_cim_init_default(obj_handler h){
  return CIM_ERROR_NOT_DEFINED;
}
int ninf_cim_finalize_default(obj_handler h){
  return CIM_ERROR_NOT_DEFINED;
}
int ninf_cim_proceed_default(obj_handler h, int rank, int n){
  return CIM_ERROR_NOT_DEFINED;
}
int ninf_cim_get_default(obj_handler h, void * p, DATA_TYPE d){
  return CIM_ERROR_NOT_DEFINED;
}
int ninf_cim_put_default(obj_handler h, void * p, DATA_TYPE d){
  return CIM_ERROR_NOT_DEFINED;
}
int ninf_cim_destruct_default(obj_handler h){
  return CIM_ERROR_NOT_DEFINED;
}

static void cim_before(){
  ninf_error_code = NINF_ERROR_NOERROR;
  ninf_error_user_string = NULL;
}

static void cim_after(int ret){
  if (ret != CIM_OK){
    if (ninf_error_user_string == NULL)
      ninf_set_error_string(cim_error_string[ret]);
    ninf_error_code = ret;
  }	
}


int ninf_cim_init(obj_handler h){
  int ret;
  cim_before();
  ret = (*ninf_cim_init_hook)(h);
  cim_after(ret);
  return ret;
}

int ninf_cim_finalize(obj_handler h){
  int ret;
  cim_before();
  ret = (*ninf_cim_finalize_hook)(h);
  cim_after(ret);
  return ret;
}

int ninf_cim_proceed(obj_handler h, int rank, int n){
  int ret;
  cim_before();
  ret = (*ninf_cim_proceed_hook)(h, rank, n);
  cim_after(ret);
  return ret;
}

int ninf_cim_get(obj_handler h, void * p, DATA_TYPE d){
  int ret;
  cim_before();
  ret = (*ninf_cim_get_hook)(h, p, d);
  cim_after(ret);
  return ret;
}
int ninf_cim_put(obj_handler h, void * p, DATA_TYPE d){
  int ret;
  cim_before();
  ret = (*ninf_cim_put_hook)(h, p, d);
  cim_after(ret);
  return ret;
}
int ninf_cim_destruct(obj_handler h){
  int ret;
  cim_before();
  ret = (*ninf_cim_destruct_hook)(h);
  cim_after(ret);
  return ret;
}

void Ninf_set_cim_funcs(int (*init)(obj_handler), 
		   int (*finalize)(obj_handler),
		   int (*proceed)(obj_handler, int, int),
		   int (*get)(obj_handler, void *, DATA_TYPE),
		   int (*put)(obj_handler, void *, DATA_TYPE),
		   int (*destruct)(obj_handler)){
  ninf_cim_init_hook      = init;
  ninf_cim_finalize_hook  = finalize;
  ninf_cim_proceed_hook   = proceed;
  ninf_cim_get_hook       = get;
  ninf_cim_put_hook       = put;
  ninf_cim_destruct_hook  = destruct;
}  

void set_cim_defaults(){
  Ninf_set_cim_funcs(ninf_cim_init_default,
		     ninf_cim_finalize_default, 
		     ninf_cim_proceed_default,
		     ninf_cim_get_default,
		     ninf_cim_put_default,
		     ninf_cim_destruct_default);
}

