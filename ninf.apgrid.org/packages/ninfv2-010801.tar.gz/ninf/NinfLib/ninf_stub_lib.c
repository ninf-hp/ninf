/*
 *  $Id: ninf_stub_lib.c,v 1.15 2001/01/26 13:29:32 nakada Exp $
 */

#define ERROR_MAIN

#include <stdio.h>
#include <signal.h>
#include <stdarg.h>
#include <stdlib.h>
#include <unistd.h>

#include "connection.h"
#include "callback.h"
#include "ninf_comm_lib.h"
#include "ninf_error.h"
#include "ninf_protocol.h"
#include "ninf_pipe.h"

#define USE_STUB_PKT

FILE * fdopen(int, const char *);
char * program_context = "STUB";

/**  ninf_debug_flag is defined in ninf_debug.c  **/
/*int ninf_debug_flag = FALSE;*/
extern int ninf_debug_flag;

static int Ninf_callback_send(any_t callback_args[], int start, int end);
static int Ninf_callback_receive(any_t ninf_args[], int start, int end);
static int get_resources_index(dataTrans * rDT, resource * c_resource);
static int Ninf_callback_get_arg(va_list * app, int num, any_t call_back_args[]);
static void print_time();
static int stub_alloc_work_mem();
/* begin matsubara writes */
static struct timeval st1, st2, fn2st3, fn1, fn3;
static double t1, t2, t3;
/* end matsubara write */
void ninf_get_arg_sub(va_list * app, NINF_STUB_INFO * ninf_stub_info_p, any_t ninf_args[], int start, int end, resource rsc[]);

int get_next_call_head(NINF_STUB_INFO * ninf_stub_info_p, int n);


#define UNIX_SOCK_NAME_FMT 	"/tmp/ninf.%d"

/* Ninf stub program libaray:
 *  Ninf_stub_INIT(argc,argv)
 *	Initalize all variable, make connection etc...
 *
 *  Ninf_stub_REQ()
 *	take request packet return 1 if NINF_REQ_CALL,
 *	return 0 if NINF_REQ_KILL, otherwise loop.
 *
 *  Ninf_stub_SET_ARG(cp,arg_i)
 *	Set values to arg.
 *	
 *  Ninf_stub_END()
 * 	Output results of OUT parameters.
 *
 *  Ninf_stub_EXIT()
 *	end the stub program.
 */

static  char local_sockname[30];
/* stub information of this stub */
extern NINF_STUB_INFO ninf_stub_info;

any_t ninf_args[MAX_PARAMS];

static struct timeval tm0, tminit, tmarg, tmend0, tmend1;
static int calc_time(struct timeval * a,  struct timeval * b);

static connection * client;
int sock_out;
int sock_err;

static char * hostname = "UNKNOWN";   /* getenv MYHOSTNAME */
static int port = -1;             /* getenv MYPORT */
char * TMP_FILE_ROOT = "/tmp";

resource * c_resource;

void
Ninf_stub_INIT(int argc, char * argv[])
{
    long ppid, pid;
    int local_sock;
    int i;

    /* connect to caller */
    /* as default, use parent pid as a socket name */
    if(ninf_debug_flag) gettimeofday(&tm0, NULL);

    if (argc < 2){
      ninf_fatal("ninf_stub: can't use pipe");
      exit(3);
    }


#ifndef USE_PIPE
    local_sock = get_fd_from_description(argv[1], NINF_PIPE_UNIXDOMAIN);
#else /* USE_PIPE */
    local_sock = get_fd_from_description(argv[1], NINF_PIPE_SOCKETPAIR);
#endif /* USE_PIPE */
    if (ninf_debug_flag)  printf("stub: using socket no.%d\n", local_sock);

#ifdef SSL_USE
    client = new_connection(local_sock, FALSE, FALSE, NULL);
#else
    client = new_connection(local_sock, FALSE, FALSE);
#endif

    

    if (argc > 2){  /* redirect treatment */
      int out, err;
	  /* printf("argc = %d, %s, %s \n", argc,  argv[2], argv[3]); */

#ifndef USE_PIPE
      out = get_fd_from_description(argv[2], NINF_PIPE_UNIXDOMAIN);
      err = get_fd_from_description(argv[3], NINF_PIPE_UNIXDOMAIN);
#else /* USE_PIPE */
      out = get_fd_from_description(argv[2], NINF_PIPE_SOCKETPAIR);
      err = get_fd_from_description(argv[3], NINF_PIPE_SOCKETPAIR);
#endif /* USE_PIPE */

      dup2(out,1);  /* redirect stdout to fdout[0] */
      dup2(err,2);  /* redirect stderr to fderr[0] */
      set_no_delay(1);
      set_no_delay(2);
    }
    if(ninf_debug_flag) printf("made dataTranses\n");

    pid = getpid();
    if(!trans_long(client->sDT, &pid))
      ninf_fatal("first packet send failed");
    if(ninf_debug_flag) printf("write dataTrans\n");

    write_flush(client->sDT);
    if(ninf_debug_flag) printf("flush dataTrans\n");

    if(ninf_debug_flag) gettimeofday(&tminit, NULL);

    if(ninf_debug_flag) printf("stub init End\n");

    if (getenv("MYHOSTNAME") != NULL)
      hostname = getenv("MYHOSTNAME");
    if (getenv("MYPORT") != NULL)
      port = atoi(getenv("MYPORT"));
    if (getenv("TMP_FILE_ROOT") != NULL)
      TMP_FILE_ROOT = getenv("TMP_FILE_ROOT");
    if (getenv("NINF_DEBUG") != NULL)
      ninf_debug_flag = TRUE;
    if (getenv("NINF_FORK_GDB") != NULL)
      fork_gdb(argv[0]);
}

fork_gdb(char * progname){
  int pid;
  char buffer[100];
  pid = getpid();

  sprintf(buffer, "xterm -e gdb %s %d", progname, pid);
  if (fork() == 0)
    system(buffer);
  else
    sleep(5);
}

/*
dumpDt(dataTrans * DT){
  int i = 0;
  print_dt(DT);
  
  for (i = 0; i < 10; i++)
    printf("%02x ", (*(DT->start + i)) & 0xff);
  printf("\n");
}
*/

Ninf_stub_REQ()
{
    int request,ncount,ack, i;
    char *p;
	long transmitted;
    
    if(ninf_debug_flag) printf("stub req start\n");

 next:
    if(ninf_debug_flag)
      printf("reading request\n");
    

    /* read request */

    /* dumpDt(client->rDT); */
    if(!trans_int(client->rDT,&request))
      ninf_fatal("read request failed");
    /*    dumpDt(client->rDT); */

    if(ninf_debug_flag)
      printf("request = %d\n",request);

    switch(request){
    case NINF_REQ_KILL:
      trans_destroy(client->rDT);
      return(FALSE);	/* exit loop */
    case NINF_REQ_STUB_INFO:

      ack = NINF_ACK_OK;
      if(!trans_int(client->sDT,&ack)) ninf_fatal("cannot encode ACK");
      trans_stub_info_all(client->sDT, &ninf_stub_info, TRUE);

      write_flush(client->sDT);      
      goto next;
    case NINF_REQ_STUB_INFO_LOCAL:           /* for ninf_local_exec */

      ack = NINF_ACK_OK;
      if(!trans_int(client->sDT,&ack)) ninf_fatal("cannot encode ACK");
      trans_stub_info(client->sDT, &ninf_stub_info, TRUE);

      write_flush(client->sDT);      
      goto next;
    case NINF_REQ_CALL:
      c_resource = new_resources(ninf_stub_info.nparam);
      
      /* begin matsubara writes */
         gettimeofday(&st1, 0); 

      /* receive scalar args */
      trans_scalar_args(client->rDT,&ninf_stub_info,ninf_args, FALSE);
      stub_alloc_work_mem();

      /* receive vector data */
      trans_vector_any_args_ft(client->rDT, &ninf_stub_info, ninf_args,
			       c_resource, 0, ninf_stub_info.nparam, FALSE, &transmitted);
      /* end matsubara writes */
         gettimeofday(&fn1, 0); 
      return(TRUE);		/* continue */

    case NINF_REQ_CALL_WITH_STREAM:      
      c_resource = new_resources(ninf_stub_info.nparam);

      gettimeofday(&st1, 0); 

      get_resources_index(client->rDT, c_resource);

      if (!trans_scalar_args(client->rDT,&ninf_stub_info,ninf_args, FALSE))
	return FALSE;
      stub_alloc_work_mem();

      if (!trans_vector_any_args_ft(client->rDT, &ninf_stub_info, ninf_args,
			       c_resource, 0, ninf_stub_info.nparam, FALSE, &transmitted))
	return FALSE;
      if (!trans_vector_any_from_stream(c_resource, 0, ninf_stub_info.nparam))
	return FALSE;

      gettimeofday(&fn1, 0); 

      return(TRUE);
    default:
      /* ninf_fatal("unknown request %d",request); */
      printf("STUB ERROR: unknown request %d(%x)\n",request, request);
/*      goto next;  */
    }
}

int stub_alloc_work_mem(){
  char * p;
  int i, ncount, nparam = ninf_stub_info.nparam;
  array_shape_info array_shape[MAX_DIM+1];
  int dum_inheader[MAX_DIM+1];
  for (i = 0; i < nparam; i++){
    struct ninf_param_desc *dp = &ninf_stub_info.params[i];

    if(dp->param_type == DT_FUNC_TYPE) break;  /* callback function */
    if(dp->ndim == 0) continue; 	/* scalar */
    /* compute the number of elemnts */
    ncount = trans_array_shape(dp,&ninf_stub_info,ninf_args, array_shape, dum_inheader);
    /* allocate memory for work array */
    if((p = (char *)calloc(ncount, DATA_TYPE_SIZE(dp->param_type)))
       == NULL){
      ninf_error("cannot allocate memory");
      return FALSE;
    }
    ninf_args[i].u.p = p;	/* set argument */
    if(ninf_debug_flag) 
      printf("allocate %d(0x%x) bytes\n",
	     ncount*DATA_TYPE_SIZE(dp->param_type),
	     ncount*DATA_TYPE_SIZE(dp->param_type));
  }
  return TRUE;
}

Ninf_stub_SET_ARG(void  *cp,int arg_i)
{
    struct ninf_param_desc *dp;
    any_t *ap;
    
    dp = &ninf_stub_info.params[arg_i];
    ap = &ninf_args[arg_i];

    if(ninf_debug_flag)
      fprintf(stderr, "Ninf_stub_SET_ARG(%d)=0x%x, 0x%x\n",arg_i,ap->u.i,ap->u.p);

    if (dp->ndim == 0){
      switch(dp->param_type){
      case DT_CHAR:
	*((char *)cp) = ap->u.c;
	break;
      case DT_SHORT:
	*((short *)cp) = ap->u.s;
	break;
      case DT_INT:
	*((int *)cp) = ap->u.i;
	break;
      case DT_LONG:
	*((long *)cp) = ap->u.l;
	break;
      case DT_UNSIGNED_CHAR:
	*((unsigned char *)cp) = ap->u.uc;
	break;
      case DT_UNSIGNED_SHORT:
	*((unsigned short *)cp) = ap->u.s;
	break;
      case DT_UNSIGNED:
	*((unsigned int *)cp) = ap->u.ui;
	break;
      case DT_UNSIGNED_LONG:
	*((unsigned long *)cp) = ap->u.l;
	break;
      case DT_FLOAT:
	*((float *)cp) = ap->u.f;
	break;
      case DT_DOUBLE:
	*((double *)cp) = ap->u.d;
	break;
      case DT_LONG_DOUBLE:
      case DT_UNSIGNED_LONGLONG:
      case DT_LONGLONG:
	ninf_fatal("not supported data type");
	break;
      case DT_STRING_TYPE:
	*((char **)cp) = ap->u.p;
	break;
      case DT_FILEPOINTER:
	*((FILE **)cp) = ap->u.p;
	break;
      case DT_FILENAME:
	*((char **)cp) = ap->u.p;
	break;
      default:
	ninf_fatal("unknown data type");
	break;
      }
    }  else *((char **)cp) = ap->u.p;	/* pointer */
    if(ninf_debug_flag) gettimeofday(&(tmarg), NULL);    
}

void _hook_for_sigsegv(int sig)
{
  int ack = NINF_ACK_ERROR;
  int code = STUB_ERROR_SIGSEGV;

  ninf_log("stub[%d]: got sigsegv", getpid());
  if(!trans_int(client->sDT, &ack)) ninf_fatal("cannot encode ACK");
  if(!trans_int(client->sDT, &code)) ninf_fatal("cannot encode error_code");
  write_flush(client->sDT);
  exit(3);
}

void _hook_for_sigfpe(int sig)
{
  int ack = NINF_ACK_ERROR;
  int code = STUB_ERROR_SIGFPE;

  ninf_log("stub[%d]: got sigsegv", getpid());
  if(!trans_int(client->sDT, &ack)) ninf_fatal("cannot encode ACK");
  if(!trans_int(client->sDT, &code)) ninf_fatal("cannot encode error_code");
  write_flush(client->sDT);
  exit(3);
}

void (* _prev_hook_sigsegv)(int);
void (* _prev_hook_sigfpe)(int);

int Ninf_stub_BEGIN()
{
  /* setup hooks */
  _prev_hook_sigsegv = signal(SIGSEGV, _hook_for_sigsegv);
  _prev_hook_sigfpe  = signal(SIGFPE,  _hook_for_sigfpe);

  gettimeofday(&st2, 0);
  return TRUE;
}

/* flush output result */
Ninf_stub_END()
{
    struct ninf_param_desc *dp;
    int nparam,i,ncount,ack;
	long transmitted;

  /* resume hooks */
    if (_prev_hook_sigsegv != SIG_ERR)
      signal(SIGSEGV, _prev_hook_sigsegv);
    if (_prev_hook_sigfpe  != SIG_ERR)
      signal(SIGFPE,  _prev_hook_sigfpe);

    if(ninf_debug_flag) gettimeofday(&tmend0, NULL);
    nparam = ninf_stub_info.nparam;

    setup_resource_ft(& ninf_stub_info, ninf_args, c_resource, 0, nparam);
    /* begin matsubara writes */
    gettimeofday(&fn2st3, 0);
    /* end matsubara writes */


    if (!trans_vector_any_to_stream(c_resource, 0, nparam))
      return FALSE;

    ack = NINF_ACK_OK;
    if(!trans_int(client->sDT, &ack)) ninf_fatal("cannot encode ACK");

    /** reverse sclar transfer: only for filepointer, for now */
    if (!trans_scalar_args(client->sDT,&ninf_stub_info,ninf_args,
			   FALSE))
      return FALSE;

    unlink_all(); 

    trans_vector_any_args_ft(client->sDT, & ninf_stub_info, ninf_args, 
			     c_resource, 0, nparam, FALSE, &transmitted);
    write_flush(client->sDT);

    /* begin matsubara writes */
    gettimeofday(&fn3, 0);
    /* end matsubara writes */


    /* begin matsubara writes */
    t1 = fn1.tv_sec - st1.tv_sec + (fn1.tv_usec - st1.tv_usec) * 1.0e-06;
    t2 = fn2st3.tv_sec - st2.tv_sec + (fn2st3.tv_usec - st2.tv_usec) * 1.0e-06;
    t3 = fn3.tv_sec - fn2st3.tv_sec + (fn3.tv_usec - fn2st3.tv_usec) * 1.0e-06;
    trans_double(client->sDT, &t1);
    trans_double(client->sDT, &t2);
    trans_double(client->sDT, &t3);

    trans_string_nolen(client->sDT, &hostname);
    trans_int(client->sDT, &port);
    write_flush(client->sDT);
    /* end matusbara writes */


    for(i = 0; i < nparam; i++){
      dp = &ninf_stub_info.params[i];
      if(dp->param_type == DT_FUNC_TYPE) break;  /* callback function */
      if(dp->ndim == 0) continue; /* scalar */
      if(ninf_debug_flag) 
	printf("freeing %d th param, address %p\n", i, ninf_args[i].u.p);
      free(ninf_args[i].u.p);		/* free area */
    }

    if(ninf_debug_flag) printf("Ninf_stub_END:exit\n");
    if(ninf_debug_flag) gettimeofday(&tmend1, NULL);
    if(ninf_debug_flag) print_time();
    return TRUE;
}

void Ninf_stub_EXIT()
{
  int ack;
  if (ninf_error_code == NINF_ERROR_NOERROR)
    return;

  ack = NINF_ACK_ERROR;

  
  if(!trans_int(client->sDT, &ack)) ninf_fatal("cannot encode ACK");
  if(!trans_int(client->sDT, &ninf_error_code)) ninf_fatal("cannot encode error_code");
  write_flush(client->sDT);
}



/***************************************
           call back function 
 ***************************************/

/* num is indexes of the callback function */
void Ninf_CallBack(int num, ...)
{
  int next;
  va_list ap;
  va_start(ap, num);

  if(ninf_debug_flag)
    printf("callback num:%d\n", num);
  
  next = Ninf_callback_get_arg(&ap, num, ninf_args);
  va_end(ap);

  Ninf_callback_send(ninf_args, num, next);
  Ninf_callback_receive(ninf_args, num, next);
}


/* read a ack & callback result */
int  Ninf_callback_receive(any_t ninf_args[], int start, int end)
{
  int ack;
  long transmitted;

  if(!trans_int(client->rDT,&ack))
    ninf_fatal("read callback ack failed");
  if(!trans_vector_array_args_ft(client->rDT, &ninf_stub_info, ninf_args, 
				 c_resource, start+1, end, TRUE, &transmitted))
    return(FALSE);
  if (ack != NINF_CALLBACK_ACK_OK){
    if (ninf_debug_flag)
      fprintf(stderr, "callback failed\n");
  } else {
    if (ninf_debug_flag)
      fprintf(stderr, "callback succeeded\n");
  }
  return TRUE;
}

int Ninf_callback_send(any_t callback_args[], int start, int end)
{
  int i, ncount, code;
  struct ninf_param_desc *dp;
  long transmitted;

  code = NINF_CALLBACK;
  
  if(!trans_int(client->sDT,&code)) ninf_fatal("cannot encode NINF_CALLBACK CODE");
  if(!trans_int(client->sDT,&start)) ninf_fatal("cannot encode CALLBACK index");

  if(!trans_scalar_args_ft(client->sDT, &ninf_stub_info, ninf_args, start+1, end, TRUE))
    return(NINF_ERROR);

  if(!trans_vector_array_args_ft(client->sDT, &ninf_stub_info, ninf_args, c_resource, start+1, end, TRUE, &transmitted))
    return(NINF_ERROR);

  write_flush(client->sDT);
}

static int Ninf_callback_get_arg(va_list * app, int num, any_t call_back_args[])
{
  struct ninf_param_desc *dp;
  int i, mode;
  int next = get_next_call_head(&ninf_stub_info, num+1);

  ninf_get_arg_sub(app, &ninf_stub_info, call_back_args, num+1, next, c_resource);
  return next;
}
char * save_str(char *);

int get_resources_index(dataTrans * rDT, resource * c_resource){
  int i;
  char buffer[MAX_STRING_LEN];
  char * buf = buffer;
  int val;
  resource * tmp;
  while(TRUE){
    if (!trans_int(rDT, &i))return FALSE;
    if (i < 0)
      return TRUE;
    tmp = c_resource + i;
    if (!trans_int(rDT, &val)) return FALSE;
    tmp->protocol = val;
    if (!trans_string(rDT, &buf, MAX_STRING_LEN))return FALSE;
    tmp->host = save_str(buf);
    if (!trans_string(rDT, &buf, MAX_STRING_LEN))return FALSE;
    tmp->port = save_str(buf);
    if (!trans_string(rDT, &buf, MAX_STRING_LEN))return FALSE;
    tmp->resource_name = save_str(buf);
    if (ninf_debug_flag) printf("%d: host = %s, port = %s, index = %s\n", i, tmp->host, tmp->port, tmp->resource_name);
  }
}

int calc_time(struct timeval * a,  struct timeval * b)
{
  return b->tv_usec - a->tv_usec + ((b->tv_sec - a->tv_sec) * 1000000);
}

void print_time()
{
  int i;
  printf("startup: %d, ", calc_time(&tm0, &tminit));
  printf("read: %d, ", calc_time(&tminit, &(tmarg)));
  printf("calc: %d, ", calc_time(&tmarg, &tmend0));
  printf("sendback: %d\n", calc_time(&tmend0, &tmend1));
}
