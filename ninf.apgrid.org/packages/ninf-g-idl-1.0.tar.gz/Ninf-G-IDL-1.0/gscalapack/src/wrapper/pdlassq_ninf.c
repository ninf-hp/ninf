#define _WRAPPER_
/* $Id: pdlassq_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define DOUBLE
#include <gscalapack.h>

void  pdlassq_ninf(	 int n,
		 double global_x[],
		 int incx,
		 double *scale,
		 double *sumsq
)
/* "pdlassq returns the values  scl  and  smsq  such that ( scl**2 )*smsq = x( 1 )**2 +...+ x( n )**2 + ( scale**2 )*sumsq, where  x( i ) X( IX+(JX-1)*DESCX(M_)+(i-1)*INCX ). The value of sumsq is assumed to be non-negative and scl returns the value scl = max( scale, abs( x( i ) ) )." */
/* OPTIONS */
{
	int maxldd;

	int maxldx;
	double *locx=NULL;
	int descx[DESCLEN];
	int desc_gx[DESCLEN];
	int row_locx, col_locx;
	int ROW_x, COL_x;

	double lscale[1];
	double lsumsq[1];

	INITIALIZE();

	SCALAR("int", n);
	SCALAR("int",incx);

	COMMON("double", scale, 1);
	COMMON("double", sumsq, 1);

	*lscale=*scale;
	*lsumsq=*sumsq;

	square(n, ROW_x, COL_x);
	if (incx!=1) incx=ROW_x;

	ROW(x);
	COL(x);
	MAXLDD( maxldd, x );
	maxldx=maxldd;

	MATRIX("double", x, ROW_x, COL_x);
	DISTRIBUTE("double", x, ROW_x, COL_x);

	if  (( mypnum != 0 ) ^ (serial==1) ) {
	 FortranCall(pdlassq)( &n,
			       locx, &one, &one, descx,
			       &incx,
			       &lscale, &lsumsq);
	  Csgsum2d( PARA_CTXT, "A", MPI_TOP, 1, 1, lscale, 1, 0, 1);
	  Csgsum2d( PARA_CTXT, "A", MPI_TOP, 1, 1, lsumsq, 1, 0, 1);
	}

	RETRIEVE("double", &lscale, 1);
	RETRIEVE("double", &lsumsq, 1);

	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
	  *scale=*lscale;
	  *sumsq=*lsumsq;
	} else {
	}

        FREE_COMMON(scale);
        FREE_COMMON(sumsq);
        FREE_MATRIX(x);

}

