#define _WRAPPER_
/* $Id: pdlatrd_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define _DISTRIBUTE_1D_
#define DOUBLE
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n

#define ROW_w ldw
#define COL_w nb

static	int worklen(int n) {
	  int ret=1;
	  ret = n+10;
	  if NEED_BUFF {
	    ret = cbloc + 10;
	  }
	  return ret;
}

void  pdlatrd_ninf(	 char uplo,
		 int n,
		 int nb,
		 double global_a[],
		 int lda,
		 double global_d[],
		 double global_e[], //uplo
		 double global_tau[],
		 double global_w[],
		 int ldw,
		 double work[],
		 int lwork
)
/* "pdlatrd reduces NB rows and columns of a real symmetric distributed matrix A to symmetric tridiagonal form by an orthogonal similarity transformation Q' * A * Q,  and returns the matrices V and W which are needed to apply the transformation to the unreduced part of A." */
/* OPTIONS */
{
	int maxldd;

	int maxlda;
	double *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
	int row_loca, col_loca;

	double *locd=NULL;
	double *loce=NULL;
	int desctdd[DESCLEN], desc_gtdd[DESCLEN];

	int maxldw;
	double *locw=NULL;
	int descw[DESCLEN];
	int desc_gw[DESCLEN];
	int row_locw, col_locw;

	double *loctau=NULL;

	double *locwork=NULL;
	int llocwork;

	INITIALIZE();

	SCALAR( "char", uplo);
	SCALAR( "int", n);
	SCALAR( "int", nb);
	SCALAR( "int", lda);
	SCALAR( "int", ldw);
	SCALAR( "int", lwork);

	SIZE(n);

	ROW( a);
	COL( a);
	ROW( w);
	COL( w);
	MAXLDD( maxldd, a );
	maxlda = maxldd;
	maxldw = maxldd;

	MATRIX( "double", a, ROW_a, COL_a);
	DISTRIBUTE( "double", a, ROW_a, COL_a);
	if (chrcmp(uplo,'U')==0) tdMATRIX( "double", 0, d, e,n);
	else tdMATRIX( "double", e, d, 0, n);
	MATRIX( "double", w, ROW_w, COL_w);
	VECTOR("c","double", tau, n);

	llocwork=worklen(n);
	llocwork = max(lwork, llocwork);
	WORK(locwork,llocwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pdlatrd)( &uplo,
                               &n, &nb,
                               loca, &one, &one, desca,
                               locd, loce,
                               loctau,
                               locw, &one, &one, descw,
                               locwork);

	GATHER( "double", a, ROW_a  , COL_a);
	if (chrcmp(uplo,'U')==0) tdGATHER( "double", 0, d, e, n);
	else tdGATHER( "double", e, d, 0, n);
	vGATHER("c", "double", tau, n);
	GATHER( "double", w, ROW_w, COL_w);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
	} else {
	}

	FREE_MATRIX(a);
	FREE_MATRIX(d);
	FREE_MATRIX(e);
	FREE_VECTOR(tau);
	FREE_MATRIX(w);
	FREE(locwork);

}

