package bricks.environment;
import bricks.util.*;
import java.util.*;

public class HostCreator extends ComponentCreator {

    // for bricks.tools.ShowUsage
    public HostCreator() {}
    private ComponentFactory componentFactory;

    public HostCreator(
	SimulationSet owner, ComponentFactory componentFactory,
	SubComponentFactory subComponentFactory
    ) {
	this.owner = owner;
	this.componentFactory = componentFactory;
	this.subComponentFactory = subComponentFactory;
    }

    public String usage() {
	return "Host <String key> <String keyOfResourceDB> <Client client> <Server server> <Disk disk>";
    }

    public void create(String str) throws BricksParseException {
	try {
	    // modify PARSE
	    StringTokenizer st = new StringTokenizer(str);
	    String tmp = st.nextToken(" \t(),"); // host
	    String key = st.nextToken(" \t(),");
	    String keyOfResourceDB = st.nextToken(" \t(),");
	    SimulationDebug.println("HostCreator.create(): " + tmp + ", " + 
				    key + ", " + keyOfResourceDB);

	    String clientString = null;
	    String serverString = null;
	    String diskString = null;

	    tmp = st.nextToken(" \t(),");
	    if (tmp.equalsIgnoreCase("client")) {
		clientString = tmp;
		while (st.hasMoreElements()) {
		    tmp = st.nextToken(" \t(),");
		    if (tmp.equalsIgnoreCase("server") || 
			tmp.equalsIgnoreCase("fallbackserver"))
			break;
		    clientString += " " + tmp;
		}
	    }
	    SimulationDebug.println("clientString = " + clientString);

	    serverString = tmp;
	    while (st.hasMoreElements()) {
		tmp = st.nextToken(" \t(),");
		if (tmp.equalsIgnoreCase("disk"))
		    break;
		serverString += " " + tmp;
	    }
	    SimulationDebug.println("serverString = " + serverString);
	    diskString = tmp;
	    while (st.hasMoreElements()) {
		diskString += " " + st.nextToken(" \t(),") + " ";
	    }
	    SimulationDebug.println("diskString = " + diskString);

	    Client client = (Client)componentFactory.create(clientString);
	    Server server = (Server)componentFactory.create(serverString);
	    Disk disk = (Disk)componentFactory.create(diskString);

	    Host host = 
		new Host(owner, key, keyOfResourceDB, client, server, disk);
	    owner.register(key, host);

	} catch (NoSuchElementException e) {
	    e.printStackTrace();
	    throw new BricksParseException(usage());

	} catch (NullPointerException e) {
	    e.printStackTrace();
	    throw new BricksParseException(usage());

	} catch (BricksParseException e) {
	    e.addMessage(usage());
	    throw e;
	}
    }
}
