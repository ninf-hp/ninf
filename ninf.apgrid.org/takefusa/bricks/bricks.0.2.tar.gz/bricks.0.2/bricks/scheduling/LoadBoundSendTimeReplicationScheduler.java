package bricks.scheduling;
import bricks.util.*;
import bricks.environment.*;
import java.util.*;

public class LoadBoundSendTimeReplicationScheduler extends DataGridScheduler implements SchedulingUnit {

    double minLoadScore;

    public LoadBoundSendTimeReplicationScheduler(
	String keyOfMetaPredictor, String keyOfReplicaManager, 
	String keyOfServerMonitor, double minLoadScore
    ) {
	this.keyOfMetaPredictor = keyOfMetaPredictor;
	this.keyOfReplicaManager = keyOfReplicaManager;
	this.keyOfServerMonitor = keyOfServerMonitor;
	this.minLoadScore = minLoadScore;
	schedulingOverhead = 0.0;
    }

/************************* needed method *************************/
    public String getName() {
	return "LoadBoundSendTimeReplicationScheduler";
    }

    protected boolean dispatchOK(
	double currentTime, RequestedData data, Host host
    ) {
	StaticHostInfo staticInfo = resourceDB.getStaticHostInfo(host);
	HostInfo info = getHostInfo(currentTime, host);
	//System.out.println(
	//   "LBSTRScheduler: " + host + 
	//   " : perf = " + staticInfo.performance + 
	//   ", load = " +  info.loadAverage + 
	//   ", score = " + (staticInfo.performance / (info.loadAverage + 1.0)));

	if (minLoadScore >= staticInfo.performance && info.loadAverage < 1.0)
	    return true;

	if (staticInfo.performance / (info.loadAverage + 1.0) >= minLoadScore)
	    return true;
	else
	    return false;
    }
}

