package ninf.netsolve;
// import java.io.*;
// import java.awt.*;
import java.awt.Frame;
import java.awt.Event;
import java.awt.TextArea;
import java.awt.Button;
import java.awt.Panel;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Color;
import java.awt.Font;

public class ServerList extends Frame{
  private Button  close_button;
  private Button  update_button;
  private TextArea message;
  private String agent;
  public int cur_lang = Labels.language;

  public ServerList(GetServers gs, String agent_name) {

    super();
    super.setTitle(Labels.server_title[cur_lang]);
    agent = agent_name;
    this.setLayout(new BorderLayout(5,5));

    Panel p1 = new Panel();
    p1.setLayout(new FlowLayout(FlowLayout.CENTER,15,15));
    close_button = new Button(Labels.close[cur_lang]);
    close_button.setFont(new Font("TimesRoman",Font.BOLD,14));
    update_button = new Button(Labels.update[cur_lang]);
    update_button.setFont(new Font("TimesRoman",Font.BOLD,14));
    p1.add(update_button);
    p1.add(close_button);

    message = new TextArea(20,90);

    /* set to default to get a fixed-size font
          so that formatting is easier */
    message.setFont(new Font("default",Font.PLAIN,13));
    message.setEditable(false);

    this.add("South",p1);
    this.add("North",message);

    message.setText(gs.status_string());

    this.show();
    this.pack();
    
  }

  public boolean action(Event e, Object arg) {
 
   if (e.target == close_button) {
     this.hide();
     this.dispose(); 
   }
   else if (e.target == update_button) {
     try {
       GetServers gs = new GetServers(agent);
       message.setText(gs.status_string());
     }catch(NetSolveException exc) {
       System.err.println( Labels.info_error[cur_lang]
          + exc.getMessage());
     }
   }
   return true;
  }
}
