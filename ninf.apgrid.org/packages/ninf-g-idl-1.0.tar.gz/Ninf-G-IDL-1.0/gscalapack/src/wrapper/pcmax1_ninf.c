#define _WRAPPER_
/* $Id: pcmax1_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define SCOMPLEX
#include <gscalapack.h>

void  pcmax1_ninf(	 int n,
		 scomplex *amax,
		 int *indx,
#ifdef HAVE_ABS                
		 scomplex global_x[],
#else
                 scomplex global_x[],
#endif                
		 int incx
)
/* "pcmax1 computes the global index of the maximum element in absolute value of a distributed vector X. The global index is returned in INDX and the value is returned in AMAX." */
/* OPTIONS */
{
	scomplex lamax[1];
	int lindx[1];

	int maxldd;
	scomplex *locx=NULL;
	int descx[DESCLEN];
	int desc_gx[DESCLEN];
	int row_lox, col_locx;
	int ROW_x, COL_x;


	INITIALIZE();

	SCALAR( "int", n);
	SCALAR("int",incx);

	square( 1+(n-1)*abs(incx), &ROW_x, &COL_x);

	ROW(x);
	COL(x);
	MAXLDD(maxldd,x );
	
	MATRIX( "scomplex", x, ROW_x, COL_x);
	DISTRIBUTE( "scomplex", x, ROW_x, COL_x);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranFormat(pcmax1)( &n, lamax, lindx, locx, &one, &one, descx, &incx);

	RETRIEVE( "float", lamax, 1);
	RETRIEVE( "int", lindx, 1);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
		*amax = *lamax;
		*indx = *lindx;
	} else {
	}
        
        FREE_MATRIX(x);
}

