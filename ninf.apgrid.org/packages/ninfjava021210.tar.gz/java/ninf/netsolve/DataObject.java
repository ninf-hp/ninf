package ninf.netsolve;
import java.io.*;
import ninf.basic.XDROutputStream;

public class DataObject{
  public int m;
  public int n;
  public Object content;

  public DataObject(int m, int n, Object content){
    this.m = m;
    this.n = n;
    this.content = content;
  }

  public DataObject(int m, Object content){
    this.m = m;
    this.n = 1;
    this.content = content;
  }

  public DataObject(int i){
    this.m = 1; this.n = 1;
    int tmp[] = new int[1];
    tmp[0] = i;
    this.content = tmp;
  }
  public DataObject(char i){
    this.m = 1; this.n = 1;
    char tmp[] = new char[1];
    tmp[0] = i;
    this.content = tmp;
  }
  public DataObject(double i){
    this.m = 1; this.n = 1;
    double tmp[] = new double[1];
    tmp[0] = i;
    this.content = tmp;
  }
  public DataObject(float i){
    this.m = 1; this.n = 1;
    float tmp[] = new float[1];
    tmp[0] = i;
    this.content = tmp;
  }

  public int[] makeSize(){
    int tmp[] = new int[2];
    tmp[0] = m;
    tmp[1] = n;
    return tmp;
  }

  public byte[] write(int data_type) throws IOException{
    ByteArrayOutputStream bs = new ByteArrayOutputStream();
    XDROutputStream os = new XDROutputStream(bs);
    switch(data_type){
    case NetSolveObject.NETSOLVE_I: {
      int tmp[] = (int[])content;
      for (int j = 0; j < n; j++)
	for (int i = 0; i < m; i++)
	  os.writeInt(tmp[j*m+i]);
      break;
    }
    case NetSolveObject.NETSOLVE_S: {
      float tmp[] = (float[])content;
      for (int j = 0; j < n; j++)
	for (int i = 0; i < m; i++)
	  os.writeFloat(tmp[j*m+i]);
      break;
    }
    case NetSolveObject.NETSOLVE_D: {
      double tmp[] = (double[])content;
      for (int j = 0; j < n; j++)
	for (int i = 0; i < m; i++)
	  os.writeDouble(tmp[j*m+i]);
      break;
    }
    case NetSolveObject.NETSOLVE_C: {
      char tmp[] = (char[])content;
      for (int j = 0; j < n; j++)
	for (int i = 0; i < m; i++)
	  os.writeByte(tmp[j*m+i]);
      break;
    }
    default :
      throw new IOException();
    }
    return bs.toByteArray();
  }



}
   
