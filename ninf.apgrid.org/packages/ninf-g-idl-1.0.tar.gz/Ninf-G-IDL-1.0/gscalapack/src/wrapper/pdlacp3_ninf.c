#define _WRAPPER_
/* $Id: pdlacp3_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n
#define ROW_b ldb
#define COL_b m
void  pdlacp3_ninf(	 int m,
		 int i,
		 double a[],
		 int lda,
		 int n,
		 double global_b[],
		 int ldb,
		 int node_ii,
		 int node_jj,
		 int rev
)
/* "pdlacp3 is an auxiliary routine that copies from a global parallel array into a local replicated array or vise versa." */
/* OPTIONS */
{
	int maxldd;

	int desca[DESCLEN];

	double *locb=NULL;
	int maxldb;
	int descb[DESCLEN];
	int desc_gb[DESCLEN];
	int row_locb, col_locb;

	INITIALIZE();

	SCALAR( "int", m);
	SCALAR( "int", i);
	SCALAR("int", lda);
	SCALAR("int", n);
	SCALAR("int", ldb);
	SCALAR("int", node_ii);
	SCALAR("int",node_jj);
	SCALAR("int", rev);

	COMMON_MATRIX( "double", a, ROW_a, COL_a);
	Cdescinit( desca, ROW_a, COL_a, ROW_a, COL_a, 0, 0, PARA_CTXT, ROW_a, &linfo);

	ROW(b);
	COL(b);
	MAXLDD( maxldd, b );
	maxldb=maxldd;

	MATRIX( "double", b, ROW_b, COL_b);
	DISTRIBUTE( "double", b, ROW_b, COL_b);

	if  (( mypnum != 0 ) ^ (serial==1) )
		FortranCall(pdlacp3)( &m, &i,
				      a, desca,
				      locb, &ldb,
				      &node_ii, &node_jj, &rev);

	RETRIEVE( "double", a, ROW_a*COL_a);

	GATHER("double",b, ROW_b, COL_b);
	RETRIEVE( "int", &linfo, 1);

	if( mypnum == 0 ){

	} else {

	}
	FREE_COMMON(a);
	FREE_MATRIX(b);
}

