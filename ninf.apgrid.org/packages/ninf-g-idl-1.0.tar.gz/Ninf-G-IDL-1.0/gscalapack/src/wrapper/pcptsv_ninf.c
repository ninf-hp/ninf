#define _WRAPPER_
/* $Id: pcptsv_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define _DISTRIBUTE_1D_
#define SCOMPLEX
#define _REAL_DIAGONAL_
#include <gscalapack.h>
#define ROW_b ldb
#define COL_b nrhs
static	int worklen(int nrhs){
#define NB blocsize
	  int ret=1;
          ret= (12 + 3*NB)  +max((10+2*min(100,nrhs))+4*nrhs, 8);
	  if NEED_BUFF ret= (12*npcol + 3*NB)  +max((10+2*min(100,nrhs))*npcol+4*nrhs, 8*npcol);
	  return ret;
}

void  pcptsv_ninf(	 int n,
		 int nrhs,
		 float global_d[],
		 scomplex global_e[],
		 scomplex global_b[],
		 int ldb,
		 int *info
)
/* "pcptsv solves a system of linear equations A * X = B where A is an N-by-N complex tridiagonal symmetric positive definite distributed matrix." */
/* OPTIONS */
{
    extern void FortranCall(pcptsv)( int*, int*,
                              float*, scomplex*, int*, int*,
                              scomplex*, int*, int*,
                              scomplex*, int*, int*);

	int maxldd;

	scomplex *locb=NULL;
	int maxldb;
	int row_locb;
	int col_locb;
	int descb[DESCLEN];
	int desc_gb[DESCLEN];

	int desc_gtdd[DESCLEN];
	int desctdd[DESCLEN];
	float *locd=NULL;
	scomplex *loce=NULL;

	scomplex *locwork=NULL;
	int llocwork;

	INITIALIZE();

	SCALAR( "int", n);
	SCALAR( "int", nrhs);
	SCALAR("int", ldb);
	SIZE(n);

	ROW(b);
	COL(b);
	MAXLDD(maxldd, b);
	maxldb=maxldd;

	tdMATRIX( "scomplex", e, d, e, n); // if d=du, then distribute du
	MATRIX("scomplex", b, ROW_b, COL_b);
	tdDISTRIBUTE( "scomplex", e, d, e, n);
	DISTRIBUTE( "scomplex", b, ROW_b, COL_b);

	llocwork = worklen(nrhs);
	WORK( locwork, llocwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pcptsv)( &n, &nrhs,
                              locd, loce, &one, desctdd,
                              locb, &one, descb,
                              locwork, &llocwork, &linfo);

	tdGATHER("scomplex", e, d, e, n); 
	GATHER("scomplex", b, ROW_b, COL_b);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
	  *info = linfo;
	} else {
	}

        FREE_MATRIX(d);
        FREE_MATRIX(e);
        FREE_MATRIX(b);
        
	FREE(locwork);
}

