#define _WRAPPER_
/* $Id: pzgbtrf_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define _DISTRIBUTE_1D_
#define DCOMPLEX
#define PIVOT
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n
static	int worklen() {
	  int ret=1;
	  ret = 10;
	  return ret;
}

void  pzgbtrf_ninf(	 int n,
		 int bwl,
		 int bwu,
		 dcomplex global_a[],
		 int lda,
		 int global_ipiv[],
		 int *info
)
/* "pzgbtrf computes a LU factorization of an N-by-N complex banded distributed matrix with bandwidth BWL, BWU: A." */
/* OPTIONS */
{
    extern void FortranCall(pzgbtrf)( int*, int*, int*,
                               dcomplex*, int*, int*,
                               int*,
                               dcomplex*, int*,
                               dcomplex*, int*, int*);

  int maxldd;

	int maxlda;
	dcomplex *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];

	dcomplex *locaf=NULL;
	int laf;
	dcomplex *locwork=NULL;
	int llocwork;

	int *locipiv=NULL;

        

	//	int ipivlen() {
	//	  int ret=1;
	//	  ret = 2*maxldd;
	//	  return ret;
	//	}

	INITIALIZE();

	SCALAR( "int", n);
	SCALAR( "int", bwl);
	SCALAR( "int", bwu);
	SCALAR("int", lda);

	SIZE(n);

	bandMATRIX("dcomplex", a, bwl, bwu, n);
	bandDISTRIBUTE("dcomplex", a, bwl, bwu, n);
	VECTOR( "c", "int", ipiv, n);

	llocwork = worklen();
	WORK(locwork,llocwork);

	laf=(cbloc+bwu)*(bwl+bwu)+6*(bwl+bwu)*(bwl+2*bwu);
	locaf=MALLOC(sizeof(dcomplex)*laf);
        assert(locaf);
        
	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pzgbtrf)( &n, &bwl, &bwu,
                               loca, &one, desca,
                               locipiv,
                               locaf, &laf,
                               locwork, &llocwork, &linfo);

	bandGATHER( "dcomplex", a,  bwl ,bwu, n);
	vGATHER( "c", "int", ipiv, n);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
	  *info = linfo;
	} else {
	}
	FREE_MATRIX(a);
	FREE_VECTOR(ipiv);
        
        FREE(locwork);
        FREE(locaf);
	
}

