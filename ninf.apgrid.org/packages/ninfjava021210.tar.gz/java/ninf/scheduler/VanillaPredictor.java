package ninf.scheduler;

import ninf.basic.*;
import ninf.common.*;
import ninf.client.*;
import ninf.metaserver.*;

public class VanillaPredictor extends Predictor{
  public VanillaPredictor(DirectoryService service){
    super(service);
  }

  public void scheduled(RequestID request, CallInformation callInfo, 
			ScheduleResult result){
    service.scheduled(request, callInfo, result);
  }

  public void done(RequestID request, CallInformation callInfo, 
		   ScheduleResult result){
    service.done(request, callInfo, result);
  }
  
  public LoadInformation getLoadInformation(NinfServerStruct server)
  throws NinfException {
    return service.getLoadInformation(server);
  }

  public CommunicationInformation getThroughput(NinfServerStruct server, 
						ServerID cproxy)
  throws NinfException {
    NinfServerHolder holder = service.getHolder(server);
    if (holder == null)
      return null;
    return holder.getThroughput(cproxy);
  }

  public CommunicationInformation getLatency(NinfServerStruct server, 
						ServerID cproxy)
  throws NinfException {
    NinfServerHolder holder = service.getHolder(server);
    if (holder == null)
      return null;
    return holder.getLatency(cproxy);
  }
}
