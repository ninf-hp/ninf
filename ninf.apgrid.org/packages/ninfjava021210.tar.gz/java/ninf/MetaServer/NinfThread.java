package ninf.MetaServer;
import ninf.basic.*;
import ninf.client.*;


import java.util.Vector;
import java.lang.Runnable;

public class NinfThread implements Runnable {
  public Thread current;
  public Vector lower;
  int index;
  protected boolean succeeded = true;

  public NinfThread(){
    current = new Thread(this);
    reset();
  }

  public void incIndex(){
    index++;
  }

  public void addLower(NinfThread t){
    lower.addElement(t);
    t.incIndex();
  }
  
  public void start(){
    this.startNow(true);
  }

  public void startNow(boolean s){
    succeeded &= s;
    index--;
    if (index <= 0){
      current.start();
    }
  }

  public void reset(){
    index = 1;
    lower = new Vector();
  }

  public void runSub(){
  }

  public void run(){
    runSub();
    end();
  }

  public void end(){
    for (int i = 0; i < lower.size(); i++)
      ((NinfThread)lower.elementAt(i)).startNow(succeeded);
  }

  public void kill(){
    current.stop();
  }
}
