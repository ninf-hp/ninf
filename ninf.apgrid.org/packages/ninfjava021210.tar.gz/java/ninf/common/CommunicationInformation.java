package ninf.common;
import ninf.basic.*;
import java.io.*;

public class CommunicationInformation implements Cloneable{
  static final CommandRepresent acceptCommands[] = {new CommandRepresent("communicationInformation", 4)};
  static NinfLog dbg = new NinfLog("CommunicationInformation");
  static CommandParser parser = new CommandParser(acceptCommands);

  public double rtt;    /* in second */
  public int  size;     /* in bytes */
  public int  mode;

  public long when;   // measured time 

  public double throughput;

  public CommunicationInformation(DataInputStream is) throws NinfException{
    NinfCommand com =parser.readCommand(is);
    rtt  = new Double(com.args[0]).doubleValue();
    size = new Integer(com.args[1]).intValue();
    mode = new Integer(com.args[2]).intValue();
    when = System.currentTimeMillis() - new Integer(com.args[3]).intValue();
      // simple calibration:  I know its not enough.
    throughput = (double)size * 1000 * (mode == 0? 2: 1)/ (double)rtt;
  }


    /** the argument rtt_long represents milli sec */
  public CommunicationInformation(long rtt_long, int size, int mode){
    this.rtt = rtt / 1000.0;
    this.size = size;
    this.mode = mode;
    this.when = System.currentTimeMillis();
    throughput = (double)size * 1000 * (mode == 0? 2: 1)/ (double)rtt;
  }

  public CommunicationInformation(double rtt, int size, int mode){
    this.rtt = rtt;
    this.size = size;
    this.mode = mode;
    this.when = System.currentTimeMillis();
    throughput = (double)size * (mode == 0? 2: 1)/ rtt;
  }

  public NinfCommand toCommand(){
    long past = System.currentTimeMillis() - when;
    return new NinfCommand("communicationInformation", ""+rtt, ""+size, ""+mode, ""+past);
  }

  public CommunicationInformation copy() throws NinfException{
    try {
      return (CommunicationInformation)this.clone();
    } catch (CloneNotSupportedException e){
      throw new NinfException("loadinformation clone failed");
    }
  }

}
