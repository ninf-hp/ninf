/*
 *  $Id: ninf_data_trans_basic.c,v 1.7 1999/05/17 23:51:49 nakada Exp $
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "ninf_data_trans.h"

#ifdef  __cplusplus
extern "C" {
#endif
bool_t xdr_scomplex(XDR *xdrs, float *bp);
bool_t xdr_dcomplex(XDR *xdrs, double *bp);
#ifdef  __cplusplus
}
#endif

extern int ninf_debug_flag;

bool_t xdr_string_len(XDR *xdrs, char  **sp)
{
  xdr_string(xdrs, sp, MAX_STRING_LEN);
}



int make_xdr(dataTrans * dt, XDR * xdrp){
  if (dt->flag == XDR_ENCODE){
/*    if (dt->end - dt->position < 20)
      *((char *)0) = 10;
    printf("%p, %p\n", dt->end, dt->position);
*/
    xdrmem_create(xdrp, dt->position, dt->end - dt->position, (enum xdr_op)dt->flag);
  }  else
    xdrmem_create(xdrp, dt->position, dt->valid_end - dt->position, (enum xdr_op)dt->flag);
}

bool_t xdr_scomplex(XDR *xdrs, float *bp){
  if (!xdr_float(xdrs, bp))
    return FALSE;
  if (!xdr_float(xdrs, bp+1))
    return FALSE;
  return TRUE;
}

bool_t xdr_dcomplex(XDR *xdrs, double *bp){
  if (!xdr_double(xdrs, bp))
    return FALSE;
  if (!xdr_double(xdrs, bp+1))
    return FALSE;
  return TRUE;
}

int trans_scomplex(dataTrans * dt, float * val){
  XDR xdrs;
retry:
  make_xdr(dt, &xdrs);
  if (!xdr_scomplex(&xdrs, val)){
    if (!do_onemore(dt))
      return FALSE;

    goto retry;
  } 
  dt->position += xdr_data_length(DT_SCOMPLEX);
  return TRUE;
}

int trans_dcomplex(dataTrans * dt, double * val){
  XDR xdrs;
retry:
  make_xdr(dt, &xdrs);
  if (!xdr_dcomplex(&xdrs, val)){
    if (!do_onemore(dt))
      return FALSE;
    goto retry;
  } 
  dt->position += xdr_data_length(DT_DCOMPLEX);
  return TRUE;
}


int trans_char(dataTrans * dt, char * val){
retry:
  if ((dt->flag == XDR_ENCODE && 
       (dt->end - dt->position) < xdr_data_length(DT_CHAR)) ||
      (dt->flag == XDR_DECODE && 
       (dt->valid_end - dt->position) < xdr_data_length(DT_CHAR))){
    if (!do_onemore(dt))
      return FALSE;
    goto retry;
  }
  trans_char_raw_single(dt, val);
  return TRUE;
}
int trans_short(dataTrans * dt, short * val){
retry:
  if ((dt->flag == XDR_ENCODE && 
       (dt->end - dt->position) < xdr_data_length(DT_SHORT)) ||
      (dt->flag == XDR_DECODE && 
       (dt->valid_end - dt->position) < xdr_data_length(DT_SHORT))){
    if (!do_onemore(dt))
      return FALSE;
    goto retry;
  }
  trans_short_raw_single(dt, (char *)val);
  return TRUE;
}

int trans_int(dataTrans * dt, int * val){
  XDR xdrs;
retry:
  make_xdr(dt, &xdrs);
  if (!xdr_int(&xdrs, val)){
    if(ninf_debug_flag) printf("xdr_int failed\n");
    if (!do_onemore(dt)){
      return FALSE;
    }
    goto retry;
  }
  dt->position += xdr_data_length(DT_INT);
  return TRUE;
}

int trans_long(dataTrans * dt, long * val){
  XDR xdrs;
retry:
  make_xdr(dt, &xdrs);
  if(ninf_debug_flag) printf("xdrmem created for xdr_long \n");
  if (!xdr_long(&xdrs, val)){
    if(ninf_debug_flag) printf("xdr_long failed\n");
    if (!do_onemore(dt))
      return FALSE;

    goto retry;
  } 
  dt->position += xdr_data_length(DT_LONG);
  return TRUE;
}

int trans_u_char(dataTrans * dt, unsigned char * val){
  return trans_char(dt, (char*)val);
}
int trans_u_short(dataTrans * dt, unsigned short * val){
  return trans_short(dt, (short*)val);
}

int trans_u_int(dataTrans * dt, unsigned int * val){
  XDR xdrs;
retry:
  make_xdr(dt, &xdrs);
  if (!xdr_u_int(&xdrs, val)){
    if (!do_onemore(dt))
      return FALSE;
    goto retry;
  }
  dt->position += xdr_data_length(DT_UNSIGNED);
  return TRUE;
}

int trans_u_long(dataTrans * dt, unsigned long * val){
  XDR xdrs;
retry:
  make_xdr(dt, &xdrs);
  if (!xdr_u_long(&xdrs, val)){
    if (!do_onemore(dt))
      return FALSE;
    goto retry;
  }
  dt->position += xdr_data_length(DT_UNSIGNED_LONG);
  return TRUE;
}

int trans_float(dataTrans * dt, float * val){
  XDR xdrs;
retry:
  make_xdr(dt, &xdrs);
  if (!xdr_float(&xdrs, val)){
    if (!do_onemore(dt))
      return FALSE;

    goto retry;
  }
  dt->position += xdr_data_length(DT_FLOAT);
  return TRUE;
}
int trans_double(dataTrans * dt, double * val){
  XDR xdrs;
retry:
  make_xdr(dt, &xdrs);
  if (!xdr_double(&xdrs, val)){
    if (!do_onemore(dt))
      return FALSE;
    goto retry;
  }
  dt->position += xdr_data_length(DT_DOUBLE);
  return TRUE;
}

int trans_enum(dataTrans * dt, enum_t * val){
  XDR xdrs;
  int tmp;
retry:
  make_xdr(dt, &xdrs);
  tmp = xdr_getpos(&xdrs); 
  if (!xdr_enum(&xdrs, val)){
    if (!do_onemore(dt))
      return FALSE;

    goto retry;
  }
  dt->position += xdr_getpos(&xdrs) - tmp;
  return TRUE;
}

#define TRANS_STRING_MAXLENGTH 100000

int trans_string_nolen(dataTrans * dt, char ** buf){
  return trans_string(dt, buf, TRANS_STRING_MAXLENGTH);
}

/** maxLen is totally ignored here */
int trans_string(dataTrans * dt, char ** buf, int maxLen){
  int limit = 4;
  char dum[4];
  int length;
  int rest;
  if (dt->flag == XDR_ENCODE){
    length = strlen(*buf);
    rest = 4 - length % 4;
    rest = (rest == 4)? 0: rest;
    if (!trans_int(dt, &length))
      return FALSE;
    if (!trans_char_array(dt, length, *buf))
      return FALSE;
    if (!trans_char_array(dt, rest, dum)) 
      return FALSE;
  } else {
    if (!trans_int(dt, &length))
      return FALSE;
    rest = 4 - length % 4;
    rest = (rest == 4)? 0: rest;
    if (*buf == NULL)
      if ((*buf = (char * )malloc(length +1)) == NULL)
	return FALSE;
    if (!trans_char_array(dt, length, *buf))
      return FALSE;
    if (!trans_char_array(dt, rest, dum))
      return FALSE;
    *((*buf) + length) = '\0';
  }

  /*  XDR xdrs;
  int tmp;
retry:
  make_xdr(dt, &xdrs);
  tmp = xdr_getpos(&xdrs);
  if (!xdr_string(&xdrs, buf, maxLen)){
    if (!do_onemore(dt))
      return FALSE;
    goto retry;
  }
  dt->position += xdr_getpos(&xdrs) - tmp;
  */

if(ninf_debug_flag) printf("trans_string: %s: %s\n", *buf, dt->flag == XDR_DECODE ? "decode" : "encode");
  return TRUE;

}

int trans_char_array_with_padding(dataTrans * dt, int count, char * buffer){
    char dummy[4];
    int rest;
    rest = 4 - count % 4;
    rest = (rest == 4)? 0: rest;
    trans_char_array(dt, count, buffer);
    if (rest != 0)
       trans_char_array(dt, rest, dummy);
}

int trans_char_array(dataTrans * dt, int count, char * buffer){
  int rest_items;
  if (dt->flag == XDR_DECODE){
    rest_items = (dt->valid_end - dt->position);
    while (TRUE){
      if (rest_items < count){
	memcpy(buffer, dt->position, rest_items);
	dt->position += rest_items;
	if (!read_onemore(dt))
	  return FALSE;
	count -= rest_items;
	buffer += rest_items;
	rest_items = (dt->valid_end - dt->position);
      }else{
	memcpy(buffer, dt->position, count);
	dt->position += count;
	break;
      }
    }
  }else {
    rest_items = (dt->end - dt->position);
    while (TRUE){
      if (rest_items < count){
	memcpy(dt->position, buffer, rest_items);
	dt->position += rest_items;
	write_flush(dt);
	count -= rest_items;
	buffer += rest_items;
	rest_items = (dt->end - dt->position);
      }else{
	memcpy(dt->position, buffer, count);
	dt->position += count;
	break;
      }
    }
  }
  return TRUE;
}

  /* only used to specify entry name in ninf_call */
int trans_string_primitive(dataTrans * dt, char ** buf, int maxLen){
  XDR xdrs;
  int tmp;
retry:
  if (dt->flag == XDR_ENCODE){
    strncpy(dt->position, *buf, maxLen);
    dt->position += strlen(*buf) + 1;
  } else {
    strncpy(*buf, dt->position, maxLen);
    dt->position += strlen(dt->position) + 1;
  }
  return TRUE;
}

int trans_char_raw_single(dataTrans * dt, char * buffer){
  return trans_char_raw_balk(dt, buffer, 1);
  
}

int trans_char_raw_balk(dataTrans * dt, char * buffer, int items){
  int i;
  if (dt->flag == XDR_ENCODE)
    memcpy(dt->position, buffer, items);
  else 
    memcpy(buffer, dt->position, items);
  dt->position += items;
  /*  for (i = 0; i < items; i++)
    printf("char tmp = %d\n", *(buffer + i)); */
  return TRUE;
}

int trans_short_raw_single(dataTrans * dt, char * buffer){
  if (dt->flag == XDR_ENCODE){
    short v = *((short *)buffer);
    *(dt->position++) = (unsigned char)((v >> 8) & 0xFF); 
    *(dt->position++) = (unsigned char)((v >> 0) & 0xFF); 
  } else {
    int ch1 = *(dt->position++);
    int ch2 = *(dt->position++);
    short tmp;
    ch1 &= 0xff;
    ch2 &= 0xff;
    tmp = (short)((ch1 << 8) + (ch2 << 0));
    *((short *)buffer) = tmp; 
    /* printf("short tmp = %d\n", tmp); */
  }
  return TRUE;
}

int trans_short_raw_balk(dataTrans * dt, char * buffer, int items){
  int i;
  for (i = 0; i < items; i++){
    if (!trans_short_raw_single(dt, buffer))
      return FALSE;
    buffer += sizeof(short);
  }
  return TRUE;
}

void trans_dataTrans_sub_xdr(dataTrans * dt, char * buffer, DATA_TYPE type, int items){
#ifdef __sparc__ 
  if (type != DT_CHAR && type != DT_UNSIGNED_CHAR &&
      type != DT_SHORT && type != DT_UNSIGNED_SHORT){
    if(ninf_debug_flag) 
      printf("sparc burst: type = %d, items = %d\n", type, items);

    if (dt->flag == XDR_ENCODE)
      memcpy(dt->position, buffer, xdr_data_length(type) * items);
    else
      memcpy(buffer, dt->position, xdr_data_length(type) * items);
    dt->position += xdr_data_length(type) * items;
    return;
  }
#endif 
  /* printf("burst: type = %d, items = %d\n", type, items);   */
  if (type == DT_CHAR || type == DT_UNSIGNED_CHAR){
    trans_char_raw_balk(dt, buffer, items);
  } else if (type == DT_SHORT || type == DT_UNSIGNED_SHORT){
    trans_short_raw_balk(dt, buffer, items);
  }else {
  XDR xdrs;
  XDR * xdrp = &xdrs;
  int i;
  char * tmpbuf = buffer;

  make_xdr(dt, &xdrs);

  for (i = 0; i < items; i++){
    if (!(*(DATA_TYPE_XDR_FUNC(type)))(xdrp, tmpbuf)){
      ninf_fatal("xdr_* failed in burst xdr on %d th item: type = %d, buffer = %p\n", i, type, tmpbuf);
      break;
    }
    tmpbuf += DATA_TYPE_SIZE(type);
  }

  
  dt->position += xdr_data_length(type) * items;

  
  }
}

#define CONV_USE_IEG2CRAY
#ifdef __j90__
#ifdef CONV_USE_IEG2CRAY
#include "ninf_data_trans_ieg2cray.c"
#else
#include "ninf_data_trans_xdr.c"
#endif 
#else 
#include "ninf_data_trans_xdr.c"
#endif

