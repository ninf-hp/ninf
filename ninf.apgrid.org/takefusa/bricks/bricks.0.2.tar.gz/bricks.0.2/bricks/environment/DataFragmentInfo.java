package bricks.environment;
import java.util.*;
import bricks.scheduling.ResourceDB;

public class DataFragmentInfo {

    public DataFragment dataFragment;
    public double score;

    DataFragmentInfo(DataFragment dataFragment) {
	this.dataFragment = dataFragment;
    }
    
    public String toString() {
	return dataFragment.id + " " + size() + " " + lastAccessedTime() +
	    " " + score;
    }

    public double lastAccessedTime() {
	return dataFragment.lastAccessedTime;
    }

    public void computeScore(ResourceDB resourceDB, double currentTime) {
	int numCopies = resourceDB.howManyReplicas(dataFragment);
	score = dataFragment.numAccesses / 
	    (currentTime - dataFragment.storedTime) / numCopies;
	    
    }

    public void setScore(double score) {
	this.score = score;
    }

    public double size() {
	return dataFragment.size;
    }
}
