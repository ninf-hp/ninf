package ninf.scheduler;
import ninf.common.*;
import ninf.metaserver.*;
import ninf.basic.*;


public class TimeSpan {
  public long from;
  public long to;

  public TimeSpan(long from, long to){
    this.from = from;
    this.to   = to;
  }
}
