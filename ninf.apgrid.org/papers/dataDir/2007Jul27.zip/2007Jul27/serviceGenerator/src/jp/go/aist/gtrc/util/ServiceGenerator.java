package jp.go.aist.gtrc.util;

import java.io.BufferedOutputStream;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.io.Writer;

import java.util.Arrays;
import java.util.Enumeration;
import java.util.Properties;
import java.util.Vector;

import javassist.ClassClassPath;
import javassist.ClassPool;
import javassist.CtClass;
import javassist.NotFoundException;

import javax.xml.parsers.ParserConfigurationException;

import org.apache.axis.utils.XMLUtils;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

public class ServiceGenerator {
	static final String WSDL_NS_URL = "http://schemas.xmlsoap.org/wsdl/";
	static final String XSD_NS_URL = "http://www.w3.org/2001/XMLSchema";
	static final String WSDD_NS_URL = "http://xml.apache.org/axis/wsdd/";
	static final String WSDDJAVA_NS_URL = "http://xml.apache.org/axis/wsdd/providers/java";
	static final String JNDICONF_NS_URL = "http://wsrf.globus.org/jndi/config";

	public static void main(String[] args) throws ResourceInfo.ResourceInfoException, ClassNotFoundException, NotFoundException, ParserConfigurationException, FileNotFoundException, IOException {
		if (args.length != 1) {
			System.out.println("usage: java jp.go.aist.gtrc.util.ServiceGenerator <class name>");
			return;
		}
		new ServiceGenerator().generate(args);
	}

	void generate(String[] args) throws ResourceInfo.ResourceInfoException, ClassNotFoundException, NotFoundException, ParserConfigurationException, FileNotFoundException, IOException {
		TypeMapping typeMapping = getTypeMapping();
		ClassPool cp = ClassPool.getDefault();
		cp.insertClassPath(new ClassClassPath(getClass()));
		CtClass resourceImpl;
		try {
			resourceImpl = cp.get(args[0]);
		} catch (NotFoundException e) {
			e.printStackTrace();
			System.exit(1);
			return;//dummy
		}
		ResourceInfo resourceInfo = new ResourceInfo(resourceImpl, "gtrc.aist.go.jp", typeMapping);

		// Create schama location
		String locationPath;
		String packageDir;
		{
			String packageName = resourceInfo.implPackageName;
			String tmp = packageName.substring(0, packageName.length() - ".impl".length());
			locationPath = tmp.replace(".", File.separator);
			packageDir = tmp.substring(tmp.lastIndexOf(".") + 1);
		}

		File location = new File("schema" + File.separator + locationPath);
		location.mkdirs();

		// Generate Factory Schema
		Document doc = generateFactoryServiceWSDL(resourceInfo);
		{
			OutputStream os = new BufferedOutputStream(new FileOutputStream(location.toString() + File.separator + resourceInfo.serviceName + "Factory.wsdl"));
			XMLUtils.PrettyDocumentToStream(doc, os);
			os.close();
		}

		// Generate Schema
		doc = generateServiceWSDL(resourceInfo, typeMapping);
		{
			OutputStream os = new BufferedOutputStream(new FileOutputStream(location.toString() + File.separator + resourceInfo.serviceName + ".wsdl"));
			XMLUtils.PrettyDocumentToStream(doc, os);
			os.close();
		}

		String srcDir = packageDir + File.separator + "impl" + File.separator + locationPath + File.separator + "impl";

		// Generate ResourceHome code
		location = new File(srcDir);
		location.mkdirs();
		{
			Writer writer = new BufferedWriter(new FileWriter(location.toString() + File.separator + resourceInfo.serviceName + "ResourceHome.java"));
			outputResourceHome(resourceInfo, writer);
			writer.close();
		}

		// Generate Service code
		location = new File(srcDir);
		location.mkdirs();
		{
			Writer writer = new BufferedWriter(new FileWriter(location.toString() + File.separator + resourceInfo.serviceName + "Service.java"));
			outputService(resourceInfo, writer, typeMapping);
			writer.close();
		}

		// Generate WSDD file
		doc = generateWSDD(resourceInfo);
		{
			OutputStream os = new BufferedOutputStream(new FileOutputStream(packageDir + File.separator + "deploy-server.wsdd"));
			XMLUtils.PrettyDocumentToStream(doc, os);
			os.close();
		}

		// Generate JNDI file
		doc = generateJNDI(resourceInfo);
		{
			OutputStream os = new BufferedOutputStream(new FileOutputStream(packageDir + File.separator + "deploy-jndi-config.xml"));
			XMLUtils.PrettyDocumentToStream(doc, os);
			os.close();
		}
	}

	static TypeMapping getTypeMapping() throws NotFoundException, FileNotFoundException, IOException {
		TypeMapping typeMapping = new TypeMapping();
		SchemaInfo xsd = new SchemaInfo("xsd", "http://www.w3.org/2001/XMLSchema");
		typeMapping.put("int", new TypeInfo(xsd, "int", "int"));  // TODO add other default xsd type
		Properties properties = new Properties();
		properties.load(new FileInputStream("types.properties"));
		Enumeration names = properties.propertyNames();
		while (names.hasMoreElements()) {
			String name = (String)names.nextElement();
			String[] vals = properties.getProperty(name).split(",");
			String shortName = name;
			String nsPrefix = vals[0];
			String fullName = vals[1];
			String nsURL = vals[2];
			String schemaLocation = vals[3];
			SchemaInfo schemaInfo = new SchemaInfo(nsPrefix, nsURL, schemaLocation);
			typeMapping.put(fullName, new TypeInfo(schemaInfo, shortName, fullName));
		}
		return typeMapping;
	}

	static Document generateFactoryServiceWSDL(ResourceInfo resourceInfo) throws ParserConfigurationException {
		Document doc = XMLUtils.newDocument();
		Element definitions = generateFactoryDefinitions(resourceInfo, doc);
		doc.appendChild(definitions);
		return doc;
	}

	static Element generateFactoryDefinitions(ResourceInfo resourceInfo, Document doc) {
		Element definitions = doc.createElementNS(WSDL_NS_URL, "wsdl:definitions");
		definitions.setAttribute("name", resourceInfo.serviceName + "Factory");
		definitions.setAttribute("targetNamespace", resourceInfo.tns);
		definitions.setAttribute("xmlns", resourceInfo.tns);
		definitions.setAttribute("xmlns:wsa", "http://schemas.xmlsoap.org/ws/2004/03/addressing");
		Element types = generateFactoryTypes(resourceInfo, doc);
		definitions.appendChild(types);
		Element[] messages = generateFactoryMessages(resourceInfo, doc);
		for (Element message : messages) {
			definitions.appendChild(message);
		}
		Element portType = generateFactoryPortType(resourceInfo, doc);
		definitions.appendChild(portType);
		return definitions;
	}

	static Element generateFactoryTypes(ResourceInfo resourceInfo, Document doc) {
		Element types = doc.createElementNS(WSDL_NS_URL, "wsdl:types");
		Element schema = generateFactorySchema(resourceInfo, doc);
		types.appendChild(schema);
		return types;
	}

	static Element generateFactorySchema(ResourceInfo resourceInfo, Document doc) {
		Element schema = doc.createElementNS(XSD_NS_URL, "xsd:schema");
		schema.setAttribute("attributeFormDefault", "unqualified");
		schema.setAttribute("elementFormDefault", "qualified");
		schema.setAttribute("targetNamespace", resourceInfo.tns);
		Element[] imports = generateFactorySchemaImports(resourceInfo, doc);
		for (Element import_ : imports) {
			schema.appendChild(import_);
		}

		Element element = doc.createElementNS(XSD_NS_URL, "xsd:element");
		element.setAttribute("name", "create" + resourceInfo.serviceName);
		element.setAttribute("type", "Create" + resourceInfo.serviceName);
		schema.appendChild(element);

		Element complexType = doc.createElementNS(XSD_NS_URL, "xsd:complexType");
		complexType.setAttribute("name", "Create" + resourceInfo.serviceName);
		schema.appendChild(complexType);

		element = doc.createElementNS(XSD_NS_URL, "xsd:element");
		element.setAttribute("name", "create" + resourceInfo.serviceName + "Response");
		element.setAttribute("type", "Create" + resourceInfo.serviceName + "Response");
		schema.appendChild(element);

		complexType = doc.createElementNS(XSD_NS_URL, "xsd:complexType");
		complexType.setAttribute("name", "Create" + resourceInfo.serviceName + "Response");
		Element sequence = doc.createElementNS(XSD_NS_URL, "xsd:sequence");
		element = doc.createElementNS(XSD_NS_URL, "xsd:element");
		element.setAttribute("ref", "wsa:EndpointReference");
		sequence.appendChild(element);
		complexType.appendChild(sequence);
		schema.appendChild(complexType);

		return schema;
	}

	static Element[] generateFactorySchemaImports(ResourceInfo resourceInfo, Document doc) {
		Vector<Element> tmp = new Vector<Element>();

		Element import_ = doc.createElementNS(XSD_NS_URL, "xsd:import");
		import_.setAttribute("namespace", "http://schemas.xmlsoap.org/ws/2004/03/addressing");
		import_.setAttribute("schemaLocation", relativePath(resourceInfo.location, "ws/addressing") + "/WS-Addressing.xsd");
		tmp.add(import_);

		return tmp.toArray(new Element[0]);
	}

	static Element[] generateFactoryMessages(ResourceInfo resourceInfo, Document doc) {
		Vector<Element> tmp = new Vector<Element>();

		Element message = doc.createElementNS(WSDL_NS_URL, "wsdl:message");
		message.setAttribute("name", "create" + resourceInfo.serviceName + "InputMessage");
		Element part = doc.createElementNS(WSDL_NS_URL, "wsdl:part");
		part.setAttribute("element", "create" + resourceInfo.serviceName);
		part.setAttribute("name", "request");
		message.appendChild(part);
		tmp.add(message);

		message = doc.createElementNS(WSDL_NS_URL, "wsdl:message");
		message.setAttribute("name", "create" + resourceInfo.serviceName + "OutputMessage");
		part = doc.createElementNS(WSDL_NS_URL, "wsdl:part");
		part.setAttribute("element", "create" + resourceInfo.serviceName + "Response");
		part.setAttribute("name", "response");
		message.appendChild(part);
		tmp.add(message);

		return tmp.toArray(new Element[0]);
	}

	static Element generateFactoryPortType(ResourceInfo resourceInfo, Document doc) {
		Element portType = doc.createElementNS(WSDL_NS_URL, "wsdl:portType");
		portType.setAttribute("name", resourceInfo.serviceName + "FactoryPortType");
		Element operation = doc.createElementNS(WSDL_NS_URL, "wsdl:operation");
		operation.setAttribute("name", "create" + resourceInfo.serviceName);
		Element input = doc.createElementNS(WSDL_NS_URL, "wsdl:input");
		input.setAttribute("message", "create" + resourceInfo.serviceName + "InputMessage");
		operation.appendChild(input);
		Element output = doc.createElementNS(WSDL_NS_URL, "wsdl:output");
		output.setAttribute("message", "create" + resourceInfo.serviceName + "OutputMessage");
		operation.appendChild(output);
		portType.appendChild(operation);
		return portType;
	}

	static Document generateServiceWSDL(ResourceInfo resourceInfo, TypeMapping typeMapping) throws ParserConfigurationException {
		Document doc = XMLUtils.newDocument();
		Element definitions = generateDefinitions(resourceInfo, doc, typeMapping);
		doc.appendChild(definitions);
		return doc;
	}

	static Element generateDefinitions(ResourceInfo resourceInfo, Document doc, TypeMapping typeMapping) {
		Element definitions = doc.createElementNS(WSDL_NS_URL, "wsdl:definitions");
		definitions.setAttribute("name", resourceInfo.serviceName);
		definitions.setAttribute("targetNamespace", resourceInfo.tns);
		definitions.setAttribute("xmlns", resourceInfo.tns);
		definitions.setAttribute("xmlns:wsa", "http://schemas.xmlsoap.org/ws/2004/03/addressing");
		definitions.setAttribute("xmlns:wsdlpp", "http://www.globus.org/namespaces/2004/10/WSDLPreprocessor");
		definitions.setAttribute("xmlns:wsrlw", "http://docs.oasis-open.org/wsrf/2004/06/wsrf-WS-ResourceLifetime-1.2-draft-01.wsdl");
		definitions.setAttribute("xmlns:wsrp", "http://docs.oasis-open.org/wsrf/2004/06/wsrf-WS-ResourceProperties-1.2-draft-01.xsd");
		definitions.setAttribute("xmlns:wsrpw", "http://docs.oasis-open.org/wsrf/2004/06/wsrf-WS-ResourceProperties-1.2-draft-01.wsdl");
		for (TypeInfo typeInfo : typeMapping.using()) {
			if (!typeInfo.schemaInfo.nsURL.equals("http://www.w3.org/2001/XMLSchema")) {
				definitions.setAttribute("xmlns:" + typeInfo.schemaInfo.nsPrefix, typeInfo.schemaInfo.nsURL);
			}
		}
		Element[] imports = generateImports(resourceInfo, doc);
		for (Element import_ : imports) {
			definitions.appendChild(import_);
		}

		Element types = generateTypes(resourceInfo, doc, typeMapping);
		definitions.appendChild(types);

		Element[] messages = generateMessages(resourceInfo, doc);
		for (Element message : messages) {
			definitions.appendChild(message);
		}

		Element portType = generatePortType(resourceInfo, doc);
		definitions.appendChild(portType);

		return definitions;
	}

	static Element[] generateImports(ResourceInfo resourceInfo, Document doc) {
		Vector<Element> tmp = new Vector<Element>();

		Element import_ = doc.createElementNS(WSDL_NS_URL, "wsdl:import");
		import_.setAttribute("location", relativePath(resourceInfo.location, "wsrf/lifetime") + "/WS-ResourceLifetime.wsdl");
		import_.setAttribute("namespace", "http://docs.oasis-open.org/wsrf/2004/06/wsrf-WS-ResourceLifetime-1.2-draft-01.wsdl");
		tmp.add(import_);

		import_ = doc.createElementNS(WSDL_NS_URL, "wsdl:import");
		import_.setAttribute("location", relativePath(resourceInfo.location, "wsrf/properties") + "/WS-ResourceProperties.wsdl");
		import_.setAttribute("namespace", "http://docs.oasis-open.org/wsrf/2004/06/wsrf-WS-ResourceProperties-1.2-draft-01.wsdl");
		tmp.add(import_);

		return tmp.toArray(new Element[0]);
	}

	static Element generateTypes(ResourceInfo resourceInfo, Document doc, TypeMapping typeMapping) {
		Element types = doc.createElementNS(WSDL_NS_URL, "wsdl:types");
		Element schema = generateSchema(resourceInfo, doc, typeMapping);
		types.appendChild(schema);
		return types;
	}

	static Element generateSchema(ResourceInfo resourceInfo, Document doc, TypeMapping typeMapping) {
		Element schema = doc.createElementNS(XSD_NS_URL, "xsd:schema");
		schema.setAttribute("attributeFormDefault", "unqualified");
		schema.setAttribute("elementFormDefault", "qualified");
		schema.setAttribute("targetNamespace", resourceInfo.tns);

		Element[] imports = generateSchemaImports(resourceInfo, doc, typeMapping);
		for (Element import_ : imports) {
			schema.appendChild(import_);
		}

		Element[] elements = generateOperationElements(resourceInfo, doc);
		for (Element element : elements) {
			schema.appendChild(element);
		}

		elements = generateResourcePropertyElements(resourceInfo, doc);
		for (Element element : elements) {
			schema.appendChild(element);
		}

		return schema;
	}

	static Element[] generateSchemaImports(ResourceInfo resourceInfo, Document doc, TypeMapping typeMapping) {
		Vector<Element> tmp = new Vector<Element>();
		for (TypeInfo typeInfo : typeMapping.using()) {
			if (!typeInfo.schemaInfo.nsURL.equals("http://www.w3.org/2001/XMLSchema")) {
				Element import_ = doc.createElementNS(XSD_NS_URL, "xsd:import");
				import_.setAttribute("namespace", typeInfo.schemaInfo.nsURL);
				import_.setAttribute("schemaLocation", relativePath(resourceInfo.location, typeInfo.schemaInfo.location));
				tmp.add(import_);
			}
		}
		return tmp.toArray(new Element[0]);
                //<xsd:import namespace="http://schemas.xmlsoap.org/ws/2004/03/addressing" schemaLocation="../../../../../ws/addressing/WS-Addressing.xsd"/>
	}

	static Element[] generateOperationElements(ResourceInfo resourceInfo, Document doc) {
		Vector<Element> tmp = new Vector<Element>();
		for (OperationInfo operationInfo : resourceInfo.operationInfos) {
			String hcName = operationInfo.name.substring(0, 1).toUpperCase() + operationInfo.name.substring(1, operationInfo.name.length());

			Element element = doc.createElementNS(XSD_NS_URL, "xsd:element");
			element.setAttribute("name", operationInfo.requestElement.name);
			element.setAttribute("type", operationInfo.requestElement.type.xmlName);
			tmp.add(element);

			Element complexType = doc.createElementNS(XSD_NS_URL, "xsd:complexType");
			complexType.setAttribute("name", operationInfo.requestElement.type.xmlName);

			if (operationInfo.params.length > 0) {
				Element sequence = doc.createElementNS(XSD_NS_URL, "xsd:sequence");
				for (ParamInfo param : operationInfo.params) {
					element = doc.createElementNS(XSD_NS_URL, "xsd:element");
					element.setAttribute("maxOccurs", "1");
					element.setAttribute("minOccurs", "1");
					element.setAttribute("name", param.name);
					element.setAttribute("nillable", "false");
					{
						String prefix = param.type.schemaInfo.nsPrefix;
						String suffix = param.type.xmlName;
						element.setAttribute("type", prefix + ":" + suffix);
					}
					sequence.appendChild(element);
				}
				complexType.appendChild(sequence);
			}
			tmp.add(complexType);

			element = doc.createElementNS(XSD_NS_URL, "xsd:element");
			element.setAttribute("name", operationInfo.responseElement.name);
			element.setAttribute("type", operationInfo.responseElement.type.xmlName);
			tmp.add(element);

			complexType = doc.createElementNS(XSD_NS_URL, "xsd:complexType");
			complexType.setAttribute("name", operationInfo.responseElement.type.xmlName);
			if (operationInfo.returnType != null) {
				Element sequence = doc.createElementNS(XSD_NS_URL, "xsd:sequence");
				element = doc.createElementNS(XSD_NS_URL, "xsd:element");
				element.setAttribute("maxOccurs", "1");
				element.setAttribute("minOccurs", "1");
				element.setAttribute("name", "result");
				element.setAttribute("nillable", "false");
				{
					String prefix = operationInfo.returnType.schemaInfo.nsPrefix;
					String suffix = operationInfo.returnType.xmlName;
					element.setAttribute("type", prefix + ":" + suffix);
				}
				sequence.appendChild(element);
				complexType.appendChild(sequence);
			}
			tmp.add(complexType);
		}
		return tmp.toArray(new Element[0]);
	}

	static Element[] generateResourcePropertyElements(ResourceInfo resourceInfo, Document doc) {
		Vector<Element> tmp = new Vector<Element>();
		if (resourceInfo.propertyInfos.length > 0) {
			Element element = doc.createElementNS(XSD_NS_URL, "xsd:element");
			element.setAttribute("name", resourceInfo.serviceName + "ResourceProperties");
			element.setAttribute("type", resourceInfo.serviceName + "ResourcePropertiesType");
			tmp.add(element);
			Element complexType = doc.createElementNS(XSD_NS_URL, "xsd:complexType");
			complexType.setAttribute("name", resourceInfo.serviceName + "ResourcePropertiesType");
			Element sequence = doc.createElementNS(XSD_NS_URL, "xsd:sequence");
			for (PropertyInfo prop : resourceInfo.propertyInfos) {
				element = doc.createElementNS(XSD_NS_URL, "xsd:element");
				element.setAttribute("maxOccurs", "1");
				element.setAttribute("minOccurs", "1");
				element.setAttribute("name", prop.name);
				element.setAttribute("nillable", "false");
				{
					String prefix = prop.type.schemaInfo.nsPrefix;
					String suffix = prop.type.xmlName;
					element.setAttribute("type", prefix + ":" + suffix);
				}
				sequence.appendChild(element);
			}
			complexType.appendChild(sequence);
			tmp.add(complexType);
		}
		return tmp.toArray(new Element[0]);
	}

	static Element[] generateMessages(ResourceInfo resourceInfo, Document doc) {
		Vector<Element> tmp = new Vector<Element>();
		for (OperationInfo op : resourceInfo.operationInfos) {
			Element message = doc.createElementNS(WSDL_NS_URL, "wsdl:message");
			message.setAttribute("name", op.name + "InputMessage");
			Element part = doc.createElementNS(WSDL_NS_URL, "wsdl:part");
			part.setAttribute("element", op.name);
			part.setAttribute("name", "request");
			message.appendChild(part);
			tmp.add(message);

			message = doc.createElementNS(WSDL_NS_URL, "wsdl:message");
			message.setAttribute("name", op.name + "OutputMessage");
			part = doc.createElementNS(WSDL_NS_URL, "wsdl:part");
			part.setAttribute("element", op.name + "Response");
			part.setAttribute("name", "response");
			message.appendChild(part);
			tmp.add(message);
		}
		return tmp.toArray(new Element[0]);
	}

	static Element generatePortType(ResourceInfo resourceInfo, Document doc) {
		Element portType = doc.createElementNS(WSDL_NS_URL, "wsdl:portType");
		portType.setAttribute("name", resourceInfo.serviceName + "PortType");
		portType.setAttribute("wsdlpp:extends", "wsrpw:GetResourceProperty wsrlw:ImmediateResourceTermination");
		if (resourceInfo.propertyInfos.length > 0) {
			portType.setAttribute("wsrp:ResourceProperties", resourceInfo.serviceName + "ResourceProperties");
		}
		for (OperationInfo op : resourceInfo.operationInfos) {
			Element operation = doc.createElementNS(WSDL_NS_URL, "wsdl:operation");
			operation.setAttribute("name", op.name);

			Element input = doc.createElementNS(WSDL_NS_URL, "wsdl:input");
			input.setAttribute("message", op.name + "InputMessage");
			operation.appendChild(input);

			Element output = doc.createElementNS(WSDL_NS_URL, "wsdl:output");
			output.setAttribute("message", op.name + "OutputMessage");
			operation.appendChild(output);

			portType.appendChild(operation);
		}
		return portType;
	}

	static String relativePath(String from, String to) {
		StringBuffer prefix = new StringBuffer("");
		if (!to.startsWith(from)) {
			do {
				prefix.append("/..");
				int index = from.lastIndexOf("/");
				index = ( (index < 0) ? 0 : index );
				from = from.substring(0, index);
			} while (!to.startsWith(from));
			prefix.deleteCharAt(0);
		}
		String suffix = to.substring(from.length(), to.length());
		if (suffix.startsWith("/")) {
			suffix = suffix.substring(1);
		}
		if ((prefix.length() > 0) && (suffix.length() > 0)) {
			return prefix.toString() + "/" + suffix;
		} else {
			return prefix.toString() + suffix;
		}
	}

	static void outputResourceHome(ResourceInfo resourceInfo, Writer writer) throws IOException {
		writer.write("package " + resourceInfo.implPackageName + ";\n");
		writer.write("\n");
		writer.write("import jp.go.aist.gtrc.impl.ResourceHomeImpl;\n");
		writer.write("\n");
		writer.write("import org.apache.axis.components.uuid.UUIDGen;\n");
		writer.write("import org.apache.axis.components.uuid.UUIDGenFactory;\n");
		writer.write("import org.globus.wsrf.Resource;\n");
		writer.write("import org.globus.wsrf.ResourceKey;\n");
		writer.write("import org.globus.wsrf.impl.SimpleResourceKey;\n");
		writer.write("import org.globus.wsrf.impl.SimpleResourceKey;\n");
		writer.write("\n");
		writer.write("public class " + resourceInfo.serviceName + "ResourceHome extends ResourceHomeImpl {\n");
		writer.write("\tprivate static final UUIDGen uuidGen = UUIDGenFactory.getUUIDGen();\n");
		writer.write("\n");
		writer.write("\tResourceKey create" + resourceInfo.serviceName + "() throws Exception {\n");
		writer.write("\t\t// Create a resource\n");
		writer.write("\t\tResource resource = createNewInstance();\n");
		writer.write("\t\t// Get key\n");
		writer.write("\t\tString uuid = uuidGen.nextUUID();\n");
		writer.write("\t\tResourceKey key = new SimpleResourceKey(keyTypeName, uuid);\n");
		writer.write("\t\t// Add the resource to the list of resources in this home\n");
		writer.write("\t\tadd(key, resource);\n");
		writer.write("\t\treturn key;\n");
		writer.write("\t}\n");
		writer.write("}\n");
	}

	static void outputService(ResourceInfo resourceInfo, Writer writer, TypeMapping typeMapping) throws IOException {
		writer.write("package " + resourceInfo.implPackageName + ";\n");
		writer.write("\n");
		writer.write("import java.net.URL;\n");
		writer.write("import java.rmi.RemoteException;\n");
		writer.write("\n");
		String implPackageName = resourceInfo.implPackageName;
		String packageName = implPackageName.substring(0, implPackageName.length() - ".impl".length());
		writer.write("import " + packageName + ".Create" + resourceInfo.serviceName + ";\n");
		writer.write("import " + packageName + ".Create" + resourceInfo.serviceName + "Response;\n");
		writer.write("\n");
		writer.write("import org.apache.axis.MessageContext;\n");
		writer.write("import org.apache.axis.message.addressing.EndpointReferenceType;\n");
		writer.write("import org.globus.wsrf.container.ServiceHost;\n");
		writer.write("import org.globus.wsrf.ResourceContext;\n");
		writer.write("import org.globus.wsrf.ResourceKey;\n");
		writer.write("import org.globus.wsrf.utils.AddressingUtils;\n");
		writer.write("\n");
		for (OperationInfo operationInfo : resourceInfo.operationInfos) {
			writer.write("import " + packageName + "." + operationInfo.requestElement.type.xmlName + ";\n");  // XXX
			writer.write("import " + packageName + "." + operationInfo.responseElement.type.xmlName + ";\n");  // XXX
		}
		writer.write("\n");
		for (TypeInfo typeInfo : typeMapping.using()) {
			if (!typeInfo.schemaInfo.nsURL.equals("http://www.w3.org/2001/XMLSchema")) {
				writer.write("import " + typeInfo.name + ";\n");
			}
		}
		writer.write("\n");
		writer.write("public class " + resourceInfo.serviceName + "Service {\n");
		writer.write("\t// Implementation of create Operation\n");
		writer.write("\tpublic Create" + resourceInfo.serviceName + "Response create" + resourceInfo.serviceName + "(Create" + resourceInfo.serviceName + " request) throws RemoteException {\n");
		writer.write("\t\tResourceContext ctx = null;\n");
		writer.write("\t\t" + resourceInfo.serviceName + "ResourceHome home = null;\n");
		writer.write("\t\tResourceKey key = null;\n");
		writer.write("\n");
		writer.write("\t\t// create Resource through the ResourceHome\n");
		writer.write("\t\ttry {\n");
		writer.write("\t\t\tctx = ResourceContext.getResourceContext();\n");
		writer.write("\t\t\thome = (" + resourceInfo.serviceName + "ResourceHome)ctx.getResourceHome();\n");
		writer.write("\t\t\tkey = home.create" + resourceInfo.serviceName + "();\n");
		writer.write("\t\t} catch (RemoteException e) {\n");
		writer.write("\t\t\te.printStackTrace();\n");
		writer.write("\t\t\tthrow e;\n");
		writer.write("\t\t} catch (Exception e) {\n");
		writer.write("\t\t\te.printStackTrace();\n");
		writer.write("\t\t\tthrow new RemoteException(\"\", e);\n");
		writer.write("\t\t}\n");
		writer.write("\n");
		writer.write("\t\t// construct EPR\n");
		writer.write("\t\tEndpointReferenceType epr = null;\n");
		writer.write("\t\ttry {\n");
		writer.write("\t\t\tURL baseURL = ServiceHost.getBaseURL();\n");
		writer.write("\t\t\tString instanceService = (String)MessageContext.getCurrentContext().getService().getOption(\"instance\");\n");
		writer.write("\t\t\tString instanceURI = baseURL.toString() + instanceService;\n");
		writer.write("\t\t\t// The endpoint reference includes the instance's URI and the resource key\n");
		writer.write("\t\t\tepr = AddressingUtils.createEndpointReference(instanceURI, key);\n");
		writer.write("\t\t} catch (RemoteException e) {\n");
		writer.write("\t\t\te.printStackTrace();\n");
		writer.write("\t\t\tthrow e;\n");
		writer.write("\t\t} catch (Exception e) {\n");
		writer.write("\t\t\te.printStackTrace();\n");
		writer.write("\t\t\tthrow new RemoteException(\"\", e);\n");
		writer.write("\t\t}\n");
		writer.write("\t\t// finally, return the endpoint reference in a response\n");
		writer.write("\t\tCreate" + resourceInfo.serviceName + "Response response = new Create" + resourceInfo.serviceName + "Response();\n");
		writer.write("\t\tresponse.setEndpointReference(epr);\n");
		writer.write("\t\treturn response;\n");
		writer.write("\t}\n");
		for (OperationInfo operationInfo : resourceInfo.operationInfos) {
			writer.write("\n");
			writer.write("\t// Implementation of " + operationInfo.name + " Operation\n");
			writer.write("\tpublic " + operationInfo.responseElement.type.xmlName +" " + operationInfo.name + "(" + operationInfo.requestElement.type.xmlName + " request) throws RemoteException {\n");
			writer.write("\t\tObject resource = null;\n");
			writer.write("\t\ttry {\n");
			writer.write("\t\t\tresource = ResourceContext.getResourceContext().getResource();\n");
			writer.write("\t\t} catch (RemoteException e) {\n");
			writer.write("\t\t\tthrow e;\n");
			writer.write("\t\t} catch (Exception e) {\n");
			writer.write("\t\t\tthrow new RemoteException(\"\", e);\n");
			writer.write("\t\t}\n");
			writer.write("\t\t" + resourceInfo.serviceName + "Resource r = (" + resourceInfo.serviceName + "Resource)resource;\n");
			writer.write("\t\t");
			if (operationInfo.returnType != null) {
				writer.write(operationInfo.returnType.xmlName + " result = ");
			}
			writer.write("r." + operationInfo.name + "(");
			StringBuffer args = new StringBuffer("");
			for (ParamInfo param : operationInfo.params) {
				String hcName = param.name.substring(0, 1).toUpperCase() + param.name.substring(1, param.name.length());
				args.append(", request.get" + hcName+ "()");
			}
			if (args.length() > 0) {
				args.delete(0, 2);
			}
			writer.write(args.toString());
			writer.write(");\n");
			writer.write("\t\t" + operationInfo.responseElement.type.xmlName + " response = new " + operationInfo.responseElement.type.xmlName + "();\n");
			if (operationInfo.returnType != null) {
				writer.write("\t\tresponse.setResult(result);\n"); // XXX
			}
			writer.write("\t\treturn response;\n");
			writer.write("\t}\n");
			//writer.write("\t\n");
		}
		writer.write("}\n");
	}

	static Document generateWSDD(ResourceInfo resourceInfo) throws ParserConfigurationException {
		Document doc = XMLUtils.newDocument();

		Element deployment = doc.createElement("deployment");
		deployment.setAttribute("name", "defaultServerConfig");
		deployment.setAttribute("xmlns", WSDD_NS_URL);
		deployment.setAttribute("xmlns:java", WSDDJAVA_NS_URL);
		deployment.setAttribute("xmlns:xsd", XSD_NS_URL);

		// Service Description
		Element service = doc.createElement("service");
		String tmp = resourceInfo.implPackageName.substring(0, resourceInfo.implPackageName.length() - "impl".length());
		String servicePath = tmp.replace(".", "/") + resourceInfo.serviceName + "Service";
		service.setAttribute("name", servicePath);
		service.setAttribute("provider", "Handler");
		service.setAttribute("style", "document");
		service.setAttribute("use", "literal");

		Element parameter = doc.createElement("parameter");
		parameter.setAttribute("name", "allowedMethods");
		parameter.setAttribute("value", "*");
		service.appendChild(parameter);

		parameter = doc.createElement("parameter");
		parameter.setAttribute("name", "className");
		parameter.setAttribute("value", resourceInfo.implPackageName + "." + resourceInfo.serviceName + "Service");
		service.appendChild(parameter);

		parameter = doc.createElement("parameter");
		parameter.setAttribute("name", "handlerClass");
		parameter.setAttribute("value", "org.globus.axis.providers.RPCProvider");
		service.appendChild(parameter);

		parameter = doc.createElement("parameter");
		parameter.setAttribute("name", "providers");
		parameter.setAttribute("value", "DestroyProvider GetRPProvider");
		service.appendChild(parameter);

		parameter = doc.createElement("parameter");
		parameter.setAttribute("name", "scope");
		parameter.setAttribute("value", "Application");
		service.appendChild(parameter);

		Element wsdlFile = doc.createElement("wsdlFile");
		wsdlFile.setTextContent("share/schema/" + tmp.replace(".", "/") + resourceInfo.serviceName + "_service.wsdl");
		service.appendChild(wsdlFile);

		deployment.appendChild(service);

		// Factory Service Description
		service = doc.createElement("service");
		String factoryServicePath = tmp.replace(".", "/") + resourceInfo.serviceName + "FactoryService";
		service.setAttribute("name", factoryServicePath);
		service.setAttribute("provider", "Handler");
		service.setAttribute("style", "document");
		service.setAttribute("use", "literal");

		parameter = doc.createElement("parameter");
		parameter.setAttribute("name", "allowedMethods");
		parameter.setAttribute("value", "*");
		service.appendChild(parameter);

		parameter = doc.createElement("parameter");
		parameter.setAttribute("name", "className");
		parameter.setAttribute("value", resourceInfo.implPackageName + "." + resourceInfo.serviceName + "Service");
		service.appendChild(parameter);

		parameter = doc.createElement("parameter");
		parameter.setAttribute("name", "handlerClass");
		parameter.setAttribute("value", "org.globus.axis.providers.RPCProvider");
		service.appendChild(parameter);

		parameter = doc.createElement("parameter");
		parameter.setAttribute("name", "instance");
		parameter.setAttribute("value", tmp.replace(".", "/") + resourceInfo.serviceName + "Service");
		service.appendChild(parameter);

		parameter = doc.createElement("parameter");
		parameter.setAttribute("name", "scope");
		parameter.setAttribute("value", "Application");
		service.appendChild(parameter);

		wsdlFile = doc.createElement("wsdlFile");
		wsdlFile.setTextContent("share/schema/" + tmp.replace(".", "/") + resourceInfo.serviceName + "Factory_service.wsdl");
		service.appendChild(wsdlFile);

		deployment.appendChild(service);

		doc.appendChild(deployment);
		return doc;
	}

	static Document generateJNDI(ResourceInfo resourceInfo) throws ParserConfigurationException {
		Document doc = XMLUtils.newDocument();

		Element deployment = doc.createElement("jndiConfig");
		deployment.setAttribute("xmlns", JNDICONF_NS_URL);

		// Service JNDI Config
		Element service = doc.createElement("service");
		String tmp = resourceInfo.implPackageName.substring(0, resourceInfo.implPackageName.length() - "impl".length());
		String servicePath = tmp.replace(".", "/") + resourceInfo.serviceName + "Service";
		service.setAttribute("name", servicePath);

		Element resource = doc.createElement("resource");
		resource.setAttribute("name", "home");
		resource.setAttribute("type", resourceInfo.implPackageName + "." + resourceInfo.simpleName + "Home");

		Element resourceParams = doc.createElement("resourceParams");

		Element parameter = doc.createElement("parameter");
		Element name = doc.createElement("name");
		name.setTextContent("resourceClass");
		parameter.appendChild(name);
		Element value = doc.createElement("value");
		value.setTextContent(resourceInfo.implPackageName + "." + resourceInfo.simpleName);
		parameter.appendChild(value);
		resourceParams.appendChild(parameter);

		parameter = doc.createElement("parameter");
		name = doc.createElement("name");
		name.setTextContent("factory");
		parameter.appendChild(name);
		value = doc.createElement("value");
		value.setTextContent("org.globus.wsrf.jndi.BeanFactory");
		parameter.appendChild(value);
		resourceParams.appendChild(parameter);

		parameter = doc.createElement("parameter");
		name = doc.createElement("name");
		name.setTextContent("resourceKeyName");
		parameter.appendChild(name);
		value = doc.createElement("value");
		value.setTextContent("{http://" + resourceInfo.tnsFQDN + "/" + resourceInfo.tnsPath +  "}" + resourceInfo.simpleName + "Key");
		parameter.appendChild(value);
		resourceParams.appendChild(parameter);

		resource.appendChild(resourceParams);
		service.appendChild(resource);
		deployment.appendChild(service);

		// Factory Service JNDI Config
		service = doc.createElement("service");
		String factoryServicePath = tmp.replace(".", "/") + resourceInfo.serviceName + "FactoryService";
		service.setAttribute("name", factoryServicePath);

		Element resourceLink = doc.createElement("resourceLink");
		resourceLink.setAttribute("name", "home");
		resourceLink.setAttribute("target", "java:comp/env/services/" + tmp.replace(".", "/") + resourceInfo.serviceName + "Service/home");
		service.appendChild(resourceLink);

		deployment.appendChild(service);

		doc.appendChild(deployment);
		return doc;
	}
/*
  3         <service name="jp/go/aist/gtrc/test/SampleService">
  4                 <resource name="home" type="jp.go.aist.gtrc.test.impl.SampleResourceHome">
  5                         <resourceParams>
  6                                 <parameter>
  7                                         <name>resourceClass</name>
  8                                         <value>jp.go.aist.gtrc.test.impl.SampleResource</value>
  9                                 </parameter>
 10                                 <parameter>
 11                                         <name>factory</name>
 12                                         <value>org.globus.wsrf.jndi.BeanFactory</value>
 13                                 </parameter>
 14                                 <parameter>
 15                                         <name>resourceKeyName</name>
 16                                         <value>{http://gtrc.aist.go.jp/test}SampleResourceKey</value>
 17                                 </parameter>
 18                         </resourceParams>
 19                 </resource>
 20         </service>
 21         <service name="jp/go/aist/gtrc/test/SampleFactoryService">
 22                 <resourceLink name="home" target="java:comp/env/services/jp/go/aist/gtrc/test/SampleService/home"/>
 23         </service>
*/
/*
        // Implementation of add Operation
        public AddResponse add(Add request) throws RemoteException {
                Object resource = null;
                try {
                        resource = ResourceContext.getResourceContext().getResource();
                } catch (RemoteException e) {
                        throw e;
                } catch (Exception e) {
                        throw new RemoteException("", e);
                }
                SampleResource counter = (SampleResource)resource;
                counter.add(request.getAddValue());
                return new AddResponse();
        }

        // Implementation of sub Operation
        public SubResponse sub(Sub request) throws RemoteException {
                Object resource = null;
                try {
                        resource = ResourceContext.getResourceContext().getResource();
                } catch (RemoteException e) {
                        throw e;
                } catch (Exception e) {
                        throw new RemoteException("", e);
                }
                SampleResource counter = (SampleResource)resource;
                counter.sub(request.getSubValue());
                return new SubResponse();
        }
*/
	static boolean isTestOk() {
		try {
			if (!relativePath("", "").equals("")) {
				System.out.println("!relativePath(\"\", \"\").equals(\"\")");
				return false;
			}
			if (!relativePath("abc", "").equals("..")) {
				System.out.println("!relativePath(\"abc\", \"\").equals(\"..\")");
				return false;
			}
			if (!relativePath("", "abc").equals("abc")) {
				System.out.println("!relativePath(\"\", \"abc\").equals(\"abc\")");
				return false;
			}
			if (!relativePath("abc/def/ghi/jkl/mno", "abc/def").equals("../../..")) {
				System.out.println("!relativePath(\"abc/def/ghi/jkl/mno\", \"abc/def\").equals(\"../../..\")");
				return false;
			}
			if (!relativePath("abc/def/ghi", "abc/def/ghi/jkl").equals("jkl")) {
				System.out.println("!relativePath(\"abc/def/ghi\", \"abc/def/ghi/jkl\").equals(\"jkl\")");
				return false;
			}
			if (!relativePath("abc/def/ghi", "abc/def/jkl").equals("../jkl")) {
				System.out.println("!relativePath(\"abc/def/ghi\", \"abc/def/jkl\").equals(\"../jkl\")");
				return false;
			}
		} catch (Throwable e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}
}
