package bricks.scheduling;
import bricks.util.*;
import bricks.environment.*;
import java.util.*;

public class DeadlineLoadThroughputScheduler extends LoadThroughputScheduler {

    /**
     * The optimisticFactor is in the range (0.0, 1.0].
     **/
    protected double optimisticFactor;
    protected double interval;

    public DeadlineLoadThroughputScheduler(
	String keyOfMetaPredictor, double optimisticFactor, double interval
    ) {
	super(keyOfMetaPredictor, optimisticFactor, interval);
	this.optimisticFactor = optimisticFactor;
	this.interval = interval;

	if ((optimisticFactor <= 0.0) || (optimisticFactor > 1.0)) {
	    System.err.println(
		"The optimisticFactor has to be in the range (0.0, 1.0]."
	    );
	    System.exit(3);
	}
    }

/************************* needed method *************************/
    public String getName() {
	return "DeadlineLoadThroughputScheduler";
    }

    public void selectHosts(
	double currentTime, Host source, RequestedData data
    ) throws BricksNotScheduledException {

	// not defined deadlineFactor
	if (data.deadlineFactor < 0.) {
	    super.selectHosts(currentTime, source, data);
	    return;
	}

	double idealElapsedTime = 
	    (data.deadline - currentTime) * optimisticFactor;

	Host safeHost = null;
	Host outHost = null;
	double safeDiff = Double.POSITIVE_INFINITY;
	double outDiff = Double.NEGATIVE_INFINITY;

	Enumeration e = resourceDB.hosts(data);
	while (e.hasMoreElements()) {
	    Host h = (Host) e.nextElement();
	    if (!data.scheduled(h)) { // for fallback
		double elapsedTime = getEstimate(currentTime, source, h, data);
		double diff = idealElapsedTime - elapsedTime;

		if (diff < 0.0) {
		    if (outDiff < diff) {
			outHost = h;
			outDiff = diff;
		    }
		} else {
		    if (safeDiff > diff) {
			safeHost = h;
			safeDiff = diff;
		    }
		}
	    }
	}

	// for fallback
	if ((safeHost == null) && (outHost == null)) {
	    e = data.scheduledHosts();
	    while (e.hasMoreElements()) {
		Host h = (Host) e.nextElement();
		double elapsedTime = getEstimate(currentTime, source, h, data);
		double diff = idealElapsedTime - elapsedTime;

		if (diff < 0.0) {
		    if (outDiff < diff) {
			outHost = h;
			outDiff = diff;
		    }
		} else {
		    if (safeDiff > diff) {
			safeHost = h;
			safeDiff = diff;
		    }
		}
	    }
	}

	Host selectedHost = null;
	if (safeHost != null) {
	    if (safeDiff > interval) { // reschedule
		updateStatus(data, interval);
		data.reschedule++;
		//System.out.println(
		SimulationDebug.println(
		    this + ": " + currentTime + " : Reschedule");
		throw new BricksNotScheduledException(this.toString());
	    } else {
		selectedHost = safeHost;
		data.expectedFinishTime = currentTime + 
		    idealElapsedTime - safeDiff;
		//System.out.println(
		SimulationDebug.println(
		    this + ": " + currentTime + " : Schedule completed(safe)");
	    }
	} else { // out
	    selectedHost = outHost;
	    data.expectedFinishTime = currentTime + idealElapsedTime - outDiff;
	    //System.out.println(
	    SimulationDebug.println(
		this + ":" + currentTime + " : Schedule completed(out)");
	}

	updateStatus(currentTime, source, selectedHost, data);
	data.setElapsedTime(data.deadline - currentTime);
    }
}
