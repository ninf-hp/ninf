#ifndef __SESSION__
#define __SESSION__

#include <stdarg.h>
#include <sys/types.h>
#ifndef WIN32
#include <sys/time.h>
#else
#include <sys/timeb.h>
#endif
#include "ninf_entry.h"
#include "connection.h"
#include "callback.h"
#include "ninf_cim.h"
#include "nslib_utils.h"

typedef struct {
  ninf_entry * entry;
  connection * server;
  NINF_STUB_INFO * stub_info;
} _Ninf_executable_t; 

typedef struct _exec_info_struct{
  double fore_time;
  double exec_time;
  double back_time;
  char * hostname;
  int port;

  /* begin akiyama writes */
  
  long fore_size;
  long back_size;
  long cmp_steps;
  double total_time;
  char * descript;
  char * usrid;
  char * client;
  char * source;
  char * func_name;
  
  /* end akiyama writes */

#ifndef WIN32
  struct timeval start_time, end_time;
#else
  struct _timeb start_time, end_time;
#endif
  double client_exec_time;
  int call_serial;
  int error_no;
} exec_info;

typedef struct ninf_session {
  int id;
  ninf_entry * entry;
  connection * server;
  any_t * args;
  NINF_STUB_INFO * stub_info;
  callback * callbacks;
  resource * c_resource;
  int synchronous;
  int isFortran;

  /** for ninf_executable support */
  int autoShutDown;
  _Ninf_executable_t * exe; 

  exec_info e_info; 
} ninf_session;

#if 0
/* deprecated  */
typedef struct session_list {
  ninf_session * session;
  struct session_list * next;
} session_list;
#endif

/********  session functions **********/
/********  instance creation **********/
ninf_session * 
new_ninf_session(connection * server, any_t args[], NINF_STUB_INFO * stub_info, 
		 callback callbacks[], resource * c_resource);
ninf_session * 
new_ninf_session_stub(NINF_STUB_INFO * stub_info);

ninf_session * 
new_ninf_session_string(char * ninf_stub_entry);

ninf_session *
new_ninf_session_entry(ninf_entry * entry);

ninf_session *
new_ninf_session_transaction();

ninf_session * 
new_ninf_session_executable(_Ninf_executable_t * exe);

void destruct_ninf_session(ninf_session * session);
void session_close(ninf_session * session);
void session_done(ninf_session * session);
int session_is_done(int id);

/********  subroutines **********/
NINF_STUB_INFO * session_stub_info(ninf_session * session);
int session_connect(ninf_session * session);
ninf_session * start_session(ninf_session * session);
int session_do_v(ninf_session * session, any_t * args);
int session_do(ninf_session * session, va_list *app);
int session_do_common(ninf_session * session);
int session_do_cim(ninf_session * session, obj_handler * hp);

int finish_session(ninf_session * session);
int do_session(int fd);
int session_kill(int id);

/*********** SESSION LIST ***********/
int add_session(ninf_session * session);
nslib_list_t * collect_session_list(int *, int);
nslib_list_t * root_sessions();
nslib_list_t * done_sessions();

ninf_session * find_session(int num, nslib_list_t *);
ninf_session * find_all_session(int num);
int get_session_fd(ninf_session * s);
ninf_session * find_session_by_fd(int fd);
ninf_session * rm_session_by_session(ninf_session * session);
ninf_session * rm_session(int num);

ninf_session * get_last_session();

ninf_session * select_session(nslib_list_t * sessions, int one_by_one);

#endif /* __CALLBACK__ */

