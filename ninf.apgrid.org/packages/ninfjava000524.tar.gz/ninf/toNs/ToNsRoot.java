package ninf.toNs;
import ninf.basic.*;
import ninf.client.*;
import ninf.cproxy.*;
import java.io.*;


public class ToNsRoot extends NServer {
  String myname;
  int myport;

  boolean lookup = true;

  static int callSerial = 0;
  MetaServerReference metaServer;
  CallableCache callableCache;
  Stoppable called; 

  static NinfLog dbg = new NinfLog("ToNsRoot");

  ToNsRoot(String myname, int myport) throws NinfException{
    this.myname = myname;
    this.myport = myport;
    this.metaServer = ToNsAdapter.conf.metaServer;
    this.callableCache = new ProblemCache(ToNsAdapter.conf.netsolveAgent);
    this.lookup = ToNsAdapter.conf.lookup;
    NinfServerConnection.lookup = ToNsAdapter.conf.lookup;
    MetaServerConnection.lookup = ToNsAdapter.conf.lookup;
  }

  void sendBackStub(Callable callable, XDROutputStream os) throws NinfException {
    NinfPacketOutputStream nos = 
      new NinfPacketOutputStream(os, NinfPktHeader.NINF_PKT_RPY_STUB_INFO, callable.index, 0);
    nos.write(callable.getStub().toByteArray());
    nos.flush();
  }

  void processReqStubInfo(NinfPacket pkt, XDROutputStream os) throws NinfException {
    try {
      String entry = pkt.readString();
      Callable stubCallable = callableCache.getStubCallable(new FunctionName(entry));
      sendBackStub(stubCallable, os);
      return;
    } catch (NinfIOException e) {
      dbg.println("processReqStubInfo: " + e);
      e.printStackTrace();
      return;
    }
  }

  void processReqCall(NinfPacket pkt, XDRInputStream is, XDROutputStream os)  
  throws NinfException {
    dbg.println("processReqCall()");
    try {
      NinfPacketOutputStream pos = 
	new NinfPacketOutputStream(os, NinfPktHeader.NINF_PKT_RPY_CALL);
      int serial = getSerial();
      pos.writeInt(serial);
      pos.flush();

      Callable callable = callableCache.getCallable(pkt.hdr.arg1);
      called = callable.call(pkt, serial, is, os);
    } finally {
      //      os.flush();
    }
  }

  void processGetTime(NinfPacket pkt, XDRInputStream is, XDROutputStream os)  
  throws NinfException {
    dbg.println("processGetTime()");
    try {
      NinfPacketOutputStream pos = 
	new NinfPacketOutputStream(os, NinfPktHeader.NINF_PKT_RPY_GETTIME);
      pos.writeDouble(System.currentTimeMillis() / 1000.0);
      pos.flush();
    } finally {
      //      os.flush();
    }
  }
  void processKill(NinfPacket pkt,  XDRInputStream is, XDROutputStream os)  
  throws NinfException {
    dbg.println("processKill()");
    if (called != null)
      called.stop();
    called = null;
    
    NinfPacketOutputStream pos = 
      new NinfPacketOutputStream(os, NinfPktHeader.NINF_PKT_RPY_KILL);
    pos.flush();
  }

  void processThroughput(NinfPacket pkt,  XDRInputStream is, XDROutputStream os)  
  throws NinfException {
    
    int length = pkt.hdr.arg1;
    int mode =   pkt.hdr.arg2; /* (0=both,1=fore,2=back) */
    NinfPacketInputStream pis = 
      new NinfPacketInputStream(pkt, is);
    if (mode == 0 || mode == 1)
      pis.readThrough(length);
    
    NinfPacketOutputStream pos = 
      new NinfPacketOutputStream(os, NinfPktHeader.NINF_PKT_RPY_THROUGHPUT);
    
    if (mode == 0 || mode == 2)
      pos.writeThrough(length);
    pos.flush();
  }

  void processLoad(NinfPacket pkt, XDRInputStream is, XDROutputStream os)  
  throws NinfException {
    NinfPacketOutputStream pos = 
      new NinfPacketOutputStream(os, NinfPktHeader.NINF_PKT_RPY_LOAD);

    /* cannot define load average of the netsolve system */
    pos.writeDouble(-1.0);
    pos.writeDouble(-1.0);   
    pos.writeDouble(-1.0);
    pos.writeDouble(-1.0);
    pos.flush();
  }

  void processCharacter(NinfPacket pkt, XDRInputStream is, XDROutputStream os)  
  throws NinfException {
    NinfPacketOutputStream pos = 
      new NinfPacketOutputStream(os, NinfPktHeader.NINF_PKT_RPY_CHARACTER);
    /* cannot define character of the netsolve system */
    pos.writeInt(-1);
    pos.writeInt(-1);
    pos.writeInt(-1);
    pos.flush();
  }

  void processIndexList(NinfPacket pkt, XDRInputStream is, XDROutputStream os)  
  throws NinfException {
    NinfPacketInputStream pis = new NinfPacketInputStream(pkt, is);
    NinfPacketOutputStream pos = 
      new NinfPacketOutputStream(os, NinfPktHeader.NINF_PKT_RPY_STUB_INDEX_LIST);

    String entry  = pis.readString();
    int    option = pkt.hdr.arg1;
    
    Callable callables[] = callableCache.findCallables(entry, option);
    for (int i = 0; i < callables.length; i++)
      pos.writeInt(callables[i].index);
    pos.setArg1(callables.length);
    pos.flush();
  }

  void processStubByIndex(NinfPacket pkt, XDRInputStream is, XDROutputStream os)  
  throws NinfException {
    try {
      int index = pkt.hdr.arg1;
      Callable stubCallable = callableCache.getCallable(index);
      sendBackStub(stubCallable, os);
      return;
    } catch (NinfIOException e) {
      dbg.println("processStubByIndex: " + e);
      e.printStackTrace();
      return;
    }
  }


  /** dispatch jobs according to packet code */
  public boolean dispatchNinfRequest(XDRInputStream is, XDROutputStream os) {
    boolean ret = true;
    NinfPacket pkt = null;
    try {
      pkt = new NinfPacket(is);
    } catch (NinfIOException e) {
      //      dbg.println("dispatchNinfRequst: " + e);
      //e.printStackTrace(dbg.os);
      return false;
    }
    try {
      if (lookup)
	dbg.log("["+myport+"] accept connection from " + clientSocket.getInetAddress());
      else
	dbg.log("["+myport+"] accept connection from " + clientSocket.getInetAddress().getHostAddress());      
      
      dbg.println("CProxy Read Pkt" + pkt.hdr);
      switch (pkt.hdr.code) {
      case NinfPktHeader.NINF_PKT_REQ_STUB_INFO:
	processReqStubInfo(pkt, os);
	break;
      case NinfPktHeader.NINF_PKT_REQ_CALL:
	processReqCall(pkt, is, os);
	break;
      case NinfPktHeader.NINF_PKT_GETTIME:
	processGetTime(pkt, is, os);
	break;
      case NinfPktHeader.NINF_PKT_KILL:
	processKill(pkt, is, os);
	break;
      case NinfPktHeader.NINF_PKT_THROUGHPUT:
	processThroughput(pkt, is, os);
	break;
      case NinfPktHeader.NINF_PKT_LOAD:
	processLoad(pkt, is, os);
	break;
      case NinfPktHeader.NINF_PKT_CHARACTER:
	processCharacter(pkt, is, os);
	break;
      case NinfPktHeader.NINF_PKT_REQ_STUB_INDEX_LIST:  /* req stub index list */
	processIndexList(pkt, is, os);
	break;
      case NinfPktHeader.NINF_PKT_REQ_STUB_BY_INDEX:    /* req stub by index */
	processStubByIndex(pkt, is, os);
	break;
      case NinfPktHeader.NINF_PKT_TO_STUB:    /* req stub by index */
	if (pkt.hdr.size == 0)              /* non zero packet is unknown */
	  break;
      default:
	dbg.log("Unknown Coded Packet " + pkt.hdr.code);
	ret = false;
	break;
      }
    } catch (NinfException e) {
      dbg.println("exception occured in execution " + pkt.hdr.code);
      e.printStackTrace(dbg.os);
      int errorNo = 0;
      if (e instanceof NinfErrorException)
	errorNo = ((NinfErrorException)e).errorNo;
      NinfPacketOutputStream pos =
	new NinfPacketOutputStream(os, NinfPktHeader.NINF_PKT_ERROR, errorNo, 0);
      try {pos.flush();} catch(Exception ie){
	dbg.println("Can't return error pkt");
      }
      ret = false;
    }
    return ret;
  }

  public void serviceRequest() {
    XDRInputStream is = new XDRInputStream(clientInput);
    XDROutputStream os = new XDROutputStream(clientOutput);
    
    while (dispatchNinfRequest(is, os))
      ;
  }

  synchronized int getSerial(){
    return callSerial++;
  }

  void introduceMyselfToMetaServer(){
    try {
      MetaServerReference metaServer = ToNsAdapter.conf.metaServer;
      if (metaServer == null){
	dbg.log("MetaServer is not specified in the config file");
	return;
      }
      MetaServerConnection con = metaServer.connect();
      con.send(new NinfCommand("register", myname, ""+myport));
      con.close();
    } catch (NinfException e){
      dbg.log("Could not introduce myself to the metaserver");
    }
  }

  void start(){
    startServer(myport);
    dbg.log("[" +myport+"] start ..");
    introduceMyselfToMetaServer();
  }
}
