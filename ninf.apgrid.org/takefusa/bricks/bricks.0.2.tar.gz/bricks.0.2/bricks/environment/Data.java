package bricks.environment;
import java.util.*;

/** Class Data
 **   static  : client, network, server, dataSize.., numInstructions
 **   dynamic : timeEventComes, queueintTime, logTime[] */

public abstract class Data {

    public double timeEventComes;
    public double processingDuration;
    public static long serialNumber = 0L;
    public int precision = 3;
    public String id;

    public abstract void updateProcessingDuration(
	double currentTime, double throughput
    );
    public abstract String getName();
    public abstract double getDataSize();
    public abstract String toOriginalString();
    public String toString() {
	return id;
    }

/************************* method needed to override *************************/
    public void gotoNextNode(double currentTime) {;}
    public void outLogString(double currentTime) {;}
    public void updateDataSize() {;}
    public void updateDataSize(double size) {;}

/************************* default method *************************/
    public Node nextNode() {
	return null;
    }

    // callee: QueueTimeSharing
    public void setProcessingDuration(double duration) {
	this.processingDuration = duration;
    }

    public void updateTimeEventComes(double currentTime) {
	timeEventComes = currentTime + processingDuration;
    }

    protected void error (String message) throws RuntimeException {
	System.err.println("Data Error:: " + message);
	throw new RuntimeException();
    }
}
