package ninf.netsolve;

import java.util.Vector;
import ninf.basic.NinfLog;

public class FormulaParser{
  static NinfLog dbg = new NinfLog("FormulaParser");

  char buffer[];
  int index;
  String tokens[];
  int tindex;
  
  static char delimiters[] = {' ', '(', ')',  '\'', ',', '='};

  char next(){
    return buffer[index++];
  }
  void pushback(){
    index--;
  }

  String nextToken(){
    return tokens[tindex++];
  }
  void pushbackToken(){
    tindex--;
  }

  public FormulaParser(String str){
    dbg.println("parsing: " + str);
    this.buffer = str.toCharArray();
    index = 0;
  }
  
  boolean isDelimiter(char c){
    for (int i = 0; i < delimiters.length; i++)
      if (delimiters[i] == c)
	return true;
    return false;
  }

  String readToken(){
    char tmp;
    int current = index;
    try {
      if (isDelimiter(tmp = next())){
	if (tmp == '\''){
	  current = index - 1;
	  while (next() != '\'');
	  return String.valueOf(buffer, current, index -current);
	}
	if (tmp == ' ')
	  return readToken();
	return ""+ tmp;
      } else
	pushback();
      current = index;
      
      while (!isDelimiter(next()));
      pushback();
      if (index == current)
	return readToken();
      return String.valueOf(buffer, current, index - current);
    } catch (Exception e){
      if (index -1 != current)
	return String.valueOf(buffer, current, index -1 - current);
      return null;
    }
    
  }

  void divide(){
    Vector v = new Vector();
    
    while (true){
      String token = readToken();
      if (token == null)
	break;
      v.addElement(token);
    }
    tokens = new String[v.size()];
    for (int i = 0; i < v.size(); i++){
      tokens[i] = (String)(v.elementAt(i));
      //      System.out.println(tokens[i]);
    }
  }

  public ParsedFormula parseSubSub() throws CannotParseException{
    String tmp, next;

    try {
      tmp = nextToken();
    } catch (Exception e){
      throw new CannotParseException();
    } 
    try {
      next = nextToken();
    } catch (Exception e){
      return makeParsed(tmp);
    }
    if (next.equals("(")){
      try {
	Vector v = new Vector();
	while (true){
	  String nn = nextToken();
	  if (nn.equals(")")){
	    ParsedFormula parts[] = new ParsedFormula[v.size()];
	    for (int i = 0; i < v.size(); i++)
	      parts[i] = (ParsedFormula)(v.elementAt(i));
	    return new FormulaExpression(tmp, parts);
	  } else if (nn.equals(",")){
	    throw new CannotParseException();
	  } else {
	    pushbackToken();
	    v.addElement(parseSub());
	  }
	  nn = nextToken();
	  if (nn.equals(")")){
	    ParsedFormula parts[] = new ParsedFormula[v.size()];
	    for (int i = 0; i < v.size(); i++)
	      parts[i] = (ParsedFormula)(v.elementAt(i));
	    return new FormulaExpression(tmp, parts);
	  } else if (!nn.equals(",")){
	    throw new CannotParseException();
	  }
	}
      } catch (Exception e){
	e.printStackTrace();
	throw new CannotParseException();
      }
    } else {
      pushbackToken();
      return makeParsed(tmp);
    }
  }

  ParsedFormula parseSub() throws CannotParseException{
    ParsedFormula tmp = parseSubSub();
    String next;
    try {
      next = nextToken();
    } catch (Exception e){
      return tmp;
    }
    if (next.equals("=")){
      ParsedFormula parts[] = new ParsedFormula[2];
      parts[0] = tmp;
      parts[1] = parseSub();
      return new FormulaExpression(next, parts);
    } else {
      pushbackToken();
      return tmp;
    }
  }
  ParsedFormula makeParsed(String str){
    char buf[] = str.toCharArray();
    if (buf[0] == '\'' && buf[buf.length -1] == '\'')
      return new FormulaConstant((int)buf[1]);
    boolean flag = true;
    for (int i = 0; i < buf.length; i++)
      if (!Character.isDigit(buf[i]))
	flag = false;
    if (flag)
      return new FormulaConstant(Integer.parseInt(str));
    return new FormulaMnemonic(str);
      
  }

  public ParsedFormula parse(){
    divide();
    tindex = 0;
    try {
      return parseSub();
    } catch(CannotParseException e) {
      e.printStackTrace();
      return null;
    }
  }


  public static void main(String args[]){
    System.out.println((new FormulaParser(args[0])).parse());
  }



}

