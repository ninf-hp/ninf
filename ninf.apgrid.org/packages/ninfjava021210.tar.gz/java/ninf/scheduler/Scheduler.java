package ninf.scheduler;
import ninf.common.*;
import ninf.metaserver.*;
import ninf.basic.*;
import ninf.client.*;
import java.util.Vector;

public abstract class Scheduler {
  public abstract ScheduleResult schedule(CallInformation info, 
					  ServerIndex serverIndexes[],
    SchedulerRoot schedulerRoot, ServerID cproxy, StringBuffer sb)
       throws NinfException;

  protected ServerInformation 
  setupInfo(SchedulerRoot schedulerRoot, ServerID cproxy, 
			      ServerIndex serverIndex) throws NinfException{
    CommunicationInformation throughput =
      schedulerRoot.getThroughput(serverIndex.server, cproxy);
    CommunicationInformation latency =
      schedulerRoot.getLatency   (serverIndex.server, cproxy);
    LoadInformation load = 
      schedulerRoot.getLoad      (serverIndex.server);
    ServerCharacter serverChar = 
      schedulerRoot.getServerChar(serverIndex.server);
    return new ServerInformation(serverIndex, throughput, latency, 
				 load, serverChar);
  }

}
