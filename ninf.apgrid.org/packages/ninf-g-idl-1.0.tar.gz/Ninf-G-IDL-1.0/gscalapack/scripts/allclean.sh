#! /bin/sh
# $Id: allclean.sh,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $

for arg in "$@"
do
    case $arg in
	*=*) eval `expr ${arg} : '\(.*\)='`=`expr ${arg} : '.*=\(.*\)'`
        ;;
        *)
        ;;
    esac
done

[ x"${MAKE}" = x"" ] && exit 3
[ x"${TOPDIR}" = x"" ] && exit 3
[ x"${BINDIR}" = x"" ] && exit 3
[ x"${INCLUDEDIR}" = x"" ] && exit 3
[ x"${SRCDIR}" = x"" ] && exit 3

if [ ! -f ${SRCDIR}/pdgesv.idl ] ; then
    exit 2 
fi

if [ x"${TOPDIR}" != x"" ] ; then

    cd ${INCLUDEDIR} && ( ${MAKE} allclean ; cd ..) 
    cd ${SRCDIR} && ( ${MAKE} allclean ;  cd ..) 

    if [ -d ${BINDIR} ] ; then
	cd ${BINDIR}
	rm *.mak scalapack::* *_ninf.[co] _stub_*.[oc] _inf_*.[oc]
	rm scalapack.*.nsdef* scalapack.*.ngdef*
    fi

    cd ${TOPDIR} || exit 2

fi

if [ -f ${SRCDIR}/pdgesv.idl ] ; then
    rm ${SRCDIR}/.??* 
    find ${SRCDIR}/lib -name '*.o' -a -type f -exec rm {} \; 
    find ${SRCDIR}/lib -name '*.a' -a -type f -exec rm {} \; 
else
    exit 2 
fi

