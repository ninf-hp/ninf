#define NINF_ERROR   (-1)
/* options */
#define ROPTION  0x0000001  /* reverce the order */
#define KOPTION  0x0000010  /* keyword search */
#define FOPTION  0x0000100  /* from the alphabet */
#define TOPTION  0x0001000  /* to the alphabet */
#define AOPTION  0x0010000  /* all range */
#define EOPTION  0x0100000  /* point out each functions */


