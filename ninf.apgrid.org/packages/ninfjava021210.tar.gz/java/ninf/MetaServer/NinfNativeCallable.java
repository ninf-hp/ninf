// NinfNativeCallable.java

package ninf.MetaServer;
import ninf.basic.*;
import ninf.client.*;
import java.util.Vector;

import java.io.IOException;

public interface NinfNativeCallable {
  public Stoppable callNative(Vector args)
    throws NinfException ;
  public Connected connect() throws NinfException ;
  public Stoppable callWith(Connected s, Vector args) throws NinfException ;
  public NinfStub getStub();
}

// end of NinfNativeCallable.java
