/***************************
  ninf_data_trans  using IEG2CRAY 
  ***************************/
/*
 *	itype argument for CRAY2IEG/IEG2CRAY function
 *	itype		data type
 *	1		Integer
 *	2		Real
 *	3		Double
 *	4		Complex
 *	5		Logical
 *	6		Character : ASCII to ASCII; no translation
 *	8		Special. IEEE double(8 bytes) <-> CRAY real(8 bytes)
 *
 *	Applications' normal translation style (in byte unit)
 *		IEEE integer(4)	<->	CRAY integer(8)		: itype=1
 *		IEEE real(4)	<->	CRAY real(8)		: itype=2
 *		IEEE double(8)	<->	CRAY real(8)		: itype=8
 *
 */
 
int ieg2cray_flag[MAX_DATA_TYPE] = 
{
    -1 /* UNDEF */,	/* undefined */
    -1 /* VOID */,
    -1 /* CHAR */,
    -1 /* SHORT */,
    -1  /* INT */,
    -1 /* LONG */,
    -1 /* LONGLONG */,
    -1 /* UNSIGNED_CHAR */,
    -1 /* UNSIGNED_SHORT */,
    -1 /* UNSIGNED */,
    -1 /* UNSIGNED_LONG */,
    -1 /* UNSIGNED_LONGLONG */,
    -1  /* FLOAT */,
    8  /* DOUBLE */,
    -1 /* LONG_DOUBLE */,
    -1 /* STRING */,
};


void dt_shift(dataTrans * dt, int offset){
  if (dt->flag == XDR_DECODE){
    memcpy(dt->position + offset, dt->position, dt->valid_end - dt->position);
    dt->position += offset;
    dt->valid_end += offset;
  }
}

void trans_dataTrans_sub(dataTrans * dt, char * buffer, DATA_TYPE type, int items){
  int flag = ieg2cray_flag[type];

  if (flag < 0){
    trans_dataTrans_sub_xdr(dt, buffer, type, items);    
    return;
  } else {
    int ibitoff = 0;
    int items2 = items;
    int ierr;
    char *position = dt->position;
    unsigned int mask = 0xe000000000000000;
    int offset = ((unsigned )(mask & (int)(dt->position))) >> 61;
    if (dt->flag == XDR_ENCODE){
      ierr = CRAY2IEG (&flag, &items2, position + offset, &ibitoff, buffer);
      memcpy(dt->position, dt->position + offset, xdr_data_length[type] * items);
    } else {
      dt_shift(dt, -offset);
      position = dt->position;
      ierr = IEG2CRAY (&flag, &items2, position, &ibitoff, buffer);
    }
    dt->position += xdr_data_length[type] * items;
  }

}




