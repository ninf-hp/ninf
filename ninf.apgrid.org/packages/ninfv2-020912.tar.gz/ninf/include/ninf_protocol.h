#ifndef _NINF_PROTOCOL_H_
#define _NINF_PROTOCOL_H_

/* ninf request code */
#define NINF_ACK_ERROR		(-1)	/* error ack, < 0 */
#define NINF_ACK_OK		0	/* OK */
#define NINF_REQ_CALL		1
#define NINF_REQ_STUB_INFO	2
#define NINF_REQ_KILL		3
#define NINF_CALLBACK           4
#define NINF_CALLBACK_ACK_OK    5
#define NINF_CALLBACK_ACK_ERR   6
#define NINF_REQ_CALL_WITH_STREAM  7
#define NINF_REQ_STUB_INFO_LOCAL	8

#endif /* _NINF_PROTOCOL_H_ */
