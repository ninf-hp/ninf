#! /bin/sh
# $Id: ninf_cc.sh,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $

# Use this script when you can't get a gcc-like preprocessor.

NINF_CC_ARGS=
for arg in "$@" ; do
    case "$arg" in
	NINF_TOPDIR=*) 
	    TARGETENV=`expr "${arg}" : '\([^=]*\)='`
	    VAL="`expr "${arg}" : '[^=]*=\(.*\)'`"
	    eval ${TARGETENV}=\"${VAL}\"
        ;;
	LINKER=*) 
	    TARGETENV=`expr "${arg}" : '\([^=]*\)='`
	    VAL="`expr "${arg}" : '[^=]*=\(.*\)'`"
	    eval ${TARGETENV}=\"${VAL}\"
        ;;
        *)
		NINF_CC_ARGS="${NINF_CC_ARGS} ${arg}"
        ;;
    esac
done

check_ninf_ver() {
    if [ x"${NINF_TOPDIR}" = x"" ] ; then
	echo -n NONINF
	exit 1
    fi
    if [ x"$NG_DIR" = x"${NINF_TOPDIR}" -a x"${NINF_TOPDIR}" != x"" ] ; then
	echo -n NINFG2
	return 0
    fi
    if [ x"$NS_DIR" = x"${NINF_TOPDIR}" -a x"${NINF_TOPDIR}" != x"" ] ; then
	echo -n NINFG1
	return 0
    fi
    if [ x"$NINF_DIR" = x"${NINF_TOPDIR}" -a x"${NINF_TOPDIR}" != x"" ] ; then
	echo -n NINF1
	exit 0
    fi
    echo -n NONINF
    return 1
}

NINF_VER=`check_ninf_ver`

case "$NINF_VER" in
    "NINFG2")
	    [ x"$LINKER" = x"" ] || export NG_LINKER=${LINKER}
	    ng_cc ${NINFG2_GEN_OPT} -DNINFG2 ${NINF_CC_ARGS}
	    ;;
    "NINFG1")
	    [ x"$LINKER" = x"" ] || export NS_LINKER=${LINKER}
	    ns_client_gen -DNINFG1 ${NINF_CC_ARGS}
	    ;;
    "NINF1")
	    ninf_client_gen -DNINF1 ${NINF_CC_ARGS}
	    ;;
    *)
	echo NoNINF
	exit 1
		;;
esac	   

