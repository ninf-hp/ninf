package bricks.environment;
import bricks.util.*;
import java.util.*;

public class DataFragments implements SubComponent {

    protected SimulationSet owner;
    protected int numFragments;
    protected Strings ids;
    protected Sequence sizes;

    public DataFragments(int numFragments, Strings ids, Sequence sizes) {
	this.numFragments = numFragments;
	this.ids = ids;
	this.sizes = sizes;
    }

    public String getName() {
	return "DataFragments";
    }

    public void setSimulationSet(SimulationSet owner) {
	this.owner = owner;
    }

    /** 
    /* generate() generates preStoredDataFragments and 
    /* returns total data size of preStoredDataFragments.
    */
    public double generate(Hashtable storedDataFragments) {
	double total = 0.0;
	for (int i = numFragments; i > 0; i--) {
	    double size = sizes.nextDouble();
	    String id = ids.nextString();
	    storedDataFragments.put(id, new DataFragment(id, size));
	    total += size;
	}
	return total;
    }
}
