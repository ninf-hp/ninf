#ifndef __CIM__
#define __CIM__

#include "ninf_error.h"
#include "ninf_stub_info.h"

extern int type_size[];

typedef void * obj_handler;
int ninf_cim_init(obj_handler);
int ninf_cim_finalize(obj_handler);
int ninf_cim_proceed(obj_handler, int, int);
int ninf_cim_get(obj_handler, void *, DATA_TYPE);
int ninf_cim_put(obj_handler, void *, DATA_TYPE);
int ninf_cim_destruct(obj_handler);

void Ninf_set_cim_funcs(int (*init)(obj_handler), 
			int (*finalize)(obj_handler),
			int (*proceed)(obj_handler, int, int),
			int (*get)(obj_handler, void *, DATA_TYPE),
			int (*put)(obj_handler, void *, DATA_TYPE),
			int (*destruct)(obj_handler));

#endif
