#include <stdio.h>
#include <math.h>
#include "ninf_stub.h"

#define URLString "http://ninf.etl.go.jp/paradise/tmp.ninfbin"

#define StorageString "storage://wiz.etl.go.jp:3001/tmpstorage"

#define N    600

int verbose = FALSE;

int file_test(char * URL){
  double a[N], b[N];
  int i, result;

  for (i = 0; i < N; i++){
    a[i] = i;
    b[i] = -1;
  }
  printf("file_testing with %s: ", URL);


  if (Ninf_call("test/double_test", N, a, URL) != NINF_OK)
    {Ninf_perror("double_test:"); return FALSE;}
  if (Ninf_call("test/double_test", N, URL, b) != NINF_OK)
    {Ninf_perror("double_test:"); return FALSE;}  
  for (i = 0; i < N; i++){
    if (a[i] != b[i]){
      printf("double_test: a[%d](%lf) != b[%d](%lf)\n", i, a[i], i, b[i]);
      return FALSE;
    }
  }
  return TRUE;
}


extern int ninf_debug_flag;
main(int argc, char ** argv)
{
    argc = Ninf_parse_arg(argc, argv);

    while (argc > 1){
      argv++;
      if (strcasecmp(*(argv), "-verbose") == 0)
	verbose = TRUE;
      if (strcasecmp(*(argv), "-debug") == 0)
	ninf_debug_flag = TRUE;
      argc--;
    }
    /*
    if (file_test("file:///saru"))  {printf("\tOK\n");} else { printf("\tfailed\n");}
    if (file_test(URLString))      {printf("\tOK\n");} else { printf("\tfailed\n");}
    */
    if (file_test(StorageString))      {printf("\tOK\n");} else { printf("\tfailed\n");}

}

