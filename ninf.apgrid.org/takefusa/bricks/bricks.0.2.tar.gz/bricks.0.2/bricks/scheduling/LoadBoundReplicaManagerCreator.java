package bricks.scheduling;
import bricks.util.*;
import java.util.*;

public class LoadBoundReplicaManagerCreator extends SchedulingUnitCreator {

    // for bricks.tools.ShowUsage
    public LoadBoundReplicaManagerCreator(){}

    public LoadBoundReplicaManagerCreator(SubComponentFactory subComponentFactory) {
	this.subComponentFactory = subComponentFactory;
    }

    public String usage() {
	return "LoadBoundReplicaManager(<String keyOfRresourceDB>, <String keyOfServerMonitor>, <Sequence interEvaluationTime>, <double compactness>, <double minLoadScore>, <double overstoredDiskRate>)";
    }

    public SchedulingUnit create(StringTokenizer st) 
	throws BricksParseException 
    {
	try {
	    String keyOfResourceDB = st.nextToken(" \t,()");
	    String keyOfServerMonitor = st.nextToken(" \t,()");
    	    Sequence interEvaluationTime = 
		(Sequence)subComponentFactory.create(st);
	    double compactness = 
		Double.valueOf(st.nextToken(" \t,()")).doubleValue();
	    double score = 
		Double.valueOf(st.nextToken(" \t,()")).doubleValue();
	    double rate = Double.valueOf(st.nextToken(" \t,()")).doubleValue();

	    return new LoadBoundReplicaManager(
		keyOfResourceDB, keyOfServerMonitor, 
		interEvaluationTime, compactness, score, rate
	    );

	} catch (NoSuchElementException e) {
	    e.printStackTrace();
	    throw new BricksParseException(usage());

	} catch (NumberFormatException e) {
	    e.printStackTrace();
	    throw new BricksParseException(usage());
	}
    }
}

