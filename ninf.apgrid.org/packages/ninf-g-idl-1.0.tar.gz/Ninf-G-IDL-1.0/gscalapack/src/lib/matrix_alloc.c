#include <stdio.h>
#include <stdlib.h>
#include <mpi.h>
#include <assert.h>
#include <string.h>

#define _LOCAL_
#include "gscalapack.h"
#include "gscalapack-scalapack.h"

extern void parse_type(const char*,char*);
extern void gamx2d( char*, void*);

#define VECTOR_ROOM 10
#define MATRIX_ROOM 10

/* MATRIX ALLOCATION, DISTRIBUTION, GATHERING GUIDE                          */
/* Swimmy Software Inc.                                                      */
/*                                                                           */
/* If you want to caluculate those around tri-diagonal matrices and          */
/* band matrices, you must set a process-grid 1D distiributed-type           */
/* (rows=1, colums=p) .                                                      */
/*                                                                           */
/* You can not use block-cyclyc distributions but use over-all distributions */
/* ( So, you have a matrix with column size=n, block size=nb, and process=p  */
/* then, it must be that nb*p >= n )                                         */
/*                                                                           */
/*                                                                           */
/* Matrix Descriptor                                                         */
/* Matrix Descriptor type is a type which decides a matrix as mass or band   */
/*                                                                           */
/* Tri-diagonal matrix:                                                      */
/* Type: D x = B                                                             */
/* D: a tridiagonal matrix with column scattered type descriptor             */
/* x: a vector or a matrix with "row" scattered type descriptor, because     */
/* D is a column spilitted type                                              */
/* B: a mass matrix with "row" scattered type descriptor, because            */
/* D is a column scattered type                                              */
/*                                                                           */
/* band matrix:                                                              */
/* Type: A x = B                                                             */
/* A: a band matrix with column scattered type descriptor                    */
/* x: a vector or a matrix with "row" scattered type descriptor, because     */
/* A is a column spilitted type                                              */
/* B: a mass matrix with "row" scattered type descriptor, because            */
/* A is a column scattered type                                              */
/*                                                                           */

/* _work(type, pworkbuffer, size) allocates a processor-local workbuffer. */
void _work( char *type, void **pw, int l)
{
  char utype[TYPESTRLEN];
  int leng=1;
  if (l>0) leng=l;
  if ((mypnum==0)&&(serial==0)) leng=1;
  parse_type(type,utype);
  
  *pw=NULL;
  switch(*utype) {
      case 'f':
          *pw = MALLOC(sizeof(float)*leng);
          assert(*pw);
          break;
      case 'd':
          *pw = MALLOC(sizeof(double)*leng);
          assert(*pw);
          break;
      case 'c':
          *pw = MALLOC(sizeof(scomplex)*leng);
          assert(*pw);
          break;
      case 'z':
          *pw = MALLOC(sizeof(dcomplex)*leng);
          assert(*pw);
          break;
      case 'i':
          *pw = MALLOC(sizeof(int)*leng);
          assert(*pw);
          break;
      default:
          assert(0);
          break;
  }    
} /* end of _work */


/* _ipiv(pipiv, size) allocates a processor-local ipivbuffer. */
void _ipiv(int **i, int l)
{
    int leng;
    
    if (l>0) leng=l;
    if ((mypnum==0)&&(serial==0)) leng=1;
    *i = NULL;
    *i = MALLOC( sizeof(int)*leng);
    assert(*i);
}

/* _matric_alloc( type, ROW, COL, globalp, global_desc, localp, local_desc, */
/* second_dimension, leading_dimension, info) allocates a local memory for */
/* a general matrix */
void _matrix_alloc(
		   const char *type,
		   int m,
		   int n,
		   void *global,
		   int *desc_g,
		   void **plocal,
		   int *desc_l,
		   int seclda,
		   int maxlda,
		   int *plinfo
)
{

  if ((mypnum==0)&&(serial==1)) {
    Cdescinit( desc_g, m, n,  m,  n, 0, 0, seq_ctxt, m, plinfo );
    Cdescinit( desc_l, m, n,  m,  n, 0, 0, seq_ctxt, m, plinfo );
    *plocal=global;
    return;
  }


  if( mypnum == 0 ) {
    Cdescinit( desc_g, m, n,  m,  n, 0, 0, seq_ctxt,      m, plinfo );
    Cdescinit( desc_l, m, n, rbloc, cbloc, 0, 0,       -1, maxlda, plinfo );
  } else {     /* mypnum !=0 */
    Cdescinit( desc_g, m, n,     m,     n, 0, 0,        -1,      m, plinfo );
    Cdescinit( desc_l, m, n, rbloc, cbloc, 0, 0, para_ctxt, maxlda, plinfo );
    
    /* Allocate memory to local arrays */
    *plocal = NULL;
    *plocal =  MALLOC( SIZEOF(type)*(maxlda*seclda+MATRIX_ROOM) );
    assert(*plocal);
  } // if (mypnum !=0)

} /* end of _matrix_alloc */

/* _matrix_aloc1d( vartype, ROW, COL, globalp, global_desc, localp, local_desc */
/* second_dim, leading_dim, info) allocates a general matrix, when routines for band matrix are called. */
/* When band-matrices are used, we must use a block-over distribution and not */
/* block-cyclic distribution. */
/* This law affects RHS and so, RHS must be also distributed in a differnt */
/* manner from a usual case. */
/**/
void _matrix_alloc1d(
		     const char *type,
		     int m,
		     int n,
		     void *global,
		     int *desc_g,
		     void **plocal,
		     int *desc_l,
		     int seclda,
		     int maxlda,
		     int *plinfo
)
{
#define RHS_MAJOR 'r'

  if ((mypnum==0)&&(serial==1)) {
    Cdescinit( desc_g+DESCLEN_0, m, n,  m,  n, 0, 0, seq_ctxt, m, plinfo );
    Cbanddescinit( RHS_MAJOR, desc_g, m, m, 0, seq_ctxt, m, plinfo );
    Cdescinit( desc_l+DESCLEN_0, m, n,  m,  n, 0, 0, seq_ctxt, m, plinfo );
    Cbanddescinit( RHS_MAJOR, desc_l, m, m, 0, seq_ctxt, m, plinfo );
    *plocal=global;
    return;
  }

  if( mypnum == 0 ) {
      Cdescinit( desc_g+DESCLEN_0, m, n,  m,  n, 0, 0,        seq_ctxt,      m, plinfo );
      Cdescinit( desc_l+DESCLEN_0, m, n,  blocsize, n, 0, 0,        -1, maxlda, plinfo );  /* splitted by rows */
      Cbanddescinit( RHS_MAJOR, desc_g, m,        m, 0, seq_ctxt, m,      plinfo );
      Cbanddescinit( RHS_MAJOR, desc_l, m, blocsize, 0,       -1, maxlda, plinfo );
  } else {    /* mypnum != 0 */
      maxlda=blocsize;
      Cdescinit( desc_g+DESCLEN_0, m, n,        m,  n, 0, 0,        -1,      m, plinfo );
      Cdescinit( desc_l+DESCLEN_0, m, n,  blocsize, n, 0, 0, para_ctxt1d, maxlda, plinfo );
      Cbanddescinit( RHS_MAJOR, desc_g, m,        m, 0,        -1,      m, plinfo );
      Cbanddescinit( RHS_MAJOR, desc_l, m, blocsize, 0, para_ctxt, maxlda, plinfo );

          /* Allocate memory to local arrays */
      *plocal=NULL;
      *plocal =  MALLOC( SIZEOF(type)*(maxlda*seclda+MATRIX_ROOM) );
      assert(*plocal);
  }

} /* end of _matrix_alloc1d */



/* tdmatrix_alloc allocates local memory for a tridiagonal matrix. */
void _tdmatrix_alloc(
		     const char *type1,
		     const char *type2,
		     const char *type3,
		     int n,
		     void *global_dl,
		     void *global_d,
		     void *global_du,
		     int *desc_g,
		     void **plocaldl,
		     void **plocald,
		     void **plocaldu,
		     int *desc_l,
		     int *plinfo
)
{
#define TD_MAJOR 'c'
  const int maxld=2+10; /* tri-diagonal matrix always need to set maxld 2+10 */

  int alloc_size;

  if ((mypnum==0)&&(serial==1)) {
      Cbanddescinit( TD_MAJOR, desc_g, n, n, 0, seq_ctxt, maxld, plinfo );
      Cbanddescinit( TD_MAJOR, desc_l, n, n, 0, seq_ctxt, maxld, plinfo );
      *plocaldl = global_dl;
      *plocald  = global_d;
      *plocaldu = global_du;
      return;
  }

  /* if col, */
  alloc_size=maxld*Cnumroc( n+10, blocsize, mypcol, 0, npcol);

  if( mypnum == 0 ) {
      Cbanddescinit( TD_MAJOR, desc_g, n,        n,  0, seq_ctxt, maxld, plinfo);
      Cbanddescinit( TD_MAJOR, desc_l, n, blocsize,  0,       -1, maxld, plinfo );
      return;

  } else {   /* mypnum != 0 */
      Cbanddescinit( TD_MAJOR, desc_g, n,        n, 0,        -1, maxld, plinfo );
      Cbanddescinit( TD_MAJOR, desc_l, n, blocsize, 0, para_ctxt, maxld, plinfo );
      /* Allocate memory to local arrays */

      *plocaldl=NULL;
      *plocaldl =  MALLOC( SIZEOF(type1)*alloc_size );
      assert(*plocaldl);      

      *plocald = NULL;
      *plocald =  MALLOC( SIZEOF(type2)*alloc_size );
      assert(*plocald);

      *plocaldu = NULL;
      *plocaldu = MALLOC( SIZEOF(type3)*alloc_size );
      assert(*plocaldu);    

  } /* end of if (mypnum!=0) */

} /* end of _tdmatrix_alloc */


/* bandmatrix_alloc allocates local memory for a band matrix. */
void _bandmatrix_alloc(
		const char *type,
		int n,
		int bwl,
		int bwu,
		void *global,
		int *desc_g,
		void **plocal,
		int *desc_l,
		int ld,
		int pivot,
		int *plinfo
)
{
#define BAND_MAJOR 'c'
  int alloc_size;
  int maxld;

  maxld=ld;

  if ((mypnum==0)&&(serial==1)) {
      Cbanddescinit( BAND_MAJOR , desc_g, n, n, 0, seq_ctxt, maxld, plinfo );
      Cbanddescinit( BAND_MAJOR , desc_l, n, n, 0, seq_ctxt, maxld, plinfo );
      *plocal = global;
      return;
  }

  if (pivot!=0) {
      alloc_size=maxld*Cnumroc( n+10, blocsize, mypcol, 0, npcol);
  } else {
      alloc_size=maxld*Cnumroc( n+10, blocsize, mypcol, 0, npcol);
  }

  if( mypnum == 0 ) {
    Cbanddescinit( BAND_MAJOR, desc_g, n,        n,  0, seq_ctxt, maxld, plinfo );
    Cbanddescinit( BAND_MAJOR, desc_l, n, blocsize,  0,       -1, maxld, plinfo );
  } else {    /* mypnum != 0 */
    Cbanddescinit( BAND_MAJOR, desc_g, n, n       , 0,        -1, maxld, plinfo );
    Cbanddescinit( BAND_MAJOR, desc_l, n, blocsize, 0, para_ctxt, maxld, plinfo );
    /* Allocate memory to local arrays */
    *plocal = NULL;
    *plocal =  MALLOC( SIZEOF(type)*alloc_size );
    assert(*plocal);
  } /* end of (mypnum!=0) */
} /* end of _bandmatrix_alloc */



void _vector_alloc(
		   char *rowcol,
		   const char *type,
		   int size,
		   void *global,
		   void **plocal
		   )
{
  int blocsize=1;
  int max;

    if ((mypnum==0)&&(serial==1)) {
        *plocal = global;
        return;
    }

    *plocal = NULL;
    if (mypnum==0) return;
    
    if (*rowcol=='r') {
        blocsize=rbloc;
        max=Cnumroc( size, rbloc, myprow, 0, nprow)+VECTOR_ROOM;
    } else {
        blocsize=cbloc;
        max=Cnumroc( size, cbloc, mypcol, 0, npcol)+VECTOR_ROOM;
    }

    *plocal = MALLOC(SIZEOF(type)*max);
    
} /* end of _vector_alloc */

void _free_matrix(void *loca) {
  if (serial==1) return;
  if (mypnum!=0) free(loca);
}
