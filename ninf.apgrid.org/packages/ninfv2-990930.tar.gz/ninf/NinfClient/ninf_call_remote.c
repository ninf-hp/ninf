/*
 *  $Id: ninf_call_remote.c,v 1.13 1999/04/16 00:49:12 nakada Exp $
 */

#define ERROR_MAIN

#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <stdarg.h>
#ifndef WIN32
#include <sys/errno.h>
#endif
#include "ninf_data_trans.h"
#include "ninf_stub_info.h"
#include "ninf_protocol.h"
#include "ninf_stream.h"
#include "callback.h"
#include "ninf_comm_lib.h"
#include "session.h"
#include "dataflow.h"
#include "ninf_client.h"
#include "ninf_error.h"
char * program_context = "CLIENT";

extern int errno;

int IN_TRANSACTION = FALSE;

connection * ninf_connect(ninf_entry *);

void add_stub_cache(ninf_entry * entry, NINF_STUB_INFO * stub);
NINF_STUB_INFO * search_stub_cache(ninf_entry * entry);

any_t * merge_ninf_args();
void ninf_exec_callback_call(void (* func)(), int start, int params, any_t ninf_args[]);
ninf_entry * new_ninf_entry(char *);

any_t * new_arg(int num);

/* client packet buffer */

NINF_STUB_INFO * new_ninf_stub_info();

NINF_STUB_INFO * Ninf_get_compound(connection * );
NINF_STUB_INFO * Ninf_get_stub_raw(connection *, ninf_entry *);
NINF_STUB_INFO * ninf_exec_get_stub(connection *);
NINF_STUB_INFO * Ninf_receive_stub(connection *);

/* argument work place */


/* 
 * Ninf_call("entry_name",arg1,arg2,...);
 */

/**************************************
                       PUBLIC FUNCTIONS  
		       ****************************************/
/* 
 * 	Ninf_call("entry",arg1,arg2,...) 
 */
Ninf_call(char * ninf_stub_entry, ...)
{
  ninf_session * session;
  va_list ap;
  va_start(ap, ninf_stub_entry);

  if ((session = new_ninf_session_string(ninf_stub_entry)) == NULL)
    return NINF_ERROR;
  return session_do(session, &ap);
}

/*
 *	Ninf_call in Fortran
 *
 *  There are several convensions to link a C library in Fortran.
 */

/*  ninf_call for Fortran: assume pointer even if scalar */
ninf_call(char * ninf_stub_entry, ...)
{
  ninf_session * session;
  va_list ap;
  va_start(ap, ninf_stub_entry);

  if ((session = new_ninf_session_string(ninf_stub_entry)) == NULL)
    return NINF_ERROR;
  session->isFortran = TRUE; /* fortran mode */
  return session_do(session, &ap);
}

ninf_call_(char * ninf_stub_entry, ...)
{
  ninf_session * session;
  va_list ap;
  va_start(ap, ninf_stub_entry);

  if ((session = new_ninf_session_string(ninf_stub_entry)) == NULL)
    return NINF_ERROR;
  session->isFortran = TRUE; /* fortran mode */
  return session_do(session, &ap);
}

ninf_call__(char * ninf_stub_entry, ...)
{
  ninf_session * session;
  va_list ap;
  va_start(ap, ninf_stub_entry);

  if ((session = new_ninf_session_string(ninf_stub_entry)) == NULL)
    return NINF_ERROR;
  session->isFortran = TRUE; /* fortran mode */
  return session_do(session, &ap);
}

NINF_CALL(char * ninf_stub_entry, ...)
{
  ninf_session * session;
  va_list ap;
  va_start(ap, ninf_stub_entry);

  if ((session = new_ninf_session_string(ninf_stub_entry)) == NULL)
    return NINF_ERROR;
  session->isFortran = TRUE; /* fortran mode */
  return session_do(session, &ap);
}

/*
 *	Asynchronous (nonblocking) Ninf_call
 */

Ninf_call_async(char * ninf_stub_entry, ...){
  ninf_session * session;
  va_list ap;
  va_start(ap, ninf_stub_entry);

  if ((session = new_ninf_session_string(ninf_stub_entry)) == NULL)
    return NINF_ERROR;
  session->synchronous = FALSE; /* async mode */
  return session_do(session, &ap);
}

/* 
 * Ninf_call_v("entry", any_t a[]) 
 */
Ninf_call_v(char * ninf_stub_entry, any_t a[]){
  ninf_session * session;
  if ((session = new_ninf_session_string(ninf_stub_entry)) == NULL)
    return NINF_ERROR;
  return session_do_v(session, a);
}

/* 
 * Ninf_call_v_async("entry", any_t a[]) 
 */
Ninf_call_v_async(char * ninf_stub_entry, any_t a[]){
  ninf_session * session;
  if ((session = new_ninf_session_string(ninf_stub_entry)) == NULL)
    return NINF_ERROR;
  session->synchronous = FALSE; /* async mode */
  return session_do_v(session, a);
}

/* 
 * Ninf_get_stub("entry", int types [], NINF_STUB_INFO ** return_stub_buffer_p) 
 */
int Ninf_get_stub(char * ninf_stub_entry, int types[], NINF_STUB_INFO ** buffer_p){
  ninf_session * session;
  if ((session = new_ninf_session_string(ninf_stub_entry)) == NULL)
    return NINF_ERROR;

  set_types(session->stub_info, types);
  *buffer_p = session->stub_info;
  session_close(session);

/*  destruct_ninf_session(session); */
  /*  return ((NINF_STUB_INFO *)(*buffer_p))->nparam; */
  return NINF_OK;
}

/* 
 * Ninf_call_body(stub_info,  ....) 
 */
Ninf_call_body(NINF_STUB_INFO * stub_info, ...)
{
  ninf_session * session;
  va_list ap;
  va_start(ap, stub_info);

  if ((session = new_ninf_session_stub(stub_info)) == NULL)
    return NINF_ERROR;
  return session_do(session, &ap);
}
/* 
 * Ninf_call_body_async(stub_info,  ....) 
 */
Ninf_call_body_async(NINF_STUB_INFO * stub_info, ...)
{
  ninf_session * session;
  va_list ap;
  va_start(ap, stub_info);
  if ((session = new_ninf_session_stub(stub_info)) == NULL)
    return NINF_ERROR;
  session->synchronous = FALSE;
  return session_do(session, &ap);
}

/* 
 * Ninf_call_body_v(stub_info, any_t a[]) 
 */
Ninf_call_body_v(NINF_STUB_INFO * stub_info, any_t a[])
{
  ninf_session * session;
  debug_log("call_body_v %p\n", stub_info->entry);
  if ((session = new_ninf_session_stub(stub_info)) == NULL)
    return NINF_ERROR;
  debug_log("got_session\n");
  return session_do_v(session, a);
}
/* 
 * Ninf_call_body_v_async(stub_info, any_t a[]) 
 */
Ninf_call_body_v_async(NINF_STUB_INFO * stub_info, any_t a[])
{
  ninf_session * session;
  if ((session = new_ninf_session_stub(stub_info)) == NULL)
    return NINF_ERROR;
  session->synchronous = FALSE;
  return session_do_v(session, a);
}

/********* CIM MAIN FUNCTION  **********/

int Ninf_cim_main(char * ninf_stub_entry, obj_handler * hp){
  ninf_session * session;

  if ((session = new_ninf_session_string(ninf_stub_entry)) == NULL)
    return NINF_ERROR;
  return session_do_cim(session, hp);
}

int Ninf_cim_main_async(char * ninf_stub_entry, obj_handler * hp){
  ninf_session * session;

  if ((session = new_ninf_session_string(ninf_stub_entry)) == NULL)
    return NINF_ERROR;
  session->synchronous = FALSE;
  return session_do_cim(session, hp);
}


/* 
 * 	Ninf_call_exec("stub_program",arg1,arg2,...) 
 */
Ninf_call_exec(char *ninf_stub_program, ...)
{
  va_list ap;
  NINF_STUB_INFO  * stub_info;
  struct callback callbacks[MAX_CALLBACK + 1];
  any_t ninf_args[MAX_PARAMS];
  int ack, i;
  connection * server;
  resource * c_resource;
  ninf_session * session;

  if ((server = ninf_connect(new_ninf_entry(NULL))) == NULL)
    return NINF_ERROR;

  ninf_remote_forkexec(server, ninf_stub_program);
  
  if ((stub_info = ninf_exec_get_stub(server)) == NULL)
    return NINF_ERROR;

  c_resource = new_resources(stub_info->nparam);
  va_start(ap, ninf_stub_program);
  ninf_get_arg(&ap, stub_info, ninf_args, callbacks, c_resource);
  va_end(ap);

  /* send arg, receive answer */
  set_trans_header(server->sDT, NINF_PKT_TO_STUB, 0, 0);

  session = new_ninf_session(server, ninf_args, stub_info, callbacks, c_resource);

  if ((ack = ninf_send_args(session)) != NINF_OK)
    return(ack);  /* send arg */
  ack = ninf_recv_or_callback(session);

  ninf_remote_kill(server);
  return(ack);
}


/******************* ERROR DIAG ROUTINES *******************/

void Ninf_set_error_string(char *str){
  ninf_set_error_string(str);
}

char * Ninf_perror_string(){
  if (ninf_error_user_string != NULL)
    return ninf_error_user_string;
  return ninf_error_string[ninf_error_code];
}

void Ninf_perror(char * str)
{
  fprintf(stderr, "%s %s\n", str, Ninf_perror_string());
}

void Ninf_perror_fp(FILE * fp, char * str)
{
  fprintf(fp, "%s %s\n", str, Ninf_perror_string());
}

char * Ninf_perror_string_id(int session_num){
  int code;
  exec_info * info;
  if (ninf_error_user_string != NULL)
    return ninf_error_user_string;

  if ((info = Ninf_get_info(session_num)) == NULL)
    code = NINF_ERROR_CANTFINDSESSION;
  else 
    code = info->error_no;
  return ninf_error_string[code];
}

void Ninf_perror_id(int id, char * str){
  fprintf(stderr, "%s %s\n", str, Ninf_perror_string_id(id));
}

void Ninf_perror_id_fp(FILE * fp, int id, char * str)
{
  fprintf(fp, "%s %s\n", str, Ninf_perror_string_id(id));
}


/************************************
                      PRIVATE FUNCTIONS  
                      **************************************/

NINF_STUB_INFO * Ninf_get_stub_raw(connection * con, ninf_entry * entry)
{
  NINF_STUB_INFO * tmp;
  trans_string(con->sDT, &(entry->entry), NINF_MAX_NAME_LEN);
  trans_flush(con->sDT, NINF_PKT_REQ_STUB_INFO,0,0);
  tmp = Ninf_receive_stub(con);
  if (tmp != NULL){
    tmp->entry = entry;
    add_stub_cache(entry, tmp);
  }
  return tmp;
}  

NINF_STUB_INFO * Ninf_get_stub_by_index(int index)
{
  connection * con;
  NINF_STUB_INFO * stub;
  if ((con = ninf_connect(new_ninf_entry(NULL))) == NULL)
    return NULL;
  trans_flush(con->sDT, NINF_PKT_REQ_STUB_BY_INDEX,index,0);
  stub = Ninf_receive_stub(con);
  ninf_disconnect(con); 
  return stub;
}  


/*********************************************
     get indexes of matched stub  for Ninf_Q
     returns  -1: error    -2: overflow          
*********************************************/
int get_indexes_by_keyword(char * keyword, int indexes[], int option, int max)
{
  int check, i, tmp, code;
  connection * server;
  
  /* send request*/
  if ((server = ninf_connect(new_ninf_entry(NULL))) == NULL)
    return NINF_ERROR;

  trans_string(server->sDT, &keyword, NINF_MAX_NAME_LEN);
  trans_flush(server->sDT, NINF_PKT_REQ_STUB_INDEX_LIST,0,option);

  /* receive */

  code = trans_getPacket(server->rDT);
  if(code != NINF_PKT_RPY_STUB_INDEX_LIST) return(NINF_ERROR);
  check = NINF_PKT_ARG1(&(server->rDT->decoded));

  if (check < max && check >= 0){
    for (i = 0; i < check; i++){
      if(!trans_int(server->rDT,&tmp)) return(-1);
      indexes[i] = tmp;
    }
    return check;
  } else {
    for (i = 0; i < check; i++)
      if(!trans_int(server->rDT,&tmp)) return(-1);
    return  -2;
  }
}

NINF_STUB_INFO * ninf_exec_get_stub(connection * server)
{
  int ack;
  /* send request */
  NINF_STUB_INFO * tmp_stub_info;

  if(!trans_request(server->sDT,NINF_REQ_STUB_INFO)) return NULL;
  trans_flush(server->sDT, NINF_PKT_TO_STUB, 0, 0);
  
  tmp_stub_info = new_ninf_stub_info();
  /* get result */
  if(!trans_int(server->rDT,&ack)) return NULL;
  else if(ack != NINF_ACK_OK) return NULL;
  trans_stub_info(server->rDT, tmp_stub_info, TRUE);
  return tmp_stub_info;
}


int Ninf_wait_all(){
  return ninf_wait_all();
}

int Ninf_wait_and(int * id_list, int count){
  return ninf_wait_and(id_list, count);
}

int Ninf_wait_or(int * id_list, int count){
  return ninf_wait_or(id_list, count);
}

id_set * ninf_wait_and_set(id_set * set);
id_set * ninf_wait_or_set(id_set * set);

id_set * Ninf_wait_and_set(id_set * set){
  return ninf_wait_and_set(set);
}
id_set * Ninf_wait_or_set(id_set * set){
  return ninf_wait_or_set(set);
}


int Ninf_session_probe(int id){
  return !session_is_done(id);
}

int Ninf_session_cancel(int id){
  return session_kill(id);
}

int Ninf_sync(int session_num){
  ninf_session * session;
  if ((session = find_all_session(session_num)) == NULL){
    ninf_error_code = NINF_ERROR_CANTFINDSESSION;
    return NINF_ERROR;
  }
  return finish_session(session);
}

int Ninf_wait(int session_num){
  return Ninf_sync(session_num);
}


#ifdef DUMP_TIME
Ninf_set_skip_size(size)
int size;
{
  int code;
  connection * server;
  if ((server = ninf_connect(new_ninf_entry(NULL))) == NULL)
    return NINF_ERROR;
  trans_flush(server->sDT, NINF_PKT_SET_SKIP_TIME,size,0);
  code = trans_getPacket(server->rDT);
  if(code != NINF_PKT_ACK_SKIP_TIME) return(NINF_ERROR);
}
#endif 

/***********************************
      Transaction Functions 
 ***********************************/
Ninf_transaction_begin(){
  if (IN_TRANSACTION){
    ninf_error("Nested check-in occurred\n");
  } else {
    IN_TRANSACTION = TRUE;
    init_dataflow();
  }
}
Ninf_transaction_end(){
  if (!IN_TRANSACTION){
    ninf_error("Check-out occurred outside transaction\n");
    return NINF_ERROR;
  } else {
    ninf_session * session = new_ninf_session_transaction();
    IN_TRANSACTION = FALSE;
    return session_do_v(session, merge_ninf_args());
  }
}

Ninf_check_in()
{ 
  return Ninf_transaction_begin();
}
Ninf_check_out()
{ 
  return Ninf_transaction_end();
}

/*************   **************/

exec_info *  Ninf_get_info(int session_num){
    ninf_session * session;
    exec_info * e_info;

    session = find_all_session(session_num);
    if (session == NULL)
      return NULL;

    e_info = &(session->e_info);
    return e_info;
}

exec_info *  Ninf_get_last_info(){
    ninf_session * session;
    exec_info * e_info;

    session = get_last_session();
    if (session == NULL)
      return NULL;
    e_info = &(session->e_info);
    return e_info;
}

/** Fortran interface  **/

int
ninf_get_last_timing(timing)
    double timing[4];
{
    exec_info * e_info = Ninf_get_last_info();
    
    if (e_info == NULL)
	return 1;

    timing[0] = e_info->fore_time;
    timing[1] = e_info->exec_time;
    timing[2] = e_info->back_time;
    timing[3] = e_info->client_exec_time;

    return 0;
}

int
ninf_get_last_timing_(timing)
    double timing[4];
{
    return ninf_get_last_timing(timing);
}

int
ninf_get_last_timing__(timing)
    double timing[4];
{
    return ninf_get_last_timing(timing);
}

int
NINF_GET_LAST_TIMING(timing)
    double timing[4];
{
    return ninf_get_last_timing(timing);
}
