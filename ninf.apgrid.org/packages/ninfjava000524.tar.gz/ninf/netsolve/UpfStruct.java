package ninf.netsolve;
public class UpfStruct {
  int lang;
}
