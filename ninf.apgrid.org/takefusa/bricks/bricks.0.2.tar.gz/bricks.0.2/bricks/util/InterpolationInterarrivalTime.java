package bricks.util;
import java.io.*;

public class InterpolationInterarrivalTime extends InterpolationThroughput {

    private double interarrivalTimeOfPackets;
    private double throughput;
    private double packetSize;

    public String getName() {
	return interpolationType + "InterarrivalTime";
    }

    public void init(double throughput, double packetSize) {
	this.throughput = throughput;
	this.packetSize = packetSize;
	this.interarrivalTimeOfPackets = throughput / packetSize;
    }

    public double nextDouble(double currentTime) {
	return 
	    (throughput / interpolation.getPoint(currentTime) - 1) *
	    interarrivalTimeOfPackets;
    }

    public double nextDouble() {
	return 
	    (throughput / interpolation.getPoint() - 1) *
	    interarrivalTimeOfPackets;
    }
}
