package ninf.cproxy;
import ninf.basic.*;
import ninf.basic.NinfErrorException;
import ninf.client.*;
import java.util.Vector;
import java.io.*;

public class StubCallable extends NativeCallable {
  public NinfStub stub;
  ScheduleProvider master;
  static NinfLog dbg = new NinfLog("StubCallable");

  StubCallable(NinfStub stub, int index, ScheduleProvider master){
    this.stub = stub;
    this.index = index;
    this.master = master;
  }
  public StubCallable(NinfStub stub, int index){
    this.stub = stub;
    this.index = index;
  }

  public NinfStub getStub(){
    return stub;
  }

  public StubCallableContext receiveNinfCode(NinfPacketInputStream is) 
  throws NinfException {
    return new StubCallableContext(is);
  }

  public NinfExecInfo callNative(CallContext callContext, int serial,
			      ServerIndex server)  throws NinfException {
    boolean aggregateMode = false;
    NinfServerConnection con;
    dbg.log("native invoking " + stub.module_name + "/" + stub.entry_name);
    if (server != null)
      aggregateMode = true;

    if (server == null){
      try {
	server = master.schedule(stub, callContext, serial);
      } catch (NinfException e){
	throw new NinfErrorException(NinfError.CPROXY_CANNOT_SCHEDULE);
      }
    }
    if (server != null){
      con = server.server.connect();
      NinfExecInfo info = con.callNative(stub, server.index, callContext);
      if (!aggregateMode) master.done(serial);
      return info;
    }
    dbg.log(stub.module_name + "/" + stub.entry_name + ": failed to be scheduled");
    throw new NinfErrorException(NinfError.CANTEXECUTESTUB);
  }

  public Stoppable call(NinfPacket pkt, int serial,
			XDRInputStream is, XDROutputStream os) 
  throws NinfException{
    NinfServerConnection con;
    StubCallableContext context;

    NinfPacketInputStream pis = new NinfPacketInputStream(pkt, is);    
    XDRInputStream dis = new XDRInputStream(pis);

    context = receiveNinfCode(pis);

    CallContext callContext = stub.setupJustScalarBuffers(dis);
    context.modifyBuffers(callContext.buffers);

    ServerIndex server;    
    dbg.log("invoking " + stub.module_name + "/" + stub.entry_name);
    try {
      server = master.schedule(stub, callContext, serial);
    } catch (NinfException e){
      throw new NinfErrorException(NinfError.CPROXY_CANNOT_SCHEDULE);
    }

    if (server != null){
      con = server.server.connect();
      con.startForwardWithScalar(stub, server.index, callContext, 
				 pis.getRestPacket(), is, os);
      return con;
    }
    dbg.log(stub.module_name + "/" + stub.entry_name + ": failed to be scheduled");
    NinfPacket.getErrorPacket(NinfError.CANTEXECUTESTUB).write(os);
    try {
      os.close();
    } catch (java.io.IOException e) {}
    return null;
  }

}
