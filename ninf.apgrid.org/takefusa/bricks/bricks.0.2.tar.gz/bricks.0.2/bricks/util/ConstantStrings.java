package bricks.util;

public class ConstantStrings extends Strings implements SubComponent {

    protected String string;

    public ConstantStrings(String string) {
	this.string = string;
    }

    public String getName() {
	return "ConstantStrings";
    }

    public String nextString() {
	return string;
    }
}
