/*
 *  stub generation
 *
 *  $Id: ninf_gen_stub.c,v 1.19 2001/11/01 04:39:46 tatebe Exp $
 */

#include "ninf_gen.h"
#ifndef COMPILER 
#define COMPILER "cc"
#endif
#define DEFAULT_MAKEFILE_NAME "NINF.mak"

#include <string.h>
#include <ctype.h>

#define FORTRAN "fortran"

#define GET_VAL_STRING(i) value_type_string[(i) + 1]
static char * value_type_string[] = {
  "VALUE_ERROR",
  "VALUE_NONE",
  "VALUE_CONST",
  "VALUE_IN_ARG",
  "VALUE_BY_EXPR",
  "VALUE_OP",
  "VALUE_END_OF_OP",
  "VALUE_IN_HEADER",
};

#define GET_MODE_STRING(i) mode_type_string[(i)]
static char * mode_type_string[] = {
  "MODE_NONE",
  "MODE_IN",
  "MODE_OUT",
  "MODE_INOUT",
  "MODE_WORK",
  "MODE_DUMMY",
  "MODE_DUMMY",
  "MODE_DUMMY",
  "MODE_CALL_BACK_FUNC"
};

#define GET_DATA_STRING(i) data_type_string[(i)]
static char * data_type_string[] = {
    "DT_UNDEF",
    "DT_VOID",
    "DT_CHAR",
    "DT_SHORT",
    "DT_INT",
    "DT_LONG",
    "DT_LONGLONG",
    "DT_UNSIGNED_CHAR",
    "DT_UNSIGNED_SHORT",
    "DT_UNSIGNED",
    "DT_UNSIGNED_LONG",
    "DT_UNSIGNED_LONGLONG",
    "DT_FLOAT",
    "DT_DOUBLE",
    "DT_LONG_DOUBLE",
    "DT_STRING_TYPE",
    "DT_FUNC_TYPE",
    "DT_SCOMPLEX",
    "DT_DCOMPLEX",
    "DT_FILEPOINTER",
    "DT_FILENAME",
    "BASIC_TYPE_END",
};

extern char * current_fortran_format;

/**  function declarations  **/

extern void error(char *fmt, ...);
extern void fatal(char *fmt, ...);

static char *C_type_name();
static int nead_and(char * name, struct stub_gen_entry *ep);
static int nead_and_sub(expr body_expr, DATA_TYPE type, int ndim, enum mode_spec param_inout);
static char *make_function_name(expr body_expr, char * fformat);
static char *get_required_depends(char * required);

/* generate Makefile */
void
generate_stubs_makefile()
{
    FILE *fp;
    char fname[NINF_MAX_NAME_LEN];
    int i,j;
    char *ent_name;

    if(current_module) sprintf(fname,"%s.mak",current_module);
    else strcpy(fname, DEFAULT_MAKEFILE_NAME);
  
    if((fp = fopen(fname,"w")) == NULL)
      {
	  error("%s: cannot create\n",fname);
	  return;
      }
    fprintf(fp,"# This file '%s' was created by %s. Don't edit.\n\n",
	    fname,program);
    
    fprintf(fp, "# Default setting\n\n");
    fprintf(fp, "CC = %s\n", COMPILER);
    fprintf(fp, "NINF_COMPILER = $(CC)\n");
    fprintf(fp, "NINF_LINKER = $(CC)\n\n");

    fprintf(fp, "# Include template\n\n");
    fprintf(fp, "include $(NINF_DIR)/lib/template\n");

    fprintf(fp,"\n# CompileOptions:\n\n");
    for(i = 0; i < n_options; i++)
	fprintf(fp,"%s\n",compile_options[i]);

    fprintf(fp,"\n# stub sources\n\nNINF_STUB_SRC =");
    for(i = 0; i < n_stubs; i++)
      fprintf(fp," _stub_%s.c ",SYM_NAME(stubs[i].ent_id));

    fprintf(fp,"\n\n# stub programs\n\nNINF_STUB_PROGRAM =");
    for(i = 0; i < n_stubs; i++)
	  fprintf(fp," _stub_%s",SYM_NAME(stubs[i].ent_id));

    fprintf(fp,"\n\nall: $(NINF_STUB_PROGRAM)\n\n");

    for(i = 0; i < n_stubs; i++){
      ent_name =  SYM_NAME(stubs[i].ent_id);
      fprintf(fp,"_stub_%s.o: _stub_%s.c\n\t$(NINF_COMPILER) $(CFLAGS) $(NINF_CFLAGS)  -c _stub_%s.c\n",
	      ent_name, ent_name, ent_name);
      fprintf(fp,"_stub_%s: _stub_%s.o %s\n\t$(NINF_LINKER) $(CFLAGS)  -o _stub_%s _stub_%s.o $(LDFLAGS) $(NINF_STUB_LDFLAGS) %s $(LIBS)",
	      ent_name, ent_name,
	      get_required_depends(stubs[i].required),
	      ent_name, ent_name,
	      (stubs[i].required == NULL) ? "": stubs[i].required);
      for(j = 0; j < n_libs; j++)
	fprintf(fp," %s",libs[j]);

      fprintf(fp,"\n\n");
    }

    fprintf(fp,"\nclean:\n");
    for(i = 0; i < n_stubs; i++)
	  fprintf(fp, "\trm -f _stub_%s.o _stub_%s.c\n",
		  SYM_NAME(stubs[i].ent_id),
		  SYM_NAME(stubs[i].ent_id));

    fprintf(fp, "\nveryclean: clean\n");
    fprintf(fp, "\trm -f $(NINF_STUB_PROGRAM)\n");
    for(i = 0; i < n_stubs; i++) {
	if(stubs[i].required != NULL) {
	    fprintf(fp,"\trm -f ");
	    fprintf(fp,"%s\n", stubs[i].required);
	}
    }
    fprintf(fp, "\n");

    fprintf(fp,"\n# END OF Makefile\n");

    fclose(fp);
}

void
ninf_expression_print(FILE * fp, NINF_EXPRESSION * exp)
{
  int i;
  fprintf(fp, "\t\t\t{\n");
  fprintf(fp, "\t\t\t  {");    
  for (i = 0; i < NINF_EXPRESSION_LENGTH; i++)
    fprintf(fp, "%s,", GET_VAL_STRING(exp->type[i]));
  fprintf(fp, "},\n");  
  fprintf(fp, "\t\t\t  {");    
  for (i = 0; i < NINF_EXPRESSION_LENGTH; i++)
    fprintf(fp, "%d,", exp->val[i]);
  fprintf(fp, "}\n");  
  fprintf(fp, "\t\t\t},\n");
}

void
generate_stub_param_desc(FILE * fp, struct stub_gen_entry * ep)
{
  struct param_gen_desc *dp;
  int i,j;

  fprintf(fp,"struct ninf_param_desc param_desc[] = {\n");
  for (i = 0; i < ep->nparam; i++){
    dp = &ep->params[i];
    fprintf(fp,"\t{ %s, %s, %d,",GET_DATA_STRING(dp->param_type),
	    GET_MODE_STRING(dp->param_inout),dp->ndim);
    if (dp->ndim > 0){
      fprintf(fp,"{\n");
      for (j = 0; j < dp->ndim; j++){
	fprintf(fp,"\t\t{ %s, %d, \n",
		GET_VAL_STRING(dp->dim[j].size_type), dp->dim[j].size);
	ninf_expression_print(fp, &(dp->dim[j].size_exp));
	fprintf(fp,"\t\t  %s, %d, \n",
		GET_VAL_STRING(dp->dim[j].start_type), dp->dim[j].start);
	ninf_expression_print(fp, &(dp->dim[j].start_exp));
	fprintf(fp,"\t\t  %s, %d, \n",
		GET_VAL_STRING(dp->dim[j].end_type), dp->dim[j].end);
	ninf_expression_print(fp, &(dp->dim[j].end_exp));
	fprintf(fp,"\t\t  %s, %d, \n",
		GET_VAL_STRING(dp->dim[j].step_type), dp->dim[j].step);
	ninf_expression_print(fp, &(dp->dim[j].step_exp));
	fprintf(fp,"\t\t},\n");
      }
      fprintf(fp,"\t\t}");
    }
    fprintf(fp,"},\n");
  }
  fprintf(fp,"};\n");
}

void
generate_stub_info_structure(FILE * fp, struct stub_gen_entry * ep, char * ent_name)
{
  int info_type = MAT_STYLE_C;

  if (ep->language != NULL && strcasecmp(ep->language, FORTRAN) == 0)
    info_type = MAT_STYLE_FORTRAN;
  else if (ep->body_expr)
    if (EXPR_ARG1(ep->body_expr) != NULL) 
      if (strcasecmp(EXPR_STR(EXPR_ARG1(ep->body_expr)), FORTRAN) == 0)
	info_type = MAT_STYLE_FORTRAN;
  
  generate_stub_param_desc(fp, ep);
  fprintf(fp,"NINF_STUB_INFO ninf_stub_info = {\n");
  fprintf(fp,"%d,%d,%d,",MAJOR_VERSION, MINOR_VERSION, info_type);
  fprintf(fp,"\t\"%s\",\"%s\",%d,\n",
	  current_module == NULL ? "": current_module,
	  ent_name,ep->nparam);
  fprintf(fp, "param_desc, \n");
  fprintf(fp, "\t%d, \n", ep->order_type);
  ninf_expression_print(fp, &(ep->order));
  fprintf(fp, "\tstub_description, \n");
  fprintf(fp, "\t%d, /* boolean: specify server side shrink */\n", ep->shrink);
  fprintf(fp, "\t0, 0, NULL, /* dummy: time, stub_index, entry */\n");
  fprintf(fp, "\t%d\n", ep->backend);
  fprintf(fp,"};\n\n");
}

void
generate_callback_proxy_sub(FILE * fp, struct stub_gen_entry * ep, int start, int end){
  int i;
  struct param_gen_desc *dp;


  fprintf(fp, "\n%s(", SYM_NAME(ep->params[start].param_id));

  i = start + 1;
  for (;;){
    dp = &ep->params[i];
    fprintf(fp, "%s %s%s", C_type_name(dp->param_type),
	    (dp->ndim > 0) ? "* ":"",
	    SYM_NAME(dp->param_id));
    i++;
    if (!(i <= end)) break;
    fprintf(fp, ", ");
  }  
  fprintf(fp, ")\n{\n\tNinf_CallBack(%d, ", start);
  i = start + 1;
  for (;;){
    dp = &ep->params[i];
    fprintf(fp, "%s",  SYM_NAME(dp->param_id));
    i++;
    if (!(i <= end)) break;
    fprintf(fp, ", ");
  }  
  fprintf(fp, ");\n}");  

}

void
generate_callback_proxy(FILE * fp, struct stub_gen_entry * ep)
{
  struct param_gen_desc *dp;
  int last_start = -1;
  int i;

  /* generate callback proxy */
  fprintf(fp,"\n/* Callback proxy */\n");
  
  for (i = 0; i < ep->nparam; i++){
    dp = &ep->params[i];
    if (dp->param_type == DT_FUNC_TYPE){
      if (last_start > 0)
	generate_callback_proxy_sub(fp, ep, last_start, i-1);
      last_start = i;
    }
  }
  if (last_start > 0)
    generate_callback_proxy_sub(fp, ep, last_start, i-1);
}

void
generate_stub_body(struct stub_gen_entry *ep, FILE * fp){
    list lp;

    if (ep->body_expr){
      /* generate body */
      char * function_name;
      function_name = make_function_name(ep->body_expr, current_fortran_format);
      fprintf(fp,"\t\t%s(", function_name);


      FOR_ITEMS_IN_LIST(lp,EXPR_ARG3(ep->body_expr)){
	char * tmp = SYM_NAME(EXPR_SYM(LIST_ITEM(lp)));
	fprintf(fp,"%s%s", nead_and(tmp, ep)?"&":"", tmp);
	if(LIST_NEXT(lp) != NULL) 
	  fprintf(fp,",");
      }
      fprintf(fp,");\n");
    } else 
      fprintf(fp,"%s\n",ep->body);
}

void
generate_stub_program(struct stub_gen_entry *ep)
{
    FILE *fp;
    char fname[NINF_MAX_NAME_LEN];
    char *ent_name;
    struct param_gen_desc *dp;
    int i;
    
    ent_name = SYM_NAME(ep->ent_id);
    sprintf(fname,"_stub_%s.c",ent_name);
    if ((fp = fopen(fname,"w")) == NULL){
      error("%s: cannot create\n");
      return;
    }
    fprintf(fp,"/* %s : generated by %s, don't edit. */\n",
	    fname,program);
    if (ep->backend == BACKEND_MPI
	|| ep->backend == BACKEND_BLACS)
      fprintf(fp,"#include <mpi.h>\n");
    fprintf(fp,"#include \"ninf_stub_lib.h\"\n\n");

    /* output description */
    if (ep->description) {
      fprintf(fp,"/* DESCRIPTION:\n%s\n*/\n\n",ep->description);
      fprintf(fp,"static char stub_description[] = \"%s\";\n", ep->description);
    } else {
      fprintf(fp,"static char stub_description[] = \"\";\n");
      
    }

    /* generate stub structure */
    generate_stub_info_structure(fp, ep, ent_name);
    
    /* geneate globals */
    fprintf(fp,"/* Globals */\n");
    for (i = 0; i < n_globals; i++) fprintf(fp,"%s\n",globals[i]);

    generate_callback_proxy(fp, ep);

    /* generate main program */
    fprintf(fp,"\n/* Stub Main program */\nmain(int argc, char ** argv){\n");
    /* declare parameters */
    for (i = 0; i < ep->nparam; i++){
      dp = &ep->params[i];
      if (dp->param_type == DT_FUNC_TYPE)
	break;
      fprintf(fp, "\t%s %s%s;\n", C_type_name(dp->param_type),
	      (dp->ndim > 0) ? "*":"",
	      SYM_NAME(dp->param_id));
    }
    fprintf(fp, "\tint tmp;\n");

    /**  Backend-dependent initialization part  **/

    switch(ep->backend) {
    case BACKEND_MPI:	/* using MPI */
	fprintf(fp, "\tint rank;\n\n");
	fprintf(fp, "\tMPI_Init(&argc, &argv);\n");
	fprintf(fp, "\tMPI_Comm_rank(MPI_COMM_WORLD, &rank);\n\n");
	fprintf(fp, "if (rank == 0){\n");
	break;
    case BACKEND_BLACS:
	fprintf(fp, "\tint ictxt, nprocs, rank;\n\n");
	fprintf(fp, "\tMPI_Init(&argc, &argv);\n");
	fprintf(fp, "\tCblacs_pinfo( &rank, &nprocs);\n");
	fprintf(fp, "\tCblacs_get( -1, 0, &ictxt);\n\n");
	fprintf(fp, "if (rank == 0){\n");
	break;
    default:
	break;
    }

    fprintf(fp,"\tNinf_stub_INIT(argc,argv);\n");
    fprintf(fp,"\twhile(1){\n");
    fprintf(fp,"\t\ttmp = Ninf_stub_REQ();\n");    

    /* using MPI */
    if (ep->backend == BACKEND_MPI
	|| ep->backend == BACKEND_BLACS){
      fprintf(fp,"\t\tMPI_Bcast(&tmp, 1, MPI_INT, 0, MPI_COMM_WORLD);\n");    
    }

    fprintf(fp,"\t\tif (!tmp)break;\n");
    /* input and setup working area */
    for (i = 0; i < ep->nparam; i++){
      dp = &ep->params[i];
      if (dp->param_type == DT_FUNC_TYPE)
	break;

      fprintf(fp,"\t\tNinf_stub_SET_ARG(&%s,%d);\n",
	      SYM_NAME(dp->param_id),i);
    }

    /* begin matsubara writes */
    fprintf(fp,"\t\tNinf_stub_BEGIN();\n");
    /* end matsubara writes */

    /* body */
    generate_stub_body(ep, fp);
    
    fprintf(fp,"\t\ttmp = Ninf_stub_END();\n");
    if (ep->backend == BACKEND_MPI
	|| ep->backend == BACKEND_BLACS){
      fprintf(fp,"\t\tMPI_Bcast(&tmp, 1, MPI_INT, 0, MPI_COMM_WORLD);\n");    
    }
    fprintf(fp,"\t\tif (!tmp) break;\n\t}\n");
    fprintf(fp,"\tNinf_stub_EXIT();\n");

    /* using MPI */
    if (ep->backend == BACKEND_MPI
	|| ep->backend == BACKEND_BLACS){
      fprintf(fp,"} else {\n");
      fprintf(fp,"\twhile (1){\n");
      fprintf(fp,"\t\tMPI_Bcast(&tmp, 1, MPI_INT, 0, MPI_COMM_WORLD);\n");
      fprintf(fp,"\t\tif (!tmp) break;\n");
      generate_stub_body(ep, fp);
      fprintf(fp,"\t\tMPI_Bcast(&tmp, 1, MPI_INT, 0, MPI_COMM_WORLD);\n");
      fprintf(fp,"\t\tif (!tmp) break;\n");
      fprintf(fp,"\t}\n");
      fprintf(fp,"}\n\n");
    }

    /**  Backend-dependent finalization part  **/

    switch(ep->backend) {
    case BACKEND_MPI:
	fprintf(fp,"\tMPI_Finalize();\n");
	break;
    case BACKEND_BLACS:
	fprintf(fp, "\tCblacs_gridexit(ictxt);\n");
	fprintf(fp, "\tCblacs_exit();\n");
	break;
    default:
	break;
    }

    fprintf(fp,"}\n/* END OF Stub Main */\n");
    fclose(fp);
}

static char function_name_buffer[100];


char * fortran_format(char * buf, char * fformat, char * fname)
{
  char * answer = buf;
  if (fformat == NULL)
    return fname;
  while (*fformat != '\0'){
    if (*fformat != '%'){
      *buf++ = *fformat++;
      continue;
    } else {
      char * tmp;
      switch (*(++fformat)){
      case 's': 
      case 'S': 
	tmp = fname;
	while (*tmp != '\0')
	  *buf++ = *tmp++;
	break;
      case 'l': 
      case 'L': 
	tmp = fname;
	while (*tmp != '\0'){
	  char tc = *tmp++;
	  *buf++ = toupper(tc);
	}
	break;
      default:
	fprintf(stderr, "unknown fortran format %%%c: ignore\n", *fformat);
      }
      fformat++;
    }   
  }
  *buf = '\0';
  return answer;
}


static char * get_required_depends(char * required){
  static char * NULL_STR = "";
  char * depend, *tmp_required;
  char * tmp;
  if (required == NULL)
    return NULL_STR;
  /** malloc depend */
  tmp_required = strdup(required);
  depend = strdup(required);
  if (tmp_required == NULL || depend == NULL)
    return NULL_STR;
  depend[0] = '\0';
  
  tmp = strtok(tmp_required, "\t ");
  if (tmp != NULL) {
    if (tmp[0] != '-')
      strcat(depend, tmp);
    tmp = strtok(NULL, "\t ");
  }
  while (tmp != NULL){
    if (tmp[0] != '-') {
      strcat(depend, " ");
      strcat(depend, tmp);
    }
    tmp = strtok(NULL, "\t ");
  }
  free(tmp_required);
  return depend;
}

char * make_function_name(expr body_expr, char * fformat)
{
  if (EXPR_ARG1(body_expr) != NULL) 
    if (strcasecmp(EXPR_STR(EXPR_ARG1(body_expr)), FORTRAN) == 0){
      return fortran_format(function_name_buffer, fformat ,
			    SYM_NAME(EXPR_SYM(EXPR_ARG2(body_expr))));
  } 
  return SYM_NAME(EXPR_SYM(EXPR_ARG2(body_expr)));
}

static int
nead_and(char * name, struct stub_gen_entry *ep){
  int i;
  struct param_gen_desc *dp;
  for (i = 0; i < ep->nparam; i++){
    dp = &ep->params[i];
    if (strcmp(SYM_NAME(dp->param_id), name) != 0)
      continue;
    if (dp->param_type == DT_FUNC_TYPE)
      break;
    return nead_and_sub(ep->body_expr,dp->param_type, dp->ndim, dp->param_inout);
  }
  return 0;
}

static int
nead_and_sub(expr body_expr, DATA_TYPE type, int ndim, enum mode_spec param_inout)
{
  if (EXPR_ARG1(body_expr) == NULL) 
    return 0;
  if (strcasecmp(EXPR_STR(EXPR_ARG1(body_expr)), FORTRAN) != 0)
    return 0;
  if (ndim != 0)
    return 0;
  if ((param_inout & MODE_IN) == 0)
    return 0;
  if (type == DT_STRING_TYPE)
      return 0;
  return 1;
}

static char *C_type_name(DATA_TYPE type)
{
  switch (type){
  case DT_VOID: return("void");
  case DT_CHAR: return("char");
  case DT_SHORT: return("short");
  case DT_LONG: return("long");
  case DT_LONGLONG: return("long long");
  case DT_UNSIGNED_CHAR: return("unsigned char");
  case DT_UNSIGNED_SHORT: return("unsigned short");
  case DT_UNSIGNED_LONG: return("unsigned long");
  case DT_UNSIGNED_LONGLONG: return("unsigned long long");
  case DT_FLOAT: return("float");
  case DT_DOUBLE: return("double");
  case DT_STRING_TYPE: return("char *");    
  case DT_UNSIGNED: return("unsigned");
  case DT_INT:  return("int");
  case DT_SCOMPLEX: return("float");
  case DT_DCOMPLEX: return("double");    
  case DT_FILEPOINTER: return("FILE *");    
  case DT_FILENAME: return("char *");    
  default:
    fatal("unknown type name %d\n",type);
    return("unknown");
  }
}



