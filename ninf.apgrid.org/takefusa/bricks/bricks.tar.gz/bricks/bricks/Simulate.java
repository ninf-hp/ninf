/**
 * Bricksf Grid Computing Simulation
 **/

package bricks;
import bricks.util.*;
import java.io.*;
import java.util.*;

public class Simulate {

    private static final String USAGE = 
	"java bricks.Simulate [-times <times> | -fin <the time finished simulation>] [-prefix <prefix of log files>] [-network_log] [-server_log] [-no_monitoring_log] [-info] <configuration file>\n";
//	"java bricks.Simulate [-times <times> | -fin <the time finished simulation>] [-prefix <prefix of log files>] [-network_log] [-server_log] [-no_monitoring_log] [-buffer <buffer size>] [-info] <configuration file>\n";

    public static void main(String[] argv) {

	int numRequestedData = 1;
	double timeFinishedSimulation = -1;

	int bufferSize = -1;
	long start = System.currentTimeMillis();

	boolean networkLog = false;
	boolean serverLog = false;
	boolean monitoringLog = true;
	boolean info = false;
	String prefix = "tmp";

	
	if (argv.length == 0) {
	    System.out.println(USAGE);
	    return;
	}
	int index = 0;
	while (index < argv.length-1) {
	    if (argv[index].equalsIgnoreCase("-times")) {
		numRequestedData = Integer.valueOf(argv[++index]).intValue();

	    } else if (argv[index].equalsIgnoreCase("-fin")) {
		timeFinishedSimulation = 
		    Double.valueOf(argv[++index]).doubleValue();

	    } else if (argv[index].equalsIgnoreCase("-prefix")) {
		prefix = argv[++index];

	    } else if (argv[index].equalsIgnoreCase("-network_log")) {
		networkLog = true;

	    } else if (argv[index].equalsIgnoreCase("-server_log")) {
		serverLog = true;

	    } else if (argv[index].equalsIgnoreCase("-no_monitoring_log")) {
		monitoringLog = false;

	    } else if (argv[index].equalsIgnoreCase("-info")) {
		info = true;

	    } else if (argv[index].equalsIgnoreCase("-buffer")) {
		bufferSize = Integer.valueOf(argv[++index]).intValue();

	    } else {
		System.out.println("The [ " + argv[index] + " ] option is wrong.");
		System.out.println(USAGE);
		return;
	    }
	    index++;
	}

	// initialize simulation
	String fileName = argv[index];
	InputStream isOfSimulationSetFile = 
	    BricksUtil.getInputStream(fileName);
	OutputStream osOfRequestedDataLog = 
	    BricksUtil.getOutputStream(prefix + "_c.log", bufferSize);

	SimulationSet simulationSet = new SimulationSet(osOfRequestedDataLog);

	if (monitoringLog) {
	    simulationSet.setNetworkMonitorLog(
		BricksUtil.getOutputStream(prefix + "_nm.log", bufferSize)
	    );
	    simulationSet.setServerMonitorLog(
		BricksUtil.getOutputStream(prefix + "_sm.log", bufferSize)
	    );
	}

	if (networkLog)
	    simulationSet.setNetworkLog(
		BricksUtil.getOutputStream(prefix + "_n.log", bufferSize)
	    );

	if (serverLog)
	    simulationSet.setServerLog(
		BricksUtil.getOutputStream(prefix + "_s.log", bufferSize)
	    );

	try {
	    simulationSet.init(isOfSimulationSetFile);
	} catch (BricksParseException e) {
	    BricksUtil.abort(e.toString());
	}

	long init = System.currentTimeMillis();

	Session session = new Session(simulationSet);
	session.nextTimeStep();

	while (timeFinishedSimulation < 0.0 ?
	       !session.finish(numRequestedData) :
	       !session.finish(timeFinishedSimulation)) {

	    // debug
	    //Runtime r = Runtime.getRuntime();
	    //System.out.println("Free Memory = " + 
	    //r.freeMemory() + " / " + r.totalMemory());

	    session.step();
	    session.nextTimeStep();
	    // debug
	    /*
	    if (timeFinishedSimulation >= 0.0) {
		SimulationDebug.primaryPrintln(
		    "finish? " + session.finish(timeFinishedSimulation) + 
		    "  current = " + session.getCurrentTime()
		);
	    }
	    */
	}

	if (info) {
	    long end = System.currentTimeMillis();
	    double total = (end - start) * 0.001;
	    double ini = (init - start) * 0.001;
	    System.out.println(fileName + " : Total " + total +
			       "(" + Format.format(ini, 3) + ")[sec], " + 
			       Data.serialNumber + " objects were generated.");
	    Runtime r = Runtime.getRuntime();
	    System.out.println("Free Memory = " + 
			       r.freeMemory() + " / " + r.totalMemory());

	}
    }
}
