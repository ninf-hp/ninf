#define _WRAPPER_
/* $Id: pzgebrd_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define _DISTRIBUTE_1D_
#define DCOMPLEX
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n
static	int worklen(int m, int n) {
	  int ret;
	  int IROFFA, ICOFFA;
	  int IAROW, IACOL, MpA0, NqA0;
	  ret = n*(m+n+1) + n;
	  if NEED_BUFF {
#define NB blocsize
#define IA 1
#define JA 1
#define MYROW myprow
#define NPROW nprow
#define MYCOL mypcol
#define NPCOL npcol
#define NUMROC Cnumroc
#define RSRC_A 0
#define CSRC_A 0
	    IROFFA = MOD( IA-1, NB );
	    ICOFFA = MOD( JA-1, NB );
	    IAROW = INDXG2P( IA, NB, MYROW, RSRC_A, NPROW );
	    IACOL = INDXG2P( JA, NB, MYCOL, CSRC_A, NPCOL );
	    MpA0 = NUMROC( M+IROFFA, NB, MYROW, IAROW, NPROW );
	    NqA0 = NUMROC( N+ICOFFA, NB, MYCOL, IACOL, NPCOL );
	    ret = NB*( MpA0 + NqA0 + 1 ) + NqA0;
	  }
	  return ret;
}

void  pzgebrd_ninf(	 int m,
		 int n,
		 dcomplex global_a[],
		 int lda,
		 double global_d[],
		 double global_e[],
		 dcomplex global_tauq[],
		 dcomplex global_taup[],
		 dcomplex work[],
                 int lwork,
		 int *info
)
/* "pzgebrd reduces a complex general M-by-N distributed matrix A to upper or lower bidiagonal form B by an unitary transformation: Q' * A * P = B. If M >= N, B is upper bidiagonal; if M < N, B is lower bidiagonal." */
/* OPTIONS */
{
  int min_m_n;
	int maxldd;

	int maxlda;
	dcomplex *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];

	double *locd=NULL;
	double *loce=NULL;
	int desctdd[DESCLEN], desc_gtdd[DESCLEN];
        
        dcomplex *loctauq=NULL;
	dcomplex *loctaup=NULL;

	dcomplex *locwork=NULL;
	int llocwork;
        
	int row_loca;
	int col_loca;


	INITIALIZE();

	SCALAR( "int", m);
	SCALAR( "int", n);
	SCALAR("int", lda);
	SCALAR( "int", lwork);

	min_m_n=min(m,n);
	SIZE(min_m_n);

	ROW( a);
	COL( a);
	MAXLDD( maxldd, a );
	maxlda = maxldd;

	MATRIX( "dcomplex", a, ROW_a, COL_a);
	tdMATRIX( "double", e, d, e, min_m_n);

	DISTRIBUTE( "dcomplex", a, ROW_a  , COL_a);
	VECTOR( "c", "dcomplex", tauq, min_m_n);
	VECTOR( "r", "dcomplex", taup, min_m_n);

	llocwork = worklen(m,n);
	llocwork = max(lwork,llocwork);
	WORK(locwork,llocwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pzgebrd)( &m, &n,
                               loca, &one, &one, desca,
                               locd, loce,
                               loctauq, loctaup,
                               locwork, &llocwork, &linfo);

	GATHER( "dcomplex", a, ROW_a  , COL_a);
	tdGATHER( "double", e, d, e, min_m_n);
	vGATHER( "c", "dcomplex", tauq, min_m_n);
	vGATHER( "r", "dcomplex",  taup, min_m_n);

	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
	  *info = linfo;
	} else {
	}

	FREE_MATRIX(a);
	FREE_MATRIX(d);
	FREE_MATRIX(e);
	FREE_VECTOR(taup);
	FREE_VECTOR(tauq);

	FREE(locwork);
}

