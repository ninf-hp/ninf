package bricks.util;
import java.util.*;

public class SerialNumberStringsCreator extends SubComponentCreator {

    public String usage() {
	return "SerialNumberStrings(<int firstNumber>)";
    }

    public SubComponent create(StringTokenizer st) throws BricksParseException{
	try {
	    int firstNumber = 
		Integer.valueOf(st.nextToken(" \t,()")).intValue();
	    return new SerialNumberStrings(firstNumber);

	} catch (NumberFormatException e) {
	    e.printStackTrace();
	    throw new BricksParseException(usage());

	} catch (NoSuchElementException e) {
	    e.printStackTrace();
	    throw new BricksParseException(usage());
	}
    }
}

