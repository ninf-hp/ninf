#define _WRAPPER_
/* $Id: pctrtrs_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define SCOMPLEX
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n
#define ROW_b ldb
#define COL_b nrhs
void  pctrtrs_ninf(	 char uplo,
		 char trans,
		 char diag,
		 int n,
		 int nrhs,
		 scomplex global_a[],
		 int lda,
		 scomplex global_b[],
		 int ldb,
		 int *info
)
/* "pctrtrs solves a triangular system of the form  A* X = B or   A**T * X = B or */
/*  A**H * X = B, where A  is a triangular distributed matrix of order N, and B is an N-by-NRHS distributed matrix." */
/* OPTIONS */
{
extern void FortranCall(pctrtrs)( char*, char*, char*,
				  int*, int*,
				  scomplex*, int*, int*, int*,
				  scomplex*, int*, int*, int*,
				  int*);

	int maxldd;

	int maxlda;
	scomplex *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
	int row_loca, col_loca;

	int maxldb;
	scomplex *locb=NULL;
	int descb[DESCLEN];
	int desc_gb[DESCLEN];
	int row_locb, col_locb;

	INITIALIZE();

	SCALAR( "char", uplo);
	SCALAR( "char", trans);
	SCALAR( "char", diag);
	SCALAR( "int", n);
	SCALAR( "int", nrhs);
	SCALAR( "int", lda);
	SCALAR( "int", ldb);

	ROW( a);
	COL( a);
	ROW( b);
	COL( b);
	MAXLDD( maxldd, a );
	maxlda = maxldd;
	maxldb = maxldd;

	trMATRIX( uplo, "scomplex", a, ROW_a, COL_a);
	trDISTRIBUTE( uplo, "scomplex", a, ROW_a, COL_a);

	MATRIX( "scomplex", b, ROW_b, COL_b);
	DISTRIBUTE( "scomplex", b, ROW_b, COL_b);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pctrtrs)( &uplo, &trans, &diag,
                               &n, &nrhs,
                               loca, &one, &one, desca,
                               locb, &one, &one, descb,
                               &linfo);

	GATHER( "scomplex", b, ROW_b, COL_b);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
		*info = linfo;
	} else {
	}

	FREE_MATRIX(a);
	FREE_MATRIX(b);
}

