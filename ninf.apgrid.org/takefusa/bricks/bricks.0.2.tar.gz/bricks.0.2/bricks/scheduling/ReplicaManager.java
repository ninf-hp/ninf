package bricks.scheduling;
import bricks.util.*;
import bricks.environment.*;
import java.util.*;
import java.io.*;

public abstract class ReplicaManager extends Obj implements SchedulingUnit {

    protected PrintWriter logWriter;
    protected Sequence interEvaluationTime;
    protected String keyOfResourceDB;
    protected ResourceDB resourceDB;
    protected String keyOfServerMonitor;
    protected ServerMonitor serverMonitor;
    protected Random random = new Random();
    protected double overstoredDiskRate;

    // for each ReplicaManager
    Vector replicatings = new Vector(10);

    // implement replication strategies
    //public abstract void processEvent(double currentTime);

    /** Compactness of each Disk at garbage collection. 
	if compactness == 0.5, then disk will be reduced to diskSize * 0.5  */
    protected double compactness = 0.0;

    public ReplicaManager(
	String keyOfResourceDB, String keyOfServerMonitor, double compactness
    ) {
	this.keyOfResourceDB = keyOfResourceDB;
	this.keyOfServerMonitor = keyOfServerMonitor;
	this.interEvaluationTime = new Constant(Double.POSITIVE_INFINITY);
	this.compactness = compactness;
    }

    public ReplicaManager(
	String keyOfResourceDB, String keyOfServerMonitor, 
	Sequence interEvaluationTime, double compactness, 
	double overstoredDiskRate
    ) {
	this.keyOfResourceDB = keyOfResourceDB;
	this.keyOfServerMonitor = keyOfServerMonitor;
	this.interEvaluationTime = interEvaluationTime;
	this.compactness = compactness;
	this.overstoredDiskRate = overstoredDiskRate;
    }

/************************* needed method *************************/
    public String getName() {
	return "ReplicaManager";
    }

    public String toInitString() {
	return getName() + " : " + key + "\n";
    }

    public void init(SimulationSet owner) {
	this.owner = owner;
	this.logWriter = owner.replicaManagerLogWriter;
	this.resourceDB = owner.getResourceDB(keyOfResourceDB);
	this.serverMonitor = owner.getServerMonitor(keyOfServerMonitor);
    }

    public void printLog(String log) {
	if (logWriter != null)
	    logWriter.println(log);
    }

    public void updateNextEvent(double currentTime) {
	nextEventTime =
	    nextEventTime + interEvaluationTime.nextDouble(currentTime);
    }
    
/************************* public method *************************/
    public void finishReplication(double currentTime, ReplicaData replica) {

	printLog(this + " " + currentTime + " " + replica);

	SimulationDebug.println("ReplicaManager.finish(): replica = " + replica);

	Vector target = null;
	Enumeration e = replicatings.elements();
	int index = 0;
	while (e.hasMoreElements()) {
	    target = (Vector)e.nextElement();
	    if (replica.equals(target.firstElement()))
		break;
	    index++;
	}
	target.removeElementAt(0);
	
	SimulationDebug.println("ReplicaManager.finish(): index = " + index + 
			   ", target repliation = " + target + " :removed");
	SimulationDebug.println("ReplicaManager.finish(): replicatings = " + 
				replicatings);

	if (target.size() == 0) { // finish one replication sequence
	    replicatings.removeElementAt(index);

	} else { // next replication
	    replicate(currentTime, index);
	}

    }

    // callee: DataGridScheduler
    public void garbageCollection(
	double currentTime, DataFragment dataFragment
    ) {
	int success = 0;
	int fail = 0;
	int noGC = 0;
	Enumeration e = resourceDB.hosts();
	while (e.hasMoreElements()) {
	    Host host = (Host)e.nextElement();
	    HostInfo info = serverMonitor.getHostInfo(currentTime, host);
	    if (info.use < compactness) {
		noGC++;
	    } else {
		if ((host.getDisk()).makeDiskSpace(currentTime, compactness, dataFragment))
		    success++;
		else
		    fail++;
	    }
	}
	printLog(currentTime + " " + noGC + " " + success + " " + fail + 
		 " triggerdByScheduler");
    }

    /** for PassiveReplicaManager */
    public void replicate(
	double currentTime, Host source, DataFragment fragment
    ) {;}

/************************* protected method *************************/
    protected boolean haveToReplicate(
	Host host, StaticHostInfo staticInfo, HostInfo info, 
	Vector scoresOfSource, Vector scoresOfDestination
    ) {
	return false;
    }

    protected void garbageCollection(double currentTime) {
	int success = 0;
	int fail = 0;
	int noGC = 0;
	Enumeration e = resourceDB.hosts();
	while (e.hasMoreElements()) {
	    Host host = (Host)e.nextElement();
	    HostInfo info = serverMonitor.getHostInfo(currentTime, host);
	    if (info.use < compactness) {
		noGC++;
	    } else {
		if ((host.getDisk()).makeDiskSpace(currentTime, compactness))
		    success++;
		else
		    fail++;
	    }
	}
	printLog(currentTime + " " + noGC + " " + success + " " + fail + 
		 " triggerdByReplicaManagerr");
    }

    protected void replicate(double currentTime, int index) {
	SimulationDebug.println(currentTime + ": index = " + index);
	Vector v = (Vector)replicatings.elementAt(index);
	ReplicaData replica = (ReplicaData)v.firstElement();
	SimulationDebug.println(currentTime + ": replicate " + replica);
	replica.replicate(currentTime);
    }

    protected boolean doneGC(double currentTime) {
	int numOverstoredDisk = 0;

	Enumeration e = resourceDB.hosts();
	while (e.hasMoreElements()) {
	    Host host = (Host)e.nextElement();
	    HostInfo info = serverMonitor.getHostInfo(currentTime, host);

	    // for GC
	    if (info.use / info.diskSize > compactness)
		numOverstoredDisk++;
	}

	if ((double)numOverstoredDisk / (double)resourceDB.numHosts() 
	    > overstoredDiskRate) {
	    garbageCollection(currentTime);
	    return true;
	}
	return false;
    }

    protected void replicate(double currentTime) {
	int numReplicationHosts = 0;
	Vector scoresOfSource = new Vector();
	Vector scoresOfDestination = new Vector();

	Enumeration e = resourceDB.hosts();
	while (e.hasMoreElements()) {
	    Host host = (Host)e.nextElement();
	    HostInfo info = serverMonitor.getHostInfo(currentTime, host);
	    StaticHostInfo staticInfo = resourceDB.getStaticHostInfo(host);

	    // for Replication
	    if (haveToReplicate(host, staticInfo, info, 
				scoresOfSource, scoresOfDestination))
		numReplicationHosts++;
	}

	shuffle(scoresOfDestination);
	HeapSortForReplicaManager.sortByScore(scoresOfSource);
	HeapSortForReplicaManager.sortByScore(scoresOfDestination);
	
	//System.out.println(
	SimulationDebug.println(
	    "numReplicationHosts = " + numReplicationHosts);
	Vector v = new Vector(numReplicationHosts);
	for (int i = 0; i < numReplicationHosts; i++) {
	    Host source = ((Score)scoresOfSource.elementAt(i)).host;
	    DataFragment fragment = 
		serverMonitor.getMostAccessedDataFragment(currentTime, source);

	    // select destination of Replica
	    if (fragment != null) {
		ReplicaData replica = null;
		for (int j = scoresOfDestination.size() - 1; j >= 0; j--) {
		    Score destinationScore = 
			(Score)scoresOfDestination.elementAt(j);
		    if (resourceDB.hasData(destinationScore.host, fragment.id))
			continue;
		    if (!serverMonitor.hasAvailableDisk(
			currentTime, destinationScore.host, fragment.size))
			continue;

		    Host destination = 
			((Score)scoresOfDestination.elementAt(j)).host;
		    scoresOfDestination.remove(j);
		    replica = new ReplicaData(
			owner, source, destination, this, fragment, 
			false, currentTime
		    );
		    //System.out.println(
		    SimulationDebug.println(
			Format.format(currentTime, 3) + ": replicate " + 
			fragment + " from " + source + " to " + destination);
		    break;
		}

		if (replica != null) {
		    v.add(replica);
		    // migrate only 1 replica
		    break; // MODIFY
		}
	    }
	}
	if (v.size() > 0) {
	    replicatings.add(v);
	    replicate(currentTime, replicatings.size() - 1);
	}
    }

    /*
    protected void evaluate(double currentTime) {
	int numReplicationHosts = 0;
	Vector scoresOfSource = new Vector();
	Vector scoresOfDestination = new Vector();

	Enumeration e = resourceDB.hosts();
	while (e.hasMoreElements()) {
	    Host host = (Host)e.nextElement();
	    HostInfo info = serverMonitor.getHostInfo(currentTime, host);
	    StaticHostInfo staticInfo = resourceDB.getStaticHostInfo(host);

	    // for GC
	    if (info.use / info.diskSize > compactness)
		numOverstoredDisk++;

	    // for Replication
	    if (haveToReplicate(host, staticInfo, info, 
				scoresOfSource, scoresOfDestination))
		numReplicationHosts++;
	}

	if ((double)numOverstoredDisk / (double)resourceDB.numHosts() 
	    > overstoredDiskRate) {
	    garbageCollection(currentTime);

	} else {
	    shuffle(scoresOfDestination);
	    HeapSortForReplicaManager.sortByScore(scoresOfSource);
	    HeapSortForReplicaManager.sortByScore(scoresOfDestination);

	    //System.out.println(
	    SimulationDebug.println(
		"numReplicationHosts = " + numReplicationHosts);
	    Vector v = new Vector(numReplicationHosts);
	    for (int i = 0; i < numReplicationHosts; i++) {
		Host source = ((Score)scoresOfSource.elementAt(i)).host;
		DataFragment fragment = 
		    serverMonitor.getMostAccessedDataFragment(
			currentTime, source
		    );

		// select destination of Replica
		if (fragment != null) {
		    ReplicaData replica = null;
		    for (int j = scoresOfDestination.size() - 1; j >= 0; j--) {
			Score destinationScore = 
			    (Score)scoresOfDestination.elementAt(j);
			if (resourceDB.hasData(destinationScore.host, 
					       fragment.id))
			    continue;
			if (!serverMonitor.hasAvailableDisk(
			    currentTime, destinationScore.host, fragment.size))
			    continue;

			Host destination = 
			    ((Score)scoresOfDestination.elementAt(j)).host;
			scoresOfDestination.remove(j);
			replica = new ReplicaData(
			    owner, source, destination, this, fragment, 
			    false, currentTime
			);
			//System.out.println(
			SimulationDebug.println(
			    Format.format(currentTime, 3) + ": replicate " + 
			    fragment + " from " + source + 
			    " to " + destination);
			break;
		    }

		    if (replica != null) {
			v.add(replica);
			// migrate only 1 replica
			break; // MODIFY
		    }
		}
	    }
	    if (v.size() > 0) {
		replicatings.add(v);
		replicate(currentTime, replicatings.size() - 1);
	    }
	}
    }
    */

    protected Vector shuffle(Vector org){
	Vector v = new Vector();
	Enumeration e = org.elements();
	while (e.hasMoreElements()) {
	    int index = (int)(random.nextDouble() * v.size());
	    v.insertElementAt(e.nextElement(), index);
	}
	return v;
    }

    /*
    // callee: disk
    public Host selectDestinationHost(
	double currentTime, DataFragment dataFragment
    ) {
	Host targetHost = null;
	double score = 0;
	Vector hosts = new Vector();
	Enumeration e = resourceDB.hosts();
	while (e.hasMoreElements()) {
	    Host host = (Host)e.nextElement();
	    HostInfo info = resourceDB.getHostInfo(host);
	    if (info.diskSize >= dataFragment.size) {
		hosts.add(host);
		if (info.availableDiskSize > dataFragment.size) {
		    StaticHostInfo staticInfo = 
			resourceDB.getStaticHostInfo(host);
		    double tmpScore = 
			staticInfo.performance / (1.0 + info.loadAverage);
		    if (tmpScore > score) {
			score = tmpScore;
			targetHost = host;
		    }
		}
	    }
	}

	if (targetHost != null)
	    return targetHost;

	e = hosts.elements();
	while (e.hasMoreElements()) {
	    Host host = (Host)e.nextElement();
	    Enumeration e1 = host.dataFragments();
	    double tmpScore = 0.0;
	    while (e1.hasMoreElements()) {
		DataFragment f = (DataFragment)e1.nextElement();
		tmpScore += f.size * resourceDB.howManyReplicas(f);

	    }
	    if (score < tmpScore) {
		score = tmpScore;
		targetHost = host;
	    }
	}
	return targetHost;
    }
    */
}
