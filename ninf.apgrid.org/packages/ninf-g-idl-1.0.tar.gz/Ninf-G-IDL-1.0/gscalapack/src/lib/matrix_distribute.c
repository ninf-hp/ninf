/* $Id: matrix_distribute.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#include <stdio.h>
#include <stdlib.h>
#include <mpi.h>
#include <assert.h>
#include <string.h>

#define _LOCAL_
#include "gscalapack.h"
#include "gscalapack-scalapack.h"

extern void parse_type(const char*,char*);
extern void gamx2d( char*, void*);

void _scatter( const char *c,void *sv, void *dv, int m, int n, int rsrc, int csrc) {
  char utype[TYPESTRLEN];
#define MPI_TAG 99
  MPI_Status status;
  if (serial==1) return;
   /* Scatter scalar elements */
  parse_type(c,utype);
  switch(*utype) {
  case 'i':
    if( mypnum == csrc ) {
      Cigebs2d( all_ctxt, "ALL", " ", m, n, (int*)sv, m );
    } else {
      Cigebr2d( all_ctxt, "ALL", " ", m, n, (int*)dv, m, rsrc, csrc );
    }
    break;
  case 'd': /* double */
    if( mypnum == csrc ) {
      Cdgebs2d( all_ctxt, "ALL", " ", m, n, (double*)sv, m );
    } else {
      Cdgebr2d( all_ctxt, "ALL", " ", m, n, (double*)dv, m, rsrc, csrc );
    }
    break;
  case 'f': /* float */
    if( mypnum == csrc ) {
      Csgebs2d( all_ctxt, "ALL", " ", m, n, (float*)sv, m );
    } else {
      Csgebr2d( all_ctxt, "ALL", " ", m, n, (float*)dv, m, rsrc, csrc );
    }
    break;
  case 'c': /* scomplex */
    if( mypnum == csrc ) {
      Ccgebs2d( all_ctxt, "ALL", " ", m, n, (scomplex*)sv, m );
    } else {
      Ccgebr2d( all_ctxt, "ALL", " ", m, n, (scomplex*)dv, m, rsrc, csrc );
    }
    break;
  case 'z': /* dcomplex */
    if( mypnum == csrc ) {
      Czgebs2d( all_ctxt, "ALL", " ", m, n, (dcomplex*)sv, m );
    } else {
      Czgebr2d( all_ctxt, "ALL", " ", m, n, (dcomplex*)dv, m, rsrc, csrc );
    }
    break;
  case 's': /* character */
    if ((rsrc==0)&&(csrc==0)) {
      MPI_Bcast( (char*)sv, m, MPI_CHAR, 0 , MPI_COMM_WORLD );
    } else if( mypnum == csrc ) {
      MPI_Send( (char*)sv, m, MPI_CHAR, 0, MPI_TAG , MPI_COMM_WORLD );
    } else {
      MPI_Recv( (char*)dv, m, MPI_CHAR, csrc, MPI_TAG , MPI_COMM_WORLD, &status );
    }
  case 'l': /* long */
    if ((rsrc==0)&&(csrc==0)) {
      MPI_Bcast( (long*)sv, m, MPI_LONG, 0 , MPI_COMM_WORLD );
    } else if( mypnum == csrc ) {
      MPI_Send( (long*)sv, m, MPI_LONG, 0, MPI_TAG , MPI_COMM_WORLD );
    } else {
      MPI_Recv( (long*)dv, m, MPI_LONG, csrc, MPI_TAG , MPI_COMM_WORLD, &status );
    }
    break;
  default:
    assert(0);
  }
} /* end of _scatter */


void _distribute(
	    const char *type,
	    int m,
	    int n,
	    void *a,
	    int ia,
	    int ja,
	    int *desc_a,
	    void *b,
	    int ib,
	    int jb,
	    int *desc_b
)
{
  /* Copy the all element of matrices into a local memory of each pocessor*/
  int *desc_s, *desc_d;
  char utype[TYPESTRLEN];

  if (serial==1) return;

  desc_s=desc_a;
  desc_d=desc_b;
  if (desc_a[0]!=1) {
    desc_s=desc_a+DESCLEN_0;
    assert(*desc_s==1);
  }
  if (desc_b[0]!=1) {
    desc_d=desc_b+DESCLEN_0;
    assert(*desc_d==1);
  }

  parse_type(type,utype);
  switch(*utype) {
  case 'd':
    Cpdgemr2d( m, n, (double*)a, ia, ja, desc_s , (double*)b, ib, jb, desc_d, all_ctxt);
    break;
  case 'f':
    Cpsgemr2d( m, n, (float*)a, ia, ja, desc_s , (float*)b, ib, jb, desc_d, all_ctxt);
    break;
  case 'c':
    Cpcgemr2d( m, n, (scomplex*)a, ia, ja, desc_s , (scomplex*)b, ib, jb, desc_d, all_ctxt);
    break;
  case 'z':
    Cpzgemr2d( m, n, (dcomplex*)a, ia, ja, desc_s , (dcomplex*)b, ib, jb, desc_d, all_ctxt);
    break;
  case 'i':
    Cpigemr2d( m, n, (int*)a, ia, ja, desc_s , (int*)b, ib, jb, desc_d, all_ctxt);
    break;
  default:
    assert(0);
    break;
  }
} /* end of _distribute */

void _tridistribute(
		     char *uplo,
		    char *diag,
		  const  char *type,
		int m,
		int n,
		void *a,
		int ia,
		int ja,
		int *desc_a,
		void *b,
		int ib,
		int jb,
		int *desc_b
){
  char utype[TYPESTRLEN];
  /* Copy the all element of matrices into a local memory of each pocessor*/
  if (serial==1) return;
  parse_type(type,utype);
  switch(*utype) {
  case 'd':
    Cpdtrmr2d( uplo, diag, m, n, (double*)a, ia, ja, desc_a , (double*)b, ib, jb, desc_b, all_ctxt);
    break;
  case 'f':
    Cpstrmr2d( uplo, diag, m, n, (float*)a, ia, ja, desc_a , (float*)b, ib, jb, desc_b, all_ctxt);
    break;
  case 'c':
    Cpctrmr2d( uplo, diag, m, n, (scomplex*)a, ia, ja, desc_a , (scomplex*)b, ib, jb, desc_b, all_ctxt);
    break;
  case 'z':
    Cpztrmr2d( uplo, diag, m, n, (dcomplex*)a, ia, ja, desc_a , (dcomplex*)b, ib, jb, desc_b, all_ctxt);
    break;
  case 'i':
    Cpitrmr2d( uplo, diag, m, n, (int*)a, ia, ja, desc_a , (int*)b, ib, jb, desc_b, all_ctxt);
    break;
  default:
    assert(0);
    break;
  }
} /* end of _tridistribute */


void _tddistribute(
	      const char *type1,
	      const char *type2,
	      const char *type3,
	      int n,
	      void *gdl,
	      void *gd,
	      void *gdu,
	      int igd, int jgd, /* not used */
	      int *desc_gd,
	      void *ldl,
	      void *ld,
	      void *ldu,
	      int ild, int jld, /* not used */
	      int *desc_ld
)
{
  char utype[TYPESTRLEN];
  /* Copy the all element of matrices into a local memory of each pocessor*/

  if (serial==1) return;

  parse_type(type1,utype);
  if (gdl!=gdu) {
    switch(*utype) {
    case 'f':
      svDistribute( "c", gdl, n-1, 1, ldl,  blocsize, nprow, npcol, myprow, mypcol, seq_ctxt, para_ctxt, all_ctxt, mypnum);
      break;
    case 'd':
      dvDistribute( "c", gdl, n-1, 1, ldl,  blocsize, nprow, npcol, myprow, mypcol, seq_ctxt, para_ctxt, all_ctxt, mypnum);
      break;
    case 'c':
      cvDistribute( "c", gdl, n-1, 1, ldl,  blocsize, nprow, npcol, myprow, mypcol, seq_ctxt, para_ctxt, all_ctxt, mypnum);
      break;
    case 'z':
      zvDistribute( "c", gdl, n-1, 1, ldl,  blocsize, nprow, npcol, myprow, mypcol, seq_ctxt, para_ctxt, all_ctxt, mypnum);
      break;
    default:
      assert(0);
      break;
    } // end of switch
  }

  parse_type(type2,utype);
  switch(*utype) {
  case 'f':
    svDistribute( "c", gd,    n, 0, ld,  blocsize, nprow, npcol, myprow, mypcol, seq_ctxt, para_ctxt, all_ctxt, mypnum);
    break;
  case 'd':
    dvDistribute( "c", gd,    n, 0, ld,  blocsize, nprow, npcol, myprow, mypcol, seq_ctxt, para_ctxt, all_ctxt, mypnum);
    break;
  case 'c':
    cvDistribute( "c", gd,    n, 0, ld,  blocsize, nprow, npcol, myprow, mypcol, seq_ctxt, para_ctxt, all_ctxt, mypnum);
    break;
  case 'z':
    zvDistribute( "c", gd,    n, 0, ld,  blocsize, nprow, npcol, myprow, mypcol, seq_ctxt, para_ctxt, all_ctxt, mypnum);
    break;
  default:
    assert(0);
    break;
  } // end of switch

  parse_type(type3,utype);
  switch(*utype) {
  case 'f':
    svDistribute( "c", gdu, n-1, 0, ldu,  blocsize, nprow, npcol, myprow, mypcol, seq_ctxt, para_ctxt, all_ctxt, mypnum);
    break;
  case 'd':
    dvDistribute( "c", gdu, n-1, 0, ldu,  blocsize, nprow, npcol, myprow, mypcol, seq_ctxt, para_ctxt, all_ctxt, mypnum);
    break;
  case 'c':
    cvDistribute( "c", gdu, n-1, 0, ldu,  blocsize, nprow, npcol, myprow, mypcol, seq_ctxt, para_ctxt, all_ctxt, mypnum);
    break;
  case 'z':
    zvDistribute( "c", gdu, n-1, 0, ldu,  blocsize, nprow, npcol, myprow, mypcol, seq_ctxt, para_ctxt, all_ctxt, mypnum);
    break;
  default:
    assert(0);
    break;
  } // end of switch

} /* end of _tddistribute */

void _band_distribute(
	      const char *type,
	      int n,
	      int bwl,
	      int bwu,
	      void *global,
	      int *desc_gd,
	      void *local,
	      int *desc_ld,
	      int pivot
)
{
  char utype[TYPESTRLEN];
  int ld;

  if (serial==1) return;

  if (pivot!=0) {
    ld=2*bwl+2*bwu+1;
  } else {
    ld=bwl+bwu+1;
  }

  parse_type(type,utype);
  switch(*utype) {
  case 'f':
    svDistribute( "c", global, ld*n, 0, local, ld*blocsize, nprow, npcol, myprow, mypcol, seq_ctxt, para_ctxt, all_ctxt, mypnum);
    break;
  case 'd':
    dvDistribute( "c", global, ld*n, 0, local, ld*blocsize, nprow, npcol, myprow, mypcol, seq_ctxt, para_ctxt, all_ctxt, mypnum);
    break;
  case 'c':
    cvDistribute( "c", global, ld*n, 0, local, ld*blocsize, nprow, npcol, myprow, mypcol, seq_ctxt, para_ctxt, all_ctxt, mypnum);
    break;
  case 'z':
    zvDistribute( "c", global, ld*n, 0, local, ld*blocsize, nprow, npcol, myprow, mypcol, seq_ctxt, para_ctxt, all_ctxt, mypnum);
    break;
  case 'i':
    ivDistribute( "c", global, ld*n, 0, local, ld*blocsize, nprow, npcol, myprow, mypcol, seq_ctxt, para_ctxt, all_ctxt, mypnum);
    break;
  default:
    assert(0);
    break;
    
  }
}

void _band_distribute_old(
	      const char *type,
	      int n,
	      int bwl,
	      int bwu,
	      void *global,
	      int *desc_gd,
	      void *local,
	      int *desc_ld,
	      int pivot
)
{
  char utype[TYPESTRLEN];
  /* Copy the all element of matrices into a local memory of each pocessor*/

  int ld;
  if (serial==1) return;

  if (pivot!=0) {
    ld=2*bwl+2*bwu+1;
    local+=blocsize*(bwl+bwu);
  } else 
    ld=bwl+bwu+1;

  parse_type(type,utype);
  switch(*utype) {
    int i,offset,len;
      case 'f':
	for(i=0;i<ld;i++) {
	  if (i<bwu) {
	    offset = bwu-i;
	    len = n-offset;
	  } else {
	    offset=0;
	    len = n-(i-bwu);
	  }
	  svDistribute( "c", global,  len, offset, local,  blocsize, nprow, npcol, myprow, mypcol, seq_ctxt, para_ctxt, all_ctxt, mypnum);
	  global += len;
	  local +=  blocsize;
	}
	break;
      case 'd':
	for(i=0;i<ld;i++) {
	  if (i<bwu) {
	    offset = bwu-i;
	    len = n-offset;
	  } else {
	    offset=0;
	    len = n-(i-bwu);
	  }
	  dvDistribute( "c", global,  len, offset, local,  blocsize, nprow, npcol, myprow, mypcol, seq_ctxt, para_ctxt, all_ctxt, mypnum);
	  global += len;
	  local +=  blocsize;
	}
	break;
      case 'c':
	for(i=0;i<ld;i++) {
	  if (i<bwu) {
	    offset = bwu-i;
	    len = n-offset;
	  } else {
	    offset=0;
	    len = n-(i-bwu);
	  }
	  cvDistribute( "c", global,  len, offset, local,  blocsize, nprow, npcol, myprow, mypcol, seq_ctxt, para_ctxt, all_ctxt, mypnum);
	  global += len;
	  local +=  blocsize;
	}
	break;
      case 'z':
	for(i=0;i<ld;i++) {
	  if (i<bwu) {
	    offset = bwu-i;
	    len = n-offset;
	  } else {
	    offset=0;
	    len = n-(i-bwu);
	  }
	  zvDistribute( "c", global,  len, offset, local,  blocsize, nprow, npcol, myprow, mypcol, seq_ctxt, para_ctxt, all_ctxt, mypnum);
	  global += len;
	  local +=  blocsize;
	}
	break;
      case 'i':
	for(i=0;i<ld;i++) {
	  if (i<bwu) {
	    offset = bwu-i;
	    len = n-offset;
	  } else {
	    offset=0;
	    len = n-(i-bwu);
	  }
	  ivDistribute( "c", global,  len, offset, local,  blocsize, nprow, npcol, myprow, mypcol, seq_ctxt, para_ctxt, all_ctxt, mypnum);
	  global += len;
	  local +=  blocsize;
	}
	break;

  default:
    assert(0);
    break;
  } // end of switch

} /* end of _band_distribute */


void _vdistribute( char *rowcol,
		   const char *type,
		   int size,
		   void *gv,
		   void *lv
)
{
  char utype[TYPESTRLEN];
  int blocsize=1;

  if (serial==1) return;

  if (*rowcol=='r') blocsize=rbloc;
  else blocsize=cbloc;

  parse_type(type,utype);
  switch(*utype) {
      case 'i':
          ivDistribute( rowcol, (int*)gv,   size, 0, (int*)lv,  blocsize, nprow, npcol, myprow, mypcol, seq_ctxt, para_ctxt, all_ctxt, mypnum);
          break;
      case 'f':
          svDistribute( rowcol, gv,   size, 0, lv,  blocsize, nprow, npcol, myprow, mypcol, seq_ctxt, para_ctxt, all_ctxt, mypnum);
          break;
      case 'd':
          dvDistribute( rowcol, gv,   size, 0, lv,  blocsize, nprow, npcol, myprow, mypcol, seq_ctxt, para_ctxt, all_ctxt, mypnum);
          break;
      case 'c':
          cvDistribute( rowcol, gv,   size, 0, lv,  blocsize, nprow, npcol, myprow, mypcol, seq_ctxt, para_ctxt, all_ctxt, mypnum);
          break;
      case 'z':
          zvDistribute( rowcol, gv,   size, 0, lv,  blocsize, nprow, npcol, myprow, mypcol, seq_ctxt, para_ctxt, all_ctxt, mypnum);
          break;
      default:
          assert(0);
          break;
  } // end of switch

} /* end of _vdistribute */
