package ninf.toNs;
import ninf.basic.*;
import java.util.Vector;
import java.util.Hashtable;
import java.io.IOException;
import java.io.*;

public class ToNsConfig extends Configure{
  static final int DEFAULT_PORT = 3012;

  static CommandRepresent initAcceptedCommands[] = {
    new CommandRepresent("metaserver",    2), 
    new CommandRepresent("myhostname",    1),
    new CommandRepresent("log",           1), 
    new CommandRepresent("port",          1),
    new CommandRepresent("lookup",        1),
    new CommandRepresent("netsolveAgent", 1)
  };
  static CommandRepresent initAcceptedOptions[] = {
    new CommandRepresent("-port",      1), 
    new CommandRepresent("-debug",     0),
    new CommandRepresent("-quiet",     0),
    new CommandRepresent("-version",   0)};

  String netsolveAgent;
  MetaServerReference metaServer;

  ToNsConfig(String args[]) throws NinfException{
    super(args, initAcceptedCommands, initAcceptedOptions);
  }

  public void configure() throws NinfException{
    port = DEFAULT_PORT;
    super.configure();
    configureMetaServer();
    configureNetsolveAgent();
  }

  void configureNetsolveAgent(){
    String tmp = getOneArg("netsolveAgent");
    if (tmp != null);
      netsolveAgent = tmp;
  }

  void configureMetaServer(){
    String strs[] = getOneContent("metaserver");
    if (strs == null || strs.length == 0)
      return;
    metaServer = new MetaServerReference(strs[0], (new Integer(strs[1]).intValue()));
  }

}
