#! /bin/sh
# $Id: make_lower2upper_header.sh,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $

[ x"$1" = x"" ] && exit

HEAD=`echo ${FORTRANFORMAT} | sed -e 's/\(^.*\)%.*$/\1/' `
TAIL=`echo ${FORTRANFORMAT} | sed -e 's/^.*%.\(.*\)$/\1/'`

echo -n > .tmp_func

for f in `find $1 -name '*.idl' -a -type f -print` ; do
	grep '^ *Calls  *\"Fortran\"' $f|sed -e 's!^.*Calls.*"Fortran" *!!;s!(.*$!!' >> .tmp_func
	grep 'FortranCall' $f|sed -e 's!^.*FortranCall(\([^)][^)]*\)).*$!\1!' >> .tmp_func
	grep 'FortranReturn' $f|sed -e 's!^.*FortranReturn[^(]*(\([^,][^,]*\),.*$!\1!' >> .tmp_func
done

for f in `find $1 -name '*_ninf.c' -a -type f -print` ; do
	grep 'FortranCall' $f|sed -e 's!^.*FortranCall(\([^)][^)]*\)).*$!\1!' >> .tmp_func
	grep 'FortranReturn' $f|sed -e 's!^.*FortranReturn[^(]*(\([^,][^,]*\),.*$!\1!' >> .tmp_func
done

echo
sed -e 's! !!g' .tmp_func |uniq| awk -v head=${HEAD} -v tail=${TAIL} '(length($1)>3){printf "#define %s%s%s\t%s%s%s\n", head,$1,tail,  head,toupper($1),tail }'

rm .tmp_func