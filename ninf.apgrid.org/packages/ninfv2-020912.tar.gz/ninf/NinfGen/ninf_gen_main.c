/* 
 *  NINF stub main and make file generator 
 *
 *  $Id: ninf_gen_main.c,v 1.3 1999/03/02 07:17:35 tatebe Exp $
 */

#include "ninf_gen.h"
#include <stdio.h>
#include <string.h>
#include <stdarg.h>

#define FILE_NAME_LEN 	125
char title_file_name[FILE_NAME_LEN];

#ifndef CPP_FILE
#define CPP_FILE "cc -E"
#endif

static char CPP_OPEN[1000];

/**  is gmake?  **/
int gmake_f = 0;

/* for debug */
int debug_flag = FALSE;
FILE *debug_fp;

/* the number of errors */
int nerrors;

char *source_file_name,*output_file_name;
FILE *source_file,*output_file;

char *program;	/* this program */

/**  function declarations  **/

extern void init_expr_code_info();
extern void initialize_lex();
extern int yyparse();
extern void dump_stubs();
extern void generate_stub_program(struct stub_gen_entry *ep);
extern void generate_stubs_makefile();

static void check_nerrors();
static void print_usage();

/*
 *  MAIN
 */

int main(int argc, char *argv[])
{
    int n;
    register char *cp;
    
    program = argv[0];

    --argc;
    ++argv;

    sprintf(CPP_OPEN, "%s ", CPP_FILE);

    /* parse command line */
    while (argc >0 && argv[0][0] == '-') {
      for (cp = argv[0]+1; *cp; cp++){
	switch (*cp){
	case 'd':
	  ++debug_flag;
	  break;
	case 'g':
	  gmake_f = 1;
	  break;
	case 'h':
	  print_usage();
	  exit(0);
	default:
	  strcat(CPP_OPEN, argv[0]);
	  strcat(CPP_OPEN, " ");
	  break;
	}
      }
      --argc;
      ++argv;
    }
    
    if (argc > 0){
      source_file_name = argv[0];
      strcat(CPP_OPEN, argv[0]);
      if ((source_file = popen(CPP_OPEN, "r")) == NULL){
	fprintf(stderr,"cannot open %s\n",source_file_name);
	exit(1);
      }
      /* set title as default */
      strcpy(title_file_name,source_file_name);
    } else 
      source_file = stdin;
    
    if (argc > 1){
      output_file_name = argv[1];
      if ((output_file = fopen(output_file_name,"w")) == NULL){
	fprintf(stderr,"cannot open %s\n",output_file_name);
	exit(1);
      }
    } else 
      output_file = stdout;

    /* DEBUG */ debug_fp = stdout;

    init_expr_code_info();
    initialize_lex();
    
    /* start processing */
    yyparse();

    if (debug_flag) dump_stubs();

    if (!nerrors){
      
      /* generate stub programs */
      for(n = 0; n < n_stubs; n++)
	generate_stub_program(&stubs[n]);
      
      /* generate make file */
      generate_stubs_makefile();
      
      /* geneate interface database */
    }
    return(nerrors?1:0);
}

/* 
 * error messages 
 */

void where(int lineno)
{ 
    /* print location of error  */
    fprintf(stderr, "\"%s\", line %d: ",title_file_name, lineno);
}

/* nonfatal error message */
/* VARARGS0 */
void error(char *fmt, ...) 
{ 
    va_list args;

    ++nerrors;
    where(lineno); /*, "Error");*/
    va_start(args, fmt);
    vfprintf(stderr, fmt, args);
    va_end(args);
    fprintf(stderr, "\n" );
    fflush(stderr);
    check_nerrors();
}

/* VARARGS0 */
void error_at_node(expr x, char *fmt, ...) 
{ 
    va_list args;
    ++nerrors;
    va_start(args, fmt);
    where((int)EXPR_LINENO(x)); /* , "ErrorAtNode"); */
    vfprintf(stderr, fmt, args);
    va_end(args);
    fprintf(stderr, "\n" );
    fflush(stderr);
    if(nerrors > 30){
      /* give the compiler the benefit of the doubt */
      fprintf(stderr, 
	      "too many error, cannot recover from earlier errors: goodbye!\n" );
      exit(1);
    }
}

/* VARARGS0 */
void warning_at_node(expr x, char *fmt, ...) 
{ 
  va_list args;

  where(EXPR_LINENO(x)); /*, "WarnAtNode"); */
  fprintf(stderr,"warning:");
  va_start(args, fmt);
  vfprintf(stderr, fmt, args);
  va_end(args);
  fprintf(stderr, "\n" );
  fflush(stderr);
}

void
check_nerrors()
{
    if(nerrors > 30){
      /* give the compiler the benefit of the doubt */
      fprintf(stderr, 
	      "too many error, cannot recover from earlier errors: goodbye!\n" );
      exit(1);
    }
}

/* compiler error: die */
/* VARARGS1 */
void
fatal(char *fmt, ...)
{ 
    va_list args;
    
    where(lineno); /*, "Fatal");*/
    fprintf(stderr, "compiler error: " );
    va_start(args, fmt);
    vfprintf(stderr, fmt, args);
    va_end(args);
    fprintf(stderr, "\n" );
    fflush(stderr);
    abort();
}

int warning_flag = FALSE; 

/* warning */
void
warning(char *fmt, ...) 
{  
  va_list args;
  
  if(warning_flag) return;
  where(lineno); /*, "Warn");*/
  va_start(args, fmt);
  fprintf(stderr, "warning: " );
  vfprintf(stderr, fmt, args);
  va_end(args);
  fprintf(stderr, "\n" );
  fflush(stderr);
}


/*
 *   Print usage
 */

void
print_usage()
{
    puts("usage: ninf_gen [-d] [-g] [-h] [input_file] [output_file]");
    puts("\t-d  Debug option");
    puts("\t-g  Produce makefile in gnu make style");
    puts("\t-h  Show this message");
}
