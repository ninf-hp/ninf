#define _WRAPPER_
/* $Id: pssygst_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define FLOAT
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n
#define ROW_b ldb
#define COL_b n
void  pssygst_ninf(	 int ibtype,
		 char uplo,
		 int n,
		 float global_a[],
		 int lda,
		 float global_b[],
		 int ldb,
		 float *scale,
		 int *info
)
/* "pssygst reduces a real symmetric-definite generalized eigenproblem to standard form." */
/* OPTIONS */
{
	int maxldd;

	int maxlda;
	float *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
	int row_loca, col_loca;

	int maxldb;
	float *locb=NULL;
	int descb[DESCLEN];
	int desc_gb[DESCLEN];
	int row_locb, col_locb;

	float lscale[1];

	INITIALIZE();

	SCALAR( "int", ibtype);
	SCALAR( "char", uplo);
	SCALAR( "int", n);
	SCALAR("int",lda);
	SCALAR("int",ldb);

	ROW( a);
	COL( a);
	ROW( b);
	COL( b);
	MAXLDD( maxldd, a );
	maxlda = maxldd;
	maxldb = maxldd;

	trMATRIX( uplo, "float", a, ROW_a, COL_a);
	trDISTRIBUTE( uplo, "float", a, ROW_a, COL_a);
	MATRIX( "float", b, ROW_b, COL_b);
	DISTRIBUTE( "float", b, ROW_b, COL_b);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pssygst)( &ibtype, &uplo, &n,
			       loca, &one, &one, desca,
			       locb, &one, &one, descb,
			       lscale,
			       &linfo);

	GATHER( "float", a, ROW_a, COL_a);

	RETRIEVE("float", lscale, 1);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
	  *info = linfo;
	  *scale = lscale[0];
	} else {
		
	}

	FREE_MATRIX(a);
	FREE_MATRIX(b);
}

