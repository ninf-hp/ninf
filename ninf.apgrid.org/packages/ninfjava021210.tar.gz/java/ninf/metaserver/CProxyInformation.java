package ninf.metaserver;
import  ninf.basic.*;
import  ninf.common.*;

/** store cproxy information, i.e. distance from each NinfServer,
  for directory service */

class CProxyInformation{
  String hostname;
  int port;
  CommunicationInformation throughput;
  CommunicationInformation latency;
  long updateTime;
  
  CProxyInformation(String hostname, int port){
    this.hostname = hostname;
    this.port     = port;
  }

  void updateInfo(CommunicationInformation throughput, 
		  CommunicationInformation latency){
    this.throughput = throughput;
    this.latency    = latency;
    updateTime = System.currentTimeMillis();
  }

  public int hashCode(){
    return hostname.hashCode() + port;
  }

  public boolean equals(Object o){
    if (!(o instanceof CProxyInformation))
      return false;
    CProxyInformation i = (CProxyInformation)o;
    return (hostname.equals(i.hostname) && port == i.port);
  }

}
