#define _WRAPPER_
/* $Id: pdlared1d_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define DOUBLE
#include <gscalapack.h>
static	int worklen(int n) {
		int ret=1;
		ret = n;
		if NEED_BUFF {
			ret = NUMROC(n, cbloc, 0, 0, npcol);
		}
		return ret;
}

void  pdlared1d_ninf(	 int n,
		 double global_bycol[],
		 double byall[]
)
/* "pdlared1d redistributes a 1D array. It assumes that the input array, BYCOL, is distributed across rows and that all process column contain the same copy of BYCOL." */
/* OPTIONS */
{
	int maxldd;

	double *locbycol=NULL;
	int desc[DESCLEN];

	double *locwork=NULL;
	int llocwork;


	INITIALIZE();

	SCALAR( "int", n);
	if (mypnum!=0) {
            byall = MALLOC(sizeof(double)*n); assert(byall);
        }
        
	VECTOR( "r", "double", bycol, n);
        Cdescinit( desc, n, 1, rbloc, 1, 0, 0, PARA_CTXT, rbloc, &linfo);
	vDISTRIBUTE( "r", "double", bycol,n);

	llocwork=worklen(n);
	WORK(locwork,llocwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
		FortranCall(pdlared1d)( &n, &one, &one, desc,
                                        locbycol,
                                        byall,
                                        locwork, &llocwork);

	RETRIEVE( "double", byall, n);

	if( mypnum == 0 ){
	} else {
		FREE(byall);
	}
        FREE(locwork);
	
}

