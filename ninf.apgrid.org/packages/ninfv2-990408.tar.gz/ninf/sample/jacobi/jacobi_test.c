#include <stdio.h>
#include "ninf_stub.h"

#define N 10
double base[N][N];

print(int size, double * base){
  int i, j;
  for (i = 0; i < size; i++){
    for (j = 0; j < size; j++){
      printf("%3.2f ", 	*((base) + (size) * (i) + (j)));      
    }
    printf("\n");
  }
  printf("\n");
}

init(int size, double * base){
  int i, j;
  for (i = 0; i < size; i++){
    for (j = 0; j < size; j++){
      *((base) + (size) * (i) + (j)) = (i==j)? 3: 0;
    }
  }
}

main(int argc, char ** argv){
  char tmp[10];
  init(N, base);

  Ninf_parse_arg(argc, argv);
  while(1){
    print(N, base);
    gets(tmp);
    if (Ninf_call("jacobi/jacobi", N, base, 1) != NINF_OK)
	Ninf_perror("jacobi");
  }
}
