#define _WRAPPER_
/* $Id: pslamr1d_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define FLOAT
#include <gscalapack.h>
void  pslamr1d_ninf(	 int n,
			 float global_a[],
			 float global_b[]
)
/* "pslamr1d redistributes a one-dimensional row vector from one data decomposition to another. This is an auxiliary routine called by PSSYTRD to redistribute D, E  and TAU." */
/* OPTIONS */
{
	int maxldd;
	float *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
	int row_loca, col_loca;

	float *locb=NULL;
	int descb[DESCLEN];
	int desc_gb[DESCLEN];
	int row_locb, col_locb;


	INITIALIZE();

	SCALAR( "int", n);

	VECTOR("c","float", a,n);
	vDISTRIBUTE( "c", "float", a, n);
	Cdescinit( desca, 1, n, 1, n, 0, 0, PARA_CTXT, 1, &linfo);
        
	VECTOR("c","float", b,n);
	vDISTRIBUTE( "c", "float", b, n);
	Cdescinit( descb, 1, n, 1, n, 0, 0, PARA_CTXT, 1, &linfo);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pslamr1d)( &n,
                                loca, &one, &one, desca,
                                locb, &one, &one, descb);

	vGATHER("c","float", a, n);
	vGATHER("c", "float", b, n);

	if( mypnum == 0 ){
	} else {
	}
        FREE_VECTOR(a);
        FREE_VECTOR(b);
	
}

