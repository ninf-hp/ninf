package ninf.scheduler;
import ninf.basic.NinfException;

public class PredictorException extends NinfException {
  public PredictorException() {
    super();
  }
}

