package bricks.environment;
import bricks.util.*;
import bricks.scheduling.Scheduler;
import bricks.scheduling.ResourceDB;
import java.io.*;
import java.util.*;

/** 
 * Host.java
 * <pre>
 * Host represents the computational resources/client of the given Grid
 * computing system, and is parameterized by e.g., performance, load, and
 * their variance over time.
 * The data injected by Host are decomposed into logical packets.
 * </pre>
 */
public class Host extends Node {

    // for event flag
    protected static final int CLIENT  = 0;
    protected static final int SERVER  = 1;
    protected static final int DISK    = 2;
    protected static final int PACKETS = 3;

    protected Server server;
    protected Client client;
    protected Disk   disk;

    protected Hashtable hashtableOfRoutes = new Hashtable();

    /** 
     * The scheduler that allocates a new task of the host.
     */
    protected Scheduler scheduler = null;
    protected ResourceDB resourceDB = null;
    
    /** 
     * Packets decomposes transmitted data into logical packets and 
     * sends them into a Network.
     */
    protected Packets packets;

    /**
     * Constructs Host with
     *     owner : a SimulationSet of your configuration,
     *     key : a key of the Host,
     *     queue : a queue which represents performance, congestion, and
     *             their variance,
     *     numInstructions : numInstructions,
     *     interarrivalTime : The interval that the Host invokes external jobs.
     */
    public Host(
	SimulationSet owner, String key, String keyOfResourceDB,
	Client client, Server server, Disk disk
    ){
	this.owner = owner;
	this.key = key;
	this.client = client;
	client.setHost(this);
	logWriter = owner.requestLogWriter;
	this.server = server;
	server.setHost(this);
	this.disk = disk;
	disk.setResourceDB(owner.getResourceDB(keyOfResourceDB));
	disk.setHost(this, (owner.logicalPacket).packetSize);
	init();
	packets = new Packets(this, (owner.logicalPacket).packetSize);
	nextLink = new Vector();
    }

/************************* needed method *************************/
    /** 
     * returns a type of the Host
     */
    public String getName() {
	return "Host";
    }

    /**
     * sets scheduler
     */
    public void setScheduler(Scheduler scheduler) {
	this.scheduler = scheduler;
	resourceDB = scheduler.getResourceDB();
    }

    // override
    public void initSession(double currentTime) {
	client.initSession(currentTime);
	server.initSession(currentTime);
	disk.initSession(currentTime);
	updateNextEvent(currentTime);
    }

    // callee: ResourceDB
    public boolean hasClient() {
	if (client instanceof NullClient)
	    return false;
	else
	    return true;
    }

    /** 
     * processEvent
     *     CLIENT : process clientevent.
     *     SERVER : process server event.
     *     DISK   : process disk event.
     */
    public void processEvent(double currentTime) {
	switch(event) {
	case CLIENT:
	    client.processEvent(currentTime);
	    break;
	case SERVER:
	    server.processEvent(currentTime);
	    break;
	case DISK:
	    disk.processEvent(currentTime);
	    break;
	case PACKETS:
	    packets.sendFirstPacket(currentTime);
	    break;
	}
    }

    /**
     * updateNextEvent finds next event which occurs earliest.
     **/
    public void updateNextEvent(double currentTime) {

	/* client */
	event = CLIENT;
	client.updateNextEvent(currentTime);
	double earliestTime = client.nextEventTime;

	/* server */
	server.updateNextEvent(currentTime);
	if (server.nextEventTime < earliestTime) {
	    event = SERVER;
	    earliestTime = server.nextEventTime;
	}
	/* disk */
	disk.updateNextEvent(currentTime);
	if (disk.nextEventTime < earliestTime) {
	    event = DISK;
	    earliestTime = disk.nextEventTime;
	}
	/* packets */
	if (!packets.isEmpty()) {
	    TrafficData requestedData = packets.firstPacket();
	    if (requestedData.timeEventComes < earliestTime) {
		earliestTime = requestedData.timeEventComes;
		event = PACKETS;
	    }
	}
	this.nextEventTime = earliestTime;
	SimulationDebug.println(
	    this + ".updateNextEvent: " + Format.format(currentTime, 3) + 
	    " : disk = " + disk + ", disk.nextEventTime = " + 
	    disk.nextEventTime);
	SimulationDebug.println("nextEventTime = " + nextEventTime);
    }

    public void sendData(double currentTime, TrafficData data) {

	SimulationDebug.println(
	    "Host.sendData: " + data + " at " + currentTime);
	Node next = data.nextNode();
	SimulationDebug.println(
	    "Host.sendData: (next, this) = (" + next + ", " + this + ")");

	if ((next == null) || (next instanceof TerminalNode))
	    return;
	
	// process job at this server or disk
	if (next.equals(this) || next instanceof Disk) { 
	    SimulationDebug.println(
		"Host.sendData: Host.sendData: " + data + "goes to " + next);
	    data.gotoNextNode(currentTime);
	} else {
	    SimulationDebug.println("Host.sendData: Host.sendData: " + data + "will be divided");
	    SimulationDebug.println("indexOfCurrentNode = " + data.getIndexOfCurrentNode());
	    SimulationDebug.println(data.getListOfRoute());
	    packets.divideTrafficData(currentTime, data);
	    //if (packets.canOnePacketSend())
		packets.sendFirstPacket(currentTime);
	}
    }

    /** callee: Disk instances. */
    public void sendOnePacket(double currentTime, TrafficData data) {
	packets.putOnePacket(currentTime, data);
	if (packets.canOnePacketSend())
	    packets.sendFirstPacket(currentTime);
    }

    /**
     * Methods for initialize routes
     */
    // override
    public void tracePath(Vector list) {

	/* Check return path */
	if (list.contains(this))
	    return;
	
	list.addElement(this);
	if (list.size() == 1) { /* Start */
	    /* trace next node */
	    Enumeration e = nextLink.elements();
	    while (e.hasMoreElements()) {
		Vector subList = (Vector)list.clone();
		Node node = (Node)e.nextElement();
		node.tracePath(subList);
	    }
	} else { /* End */
	    Node node = (Node)list.firstElement();
	    if (node instanceof Host)
		((Host)node).addRoute(this, list);
	    else
		BricksUtil.abort("configuration file");
	}
	return;
    }

    public void addRoute(Node node, Vector list) {
	hashtableOfRoutes.put(node, list);
    }

    /* caller: RouteService */
    public Hashtable getRoutes() {
	return hashtableOfRoutes;
    }

    /** overriden method defined by Node */
    public void putInterarrivalTimeOfPackets(Sequence ng, Node toNode) {
	packets.putInterarrivalTimeOfPackets(ng, toNode);
    }

    // override
    /** 
     * prints simulation log.
     */
    public void printLog(String log) {
	logWriter.println(log);
    }

    public String toOriginalString(double currentTime) {
	String str = "  [" + getName() + " " + key + "](";
	str += client.toOriginalString(currentTime) + "), (";
	str += server.toOriginalString(currentTime) + "), (";
	str += disk.toOriginalString(currentTime) + "\n";
	return str;
    }

    public String toInitString() {
	String str = "  [" + getName() + " " + key + "] : ";
	str += client.toInitString() + "), (";
	str += server.toInitString() + "), (";
	str += disk.toInitString() + "\n";
	return str;
    }

/************************* public method *************************/
    /** 
     * calls the data's outLogString when the RequestData 
     * returns to the Client.
     */
    public void schedule(double currentTime, Data data) {

	// RequestedData or ReplicaData
	TrafficData td = (TrafficData)data;
	Vector listOfRoute = td.getListOfRoute();
	SimulationDebug.println(
	    "Host.schedule(): " + currentTime + " : " + "data");

	// finish
	if (td.getIndexOfCurrentNode() - listOfRoute.size() + 1 == 0) {
	    if (data instanceof RequestedData) {
		RequestedData rd = (RequestedData)data;
		if (scheduler != null)
		    scheduler.finishTask(rd);
		// output simulation results
		rd.outLogString(currentTime);
		
	    } else {  // ReplicaData
		SimulationDebug.println(
		    "Replica " + data + " arrived at " + this);
		((ReplicaData)data).killed(currentTime);
	    }

	} else {// do not finish (RequestedData only)
	    RequestedData rd = (RequestedData)data;
	    server.schedule(currentTime, data);
	}
	updateNextEvent(currentTime);
    }
    
    /**
     * returns StaticHostInfo at First
     */
    public StaticHostInfo getStaticHostInfo() {
	StaticHostInfo info = server.getStaticHostInfo();
	info.setDiskThroughput(disk.getThroughput());
	return info;
    }

    /** 
     * returns HostInfo that denotes current status of the Host.
     */
    public HostInfo getHostInfo(
	double currentTime, double trackingTime, double trackingTimeForAccess
    ) {
	HostInfo hostInfo = server.getHostInfo(currentTime, trackingTime);
	disk.addDiskInfo(currentTime, trackingTimeForAccess, hostInfo);
	return hostInfo;
    }

    /** 
     * for Disk
     */
    public Enumeration dataFragments() {
	return disk.dataFragments();
    }

    public Disk getDisk() {
	if (disk instanceof NullDisk)
	    return null;
	else
	    return disk;
    }

    public DataFragment getMostAccessedDataFragment(
	double currentTime, double trackingTime
    ) {
	return disk.getMostAccessedDataFragment(currentTime, trackingTime);
    }

    public boolean isClient() {
	if (client instanceof NullClient)
	    return false;
	else
	    return true;
    }
    
    public boolean isServer() {
	if (server instanceof NullServer)
	    return false;
	else 
	    return true;
    }

    public void finish() {
	disk.finish();
    }

    /**
     * for fallback
     **/
    public void fallback(double currentTime, RequestedData data) {
	client.fallback(currentTime, data);
	updateNextEvent(currentTime);
    }

    /**
     * for PassiveReplicaManager
     **/
    public void replicate(double currentTime, DataFragment fragment) {
	owner.replicate(currentTime, this, fragment);
    }
}
