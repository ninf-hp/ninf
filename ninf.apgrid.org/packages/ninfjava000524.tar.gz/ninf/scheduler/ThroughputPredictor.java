package ninf.scheduler;

import ninf.basic.*;
import ninf.common.*;
import ninf.metaserver.*;
import ninf.client.*;
import java.util.Hashtable;
import java.util.Enumeration;

public class ThroughputPredictor extends Predictor{
  Hashtable throughputTable;
  static NinfLog dbg = new NinfLog("ThroughputPredictor");
  static double UPVAL = 1.0;

  public ThroughputPredictor(){
    super();
    throughputTable = new Hashtable();
  }

  public void scheduled(RequestID request, CallInformation callInfo, 
			ScheduleResult result){
    ServerIndex serverIndex = result.serverInfo.serverIndex;
    UpValT val = (UpValT)throughputTable.get(serverIndex.server);
    if (val == null){
      val = new UpValT();
      throughputTable.put(serverIndex.server, val);    
    }
    val.add(request, System.currentTimeMillis(), callInfo, result);
    super.scheduled(request, callInfo, result);
  }

  public void done(RequestID request, CallInformation callInfo, 
		   ScheduleResult result){
    ServerIndex serverIndex = result.serverInfo.serverIndex;
    UpValT val = (UpValT)throughputTable.get(serverIndex.server);
    if (val == null){
      val = new UpValT();
      throughputTable.put(serverIndex.server, val);    
    }
    val.remove(request);
    super.done(request, callInfo, result);
  }
  
  public CommunicationInformation getThroughput(NinfServerStruct server, 
						ServerID cproxy)
  throws NinfException {
    CommunicationInformation commInfo = super.getThroughput(server, cproxy);
    UpValT val = (UpValT)throughputTable.get(server);
    if (val != null){
      int active = val.getActiveSend(cproxy, commInfo.when);
      commInfo = commInfo.copy();
      commInfo.throughput = commInfo.throughput / (active + 1.0);
      dbg.println("throughput is div by " + (active + 1.0));
    }
    return commInfo;
  }
}

class TimeInfoStruct {
  long time;
  CallInformation callInfo;
  ScheduleResult result;
  RequestID request;
  TimeInfoStruct(long time, RequestID request,  CallInformation callInfo, 
		 ScheduleResult result){
    this.time     = time;
    this.request  = request;
    this.callInfo = callInfo;
    this.result   = result;
  }			
}

class UpValT {
  Hashtable table;

  UpValT(){
    table = new Hashtable();
  }

  void add(RequestID request, long time, CallInformation callInfo, 
	   ScheduleResult result){
    table.put(request, new TimeInfoStruct(time, request, callInfo, result));
  }

  void remove(RequestID request){
    table.remove(request);
  }

  int getActiveSend(ServerID cproxy, long when){
    int counter = 0;
    Enumeration enum = table.elements();
    while (enum.hasMoreElements()){
      TimeInfoStruct struct = (TimeInfoStruct)enum.nextElement();
      if (struct.request.cproxyHost.equals(cproxy.host) &&
	  struct.request.cproxyPort == cproxy.port){
	long start = struct.time;
	long end   = struct.time + (long)(struct.result.predicted[1]) * 1000;

System.out.println("start = "+ start +", when = "+ when + ", end = " + end);
	if (when > start && end > when)
	  counter++;
      }
    }
    return counter;
  }
}
