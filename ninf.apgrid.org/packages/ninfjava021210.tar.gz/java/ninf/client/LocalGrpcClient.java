package ninf.client;

import org.gridforum.gridrpc.*;
import java.util.*;
import java.io.*;

public class LocalGrpcClient implements org.gridforum.gridrpc.GrpcClient{
  Properties instanceProp;
  
  public void activate(String propertiesFilename) throws GrpcException{
    try {
      Properties prop = new Properties();
      prop.load(new FileInputStream(propertiesFilename));
      activate(prop);
    } catch (IOException e) {
      throw new GrpcException(e);
    }
  }

  /** initializes a Grpc Client */
  public void activate(Properties prop){
    this.instanceProp = prop;
  }

  public GrpcHandle getHandle(String functionName, Properties prop)
  throws GrpcException {
    if (functionName == null)
      throw new GrpcException("functionName not specified.");
    String executableName = prop.getProperty(functionName);
    if (executableName == null)
      return getHandle(functionName);
    return new LocalGrpcHandle(executableName);    
  }

  /** Create a default GrpcHandler and returns */
  public GrpcHandle getHandle(String functionName)
  throws GrpcException {
    String executableName;
    if (functionName == null)
      throw new GrpcException("functionName not specified.");
    executableName = instanceProp.getProperty(functionName);
    if (executableName == null)
      throw new GrpcException("functionName not specified.");
    return new LocalGrpcHandle(executableName);
  }

  public void deactivate(){
    // nothing to do
  }

}
