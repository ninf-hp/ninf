//
// NinfServerConnection.java
//

package ninf.client;

import java.io.IOException;
import java.io.*;
import java.net.*;
import java.util.Vector;
import ninf.basic.*;
import ninf.basic.NinfErrorException;
import ninf.common.*;

public class NinfServerConnection  extends NinfConnection  
  implements Stoppable, ConnectionManager {

  public static boolean lookup = true;

  NinfServerStruct struct;
  ClientConfig config;
  GeneralConnection connection;  
  public int currentIndex;
  public final static int RETRY_DEFAULT = 3;
  public final static int SLEEP_INIT = 2000;
  boolean stopped = false;
  NinfLog dbg = new NinfLog(this);
  ForeServer fs;
  OutputStream stdoutStream, stderrStream;
  NinfExecInfo execInfo;

  //  for ninfQ protocol
  public static final int MATCH_PARTIAL = 0;
  public static final int MATCH_EXACT = 1;

  void getConnect() throws IOException{
        connection = new GeneralConnection(config).connect();
	is = new XDRInputStream(connection.getInputStream());
	os = new XDROutputStream(connection.getOutputStream());
	String peer;
	dbg.println("Connected to "+struct.host+ "("+ 
		    connection.peerName(lookup) +
		    ") at " + struct.port + " T:" + 
		    System.currentTimeMillis()/1000.0);
  }


  public NinfServerConnection(NinfServerStruct s) throws NinfException {
    this(s, RETRY_DEFAULT);
  }

  public NinfServerConnection(NinfServerStruct s, OutputStream stdoutStream, 
			       OutputStream stderrStream) throws NinfException {
    this(s, RETRY_DEFAULT);
    this.stdoutStream = stdoutStream;
    this.stderrStream = stderrStream;
  }

  public NinfServerConnection(ClientConfig config, 
			      OutputStream stdoutStream, 
			      OutputStream stderrStream) 
      throws NinfException {
    struct = config.getStruct();
    this.config = config;
    this.stdoutStream = stdoutStream;
    this.stderrStream = stderrStream;
    this.connectServer(RETRY_DEFAULT);
  }

  public NinfServerConnection(NinfServerStruct s, int retry)
    throws NinfException {
      struct = s;
      config = new ClientConfig(struct.host, struct.port);
      this.connectServer(retry);
  }

  public LoadInformation getLoad() throws NinfException {
    NinfPacket pkt = new NinfPacket(NinfPktHeader.NINF_PKT_LOAD,0,0,0);
    pkt.write(os);
    XDRInputStream pis = new XDRInputStream(new NinfPacketInputStream(is));
    try {
      double loadAverage = pis.readDouble();
      double user   = pis.readDouble();
      double system = pis.readDouble();
      double idle   = pis.readDouble();
      return new LoadInformation(loadAverage, user, system, idle);
    } catch (IOException e){
      throw new NinfIOException(e);
    }
  }

  public ServerCharacter getServerCharacter() throws NinfException {
    NinfPacket pkt = new NinfPacket(NinfPktHeader.NINF_PKT_CHARACTER,0,0,0);
    pkt.write(os);
    NinfPacketInputStream pis = new NinfPacketInputStream(is);
    return new ServerCharacter(pis);
  }

  public void clearResource(URLResource rsc) throws NinfException{
    NinfPacketOutputStream pos = new NinfPacketOutputStream(os);
    pos.setCode(NinfPktHeader.NINF_PKT_CLEAR_STORAGE_RESOURCE);
    pos.writeString(rsc.path);
    pos.flush();
    NinfPacketInputStream pis = new NinfPacketInputStream(is);
    if (pis.getCode() != NinfPktHeader.NINF_PKT_RPY_STORAGE_RESOURCE)
      throw new NinfErrorException(pis.getArg1());
  }


  public long getThroughput(int size, int mode) throws NinfException {
    /* mode = 0:both, 1:fore, 2: back */
    NinfPacket pkt = new NinfPacket(NinfPktHeader.NINF_PKT_THROUGHPUT,0,size,mode);
    long t1 = System.currentTimeMillis();
    pkt.write(os);
    byte tmp[] = new byte[size];
    if (mode == 0 || mode == 1){
      NinfPacketOutputStream pos = new NinfPacketOutputStream(os);
      pos.write(tmp);
      pos.flush();
    }
    NinfPacketInputStream pis = new NinfPacketInputStream(is);
    if (mode == 0 || mode == 2){
      try {
	pis.read(tmp, size);
      } catch (IOException e){ throw new NinfIOException(e); }
    }
    long t2 = System.currentTimeMillis();
    return t2 - t1;
  }

  public void connectServer(int retryCount) throws NinfException {
//    dbg.println("host = " + struct.host + " port = " + struct.port);
    int count = 0;
    Exception e = null;
    execInfo = new NinfExecInfo();
    int sleepTime = SLEEP_INIT;
    while (count < retryCount) {
      try{
	getConnect();
	return;
      } catch (IOException e0) {
	dbg.println("caught execption " + struct.host + ":" + struct.port);
	try {
	  Thread.currentThread().sleep(sleepTime);
	  ++count;
	  e = e0;
	  sleepTime *= 2;
	} catch(InterruptedException ie) {
	  ie.printStackTrace();
	}
      }
    }
    if (e != null) {
      dbg.println("retry over: host = " + struct.host + " port = " + struct.port);
      throw(new NinfErrorException(NinfError.CANTCONNECTSERVER));
    }
  }


  public NinfStub getStub(String str) throws NinfException {
    NinfPacket.getStubPacket(str).write(os);
    NinfPacket tmp = new NinfPacket(is);
    if (tmp.hdr.isRpyStubInfo()) {
      currentIndex = tmp.hdr.arg1;
      return new NinfStub(tmp.buf);
    } else{
      dbg.println("Can't read Stub:" + tmp);
      throw new NinfErrorException(tmp.hdr.arg1);
    }
  }

  public NinfStub[] query(int indexes[]) throws NinfException {
    NinfStub tmp[] = null;
    if (indexes != null){
      tmp = new NinfStub[indexes.length];
      for (int i = 0; i < indexes.length; i++){
	tmp[i] = getStub(indexes[i]);
      }
    }
    return tmp;
  }
  public NinfStub[] query(String key) throws NinfException {
    int indexes[] = getIndexes(key, NinfPktHeader.PARTIAL, 100);
    return query(indexes);
  }

  public NinfStub getStub(int index) throws NinfException{
    NinfPacket.getStubPacket(index).write(os);
    NinfPacket tmp = new NinfPacket(is);
    if (tmp.hdr.isRpyStubInfo()) {
      currentIndex = tmp.hdr.arg1;
      return new NinfStub(new XDRInputStream(
                          new NinfPacketInputStream(tmp, is)));
    }else{
      dbg.println("Can't read Stub:" + tmp);
      throw new NinfErrorException(NinfError.STUBREADFAIL);
    }
  }

  public int[] getIndexes(String keyword) throws NinfException{
    return getIndexes(keyword, 0, 100);
  }

  public int[] getIndexes(String keyword, int option, int max) throws NinfException{
    NinfPacket.getReqStubIndexListPacket(keyword, option).write(os);
    NinfPacket tmp = new NinfPacket(is);
    if (tmp.hdr.code != NinfPktHeader.NINF_PKT_RPY_STUB_INDEX_LIST) {
      dbg.println("Can't get reply stub index list");
      throw new NinfErrorException(NinfError.NINF_PROTOCOL_ERROR);
    }
    dbg.println("Got call reply (NINF_PKT_RPY_STUB_INDEX_LIST)");
    
    int tmpRep[] = new int[tmp.hdr.arg1];
    XDRInputStream is = new XDRInputStream(new ByteArrayInputStream(tmp.buf));
    try {
      for (int i = 0; i < tmp.hdr.arg1; i++)
	tmpRep[i] = is.readInt();
    } catch (IOException e){
      throw new NinfIOException();
    }
    return tmpRep;
  }

  public void sendCall(int index) throws NinfException{
    dbg.println("Now, send call : index =" + index + " (NINF_PKT_REQ_CALL)");
    if (execInfo != null)
      execInfo.start();
    NinfPacket.getCallPacket(index).write(os);
    NinfPacket tmp = new NinfPacket(is);
    if (!tmp.hdr.isRpyCall()) {
      dbg.println("Can't get reply call:" + tmp.hdr);
      throw new NinfErrorException(NinfError.NINF_PROTOCOL_ERROR);
    }
    try {
      int serial = new XDRInputStream((new NinfPacketInputStream(tmp, is))).readInt();
      dbg.println("Got call reply (NINF_PKT_RPY_CALL): "+ serial);
      if (execInfo != null)
	execInfo.call_serial = serial;
    } catch (IOException e){
      throw new NinfIOException(e);
    }
  }



  public double getTime() throws NinfException{
    NinfPacketOutputStream pos = 
      new NinfPacketOutputStream(os, NinfPktHeader.NINF_PKT_GETTIME);
    pos.flush();
    XDRInputStream pis = new XDRInputStream(new NinfPacketInputStream(is));
    try {
      double time = pis.readDouble();
      return time;
    } catch (IOException e){
      throw new NinfIOException(e);
    }
  }

  public NinfStub invoke(String func) throws NinfException {
    NinfStub currentStub = getStub(func);
    //    System.out.println(currentStub);
    sendCall(currentIndex);
    return currentStub;
  }


  public NinfExecInfo call(String func, Vector args) throws NinfException {
    CallContext context;
    NinfStub currentStub = getStub(func);
    //    System.out.println(currentStub);

    context = currentStub.transformArgs(args);
    sendCall(currentIndex);
    currentStub.sendArgs(context, new NinfPacketOutputStream(os), new int[currentStub.nparam][]);
    receive(currentStub, context);
    killStubProgram();
    currentStub.reverseTrans(context, args);
    return execInfo;
  }

  public NinfExecInfo callNative(NinfStub stub, int index, 
				 CallContext context) 
  throws NinfException{
    try {		   
      currentIndex = index;
      sendCall(currentIndex);
      
      stub.sendArgs(context, new NinfPacketOutputStream(os), new int[stub.nparam][]);
      receive(stub, context);

      //      stub.receive(args, new NinfPacketInputStream(is));
      killStubProgram();
      // dbg.println("callNative for "+struct.host+ " at " + struct.port + "end. T:" + System.currentTimeMillis());
      return execInfo;
    } catch (NinfException e){
      if (stopped)
	throw new NinfStoppedByUserException();
      throw e;
    }
  }

  public void stop(){
    stopped = true;
    dbg.println("stopped");
    close();
  }

  public void close() {
    try {
      connection.close();
      if (fs != null){
	ForeServer tmp = fs;
	fs = null;
	tmp.stop();

      }
    } catch (Exception e) {
      dbg.println("failed to close, ignore." );
    }
  }

  public void killStubProgram() throws NinfException {
    NinfPacket.getKillPacket().write(os);
    NinfPacketInputStream istream = new NinfPacketInputStream(is, stdoutStream, stderrStream);
    try {
      if (istream.getCode() != NinfPktHeader.NINF_PKT_RPY_KILL)
	throw new NinfErrorException(NinfError.NINF_PROTOCOL_ERROR);
    }catch(NinfIOException e){
      throw new NinfErrorException(NinfError.NINF_PROTOCOL_ERROR);
    }
  }


  /** this will detach the forwarding server. for ninf.proxy.PortManger */
  public void startForward(XDRInputStream is, XDROutputStream os)
     throws NinfException{
    fs = new ForeServer(is, os, this);
    fs.detachMode();
    fs.simple();
    fs.run(this);
  }

  public void startForward(NinfPacket pkt, int index, XDRInputStream is, XDROutputStream os)
     throws NinfException{
    pkt.hdr.arg1 = index; /* change the index in header to that in server */
    fs = new ForeServer(is, os, this);
    fs.run(pkt, this);
  }

  /** does not detach. used by LatchStubCallable */
  public void startForward(NinfStub stub, int index, CallContext context,
			   XDRInputStream is, 
			   XDROutputStream os) throws NinfException{
    currentIndex = index;
    sendCall(currentIndex);
    stub.sendArgs(context, new NinfPacketOutputStream(this.os), 
		  new int[stub.nparam][]);
    fs = new ForeServer(is, os, this);
    fs.simple(); // simple mode;
    fs.run(this);
  }

  /** does not detach. used by StubCallable */
  public void startForwardWithScalar(NinfStub stub, int index, CallContext context,
				     NinfPacket pkt, XDRInputStream is, 
			   XDROutputStream os) throws NinfException{
    currentIndex = index;
    sendCall(currentIndex);
    NinfPacketOutputStream ops = new NinfPacketOutputStream(this.os);
    stub.sendCall(context, ops);
    stub.sendScalar(context, ops);
    ops.flush();
    fs = new ForeServer(is, os, this);
    fs.simple();  // simple mode
    fs.run(pkt, this);
  }

  public void closed(ForeServer foresever){
    dbg.println("fowarding server closed");
  }
  public void exception(Exception e){
  }
}

// end of NinfServerConnection.java



