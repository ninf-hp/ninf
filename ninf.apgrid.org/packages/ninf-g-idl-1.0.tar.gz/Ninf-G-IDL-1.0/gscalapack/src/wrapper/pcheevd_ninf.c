#define _WRAPPER_
/* $Id: pcheevd_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define SCOMPLEX
#include <gscalapack.h>

#define ROW_a lda 
#define COL_a n
#define ROW_z ROW_a
#define COL_z COL_a

static	int worklen(int n) {
	  int ret=1;
	  int NP0, MQ0;
          ret = n + (n + n + n)*n;
#define NB cbloc
	  if NEED_BUFF {
	    NP0 = NUMROC( MAX( N, max(NB, 2) ), NB, 0, 0, NPROW );
	    MQ0 = NUMROC( MAX( N, max(NB, 2) ), NB, 0, 0, NPCOL );
	    ret = N + ( NP0 + MQ0 + NB ) * NB;
	  }
	  return ret;
}
static	int rworklen(int n) {
	  int ret=1;
	  int NP, NQ, IAROW, IACOL;
          ret = 1+ 8 *n +2 *n*2;
	  if NEED_BUFF {
	    IAROW = _IAROW;
	    IACOL = _IACOL;
	    NP = NUMROC( N, NB, MYROW, IAROW, NPROW );
	    NQ = NUMROC( N, NB, MYCOL, IACOL, NPCOL );
	    ret = 1 + 8*N + 2*NP*NQ;
	  }
	  return ret;
}
static	int iworklen(int n) {
	  int ret=1;
          ret = 7*n + 8+2;
	  if NEED_BUFF {
	    ret = 7*N + 8*NPCOL + 2;
	  }
	  return ret;
}

void  pcheevd_ninf(	 char jobz,
		 char uplo,	
		 int n,
		 scomplex global_a[],
		 int lda,
		 float w[],
		 scomplex work[],
		 int lwork,
		 float rwork[],
		 int lrwork,
		 int iwork[],
		 int liwork,
		 int *info
)
/* "pcheevd computes all the eigenvalues and eigenvectors of a Hermitian matrix A by using a divide and conquer algorithm." */
/* OPTIONS */
{
extern void FortranCall(pcheevd)( char*, char*, int*,
				  scomplex*, int*, int*, int*,
				  scomplex*,
				  scomplex*, int*, int*, int*,
				  scomplex*, int*,
				  float*, int*,
				  int*, int*, int*);
extern void FortranCall(pclacpy)( char*, int*, int*,
                               scomplex*, int*, int*, int*,
                               scomplex*, int*, int*, int*);

	int maxldd;

	scomplex *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
	int maxlda;
	int row_loca, col_loca;

	int maxldz;
	scomplex *global_z=NULL;
	scomplex *locz=NULL;
	int descz[DESCLEN];
	int desc_gz[DESCLEN];
	int row_locz, col_locz;

        float *locw=NULL;

	scomplex *locwork=NULL;
	int llocwork;
	float *locrwork=NULL;
	int llocrwork;
	int *lociwork=NULL;
	int llociwork;

	INITIALIZE();

	SCALAR("char",jobz);
	SCALAR("char",uplo);
	SCALAR("int", n);
	SCALAR("int", lda);
        SCALAR( "int", lwork);
        SCALAR( "int", lrwork);
        SCALAR( "int", liwork);

	if (mypnum==0) {
            global_z = MALLOC(sizeof(scomplex)*ROW_z*COL_z);
            assert(global_z);
        }

	ROW(a);
	COL(a);
	ROW(z);
	COL(z);
	MAXLDD(maxldd, a);
	maxlda=maxldd;
	MAXLDD( maxldd, z);
	maxldz=maxldd;

	trMATRIX( uplo, "scomplex", a, ROW_a, COL_a);
	trDISTRIBUTE( uplo, "scomplex", a, ROW_a, COL_a);
	MATRIX( "scomplex", z, ROW_z, COL_z);

        locw=MALLOC(sizeof(float)*n); assert(locw);

	llocwork=worklen(n);
        llocwork=max(llocwork,lwork);
	WORK(locwork,llocwork);
        
	llocrwork=rworklen(n);
        llocrwork = max(llocrwork,lrwork);
	_work("float",&locrwork,llocrwork);
        
	llociwork=iworklen(n);
        llociwork=max(llociwork,liwork);
	IWORK(lociwork,llociwork);
	
	if  (( mypnum != 0 ) ^ (serial==1) ) {
	 FortranCall(pcheevd)( &jobz, &uplo, &n,
                               loca, &one, &one, desca,
                               locw,
                               locz, &one, &one, descz,
                               locwork, &llocwork,
                               locrwork, &llocrwork,
                               lociwork, &llociwork, &linfo);
	 FortranCall(pclacpy)( &uplo, &ROW_a, &COL_a,
                               locz, &one, &one, descz,
                               loca, &one, &one, desca);
	}

	GATHER("scomplex", a, ROW_a, COL_a );
	RETRIEVE("int", &linfo, 1);
        RETRIEVE("float", locw, n);

	if( mypnum == 0 ){
            int i;
            *info = linfo;
            for(i=0;i<n;i++) w[i] = locw[i];
	} else {
	}

	FREE_MATRIX(a);
	FREE_MATRIX(z);
        FREE(locwork);
        FREE(locrwork);
        FREE(lociwork);
        FREE(locw);
	
}

