#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>

#define N 103

#if defined(NINFG1)
#include "grpc.h"
#include "ns.h"
#include "ns_complex.h"
#include "nsapi.h"
#elif defined(NINFG2)
#include "grpc.h"
#include "ng.h"
#else
#error NINF Version is unknown.
#endif
#include "assert.h"

#include <gfftest.h>

char *host;
int port;

#define COUNT 1

int main(int argc,char ** argv) {

  grpc_function_handle_t handle;
  dcomplex *in=NULL, *out=NULL, *rout=NULL;
  char plan[WISDOMLEN];
  int ldim=3;
  int dim[ldim];
  int size;

  double resid;
  double *dat=NULL;
  double x;
  int i;

  if (argc>1) {
      if (grpc_initialize(argv[1]) != GRPC_NO_ERROR) {
          fprintf(stderr, "grpc initialize\n");
          exit(2);
      }
  } else {
      fprintf(stderr, "You need to put config_file.\n");
      exit(0);
  }

  for(i=0;i<ldim;i++) dim[i] = N;
  size=1;
  for(i=0;i<ldim;i++) size=size*dim[i];


  in = malloc(sizeof(dcomplex)*size); assert(in);
  out = malloc(sizeof(dcomplex)*size); assert(out);
  rout = malloc(sizeof(dcomplex)*size); assert(rout);
  dat = malloc(sizeof(double)*size); assert(dat);

  x=0.2;
  for(i=0;i<size;i++) {
    //            x=4.*x*(1.-x);
    dat[i]=sin((double)i/64.);
  }

  for(i=0;i<size;i++) {
    in[i].r = dat[i];
    in[i].i = 1./(dat[i]+0.1);
    out[i].r = 0.;
    out[i].i = 0.;
    rout[i].r = 0.;
    rout[i].i = 0.;
  }


#if defined(NINFG1)
  host = strdup(nslib_conf_getserverhostname());
  port = nslib_conf_getserverport();
#elif defined(NINFG2)
  if ((host=getenv("NG_SERVER"))==NULL) {
      fprintf(stderr, "env 'NG_SERVER' is not defined and set my hostname instead.\n");
#define HOSTNAMELEN 512
      host = calloc(HOSTNAMELEN, sizeof(char));
      if (gethostname(host, HOSTNAMELEN) != 0) {
          strcpy(host,"localhost");
      }
  }
  {
      char *dummyc;
      if ( (dummyc = getenv("NG_SERVER_PORT")) != NULL) {
          port = atoi(dummyc);
      }
  }
#else
#error
#endif

   if (grpc_function_handle_init( &handle, host, "fftw/fftwnd_create_plan") 
       != GRPC_NO_ERROR ) {
     grpc_perror_np( "handle_init");
     exit(2);
   }

   printf("size=");
   for(i=0;i<ldim-1;i++) {
     printf("%dx",dim[i]);
   }
   printf("%d=%d\n", dim[i],size);

   if (grpc_call(&handle, ldim, dim, FFTW_FORWARD, FFTW_MEASURE, plan) != GRPC_NO_ERROR) {
	          fprintf(stderr,"Failed in grpc_call:create_plan\n");
	          exit(2);
   }
   grpc_function_handle_destruct(&handle);
   printf( "PLAN=%s\n", plan);


   if (grpc_function_handle_init( &handle, host, "fftw/fftwnd_one") 
       != GRPC_NO_ERROR ) {
     grpc_perror_np( "handle_init");
     exit(2);
   }
   if (grpc_call(&handle, plan, ldim, in, out, size, size) != GRPC_NO_ERROR) {
     grpc_perror_np("Failed in grpc_call:one\n");
     exit(2);
   }
   grpc_function_handle_destruct(&handle);

   printf("\nRESIDUE Check.\n");
   if (grpc_function_handle_init( &handle, host, "fftw/ifftwnd_one") 
       != GRPC_NO_ERROR ) {
     grpc_perror_np( "handle_init");
     exit(2);
   }
   if (grpc_call(&handle, plan, ldim, out, rout, size, size) != GRPC_NO_ERROR) {
     fprintf(stderr,"Failed in grpc_call:ione\n");
     exit(2);
   }
   grpc_function_handle_destruct(&handle);

   for(i=0;i<size;i++) {
     rout[i].r /= (double)(size);
     rout[i].i /= (double)(size);
   }

      
   printf("\n");
   printf("\norg inv^2\n");
   for(i=0;i<5;i++) printf("%3.16f %3.16f\n",in[i].r,rout[i].r);
   printf("\n");
   for(i=0;i<5;i++) printf("%3.16f %3.16f\n",in[i+N].r,rout[i+N].r);

   resid = 0.;
   for(i=0;i<N*N;i++) {
     resid += (in[i].r-rout[i].r)*(in[i].r-rout[i].r)+(in[i].i-rout[i].i)*(in[i].i-rout[i].i);
   }
   resid = sqrt(resid)/(double)(size);
   printf("\nresid=%2.18f\n", resid);


   grpc_finalize();

   free(in);
   free(out);

   return 0;
}
