#ifndef __NINF_READ_CONFIG_H__
#define __NINF_READ_CONFIG_H__

struct delegate_item {
  char * function_name;
  char * hostname;
  char * port;
  struct delegate_item  * next;
};

struct read_stub_item {
  char * stub_file_name;
  struct read_stub_item * next;
};

struct metaserver_item {
  char * hostname;
  char * port;
  struct metaserver_item * next;
};

#endif
