#define _WRAPPER_
/* $Id: pspttrf_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define _DISTRIBUTE_1D_
#define FLOAT
#include <gscalapack.h>

static	int worklen() {
	  int ret=1;
	  ret = 8;
	  if NEED_BUFF {
	    ret = 8*npcol;
	  }
	  return ret;
}


void  pspttrf_ninf(	 int n,
		 float global_d[],
		 float global_e[],
		 int *info
)
/* "pspttrf computes a Cholesky factorization of an N-by-N real tridiagonal symmetric positive definite distributed matrix A." */
/* OPTIONS */
{
    extern void FortranCall(pspttrf)( int*,
                               float*, float*, int*, int*,
                               float*, int*,
                               float*, int*,
                               int*);

	int maxldd;

	float *locd=NULL;
	float *loce=NULL;
	int desctdd[DESCLEN];
	int desc_gtdd[DESCLEN];

	float *locaf=NULL;
	int laf;
	
	float *locwork=NULL;
	int llocwork;

	INITIALIZE();

	SCALAR( "int", n);
	SIZE(n);

	tdMATRIX( "float", e, d, e, n);
        tdDISTRIBUTE( "float", e, d, e, n);
        
	laf = blocsize+2;
        locaf = MALLOC(sizeof(float)*laf);
        assert(locaf);
	
	llocwork = worklen();
	WORK(locwork,llocwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pspttrf)( &n,
                               locd, loce, &one, desctdd,
                               locaf, &laf,
                               locwork, &llocwork,
                               &linfo);

	tdGATHER( "float", e, d, e, n);

	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
		*info = linfo;
	} else {
	}
	FREE_MATRIX(d);
	FREE_MATRIX(e);
	FREE(locaf);
        FREE(locwork);
	
}

