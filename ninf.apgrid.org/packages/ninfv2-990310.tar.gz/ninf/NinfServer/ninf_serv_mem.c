#include <stdlib.h>
#include <stdio.h>
#define XMALLOC(t,size)	((t)xmalloc(size))


char *xmalloc(int size)
{
    char *p;
    if((p = (char *)malloc(size)) == NULL){
      fprintf(stderr, "no memory");
      exit(3);
    }
    return(p);
}


