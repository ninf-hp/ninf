#define _WRAPPER_
/* $Id: pcpoequ_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define SCOMPLEX
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n
void  pcpoequ_ninf(	 int n,
		 scomplex global_a[],
		 int lda,
		 float global_sr[],
		 float global_sc[],
		 int ldsc,
		 float *scond,
		 float *amax,
		 int *info
)
/* "pcpoequ computes row and column scalings intended to equilibrate a distributed Hermitian positive definite matrix A and reduce its condition number (with respect to the two-norm).  SR and SC contain the scale factors, S(i) = 1/sqrt(A(i,i)), chosen so that the scaled distributed matrix B with elements B(i,j) = S(i)*A(i,j)*S(j) has ones on the  diagonal. " */
/* OPTIONS */
{
	int maxldd;

	int maxlda;
	scomplex *loca;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
	int row_loca, col_loca;

	float *locsr;
	float *locsc;

	float lscond[1];
	float lamax[1];


	INITIALIZE();

	SCALAR( "int", n);
	SCALAR( "int", lda);
	SCALAR( "int", ldsc);

	ROW( a);
	COL( a);
	MAXLDD( maxldd, a );
	maxlda = maxldd;

	MATRIX( "scomplex", a, ROW_a, COL_a);
	DISTRIBUTE( "scomplex", a, ROW_a, COL_a);
	VECTOR( "r", "float", sr, ROW_a);
	VECTOR( "c", "float", sc, COL_a);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pcpoequ)( &n,
                               loca, &one, &one, desca,
                               locsr, locsc,
                               lscond, lamax,
                               &linfo);

	vGATHER( "r", "float", sr, ROW_a);
	vGATHER( "c", "float", sc, COL_a);

	RETRIEVE("int", lscond, 1);
	RETRIEVE("int", lamax, 1);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
	  *scond = lscond[0];
	  *amax = lamax[0];
	  *info = linfo;
	} else {
	}

	FREE_MATRIX(a);
}

