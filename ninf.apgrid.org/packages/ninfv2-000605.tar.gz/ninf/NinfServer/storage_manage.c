#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <fcntl.h>

#include "ninf_packet.h"
#include "ninf_server_state.h"

extern char * TMP_FILE_ROOT;

int clear_storage(char * index){
  char buffer[256];
  sprintf(buffer, "%s/%s", TMP_FILE_ROOT, index);
  if (unlink(buffer) != 0){
    ninf_log("cannot unlink storage file %s: %s", index, strerror(errno));
    return FALSE;
  }
  return TRUE;
}


int open_file(char * index, int modeIn){
  int fd;
  dataTrans * dt;
  char filename[1000];

  sprintf(filename, "%s/%s", TMP_FILE_ROOT, index);
  if (ninf_debug_flag) printf("file is %s/%s\n", TMP_FILE_ROOT, index);
  if (modeIn){
    if ((fd = open(filename, O_RDONLY, 0666)) < 0){
      ninf_log("failed to read open %s: %s", filename, strerror(errno));
      return -1;
    }
  } else {
    if ((fd = creat(filename, 0666)) < 0){
      ninf_log("failed to write open %s: %s", filename, strerror(errno));
      return -1; 
    }
  }
  return fd;
}

int put_storage(dataTrans *rDT, int fd){
  while (TRUE){
    int code = trans_getPacket(rDT);
    if (code != NINF_PKT_TRANSFER &&
	code != NINF_PKT_TRANSFER_END){
      ninf_log("invalid packet code: %d", code);
      return FALSE;
    }
    write(fd, rDT->position, rDT->valid_end - rDT->position);
    rDT->position = rDT->valid_end;
    if (code == NINF_PKT_TRANSFER_END)
      break;
  }
  close(fd);
  return TRUE;
}

int get_storage(dataTrans *sDT, int fd){
  while (TRUE){
    int readed = read(fd, sDT->start, STUB_BUF_SIZE);
    if (readed <= 0){
      sDT->position = sDT->start;
      trans_flush(sDT, NINF_PKT_TRANSFER_END, 0, 0);
      break;
    }
    sDT->position = sDT->start + readed;
    trans_flush(sDT, NINF_PKT_TRANSFER, 0, 0);
  }
  close(fd);
  return TRUE;
}

/*************************** exec routines  ***************************/

int ninf_pkt_clear_storage(server_state * state){
  dataTrans *rDT = state->client->rDT;
  dataTrans *sDT = state->client->sDT;

  char buffer[1000];
  char * index = buffer;
  if (!trans_string_nolen(rDT, &index)){
    return STORAGE_CANNOT_UNLINK;
  }
  if (clear_storage(index)){
    trans_flush(sDT, NINF_PKT_RPY_STORAGE_RESOURCE, 0, 0);
    return NINF_ERROR_NOERROR;
  }
  return STORAGE_CANNOT_UNLINK;
}

int ninf_pkt_get_storage(server_state * state){
  dataTrans *rDT = state->client->rDT;
  dataTrans *sDT = state->client->sDT;
  char buffer[1000];
  char * index = buffer;
  int fd, code;

  if (!trans_string_nolen(rDT, &index))
    return STORAGE_CANNOT_OPEN;
  if ((fd = open_file(index, TRUE)) < 0)
    return STORAGE_CANNOT_OPEN;
  trans_flush(sDT, NINF_PKT_RPY_STORAGE_RESOURCE, 0, 0);
  if (!get_storage(sDT, fd))
    return STORAGE_CANNOT_OPEN;
  code = trans_getPacket(rDT);
  if (code != NINF_PKT_RPY_TRANSFER_END)
    return STORAGE_CANNOT_OPEN;
  return NINF_ERROR_NOERROR;
}

int ninf_pkt_put_storage(server_state * state){
  dataTrans *rDT = state->client->rDT;
  dataTrans *sDT = state->client->sDT;

  char buffer[1000];
  char * index = buffer;
  int fd, code;

  if (!trans_string_nolen(rDT, &index))
    return STORAGE_CANNOT_OPEN;
  if ((fd = open_file(index, FALSE)) < 0)
    return STORAGE_CANNOT_OPEN;
  trans_flush(sDT, NINF_PKT_RPY_STORAGE_RESOURCE, 0, 0);
  if (!put_storage(sDT, fd))
    return STORAGE_CANNOT_OPEN;
  trans_flush(sDT, NINF_PKT_RPY_TRANSFER_END, 0, 0);
  return NINF_ERROR_NOERROR;
}

