package ninf.monitor;
import java.awt.*;
import ninf.basic.*;
import ninf.metaserver.NinfServerHolder;
import ninf.common.*;

public class ServerMonitorPanel extends Panel {
  Frame frame;
  Label label;
  Button retract;
  LoadGraph graph;
  ServerMonitor serverMonitor;
  NinfServerHolder holder;
  Font font = new Font("Helvetica", Font.BOLD, 12);
  TextArea logWindow;

  String labelString(){
    if (holder.serverChar != null)
      return holder.struct.host + ":" + holder.struct.port + "  " + 
	holder.serverChar.toText();
    else
      return holder.struct.host + ":" + holder.struct.port;
  }
  
  void initPanel(){
    Panel labelPanel = new Panel();
    labelPanel.setLayout(new BorderLayout());
    retract = new Button("Retract");
    label = new Label(labelString());
    labelPanel.add("Center", label);
    labelPanel.add("East", retract);
    graph = new LoadGraph(serverMonitor.loadMonitor);

    logWindow = new TextArea(80, 5);
    logWindow.setEditable(false);
    logWindow.setFont(new Font("Helvetica", Font.BOLD, 8));
    logWindow.setFont(font);
    logWindow.setBackground(Color.white);

    /* 
    this.setLayout(new BorderLayout());
    this.add("North", labelPanel);
    this.add("South", logWindow);
    this.add("Center", graph);
    */
    double ratio[] = {0.1, 0.6, 0.3};
    this.setLayout(new RatioLayout(RatioLayout.VERTICAL, ratio));
    this.add(labelPanel);
    this.add(graph);
    this.add(logWindow);
  }

  public ServerMonitorPanel(ServerMonitor serverMonitor, NinfServerHolder holder){
    this.holder = holder;
    this.setFont(font);
    this.serverMonitor = serverMonitor;
    initPanel();
  }

  public void show(){
    if (frame == null){
      frame = new Frame(labelString());
      frame.add("Center", this);
      frame.resize(600, 230);
      frame.show();
    }
  }

  public void dispose(){
    if (frame != null){
      frame.dispose();
      frame = null;
    }
  }

  public void repaint(){
    graph.repaint();
  }

  public void print(Object o){
    logWindow.appendText(""+ o);
  }

  public void println(Object o){
    logWindow.appendText(""+ o + "\n");
  }

  public boolean action(Event evt, Object arg){
    if (evt.target == retract){         /* accept button pressed */
      dispose();
      return true;
    }
    return false;
  }
}
