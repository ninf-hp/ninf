package ninf.netsolve;
// import java.io.*;
import java.io.InputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.StringBufferInputStream;
import java.net.URL;

// import java.awt.*;
import java.awt.Choice;
import java.awt.Frame;

// import java.util.*;
import java.util.Vector;
import java.util.StringTokenizer;

public class CheckData extends Thread {

  private Vector [] v;
  private Problem prob;
  private String [] filename;
  private String [] data;
  private String agent;
  private int [] lang_checked;
  private int [] checked;
  private Frame pframe;
  private int id;
  private int parentID = 0;
  private int [] m;
  private int [] n;
  private InputData input_frame;
  private int cur_lang = Labels.language;

  public CheckData(Vector [] a, Problem b, String [] c, String [] d,
    String e, int [] f, int [] g, Frame h, int i) {

    v = a;
    prob = b;
    filename = c;
    data = d;
    agent = e;
    lang_checked = f;
    checked = g;
    pframe = h;
    input_frame = (InputData) h;
    id = i;
    parentID = ((InputData)h).myID;

    m = new int [prob.nb_input];
    n = new int [prob.nb_input];

    this.start();
  }

  private Object parse_line(String line, int data_type, StringBuffer err) {
    boolean err_status = false, isTok = false;
    StringTokenizer st = new StringTokenizer(line);
    int items = 0, tokCount;
    String temp = null;
    Object return_object = null;

    tokCount = st.countTokens();

    if(data_type == NetSolveObject.NETSOLVE_EXTERNAL) {
      return(line + "\n");
    }

    switch(data_type) {
      case NetSolveObject.NETSOLVE_I:
        int [] int_arr = new int [tokCount];
        while(tokCount-- > 0) {
          try {
            temp = st.nextToken();
            int_arr[items] = Integer.valueOf(temp).intValue();
            items++;
          }catch (NumberFormatException e) {
            err_status = true;
            err.append(Labels.invalid_integer[cur_lang]+temp+"\n");
          }
        }
        return_object = int_arr;
        break;
      case NetSolveObject.NETSOLVE_S:
        float [] float_arr = new float [tokCount];
        while(tokCount-- > 0) {
          try {
            temp = st.nextToken();
            float_arr[items] = Float.valueOf(temp).floatValue();
            items++;
          }catch (NumberFormatException e) {
            err_status = true;
            err.append(Labels.invalid_float[cur_lang]
              +temp+"\n");
          }
        }
        return_object = float_arr;
        break;
      case NetSolveObject.NETSOLVE_D:
        double [] double_arr = new double [tokCount];
        while(tokCount-- > 0) {
          try {
            temp = st.nextToken();
            double_arr[items] = Double.valueOf(temp).doubleValue();
            items++;
          }catch (NumberFormatException e) {
            err_status = true;
            err.append(Labels.invalid_double[cur_lang]
              +temp+"\n");
          }
        }
        return_object = double_arr;
        break;
      case NetSolveObject.NETSOLVE_C:
        if((return_object = parse_complex(line,data_type,err)) == null)
          err_status = true;
        else
          items = ((float []) return_object).length / 2;
        break;
      case NetSolveObject.NETSOLVE_Z:
        if((return_object = parse_complex(line,data_type,err)) == null)
          err_status = true;
        else
          items = ((double []) return_object).length / 2;
        break;
      case NetSolveObject.NETSOLVE_CHAR:
        char [] char_arr = new char [tokCount];
        while(tokCount-- > 0) {
          temp = st.nextToken();
          if(temp.length() > 1) {
            err_status = true;
            err.append(Labels.char_expected[cur_lang]+temp+"\n");
          }
          try {
            char_arr[items] = new Character(temp.charAt(0)).charValue();
          }catch (NumberFormatException e) {
            err_status = true;
            err.append(Labels.invalid_char[cur_lang]+temp+"\n");
          }
          items++;
        }
        return_object = char_arr;
        break;
    }
    if(err_status)
      return(null);
    else
      return(return_object);
  }

//  private static Object parse_complex(String line, int data_type, StringBuffer err) {
  private Object parse_complex(String line, int data_type, StringBuffer err) {
    String input, token;
    StringTokenizer st;
    boolean extra, img_neg, error=false;
    int idx, real_start, real_end, img_start, img_end, count, tok_count;
    char [] tok;
    double [] temp_array = null;
    float  [] scomplex = null;
    double [] dcomplex = null;

    st = new StringTokenizer(line,"i");
 
    temp_array = new double[2 * st.countTokens()];

System.out.println("Allocating " + 2 * st.countTokens() + " elements for temp_array[]");

    count = 0;

    tok_count = 0;
    while(st.hasMoreTokens()) {
      tok_count++;
      token = st.nextToken();
      tok = token.toCharArray();
      System.out.println("Token: " + token);
      idx = 0;
      try {
        try {
          while((tok[idx] == ' ') || (tok[idx] == '\t'))
            idx++; // skip blanks 
        }catch(ArrayIndexOutOfBoundsException e) {
          System.out.println("empty token");
          tok_count--;
          continue;
        }
        System.out.println("first char is: " + tok[idx]);
        real_start = idx;
        if((tok[idx] == '+') || (tok[idx] == '-'))
          idx++;
        while((tok[idx] >= '0') && (tok[idx] <= '9')) 
          idx++;
        if(tok[idx] == '.')
          idx++;
        while((tok[idx] >= '0') && (tok[idx] <= '9')) 
          idx++;
        if((tok[idx] == 'e') || (tok[idx] == 'E')) {
          idx++;
          if((tok[idx] == '+') || (tok[idx] == '-'))
            idx++;
          while((tok[idx] >= '0') && (tok[idx] <= '9')) 
            idx++;
        }
        real_end = idx;
        while((tok[idx] == ' ') || (tok[idx] == '\t'))
          idx++; // skip blanks 

        if(tok[idx] == '+')
          img_neg = false;
        else if(tok[idx] == '-')
          img_neg = true;
        else {
          System.out.println("Error, expected a + or -");
          error = true;
          err.append(Labels.invalid_complex[cur_lang] + token + "\n");
          continue;
        }

        idx++;
        try {
          while((tok[idx] == ' ') || (tok[idx] == '\t'))
            idx++; // skip blanks 
        }catch(ArrayIndexOutOfBoundsException e) {
          System.out.println("no imaginary part");
          error = true;
          err.append(Labels.no_imaginary[cur_lang] + 
            token + "\n");
          continue;
        }
        System.out.println("first char is: " + tok[idx]);
        img_start = idx;
        try {
          while((tok[idx] >= '0') && (tok[idx] <= '9')) 
            idx++;
        }catch(ArrayIndexOutOfBoundsException e) {
           System.out.println("tok ended with digits...OK");
           img_end = idx;

           temp_array[count] = 
              new Double(token.substring(real_start,real_end)).doubleValue();
            
           if(img_neg)
             temp_array[count+1] = new Double("-" + 
                token.substring(img_start,img_end)).doubleValue();
           else
             temp_array[count+1] =
               new Double(token.substring(img_start,img_end)).doubleValue();

           count += 2;
           continue;
        }
        if(tok[idx] == '.')
          idx++;
        try {
          while((tok[idx] >= '0') && (tok[idx] <= '9')) 
            idx++;
        }catch(ArrayIndexOutOfBoundsException e) {
          System.out.println("at end of line.. OK");
          img_end = idx;

          temp_array[count] = 
             new Double(token.substring(real_start,real_end)).doubleValue();
         
          if(img_neg)
            temp_array[count+1] = new Double("-" + 
               token.substring(img_start,img_end)).doubleValue();
          else
            temp_array[count+1] =
              new Double(token.substring(img_start,img_end)).doubleValue();

          count += 2;
          continue;
        }
        if((tok[idx] == 'e') || (tok[idx] == 'E')) {
            idx++;
          if((tok[idx] == '+') || (tok[idx] == '-'))
            idx++;
          try {
            while((tok[idx] >= '0') && (tok[idx] <= '9')) 
              idx++;
          }catch(ArrayIndexOutOfBoundsException e) {
            System.out.println("at end of line.. OK");
            img_end = idx;

            temp_array[count] = 
               new Double(token.substring(real_start,real_end)).doubleValue();
             
            if(img_neg)
              temp_array[count+1] = new Double("-" + 
                 token.substring(img_start,img_end)).doubleValue();
            else
              temp_array[count+1] =
                new Double(token.substring(img_start,img_end)).doubleValue();
 
            count += 2;
            continue;
          }
        }
         
        img_end = idx;
        extra = false;
        while(idx < token.length()) {
          if((tok[idx] != ' ') && (tok[idx] != '\t')) {
            extra = true;
            break;
          }
          idx++;
        }
        if(extra) {
          System.out.println("Extraneous stuff at end of token");
          error = true;
          err.append(Labels.invalid_complex[cur_lang] + token + " \n");
          continue;
        }
        
        temp_array[count] = 
           new Double(token.substring(real_start,real_end)).doubleValue();
       
        if(img_neg)
          temp_array[count+1] = new Double("-" + 
             token.substring(img_start,img_end)).doubleValue();
        else
          temp_array[count+1] =
            new Double(token.substring(img_start,img_end)).doubleValue();

        count += 2;
       }catch(ArrayIndexOutOfBoundsException e) {
         System.out.println("Incomplete Complex Number: "+token);
         error = true;
         err.append(Labels.incomplete_complex[cur_lang] + token + "\n");
       }
    } //while

    System.out.println("tok_count = " + tok_count);
    System.out.println("Complex array: " + temp_array.length + " elements");
    for(idx=0;idx<temp_array.length;idx+=2)
      System.out.println(temp_array[idx] + " " + temp_array[idx+1]);
    
    if(error) 
      return(null);

    if(data_type == NetSolveObject.NETSOLVE_C) {
      scomplex = new float[tok_count * 2];
      for(idx=0;idx<tok_count * 2;idx++) {
        scomplex[idx] = (float) temp_array[idx];
        System.out.println("scomplex ["+idx+"] = " + scomplex[idx]);
      }
      return(scomplex);
    }
    else {
      dcomplex = new double[tok_count * 2];
      for(idx=0;idx<tok_count * 2;idx++) {
        dcomplex[idx] = temp_array[idx];
        System.out.println("dcomplex ["+idx+"] = " + dcomplex[idx]);
      }
      return(dcomplex);
    }
  }

  private Vector check_data_input(String name, InputStream input, int idx,
     int obj_type, int data_type, StringBuffer err)
  {
    int last = 0, lines = 0, total_items = 0, prev = 0;
    boolean err_status = false, uneven = false;
    String temp=null;
    DataInputStream s = new DataInputStream(input);
    Vector vec = new Vector(100);
    Object items;

/*
    if(prob.upf && (idx == prob.nb_input - 1)) {
      if(name != null) {
        if(name.charAt(name.length() - 1) == 'c') {
          System.out.println("lang is C");
          vec.addElement(new Integer(GlobalDefs.LANG_C));
        }
        else {
          System.out.println("lang is FORTRAN");
          vec.addElement(new Integer(GlobalDefs.LANG_FORTRAN));
        }
      }
      else {
        vec.addElement(new Integer(lang_choice.getSelectedIndex()));
      }
    }
*/
    if(data_type == NetSolveObject.NETSOLVE_EXTERNAL) {
      if(name != null) {
        if(name.charAt(name.length() - 1) == 'c') {
          System.out.println("lang is C");
          vec.addElement(new Integer(GlobalDefs.LANG_C));
        }
        else {
          System.out.println("lang is FORTRAN");
          vec.addElement(new Integer(GlobalDefs.LANG_FORTRAN));
        }
      }
      else {
        vec.addElement(new Integer(lang_checked[idx]));
      }
    }

    try {
      while((temp = s.readLine()) != null) {
        this.yield();
        lines++;
        System.out.println("line "+lines);
        if((items = parse_line(temp,data_type,err)) == null) {
          err_status = true;
          total_items++;
          continue;
        }
        vec.addElement(items);
        switch(data_type) {
          case NetSolveObject.NETSOLVE_I:
            prev = ((int [])items).length;
            total_items += prev;
            break;
          case NetSolveObject.NETSOLVE_S:
            prev = ((float [])items).length;
            total_items += prev;
            break;
          case NetSolveObject.NETSOLVE_D:
            prev = ((double [])items).length;
            total_items += prev;
            break;
          case NetSolveObject.NETSOLVE_C:
            prev = ((float [])items).length / 2;
            total_items += prev;
            break;
          case NetSolveObject.NETSOLVE_Z:
            prev = ((double [])items).length / 2;
            total_items += prev;
            break;
          case NetSolveObject.NETSOLVE_CHAR:
            prev = ((char [])items).length;
            total_items += prev;
            break;
          case NetSolveObject.NETSOLVE_EXTERNAL:
            prev = 1;
            total_items += prev;
        }
        if((obj_type == NetSolveObject.NETSOLVE_MATRIX) && (last != 0) 
           && (last != prev)) {
              err_status = true;
              uneven = true;
        }
        last = prev;
      }
    }catch(IOException e) {
      System.out.println("what the hell?");
    }

    if(uneven)
      err.append(Labels.uneven_matrix[cur_lang] + "\n"); 

    if(total_items == 0) {
      err_status = true;
      err.append(Labels.empty_input[cur_lang] + "\n");
    }

    if((obj_type == NetSolveObject.NETSOLVE_SCALAR) && (total_items > 1))
      System.err.println("Warning: Scalar input requires only 1 item.");

    switch(obj_type) {
      case NetSolveObject.NETSOLVE_SCALAR:
        System.out.println("Scalar - "+total_items+" items");
        m[idx] = 1;
        n[idx] = 0;
        break;
      case NetSolveObject.NETSOLVE_VECTOR:
        System.out.println("Vector - m = " +total_items);
        m[idx] = total_items;
        n[idx] = 0;
        break;
      case NetSolveObject.NETSOLVE_MATRIX:
        System.out.println("Matrix - m = " + last + ", n = " +lines);
        m[idx] = last;
        n[idx] = lines;
    }
    if(err_status)
      return(null);
    else
      return(vec);
  }

  private FileInputStream open_file(int datatype, String filename, 
   StringBuffer err) {
    FileInputStream in;
    StringBuffer temp = new StringBuffer(500);
    int resp;

    if(datatype == NetSolveObject.NETSOLVE_EXTERNAL) {
      if(filename.length() < 2) {
        System.out.println("Invalid filename...Must end in .c or .f");
        err.append(Labels.invalid_file[cur_lang] + "\n");
        return(null);
      }

      if(filename.charAt(filename.length()-2) != '.') {
        System.out.println("Invalid filename...Must end in .c or .f");
        err.append(Labels.invalid_file[cur_lang] + "\n");
        return(null);
      }
      
      if(filename.charAt(filename.length()-1) == 'c') {
        System.out.println("language is C");
      }
      else if(filename.charAt(filename.length()-1) == 'f') {
        System.out.println("language is FORTRAN");
      }
      else {
        System.out.println("Invalid filename...Must end in .c or .f");
        err.append(Labels.invalid_file[cur_lang] + "\n");
        return(null);
      }
    }

    try {
      in = new FileInputStream(filename);
    } catch (FileNotFoundException e) {
      System.out.println("File not found");
      err.append(Labels.no_file[cur_lang]+filename+"\n");
      return(null);
    }
   
    return(in);
  }

  public void run() {
    int i,j,k;
    boolean data_err = false;
    StringBuffer temp = new StringBuffer(100);
    StringBuffer error_rpt = new StringBuffer(500);
    String [] errors;
    
    input_frame.set_status(Labels.checking_data[cur_lang]);
    errors = new String[prob.nb_input];
    v = new Vector[prob.nb_input];
    for(i=0;i<prob.nb_input;i++) {
      if(checked[i] == GlobalDefs.FILE_INPUT) {
        temp.setLength(0);
        FileInputStream fs = open_file(prob.inputs[i].data_type,
                                filename[i],temp);
        if(fs == null) {
          System.out.println("ERROR in your data");
          errors[i] = new String(temp.toString());
          data_err = true;
        }
        else {
          if((v[i] = check_data_input(filename[i],fs,i,
            prob.inputs[i].object_type,prob.inputs[i].data_type,temp)) == null) {
               System.out.println("ERROR in your data");
               errors[i] = new String(temp.toString());
               data_err = true;
          }

          try {
            fs.close();
          }catch(IOException e) {
            System.err.println("Can't close FileInputStream, but I don't care.");
          }
        }
      }
      else if(checked[i] == GlobalDefs.URL_INPUT) {
        InputStream url_input = null;
        byte [] head = new byte[4];
        byte b;
        int loop_count=0;

        temp.setLength(0);
        System.out.println("Going to try to read input data from URL: " + filename[i]);
        
        try {
           url_input = new URL(filename[i]).openStream();
          
           /* Sometimes the http server returns a bunch of header
              information which will screw up things on the server
              side if we don't strip it off first.  The following
              bit of code attempts to determine if there's an http
              header and if so, strips it off.  I thought the URL
              class would have a way to return only the content
              but I couldn't find one (even getContent() returned
              the headers.  */

           url_input.read(head, 0, 4);

           if(head[0]=='H' && head[1]=='T' && head[2]=='T' && head[3]=='P')
           {
             //server sent us some http crap that we need to strip off
             while(true) {
               if(loop_count++ > 200)  // guard against infinite loops
                 throw new IOException("Weird Header");

               while((b = (byte) url_input.read()) != '\n') {
                 if(b == -1)
                   throw new IOException("Weird Header");
               }   

               b = (byte) url_input.read();
               if(b == '\n') {
                 // we're done
                 break;
               }
               else if(b == '\r') {
                 // we're almost done
                 url_input.read();
                 break;
               }
             }
           }
           else {
             url_input.reset();
           }
        } catch (java.net.MalformedURLException e) {
           System.err.println("Bad URL: " + e.getMessage());
           errors[i] = new String(Labels.bad_url[cur_lang]);
           data_err = true;
        } catch (IOException e2) {
           System.err.println("Couldn't open stream to url");
           errors[i] = Labels.stream_err[cur_lang] + e2.getMessage();
           data_err = true;
        }

        if(url_input != null) {
          if((v[i] = check_data_input(filename[i],url_input,i,
            prob.inputs[i].object_type,prob.inputs[i].data_type,temp)) == null) {
               System.out.println("ERROR in your data");
               errors[i] = new String(temp.toString());
               data_err = true;
          }

          try {
            url_input.close();
          }catch(IOException e3) {
            System.err.println("Can't close InputStream, but I don't care.");
          }
        }
      }
      else if(checked[i] == GlobalDefs.DATA_INPUT) {

        StringBufferInputStream sb = new StringBufferInputStream(data[i]);

        temp.setLength(0);
        if((v[i] = check_data_input(null,sb,i,
           prob.inputs[i].object_type,prob.inputs[i].data_type,temp)) == null) {
             System.out.println("ERROR in your data");
             errors[i] = new String(temp.toString());
             data_err = true;
        }

        try {
          sb.close();
        }catch(IOException e) {
          System.err.println("Can't close StringBufferInputStream, but I don't care.");
        }
      }
      else {
        System.out.println(
          "Error - you must enter a file or some data for input "+i);
        errors[i] = new String(Labels.no_input[cur_lang]+i);
        data_err = true;
      }
    }

    input_frame.set_status(Labels.good_data[cur_lang]);

    System.out.println("dimensions: ");
    for(i=0;i<prob.nb_input;i++) {
      System.out.println("Object " + i + ":");
      System.out.println("    m = " + m[i]);
      System.out.println("    n = " + n[i]);
    }

    System.out.println("DATA:");
    for(i=0;i<prob.nb_input;i++) {
     if(v[i] != null) {
      switch(prob.inputs[i].data_type) {
        case NetSolveObject.NETSOLVE_I:
          for(j=0;j<v[i].size();j++) {
            for(k=0;k< ((int [])v[i].elementAt(j)).length;k++)
              System.out.println( ((int [])v[i].elementAt(j))[k]);
          }
          break;
        case NetSolveObject.NETSOLVE_S:
          for(j=0;j<v[i].size();j++) {
            for(k=0;k< ((float [])v[i].elementAt(j)).length;k++)
              System.out.println( ((float [])v[i].elementAt(j))[k]);
          }
          break;
        case NetSolveObject.NETSOLVE_D:
          for(j=0;j<v[i].size();j++) {
            for(k=0;k< ((double [])v[i].elementAt(j)).length;k++)
              System.out.println( ((double [])v[i].elementAt(j))[k]);
          }
          break;
        case NetSolveObject.NETSOLVE_C:
          for(j=0;j<v[i].size();j++) {
            for(k=0;k< ((float [])v[i].elementAt(j)).length;k+=2)
              System.out.println( ((float [])v[i].elementAt(j))[k] + " " +
                ((float [])v[i].elementAt(j))[k+1]);
          }
          break;
        case NetSolveObject.NETSOLVE_Z:
          for(j=0;j<v[i].size();j++) {
            for(k=0;k< ((double [])v[i].elementAt(j)).length;k+=2)
              System.out.println( ((double [])v[i].elementAt(j))[k] + " " +
                ((double [])v[i].elementAt(j))[k+1]);
          }
          break;
        case NetSolveObject.NETSOLVE_CHAR:
          for(j=0;j<v[i].size();j++) {
            for(k=0;k< ((char [])v[i].elementAt(j)).length;k++)
              System.out.println( ((char [])v[i].elementAt(j))[k]);
          }
          break;
        case NetSolveObject.NETSOLVE_EXTERNAL:
          for(j=1;j<v[i].size();j++)
            System.out.println((String)v[i].elementAt(j));
          break;
      }
     }
    }
    
    input_frame.set_status(Labels.submitting[cur_lang]);

    if(!data_err) {
      System.out.println("ok... data looks good, submitting the job");

      try {
        SubmitJob sub = new SubmitJob(pframe,agent,prob,v,filename,
            m,n,parentID + "." + id);
      }catch(NetSolveException e) {
        System.out.println("Could not submit job: "+e);
        NetSolveWarning solve_warn = new NetSolveWarning(pframe,
          "SubmitJob: "+e.getMessage());
      }
    }
    else {
      System.out.println(
         "Not submitting your data because of the following errors:");
      error_rpt.append(Labels.no_submit[cur_lang] + "\n\n");
      for(i=0;i<prob.nb_input;i++)
        if(errors[i] != null) {
          System.out.println("Input "+i+": ");
          error_rpt.append(Labels.input[cur_lang]+i+": \n");
          System.out.println(errors[i]);
          error_rpt.append(errors[i] + "\n");
        }
      TextScreen el = new TextScreen(Labels.bad_data[cur_lang],
         error_rpt.toString());
    }
  }
}
