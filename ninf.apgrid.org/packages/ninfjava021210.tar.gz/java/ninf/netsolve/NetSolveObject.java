package ninf.netsolve;

import ninf.client.BufferObject;
import ninf.client.NinfVal;
import ninf.client.NinfParamDesc;
import ninf.client.NinfDimParam;
import ninf.client.NinfDimParamElem;
import ninf.client.NinfExpression;
import ninf.basic.*;
import ninf.basic.NinfException;

/*  defined in NinfVal
  static final int       VALUE_CONST = 1;	default, give by constant 
  static final int       VALUE_IN_ARG = 2;	specified by IN scalar paramter 
  static final int       VALUE_BY_EXPR = 3; 	 computed by interpreter 
*/


public class NetSolveObject{
  static NinfLog dbg = new NinfLog("NetSolveObject");

  public static final int        NETSOLVE_I = 1;
  public static final int        NETSOLVE_S = 2;
  public static final int        NETSOLVE_D = 3;
  public static final int        NETSOLVE_C = 4;
  public static final int        NETSOLVE_Z = 5;
  public static final int     NETSOLVE_CHAR = 6;
  public static final int NETSOLVE_EXTERNAL = 7;

  public static final int   NETSOLVE_MATRIX = 1;
  public static final int   NETSOLVE_VECTOR = 2;
  public static final int   NETSOLVE_SCALAR = 3;
  public static final int   NETSOLVE_UPF    = 4;

  public int data_type;
  public int object_type;

  public String description;

  ObjectProperty property;

  NetSolveObject(){
  }

  public NetSolveObject(int ninfDataType, int ninfDim) throws CannotConvertException{
    data_type = getNetSolveType(ninfDataType);
    object_type = getObjectType(ninfDim);
  }
  
  public String toString(){
    return datatype2str(data_type) + ", " + objtype2str(object_type) + ":" + 
      ((property != null) ? property.toString() : "");
  }

  
  void setProperty(ObjectProperty property){
    this.property = property;
  }

  void mergeProperty (ObjectProperty property){
    this.property.merge(property);
    this.property = property;
  }


  public static String datatype2str(int data_type) {
    switch(data_type) {
      case NetSolveObject.NETSOLVE_I:
        return(new String("Integer"));
      case NetSolveObject.NETSOLVE_S:
        return(new String("Float"));
      case NetSolveObject.NETSOLVE_D:
        return(new String("Double"));
      case NetSolveObject.NETSOLVE_C:
        return(new String("Complex"));
      case NetSolveObject.NETSOLVE_Z:
        return(new String("Double Complex"));
      case NetSolveObject.NETSOLVE_CHAR:
        return(new String("Char"));
      case NetSolveObject.NETSOLVE_EXTERNAL:
        return(new String("User Provided Function"));
      default:
        return(new String("UNKNOWN DATA TYPE"));
    }
  }
 
  public static String objtype2str(int obj_type) {
    switch(obj_type) {
      case NetSolveObject.NETSOLVE_MATRIX:
        return(new String("Matrix"));
      case NetSolveObject.NETSOLVE_VECTOR:
        return(new String("Vector"));
      case NetSolveObject.NETSOLVE_SCALAR:
        return(new String("Scalar"));
      case NetSolveObject.NETSOLVE_UPF:
        return(new String("UPF"));
      default:
        return(new String("UNKNOWN OBJECT TYPE"));
    }
  }

  public static int getNinfType(int data_type) throws NetSolveException{
    switch(data_type) {
      case NetSolveObject.NETSOLVE_I:
        return NinfVal.INT;
      case NetSolveObject.NETSOLVE_S:
        return NinfVal.FLOAT;
      case NetSolveObject.NETSOLVE_D:
        return NinfVal.DOUBLE;
      case NetSolveObject.NETSOLVE_CHAR:
        return NinfVal.CHAR;
      case NetSolveObject.NETSOLVE_C:
        return NinfVal.SCOMPLEX;
      case NetSolveObject.NETSOLVE_Z:
        return NinfVal.DCOMPLEX;
      default:
	throw new NetSolveException();	
    }
  }
  public static int getNinfDim(int obj_type) throws NetSolveException{
    switch(obj_type) {
      case NetSolveObject.NETSOLVE_MATRIX:
	return 2;
      case NetSolveObject.NETSOLVE_VECTOR:
	return 1;
      case NetSolveObject.NETSOLVE_SCALAR:
	return 0;
      default:
	throw new NetSolveException();
    }
  }

  public static int getNetSolveType(int data_type) throws CannotConvertException{
    switch(data_type) {
      case NinfVal.INT:
        return NetSolveObject.NETSOLVE_I;
      case NinfVal.FLOAT:
        return NetSolveObject.NETSOLVE_S;
      case NinfVal.DOUBLE:
	return NetSolveObject.NETSOLVE_D;
      case NinfVal.CHAR:
        return NetSolveObject.NETSOLVE_CHAR;
      case NinfVal.SCOMPLEX:
        return NetSolveObject.NETSOLVE_C;
      case NinfVal.DCOMPLEX:
        return NetSolveObject.NETSOLVE_Z;
      default:
	throw new CannotConvertException();	
    }
  }

  public static int getObjectType(int ndim) throws CannotConvertException{
    switch (Math.abs(ndim)){
    case 0:
      return NetSolveObject.NETSOLVE_SCALAR;
    case 1:
      return NetSolveObject.NETSOLVE_VECTOR;
    case 2:
      return NetSolveObject.NETSOLVE_MATRIX;
    default:
      throw new CannotConvertException();
    }
  }

  boolean setParamDesc(NinfParamDesc tmp) throws NetSolveException{
    tmp.ndim = getNinfDim(object_type);
    dbg.println("ndim = " + tmp.ndim);
    tmp.param_type = getNinfType(data_type);
    if (tmp.ndim == 0){
      if (tmp.param_inout == NinfParamDesc.MODE_OUT){
	tmp.ndim = 1;
	tmp.dim[0] = new NinfDimParam(new NinfDimParamElem(NinfVal.VALUE_CONST, 1));
      }
      return true;
    }
    if (tmp.ndim == 1){
      ObjectChar propm;
	
      if (property.m == null)
	tmp.ndim = -1;
      propm = (property.m != null)? property.m : new ObjectChar(NinfVal.VALUE_IN_HEADER, -1);
      tmp.dim[0] = new NinfDimParam(new NinfDimParamElem(propm.flag, propm.value, propm.exp));
    }
    if (tmp.ndim == 2){
      ObjectChar propn, propm, propl;
      if (property.n == null || property.m == null)
	tmp.ndim = -2;
      propn = (property.n != null)? property.n : new ObjectChar(NinfVal.VALUE_IN_HEADER, -1);
      propm = (property.m != null)? property.m : new ObjectChar(NinfVal.VALUE_IN_HEADER, -1);
      propl = (property.l != null)? property.l : propm;
      
      tmp.dim[1] = new NinfDimParam(new NinfDimParamElem(propn.flag, propn.value, propn.exp));
      tmp.dim[0] = new NinfDimParam(new NinfDimParamElem(propl.flag, propl.value, propl.exp),
				    new NinfDimParamElem(propm.flag, propm.value, propm.exp));
    }
    return true;
    
  }

  /****************** For Netsolve - Ninf Conversion*******************/
  void readInto(XDRInputStream is, BufferObject bo) throws NinfException{
    try {
      int m = 0, n = 0;
      switch (object_type){
      case NETSOLVE_MATRIX:
	dbg.println("reading matrix");
	m = is.readInt();
	n = is.readInt();
	bo.sizes = new int[2];
	bo.sizes[0] = m;
	bo.sizes[1] = n;
	bo.data = new byte[getSize(data_type) * m * n];
	dbg.println("reading size: " + bo.data.length);
	is.readFully(bo.data);
	break;
      case NETSOLVE_VECTOR:
	dbg.println("reading vector");
	m = is.readInt();
	dbg.println(FormatString.format("%x", new Integer(m)));
	bo.sizes = new int[1];
	bo.sizes[0] = m;
	bo.data = new byte[getSize(data_type) * m];
	dbg.println("reading size: " + bo.data.length);
	is.readFully(bo.data);
	break;
      case NETSOLVE_SCALAR:
	dbg.println("reading scalar");
	bo.sizes = new int[0];
	bo.data = new byte[getSize(data_type)];
	dbg.println("reading size: " + bo.data.length);
	is.readFully(bo.data);
	break;
      default:
	throw new CannotConvertException();
      } 
    } catch (Exception e){
      e.printStackTrace();
      throw new NinfException();
    }
  }

  void writeOut(XDROutputStream os, BufferObject bo) throws NinfException{
    try {
      switch (object_type){
      case NETSOLVE_MATRIX:
	dbg.println("writing matrix: " + bo.sizes[0] + ", " + bo.sizes[1]);
	os.writeInt(bo.sizes[0]);
	os.writeInt(bo.sizes[1]);
	os.write(bo.data);
	break;
      case NETSOLVE_VECTOR:
	dbg.println("writing vector: " + bo.sizes[0]);
	os.writeInt(bo.sizes[0]);
	os.write(bo.data);
	break;
      case NETSOLVE_SCALAR:
	dbg.println("writing scalar");
	os.write(bo.data);
	break;
      default:
	throw new CannotConvertException();
      } 
    } catch (Exception e){
      e.printStackTrace();
      throw new NinfException();
    }
  }

  int getSize(int data_type) throws CannotConvertException{
    switch(data_type){
    case NETSOLVE_I:
      return 4;
    case NETSOLVE_S:
      return 4;
    case NETSOLVE_D:
      return 8;
    case NETSOLVE_C:
      return 8;
    case NETSOLVE_Z:
      return 16;
    case NETSOLVE_CHAR:
      return 4;
    default:
      throw new CannotConvertException();
    }
  }

  static NetSolveObject readPartial(XDRInputStream is) throws java.io.IOException{
    NetSolveObject tmp = new NetSolveObject();
    tmp.data_type = is.readInt();
    tmp.object_type = is.readInt();
    return tmp;
  }
  static NetSolveObject readFull(XDRInputStream is) throws java.io.IOException{
    NetSolveObject tmp = new NetSolveObject();
    tmp.data_type = is.readInt();
    tmp.object_type = is.readInt();
    tmp.description = is.readString();
    return tmp;
  }

  void writeFull(XDROutputStream os) throws java.io.IOException{
    os.writeInt(data_type);
    os.writeInt(object_type);
    os.writeString(description == null ? "": description);
  }

  boolean partialEqual(NetSolveObject other){
    return (data_type == other.data_type && 
	    object_type == other.object_type);
    
  }

} // End class NetSolveObject
