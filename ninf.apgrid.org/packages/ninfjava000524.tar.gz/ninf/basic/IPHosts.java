package ninf.basic;

import java.util.*;
import java.net.*;

/** to represent host restriction based on IPAddress */
public class IPHosts{
  static final String CLASS_C = "CLASS_C";
  static final String CLASS_B = "CLASS_B";
  static final String HOST_MASK    = "255.255.255.255";
  static final String CLASS_C_MASK = "255.255.255.0";
  static final String CLASS_B_MASK = "255.255.0.0";


  private boolean addmaskflag;
  private byte address[];
  private byte mask[];

  public IPHosts(byte[] address, byte[] mask, boolean addmaskflag){
    this.addmaskflag = addmaskflag;
    this.address = address;
    this.mask = mask;
  }

  public IPHosts(String address, String mask) throws NinfException{
    String orgmask = mask;
    if (mask == null || mask.equals(""))
      mask = HOST_MASK;
    else if (mask.equals(CLASS_C))
      mask = CLASS_C_MASK;
    else if (mask.equals(CLASS_B))
      mask = CLASS_B_MASK;
    InetAddress addr = null;
    try {
      addr = InetAddress.getByName(address);
    } catch (UnknownHostException e){
      if (orgmask == null){
	parseHosts(this, address);
	return;
      }
      throw new NinfException("cannot parse: " + address + ", " + mask);
    }
    this.address = addr.getAddress();
    try {
      addr = InetAddress.getByName(mask);
    } catch (UnknownHostException e){
      throw new NinfException("cannot parse: " + address + ", " + mask);
    }
    this.mask = addr.getAddress();
    this.addmaskflag = true;
  }

  private static void parseHosts(IPHosts iphosts, String address) 
    throws NinfException{
    StringTokenizer st = new StringTokenizer(address, ".");
    String a[] = new String[4];
    byte b[] = new byte[4];
    byte b_u[] = new byte[4];
    try {
      for (int i = 0; i < 4; i++)
	a[i] = st.nextToken();
      for (int i = 0; i < 3; i++){
	b[i]   = (byte)(new Integer(a[i]).intValue());
	b_u[i] = (byte)(new Integer(a[i]).intValue());
      }
      StringTokenizer st2 = new StringTokenizer(a[3], "-");
      String a1 = st2.nextToken();
      String a2 = st2.nextToken();
      b[3]    = (byte)(new Integer(a1).intValue());
      b_u[3]  = (byte)(new Integer(a2).intValue());
      iphosts.address = b;
      iphosts.mask = b_u;
      iphosts.addmaskflag = false;
    } catch (NoSuchElementException e){
	e.printStackTrace();
      throw new NinfException("cannot parse "+ address);
    } catch (NumberFormatException e){
	e.printStackTrace();
      throw new NinfException("cannot parse "+ address);
    }
  }


  boolean includes(byte[] address){
    if (this.addmaskflag){
      for (int i = 0; i < 4; i++){
	if ((this.address[i] & this.mask[i]) !=
	    (        address[i] & this.mask[i]))
	  return false;
      }
      return true;
    } else {
      for (int i = 0; i < 3; i++){
	if ((this.address[i] != address[i]))
	  return false;
      }
      if ((this.address[3] <= address[3]) &&
	  (this.mask[3]    >= address[3]) )
	return true;
      return false;
    }
  }

  public String toString(){
    if (addmaskflag)
      return FormatString.format("%d.%d.%d.%d, \tmask:%d.%d.%d.%d",
	    new Integer(0xff & address[0]),new Integer(0xff & address[1]),
	    new Integer(0xff & address[2]),new Integer(0xff & address[3]),
	    new Integer(0xff & mask[0]),new Integer(0xff & mask[1]),
	    new Integer(0xff & mask[2]),new Integer(0xff & mask[3]));
    else
      return FormatString.format("%d.%d.%d.%d-%d",
	    new Integer(0xff & address[0]),new Integer(0xff & address[1]),
	    new Integer(0xff & address[2]),new Integer(0xff & address[3]),
	    new Integer(0xff & mask[3]));
  }


}

