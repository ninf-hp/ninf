#define _WRAPPER_
/* $Id: psstebz_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define FLOAT
#include <gscalapack.h>
static  int worklen(int n){
    int ret=1;
    ret = MAX( 5*n, 7 );
    return ret;
}

static  int iworklen(int n){
      int ret = 1;
      ret = MAX( 4*n, 14 );
    return ret;
}


void  psstebz_ninf(	 char range,
		 char order,
		 int n,
		 float vl,
		 float vu,
		 int il,
		 int iu,
		 float abstol,
		 float d[],
		 float e[],
		 int *m,
		 int *nsplit,
		 float w[],
		 int iblock[],
		 int isplit[],
		 float work[],
		 int iwork[],
		 int *info
)
/* "psstebz computes the eigenvalues of a symmetric tridiagonal matrix in parallel. The user may ask for all eigenvalues, all eigenvalues in the interval [VL, VU], or the eigenvalues indexed IL through IU. " */
/* OPTIONS */
{

  int maxldd;

  int locm[1];
  int locnsplit[1];
  
  float *locw=NULL;
  int *lociblock=NULL;
  int *locisplit=NULL;
  
  float *locwork=NULL;
  int llocwork;
  int *lociwork=NULL;
  int llociwork;

  INITIALIZE();

  SCALAR( "char", range);
  SCALAR( "char", order);
  SCALAR( "int", n);
  SCALAR( "float", vl);
  SCALAR( "float", vu);
  SCALAR( "int", il);
  SCALAR( "int", iu);
  SCALAR( "float", abstol);

  /* MATRIX <- d,e */

  COMMON( "float", d, n);
  COMMON( "float", e, n-1);

  locw = MALLOC(sizeof(float)*n); assert(locw);
  lociblock = MALLOC(sizeof(int)*n); assert(lociblock);
  locisplit = MALLOC(sizeof(int)*n); assert(locisplit);
  
  llocwork=worklen(n);
  WORK(locwork,llocwork);
  llociwork=iworklen(n);
  IWORK(lociwork, llociwork);
  
  if  (( mypnum != 0 ) ^ (serial==1) )
    FortranCall(psstebz)( &PARA_CTXT, &range, &order, &n,
			  &vl, &vu, &il, &iu, &abstol,
			  d, e,
			  locm, locnsplit,
			  locw, lociblock, locisplit,
			  locwork, &llocwork,
			  lociwork, &llociwork,
			  &linfo);

  RETRIEVE("float", locw, n);
  RETRIEVE("int", locm, 1);
  RETRIEVE("int", locnsplit, 1);
  RETRIEVE("int", lociblock, n);
  RETRIEVE("int", locisplit, n);
  RETRIEVE("int", &linfo, 1);

  if( mypnum == 0 ){
    int i;
    *info = linfo;
    *m = *locm;
    *nsplit = *locnsplit;
    for(i=0;i<n;i++) w[i] = locw[i];
    for(i=0;i<n;i++)  iblock[i] = lociblock[i];
    for(i=0;i<n;i++)  isplit[i] = locisplit[i];
  } else {
  }
  
  FREE_COMMON(d);
  FREE_COMMON(e);
  
  FREE(locw);
  FREE(lociblock);
  FREE(locisplit);
  
}

void  pslaebz_ninf(	 int ijob,
		 int n,
		 int mmax,
		 int minp,
		 float abstol,
		 float reltol,
		 float pivmin,
		 float d[],
		 int nval[],
		 float intvl[],
		 int intvlct[],
		 int *mout,
		 float *lsave,
		 int ieflag,
		 int *info
)
/* "pslaebz contains the iteration loop which computes the eigenvalues contained in the input intervals [ INTVL(2*j-1), INTVL(2*j) ] where j = 1,...,MINP. It uses and computes the function N(w), which is the count of eigenvalues of a symmetric tridiagonal matrix less than or equal to its argument w." */
/* OPTIONS */
{


  INITIALIZE();

  SCALAR("int",ijob);
  SCALAR("int",n);
  SCALAR("int",mmax);
  SCALAR("int",minp);
  SCALAR("float",abstol);
  SCALAR("float",reltol);
  SCALAR("float",pivmin);
  SCALAR("int",ieflag);


  COMMON( "float", d, 2*n-1);
  COMMON( "int", nval, 4);
  COMMON( "int", intvl, 2*mmax);
  COMMON( "int", intvlct, 2*mmax);
  COMMON("int", mout, 1);
  COMMON("float", lsave, 1);

  if  (( mypnum != 0 ) ^ (serial==1) )
    FortranCall(pslaebz)( &ijob, &n, &mmax, &minp, &abstol, &reltol, &pivmin, d, nval, intvl, intvlct, mout, lsave, &ieflag, &linfo);

  RETRIEVE("int", nval, 4);
  RETRIEVE( "int", intvl, 2*mmax);
  RETRIEVE( "int", intvlct, 2*mmax);
  RETRIEVE("int", mout, 1);
  RETRIEVE( "float", lsave, 1);
  RETRIEVE("int", &linfo, 1);

  if( mypnum == 0 ){
    *info = linfo;
  } else {
  }

    FREE_COMMON(lsave);
    FREE_COMMON(mout);
    FREE_COMMON(d);
    FREE_COMMON(intvl);
    FREE_COMMON(intvlct);
  
}


void  pslaecv_ninf(	 int ijob,
		 int *kf,
		 int kl,
		 float intvl[],
		 int intvlct[],
		 int nval[],
		 float abstol,
		 float reltol
)
/* "pslaecv checks if the input intervals [ INTVL(2*i-1), INTVL(2*i) ], i = KF, ... , KL-1, have 'converged'. pslaecv modifies KF to be the index of the last converged interval, i.e., on output, all intervals [ INTVL(2*i-1), INTVL(2*i) ], i < KF,  have converged. Note that the input intervals may be reordered by pslaecv." */
/* OPTIONS */
{
	int maxldd;
	int oldkf;

	INITIALIZE();

	SCALAR("int",ijob);


	SCALAR("int",kl);
	SCALAR("float",abstol);
	SCALAR("float",reltol);

	COMMON("int",kf,1);
	COMMON( "int", intvl, 2*(kl-*kf));
	COMMON( "int", intvlct, 2*(kl-*kf));
	COMMON( "int", nval, 2*(kl-*kf));
	oldkf = *kf;

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pslaecv)( &ijob, kf, &kl, intvl, intvlct, nval, &abstol, &reltol);

	RETRIEVE( "int", intvl, 2*(kl-oldkf));
	RETRIEVE( "int", intvlct, 2*(kl-oldkf));
	RETRIEVE( "int", nval, 2*(kl-oldkf));

	if( mypnum == 0 ){
	} else {
	}
	FREE_COMMON(kf);
	FREE_COMMON(intvl);
	FREE_COMMON(intvlct);
	FREE_COMMON(nval);
}



void  pslapdct_ninf(	 float sigma,
		 int n,
		 float d[],
		 float pivmin,
		 int *count
)
/* "pslapdct counts the number of negative eigenvalues of (T - SIGMA I). This implementation of the Sturm Sequence loop has conditionals in the innermost loop to avoid overflow and determine the sign of a floating point number. " */
/* OPTIONS */
{


	INITIALIZE();

	SCALAR("float",sigma);
	SCALAR("int",n);
	SCALAR("float",pivmin);
	
	COMMON( "float", d, 2*n-1);
	COMMON("int", count, 1);

	if  (( mypnum != 0 ) ^ (serial==1) )
		FortranCall(pslapdct)( &sigma, &n, d, &pivmin, count);

	
	RETRIEVE("int", count, 1);

	if( mypnum == 0 ){
	} else {

	}
	FREE_COMMON(d);
	FREE_COMMON(count);
	
}
