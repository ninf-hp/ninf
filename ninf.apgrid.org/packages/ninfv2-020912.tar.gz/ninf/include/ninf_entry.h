/*
 *  $Id: ninf_entry.h,v 1.3 2001/01/15 07:35:58 nakada Exp $
 */

#ifndef _NINF_ENTRY_H_
#define _NINF_ENTRY_H_

typedef struct ninf_entry{
  char * host;
  char * port;
  char * entry;
} ninf_entry;
ninf_entry * new_ninf_entry(char * p);
ninf_entry * ninf_entry_copy(ninf_entry * e);
void destruct_ninf_entry(ninf_entry * e);

#endif /* _NINF_ENTRY_H_ */
