package ninf.cproxy;
import ninf.basic.*;
import ninf.common.*;
import ninf.client.*;

class ServerTablePinger extends ServerTablePingerRoot {
  ServerTable table;

  ServerTablePinger(MetaServerReference target, int interval, ServerTable table){
    super(target, interval);
    this.table = table;
  }

  public void addNewServer(NinfServerStruct serverStruct){
      table.addNewServer(new NinfServerStructComm(serverStruct));    
  }
}

