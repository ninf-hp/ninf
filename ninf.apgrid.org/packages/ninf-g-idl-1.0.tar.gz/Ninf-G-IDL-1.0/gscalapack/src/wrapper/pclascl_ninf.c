#define _WRAPPER_
/* $Id: pclascl_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define SCOMPLEX
#include <gscalapack.h>

#define ROW_a lda
#define COL_a m
void  pclascl_ninf(	 char type,
		 int dummy_kl,
		 int dummy_ku,
		 float cfrom,
		 float cto,
		 int m,
		 int n,
		 scomplex global_a[],
		 int lda,
		 int *info
)
/* "pclascl multiplies the M-by-N complex distributed matrix A by the real scalar CTO/CFROM.  This is done without over/underflow as long as the final result CTO * A(I,J) / CFROM does not over/underflow. TYPE specifies that A may be full, upper triangular, lower triangular or upper Hessenberg." */
/* OPTIONS */
{
	int maxldd;

	int maxlda;
	scomplex *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
	int row_loca, col_loca;

	INITIALIZE();

	SCALAR( "char", type);
	SCALAR( "float", cfrom);
	SCALAR( "float", cto);
	SCALAR( "int", m);
	SCALAR( "int", n);
	SCALAR("int",lda);

	ROW( a);
	COL( a);
	MAXLDD( maxldd, a );
	maxlda = maxldd;

	MATRIX( "scomplex", a, ROW_a, COL_a);
	DISTRIBUTE( "scomplex", a, ROW_a  , COL_a);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pclascl)( &type,
                               &cfrom, &cto,
                               &m, &n,
                               loca, &one, &one, desca,
                               &linfo);

	GATHER( "scoomplex", a, ROW_a, COL_a);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
		*info = linfo;
	} else {
	}

	FREE_MATRIX(a);
}

