package ninf.basic;

import java.util.Vector;

public class SortedVector{
  Vector vec;

  public SortedVector(){
    vec = new Vector();
  }
  public void addElement(Comparable o){
    for (int i = 0; i < vec.size(); i++){
      Comparable tmp = (Comparable)vec.elementAt(i);
      if (tmp.greaterOrEqual(o)){
	vec.insertElementAt(o, i);
	return;
      }
    }
    vec.addElement(o);
  }

  public Vector contents(){
    return vec;
  }

  public int size(){
    return vec.size();
  }
}
