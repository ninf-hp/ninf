package ninf.metaserver;
import ninf.basic.*;

public class RequestID{
  public String cproxyHost;
  public int cproxyPort;
  public int serial;
  public FunctionName funcName;

  RequestID(String cproxyHost, int cproxyPort, int serial){
    this.cproxyHost = cproxyHost;
    this.cproxyPort = cproxyPort;
    this.serial =     serial;
  }
  RequestID(String cproxyHost, String cproxyPort, String serial){
    this.cproxyHost = cproxyHost;
    this.cproxyPort = (new Integer(cproxyPort)).intValue();
    this.serial =     (new Integer(serial)).intValue();
  }

  public int hashCode(){
    return cproxyHost.hashCode() + cproxyPort + serial;
  }

  public boolean equals(Object o){
    if (!(o instanceof RequestID))
      return false;
    RequestID s = (RequestID)o;
    if (cproxyHost.equals(s.cproxyHost) && cproxyPort == s.cproxyPort && 
	serial == s.serial)
      return true;
    return false;
  }

  public String toString(){
    return cproxyHost +":"+cproxyPort+"/"+serial;
  }
}
