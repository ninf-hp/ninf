#define _WRAPPER_
/* $Id: pctrtri_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define SCOMPLEX
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n
void  pctrtri_ninf(	 char uplo,
		 char diag,
		 int n,
		 scomplex global_a[],
		 int lda,
		 int *info
)
/* "pctrtri computes the inverse of a upper or lower triangular distributed matrix A." */
/* OPTIONS */
{
    extern void FortranCall(pctrtri)( char*, char*, int*,
				      scomplex*, int*, int*, int*,
				      int*);

	int maxldd;
	int maxlda;
	scomplex *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
	int row_loca, col_loca;

	INITIALIZE();

	SCALAR( "char", uplo);
	SCALAR( "char", diag);
	SCALAR( "int", lda);
	SCALAR( "int", n);

	ROW( a);
	COL( a);
	MAXLDD( maxldd, a );
	maxlda = maxldd;

	trMATRIX( uplo, "scomplex", a, ROW_a, COL_a);
	trDISTRIBUTE( uplo, "scomplex", a, ROW_a, COL_a);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pctrtri)( &uplo, &diag, &n,
			       loca, &one, &one, desca,
			       &linfo);

	GATHER( "scomplex", a, ROW_a, COL_a);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
		*info = linfo;
	} else {
	}

	FREE_MATRIX(a);
}

