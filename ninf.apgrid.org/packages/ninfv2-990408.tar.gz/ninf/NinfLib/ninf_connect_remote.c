#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#ifndef WIN32
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#else
#include <windows.h>
#include <Winsock.h>
#endif
#include <errno.h>
#include <string.h>
#include "ninf_error.h"
#include "ninf_macros.h"

#define TUNNEL_PROGRAM "ninf_tunnel"

#ifndef WIN32
int ninf_connect_remote_privileged(char * hostname, char * service){
  int fd[2];
  int pid;
  char buffer[10];
  if (socketpair(AF_UNIX, SOCK_STREAM, 0, fd) < 0){
    perror("socketpair");
    return -1;
  }
  if ((pid = fork()) == 0){
    sprintf(buffer, "%d", fd[0]);
    close(fd[1]);
    if (execlp(TUNNEL_PROGRAM, TUNNEL_PROGRAM, buffer, hostname, service, NULL))
      perror("execl failed:");
  }
  if (pid < 0){
    perror("fork error");
    return -1;
  }
  close(fd[0]);
  return fd[1];
}
#else
int ninf_connect_remote_privileged(char * hostname, char * service){
	return ninf_connect_remote(hostname, service);
}
#endif

/* returns socket if succeed, return -1 if failed */ 
int ninf_connect_remote(char * hostname, char * service)
{
  int s,size;
  struct sockaddr_in peer;
  struct hostent *hp;
  struct servent *sp;

#ifdef WIN32
  WSADATA Data;
  WSAStartup(MAKEWORD(1,1), &Data);
#endif

  if (hostname != NULL){
    hp = gethostbyname(hostname);
    if (hp == NULL){
      ninf_debug("%s: unknown hostname\n", hostname);
      return -1;
    }
#ifdef __j90__
    memcpy(&peer.sin_addr.s_da,hp->h_addr,hp->h_length);
#else
    memcpy((char *)(&peer.sin_addr.s_addr),hp->h_addr,hp->h_length);
#endif 

  } else
    peer.sin_addr.s_addr = INADDR_ANY; /* default, current host */
  
  if (service == NULL || atoi(service) == 0)
    service = NINF_SERVER_PORT;
  
  peer.sin_port = atoi(service);
  peer.sin_port = htons(peer.sin_port);	/* in net order */
  
  /* make connenction to ninf_server */
  peer.sin_family = AF_INET;
  size = sizeof(peer);
  s = socket(PF_INET,SOCK_STREAM,0);
  if(s < 0) {
    ninf_debug("cannot create socket: %s", strerror(errno));
    return -1;
    /* exit(1); */
  }
  if(connect(s,(struct sockaddr *)&peer,size) < 0){
    ninf_debug("cannot connect: %s", strerror(errno));
    return -1;
    /* exit(1); */
  }
  return s;
}
