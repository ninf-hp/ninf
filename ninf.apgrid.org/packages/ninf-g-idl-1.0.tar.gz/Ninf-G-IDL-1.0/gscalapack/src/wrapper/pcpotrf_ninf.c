#define _WRAPPER_
/* $Id: pcpotrf_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define SCOMPLEX
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n
void  pcpotrf_ninf(	 char uplo,
		 int n,
		 scomplex global_a[],
		 int lda,
		 int *info
)
/* "pcpotrf computes the Cholesky factorization of an N-by-N complex hermitian positive definite distributed matrix A. The factorization has the form\\n */
/*            sub( A ) = U' * U ,  if UPLO = 'U', or\\n */
/*            sub( A ) = L  * L',  if UPLO = 'L', \\n */
/*  where U is an upper triangular matrix and L is lower triangular." */
/* OPTIONS */
{
    extern void FortranCall(pcpotrf)( char*, int*, scomplex*, int*, int*, int*, int*);
	int maxldd;

	int maxlda;
	scomplex *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
	int row_loca, col_loca;

	INITIALIZE();

	SCALAR( "char", uplo);
	SCALAR( "int", n);
        SCALAR("int",lda);

	ROW( a);
	COL( a);
	MAXLDD( maxldd, a );
	maxlda = maxldd;

	trMATRIX( uplo, "scomplex", a, ROW_a, COL_a);
	trDISTRIBUTE( uplo, "scomplex", a, ROW_a  , COL_a);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pcpotrf)( &uplo, &n, loca, &one, &one, desca, &linfo);

	trGATHER( uplo, "scomplex", a, ROW_a  , COL_a);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
		*info = linfo;
	} else {
	}

	FREE_MATRIX(a);
}

