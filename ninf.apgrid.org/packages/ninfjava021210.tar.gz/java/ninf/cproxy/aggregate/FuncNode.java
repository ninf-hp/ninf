package ninf.cproxy.aggregate;
import ninf.cproxy.*;
import ninf.basic.*;
import ninf.common.*;
import ninf.client.*;
import java.io.*;

/* 
	funcname MODULE ENTRY
	calcOrder ORDER
  */

public class FuncNode {
  public FunctionName name;
  public long order;

  /** for scheduling **/

  public DataNode[] upperData;
  public DataNode[] lowerData;
  public ServerIndex serverIndex = null;

  public ServerIndex[] serverIndexes;

  static CommandParser calcOrderParser = 
    new CommandParser(new CommandRepresent("calcOrder",     1));
  

  /*********** instance creation ***********/
  public FuncNode(DataInputStream is) throws NinfException{
    name = new FunctionName(is);
    NinfCommand com;
    com = calcOrderParser.readCommand(is);
    order = new Long(com.args[0]).longValue();
  }

  public FuncNode(){
    this.name = null;
    this.order = 0;
    upperData = new DataNode[0];
    lowerData = new DataNode[0];
  }

  public FuncNode(FunctionName name, long order){
    this.name = name;
    this.order = order;
  }

  public void send(PrintStream ps) throws NinfException {
    name.toCommand().send(ps);
    ps.println("calcOrder " + order);
  }

  public String toString(){
    return name + ":" + order;
  }


  public void locate(NinfServerStruct serverStruct){
    for (int i = 0; i < serverIndexes.length; i++)
      if (serverIndexes[i].server.equals(serverStruct)){
	serverIndex = serverIndexes[i];
	return;
      }
  }


  /************* make data links ************/

  private static DataNode[] addData(DataNode[] nodes, DataNode node){
    DataNode[] tmp;
    if (nodes == null){
      tmp = new DataNode[1];
      tmp[0] = node;
      return tmp;
    }
    tmp = new DataNode[nodes.length + 1];
    System.arraycopy(nodes, 0, tmp, 0, nodes.length);
    tmp[nodes.length] = node;
    return tmp;
  }

  public void registerLower(DataNode node){
    lowerData = addData(lowerData, node);
  }

  public void registerUpper(DataNode node){
    upperData = addData(upperData, node);
  }
}
	
