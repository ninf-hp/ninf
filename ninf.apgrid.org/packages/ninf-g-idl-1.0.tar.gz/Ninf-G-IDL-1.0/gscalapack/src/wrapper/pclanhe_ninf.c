#define _WRAPPER_
/* $Id: pclanhe_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define SCOMPLEX
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n
static	int worklen(char norm, int n) {
	  int ret=1;
	  int LDW;
	  int LCM, IROFFA, ICOFFA, IAROW, IACOL;
	  int Np0, Nq0;
	  ret = 3*n + 1;
	  if NEED_BUFF {
	    if (chrcmp(norm,'M')==0) return 1;
	    if (chrcmp(norm,'E')==0) return 1;
	    if (chrcmp(norm,'F')==0) return 1;

	    if( nprow != npcol ) 
	      LDW = MB_A*CEIL(CEIL(Np0,MB_A),(LCM/NPROW));
	    else
	      LDW = 0;

	    LCM = LCM( NPROW, NPCOL );

	    IROFFA = MOD( IA-1, MB_A ); ICOFFA = MOD( JA-1, NB_A );
	    IAROW = INDXG2P( IA, MB_A, MYROW, RSRC_A, NPROW );
	    IACOL = INDXG2P( JA, NB_A, MYCOL, CSRC_A, NPCOL );
	    Np0 = NUMROC( N+IROFFA, MB_A, MYROW, IAROW, NPROW );
	    Nq0 = NUMROC( N+ICOFFA, NB_A, MYCOL, IACOL, NPCOL );

	    ret = 2*Nq0+Np0+LDW;
	  }
	  return ret;
}


void  pclanhe_ninf(	 char norm,
		 char uplo,
		 int n,	/*  n >= 0 */
		 scomplex global_a[],
		 int lda,
		 float work[],
		 float *ret	/* return value */
)
/* "pclanhe returns the value of the one norm, or the Frobenius norm, or the infinity norm, or the element of largest absolute value of a complex hermitian distributed matrix A." */
/* OPTIONS */
{
    extern float FortranCall(pclanhe)( char*, char*, int*, scomplex*, int*, int*, int*, float*);

	int maxldd;

	int maxlda;
	scomplex *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
	int row_loca, col_loca;

	float locpclanhe[1];

	float *locwork=NULL;
	int llocwork;

	INITIALIZE();

	SCALAR("char",norm);
	SCALAR("char",uplo);
	SCALAR("int",n);
	SCALAR( "int", lda);

	ROW(a );
	COL(a);
	MAXLDD(maxldd,a );
	maxlda=maxldd;

	MATRIX("scomplex",a, ROW_a, COL_a);
	DISTRIBUTE("scomplex", a, ROW_a, COL_a);

        llocwork = worklen(norm, n);
        _work( "float", &locwork, llocwork);
        
	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranReturnSimple(pclanhe, locpclanhe,
                       ( &norm, &uplo, &n,
                       loca, &one, &one, desca,
                       locwork) );

	RETRIEVE("int", &linfo, 1);
	RETRIEVE( "float", locpclanhe, 1);

	if( mypnum == 0 ){
	  *ret = *locpclanhe;
	} else {
	}

	FREE_MATRIX(a);
	FREE(locwork);
}

