#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

#include <fcntl.h>
#include <sys/stat.h>

char * save_str(char *);
#include "ninf_data_trans.h"
#include "ninf_stream.h"
#include "ninf_error.h"

#define HTTP_CODE_OK                       200
#define HTTP_CODE_CREATED                  201
#define HTTP_CODE_ACCEPTED                 202
#define HTTP_CODE_NOCONTENT                204
#define HTTP_CODE_MOVED_PERMANENTLY        301 
#define HTTP_CODE_MOVED_TEMPORALY          302
#define HTTP_CODE_BAD_REQUEST              400
#define HTTP_CODE_UNAUTHORIZED             401
#define HTTP_CODE_FORBIDDEN                403
#define HTTP_CODE_NOT_FOUND                404
#define HTTP_CODE_NOT_IMPLEMENTD           500
#define HTTP_CODE_BAD_GATEWAY              501
#define HTTP_CODE_BAD_SERVICE_UNAVAILABLE  502

#define MAX_LINE_LEN 100
#define MAX_HEADER 100

typedef struct http_header{
  char * header_buffer[MAX_HEADER];
  char * protocol;
  int code;
  char * content_type;
  char * content_subtype;
} http_header;

typedef struct content_handler{
  char *type;
  char *subtype;
  int (*func)(http_header * hdr, dataTrans * dt, resource * rsc);
} content_handler;

extern content_handler HANDLERS[];

dataTrans * connect_content(char * host, char * port, char * index, int modeIn){
  int sock;
  dataTrans * dt;
  FILE * fp;
  sock = ninf_connect_remote(host, port);
  if ((fp = fdopen(sock, "w")) == NULL) 
    return NULL;

  if (*index == '/')
    index++;                       /* cut off excess slush */

  if (modeIn){
    fprintf(fp, "%s /%s http/1.0\n\n", "GET", index);
  } else {
    fprintf(fp, "%s /%s http/1.0\n", "PUT", index);
    fprintf(fp, "Content-length: 10000000000\n\n"); /* Dummy Length */
  }
  fflush(fp);

  dt = new_dataTrans(sock, modeIn? XDR_DECODE : XDR_ENCODE, FALSE);
  return dt;
}

extern char * TMP_FILE_ROOT;
dataTrans * connect_file(char * index, int modeIn){
  int fd;
  dataTrans * dt;
  char filename[1000];

  sprintf(filename, "%s/%s", TMP_FILE_ROOT, index);
  if (ninf_debug_flag) printf("file is %s/%s\n", TMP_FILE_ROOT, index);
  if (modeIn){
    if ((fd = open(filename, O_RDONLY, 0666)) < 0){
      perror("read open:");
      return NULL;
    }
  } else {
    if ((fd = creat(filename, 0666)) < 0){
      perror("write open:");
      return NULL; 
    }
  }
  dt = new_dataTrans(fd, modeIn? XDR_DECODE : XDR_ENCODE, FALSE);
  return dt;
}

connection * connect_storage(char * host, char * port, char * index, int modeIn){
  int sock;
  int code;
  connection * con;

  sock = ninf_connect_remote(host, port);
  if (sock < 0){
    ninf_error_code = STORAGE_CANNOT_CONNECT;
    return NULL;
  }
  con = new_connection(sock, TRUE);
  trans_string_nolen(con->sDT, &index);
  if (modeIn)
    trans_flush(con->sDT, NINF_PKT_GET_STORAGE_RESOURCE, 0, 0);
  else
    trans_flush(con->sDT, NINF_PKT_PUT_STORAGE_RESOURCE, 0, 0);

  if ((code = trans_getPacket(con->rDT)) != NINF_PKT_RPY_STORAGE_RESOURCE){
    ninf_error_code = getArg1(con->rDT);
    return NULL;
  }
  return con;
}

void parse_http_code(http_header * hdr, char *line){
  hdr->protocol = strtok(line,  " \t");
  hdr->code = atoi(strtok(NULL,  " \t"));
}

void parse_http_content_type(http_header * hdr, char *line){
  strtok(line, " \t");
  hdr->content_type = strtok(NULL, " /");
  hdr->content_subtype = strtok(NULL, " /");
  if (ninf_debug_flag) printf("protocol        = %s\n", hdr->protocol);
  if (ninf_debug_flag) printf("code            = %d\n", hdr->code);
}

char * find_tag_header(char * tag, char ** lines){
  char buffer[MAX_LINE_LEN];
  while (*lines != NULL){
    strncpy(buffer, *lines, MAX_LINE_LEN);
    if (strncasecmp(strtok(buffer,  " \t"), tag, MAX_LINE_LEN) == 0)
      return *lines;
    lines++;
  }
  return NULL;
}

void parse_http_header(http_header * hdr){
  char * line;
  parse_http_code(hdr, hdr->header_buffer[0]);
  if ((line = find_tag_header("Content-Type:", hdr->header_buffer + 1)) == NULL)
    return;
  parse_http_content_type(hdr, line);
}

http_header * read_http_header(http_header *hdr, dataTrans * dt){
  int i;
  for (i = 0; i < MAX_HEADER-1; i++){
    char * line;
    line = read_line_dataTrans(dt);
    if (line == NULL)
      return NULL;
    if (strlen(line) == 0){
      hdr->header_buffer[i] = NULL;
      return hdr;
    }
    hdr->header_buffer[i] = save_str(line);
  }
  return NULL; /* header buffer over flow */
}

void print_http_header(http_header *hdr){
  char ** tmp = hdr->header_buffer;
  while (*tmp != NULL){
    printf("%s\n", *(tmp++));
  }
}

http_header * new_http_header(dataTrans * dt){
  http_header * hdr;
  if ((hdr = (http_header *)malloc(sizeof(http_header))) == NULL)
    return NULL;
  if (read_http_header(hdr, dt) == NULL)
    return NULL;
  if (ninf_debug_flag) print_http_header(hdr);
  parse_http_header(hdr);
  if (ninf_debug_flag) printf("content-type    = %s\n", hdr->content_type);
  if (ninf_debug_flag) printf("content-subtype    = %s\n", hdr->content_subtype);
  return hdr;
}


int ninf_bin_handler(http_header * hdr, dataTrans * dt, resource * rsc){
  if (trans_any(dt, (rsc)->param_type, (rsc)->size, (rsc)->base))
    return NINF_ERROR_NOERROR;
  else
    return HTTP_UNKNOWN_FORMAT;
}

/* stub information of this stub */
extern NINF_STUB_INFO ninf_stub_info;

typedef struct MMHeader{
  int object;    /* matrix or vector or ..*/
#define MATRIX 0
#define VECTOR 1

  int format;    /* corrdinate / array  */
#define COORDINATE 0
#define ARRAY      1

  int dataType;  /* real / integer / complex */
#define REAL       0
#define INTEGER    1
#define COMPLEX    2

  int symmetry;  /* general symmetric skew-symmetric hemitian */
#define GENERAL        0
#define SYMMETRIC      1
#define SKEW_SYMMETRIC 2
#define HERMITIAN      3

#define MMFORMAT_IDENTIFIER "%%MatrixMarket"
} MMHeader;

void put_array_item(double * base, int n, int m, int n0, int m0, double val){
  if (ninf_stub_info.info_type == MAT_STYLE_FORTRAN)
    *(base + m0 * n + n0) = val;
  else
    *(base + n0 * m + m0) = val;
}

void get_array_item(double * base, int n, int m, int n0, int m0, double * val){
  if (ninf_stub_info.info_type == MAT_STYLE_FORTRAN)
    *val = *(base + m0 * n + n0);
  else
    *val = *(base + n0 * m + m0);
}

int mm_array_read(dataTrans * dt, double * base, int symmetry){
  char * line;
  int n, m, size, n0, m0;
  int i, j;
  double val;
  char * tmp;

  while (TRUE){                      /* SKIP COMMENTS */
    line = read_line_dataTrans(dt);
    if (line == NULL) 
      return HTTP_FORMAT_ERROR;
    if (*line != '%')   
      break;
  }
  
  if ((tmp = strtok(line, " \t"))== NULL)
    return HTTP_FORMAT_ERROR;
  n = atoi(tmp);
  if ((tmp = strtok(NULL,      " \t"))== NULL)
      return HTTP_FORMAT_ERROR;
  m = atoi(tmp);


  if (symmetry == SYMMETRIC || symmetry == HERMITIAN){
    size = n * (n + 1) / 2;
  } else if (symmetry == SKEW_SYMMETRIC){
    size = n * (n - 1) / 2;
  } else {
    size = n * m;
  }

  if (ninf_debug_flag) printf("size = %d x %d (%d): sym:%d \n", n, m, size, symmetry);
  switch (symmetry){
  case GENERAL:
    for (j = 0; j < m; j++){
      for (i = 0; i < n; i++){
	if ((line = read_line_dataTrans(dt)) == NULL){
	  if (ninf_debug_flag) printf("%s\n", dt->position);
	  return HTTP_FORMAT_ERROR;
	}
	if ((tmp = strtok(line, " \t"))==NULL)
	  return HTTP_FORMAT_ERROR;
	val = atof(tmp);
	put_array_item(base, n, m, i, j, val);
      }
    }
    break;
  case SYMMETRIC:
  case HERMITIAN:
    for (j = 0; j < m; j++){
      for (i = j; i < n; i++){
	if ((line = read_line_dataTrans(dt)) == NULL){
	  if (ninf_debug_flag) printf("%s\n", dt->position);
	  return HTTP_FORMAT_ERROR;
	}
	if ((tmp = strtok(line, " \t"))==NULL)
	  return HTTP_FORMAT_ERROR;
	val = atof(tmp);
	put_array_item(base, n, m, i, j, val);
	put_array_item(base, n, m, j, i, val);
      }
    }
    break;
  case SKEW_SYMMETRIC:
    for (j = 0; j < m - 1; j++){
      for (i = j + 1; i < n; i++){
	if ((line = read_line_dataTrans(dt)) == NULL){
	  if (ninf_debug_flag) printf("%s\n", dt->position);
	  return HTTP_FORMAT_ERROR;
	}
	if ((tmp = strtok(line, " \t"))==NULL)
	  return HTTP_FORMAT_ERROR;
	val = atof(tmp);
	put_array_item(base, n, m, i, j, val);
	put_array_item(base, n, m, j, i, -val);
      }
    }
    break;
  }
  return NINF_ERROR_NOERROR;;
}


int coordination_read(dataTrans * dt, double * base, int symmetry){
  char * line, * tmp;
  int n, m, size;
  int i, j;

  while (TRUE){                      /* SKIP COMMENTS */
    line = read_line_dataTrans(dt);
    if (line == NULL) 
      return HTTP_FORMAT_ERROR;
    if (*line != '%')   
      break;
  }

  if ((tmp = strtok(line, " \t"))== NULL)
    return HTTP_FORMAT_ERROR;
  n = atoi(tmp);
  if ((tmp = strtok(NULL,      " \t"))== NULL)
      return HTTP_FORMAT_ERROR;
  m = atoi(tmp);
  if ((tmp = strtok(NULL,      " \t"))== NULL)
      return HTTP_FORMAT_ERROR;
  size = atoi(tmp);

  if (ninf_debug_flag) printf("size = %d x %d (%d items) \n", n, m, size);
  
  for (i = 0; i < n; i++)
    for (j = 0; j < m; j++)
      *(base + (i + j * n) ) = 0;   /* clear matrix */

  for (i = 0; i < size; i++){
    int n0, m0;
    double val;
    if ((line = read_line_dataTrans(dt)) == NULL){
      return HTTP_FORMAT_ERROR;
    }
    if ((tmp = strtok(line, " \t"))== NULL)
      return HTTP_FORMAT_ERROR;
    n0 = atoi(tmp) - 1;
    if ((tmp = strtok(NULL, " \t"))== NULL)
      return HTTP_FORMAT_ERROR;
    m0 = atoi(tmp) - 1;  /* one origin */
    if ((tmp = strtok(NULL, " \t"))== NULL)
      return HTTP_FORMAT_ERROR;
    val = atof(tmp);
    put_array_item(base, n, m, n0, m0, val);
    if (symmetry == SYMMETRIC || symmetry == HERMITIAN){
      put_array_item(base, n, m, m0, n0, val);
    } else if (symmetry == SKEW_SYMMETRIC){
      put_array_item(base, n, m, m0, n0, -val);
    }
  }
  return NINF_ERROR_NOERROR;;
}


void print_mmheader(MMHeader * mmheader){
  printf("MMheader: ");
  if (mmheader->object == MATRIX)
    printf("matrix ");
  else 
    printf("vector ");

  if (mmheader->format == COORDINATE)
    printf("coordinate ");
  else if (mmheader->format == ARRAY)
    printf("array ");

  if (mmheader->dataType == REAL)
    printf("real ");
  else if (mmheader->dataType == INTEGER)
    printf("integer ");
  else if (mmheader->dataType == COMPLEX)
    printf("complex ");

  if (mmheader->symmetry == GENERAL)
    printf("general ");
  else if (mmheader->symmetry == SYMMETRIC)
    printf("symmetric ");
  else if (mmheader->symmetry == SKEW_SYMMETRIC)
    printf("skew_symmetric ");
  else if (mmheader->symmetry == HERMITIAN)
    printf("HEMITIAN");
}

MMHeader * read_MMHeader(dataTrans * dt){
  char * line = read_line_dataTrans(dt);
  MMHeader * mmheader;
  char * token;
  if (line == NULL)
      return NULL;
  mmheader = (MMHeader *) malloc(sizeof(MMHeader));
  token = strtok(line, " \t");
  if (mmheader == NULL) 
    return NULL;
  if (strncasecmp(MMFORMAT_IDENTIFIER, token, 
		  strlen(MMFORMAT_IDENTIFIER) + 1) != 0)
    return NULL;

  token = strtok(NULL, " \t");
  if (strncasecmp("matrix", token, strlen("matrix")+1) != 0)
    return NULL;
  mmheader->object = MATRIX;

  token = strtok(NULL, " \t");
  if (strncasecmp("coordinate", token, strlen("coordinate")+1) == 0)
    mmheader->format = COORDINATE;
  else if (strncasecmp("array", token, strlen("array")+1) == 0)
    mmheader->format = ARRAY;
  else 
    return NULL;

  token = strtok(NULL, " \t");
  if (strncasecmp("real", token, strlen("real")+1) == 0)
    mmheader->dataType = REAL;
  else if (strncasecmp("integer", token, strlen("integer")+1) == 0)
    mmheader->dataType = INTEGER;
  else if (strncasecmp("complex", token, strlen("complex")+1) == 0)
    mmheader->dataType = COMPLEX;
  else 
    return NULL;


  token = strtok(NULL, " \t");
  if (strncasecmp("general", token, strlen("general")+1) == 0)
    mmheader->symmetry = GENERAL;
  else if (strncasecmp("symmetric", token, strlen("symmetric")+1) == 0)
    mmheader->symmetry = SYMMETRIC;
  else if (strncasecmp("skew-symmetric", token, strlen("skew-symmetric")+1) == 0)
    mmheader->symmetry = SKEW_SYMMETRIC;
  else if (strncasecmp("hermitian", token, strlen("hermitian")+1) == 0)
    mmheader->symmetry = HERMITIAN;
  else 
    return NULL;
  return mmheader;
}


int matrixmarket_handler(http_header * hdr, dataTrans * dt, resource * rsc){
  char * line;
  MMHeader *mmheader;
  if (rsc->param_type != DT_DOUBLE || rsc->dim != 2 )
    return HTTP_TYPE_MISMATCH;

  if (ninf_debug_flag) printf("matrixmarket handler\n");

  if ((mmheader = read_MMHeader(dt)) == NULL){
    if (ninf_debug_flag) printf("cannot read mmheader correctly\n");
    return HTTP_FORMAT_ERROR;
  }
  if (ninf_debug_flag) printf("read header\n");

  if (mmheader->dataType == COMPLEX) /* COMPLEX is not supported  */
    return HTTP_FORMAT_ERROR;         /* INTEGER will be cast into double */

  print_mmheader(mmheader);
  if (mmheader->format == COORDINATE)
    return coordination_read(dt, (double *)(rsc->base), mmheader->symmetry);
  if (mmheader->format == ARRAY)
    return mm_array_read(dt, (double *)(rsc->base), mmheader->symmetry);
}

int coordination_handler(http_header * hdr, dataTrans * dt, resource * rsc){
  if (rsc->param_type != DT_DOUBLE || rsc->dim != 2 )
    return HTTP_TYPE_MISMATCH;

  return coordination_read(dt, (double *)(rsc->base), GENERAL);
}



content_handler * find_handler(char * type, char * subtype){
  content_handler * tmp = HANDLERS;
  while (tmp->type != NULL){
    if (strcasecmp(tmp->type, type) == 0 && 
	strcasecmp(tmp->subtype, subtype) == 0 )
      return tmp;
    tmp++;
  }
  if (ninf_debug_flag) printf("cannot find a handler \n");
  return NULL;
}

int read_content(http_header * hdr, dataTrans * dt, resource * rsc){
  content_handler * handler = find_handler(hdr->content_type, hdr->content_subtype);
  if (handler == NULL){
    ninf_error_code =  HTTP_UNKNOWN_FORMAT;
    return FALSE;
  } else {
    ninf_error_code = (*(handler->func))(hdr, dt, rsc);
    if (ninf_error_code == NINF_ERROR_NOERROR)
      return TRUE;
    else
      return FALSE;
  }
}


int coordination_write(dataTrans * dt, double * base, int n, int m){
  int size = 0;
  int i, j, n0, m0;
  double val;
  FILE * fp;

  fprintf(stdout, "coordination write %d, %d\n", n, m);
  write_flush(dt);
  if ((fp = fdopen(dt->fd, "w")) == NULL){
    fprintf(stdout, "cannot fdopen\n");
    return HTTP_CANNOT_CONNECT;
  }
/*   fprintf(stdout, "coordination here\n"); */
  for (n0 = 0; n0 < n; n0++){
    for (m0 = 0; m0 < m; m0++){
      get_array_item(base, n, m, n0, m0, &val);
      if (val != 0.0)
	size++;
    }
  }
/*  fprintf(stdout, "size: %d\n", size); */

  fprintf(fp, "%d %d %d\n", n, m, size);
/*  fprintf(stdout, "%d %d %d\n", n, m, size); */

  for (n0 = 0; n0 < n; n0++){
    for (m0 = 0; m0 < m; m0++){
      get_array_item(base, n, m, n0, m0, &val);
      if (val != 0.0){
	fprintf(fp, "%d %d %lf\n", n0 + 1, m0 + 1, val);
/*	fprintf(stdout, "%d %d %lf\n", n0 + 1, m0 + 1, val); */
      }
    }
  }
  fflush(fp);
  return NINF_ERROR_NOERROR;;
}


int coordination_write(dataTrans * dt, double * base, int n, int m);

	
int is_coord(char * str){
  char *coordination = "coordination";
  int len = strlen(str);
  int cordlen = strlen(coordination);
  int i;
  for (i = 0; i < cordlen; i++){
    if (str[len - 1 - i] != coordination[cordlen - 1 -i])
      return FALSE;
  }
  return TRUE;
}


int put_http_content(resource * rsc){
  dataTrans * dt;
  http_header * hdr;

  if ((dt = connect_content((rsc)->host , (rsc)->port, 
			    (rsc)->resource_name, FALSE)) == NULL){
    ninf_error_code = HTTP_CANNOT_CONNECT;
    return FALSE;
  }
  if (is_coord(rsc->resource_name)){
    if (!coordination_write(dt, (double*)(rsc->base), rsc->array_shape[0].end,
			    rsc->array_shape[1].end)){
      ninf_error_code = HTTP_CANNOT_CONNECT;
      return FALSE;
    } 
  } else {
    /*    printf("bin write\n"); */
    if (!trans_any(dt, (rsc)->param_type, (rsc)->size, (rsc)->base)){
      ninf_error_code = HTTP_CANNOT_CONNECT;
      return FALSE;
    }
  }
  write_flush(dt);
  trans_destroy(dt);
  return TRUE;
}


int get_http_content(resource * rsc){
  dataTrans * dt;
  http_header * hdr;
  int ack;

  if ((dt = connect_content((rsc)->host , (rsc)->port, 
			    (rsc)->resource_name, TRUE)) == NULL){
    ninf_error_code = HTTP_CANNOT_CONNECT;
    return FALSE;
  }
  if ((hdr = new_http_header(dt)) == NULL){
    ninf_error_code = HTTP_HEADER_READ_ERROR;
    close(dt->fd);
    return FALSE;
  }    
  switch (hdr->code){
  case HTTP_CODE_OK:
  case HTTP_CODE_CREATED:
  case HTTP_CODE_ACCEPTED:
    ack =  read_content(hdr, dt, rsc);
    trans_destroy(dt);
    return ack;
  default:
    ninf_error_code = HTTP_NOT_FOUND;
    close(dt->fd);
    return FALSE;
  }
}

int get_storage_content(resource * rsc){
  dataTrans * dt;
  int ack, code;
  connection * con;

  if ((con = connect_storage((rsc)->host , (rsc)->port, 
			    (rsc)->resource_name, TRUE)) == NULL)
    return FALSE;
  if (!trans_any(con->rDT, (rsc)->param_type, (rsc)->size, (rsc)->base)){
    ninf_error_code = STORAGE_TRANSFER_ERROR;
    return FALSE;
  }
 
  trans_flush(con->sDT, NINF_PKT_RPY_TRANSFER_END, 0, 0);
  return TRUE;
}

int put_storage_content(resource * rsc){
  dataTrans * dt;
  int ack, code;
  connection * con;

  if ((con = connect_storage((rsc)->host , (rsc)->port, 
			    (rsc)->resource_name, FALSE)) == NULL)
    return FALSE;

  set_trans_header(con->sDT, NINF_PKT_TRANSFER, 0, 0);
  if (!trans_any(con->sDT, (rsc)->param_type, (rsc)->size, (rsc)->base)){
    ninf_error_code = STORAGE_TRANSFER_ERROR;
    return FALSE;
  }
  trans_flush(con->sDT, NINF_PKT_TRANSFER_END, 0, 0);
  code = trans_getPacket(con->rDT);
  if (code != NINF_PKT_RPY_TRANSFER_END){
    ninf_error_code = STORAGE_TRANSFER_ERROR;
    return FALSE;
  }
  return TRUE;
}


int put_resource(resource * rsc){
  switch (rsc->protocol){
  case FILE_RESOURCE:
    return put_file_content(rsc);
  case HTTP_RESOURCE:
    return put_http_content(rsc);
  case NINF_STORAGE_RESOURCE:
    return put_storage_content(rsc);
  default:
    ninf_error_code = UNKNOWN_URL_PROTOCOL;
    return FALSE;
  }
}

int get_resource(resource * rsc){
  switch (rsc->protocol){
  case FILE_RESOURCE:
    return get_file_content(rsc);
  case HTTP_RESOURCE:
    return get_http_content(rsc);
  case NINF_STORAGE_RESOURCE:
    return get_storage_content(rsc);
  default:
    ninf_error_code = UNKNOWN_URL_PROTOCOL;
    return FALSE;
  }
}

http_header dummy_ninf_type_header;

int get_file_content(resource * rsc){
  dataTrans * dt;
  int ack;

  dummy_ninf_type_header.content_type = "application";
  dummy_ninf_type_header.content_subtype = "x-ninf-binary";

  if ((dt = connect_file(rsc->resource_name, TRUE)) == NULL){
    ninf_error_code = NINF_FILE_CANNOT_OPEN;
    return FALSE;
  }

  ack =  read_content(&dummy_ninf_type_header, dt, rsc);
  trans_destroy(dt);
  return ack;
}

int put_file_content(resource * rsc){
  dataTrans * dt;
  int i = 100;

  int ack;
  if ((dt = connect_file(rsc->resource_name, FALSE)) == NULL){
    ninf_error_code = NINF_FILE_CANNOT_OPEN;
    return FALSE;
  }
  if (!trans_any(dt, (rsc)->param_type, (rsc)->size, (rsc)->base)){
    ninf_error_code = NINF_FILE_CANNOT_WRITE;
    return FALSE;
  }
  write_flush(dt);
  trans_destroy(dt);
  close(dt->fd);
  return TRUE;
}


int trans_vector_any_from_stream(resource * rsc, int from, int to){
  int  i;

  if (rsc == NULL) return TRUE;
  for (i = from; i < to; i++){
    if (!IS_IN_MODE((rsc+i)->io_mode)) continue;
    if ((rsc+i)->host == NULL) continue;
    if (!get_resource(rsc + i))
      return FALSE;
  }
  return TRUE;
}


int trans_vector_any_to_stream(resource * rsc, int from, int to){
  int  i;

  if (rsc == NULL) return TRUE;
  for (i = from; i < to; i++){
    if (!IS_OUT_MODE((rsc+i)->io_mode)) continue;
    if ((rsc+i)->host == NULL) continue;
    if (!put_resource(rsc + i))
      return FALSE;
  }
  return TRUE;
}

/*****     This must be at the last of code    *****/

content_handler HANDLERS[] = {
  {"application", "x-ninf-binary", ninf_bin_handler},
  {"x-math", "coordination", coordination_handler},
  {"x-math", "matrixmarket", matrixmarket_handler}, 
  {NULL, NULL, NULL}
};

