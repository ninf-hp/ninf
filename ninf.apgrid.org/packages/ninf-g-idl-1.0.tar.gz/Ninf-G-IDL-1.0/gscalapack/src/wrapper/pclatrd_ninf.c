#define _WRAPPER_
/* $Id: pclatrd_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define _DISTRIBUTE_1D_
#define SCOMPLEX
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n

#define ROW_w ldw
#define COL_w nb
static	int worklen(int n) {
	  int ret=1;
	  ret = n;
	  if NEED_BUFF {
	    ret = blocsize;
	  }
	  return ret;
}

void  pclatrd_ninf(	 char uplo,
		 int n,
		 int nb,
		 scomplex global_a[],
		 int lda,
		 float global_d[],
		 float global_e[], //uplo
		 scomplex global_tau[],
		 scomplex global_w[],
		 int ldw
)
/* "pclatrd reduces NB rows and columns of a complex Hermitian distributed matrix A to complex tridiagonal form by an unitary similarity transformation Q' * A * Q, and returns the matrices V and W which are needed to apply the transformation to the unreduced part of A." */
/* OPTIONS */
{
extern	 void FortranCall(pclatrd)( char*, int*, int*,
                                scomplex*, int*, int*, int*,
                                float*, float*,
                                scomplex*,
                                scomplex*, int*, int*, int*,
                                scomplex*);

	int maxldd;

	int maxlda;
	scomplex *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
	int row_loca, col_loca;

	float *locd=NULL;
	float *loce=NULL;
	int desctdd[DESCLEN], desc_gtdd[DESCLEN];

	int maxldw;
	scomplex *locw=NULL;
	int descw[DESCLEN];
	int desc_gw[DESCLEN];
	int row_locw, col_locw;

	scomplex *loctau=NULL;

	scomplex *locwork=NULL;
	int llocwork;

	INITIALIZE();

	SCALAR( "char", uplo);
	SCALAR( "int", n);
	SCALAR( "int", nb);
	SCALAR("int",lda);
	SCALAR("int",ldw);

	SIZE(n);

	ROW( a);
	COL( a);
	MAXLDD( maxldd, a );
	maxlda = maxldd;
	ROW( w);
	COL( w);
	MAXLDD( maxldd, w);
	maxldw = maxldd;

	MATRIX( "scomplex", a, ROW_a, COL_a);
	DISTRIBUTE( "scomplex", a, ROW_a, COL_a);
	MATRIX( "scomplex", w, ROW_w, COL_w);

	if (chrcmp(uplo,'U')==0) tdMATRIX( "float", 0, d, e,n);
	else tdMATRIX( "float", e, d, 0, n);

	VECTOR("c","scomplex", tau, n);
	vDISTRIBUTE("c", "scomplex", tau, n);

	llocwork=worklen(n);
	WORK(locwork,llocwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	  FortranCall(pclatrd)( &uplo, &n, &nb,
                                loca, &one, &one, desca,
                                locd, loce,
                                loctau,
                                locw, &one, &one, descw,
                                locwork);

	GATHER( "scomplex", a, ROW_a, COL_a);
	if (chrcmp(uplo,'U')==0) tdGATHER( "float", 0, d, e, n);
	else tdGATHER( "float", e, d, 0, n);
	vGATHER("c", "scomplex", tau, n);

	GATHER( "scomplex", w, ROW_w, COL_w);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
	} else {
	}

	FREE_MATRIX(a);
	FREE_MATRIX(d);
	FREE_MATRIX(e);
	FREE_MATRIX(w);
	FREE_VECTOR(tau);
        FREE(locwork);
	
}
