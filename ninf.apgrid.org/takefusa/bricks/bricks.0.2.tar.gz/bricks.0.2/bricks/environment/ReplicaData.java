package bricks.environment;
import bricks.util.*;
import bricks.scheduling.*;
import java.util.*;

public class ReplicaData extends TrafficData {

    public ReplicaManager replicaManager;
    public Host source;
    public Host destination;
    public double startTime;
    public boolean move = false;
    public DataFragment dataFragment;

    public ReplicaData(
	SimulationSet owner, Host source, Host destination, 
	ReplicaManager replicaManager, DataFragment dataFragment, 
	boolean move, double currentTime
    ) {
	id = generateId();
	processingDuration = 0.0;
	this.source = source;
	this.destination = destination;
	this.replicaManager = replicaManager;
	this.dataSize = dataFragment.size;
	this.dataFragment = new DataFragment(dataFragment.id, dataSize);
	this.dataFragment.generatedTime = dataFragment.generatedTime;
	this.move = move;
	startTime = currentTime;
	listOfRoute = owner.getRouteForStore(source, destination);
	currentNode = (Node)listOfRoute.firstElement();

	//System.out.println(
	SimulationDebug.println(
	    "ReplicaData: from " + source + " to " + destination + "(" + 
	    listOfRoute + ")"
	);
    }

    public Vector getSubList(double currentTime) {
	Vector list = (Vector)listOfRoute.clone();
	list.removeElementAt(0);
	list.removeElementAt(list.size() - 1);
	list.addElement(new TerminalNode());

	return list;
    }

/************************* needed method *************************/
    public String getName() {
	return "ReplicaData";
    }

    public String toString() {
	String str = startTime + " " + source + " " + destination + " " + 
	    dataFragment.id;
	if (move)
	    str += " move";
	else
	    str += " copy";
	return str;
    }

    public void gotoNextNode(double currentTime) {
	if (indexOfCurrentNode >= listOfRoute.size()) {
	    error(getName() + " - No more nextNode Element [" + 
		  listOfRoute + "]");
	}
	currentNode = (Node)listOfRoute.elementAt(++indexOfCurrentNode);
	SimulationDebug.println(this + " goes to " + currentNode);
	//send data
	if (indexOfCurrentNode == 1) { 
	    dataSourceDisk = (Disk)currentNode;
	    // if failed, no replication is caused.
	    boolean reservationFail = false;
	    if (!(source.getDisk()).reserved(this.dataFragment))
		reservationFail = true;
	    if (!(destination.getDisk()).reserved(this.dataSize))
		reservationFail = true;
	    
	    if (reservationFail)
		BricksUtil.abort(this + ": Disk space reservation failed.");

	} else if (indexOfCurrentNode == listOfRoute.size() - 1) {
	    try {
		Disk disk = ((Host)currentNode).getDisk();
		disk.released(this.dataSize);
		(source.getDisk()).released(this.dataFragment);
		dataFragment.stored(currentTime, disk);
		if (move)
		    dataSourceDisk.remove(currentTime, dataFragment);
	    } catch (BricksNoDiskSpaceException e) {
		e.printStackTrace();
		BricksUtil.abort();
	    } catch (ClassCastException e) {
		e.printStackTrace();
		BricksUtil.abort("ReplicaData: currentNode = " + currentNode);
	    }
	}

	currentNode.schedule(currentTime, this);
    }

    public void replicate(double currentTime) {
	this.gotoNextNode(currentTime);
    }

    public void killed(double currentTime) {
	SimulationDebug.println(this + " killed");
	replicaManager.finishReplication(currentTime, this);
    }

    // override
    //public void outLogString(double currentTime) {
    //replicaManager.printLog(toLogString(currentTime));
    //}

    public boolean equals(Object object) {
	if (object instanceof ReplicaData) {
	    ReplicaData data2 = (ReplicaData)object;
	    if ((this.id).equals(data2.id))
		return true;
	}
	return false;
    }

    protected String toLogString(double currentTime) {
	double duration = currentTime - startTime;
	return this + " " + dataFragment + " " + 
	    source + " " + destination + " " + 
	    startTime + " " + duration;
    }
}
