package bricks.util;
import bricks.environment.*;
import java.util.*;

public abstract class ComponentCreator implements Creator {

    protected SimulationSet owner;
    protected SubComponentFactory subComponentFactory;

    // for ComponentCreator without Server and Client
    public void create(String str) throws BricksParseException {;}

    // for HostCreator
    public Node createNode(String str) throws BricksParseException {
	return null;
    }

    // for user Class
    public void set(
	SimulationSet owner, SubComponentFactory subComponentFactory
    ) {
	this.owner = owner;
	this.subComponentFactory = subComponentFactory;
    }
}
