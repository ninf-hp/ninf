/*
 *  $Id: ninf_entry.h,v 1.2 1999/02/27 10:18:32 tatebe Exp $
 */

#ifndef _NINF_ENTRY_H_
#define _NINF_ENTRY_H_

typedef struct ninf_entry{
  char * host;
  char * port;
  char * entry;
} ninf_entry;
ninf_entry * new_ninf_entry(char * p);

#endif /* _NINF_ENTRY_H_ */
