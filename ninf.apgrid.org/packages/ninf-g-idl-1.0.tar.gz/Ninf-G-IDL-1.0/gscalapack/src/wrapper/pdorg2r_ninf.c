#define _WRAPPER_
/* $Id: pdorg2r_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define DOUBLE
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n
static	int worklen(int m, int n) {
	  int ret=1;
	  int IROFFA, ICOFFA, IAROW, IACOL, MpA0, NqA0;
	  ret = m + max(1,n);
	  if NEED_BUFF {
	    IROFFA = MOD( IA-1, MB_A ); ICOFFA = MOD( JA-1, NB_A );
	    IAROW = INDXG2P( IA, MB_A, MYROW, RSRC_A, NPROW );
	    IACOL = INDXG2P( JA, NB_A, MYCOL, CSRC_A, NPCOL );
	    MpA0 = NUMROC( M+IROFFA, MB_A, MYROW, IAROW, NPROW );
	    NqA0 = NUMROC( N+ICOFFA, NB_A, MYCOL, IACOL, NPCOL );
	    ret = MpA0 + MAX( 1, NqA0 );
	  }
	  return ret;
}

void  pdorg2r_ninf(	 int m,
		 int n,
		 int k,
		 double global_a[],
		 int lda,
		 double global_tau[],
		 double work[],
		 int *info
)
/* "pdorg2r generates an M-by-N real distributed matrix Q with orthonormal columns, which is defined as the first N columns of a product of K elementary reflectors of order M\\n\\n        Q  =  H(1) H(2) ." */
/* OPTIONS */
{
	int maxldd;

	int maxlda;
	double *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
	int row_loca, col_loca;

	double *loctau=NULL;

	double *locwork=NULL;
	int llocwork;


	INITIALIZE();

	SCALAR( "int", m);
	SCALAR( "int", n);
	SCALAR( "int", k);
	SCALAR( "int", lda);

	ROW( a);
	COL( a);
	MAXLDD( maxldd, a );
	maxlda = maxldd;

	MATRIX( "double", a, ROW_a, COL_a);
	DISTRIBUTE( "double", a, ROW_a, COL_a);
	VECTOR("c", "double", tau, k);
	vDISTRIBUTE("c", "double", tau, k);

	llocwork= worklen(m, n);
	WORK(locwork,llocwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pdorg2r)( &m, &n, &k,
                               loca, &one, &one, desca,
                               loctau,
                               locwork, &llocwork,
                               &linfo);

	GATHER( "double", a, ROW_a, COL_a);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
		*info = linfo;
	} else {
		
	}

	FREE_MATRIX(a);
	FREE_VECTOR(tau);
        FREE(locwork);
	
}

