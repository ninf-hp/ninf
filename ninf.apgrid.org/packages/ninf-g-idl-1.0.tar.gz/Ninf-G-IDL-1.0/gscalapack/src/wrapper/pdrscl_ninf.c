#define _WRAPPER_
/* $Id: pdrscl_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define DOUBLE
#include <gscalapack.h>


#ifdef HAVE_ABS
#define LENGTH (1+(n-1)*abs(incx))
#else
#define LENGTH (1+(n-1)*(incx))
#endif

void  pdrscl_ninf(	   int n,
		   double sa,
		   double global_sx[],
		   int incx
)
/* "pdrscl multiplies an N-element real distributed vector X by the real scalar 1/a." */
/* OPTIONS */
{
	int maxldd;

	int maxldsx;
	double *locsx=NULL;
	int descsx[DESCLEN];
	int desc_gsx[DESCLEN];
	int row_locsx, col_locsx;
	int ROW_sx;
	int COL_sx;

	INITIALIZE();

	SCALAR( "int", n);
	SCALAR( "double", sa);
	SCALAR( "int", incx);

	square( LENGTH, &ROW_sx, &COL_sx);

	ROW(sx);
	COL(sx);
	MAXLDD( maxldd, sx );
	maxldsx=maxldd;

	MATRIX( "double", sx, ROW_sx, COL_sx);
	DISTRIBUTE( "double", sx, ROW_sx, COL_sx);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pdrscl)( &n, &sa,
                              locsx, &one, &one, descsx,
                              &incx);

	GATHER( "double", sx, ROW_sx, COL_sx );

	if( mypnum == 0 ){
	}else {
        }
        
	FREE_MATRIX(sx);
}

