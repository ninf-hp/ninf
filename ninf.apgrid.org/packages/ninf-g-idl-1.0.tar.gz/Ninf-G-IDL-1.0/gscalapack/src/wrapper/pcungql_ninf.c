#define _WRAPPER_
/* $Id: pcungql_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define SCOMPLEX
#include <gscalapack.h>
#define ROW_a lda
#define COL_a n
static	int worklen(int m, int n) {
	  int ret;
	  int IROFFA, ICOFFA, IAROW, IACOL, MpA0, NqA0;
	  ret = n*(n+m+n);
	  if NEED_BUFF {
	    IROFFA = MOD( IA-1, MB_A ); ICOFFA = MOD( JA-1, NB_A );
	    IAROW = INDXG2P( IA, MB_A, MYROW, RSRC_A, NPROW );
	    IACOL = INDXG2P( JA, NB_A, MYCOL, CSRC_A, NPCOL );
	    MpA0 = NUMROC( M+IROFFA, MB_A, MYROW, IAROW, NPROW );
	    NqA0 = NUMROC( N+ICOFFA, NB_A, MYCOL, IACOL, NPCOL );
	    ret = NB_A * ( NqA0 + MpA0 + NB_A );
	  }
	  return ret;
}


void  pcungql_ninf(	 int m,	/*  m >= 0 */
		 int n,	/*  m >= n >= 0 */
		 int k,	/*  n >= k >= 0 */
		 scomplex global_a[],
		 int lda,
		 scomplex global_tau[],
		 scomplex work[],	/*  n >= k >= 0 */
		 int lwork,
		 int *info
)
/* "pcungql generates an M-by-N complex distributed matrix Q with orthonormal columns, which is defined as the last N columns of a product of K elementary reflectors of order M\\n        Q  =  H(k) . . . H(2) H(1) as returned by PCGEQLF." */
/* OPTIONS */
{
	int maxldd;

	int maxlda;
	scomplex *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
	int row_loca, col_loca;

	scomplex *loctau=NULL;

	scomplex *locwork=NULL;
	int llocwork;

	INITIALIZE();

	SCALAR("int",m);
	SCALAR("int",n);
	SCALAR("int",k);
	SCALAR("int",lda);
	SCALAR( "int", lwork);

	ROW(a );
	COL(a );
	MAXLDD(maxldd,a );
	maxlda=maxldd;

	MATRIX("scomplex",a,ROW_a  ,COL_a );
	VECTOR("c", "scomplex",tau, n );
	DISTRIBUTE("scomplex", a, ROW_a , COL_a );
	vDISTRIBUTE("c", "scomplex", tau, n);

	llocwork=worklen(m, n);
	llocwork = max(lwork,llocwork);
	WORK(locwork,llocwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pcungql)( &m, &n, &k,
                               loca, &one, &one, desca,
                               loctau,
                               locwork, &llocwork, &linfo);

	GATHER("scomplex", a, ROW_a , COL_a );
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
		*info = linfo;
	} else {
	}

	FREE_MATRIX(a);
	FREE_VECTOR(tau);
	FREE(locwork);
}

