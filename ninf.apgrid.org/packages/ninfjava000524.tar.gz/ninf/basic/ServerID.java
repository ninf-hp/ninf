// ServerID.java

package ninf.basic;
import ninf.basic.*;
import java.net.*;
import java.io.*;

public class ServerID {
  /** host name of Server */
  public String host;
  public InetAddress address;

  /** port no of NinfServer */
  public int port;

  static CommandParser parser = 
    new CommandParser(new CommandRepresent("server",     2));

  public ServerID(DataInputStream is) throws NinfException{
    NinfCommand com = parser.readCommand(is);
    host = com.args[0];
    port = new Integer(com.args[1]).intValue();
    initInetAddr();
  }

  public ServerID(String h, int p) {
    host = h; 
    port = p;
    initInetAddr();
  }
  public ServerID(String h, String port) {
    host = h; 
    this.port = new Integer(port).intValue();
    initInetAddr();
  }
  void initInetAddr(){
    try {
      address = InetAddress.getByName(host);
    } catch (UnknownHostException e){
      address = null;
    } catch (SecurityException e){
      address = null;
    }
  }

  public String toString() {
    return (host + ":" + port);
  }

  public NinfCommand toCommand() {
    return new NinfCommand("server", host, ""+port);
  }

  public int hashCode(){
    return host.hashCode() + port;
  }

  public boolean equals(Object o){
    if (!(o instanceof ServerID))
      return false;
    ServerID s = (ServerID)o;
    if (address != null && s.address != null)
      if (address.equals(s.address) && port == s.port)
	return true;
    if (host.equals(s.host) && port == s.port)
      return true;
    return false;
  }
}
