#define _WRAPPER_
/* $Id: psdtsv_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define _DISTRIBUTE_1D_
#define FLOAT
#include <gscalapack.h>

#define ROW_b n
#define COL_b nrhs
static	int worklen( int n, int nrhs) {
#define NB blocsize
	  int ret=1;
	  ret =  (12+3*n) +max(10+4*nrhs, 8);
	  if NEED_BUFF
	    ret =  (12*npcol+3*NB) +max(10*npcol+4*nrhs, 8*npcol);
          return ret;
}


void  psdtsv_ninf(	 int n,
		 int nrhs,
		 float global_dl[],
		 float global_d[],
		 float global_du[],
		 float global_b[],
		 float work[],
		 int lwork,
		 int *info
)
/* "psdtsv solves a system of linear equations A * X = B where A is an N-by-N real tridiagonal diagonally dominant-like distributed matrix." */
/* OPTIONS */
{
	extern void FortranCall(psdtsv)( int*, int*,
                              float*, float*, float*, int*, int*,
                              float*, int*, int*,
                              float*, int*, int*);

	int maxldd;

	float *locdl=NULL, *locd=NULL, *locdu=NULL;
	int desctdd[DESCLEN];
	int desc_gtdd[DESCLEN];

	float *locb=NULL;
	int maxldb;
	int descb[DESCLEN];
	int desc_gb[DESCLEN];
	int row_locb, col_locb;

	float *locwork=NULL;
	int llocwork;

	INITIALIZE();

	SCALAR( "int", n);
	SCALAR( "int", nrhs);
	SCALAR( "int", lwork);

	SIZE(n);

	tdMATRIX( "float", dl, d, du, n);
	MATRIX( "float", b, ROW_b, COL_b);
	tdDISTRIBUTE( "float", dl, d, du, n);
	DISTRIBUTE( "float", b, ROW_b, COL_b);

	llocwork = worklen(n, nrhs);
        llocwork = max(lwork, llocwork);
	WORK(locwork, llocwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(psdtsv)( &n, &nrhs,
                              locdl, locd, locdu, &one, desctdd,
                              locb, &one, descb,
                              locwork, &llocwork, &linfo);

	tdGATHER( "float",dl, d, du, n);
	GATHER("float", b, ROW_b, COL_b);

	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
		*info = linfo;
	} else {
	}
	FREE_MATRIX(dl);
	FREE_MATRIX(d);
	FREE_MATRIX(du);
	FREE_MATRIX(b);
        FREE(locwork);
	
}

