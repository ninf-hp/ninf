#include <stdio.h>

extern int mypnum;


/* An original source code is described in FORTRAN                      */
/*                                                                      */
/*     -- BLACS example code --                                         */
/*     Written by Clint Whaley 7/26/94.                                 */
/*     ..                                                               */
/*     ..Scalar Arguments ..                                            */
/*      INTEGER CONTEXT, MAPPING, BEGPROC, NPROW, NPCOL                 */
/*     ..                                                               */
/*     .. Array Arguments ..                                            */
/*      INTEGER IMAP(NPROW, *)                                          */
/*     ..                                                               */
/*                                                                      */
/*  Purpose                                                             */
/*  =======                                                             */
/*  PROCMAP maps NPROW*NPCOL processes starting from process BEGPROC to */
/*  the grid in a variety of ways depending on the parameter MAPPING.   */
/*                                                                      */
/*  Arguments                                                           */
/*  =========                                                           */
/*                                                                      */
/*  CONTEXT      (output) INTEGER                                       */
/*               This integer is used by the BLACS to indicate a context. */
/*               A context is a universe where messages exist and do not  */
/*               interact with other context's messages.  The context includes */
/*               the definition of a grid, and each process's coordinates in it. */
/* */
/*  MAPPING      (input) INTEGER */
/*               Way to map processes to grid.  Choices are: */
/*               1 : row-major natur/al ordering */
/*               2 : column-major natural ordering */
/* */
/*  BEGPROC      (input) INTEGER */
/*               The process number (between 0 and NPROCS-1) to use as {0,0}. */
/*               From this process, processes will be assigned to the grid */
/*               as indicated by MAPPING. */
/* */
/*  NPROW        (input) INTEGER */
/*               The number of process rows the created grid  */
/*               should have. */
/* */
/*  NPCOL        (input) INTEGER */
/*               The number of process columns the created grid */
/*               should have. */
/* */
/*  IMAP         (workspace) INTEGER array of dimension (NPROW, NPCOL) */
/*               Workspace where the array which maps the  */
/*               processes to the grid will be stored for the */
/*               call to GRIDMAP. */
/*     */
/* ===================================================================== */
/* */

void Cprocmap( int *pcontext, int mapping, int begproc, int npr, int npc, int *pmap)
{
  extern void Cblacs_pinfo( int*, int*);
  extern void Cblacs_gridinit( int*, char*, int ,int );
  extern int Cblacs_pnum(int, int, int);
  extern void Cblacs_gridexit(int);

  extern void Cblacs_get( int, int, int*);
  extern void Cblacs_gridmap(int *, int *, int, int , int );
  extern void exit(int);

  int nprow, npcol;
  int tmpcontxt, nprocs, i,j, k;
  char order='R';


  nprow = npr;
  npcol = npc;

  /* See how many processes there are in the system */
  Cblacs_pinfo( &i, &nprocs);

  if (nprocs-begproc < nprow*npcol) {
    fprintf(stderr, "Not enough processes for grid\n");
    exit(-1);
  }

  /* Temporarily map all processes into 1 x NPROCS grid */
  Cblacs_get( 0, 0, &tmpcontxt);
  Cblacs_gridinit( &tmpcontxt, &order, 1, nprocs); 
  k = begproc;

  /* If we want a row-major ordering */
  if (mapping == 1) {
    for(i=0;i<nprow;i++)
      for(j=0;j<npcol;j++) {
	pmap[i+j*nprow] = Cblacs_pnum( tmpcontxt, 0, k);
	k++;
      }
  } else if (mapping == 2) {
    /* If we want a column-major ordering */
      for(j=0;j<npcol;j++) 
	for(i=0;i<nprow;i++){
	pmap[i+j*nprow] = Cblacs_pnum( tmpcontxt, 0, k);
	k++;
      }
  } else {
    fprintf( stderr, "Unknown mapping.\n");
    exit(2);
  }

  /* Free temporaly context */
  Cblacs_gridexit(tmpcontxt);

  Cblacs_get( 0, 0, pcontext);
  Cblacs_gridmap( pcontext, pmap, nprow, nprow, npcol);

  return ;
}


void procmap_( int *pcontext, int *pmapping, int *begproc, int *nprow, int *npcol, int *pmap) {
  Cprocmap( pcontext, *pmapping, *begproc, *nprow, *npcol, pmap);
}

void F77procmap_( int *pcontext, int *pmapping, int *begproc, int *nprow, int *npcol, int *pmap) {
  Cprocmap( pcontext, *pmapping, *begproc, *nprow, *npcol, pmap);
}

