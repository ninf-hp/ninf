#ifndef _RESOURCE_H_
#define _RESOURCE_H_

#define HTTP_RESOURCE 1
#define FILE_RESOURCE 2
#define NINF_STORAGE_RESOURCE 3

#include "array_info.h"

/** this structure is use to specify 
  the resource location and the method to retrieve the resource 
  ***/
typedef struct resource
{
  int protocol;
  char * host;
  char * port;
  char * resource_name;
  
  int size;
  enum data_type param_type;
  MODE_SPEC io_mode;
  char * base;
  int dim;
  array_shape_info * array_shape;
} resource;

resource * new_resources(int num);

#endif /* _RESOURCE_H_ */
