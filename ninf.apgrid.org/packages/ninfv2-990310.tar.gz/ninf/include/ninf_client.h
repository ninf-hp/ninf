#ifndef  __NINF_CLIENT__
#define  __NINF_CLIENT__

#include "ninf_stub.h"
#include "ninf_data_trans.h"
#include "session.h"

int ninf_recv_or_callback(ninf_session *);
int ninf_recv_or_callback_org(ninf_session *);
int ninf_recv_data(ninf_session *);
int ninf_recv_callback(ninf_session *);
		   

void set_types(NINF_STUB_INFO * stub_info, int types[]);

void copy_stub_info(NINF_STUB_INFO * stub_info, char * buffer);

int ninf_wait_all();
int ninf_wait_and(int * id_list, int counts);
int ninf_wait_or(int * id_list, int counts);
int session_is_done(int id);
NINF_STUB_INFO * Ninf_get_stub_raw(connection * con, ninf_entry * entry);
int get_next_call_head(NINF_STUB_INFO * ninf_stub_info_p, int n);

int ninf_disconnect(connection * con);
int ninf_remote_forkexec(connection * server, char *program);
int ninf_remote_kill(connection * server);

int ninf_get_arg_sub2(va_list * app, NINF_STUB_INFO * ninf_stub_info_p, any_t ninf_args[], int start, int end, resource rsc[], int FortranFlag);

int start_stub_by_index(ninf_session *);
int ninf_get_arg(va_list * app, NINF_STUB_INFO * stub_info, any_t ninf_args[], struct callback callbacks[], resource rsc[]);

int ninf_get_arg2(va_list * app, NINF_STUB_INFO * stub_info, any_t ninf_args[], struct callback callbacks[], resource rsc[], int FortranFlag);

int ninf_get_arg_v(NINF_STUB_INFO * stub_info, any_t ninf_args[], struct callback callbacks[]);

size_info * Ninf_get_size_info(NINF_STUB_INFO * stub_info, any_t * args);


#endif /*__NINF_CLIENT__*/

