int Cilcm( int m, int n) {
  int ia, iq, ir, ilcm;
  if (m>=n) {
    ia = m;
    ilcm = n;
  } else {
    ia = n;
    ilcm = m;
  }

  while(1) {
    iq = ia/ilcm;
    ir = ia-iq*ilcm;
    if (ir == 0) {
      ilcm = m/ilcm*n;
      break;
    }
    ia = ilcm;
    ilcm = ir;
  }
  return ilcm;
}


