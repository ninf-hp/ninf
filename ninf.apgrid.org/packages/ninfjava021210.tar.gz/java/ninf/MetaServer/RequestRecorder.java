package ninf.MetaServer;
import ninf.basic.*;
import ninf.client.*;


import java.util.Hashtable;

public class RequestRecorder {
  Hashtable record = new Hashtable();

  void addRequestRecord(String uniqid) {
    record.put(uniqid, Boolean.TRUE);
  }
  boolean isRecorded(String uniqid) {
    Boolean r = (Boolean)(record.get(uniqid));
    return (r != null && r.booleanValue());
  }
}
