package bricks.scheduling;
import bricks.util.*;
import bricks.environment.*;
import java.util.*;

public class RandomScheduler extends Scheduler implements SchedulingUnit {

    protected Random random;
    protected Vector hosts;

    public RandomScheduler(String keyOfMetaPredictor, long seed) {
	this.keyOfMetaPredictor = keyOfMetaPredictor;
	random = new Random(seed);
	schedulingOverhead = 0.0;
    }


/************************* needed method *************************/
    public String getName() {
	return "RandomScheduler";
    }

    public void selectHosts (
	double currentTime, Host source, RequestedData data
    ) throws BricksNotScheduledException {
	hosts = resourceDB.getHostList();
	if (hosts.size() == 0)
	    throw new BricksNotScheduledException(this.toString());

	Host host = (Host)hosts.elementAt(
	    Math.abs(random.nextInt()) % hosts.size()
	);
	updateStatus(currentTime, source, host, data);
    }
}

