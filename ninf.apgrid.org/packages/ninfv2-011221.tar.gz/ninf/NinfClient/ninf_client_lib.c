#include <stdio.h>
#include <errno.h>
#include <stdlib.h>
#include <sys/types.h>
#include <pwd.h>
#include <stdarg.h>
#include <rpc/rpc.h>
#include <string.h>
#ifndef WIN32
#include <unistd.h>
#else
#include <io.h>
#endif
#include "ninf_stub_info.h"
#include "ninf_protocol.h"
#include "connection.h"
#include "ninf_error.h"
#include "session.h"
#include "ninf_client.h"
#include "ninf_stream.h"
#include "callback.h"
#include "dataflow.h"

#ifdef SSL_USE
#include "ninf_ssl.h"

int    ssl_use  = FALSE;
char * ssl_cert = NULL;
char * ssl_key  = NULL;
#endif

/*begin akiyama start */
FILE * log_fp;
/*end akiyama start */ 

connection * ninf_connect(ninf_entry *);
NINF_STUB_INFO * search_stub_cache(ninf_entry * entry);
void remove_stub_cache(int index);
int ninf_connect_remote_shell(char * hostname, char * service);
int ninf_connect_remote_shell_callback(char * hostname, char * service, 
				     int callback_port);

typedef void (*void_func)();

extern FILE * stub_out;
extern FILE * stub_err;
int privileged = FALSE;
int ninf_shell_mode = NINF_SHELL_NO;
char * map_file_name = NULL;

ninf_get_arg(va_list * app, NINF_STUB_INFO * stub_info, any_t ninf_args[], struct callback callbacks[], resource rsc[]){
  ninf_get_arg2(app, stub_info, ninf_args, callbacks, rsc, FALSE);
}

ninf_get_arg2(va_list * app, NINF_STUB_INFO * stub_info, any_t ninf_args[], struct callback callbacks[], resource rsc[], int FortranFlag)
{
  int end_of_nomal_args, tmp;
  int nparam = stub_info->nparam;
  int index = 0;
  
  end_of_nomal_args = 
    get_next_call_head(stub_info, 0);
  ninf_get_arg_sub2(app, stub_info, ninf_args, 0, end_of_nomal_args, 
		   rsc, FortranFlag);

  while (end_of_nomal_args < nparam){
    tmp = get_next_call_head(stub_info, end_of_nomal_args + 1);
    init_callback (&(callbacks[index]), 
		   va_arg(*app, void_func),
		   end_of_nomal_args,
		   tmp - end_of_nomal_args -1);
    end_of_nomal_args = tmp;
    index++;
  }
  callbacks[index].start_index = -1;
}

ninf_get_arg_v(NINF_STUB_INFO * stub_info, any_t ninf_args[], struct callback callbacks[])
{
  int end_of_nomal_args, tmp;
  int nparam = stub_info->nparam;
  int index = 0;
  
  end_of_nomal_args = 
    get_next_call_head(stub_info, 0);

  while (end_of_nomal_args < nparam){
    tmp = get_next_call_head(stub_info, end_of_nomal_args + 1);
    init_callback (&(callbacks[index]), 
		   (void_func)(ninf_args[end_of_nomal_args].u.p),
		   end_of_nomal_args,
		   tmp - end_of_nomal_args -1);
    end_of_nomal_args = tmp;
    index++;
  }
  callbacks[index].start_index = -1;
}


void set_types(NINF_STUB_INFO * stub_info, int types[])
{
  int i;
  if (types == NULL)
    return;
  for (i = 0; i < stub_info->nparam; i++)
    types[i] = stub_info->params[i].param_inout;
}

void copy_stub_info(NINF_STUB_INFO * stub_info, char * buffer)
{
  int i, size;
  if (buffer == NULL)
    return;
  size = sizeof(NINF_STUB_INFO);
  memcpy(buffer, (char *)stub_info, size);
/* 
  printf("copy from %p\n", stub_info->params);
  printf("copy to %p\n", buffer + size);
  printf("copy size %d = %d * %d \n", (sizeof(struct ninf_param_desc) * stub_info->nparam), sizeof(struct ninf_param_desc) ,  stub_info->nparam);
*/
  if (stub_info->nparam != 0){
    memcpy((buffer + size), (char *)(stub_info->params), 
	  (sizeof(struct ninf_param_desc) * stub_info->nparam));
    ((NINF_STUB_INFO *)buffer)->params = (struct ninf_param_desc *)(buffer + size);
  } 
  if (stub_info->description != NULL){
    char * tmpaddr = buffer + size +
      (sizeof(struct ninf_param_desc) * stub_info->nparam);
    strcpy(stub_info->description, tmpaddr);
    ((NINF_STUB_INFO *)buffer)->description = tmpaddr;
  }
}

NINF_STUB_INFO * Ninf_receive_stub(connection *);

int ninf_req_compound(connection * server)
{
  set_trans_header(server->sDT, NINF_PKT_REQ_COMP, 0,0);
  trans_dataflows(server->sDT);
  trans_common_data(server->sDT);
  trans_flush(server->sDT, NINF_PKT_REQ_COMP, 0,0);
}

NINF_STUB_INFO * Ninf_get_compound(connection * server)
{
  ninf_req_compound(server);
  return Ninf_receive_stub(server);
}  

int start_stub_by_index(ninf_session * session){
  /* invoke stub by stub index */
  connection * con = session->server;
  int i = session->stub_info->stub_index;
  int time = session->stub_info->registered_time;
  int serial;
  int ack;

  debug_log("NINF_PKT_REQ_CALL (index=%ld)\n", i);

  trans_flush(con->sDT, NINF_PKT_REQ_CALL, i, time); 
  ack = trans_getPacket(con->rDT);
  if (ack == NINF_PKT_RPY_CALL){   /* call success */
    trans_int(con->rDT, &serial);
    session->e_info.call_serial = serial;
    return TRUE;
  }
  if (ack != NINF_PKT_ERROR){  /* unknown error */
    ninf_error_code = NINF_ERROR_CANTCONNECTSERVER;
  }
  remove_stub_cache(i);
  return FALSE;
}

char * get_arg_host(char *);
char * get_arg_port(char *); 
extern int callback_port;

int ninf_connect_to_serv(char * host, char * port)
{
  char * tmphost, * tmpport;
  tmphost = (host == NULL ? get_arg_host(getenv("NINF_SERVER")): host);
  tmpport = (port == NULL ? get_arg_port(getenv("NINF_SERVER_PORT")): port);
  if (privileged)
    return ninf_connect_remote_privileged(tmphost, tmpport);
  else if (ninf_shell_mode == NINF_SHELL_STREAM)
    return ninf_connect_remote_shell(tmphost, tmpport);
  else if (ninf_shell_mode == NINF_SHELL_CALLBACK)
    return ninf_connect_remote_shell_callback(tmphost, tmpport, 
					      callback_port);
  else 
    return ninf_connect_remote(tmphost, tmpport);

}

connection * ninf_connect(ninf_entry * entry){
  int sock;
  connection * con;
#ifdef SSL_USE
  SSL_CTX * ctx = NULL;

  if (ssl_use){
    ctx = 
      ninf_client_new_ssl_ctx(ninf_client_ssl_cert_file(ssl_cert),
			      ninf_client_ssl_key_file(ssl_key));
    if (ctx == NULL){
      return NULL;
    }
  }
#endif

  if ((sock = ninf_connect_to_serv(entry->host, entry->port)) < 0){
    ninf_error_code = NINF_ERROR_CANTCONNECTSERVER;
    return NULL;
  }
#ifdef SSL_USE
  if (ninf_shell_mode == NINF_SHELL_CALLBACK)
    con = new_connection(sock, TRUE, TRUE, ctx);
  else
    con = new_connection(sock, TRUE, FALSE, ctx);
#else
  if (ninf_shell_mode == NINF_SHELL_CALLBACK)
    con = new_connection(sock, TRUE, TRUE);
  else
    con = new_connection(sock, TRUE, FALSE);
#endif


#ifndef WIN32
  if (con != NULL && privileged){
    int code;
    struct passwd *pwd = getpwuid(geteuid());
    char *name = pwd->pw_name;

    trans_string(con->sDT, &name, NINF_MAX_NAME_LEN);
    trans_flush(con->sDT, NINF_PKT_AUTH,0,0);

    code = trans_getPacket(con->rDT);
    if (code == NINF_PKT_AUTH_OK)
      return con;
    else {
      ninf_error_code = NINF_AUTHENTICATION_FAILED;
      ninf_disconnect(con);
      return NULL;
    }
  }
#endif
  return con;
}

int ninf_remote_forkexec(connection * server, char *program)
{
  int code;

  /* remote fork, send EXEC packet */
  trans_string(server->sDT, &program, NINF_MAX_NAME_LEN);
  trans_flush(server->sDT, NINF_PKT_REQ_EXEC,0,0);
  code = trans_getPacket(server->rDT);
  
  if(code == NINF_PKT_RPY_EXEC) return TRUE;
  Ninf_perror("ninf_remote_exec failed:"); 
  return FALSE;
}

int ninf_remote_kill(connection * server){
  int code;
    /* send kill request */
  trans_flush(server->sDT, NINF_PKT_KILL,0,0);
  /*  server->rDT->dying = TRUE; */
  code = trans_getPacket(server->rDT);
  if (code != NINF_PKT_RPY_KILL){
    ninf_error_code = NINF_PROTOCOL_ERROR;

    if (ninf_debug_flag) fprintf(stderr, "packet is %d\n", code);
    if (ninf_debug_flag) {
      fprintf(stderr, "size = %d, code = %d, arg1 = %d, arg2 = %d\n", 
	      server->rDT->decoded.size, server->rDT->decoded.code, 
	      server->rDT->decoded.arg1, server->rDT->decoded.arg2);
      {  
	int i; 
	char * pointer = server->rDT->start;
	for (i = 0; i < server->rDT->decoded.size; i++)
	  fprintf(stderr, "%02x ", (0xff)&(*pointer++));
	fprintf(stderr, "\n");
	for (i = 0; i < server->rDT->decoded.size; i++)
	  fprintf(stderr, "%c", (0xff)&(*pointer++));
	fprintf(stderr, "\n");
      }
    }

    ninf_disconnect(server); 
    return NINF_ERROR; 
  }
  ninf_disconnect(server);
  return NINF_OK;
}

alloc_callback_work(struct callback * call, int func_index, NINF_STUB_INFO * stub_info, any_t ninf_args[])
{
  int i, ncount;
  char * p;
  array_shape_info array_shape[MAX_DIM + 1];
  int sizes_in_header[MAX_DIM + 1];

  for(i = func_index + 1; i < stub_info->nparam; i++){
    struct ninf_param_desc *dp = &stub_info->params[i];
    if(dp->param_type == DT_FUNC_TYPE) break;  /* callback function */
    if(dp->ndim == 0) continue; /* scalar */
    ncount = trans_array_shape(dp, stub_info, ninf_args, array_shape, sizes_in_header);
    /* allocate memory for work array */
    if (call->allocated_size[i] < ncount){
      if((p = (char *)calloc(ncount, DATA_TYPE_SIZE(dp->param_type)))
	 == NULL)
	ninf_error("cannot allocate memory");
      ninf_args[i].u.p = p;	/* set argument */
    }
  }
}

int isResourceExists(resource * rsc, int size){
  int i;
  for (i = 0; i < size; i++)
    if (rsc[i].host != NULL)
      return TRUE;
  return FALSE;
}

int send_call_request(ninf_session * session, int len){
  int terminator = -1, i;
  char null_str[] = "";
  char * null_str_p = null_str;
  dataTrans * sDT = session->server->sDT;
  resource * rsc = session->c_resource;

  if (!isResourceExists(session->c_resource, len))
    return trans_request(sDT, NINF_REQ_CALL);
  
  if (!trans_request(sDT,NINF_REQ_CALL_WITH_STREAM))
      return FALSE;
  for (i = 0; i < len; i++)
    if (rsc[i].host != NULL){
      if (!trans_int(sDT, &i))return FALSE;
      if (!trans_int(sDT, &(rsc[i].protocol))) return FALSE;
      if (!trans_string(sDT, &(rsc[i].host),MAX_STRING_LEN)) return FALSE;
      if (!trans_string(sDT, &(rsc[i].port),MAX_STRING_LEN)) return FALSE;
      if (!trans_string(sDT, &(rsc[i].resource_name),MAX_STRING_LEN)) 
	return FALSE;
    }
  if (!trans_int(sDT, &terminator))
	return FALSE;

  return TRUE;
}

int ninf_send_args(ninf_session * session){
  struct ninf_param_desc *dp;
  int nparam = session->stub_info->nparam;
  long send_size = 0;

  /* do call */
  if (!send_call_request(session, nparam))
      return(NINF_ERROR);

  /* send scalar args */
  if (!trans_scalar_args(session->server->sDT, session->stub_info, 
			 session->args, TRUE))
    return(NINF_ERROR);

  /* send array data */
  if (!trans_vector_array_args_ft(session->server->sDT, 
				  session->stub_info, session->args, 
				  session->c_resource, 
				  0, session->stub_info->nparam,
				  TRUE, &send_size))
    return(NINF_ERROR);
  write_flush(session->server->sDT);
  session->e_info.fore_size = send_size;
  if (session->stub_info->order_type == VALUE_BY_EXPR)
	session->e_info.cmp_steps = 
	  eval_expression(&(session->stub_info->order), session->stub_info, session->args);
  else
	session->e_info.cmp_steps = -1; /* unknown */
  return NINF_OK;
}

/***   read a stub from rDT  ***/
NINF_STUB_INFO * Ninf_receive_stub(connection * server)
{
  int  stub_index, time;
  int code;
  NINF_STUB_INFO * tmp_stub_info;
  
  code = trans_getPacket(server->rDT);
  if(code != NINF_PKT_RPY_STUB_INFO) {
    return(NULL);
  }
  stub_index = getArg1(server->rDT);
  time = getArg2(server->rDT);
  tmp_stub_info = new_ninf_stub_info();
  trans_stub_info(server->rDT, tmp_stub_info, TRUE);
  debug_log("stub_index=%d\n", stub_index);
  tmp_stub_info->stub_index = stub_index;
  tmp_stub_info->registered_time = time;
  return tmp_stub_info;
}

/**********************  size_info  *************************/
size_info * new_size_info(int n){
  void * tmp;
  if ((tmp = malloc(sizeof(size_info) * n)) == NULL)
    ninf_fatal("Failed to alloc size_info memory: len = %d", n);
  return (size_info *) tmp;
}

size_info * Ninf_get_size_info(NINF_STUB_INFO * stub_info, any_t * args){
  int sizes_in_header[MAX_DIM + 1];
  struct ninf_param_desc *dp;
  int i;
  
  size_info * s_info = new_size_info(stub_info->nparam);
  
  for (i = 0; i < stub_info->nparam; i++){
    dp = & stub_info->params[i];
    (s_info + i)->param_type = stub_info->params[i].param_type;
    (s_info + i)->param_inout= stub_info->params[i].param_inout;
    (s_info + i)->ndim       = stub_info->params[i].ndim;
    trans_array_shape(dp, stub_info, args, (s_info+i)->shape, sizes_in_header);
  }
  return s_info;
}


char * save_str(char *);
/*********************** NINF ENTRY STUFF ***********************/
int ninf_entry_eq(ninf_entry * a, ninf_entry *b){
  if (((a->host  == NULL && b->host  == NULL) ||
        a->host  != NULL && b->host  != NULL && strcmp(a->host, b->host) == 0)
   && ((a->port  == NULL && b->port  == NULL) ||
        a->port  != NULL && b->port  != NULL && strcmp(a->port, b->port) == 0)
   && ( a->entry != NULL && b->entry != NULL && strcmp(a->entry, b->entry) == 0))
    return TRUE;
  return FALSE;
}
ninf_entry * new_ninf_entry(char * p){
  ninf_entry * tmp = (ninf_entry *)(malloc(sizeof(ninf_entry)));
  static char * zerostring = "";
  char * host = NULL, * port = NULL, * entry = NULL;
  if (tmp == NULL)
    ninf_fatal("Failed to alloc size_info memory: for arg.");

  if (p != NULL){
    p = save_str(p);
    if (strncmp(p, "ninf://", 7) == 0){
      host = strtok(p+7, "/");
      entry = strtok(NULL, "\0");
      host = strtok(host, ":");
      port = strtok(NULL, "\0");
      if (host != NULL) host = save_str(host);
      if (port != NULL) port = save_str(port);
      if (entry != NULL) entry = save_str(entry);
      free(p);
    } else {
      entry = p;
    }
  }
  if (tmp != NULL){
    tmp->host = host;
    tmp->port = port;
    tmp->entry = entry;
  }
  return tmp;
}

ninf_entry * ninf_entry_copy(ninf_entry * entry){
  ninf_entry * tmp = (ninf_entry *)(malloc(sizeof(ninf_entry)));
  if (tmp == NULL)
    ninf_fatal("Failed to alloc size_info memory: for arg.");

  tmp->host  = save_str(entry->host);
  tmp->port  = save_str(entry->port);
  tmp->entry  = save_str(entry->entry);
  return tmp;
}

void destruct_ninf_entry(ninf_entry * e){
  if (e->host != NULL)  free(e->host);
  if (e->port != NULL)  free(e->port);
  if (e->entry != NULL) free(e->entry);
  free(e);
}

/********************************************************/

int ninf_wait_all(){
  int flag = TRUE;
  ninf_session * sess;
  while (TRUE){
    if (session_is_null(root_sessions()))
      break;
    if ((sess = select_session(root_sessions(), FALSE)) == NULL)
      flag = FALSE;
    if (sess->e_info.error_no != NINF_ERROR_NOERROR)
      flag = FALSE;
  }
  if (flag)
    return NINF_OK;
  else
    return NINF_ERROR;
}

/** returns 
SESSION_ID : if a session succeeded    
NINF_OK    : if there's no session left
NINF_EROOR : if the session failed     , the first arg points the faild sessionID
*/
int ninf_wait_any(int * sessionIDp){
  ninf_session * sess;
  if (session_is_null(root_sessions())){   
    *sessionIDp = NINF_OK;
    return NINF_OK;
  }
  if ((sess = select_session(root_sessions(), TRUE)) == NULL){
    *sessionIDp = NINF_ERROR;
    return NINF_ERROR;
  } 
  if (sess->e_info.error_no != NINF_ERROR_NOERROR){
    *sessionIDp = sess->id;
    return NINF_ERROR;
  }
  *sessionIDp = sess->id;
  return sess->id;
}


int ninf_wait_and(int * id_list, int counts){
  ninf_session * ses = NULL;
  int flag = TRUE;
  int ack;
  nslib_list_t * sl = collect_session_list(id_list, counts);
  if (nslib_list_size(sl) == 0){
    ninf_error_code = NINF_ERROR_CANTFINDSESSION;
    ack = NINF_ERROR;
    goto EXIT;
  }  

  while (TRUE){
    if (nslib_list_size(sl) == 0){
      ack = NINF_OK;
      goto EXIT;
    }
    if ((ses = select_session(sl, TRUE)) == NULL)
      flag == FALSE;
    if (ses->e_info.error_no != NINF_ERROR_NOERROR)
      flag == FALSE;
    nslib_list_remove(sl, ses);
  }
  if (flag)
    ack = NINF_OK;
  else
    ack = NINF_ERROR;

EXIT:
  nslib_list_destruct(sl);
  return ack;
}

int ninf_wait_or(int * id_list, int counts){
  int ack;
  ninf_session * ses = NULL;
  nslib_list_t * sl = collect_session_list(id_list, counts);
  if (nslib_list_size(sl) == 0){
    ninf_error_code = NINF_ERROR_CANTFINDSESSION;
    ack = NINF_ERROR;
    goto EXIT;
  }  

  if ((ses = select_session(sl, TRUE)) == NULL){
    ack = NINF_ERROR;
    goto EXIT;
  }
  if (ses->e_info.error_no != NINF_ERROR_NOERROR){
    ack = NINF_ERROR;
    goto EXIT;
  }
  ack = NINF_OK;

EXIT:
  nslib_list_destruct(sl);
  return ack;
}

id_set * make_done_set(id_set * set){   /* remove done sessions and store them 
					   in newly allocated set */
  int i;
  id_set * tmp = new_id_set();
  for (i = id_set_length(set) - 1; i >= 0; i--){
    int tmpID = id_set_get_id(set, i);
    if (session_is_done(tmpID)){
      id_set_rm(set, i);
      id_set_add(tmp, tmpID);
    }
  }
  return tmp;
}

id_set * ninf_wait_and_set(id_set * set){
  int ack = ninf_wait_and(id_set_content(set), id_set_length(set));
  return make_done_set(set);
}

id_set * ninf_wait_or_set(id_set * set){
  int ack = ninf_wait_or(id_set_content(set), id_set_length(set));
  return make_done_set(set);
}


callback * new_callback(int num){
  callback * tmp = (callback *)malloc(sizeof(callback) * num);
  if (tmp == NULL)
    ninf_fatal("Failed to alloc size_info memory: for callbak.");

  return tmp;
}

any_t * new_arg(int num){
  int i;
  any_t * tmp = (any_t *)malloc(sizeof(any_t) * num);
  if (tmp == NULL)
    ninf_fatal("Failed to alloc size_info memory: for arg.");

  for (i = 0; i < num; i++){
    tmp[i].isHandler = FALSE; 
    tmp[i].isFileNull = FALSE;
  }
  return tmp;
}

int ninf_recv_or_callback(ninf_session * session){
  int ack;
  while ((ack = ninf_recv_or_callback_org(session)) == NINF_CALLBACK);
  return ack;
}

int ninf_recv_or_callback_org(ninf_session * session){
  int ack, error;

  if(!trans_int(session->server->rDT,&ack)) return(NINF_ERROR);
  switch (ack){
  case NINF_ACK_OK:
    if (ninf_recv_data(session))
      return NINF_OK;
    return NINF_ERROR;
  case NINF_CALLBACK:
    ninf_recv_callback(session);
    return NINF_CALLBACK;
  case NINF_ACK_ERROR:   /* stub side error */
    if (!trans_int(session->server->rDT, &error)) return(NINF_ERROR);
    ninf_error_code = error;
    return(ack);
  default:
    return(ack);
  }
}

int ninf_recv_data(ninf_session * session){
  /* begin matsubara writes */
 
  int ninfrdata_retval;
  double t1, t2, t3;

  long recv_size = 0;

  /* receive filepointer content */
  trans_scalar_args(session->server->rDT, session->stub_info,
		    session->args, TRUE);


  ninfrdata_retval = trans_vector_array_args_ft(
			session->server->rDT, session->stub_info,
			session->args, session->c_resource,
			0, session->stub_info->nparam,
			TRUE, &recv_size);

  session->e_info.back_size = recv_size;

  trans_double(session->server->rDT, &t1);
  trans_double(session->server->rDT, &t2);
  trans_double(session->server->rDT, &t3);

  session->e_info.hostname = NULL;   /* null clear before getting data */  
  trans_string_nolen(session->server->rDT, &(session->e_info.hostname));
  trans_int(session->server->rDT, &(session->e_info.port));

  session->e_info.fore_time = t1;
  session->e_info.exec_time = t2;
  session->e_info.back_time = t3;

#ifndef WIN32
  gettimeofday(&(session->e_info.end_time), 0);
  session->e_info.client_exec_time = 
    (session->e_info.end_time.tv_sec  - session->e_info.start_time.tv_sec) + 
    (session->e_info.end_time.tv_usec - session->e_info.start_time.tv_usec) * 1.0e-06;
#else
  _ftime(&(session->e_info.end_time));
  session->e_info.client_exec_time = 
    (session->e_info.end_time.time  - session->e_info.start_time.time) + 
    (session->e_info.end_time.millitm - session->e_info.start_time.millitm) * 1.0e-03;
#endif

  /* end matsubara writes */

  session->e_info.error_no = ninf_error_code;

  /*begin akiyama writes */
  if(log_fp != NULL) ninf_log_record(session);
  /*end akiyama writes */
  return ninfrdata_retval;
				    
}

/* begin akiyama writes */
ninf_log_record(ninf_session * session){
  struct timeval tv;
  struct tm *tmp;
  long   msec1;
  long   msec2; 
  char   buf1 [100]; 
  char   buf2 [100];

  /*
   * fprintf( log_fp, " fore_time %f\n", (session->e_info.fore_time)); 
   * fprintf( log_fp, " back_time %f\n", (session->e_info.back_time));
   * fprintf( log_fp, " exec_time %f\n", (session->e_info.exec_time));
   * fprintf( log_fp, " port      %d\n", (session->e_info.port));
   * fprintf( log_fp, " hostname  %s\n", (session->e_info.hostname));
   */
 
  session->e_info.descript = NULL;
  session->e_info.client = NULL;
  /*session->e_info.total_time = (session->e_info.fore_time) + (session->e_info.exec_time) + (session->e_info.back_time); */
    
  gettimeofday(&tv, NULL);
  tmp = localtime(&(tv.tv_sec));
  strftime(buf1, 100, "%Y-%m-%dT%X", tmp);
  msec1 = tv.tv_usec / 1000;

  tmp = localtime(&(session->e_info.start_time.tv_sec));
  strftime(buf2, 100, "%Y-%m-%dT%X", tmp);
  msec2 = (session->e_info.start_time.tv_usec) / 1000;
		   
  fprintf( log_fp, "<NsInvocationEvent>\n");
  fprintf( log_fp, " <description>%s</description>\n", (session->e_info.descript));
  fprintf( log_fp, " <source>%s</source>\n", (session->e_info.source));
  fprintf( log_fp, " <time>%s.%ld-5:00</time>\n", buf1, msec1);
  fprintf( log_fp, " <usrId>%s</usrId>\n", (session->e_info.usrid));      
  fprintf( log_fp, " <client>%s</client>\n", (session->e_info.client));
  fprintf( log_fp, " <server>%s:%d</server>\n", (session->e_info.hostname), (session->e_info.port));
  fprintf( log_fp, " <sendDuration>%f</sendDuration>\n", (session->e_info.fore_time));
  fprintf( log_fp, " <execDuration>%f</execDuraiton>\n", (session->e_info.exec_time));
  fprintf( log_fp, " <clientExecDuration>%f<clientExecDuration>\n", (session->e_info.client_exec_time));
  fprintf( log_fp, " <recvDuration>%f</recvDuration>\n", (session->e_info.back_time));
  fprintf( log_fp, " <startTime>%s.%ld-5:00</startTime>\n", buf2, msec2);
  /* fprintf( log_fp, " <duration>%f</duration>\n", (session->e_info.total_time)); */
  fprintf( log_fp, " <functionName>%s</functionName>\n", (session->e_info.func_name));
  fprintf( log_fp, " <sendDatasize>%ld</sendDatasize>\n", (session->e_info.fore_size));
  fprintf( log_fp, " <recvDatasize>%ld</recvDatasize>\n", (session->e_info.back_size));
  fprintf( log_fp, " <computingSteps>%ld</computingSteps>\n", (session->e_info.cmp_steps)); 
  fprintf( log_fp, "</NsInvocationEvent>\n");

  /* fprintf( log_fp, "msec1= %ld\n", (tv.tv_usec));
   * fprintf( log_fp, "msec2= %ld\n", (session->e_info.start_time.tv_usec));
   */
}

/* end akiyama writes */ 

ninf_exec_callback_send(connection * server, int start, int end,
		       NINF_STUB_INFO * stub_info, any_t ninf_args[], 
			resource * rsc){
  long transmitted;
  if(!trans_request(server->sDT,NINF_CALLBACK_ACK_OK))
    return(NINF_ERROR);
  trans_vector_any_args_ft(server->sDT, stub_info, ninf_args, rsc,
			   start, end, FALSE, &transmitted);
  write_flush(server->sDT);
}


int ninf_recv_callback(ninf_session *session)
{
  int func_index;
  struct callback * call;
  connection * server = session->server;
  struct callback * callbacks = session->callbacks;
  NINF_STUB_INFO * stub_info = session->stub_info; 
  any_t * ninf_args = session->args;
  long transmitted;

  resource * rsc = session->c_resource;
  
  if(!trans_int(server->rDT, &func_index)) return(NINF_ERROR);
  if((call = find_callback(callbacks, func_index)) == NULL)
    return(NINF_ERROR);
  
  if(!trans_scalar_args_ft(server->rDT, stub_info, ninf_args, 
			func_index+1, stub_info->nparam, FALSE))
    return(NINF_ERROR);
  alloc_callback_work(call, func_index, stub_info, ninf_args);

  trans_vector_any_args_ft(server->rDT, stub_info, ninf_args, rsc,
			   func_index+1, stub_info->nparam, FALSE, &transmitted);

  ninf_exec_callback_call(call->func, func_index, call->nparam, ninf_args);
  ninf_exec_callback_send(server, func_index + 1, stub_info->nparam, 
			 stub_info, ninf_args, rsc);
}

/********  stdout/stderr redirect  ********/
extern FILE * stub_out;
extern FILE * stub_err;

void Ninf_set_stdout_fp(FILE *fp){
  stub_out = fp;
}

void Ninf_set_stderr_fp(FILE *fp){
  stub_err = fp;
}


/*************************************
             Argument Parser  
  *************************************/

static char * arg_host = NULL;
static char * arg_port = NINF_SERVER_PORT;
int parse_port_called = FALSE;
int callback_port = -1;

char * get_arg_host(char * default_host){ 
  if (arg_host != NULL)
    return arg_host;
  return default_host;
}

char * get_arg_port(char * default_port){ 
  if (parse_port_called)
    return arg_port;
  if (default_port != NULL)
    return default_port;
  return NINF_SERVER_PORT;
}

void Ninf_set_server(char *server, char * port){
  arg_host = save_str(server);
  arg_port = save_str(port);

  parse_port_called = TRUE;
}


extern void init_session_list();

void init_client(){
  init_session_list();
}

int Ninf_parse_arg(int argc, char ** argv){
  int i = 0;
  char ** index = argv;

  
  for (; *argv != NULL; argv++){
    if (strcasecmp(*argv, "-server") == 0)
      arg_host= *(++argv);
    else if (strcasecmp(*argv, "-port") == 0){
      arg_port= *(++argv);
      parse_port_called = TRUE;
    } else if (strcasecmp(*argv, "-map") == 0){
      map_file_name = *(++argv);
      ninf_group_setup(map_file_name);
    } else if (strcasecmp(*argv, "-privileged") == 0){
      privileged = TRUE;
    } else if (strcasecmp(*argv, "-shell") == 0){
      ninf_shell_mode = NINF_SHELL_STREAM;
    } else if (strcasecmp(*argv, "-shell_stream") == 0){
      ninf_shell_mode = NINF_SHELL_STREAM;
    } else if (strcasecmp(*argv, "-shell_callback") == 0){
      ninf_shell_mode = NINF_SHELL_CALLBACK;
    } else if (strcasecmp(*argv, "-version") == 0){
      print_version();
    } else if (strcasecmp(*argv, "-callback_port") == 0){
      callback_port = atoi(*(++argv));
      /* start akiyama writes */
    } else if (strcasecmp(*argv, "-log_record") == 0){
      char * arg_file = *(++argv);
      if ((log_fp = fopen( arg_file, "w")) == NULL){
	printf("Can't open %s /n", arg_file);
        return(-1);
    }
      /* end akiyama writes */
#ifdef SSL_USE
    } else if (strcasecmp(*argv, "-ssl") == 0){
      ssl_use = TRUE;
    } else if (strcasecmp(*argv, "-ssl_cert") == 0){
      ssl_cert = *(++argv);
    } else if (strcasecmp(*argv, "-ssl_key") == 0){
      ssl_key = *(++argv);
#endif
    } else {
      i++;
      *(index++) = *(argv);
    }
  }
  *(index++) = *(argv);

  init_client();

  return i;
}

/********  stub cache ********/

typedef struct stub_list {
  ninf_entry * entry;
  NINF_STUB_INFO * stub;
  struct stub_list * next;
} stub_list;

static stub_list * StubList = NULL;

stub_list * new_stub_list(ninf_entry * entry, NINF_STUB_INFO * stub, 
			  stub_list *next){
  stub_list * tmp;			    
  if ((tmp = (stub_list *)malloc(sizeof(stub_list))) == NULL)
    ninf_fatal("can't alloc in new_stub_list");
  tmp->entry = entry;
  tmp->stub = stub;
  tmp->next = next;
  return tmp;
}

void add_stub_cache(ninf_entry * entry, NINF_STUB_INFO * stub){
  StubList = new_stub_list(entry, stub, StubList);
}

void remove_stub_cache(int index){
  stub_list ** tmp = &StubList;
  while (*tmp != NULL){
    if ((*tmp)->stub->stub_index == index){
      *tmp = (*tmp)->next;
      return;
    }
    tmp = &((*tmp)->next);
  }
}

NINF_STUB_INFO * search_stub_cache(ninf_entry * entry){
  stub_list * tmp = StubList;
  while (tmp != NULL){
    if (ninf_entry_eq(tmp->entry, entry))
      return tmp->stub;
    tmp = tmp->next;
  }
  return NULL;
}

/******* SUPPORT FUNCTIONS  to Set any_t *****************/

void any_set_char(any_t * a, char val){
  a->isHandler = FALSE;
  a->u.c = val;
}
void any_set_unsigned_char(any_t * a, unsigned char val){
  a->isHandler = FALSE;
  a->u.uc = val;
}
void any_set_short(any_t * a, short val){
  a->isHandler = FALSE;
  a->u.s = val;
}
void any_set_unsigned_short(any_t * a, unsigned short val){
  a->isHandler = FALSE;
  a->u.us = val;
}
void any_set_int(any_t * a, int val){
  a->isHandler = FALSE;
  a->u.i = val;
}
void any_set_unsigned(any_t * a, unsigned val){
  a->isHandler = FALSE;
  a->u.ui = val;
}
void any_set_long(any_t * a, long val){
  a->isHandler = FALSE;
  a->u.l = val;
}
void any_set_unsigned_long(any_t * a, unsigned long val){
  a->isHandler = FALSE;
  a->u.ul = val;
}
void any_set_float(any_t * a, float val){
  a->isHandler = FALSE;
  a->u.f = val;
}
void any_set_double(any_t * a, double val){
  a->isHandler = FALSE;
  a->u.d = val;
}
void any_set_pointer(any_t * a, void * val){
  a->isHandler = FALSE;
  a->u.p = val;
}
void any_set_function(any_t * a, void *(*val)()){
  a->isHandler = FALSE;
  a->u.func = val;
}
void any_set_handler(any_t * a, void * val){
  a->isHandler = TRUE;
  a->handler = val;
}

/*********** PUBLIC FUNCTION *************/
int Ninf_shell(int FLAG){
  ninf_shell_mode = FLAG;
  return ninf_shell_mode;
}
