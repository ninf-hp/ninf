package bricks.util;
import java.util.*;

public class QueueTimeSharing extends Queue implements SubComponent {

    private double timeSlice;
    private EnqueuedData currentTop;

    public QueueTimeSharing (Sequence throughput, double timeSlice) {
	this.queue = new Vector(DEFAULT_QUEUE_LENGTH);
	this.throughput = throughput;
	this.timeSlice = timeSlice;
	if (throughput instanceof InterpolationCpu) {
	    interpolationCpu = true;
	}
    }

/************************* internal class *************************/
    private class EnqueuedData {
	public Data data;
	public double currentDataSize;
	public boolean finish = false;

	EnqueuedData(Data data) {
	    this.data = data;
	    this.currentDataSize = data.getDataSize();
	}
	
	public void updateTop(double currentTime, double throughput){

	    double nextProcessedDataSize = throughput * timeSlice;
	    if (nextProcessedDataSize < currentDataSize) {
		data.setProcessingDuration(timeSlice);
		currentDataSize = currentDataSize - nextProcessedDataSize;

	    } else {
		finish = true;
		data.setProcessingDuration(currentDataSize / throughput);
		currentDataSize = 0.0;
	    }
	    data.updateTimeEventComes(currentTime);
	}
    }


/************************* needed method *************************/
    public String getName() {
	return "QueueTimeSharing";
    }

/************************* overridden method *************************/
    public Data top() {
	return currentTop.data;
    }

    public double getTimeQueueEventComes() {
	return top().timeEventComes;
    }

    /* callee: NetworkNode */
    public boolean processEvent(double currentTime) {
	if (currentTop.finish) {
	    return super.processEvent(currentTime);
	} else {
	    changeQueueTop(currentTime);
	    return false;
	}
    }

    /* callee: ServerNode */
    public boolean processEventForPackets(double currentTime) {
	if (currentTop.finish) {
	    return super.processEventForPackets(currentTime);
	} else {
	    changeQueueTop(currentTime);
	    return false;
	}
    }

    protected void updateNextTop(double currentTime) {
	if (!isEmpty()) {
	    currentTop.updateTop(
	        currentTime, throughput.nextDouble(currentTime)
	    );
	}
    }

    public void dequeue(double currentTime) {
	if (queue.isEmpty())
	    error("no dequeue data");

	EnqueuedData dequeuedData = currentTop;
	if (queue.size() > 1) {
	    changeQueueTop(currentTime);
	} else {
	    currentTop = null;
	}
	queue.removeElement(dequeuedData);
    }

    public void enqueue(double currentTime, Data data) {
	EnqueuedData endata = new EnqueuedData(data);
	if (currentTop == null) {
	    currentTop = endata;
	    queue.addElement(endata);
	    updateNextTop(currentTime);

	} else {
	    int index = queue.indexOf(currentTop);
	    queue.add(index + 1, endata);
	}
    }

    // for fallback
    public double getEstimation(double currentTime, RequestedData data) {
	double total = 0.0;
	Enumeration e = queue.elements();
	while (e.hasMoreElements()) {
	    EnqueuedData endata = (EnqueuedData)e.nextElement();
	    total += endata.currentDataSize;
	}
	double diff = top().timeEventComes - currentTime;
	return (total + data.getDataSize()) / throughput.nextDouble(currentTime) + diff;
    }

    // add!
    private void changeQueueTop(double currentTime) {
	int index = queue.indexOf(currentTop);
	if (index == 0) {
	    currentTop = (EnqueuedData)queue.lastElement();
	} else {
	    currentTop = (EnqueuedData)queue.get(index - 1);
	}
	currentTop.updateTop(currentTime, throughput.nextDouble(currentTime));
    }
}
