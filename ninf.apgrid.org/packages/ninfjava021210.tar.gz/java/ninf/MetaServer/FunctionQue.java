package ninf.MetaServer;
import ninf.basic.*;
import ninf.client.*;

import java.io.IOException;

public class FunctionQue {
  FunctionManager manager;

  public FunctionQue(FunctionManager manager){
    this.manager = manager;
  }

  public synchronized ServerIndex getProperServer(NinfFunctionStruct func, int load) throws NinfException {
    return manager.getProperServer(func, load);
  }

  public synchronized ServerIndex getServerLock(NinfFunctionStruct func, int load)
  throws NinfException {
    ServerIndex tmp;
    while ((tmp = manager.getServerLock(func, load))
	   == null){
//      System.out.println(func + " :notified");
      try { wait();} catch (InterruptedException e){}
    }
    return tmp;
  }

  public synchronized void serverReleased(){
    System.out.println("FunctionQue    :serverReleased");
    notifyAll();
  }
}

