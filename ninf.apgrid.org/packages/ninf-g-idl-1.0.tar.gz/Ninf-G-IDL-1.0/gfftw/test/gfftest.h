#ifndef _GFFTEST_H_
#define _GFFTEST_H_

#define FFTW_FORWARD -1
#define FFTW_BACKWARD 1
#define FFTW_MEASURE 1
#define FFTW_ESTIMATE 0

#define WISDOMLEN 8000

#endif
