#define _WRAPPER_
/* $Id: pddtsv_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define _DISTRIBUTE_1D_
#define DOUBLE
#include <gscalapack.h>

#define ROW_b n
#define COL_b nrhs
static	int worklen(int n, int nrhs) {
#define NB blocsize
	  int ret=1;
	  ret =  (12+3*n) +max(10+4*nrhs, 8);
	  if NEED_BUFF
	    ret =  (12*npcol+3*NB) +max(10*npcol+4*nrhs, 8*npcol);
          return ret;
}

void  pddtsv_ninf(	 int n,
		 int nrhs,
		 double global_dl[],
		 double global_d[],
		 double global_du[],
		 double global_b[],
		 double work[],
		 int lwork,
		 int *info
)
/* "pddtsv solves a system of linear equations A * X = B where A is an N-by-N real tridiagonal diagonally dominant-like distributed matrix." */
/* OPTIONS */
{
	extern void FortranCall(pddtsv)( int*, int*,
					 double*, double*, double*, int*, int*,
					 double*, int*, int*,
					 double*, int*,
					 int*);

	int maxldd;

	double *locdl=NULL, *locd=NULL, *locdu=NULL;
	int desctdd[DESCLEN];
	int desc_gtdd[DESCLEN];

	double *locb=NULL;
	int maxldb;
	int descb[DESCLEN];
	int desc_gb[DESCLEN];
	int row_locb, col_locb;

	double *locwork=NULL;
	int llocwork;

	INITIALIZE();

	SCALAR( "int", n);
	SCALAR( "int", nrhs);
	SCALAR( "int", lwork);

	SIZE(n);

	tdMATRIX( "double", dl, d, du, n);
	MATRIX( "double", b, ROW_b, COL_b);
	tdDISTRIBUTE( "double", dl, d, du, n);
	DISTRIBUTE( "double", b, ROW_b, COL_b);

	llocwork = worklen(n, nrhs);
        llocwork = max(lwork, llocwork);
	WORK(locwork, llocwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pddtsv)( &n, &nrhs,
                              locdl, locd, locdu, &one, desctdd,
                              locb, &one, descb,
                              locwork, &llocwork, &linfo);

	tdGATHER( "double",dl, d, du, n);
	GATHER("double", b, ROW_b, COL_b);

	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
		*info = linfo;
	} else {
	}
	FREE_MATRIX(dl);
	FREE_MATRIX(d);
	FREE_MATRIX(du);
	FREE_MATRIX(b);
        FREE(locwork);
	
}

