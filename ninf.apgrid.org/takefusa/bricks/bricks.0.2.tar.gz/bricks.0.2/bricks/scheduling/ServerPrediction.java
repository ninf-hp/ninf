package bricks.scheduling;
import bricks.environment.HostInfo;

public class ServerPrediction {

    public HostInfo hostInfo;
    public HostInfo predictedHostInfo;
    public double error = -1.0;

    public ServerPrediction(
	HostInfo hostInfo, HostInfo predictedHostInfo
    ) {
	this.hostInfo = hostInfo;
	this.predictedHostInfo = predictedHostInfo;
    }

    public ServerPrediction(
	HostInfo hostInfo, HostInfo predictedHostInfo, double error
    ) {
	this.hostInfo = hostInfo;
	this.predictedHostInfo = predictedHostInfo;
	this.error = error;
    }
}
