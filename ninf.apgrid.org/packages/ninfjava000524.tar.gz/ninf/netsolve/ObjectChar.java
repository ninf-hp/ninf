package ninf.netsolve;


import ninf.client.NinfVal;
import ninf.client.NinfParamDesc;
import ninf.client.NinfDimParam;
import ninf.client.NinfDimParamElem;
import ninf.client.NinfExpression;

/*  defined in NinfVal
  static final int       VALUE_CONST = 1;	default, give by constant 
  static final int       VALUE_IN_ARG = 2;	specified by IN scalar paramter 
  static final int       VALUE_BY_EXPR = 3; 	 computed by interpreter 
*/

class ObjectChar {
  int flag; /* 1 = constant, 2 = in argumet list, 3 = expression */
  int value;	     
  NinfExpression exp;

  ObjectChar(NinfExpression exp){
    this.flag = NinfVal.VALUE_BY_EXPR;
    this.exp = exp;
  }
  ObjectChar(int flag, int value){
    this.flag = flag;
    this.value = value;
    this.exp = new NinfExpression();
  }
  public String toString(){
    return (flag == 1)?"constant ":"inarg " + value;
  }
}
