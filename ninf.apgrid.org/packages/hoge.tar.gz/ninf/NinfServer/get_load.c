#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#ifdef __alpha__
#include <sys/resource.h>
#include <sys/table.h>
#endif 
#include <string.h>
#include "ninf_macros.h"
#include "ninf_error.h"
#include "get_load.h"

#define TMP_MAX_STRING_LEN 1000


double get_loadAverage(){
#ifdef __alpha__
  double loadavg[3];
  struct tbl_loadavg load_ave;
  int elem;
  int nelem = 3;

  table (TBL_LOADAVG, 0, &load_ave, 1, sizeof (load_ave));

  for (elem = 0; elem < nelem; elem++)
    loadavg[elem]
      = (load_ave.tl_lscale == 0
	 ? load_ave.tl_avenrun.d[elem]
	 : (load_ave.tl_avenrun.l[elem] / (double) load_ave.tl_lscale));

  return loadavg[0];
#elif defined(__j90__)
  static char buffer[1000];
  FILE * fp;
  char * ave, *token;
  int i;
  fp = popen("/usr/bin/sar -W 30 1", "r");
  for (i = 0; i < 5; i++){
    if (fgets(buffer, 1000, fp) == NULL){
      fprintf(stderr, "can't uptime\n");
    }
  }
  pclose(fp);

  token = strtok(buffer, "\t \n");
  if (token == NULL)
    return -1.0;
  token = strtok(NULL, "\t \n");
  if (token == NULL)
	return -1.0;
  return atof(token);

#elif defined(UPTIME_COMMAND)

  static char buffer[1000];
  FILE * fp;
  char * ave, *token;
  int i;
  fp = popen(UPTIME_COMMAND, "r");
  if (fgets(buffer, 1000, fp) == NULL){
    fprintf(stderr, "can't uptime\n");
  }
  pclose(fp);
  
  ave = strstr(buffer, "average");
  if (ave == NULL)
    return -1.0;
  for (i = 0; i < TMP_MAX_STRING_LEN; i++){
    if (isdigit(*(ave+i))){
      token = strtok(ave+i, ",");
      if (token == NULL)
	return -1.0;
      return atof(token);
    }
  }
  return -1.0;
#else
  return -1.0;
#endif 
}

void get_vmstat(struct load * l){
  l->user = -1.0;
  l->system = -1.0;
  l->idle = -1.0;
  {
#if defined(__j90__)
    static char buffer[1000];
    FILE * fp;
    char * token;
    int i;
    fp = popen("/usr/bin/sar -u 30 1", "r");
    for (i = 0; i < 5; i++){
      if (fgets(buffer, 1000, fp) == NULL){
	fprintf(stderr, "can't uptime\n");
      }
    }
    pclose(fp);
    
    token = strtok(buffer, "\t \n");
    if (token == NULL)
      return;
    if ((token = strtok(NULL, "\t \n")) == NULL) return;
    l->user = atof(token) / 100.0;
    if ((token = strtok(NULL, "\t \n")) == NULL) return;
    l->system = atof(token)/ 100.0;
    if ((token = strtok(NULL, "\t \n")) == NULL) return;
    if ((token = strtok(NULL, "\t \n")) == NULL) return;
    if ((token = strtok(NULL, "\t \n")) == NULL) return;
    l->idle = atof(token) /100.0;
    return;
#elif defined(VMSTAT_COMMAND)
    static char buffer[1000];
    static char command[1000];
    FILE * fp;
    char * user = "";
    char * system = "";
    char * idle = "";
    char * tmp;
    int i;

    sprintf(command, "%s 1 2", VMSTAT_COMMAND);
    fp = popen(command, "r");
    for (i = 0; i < 4; i++){
      if (fgets(buffer, 1000, fp) == NULL){
	ninf_log("can't vmstat\n");
	return;
      }
    }
    pclose(fp);
    tmp = strtok(buffer, " \t");
    while (tmp != NULL){
      user = system;
      system = idle;
      idle = tmp;
      tmp = strtok(NULL, " \t");
    }
    l->user = atof(user) / 100.0;
    l->system = atof(system)/ 100.0;
    l->idle = atof(idle) /100.0;
    return;
#endif
  }
  return;
}


void get_load(struct load * l){
  l->loadAverage = get_loadAverage();
  get_vmstat(l);
}
