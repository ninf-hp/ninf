package bricks.environment;
import bricks.util.Format;

public class HostInfo implements Cloneable {

    public Host owner;
    public double probeTime = Double.NEGATIVE_INFINITY;

    // server info
    public double trackingTime = -1.0;
    public double loadAverage;
    public double cpuUtilization = 100.0;
    public double availableCpu = -1.0;

    // for data grid
    public double numAccessedDataSize = 0.0;
    public double numAccesses = 0.0;

    // disk info
    public double diskSize;
    public double availableDiskSize;
    public double use;

    public HostInfo(Host owner, double loadAverage) {
	this.owner = owner;
	this.loadAverage = loadAverage;
    }

    public HostInfo(Host owner, double loadAverage, double cpuUtilization) {
	this.owner = owner;
	this.loadAverage = loadAverage;
	this.cpuUtilization = cpuUtilization;
    }

    public HostInfo(
	Host owner, double probeTime, double trackingTime, 
	double loadAverage, double cpuUtilization
    ) {
	this.owner = owner;
	this.probeTime = probeTime;
	this.trackingTime = trackingTime;
	this.loadAverage = loadAverage;
	this.cpuUtilization = cpuUtilization;
    }

    public String toString() {
	return owner + " " + 
	    Format.format(probeTime, 3) + " " + 
	    Format.format(trackingTime, 3) + " " + 
	    Format.format(loadAverage , 6) + " " + 
	    Format.format(cpuUtilization, 6);
    }

    public synchronized Object clone() {
        try {
	    HostInfo h = (HostInfo)super.clone();
	    h.owner = owner;
	    h.probeTime = probeTime;
	    h.trackingTime = trackingTime;
	    h.loadAverage = loadAverage;
	    h.cpuUtilization = cpuUtilization;
	    return h;
        } catch (CloneNotSupportedException e) {
            // This shouldn't happen, since we are Cloneable
            throw new InternalError();
        }
    }
}
