package bricks.scheduling;
import bricks.util.*;
import bricks.environment.*;
import java.util.*;
import java.io.*;

public abstract class ServerMonitor extends Obj implements SchedulingUnit {

    protected PrintWriter logWriter;

    protected Sequence interprobingTime;
    protected double trackingTime;
    protected String keyOfResourceDB;
    protected ResourceDB resourceDB;

    protected double trackingTimeForAccess;

    // nodes
    protected Vector hostList;

    // for event flag
    protected int event;
    protected static final int PROBE = 0;
    protected static final int SEND = 1;

/************************* needed method *************************/
    public String toInitString() {
	return getName() + " : " + key + "\n";
    }

    public void init(SimulationSet owner) {
	this.owner = owner;
	this.logWriter = owner.serverMonitorLogWriter;
	this.resourceDB = owner.getResourceDB(keyOfResourceDB);
	//System.out.println("hostList: " + hostList);
    }

/************************* public method *************************/
    public void printLog(String log) {
	if (logWriter != null)
	    logWriter.println(log);
    }

    public void updateNextEvent(double currentTime) {
	event = PROBE;
	nextEventTime = 
	    nextEventTime + interprobingTime.nextDouble(currentTime);
    }
    
    public void processEvent(double currentTime) {
	probe(currentTime);
    }

    // callee: DataGridScheduler
    public HostInfo getHostInfo(double currentTime, Host host) {
	return host.getHostInfo(currentTime, trackingTime, 
				trackingTimeForAccess);
    }

    // callee: ReplicaManager
    public DataFragment getMostAccessedDataFragment(
	double currentTime, Host source
    ) {
	return source.getMostAccessedDataFragment(currentTime, trackingTime);
    }

    protected boolean hasAvailableDisk(
	double currentTime, Host host, double dataSize
    ) {
	HostInfo info = getHostInfo(currentTime, host);
	//System.out.println(
	SimulationDebug.println(
	    host + ": (availableDiskSize, dataSize) = (" + 
	    info.availableDiskSize + ", " + dataSize + ")");
	if (info.availableDiskSize > dataSize)
	    return true;
	else
	    return false;
    }

/************************* protected method *************************/

    protected void probe(double currentTime) {
	Enumeration e = resourceDB.hosts();
	while (e.hasMoreElements()) {
	    Host host = (Host) e.nextElement();
	    HostInfo hostInfo = host.getHostInfo(currentTime, trackingTime,
						 trackingTimeForAccess);
	    printLog(this + " " + hostInfo);
	    SimulationDebug.println("ServerMonitor: putHostInfo()");
	    resourceDB.putHostInfo(hostInfo);
	}
    }

/******************** aren't called at this point ********************/
    /*
    protected int numHosts() {
	hostList = resourceDB.getHostList();
	return hostList.size();
    }

    protected void registerNewServer(Server node) {
	hostList = resourceDB.getHostList();
	hostList.addElement(node);
    }

    protected void deleteServer(Server node) {
	hostList = resourceDB.getHostList();
	hostList.removeElement(node);
    }
    */
}
