package ninf.proxy;
import ninf.basic.*;
import ninf.client.*;
import java.util.Vector;
import java.util.Hashtable;
import java.io.IOException;
import java.net.*;

public class Proxy{
  public static NinfLog dbg = new NinfLog("Proxy");
  ProxyConfig conf;
  OutSideProxy oproxy;

  Hashtable portManagers;

  void usage(){
    dbg.println("USAGE: java ninf.proxy.Proxy [-port PORT] [-debug] CONFIGFILE");
  }

  PortManager addPortManager(NinfCommand com) throws CommandParseException{
    int serverport = (new Integer(com.args[1])).intValue();
    int port;
    if (serverport == 0)
      throw new CommandParseException(""+com);
    NinfServerStruct server = new NinfServerStruct(com.args[0], serverport);
    PortManager tmp = new PortManager(server, 0, this);
    port = tmp.start();
    portManagers.put(new Integer(port), tmp);
    return tmp;
  }

  void startPortManagers(){
    portManagers = new Hashtable();
    Vector stringsVec = conf.getContent("server");
    for (int i = 0; i < stringsVec.size(); i++){
      String args[] = (String[])stringsVec.elementAt(i);
      if (args.length < 2)
	dbg.log("informal server definition in the Configfile");
      NinfServerStruct server = new NinfServerStruct(args[0], (new Integer(args[1])).intValue());
      int port = args.length > 2 ? (new Integer(args[2])).intValue(): 0;
      PortManager tmp = new PortManager(server, port, this);
      tmp.allowedHosts = conf.allowedHosts;
      port = tmp.start();
      portManagers.put(new Integer(port), tmp);
      tmp.registerToMetaServer(conf.metaServer);
    }
  }

  void start(String args[]){
    NinfLog.log();
    try {
      conf = new ProxyConfig(args);
      conf.configure();
    } catch (NinfException e){
      e.printStackTrace();
      usage();
      System.exit(3);
    }
    PortManager.lookup = conf.lookup;
    NinfServerConnection.lookup = conf.lookup;
    MetaServerConnection.lookup = conf.lookup;
    startPortManagers();
    oproxy = new OutSideProxy(conf.myhostname, conf.port, this);
    oproxy.lookup = conf.lookup;
    oproxy.start();
  }

  public static void main(String args[]){
    new Proxy().start(args);
  }
}
