#! /bin/sh
# $Id: binclean.sh,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $

for arg in "$@"
do
    case $arg in
	*=*) eval `expr ${arg} : '\(.*\)='`=`expr ${arg} : '.*=\(.*\)'`
        ;;
        *)
        ;;
    esac
done

[ x"${MAKE}" = x"" ] && exit 3
[ x"${TOPDIR}" = x"" ] && exit 3
[ x"${THISDIR}" = x"" ] && exit 3
[ x"${BINDIR}" = x"" ] && exit 3


if [ -d lib ] ; then
    cd lib && \
    ${MAKE} clean && \
    cd .. 
fi

if [ -d ${BINDIR} ] ; then

    cd ${BINDIR} || exit 2

    for idl in ${THISDIR}/*idl ; do
	endmark=`basename ${idl} | sed -e 's!\(.*\)\.idl!.\1!'`
	[ x"${endmark}" = x"" ] && exit 3
	if [ -f ${THISDIR}/$endmark ] ; then
	    funclist="`grep Define ${idl} | sed -e 's!^.*Define !!;s!(.*$!!'`"
	    for funcname in  $funclist ; do
		rm  _stub_${funcname}*
		rm  _inf_${funcname}*
		rm  scalapack::${funcname}*
	    done;
	    rm ${THISDIR}/${endmark}
	fi
    done 

    for header in *h ; do
	if [ -L $header ] ; then
	    rm $header 
	fi
    done 

fi