#define _WRAPPER_
/* $Id: pclarfg_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define SCOMPLEX
#include <gscalapack.h>

void  pclarfg_ninf(	 int n,
		 scomplex *alpha,
		 scomplex global_vx[],
		 int incx,
		 scomplex *global_tau
)
/* "pclarfg generates a complex elementary reflector H of order n, such that\\n */
/*    H * X = H * (     x(1,1) ) = ( alpha ),   H' * H = I. \\n */
/*                (      x     )   (   0   ) \\n */
/* where alpha is a real scalar, and X is a complex distributed vector X. H is represented in the form\\n */
/*       H = I - tau * ( 1 ) * ( 1 v' ) ,\\n */
/*                     ( v ) \\n */
/* where tau is a complex scalar and v is a complex (N-1)-element vector. Note that H is not Hermitian." */
/* OPTIONS */
{
	int maxldd;

	int maxldvx;
	scomplex *locvx=NULL;
	int descvx[DESCLEN];
	int desc_gvx[DESCLEN];
	int row_locvx, col_locvx;
	int ROW_vx, COL_vx;

	int iax = 1;
	int jax = 1;

	int ix=1;
	int jx=2;

	scomplex loctau[1];

	INITIALIZE();

	SCALAR( "int", n);
	SCALAR("int", incx);

	COMMON("scomplex", alpha,1);

	square(1+(n-1)*abs(incx), &ROW_vx, &COL_vx);
	ROW(vx);
	COL(vx);
	MAXLDD(maxldd,vx);
	maxldvx=maxldd;

	MATRIX("scomplex", vx, ROW_vx, COL_vx);
	DISTRIBUTE( "scomplex", vx, ROW_vx, COL_vx);

	locvx[(iax-1)+(jax-1)*n] = *alpha;	

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pclarfg)( &n, alpha,
                               &iax, &jax,
                               locvx, &ix, &jx, descvx,
                               &incx,
                               loctau);

	GATHER( "scomplex", vx, ROW_vx, COL_vx);

	RETRIEVE("scomplex", alpha, 1);
	RETRIEVE("scomplex", loctau, 1);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
		*global_tau = loctau[0]; 
	} else {
	}

	FREE_COMMON(alpha);
	FREE_MATRIX(vx);
}

