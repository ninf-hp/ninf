package bricks.scheduling;
import bricks.util.*;
import bricks.environment.*;
import java.util.*;

public class GreedyReplicationScheduler extends DataGridScheduler implements SchedulingUnit {

    public GreedyReplicationScheduler(
	String keyOfMetaPredictor, String keyOfReplicaManager,
	String keyOfServerMonitor
    ) {
	this.keyOfMetaPredictor = keyOfMetaPredictor;
	this.keyOfReplicaManager = keyOfReplicaManager;
	this.keyOfServerMonitor = keyOfServerMonitor;
	schedulingOverhead = 0.0;
    }

/************************* needed method *************************/
    public String getName() {
	return "GreedyReplicationScheduler";
    }
}

