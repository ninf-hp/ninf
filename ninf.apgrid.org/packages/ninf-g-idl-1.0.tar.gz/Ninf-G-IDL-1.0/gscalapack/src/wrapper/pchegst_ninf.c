#define _WRAPPER_
/* $Id: pchegst_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define SCOMPLEX
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n
#define ROW_b ldb
#define COL_b n
void  pchegst_ninf(	 int ibtype,
		 char uplo,
		 int n,	/*  n >= 0 */
		 scomplex global_a[],
		 int lda,
		 scomplex global_b[],
		 int ldb,
		 float *scale,
		 int *info
)
/* "pchegst reduces a complex Hermitian-definite generalized eigenproblem to standard form.\\n */
/*  If IBTYPE = 1, the problem is  A *x = lambda* B *x, and  A is overwritten by inv(U**H)* A *inv(U) or inv(L)* A *inv(L**H)\\n */
/*  If IBTYPE = 2 or 3, the problem is  A* B *x = lambda*x or B* A *x = lambda*x, and A is overwritten by  U*sub( A )*U**H or L**H*sub( A )*L.\\n  B must have been previously factorized as U**H*U or L*L**H by  PCPOTRF." */
/* OPTIONS */
{
	int maxldd;

	int maxlda;
	scomplex *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
	int row_loca, col_loca;

	int maxldb;
	scomplex *locb=NULL;
	int descb[DESCLEN];
	int desc_gb[DESCLEN];
	int row_locb, col_locb;

	float locscale[1];

	INITIALIZE();

	SCALAR("int",ibtype);
	SCALAR("char",uplo);
	SCALAR("int",n);
	SCALAR( "int", lda);
	SCALAR( "int", ldb);

	ROW(a);
	COL(a);
	ROW(b);
	COL(b);
	MAXLDD(maxldd,a );
	maxlda=maxldd;
	maxldb=maxldd;

	trMATRIX( uplo, "scomplex", a, ROW_a, COL_a );
	trDISTRIBUTE( uplo, "scomplex", a, ROW_a, COL_a  );
	MATRIX( "scomplex", b, ROW_b, COL_b );
	DISTRIBUTE("scomplex", b, ROW_b, COL_b );

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pchegst)( &ibtype, &uplo, &n,
                               loca, &one, &one, desca,
                               locb, &one, &one, descb,
                               locscale,
                               &linfo);

	GATHER("scomplex", a, ROW_a, COL_a);
	RETRIEVE( "float", locscale, 1);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
		*info = linfo;
		*scale=locscale[0];
	} else {
	}

	FREE_MATRIX(a);
	FREE_MATRIX(b);
	
}

