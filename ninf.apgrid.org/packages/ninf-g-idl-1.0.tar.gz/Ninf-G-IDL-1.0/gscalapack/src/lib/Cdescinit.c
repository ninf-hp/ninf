/*
 * Cdescinit
 * 
 *
 * Written by Keita Teranishi
 * Date: 8/11/1999
 */


void Cdescinit( int desc[], int m, int n, int mb, int nb, int irsrc,
                   int icsrc, int ictxt, int lld, int *info )
{
   int nprow, npcol, myrow, mycol;

   Cblacs_gridinfo( ictxt, &nprow, &npcol, &myrow, &mycol );

   *info = 0;
   
   if( m < 0 ) 
      *info = -2;
   else if ( n < 0 )
      *info = -3;
   else if ( mb < 1 )
      *info = -4;
   else if ( nb < 1 )
      *info = -5;
   else if ( irsrc < 0 || irsrc > nprow )
       *info = -6;
   else if ( icsrc < 0 || icsrc > npcol )
      *info = -7;
   else if ( nprow == -1 )
      *info = -8;
   else if( lld < Cnumroc( m, mb, myrow, irsrc, nprow ) )
     *info = -9;

   desc[0]=1;  /* Block Cyclic 2d */
   desc[1]=ictxt;
   desc[2]=m;
   desc[3]=n;
   desc[4]=mb;
   desc[5]=nb;
   desc[6]=irsrc;
   desc[7]=icsrc;
   desc[8]=lld;
}

void Cbanddescinit( char major ,int desc[], int n, int nb, int src,
                    int ictxt, int lld, int *info )
{
   int nprow, npcol, myrow, mycol;

   Cblacs_gridinfo( ictxt, &nprow, &npcol, &myrow, &mycol );

   *info = 0;
   

   if( major == 'c' ) 
      desc[0]=501;  /* Block Columns */
   else if ( major == 'r' )
      desc[0]=502;
   else
      *info = -1; 
   desc[1]=ictxt;
   desc[2]=n;
   desc[3]=nb;
   desc[4]=src;
   desc[5]=lld;
   desc[6]=0;
}
