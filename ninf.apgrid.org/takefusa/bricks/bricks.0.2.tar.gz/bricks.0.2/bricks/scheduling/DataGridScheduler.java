package bricks.scheduling;
import bricks.environment.*;
import bricks.util.*;
import java.util.*;

public abstract class DataGridScheduler extends Scheduler {

    protected ReplicaManager replicaManager;
    protected String keyOfReplicaManager;
    protected ServerMonitor serverMonitor;
    protected String keyOfServerMonitor;
    protected Random random = new Random();

    protected OwnerComputesScheduler ownerComputesScheduler;
    protected double specifiedSize = 10000.0;

    /************************* public method *************************/
    public void init(SimulationSet owner) {
	super.init(owner);
	replicaManager = owner.getReplicaManager(keyOfReplicaManager);
	serverMonitor = owner.getServerMonitor(keyOfServerMonitor);
	if (replicaManager == null)
	    BricksUtil.abort(getName() + ": Bad ReplicaManager name: " + 
			     keyOfReplicaManager);
	if (serverMonitor == null)
	    BricksUtil.abort(getName() + ": Bad ServerMonitor name: " + 
			     keyOfServerMonitor);

	if (!(this instanceof OwnerComputesScheduler)) {
	    ownerComputesScheduler = new OwnerComputesScheduler(
		keyOfMetaPredictor, keyOfReplicaManager, keyOfServerMonitor
	    );
	    ownerComputesScheduler.init(owner);
	}
    }
    public void selectHosts(
	double currentTime, Host source, RequestedData data
    ) throws BricksNotScheduledException {

	// only small data!!
	if (data.dataSizeForSend != specifiedSize) {
	    ownerComputesScheduler.selectHosts(currentTime, source, data);
	    return;
	}

 	//System.out.println(
 	SimulationDebug.println(
	     "DataGridScheduler.selectHost(): host = " + source + 
	     ", data = " + data + ", requiredDataID = " + data.requiredDataID);

	boolean doneGC = false;
	Host selectedHost = null;
	while (selectedHost == null) {
	    Enumeration e = resourceDB.hosts(data);
	    selectedHost = select(currentTime, data, e);

	    /* copy version only */
	    //Vector v = resourceDB.dataSourceHostList(data);
	    //if (!v.contains(selectedHost)) {
	    //data.moveAtSend = true;
	    //}

	    if (selectedHost != null) {
		updateStatus(
		    currentTime, selectedHost, selectedHost, 
		    data.dataDestination, data
		);

	    } else {  // for fallback
		//if (data.numSchedule() == 0)
		//throw new BricksNotScheduledException(this.toString());

		if (doneGC) {
		    BricksUtil.abort("The specified environment does not have enough disk space at " + currentTime + ".");
		    

		} else {
		    replicaManager.garbageCollection(currentTime, data.dataFragment);
		    SimulationDebug.println("DataGridScheduler calls replicaManager.gc");
		    doneGC = true;
		}
	    }
	}
	SimulationDebug.println(
	    getName() + ": select " + selectedHost + 
	    " for " + data + " at " + currentTime
	);
    }

    /************************* protected method *************************/
    protected double getEstimate(
	double currentTime, Host computeServer, RequestedData data
    ) {
	if (resourceDB.hasData(computeServer, data.requiredDataID)) {
	    return getEstimate(
		currentTime, computeServer, computeServer, 
		data.dataDestination, data
	    );
	} else {
	    //System.out.println("DataGridScheduler: " + computeServer + 
	    SimulationDebug.println("DataGridScheduler: " + computeServer + 
				    " does not have " + data.requiredDataID);
	    double min = Double.POSITIVE_INFINITY;
	    Enumeration e = resourceDB.dataSourceHosts(data);
	    while (e.hasMoreElements()) {
		Host host = (Host)e.nextElement();
		double estimate = 
		    getEstimate(currentTime, host, computeServer,
				data.dataDestination, data);
		if (estimate < min) {
		    min = estimate;
		    data.setDataSource(host);
		}
	    }

	    //System.out.println("DataGridScheduler: data.dataSource = " + 
	    SimulationDebug.println("DataGridScheduler: data.dataSource = " + 
				    data.dataSource + " for " + data);
	    return min;
	}
    }

    protected double getEstimate(
	double currentTime, Host dataSource, Host computeServer, 
	Host dataDestination, RequestedData data
    ) {
	if (dataDestination == null)
	    dataDestination = computeServer;

	// compute Comptation elapsedTime
	double comp = getComputationEstimate(
	    currentTime, computeServer, data.numInstructions
	);
	    
	// compute Communication elapsedTime: send
	double send = getCommunicationEstimate(
	    currentTime, dataSource, computeServer, data.dataSizeForSend
	);

	// compute Communication elapsedTime: receive
	double recv = getCommunicationEstimate(
	    currentTime, computeServer, dataDestination, 
	    data.dataSizeForReceive
	);

	return comp + send + recv;
    }

    protected double getEstimateOfSendAndComputeDuration(
	double currentTime, Host dataSource, Host computeServer, 
	RequestedData data
    ) {
	// compute Comptation elapsedTime
	double comp = getComputationEstimate(
	    currentTime, computeServer, data.numInstructions
	);

	// compute Communication elapsedTime: send
	double send = getCommunicationEstimate(
	    currentTime, dataSource, computeServer, data.dataSizeForSend
	);
	return comp + send;
    }

    protected void updateStatus(
	double currentTime, Host dataSource, Host computeServer, 
	Host dataDestination, RequestedData data
    ) {
	SimulationDebug.println("updateState for single task job");

	/* add scheduling overhead */
	//data.timeEventComes = data.timeEventComes + schedulingOverhead;
	data.timeEventComes = currentTime + schedulingOverhead;
	if (data.dataSource == null)
	    data.setDataSource(dataSource);
	if (dataDestination == null) {
	    data.dataDestination = computeServer;
	    dataDestination = computeServer;
	}
	if (data.deadlineFactor > 0)
	    data.setElapsedTime(data.deadline - currentTime);
	StaticHostInfo info = resourceDB.getStaticHostInfo(computeServer);
	data.putDestination(computeServer, info.priority);
	storeSchedulingInfo(
	    currentTime, dataSource, computeServer, dataDestination, data
	);
    }
	
    protected void storeSchedulingInfo(
	double currentTime, Host dataSource, Host computeServer, 
	Host dataDestination, RequestedData data
    ) {
	data.putEstimate(
	    getCommunicationEstimate(
	        currentTime, dataSource, computeServer, data.dataSizeForSend
	    ), 
	    getCommunicationEstimate(
	        currentTime, computeServer, dataDestination, 
		data.dataSizeForReceive
	    ), 
	    getComputationEstimate(
	        currentTime, computeServer, data.numInstructions
	    )
	);
	metaPredictor.addServerLoad(currentTime, computeServer, data);
	metaPredictor.addNetworkLoad(
	    currentTime, dataSource, computeServer, data
	);
	resourceDB.putSchedulingInfo(data);
    }

    // override this method to take disk I/O into account.
    protected double getCommunicationEstimate(
	double currentTime, Host source, Host destination, double dataSize
    ) {
	double throughput = 0.0;
	if (source.equals(destination)) {
	    StaticHostInfo info = resourceDB.getStaticHostInfo(source);
	    throughput = info.diskThroughput;

	} else {
	    StaticHostInfo sInfo = resourceDB.getStaticHostInfo(source);
	    StaticHostInfo dInfo = resourceDB.getStaticHostInfo(destination);
	    NetworkInfo nInfo = metaPredictor.getNetworkInfo(
		currentTime, source, destination
	    );
	    throughput = nInfo.throughput;
	    if (throughput > sInfo.diskThroughput)
		throughput = sInfo.diskThroughput;
	    if (throughput > dInfo.diskThroughput)
		throughput = dInfo.diskThroughput;
	}

	double estimate = dataSize / throughput;
	SimulationDebug.println(
	    this + ": " + source + "-" + destination + 
	    " : network estimate = " + estimate
	);
	return estimate;
    }

    protected HostInfo getHostInfo(double currentTime, Host host) {
	return serverMonitor.getHostInfo(currentTime, host);
    }

    protected Host select(
	double currentTime, RequestedData data, Enumeration e
    ) {
	Host selectedHost = null;
	double minElapsedTime = Double.POSITIVE_INFINITY;
	Host dataSource = null;
	while (e.hasMoreElements()) {
	    Host h = (Host)e.nextElement();
	    if (data.scheduled(h)) //for fallback
		continue;
	    if (!hasAvailableDisk(currentTime, data, h)) {
		SimulationDebug.println(h + " has no disk space for " + data);
		continue;
	    }
	    if (dispatchOK(currentTime, data, h)) {
		/* set data.dataSource!!!! */
		double elapsedTime = getEstimate(currentTime, h, data);
		if (minElapsedTime > elapsedTime) {
		    minElapsedTime = elapsedTime;
		    selectedHost = h;
		    dataSource = data.dataSource;
		    data.setDataSource(null);
		}
	    }
	}
	// for *Bound*TimeReplicationScheduler
	if (selectedHost == null) {
	    e = resourceDB.hosts(data);
	    while (e.hasMoreElements()) {
		Host h = (Host)e.nextElement();
		if (data.scheduled(h)) //for fallback
		    continue;
		if (!hasAvailableDisk(currentTime, data, h)) {
		    SimulationDebug.println(h + " has no disk space for " + data);
		    continue;
		}
		double elapsedTime = getEstimate(currentTime, h, data);
		if (minElapsedTime > elapsedTime) {
		    minElapsedTime = elapsedTime;
		    selectedHost = h;
		    dataSource = data.dataSource;
		    data.setDataSource(null);
		}
	    }
	}
	if (selectedHost != null) {
	    data.setDataDestination(selectedHost);
	}
	data.setDataSource(dataSource);
	//System.out.println(
	SimulationDebug.println(
	     "DataGridScheduler.select(): select dataSource = " + dataSource +
	     ", selectedHost = " + selectedHost);
	return selectedHost;
    }

    protected Host selectBySendAndComputeDuration(
	double currentTime, RequestedData data, Enumeration e
    ) {
	// select computeHost
	Host selectedHost = null;
	double minElapsedTime = Double.POSITIVE_INFINITY;
	while (e.hasMoreElements()) {
	    Host h = (Host)e.nextElement();
	    if (data.scheduled(h)) { //for fallback
		continue;
	    }
	    if (!hasAvailableDisk(currentTime, data, h)) {
		continue;
	    }
	    if (resourceDB.hasData(h, data.requiredDataID)) {
		double elapsedTime = getEstimateOfSendAndComputeDuration(
		    currentTime, h, h, data
		);
		if (minElapsedTime > elapsedTime) {
		    minElapsedTime = elapsedTime;
		    selectedHost = h;
		}
	    }
	}

	// select destinationHost
	if (selectedHost != null) {
	    data.setDataDestination(selectedHost);
	    if (!dispatchOK(currentTime, data, selectedHost)) {
		if (data.dataSizeForReceive == specifiedSize) {
		    Host destination = 
			selectDataDestination(currentTime, data, selectedHost);
		    if (destination != null)
			data.setDataDestination(destination);
		}
	    }
	}
	return selectedHost;
    }

    protected boolean dispatchOK(
	double currentTime, RequestedData data, Host host
    ) {
	return true;
    }

    protected Host selectDataDestination(
	double currentTime, RequestedData data, Host selectedHost
    ) {
	return selectedHost;
    }

    protected Vector shuffle(Enumeration e) {
	Vector v = new Vector();
	while (e.hasMoreElements()) {
	    int index = (int)(random.nextDouble() * v.size());
	    v.insertElementAt(e.nextElement(), index);
	}
	return v;
    }

    protected boolean hasAvailableDisk(
	double currentTime, RequestedData data, Host computeServer
    ) {
	SimulationDebug.println(
	    getName() + " " + Format.format(currentTime, 3) + " data(" + data +
	    ") dataFragmentID = " + data.requiredDataID);
	if (resourceDB.hasData(computeServer, data.requiredDataID))
	    return serverMonitor.hasAvailableDisk(
		currentTime, computeServer, data.dataSizeForReceive);
	else
	    return serverMonitor.hasAvailableDisk(
		currentTime, computeServer, 
		data.dataSizeForSend + data.dataSizeForReceive);
    }

    protected boolean hasAvailableDisk(
	double currentTime, Host host, double dataSize
    ) {
	return serverMonitor.hasAvailableDisk(currentTime, host, dataSize);
    }
}
