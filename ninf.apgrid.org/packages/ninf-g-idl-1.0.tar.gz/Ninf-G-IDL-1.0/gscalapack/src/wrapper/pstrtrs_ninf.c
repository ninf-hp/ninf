#define _WRAPPER_
/* $Id: pstrtrs_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define FLOAT
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n
#define ROW_b ldb
#define COL_b nrhs
void  pstrtrs_ninf(	 char uplo,
		 char trans,
		 char diag,
		 int n,
		 int nrhs,
		 float global_a[],
		 int lda,
		 float global_b[],
		 int ldb,
		 int *info
)
/* "pstrtrs solves a triangular system of the form A * X = B or A**T * X =  B, where A is a triangular distributed matrix of order N, and B is an N-by-NRHS distributed matrix." */
/* OPTIONS */
{
extern void FortranCall(pstrtrs)( char*, char*, char*,
				  int*, int*,
				  float*, int*, int*, int*,
				  float*, int*, int*, int*,
				  int*);
	int maxldd;

	int maxlda;
	float *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
	int row_loca, col_loca;

	int maxldb;
	float *locb=NULL;
	int descb[DESCLEN];
	int desc_gb[DESCLEN];
	int row_locb, col_locb;

	INITIALIZE();

	SCALAR( "char", uplo);
	SCALAR( "char", trans);
	SCALAR( "char", diag);
	SCALAR( "int", n);
	SCALAR( "int", nrhs);
	SCALAR( "int", lda);
	SCALAR( "int", ldb);

	ROW( a);
	COL( a);
	ROW( b);
	COL( b);
	MAXLDD( maxldd, a );
	maxlda = maxldd;
	maxldb = maxldd;

	trMATRIX( uplo, "float", a, ROW_a, COL_a);
	trDISTRIBUTE( uplo, "float", a, ROW_a, COL_a);
	MATRIX( "float", b, ROW_b, COL_b);
	DISTRIBUTE( "float", b, ROW_b, COL_b);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pstrtrs)( &uplo, &trans, &diag,
                               &n, &nrhs,
                               loca, &one, &one, desca,
                               locb, &one, &one, descb,
                               &linfo);

	GATHER( "float", b, ROW_b, COL_b);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
		*info = linfo;
	} else {
	}

	FREE_MATRIX(a);
	FREE_MATRIX(b);
}

