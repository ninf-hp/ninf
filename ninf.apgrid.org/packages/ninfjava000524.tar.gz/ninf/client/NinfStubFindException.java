package ninf.client;
import ninf.basic.NinfException;

public class NinfStubFindException extends NinfException {
  public NinfStubFindException(){
    super();
  }
}


