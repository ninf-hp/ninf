#define _WRAPPER_
/* $Id: psggrqf_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define FLOAT
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n
#define ROW_b ldb
#define COL_b n
static	int worklen(int m, int n, int p) {
	  int ret=1;
	  int IROFFA, ICOFFA, IAROW, IACOL, NpA0, MqA0, IROFFB, ICOFFB;
	  int IBROW, IBCOL, NpB0, PqB0;
          int MpA0, NqA0, PpB0, NqB0;
#define IA 1
#define JA 1
#define MB_A rbloc
#define NB_A cbloc
#define RSRC_A 0
#define CSRC_A 0
#define IB 1
#define JB 1
#define MB_B rbloc
#define NB_B cbloc
	  ret = MAX( max(m * ( m + n + m ),
		     MAX( (m*(m-1))/2, (p + n)*m ) +
		     m * m),
		     n * ( p + n + n ) );
	  if NEED_BUFF {
	    IROFFA = MOD( IA-1, MB_A );
	    ICOFFA = MOD( JA-1, NB_A );
	    IAROW  = INDXG2P( IA, MB_A, MYROW, RSRC_A, NPROW );
	    IACOL  = INDXG2P( JA, NB_A, MYCOL, CSRC_A, NPCOL );
	    MpA0   = NUMROC( M+IROFFA, MB_A, MYROW, IAROW, NPROW );
	    NqA0   = NUMROC( N+ICOFFA, NB_A, MYCOL, IACOL, NPCOL );
	    IROFFB = MOD( IB-1, MB_B ), ICOFFB = MOD( JB-1, NB_B );
	    IBROW  = INDXG2P( IB, MB_B, MYROW, RSRC_B, NPROW );
	    IBCOL  = INDXG2P( JB, NB_B, MYCOL, CSRC_B, NPCOL );
	    PpB0   = NUMROC( p+IROFFB, MB_B, MYROW, IBROW, NPROW );
	    NqB0   = NUMROC( N+ICOFFB, NB_B, MYCOL, IBCOL, NPCOL );
	    ret = MAX( max(MB_A * ( MpA0 + NqA0 + MB_A ),
		       MAX( (MB_A*(MB_A-1))/2, (PpB0 + NqB0)*MB_A ) +
		       MB_A * MB_A),
		       NB_B * ( PpB0 + NqB0 + NB_B ) );
	  }
	  return ret;
}

void  psggrqf_ninf(	 int m,
		 int p,
		 int n,
		 float global_a[],
		 int lda,
		 float global_taua[],
		 float global_b[],
		 int ldb,
		 float global_taub[],
		 float work[],
		 int lwork,
		 int *info
)
/* "psggrqf computes a generalized RQ factorization of an M-by-N matrix A and a P-by-N matrix B:\\n\\n              sub( A ) = R*Q,        sub( B ) = Z*T*Q,\\n\\n  where Q is an N-by-N orthogonal matrix, Z is a P-by-P orthogonal matrix, and R and T assume one of the forms:\\n\\n  if M <= N,  R = ( 0  R12 ) M,   or if M > N,  R = ( R11 ) M-N,\\n                   N-M  M                           ( R21 ) N\\n                                                       N\\n\\n  where R12 or R21 is upper triangular, and\\n\\n  if P >= N,  T = ( T11 ) N  ,   or if P < N,  T = ( T11  T12 ) P,\\n                  (  0  ) P-N                         P   N-P\\n                     N\\n\\n  where T11 is upper triangular." */
/* OPTIONS */
{
	int maxldd;

	int maxlda;
	float *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
	int row_loca, col_loca;


	int maxldb;
	float *locb=NULL;
	int descb[DESCLEN];
	int desc_gb[DESCLEN];
	int row_locb, col_locb;

	float *loctaua=NULL;
	float *loctaub=NULL;

	float *locwork=NULL;
	int llocwork;



	INITIALIZE();

	SCALAR( "int", m);
	SCALAR( "int", p);
	SCALAR( "int", n);
	SCALAR("int",lda);
	SCALAR("int",ldb);
	SCALAR("int",lwork);

	ROW( a);
	COL( a);
	ROW( b);
	COL( b);
	MAXLDD( maxldd, a );
	maxlda = maxldd;
	maxldb = maxldd;

	MATRIX( "float", a, ROW_a, COL_a);
	MATRIX( "float", b, ROW_b, COL_b);
	VECTOR( "r", "float", taua, m);
	VECTOR( "c", "float", taub, min(p,n));

        llocwork = worklen(m, n, p);
	llocwork = max(lwork,llocwork);
	WORK(locwork,llocwork);

	DISTRIBUTE( "float", a, ROW_a  , COL_a);
	DISTRIBUTE( "float", b, ROW_b  , COL_b);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(psggrqf)( &m, &p, &n,
                               loca, &one, &one, desca,
                               loctaua,
                               locb, &one, &one, descb,
                               loctaub,
                               locwork, &llocwork, &linfo);

	GATHER( "float", a, ROW_a  , COL_a);
	GATHER( "float", b, ROW_b  , COL_b);

	vGATHER( "r", "float", taua, m);
	vGATHER( "c", "float", taub, min(p,n));

	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
	  *info = linfo;
	} else {
	}

	FREE_MATRIX(a);
	FREE_MATRIX(taua);
	FREE_MATRIX(b);
	FREE_MATRIX(taub);
        FREE(locwork);
	
}

