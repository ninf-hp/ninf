#define _WRAPPER_
/* $Id: pzgeequ_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define DCOMPLEX
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n
void  pzgeequ_ninf(	 int m,
		 int n,
		 dcomplex global_a[],
		 int lda,
		 double global_r[],
		 double global_c[],
		 double *rowcnd,
		 double *colcnd,
		 double *amax,
		 int *info
)
/* "pzgeequ computes row and column scalings intended to equilibrate an M-by-N distributed matrix A and reduce its condition number.  R returns the row scale factors and C the column scale factors, chosen to try to make the largest entry in each row and column of the distributed matrix B with elements B(i,j) = R(i) * A(i,j) * C(j) have absolute value 1." */
/* OPTIONS */
{
	int maxldd;
	int maxlda;
	dcomplex *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
	int row_loca, col_loca;
        
	double *locr=NULL;
	double *locc=NULL;

	double locrowcond[1], loccolcond[1], locamax[1];

	INITIALIZE();

	SCALAR( "int", m);
	SCALAR( "int", n);
	SCALAR( "int", lda);

	ROW( a);
	COL( a);
	MAXLDD( maxldd, a );
	maxlda = maxldd;

	MATRIX( "dcomplex", a, ROW_a, COL_a);
	DISTRIBUTE( "dcomplex", a, ROW_a  , COL_a);
	VECTOR("r", "double", r, m);
	VECTOR("c", "double", c, n);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pzgeequ)( &m, &n,
                               loca, &one, &one, desca,
                               locr, locc,
                               locrowcond, loccolcond, locamax,
                               &linfo);

	vGATHER("r", "double", r, m);
	vGATHER("c", "double", c, n);
        RETRIEVE("double",locrowcond,1);
        RETRIEVE("double",loccolcond,1);
        RETRIEVE("double",locamax,1);
        
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
	  *rowcnd=*locrowcond;
	  *colcnd=*loccolcond;
	  *amax=*locamax;
	  *info = linfo;
	} else {
		
	}

	FREE_MATRIX(a);
	FREE_VECTOR(r);
	FREE_VECTOR(c);
	
}

