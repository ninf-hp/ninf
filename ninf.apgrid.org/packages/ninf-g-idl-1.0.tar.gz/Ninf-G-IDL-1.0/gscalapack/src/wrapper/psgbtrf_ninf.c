#define _WRAPPER_
/* $Id: psgbtrf_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define _DISTRIBUTE_1D_
#define FLOAT
#define PIVOT
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n
static	int worklen() {
	  int ret=1;
	  ret = 10;
	  if NEED_BUFF {
	    ret = max(10,blocsize);
	  }
	  return ret;
}

void  psgbtrf_ninf(	 int n,
		 int bwl,
		 int bwu,
		 float global_a[],
		 int lda,
		 int global_ipiv[],
		 int *info
)
/* "psgbtrf computes a LU factorization of an N-by-N real banded distributed matrix with bandwidth BWL, BWU: A." */
/* OPTIONS */
{
    extern void FortranCall(psgbtrf)( int*, int*, int*,
                               float*, int*, int*,
                               int*,
                               float*, int*,
                               float*, int*, int*);

	int maxldd;

	float *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];

	float *locaf=NULL;
	int laf;

	int *locipiv=NULL;

	float *locwork=NULL;
	int llocwork;



	INITIALIZE();

	SCALAR( "int", n);
	SCALAR( "int", bwl);
	SCALAR( "int", bwu);
	SCALAR("int", lda);

	SIZE(n);

	bandMATRIX( "float", a, bwl, bwu, n);
	bandDISTRIBUTE( "float", a, bwl, bwu, n);
	VECTOR( "c", "int", ipiv, n);

	llocwork=worklen();
	WORK(locwork,llocwork);

	laf=(blocsize+bwu)*(bwl+bwu)+6*(bwl+bwu)*(bwl+2*bwu);
	locaf=MALLOC(sizeof(float)*laf); assert(locaf);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(psgbtrf)( &n, &bwl, &bwu,
                               loca, &one, desca,
                               locipiv,
                               locaf, &laf,
                               locwork, &llocwork, &linfo);

	bandGATHER( "float", a,  bwl, bwu, n);
	vGATHER( "c", "int", ipiv, n);

	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
	  *info = linfo;
	} else {
	}
	FREE_MATRIX(a);
	FREE_MATRIX(ipiv);
	FREE_MATRIX(af);
        FREE(locaf);
	
}

