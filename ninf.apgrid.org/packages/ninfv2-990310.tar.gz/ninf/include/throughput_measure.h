#ifndef __THROUGHPUT_MEASURE_H__
#define __THROUGHPUT_MEASURE_H__


typedef struct communication_information{
  long rtt;
  int size;
  int mode;
} communication_information;

typedef struct measure_server{
  char * host;
  char * port;

  communication_information * throughput;
  communication_information * latency;

  struct measure_server * next;
} measure_server;

measure_server * new_measure_server(measure_server * link);

void measure_inter_server_throughput();
#endif
