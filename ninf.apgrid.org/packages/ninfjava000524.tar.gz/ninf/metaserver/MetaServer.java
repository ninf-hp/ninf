package ninf.metaserver;
import ninf.basic.*;
import ninf.client.*;
import java.util.Vector;
import java.net.*;
import java.io.*;

public class MetaServer {
  public static NinfLog dbg = new NinfLog("MetaServer");
  public static MetaServerConfig conf;
  MetaServerRoot metaServer;

  void usage(){
    dbg.println("USAGE: java ninf.metaserver.MetaServer [-port PORT] [-debug] CONFIGFILE");
  }

  void start(String args[]){
    MetaServerRoot metaServer = null;
    try {
      conf = new MetaServerConfig(args);
      conf.configure();
      metaServer = new MetaServerRoot(conf.myhostname, conf.port, this);
    } catch (NinfException e){
      System.err.println(e);
      usage();
      System.exit(3);
    }

    metaServer.start();
  }

  public static void main(String args[]){
    new MetaServer().start(args);
  }
}
