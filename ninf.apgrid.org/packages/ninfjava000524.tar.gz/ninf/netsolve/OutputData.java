package ninf.netsolve;
// import java.io.*;
import java.io.FileOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;

// import java.awt.*;
import java.awt.Button;
import java.awt.List;
import java.awt.Panel;
import java.awt.Frame;
import java.awt.BorderLayout;
import java.awt.Event;
import java.awt.TextArea;
import java.awt.FileDialog;
import java.awt.Font;
import java.awt.Label;

// import java.util.*;
import java.util.Vector;

public class OutputData extends Frame {

  private String [] data;

  private Button quit_button;
  private Button save_button;

  private List output_list;

  private TextArea data_box;
  private TextArea description;

  private Panel data_panel;

  private Frame parent;
  private Problem prob;

  private Label output_label;
  private Label desc_label;
  private Label data_label;

  private int cur_lang = Labels.language;

  public OutputData(Frame f, Problem p, Vector vec, String ident) {
    super(); 
    super.setTitle(Labels.output_title[cur_lang]+p.name+"' ("+ident+")"); 

    int i;

    parent = f;
    prob = p;

    this.setLayout(new BorderLayout(10,10)); 

    InitData id = new InitData(p,vec);
    try {
      id.join();
    }catch(InterruptedException e) {
      System.out.println("Interrupted..." + e.getMessage());
    }
    data = id.get_strArray();

Event evt1 = new Event(parent,Event.ACTION_EVENT,"HI THERE");
parent.postEvent(evt1);

//initialize all the checkbox and text field arrays
    data_box = new TextArea(10,35);
    data_box.setFont(new Font("Helvetica",Font.BOLD,12));

//create some buttons
    quit_button = new Button(Labels.dismiss[cur_lang]);
    quit_button.setFont(new Font("Helvetica",Font.BOLD,18));

    save_button = new Button(Labels.save_data[cur_lang]);
    save_button.setFont(new Font("Helvetica",Font.BOLD,18));
    save_button.disable();

    Panel output_panel = new Panel();
    output_panel.setLayout(new BorderLayout(5,5));

    output_list = new List(15,false);
    output_panel.add("South",output_list);

    output_label = new Label(Labels.outputs[cur_lang]);
    output_label.setFont(new Font("Helvetica",Font.BOLD,18));
    output_panel.add("North",output_label);
 
// define description panel
    Panel desc_panel = new Panel();
    desc_panel.setLayout(new BorderLayout(5,5));

    description = new TextArea(10,35);
    description.setFont(new Font("Helvetica",Font.BOLD,12));
    description.setEditable(false);
   
    desc_label = new Label(Labels.desc[cur_lang]);
    desc_label.setFont(new Font("Helvetica",Font.BOLD,18));

    desc_panel.add("North",desc_label);
    desc_panel.add("South",description);

    data_panel = new Panel();
    data_panel.setLayout(new BorderLayout(5,5));

    data_panel.add("South",data_box);

    data_label = new Label(Labels.data[cur_lang]);
    data_label.setFont(new Font("Helvetica",Font.BOLD,18));

    Panel data_save_panel = new Panel();
    data_save_panel.setLayout(new BorderLayout(5,5));
    
    data_save_panel.add("West",data_label);
    data_save_panel.add("East",save_button);

    data_panel.add("North",data_save_panel);

    Panel right_panel = new Panel();
    right_panel.setLayout(new BorderLayout(5,5));

    right_panel.add("North",data_panel);
    right_panel.add("South",desc_panel);
 
// define panel for buttons
    Panel left_panel = new Panel();
    left_panel.setLayout(new BorderLayout(5,5));

    left_panel.add("North",output_panel);
    left_panel.add("South",quit_button);

    this.add("West",left_panel);
    this.add("East",right_panel);

    for(i=0;i<prob.nb_output;i++)
      output_list.addItem( 
        NetSolveObject.datatype2str(prob.outputs[i].data_type) 
         + " - " +
        NetSolveObject.objtype2str(prob.outputs[i].object_type));
    
    data_box.setEditable(false);
    
    this.show();
    this.pack();
  }  

  private void save_data(String data, String filename) {
    FileOutputStream file_out;
    DataOutputStream out;

System.out.println("saving to file: "+filename);
    try {
      file_out = new FileOutputStream(filename);
    } catch (IOException e) {
      System.out.println("Can't create file: '"+filename+"'");
      NetSolveWarning n1 = 
        new NetSolveWarning(this,"Can't create file: '"+filename+"'");
      return;
    }

    out = new DataOutputStream(file_out);
 
    try {
      out.writeBytes(data);
    } catch (IOException e) {
      System.out.println("Error writing to file: "+filename);
      NetSolveWarning n1 = 
        new NetSolveWarning(this,"Error writing to file: '"+filename+"'");
      return;
    }

    try {
      out.close();
    } catch (IOException e) {
      System.out.println("Can't close file.");
      return;
    }
  }

  public boolean handleEvent(Event event) {

    switch(event.id) {

      case Event.ACTION_EVENT:
        if (event.target == quit_button) {
          this.hide();
          this.dispose(); 
        } 
        else if (event.target == save_button) {
          int selected = output_list.getSelectedIndex();

          // call file dialog to save data here
          FileDialog fd = new FileDialog(this,"Save data",FileDialog.SAVE);
          fd.show();
          if(fd.getFile() != null) {
            if(fd.getDirectory() == null) {
              save_data(data[selected], fd.getFile());
            } 
            else {
              save_data(data[selected],fd.getDirectory() + fd.getFile());
            }
          }
        } 
        break;

      case Event.LIST_SELECT:
        if (event.target == output_list) {
          int selected = output_list.getSelectedIndex();

          data_box.setText(data[selected]);
          description.setText(prob.outputs[selected].description);
          save_button.enable(); 
        }
        break;
      case Event.LIST_DESELECT:
        if (event.target == output_list) {
          save_button.disable();
        }
        break;
    }
    return true;
  }
}
