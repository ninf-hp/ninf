package ninf.cproxy;
import ninf.basic.*;
import java.util.Vector;
import java.util.Hashtable;
import java.io.IOException;
import java.io.*;

public class CProxyConfig extends Configure{
  static final int DEFAULT_PORT = 3002;

  static CommandRepresent initAcceptedCommands[] = {
    new CommandRepresent("metaserver",    2), 
    new CommandRepresent("myhostname",    1),
    new CommandRepresent("log",           1), 
    new CommandRepresent("port",          1),
    new CommandRepresent("lookup",        1),    
    new CommandRepresent("throughputSize",1),
    new CommandRepresent("MinimumSize",   1),
    new CommandRepresent("MaxmumSize",    1),
    new CommandRepresent("interval",      1),
    new CommandRepresent("measureTime",   1),
    new CommandRepresent("metaInterval",  1),
    new CommandRepresent("throughputlog", 1),
    new CommandRepresent("latchUp",       1),
    new CommandRepresent("aggregateSchedule", 1),

    new CommandRepresent("NWSuse",      1),
    new CommandRepresent("NWSdir",      1),
    new CommandRepresent("NWSMemoryDir",      1),
    new CommandRepresent("NWSinvokeSensor", 1),
    new CommandRepresent("NWSinvokeForecaster", 1),
    new CommandRepresent("NWSMemoryLog",      1),
    new CommandRepresent("NWSMemoryErr",      1),
    new CommandRepresent("NWSSensorLog",      1),
    new CommandRepresent("NWSSensorErr",      1),
    new CommandRepresent("NWSForecasterLog",      1),
    new CommandRepresent("NWSForecasterErr",      1),

    new CommandRepresent("allowHost",  1),
    new CommandRepresent("allowHost",  2)

  };
  static CommandRepresent initAcceptedOptions[] = {
    new CommandRepresent("-port",      1), 
    new CommandRepresent("-debug",     0),
    new CommandRepresent("-quiet",     0),
    new CommandRepresent("-version",   0)};

  CProxyConfig(String args[]) throws NinfException{
    super(args, initAcceptedCommands, initAcceptedOptions);
  }

  public void configure() throws NinfException{
    port = DEFAULT_PORT;
    super.configure();
    configureMetaServer();
    configureThroughputMeasurements();
    configureMetaInterval();
    configureThroughputLog();
    configureLatchUp();
    configureAggregateSchedule();
    configureNWS();
    configureAllowHost();
  }

  int throughputSize = 10000;    /* size for getting throughput */
  int minimumSize    = 1000;
  int maximumSize    = 10000000;
  int interval       = 100;      /* default ping interval in sec */
  double measureTime = 1.0;      /* measurement goal time in second */

  int metaInterval   = 100;      /* metaserver ping interval in sec */
  PrintStream throughputLogStream = null;
  public MetaServerReference metaServer;
  boolean latchUp = false;
  boolean aggregateSchedule = false;
  public Vector  initializers = new Vector();

  /** for IP restriction */
  boolean    allowAll = true;
  /** for IP restriction */
  IPHostList allowedHosts = new IPHostList();

  public boolean NWSuse = false;
  public String  NWSdir = null;
  public boolean NWSinvokeSensor = false;
  public boolean NWSinvokeForecaster = false;
  public String  NWSMemoryDir = null;
  public String  NWSMemoryLog = null;
  public String  NWSMemoryErr = null;
  public String  NWSSensorLog = null;
  public String  NWSSensorErr = null;
  public String  NWSForecasterLog = null;
  public String  NWSForecasterErr = null;

  public Class   TPingerClass = TPingerNative.getPingerClass();
  public String  NWSNameServer = null;

  private void configureNWS() throws NinfException{
    NWSuse              = getBoolean("NWSuse", NWSuse);
    NWSdir              = getOneArg("NWSdir");
    NWSMemoryDir        = getOneArg("NWSMemoryDir");
    NWSinvokeSensor     = getBoolean("NWSinvokeSensor", 
				     NWSinvokeSensor);
    NWSinvokeForecaster = getBoolean("NWSinvokeForecaster", 
				     NWSinvokeForecaster);
    try {
      if (NWSuse)
        initializers.addElement(Class.forName("ninf.nws.CProxyInitializerNWS"));
    } catch (ClassNotFoundException e){
	throw new ConfigureException("Cannot get intializer for NWS");
    }
    if (NWSuse && NWSinvokeSensor && NWSMemoryDir == null)
	throw new ConfigureException("have to specify NWSMemoryDir");

    NWSMemoryLog        = getOneArg("NWSMemoryLog");
    NWSMemoryErr        = getOneArg("NWSMemoryErr");
    NWSSensorLog        = getOneArg("NWSSensorLog");
    NWSSensorErr        = getOneArg("NWSSensorErr");
    NWSForecasterLog    = getOneArg("NWSForecasterLog");
    NWSForecasterErr    = getOneArg("NWSForecasterErr");
  }

  private void configureAggregateSchedule(){
    String tmp = getOneArg("aggregateSchedule");
    if ((tmp != null) && 
	(tmp.equalsIgnoreCase("yes") || tmp.equalsIgnoreCase("on")))
      aggregateSchedule = true;
  }

  private void configureLatchUp(){
    String tmp = getOneArg("latchUp");
    if ((tmp != null) && 
	(tmp.equalsIgnoreCase("yes") || tmp.equalsIgnoreCase("on")))
      latchUp = true;
  }

  private void configureMetaInterval(){
    int tmp;
    if ((tmp = getPositiveNumber("metaInterval"))>= 0)
      metaInterval = tmp;
  }

  private void configureThroughputLog() throws NinfException{
    PrintStream tmp = openLogStream("throughputlog");
    if (tmp != null)
      throughputLogStream = tmp;
  }

  private void configureThroughputMeasurements(){
    int tmp;
    if ((tmp = getPositiveNumber("throughputSize"))>= 0)
      throughputSize = tmp;
    if ((tmp = getPositiveNumber("MinimumSize"))>= 0)
      minimumSize = tmp;
    if ((tmp = getPositiveNumber("MaximumSize"))>= 0)
      maximumSize = tmp;
    if ((tmp = getPositiveNumber("interval"))>= 0)
      interval = tmp;
    double tmpDouble;
    if ((tmpDouble = getPositiveDouble("measureTime"))>= 0)
      measureTime = tmpDouble;
  }

  private void configureMetaServer(){
    String strs[] = getOneContent("metaserver");
    if (strs == null || strs.length == 0)
      return;
    metaServer = new MetaServerReference(strs[0], (new Integer(strs[1]).intValue()));
  }

  private void configureAllowHost() throws NinfException{
    allowedHosts.addHost("localhost", null);
    Vector v = getContent("allowHost");
    if (v == null)
	return;
    allowAll = false;
    for (int i = 0; i < v.size(); i++){
      String strs[] = (String [])v.elementAt(i);
      if (strs.length == 2)
	  allowedHosts.addHost(strs[0], strs[1]);
      else if (strs.length == 1)
	  allowedHosts.addHost(strs[0], null);      
    }
  }
}

