#define _WRAPPER_
/* $Id: pdlapiv_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define DOUBLE
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n
static	int ipivlen(char rowcol, int m, int n) {
	  int ret=1;
	  if (chrcmp(rowcol,'R')==0) 
		  ret = m;
	  else 
		  ret = n;
	  return ret;
}

static	int iworklen(char rowcol, char pivroc, int m, int n) {
    int ret=1;

    if ( (chrcmp(rowcol,'R')==0) && (chrcmp(pivroc,'R')==0) ) 
	ret = n + n;
    else if ( (chrcmp(rowcol,'C')==0) &&  (chrcmp(pivroc,'C')==0) ) 
	ret = m + m;

    if NEED_BUFF {
#define N_P n
#define NB_P cbloc
#define M_P m
#define MB_P rbloc
#define LCM LCM(nprow, npcol)
#define IP 1
#define JP 1
	if ( (chrcmp(rowcol,'R')==0) && (chrcmp(pivroc,'R')==0) ) {
	    if ( nprow==npcol ) 
		ret = LOCr( N_P + MOD(JP-1, NB_P) ) + NB_P;
	    else
		ret = LOCr( N_P + MOD(JP-1, NB_P) ) +
		    NB_P * CEIL( CEIL(LOCc(N_P),NB_P) , (LCM/NPCOL) );
	} else if ( (chrcmp(rowcol,'C')==0) &&  (chrcmp(pivroc,'C')==0) ) {
	    if ( nprow==npcol ) 
		ret = LOCc( M_P + MOD(IP-1, MB_P) ) + MB_P;
	    else
		ret = LOCc( M_P + MOD(IP-1, MB_P) ) +
		    MB_P * CEIL( CEIL(LOCr(M_P),MB_P) , (LCM/NPROW) );
	}
    }
    return ret;
}


void  pdlapiv_ninf(	 char direc,
		 char rowcol,
		 char pivroc,
		 int m,
		 int n,
		 double global_a[],
		 int lda,
		 int global_ipiv[]
)
/* "pdlapiv applies either P (permutation matrix indicated by IPIV) or inv( P ) to a general M-by-N distributed matrix A, resulting in row or column pivoting." */
/* OPTIONS */
{
	int maxldd;

	int maxlda;
	double *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
	int row_loca, col_loca;

	int *locipiv=NULL;
	int descipiv[DESCLEN];

	int *lociwork=NULL;
	int llociwork;

	INITIALIZE();

	SCALAR( "char", direc);
	SCALAR( "char", rowcol);
	SCALAR( "char", pivroc);
	SCALAR( "int", m);
	SCALAR( "int", n);
	SCALAR( "int", lda);

	ROW( a);
	COL( a);
	MAXLDD( maxldd, a );
	maxlda = maxldd;

	MATRIX( "double", a, ROW_a, COL_a);
	DISTRIBUTE( "double", a, ROW_a, COL_a);

	if (chrcmp(pivroc,'r')==0) {
	  VECTOR( "c", "int", ipiv, ipivlen(rowcol, m, n));
	  Cdescinit( descipiv, ipivlen(rowcol, m, n), 1, rbloc, 1, 0, 0, PARA_CTXT, rbloc, &linfo);
	  vDISTRIBUTE( "c", "int", ipiv, ipivlen(rowcol, m, n));
	} else {
	  VECTOR( "r", "int", ipiv, ipivlen(rowcol, m, n));
	  Cdescinit( descipiv, 1, ipivlen(rowcol, m, n),  1, cbloc, 0, 0, PARA_CTXT, 1, &linfo);
	  vDISTRIBUTE( "r", "int", ipiv, ipivlen(rowcol, m, n));
	}

	llociwork = iworklen(rowcol, pivroc, m, n);
	IWORK(lociwork,llociwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pdlapiv)( &direc, &rowcol, &pivroc,
                               &m, &n,
                               loca, &one, &one, desca,
                               locipiv, &one, &one, descipiv,
                               lociwork);

	GATHER( "double", a, ROW_a  , COL_a);

	if( mypnum == 0 ){
	} else {
	}

	FREE_MATRIX(a);
	FREE_VECTOR(ipiv);
        FREE(lociwork);
}

