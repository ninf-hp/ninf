package ninf.client;
import ninf.netsolve.*;
import java.util.Vector;


public class StubConverter {
  NinfStub stub;

  public StubConverter(NinfStub stub){
    this.stub = stub;
  }

  public boolean isUsedAsSize(int index){
    for (int i = 0; i < stub.nparam; i++)
      if (isUsedAsSize(stub.params[i], index))
	return true;
    return false;
  }

  public boolean isUsedAsSize(NinfParamDesc desc, int index){
    for (int i = 0; i < Math.abs(desc.ndim); i++)
      if (isUsedAsSize(desc.dim[i], index))
	return true;
    return false;
  }

  public boolean isUsedAsSize(NinfDimParam dim, int index){
    if (dim.size.isUsedAsSize(index))
      return true;
    if (dim.start.isUsedAsSize(index))
      return true;
    if (dim.end.isUsedAsSize(index))
      return true;
    if (dim.step.isUsedAsSize(index))
      return true;
    return false;
  }


  void makeMnemonicsSubSub(String s, int in_num, int out_num, Vector m){
    if (in_num >= 0)
      m.addElement(s + "I" + in_num);
    if (out_num >= 0)
      m.addElement(s + "O" + out_num);
  }


  void addConsts(String s, int in_num, int out_num, int val, Vector con){
    if (in_num >= 0)
      con.addElement(new Constant(s + "I" + in_num, val));
    //    if (out_num >= 0)
    //      con.addElement(new Constant(s + "O" + out_num, val));
  }

							  
  public void makeMnemonics(int index, int in_num, int out_num, 
			    Vector mnemonics[], Vector constants) 
  throws CannotConvertException{
    NinfParamDesc cp = stub.params[index];

    if (Math.abs(cp.ndim) > 2){
      System.err.println("netsolve cannot manage more than 3 dimensional array");
      throw new CannotConvertException();
    }
    if (cp.ndim == 0)
      return;
    if (cp.ndim == 1){
      if (cp.dim[0].start.type != NinfVal.VALUE_NONE ||
	  cp.dim[0].step.type  != NinfVal.VALUE_NONE){
	System.err.println("netsolve cannot manage step and start ");
	throw new CannotConvertException();
      }      
      //    if (cp.dim[0].end.type != NinfVal.VALUE_NONE){
      makeMnemonicSub(cp.dim[0].size, "m", in_num, out_num, mnemonics,  constants);
    } else {
      if (cp.dim[0].start.type != NinfVal.VALUE_NONE ||
	  cp.dim[0].step.type  != NinfVal.VALUE_NONE ||
	  cp.dim[1].start.type != NinfVal.VALUE_NONE ||
	  cp.dim[1].step.type  != NinfVal.VALUE_NONE ||
	  cp.dim[1].end.type   != NinfVal.VALUE_NONE ){

	System.err.println("netsolve cannot manage step and start ");
	throw new CannotConvertException();
      }
      if (cp.dim[0].end.type != NinfVal.VALUE_NONE){
	makeMnemonicSub(cp.dim[0].end,  "m", in_num, out_num, mnemonics,  constants);
	makeMnemonicSub(cp.dim[0].size, "l", in_num, out_num, mnemonics,  constants);
      } else {
	makeMnemonicSub(cp.dim[0].size, "m", in_num, out_num, mnemonics,  constants);
	makeMnemonicSub(cp.dim[0].size, "l", in_num, out_num, mnemonics,  constants);
      }
      makeMnemonicSub(cp.dim[1].size, "n", in_num, out_num, mnemonics,  constants);
    }
  }

  void makeMnemonicSub(NinfDimParamElem elem, String s, int in_num, int out_num,
		       Vector mnemonics[], Vector constants){
    switch (elem.type){
    case NinfVal.VALUE_NONE:
      addConsts(s, in_num, out_num, 1, constants);
      break;
    case NinfVal.VALUE_CONST:
      addConsts(s, in_num, out_num, elem.val, constants);
      break;
    case NinfVal.VALUE_IN_ARG:
      makeMnemonicsSubSub(s, in_num, out_num, mnemonics[elem.val]);
      break;
    }
  }
  

}
