#define _WRAPPER_
/* $Id: pdlascl_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define DOUBLE
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n
void  pdlascl_ninf(	 char type,
		 int dummy_kl,
		 int dummy_ku,
		 double cfrom,
		 double cto,
		 int m,
		 int n,
		 double global_a[],
		 int lda,
		 int *info
)
/* "pdlascl multiplies the M-by-N real distributed matrix A by the real scalar CTO/CFROM." */
/* OPTIONS */
{
	int maxldd;

	int maxlda;
	double *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
	int row_loca, col_loca;

	INITIALIZE();

	SCALAR( "char", type);
	SCALAR( "double", cfrom);
	SCALAR( "double", cto);
	SCALAR( "int", m);
	SCALAR( "int", n);
	SCALAR("int",lda);

	ROW( a);
	COL( a);
	MAXLDD( maxldd, a );
	maxlda = maxldd;

	MATRIX( "double", a, ROW_a, COL_a);
	DISTRIBUTE( "double", a, ROW_a  , COL_a);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pdlascl)( &type,
                               &cfrom, &cto,
                               &m, &n,
                               loca, &one, &one, desca,
                               &linfo);

	GATHER( "double", a, ROW_a, COL_a);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
		*info = linfo;
	} else {
	}

	FREE_MATRIX(a);
}

