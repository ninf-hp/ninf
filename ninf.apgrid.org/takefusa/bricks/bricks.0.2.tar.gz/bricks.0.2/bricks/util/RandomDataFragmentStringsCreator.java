package bricks.util;
import java.util.*;

public class RandomDataFragmentStringsCreator extends SubComponentCreator {

    public String usage() {
	return "RandomDataFragmentStrings(<long seed>, <String keyOfResourceDB>)";
    }

    public SubComponent create(StringTokenizer st) throws BricksParseException{
	try {
	    long seed = Long.valueOf(st.nextToken(" \t,()")).longValue();
	    String keyOfResourceDB = st.nextToken(" \t,()");
	    return new RandomDataFragmentStrings(seed, keyOfResourceDB);

	} catch (NumberFormatException e) {
	    e.printStackTrace();
	    throw new BricksParseException(usage());

	} catch (NoSuchElementException e) {
	    e.printStackTrace();
	    throw new BricksParseException(usage());
	}
    }
}

