#include <stdio.h>
#include <stdlib.h>
#define N 10

void  mmul(int n, double * a, double * b, double * c){
  double t;
  int i, j, k;
  for (i = 0; i < N; i++) {
	for (j = 0; j < N; j++) {
	  t = 0;
	  for (k = 0; k < N; k++){
		t += a[i * n + k] * b[k * n + j];
	  }
	  c[i*N+j] = t;
	}
  }
}

