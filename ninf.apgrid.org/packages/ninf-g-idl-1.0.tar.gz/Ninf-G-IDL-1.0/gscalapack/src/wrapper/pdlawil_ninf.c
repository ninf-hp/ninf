#define _WRAPPER_
/* $Id: pdlawil_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define DOUBLE
#include <gscalapack.h>

#define ROW_a lda
#define COL_a m
void  pdlawil_ninf(	 int ii,
		 int jj,
		 int m,
		 double a[],
		 int lda,
		 double h44,
		 double h33,
		 double h43,
		 double global_v[]
)
/* "pdlawil gets the transform given by H44,H33, & H43H34 into V starting at row M." */
/* OPTIONS */
{
	int maxldd;

	int desca[DESCLEN];

	double locv[3];

	INITIALIZE();

	SCALAR( "int", ii);
	SCALAR( "int", jj);
	SCALAR( "int", m);
	SCALAR("int",lda);
	SCALAR( "double", h44);
	SCALAR( "double", h33);
	SCALAR( "double", h43);

	COMMON_MATRIX("double", a, ROW_a, COL_a);
	Cdescinit( desca, ROW_a, COL_a, ROW_a, COL_a, 0, 0, PARA_CTXT, ROW_a, &linfo);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pdlawil)( &ii, &jj, &m, a, desca, &h44, &h33, &h43, locv);

	RETRIEVE("double", locv, 3);

	if( mypnum == 0 ){
	  int i;
	  for(i=0;i<3;i++) global_v[i]=locv[i];
	} else {
	}
        FREE_COMMON(a);
}

