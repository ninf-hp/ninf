/* ----------------------------------------
         Header file defines Ninf API
   ---------------------------------------- */

#ifdef  __cplusplus
extern "C" {
#endif

/*****  define constants ****/
#ifndef NINF_ERROR
#define NINF_ERROR	(-1)
#endif

#ifndef NINF_OK
#define NINF_OK		0
#endif 

#ifndef TRUE
#define TRUE	1
#endif

#ifndef FALSE
#define FALSE	0
#endif
/**********   define structures ***********/
struct ninf_stub_information;
struct _id_set_struct;
struct _exec_info_struct;
struct _any_t_struct;

/********** CALLING APIS **********/

int Ninf_call        (char * ninf_stub_entry, ...);
int Ninf_call_async  (char * ninf_stub_entry, ...);

int Ninf_call_v      (char * ninf_stub_entry, struct _any_t_struct a[]);
int Ninf_call_v_async(char * ninf_stub_entry, struct _any_t_struct a[]);

int Ninf_get_stub    (char * ninf_stub_entry, int types[],  
		      struct ninf_stub_information ** buffer_p);

int Ninf_call_body        (struct ninf_stub_information * stub_info, ...);
int Ninf_call_body_async  (struct ninf_stub_information * stub_info, ...);
int Ninf_call_body_v      (struct ninf_stub_information * stub_info, 
			   struct _any_t_struct a[]);
int Ninf_call_body_v_async(struct ninf_stub_information * stub_info, 
			   struct _any_t_struct a[]);

int Ninf_cim_main(char * entry, void ** args);

int Ninf_wait(int session_id);
int Ninf_wait_all();
int Ninf_wait_any(int * session_id);
int Ninf_wait_and(int * id_list, int count);
int Ninf_wait_or(int * id_list, int count);

typedef struct {
  void * entry;
  void * server;
  void * stub_info;
} Ninf_executable_t;

Ninf_executable_t * 
    Ninf_get_executable(char * ninf_stub_entry);
int Ninf_call_executable(Ninf_executable_t * exe, ...);
int Ninf_call_executable_async(Ninf_executable_t * exe, ...);
int Ninf_executable_finalize(Ninf_executable_t * exe);
Ninf_executable_t * 
    Ninf_get_executable_from_session(int session_id);

typedef struct {
  void * entry;
  void * managers;
  void * session_manager_map;
} Ninf_group_t;

Ninf_group_t *
    Ninf_group_init(char * entry);
int Ninf_group_call_async(Ninf_group_t * gr, ...);
int Ninf_group_wait_all(Ninf_group_t * gr);


struct _id_set_struct * new_id_set();                 /* creation */
struct _id_set_struct * Ninf_wait_and_set(struct _id_set_struct *);
struct _id_set_struct * Ninf_wait_or_set (struct _id_set_struct *);

/********** OTHER APIs  **********/
void Ninf_set_server(char *server, char * port);
int Ninf_parse_arg(int argc, char ** argv);
void Ninf_perror(char * string);
int Ninf_session_probe(int id);
int Ninf_session_cancel(int id);
int Ninf_session_remove(int id);

/********** Information APIs  **********/
struct _exec_info_struct * Ninf_get_info(int session_num);
struct _exec_info_struct * Ninf_get_last_info();

/********** Type handling APIs  **********/
void any_set_char          (struct _any_t_struct * a, char val);
void any_set_unsigned_char (struct _any_t_struct * a, unsigned char val);
void any_set_short         (struct _any_t_struct * a, short val);
void any_set_unsigned_short(struct _any_t_struct * a, unsigned short val);
void any_set_int           (struct _any_t_struct * a, int val);
void any_set_unsigned      (struct _any_t_struct * a, unsigned val);
void any_set_long          (struct _any_t_struct * a, long val);
void any_set_unsigned_long (struct _any_t_struct * a, unsigned long val);
void any_set_float         (struct _any_t_struct * a, float val);
void any_set_double        (struct _any_t_struct * a, double val);
void any_set_pointer       (struct _any_t_struct * a, void * val);
void any_set_function      (struct _any_t_struct * a, void *(*val)());
void any_set_handler       (struct _any_t_struct * a, void * val);


#ifdef  __cplusplus
};
#endif
