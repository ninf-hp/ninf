package ninf.nws;
import ninf.basic.FormatString;
import ninf.basic.*;
import ninf.client.*;
import ninf.common.*;
import ninf.metaserver.*;
import nws.support.*;
import nws.api.*;
import java.io.*;

public class LPingerNWS implements LPinger{
  int interval;               /* interval in second */
  NinfServerHolder target;
  LoadInformation load;
  static NinfLog dbg = new NinfLog("LPingerNWS");
  PrintStream loadLog;

  NWSClient forecaster;
  ExperimentSpec experiment = new ExperimentSpec();


  public LPinger setup(NinfServerHolder target, int interval){
    dbg.println("seting up LPingerNWS");
    this.target = target;
    this.interval = interval;
    HostSpec forecasterSpec  = new HostSpec(target.struct.host,
					   ConfigSite.DEFAULTFOREPORT);
    HostSpec nsSpec = null;
    try {
	forecaster = new NWSClient();
	forecaster.setForecaster(forecasterSpec);
	nsSpec = forecaster.getNameServer(new HostCookie(forecasterSpec));
	forecaster.setNameServer(nsSpec);
    } catch (NWSException e){
	dbg.println("Unable to determine NWS name server, using default\n");
	try {
	    forecaster.useDefaultNameServer();
	} catch (NWSException e2){
	    dbg.log("couldn't set NWSname server");
	}
    }
    dbg.println("seting up LPingerNWS: got nameServer " + nsSpec);
    experiment.experimentName = ExperimentSpec.DEFAULT_AVAILABLE_CPU_EXPERIMENT;
    experiment.sourceMachine = target.struct.host;
    loadLog = MetaServer.conf.loadLogStream;

    return this;
  }

  private LoadInformation makeLoad(ForecastCollection fore){
    double val = fore.forecasts[0].forecast;
    return new LoadInformation(1.0 - val, 0.0, 0.0, 0.0);
  }

  private boolean ping(){
    try {
      ForecastCollection[] forecasts = 
	  forecaster.getForecasts(experiment, 1);
      if (forecasts == null)
	  throw new NWSException("failed to get forecast.");
      load = makeLoad(forecasts[0]);
      dbg.println("        got: " + load);
      target.setLoad(load);
      return true;;
    } catch (NWSException e) {
      e.printStackTrace();	
      dbg.log("nws exception caught");
      startNative();
      return false;
    }
  }

  private void startNative(){
    (new Thread
     ((new LPingerNative()).
      setup(target, interval))).start();

  }

  public void run(){
    while (ping()){
      if (loadLog != null)
	  loadLog.println(FormatString.format(
              "%.2lf %s %s", 
	      new Double(System.currentTimeMillis() / 1000.0),
		target,
		load.logString()));
      try {
	Thread.sleep(interval * 1000);
      } catch (InterruptedException e){
      }
    }
  }

  public static void main(String args[]){
    NinfLog.verbose();
    //    NinfLog.log();
    NinfServerHolder tmp = 
      new NinfServerHolder(args[0], new Integer(args[1]).intValue());
    new Thread((new LPingerNWS()).setup(tmp, 1)).start();
  }
}

