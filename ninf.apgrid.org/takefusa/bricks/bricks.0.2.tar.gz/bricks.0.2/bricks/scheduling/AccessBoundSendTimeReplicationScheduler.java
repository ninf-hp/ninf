package bricks.scheduling;
import bricks.util.*;
import bricks.environment.*;
import java.util.*;

public class AccessBoundSendTimeReplicationScheduler extends DataGridScheduler implements SchedulingUnit {

    double minAccessScore;

    public AccessBoundSendTimeReplicationScheduler(
	String keyOfMetaPredictor, String keyOfReplicaManager, 
	String keyOfServerMonitor, double minAccessScore
    ) {
	this.keyOfMetaPredictor = keyOfMetaPredictor;
	this.keyOfReplicaManager = keyOfReplicaManager;
	this.keyOfServerMonitor = keyOfServerMonitor;
	this.minAccessScore = minAccessScore;
	schedulingOverhead = 0.0;
    }

/************************* needed method *************************/
    public String getName() {
	return "AccessBoundSendTimeReplicationScheduler";
    }

    protected boolean dispatchOK(
	double currentTime, RequestedData data, Host host
    ) {
	StaticHostInfo staticInfo = resourceDB.getStaticHostInfo(host);
	HostInfo info = getHostInfo(currentTime, host);

	SimulationDebug.println(
	    "host = " + host + ", perf = " + staticInfo.performance + 
	    ", numAccesses = " + info.numAccesses + 
	    ", score = " + staticInfo.performance / (info.numAccesses + 1.0));
	if (staticInfo.performance <= minAccessScore && info.numAccesses < 1.0)
	    return true;

	if (staticInfo.performance / (info.numAccesses + 1.0) > minAccessScore)
	    return true;
	else
	    return false;
    }
}

