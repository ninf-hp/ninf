package ninf.monitor;
import java.awt.*;
import ninf.basic.*;
import ninf.common.*;
import ninf.client.*;
import ninf.metaserver.*;
import java.util.Hashtable;
import java.util.Vector;
import java.util.Enumeration;



public class StubPanel extends Panel {
  Monitor monitor;

  Font font = new Font("Helvetica", Font.BOLD, 10);
  
  List stubList;
  TextArea description;
  NinfStub stubs[];
  FunctionName names[];

  StubPanel(Monitor monitor){
    this.monitor = monitor;
    this.setFont(font);

    double ratio[] = {0.35, 0.65};
    this.setLayout(new RatioLayout(RatioLayout.HORIZONTAL, ratio));

    stubList = new List();
    stubList.setBackground(Color.white);

    description = new TextArea(60, 25);
    description.setBackground(Color.white);
    description.setEditable(false);
    this.add(addLabel("FUNCTIONS", stubList));
    this.add(addLabel("INTERFACE", description));
  }

  Panel addLabel(String str, Component comp){
    Panel tmp = new Panel();
    tmp.setLayout(new BorderLayout());
    Label label = new Label(str, Label.CENTER);
    label.setBackground(Color.darkGray);
    label.setForeground(Color.white);
    tmp.add("Center", comp);
    tmp.add("North", label);
    return tmp;
  }

  void selectFuncs(FunctionName[] selectNames){
    for (int i = 0; i < names.length; i++)
      stubList.deselect(i);
    stubList.setMultipleSelections(true);
    
    for (int i = 0; i < names.length; i++)
      for (int j = 0; j < selectNames.length; j++)
	if (names[i].equals( selectNames[j])){
	  stubList.select(i);
	  break;
	}
  }

  public void makeList(){
    Hashtable table = monitor.functionTable;
    int num = table.size();   
    if (num < 0) return;
    stubs = new NinfStub[num];
    names = new FunctionName[num];
    stubList.clear();
    Enumeration enum = table.keys();
    SortedVector sort = new SortedVector();
    for (int i = 0; i < num; i++)
      sort.addElement((FunctionName)enum.nextElement());
    Vector vec = sort.contents();
    
    for (int i = 0; i < vec.size(); i++){
      FunctionName name = (FunctionName)vec.elementAt(i);
      stubs[i] = ((FunctionStruct)(table.get(name))).stub;
      names[i] = name;
      stubList.addItem(name.toString());
    }    
  }

  void clearDescription(){
    description.setText("");
  }

  public boolean action(Event evt, Object arg){
    if (evt.target == stubList){         /* List Item clicked */
      int selected = stubList.getSelectedIndex();
      for (int i = 0; i < names.length; i++)
	stubList.deselect(i);
      stubList.setMultipleSelections(false);
      if (selected < 0 || selected >= stubs.length)
	return true;
      stubList.select(selected);
      description.setText(stubs[selected].toText());
      monitor.selectServers(stubs[selected].getName());
      return true;
    }
    return false;  
  }


  


}
