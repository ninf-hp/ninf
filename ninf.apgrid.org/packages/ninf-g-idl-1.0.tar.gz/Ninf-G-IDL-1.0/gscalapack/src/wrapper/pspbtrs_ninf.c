#define _WRAPPER_
/* $Id: pspbtrs_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define _DISTRIBUTE_1D_
#define FLOAT
#define NO_PIVOT
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n
#define ROW_b ldb
#define COL_b nrhs
static	int worklen(int nrhs, int bw) {
            int ret;
	    ret = bw*nrhs;
	    return ret;
}

void  pspbtrs_ninf(	 char uplo,
		 int n,
		 int bw,
		 int nrhs,
		 float global_a[],
		 int lda,
		 float global_b[],
		 int ldb,
		 int *info
)
/* "pspbtrs solves a system of linear equations A * X = B where A is the matrix used to produce the factors stored in A and AF by PSPBTRF." */
/* OPTIONS */
{
extern void FortranCall(pspbtrs)( char*, int*, int*, int*,
                               float*, int*, int*,
                               float*, int*, int*,
                               float*, int*,
                               float*, int*, int*);

	int maxldd;

	int maxlda;
	float *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
	int row_loca, col_loca;

	float *locb=NULL;
	int maxldb;
	int descb[DESCLEN];
	int desc_gb[DESCLEN];
	int row_locb,col_locb;

	float *locaf=NULL;
	int laf;

	float *locwork=NULL;
	int llocwork;


	INITIALIZE();

	SCALAR( "char", uplo);
	SCALAR( "int", n);
	SCALAR( "int", bw);
	SCALAR( "int", nrhs);
	SCALAR("int", lda);
	SCALAR("int", ldb);
	SIZE(n);

	ROW(a);
	COL(a);
	ROW(b);
	COL(b);
	MAXLDD(maxldd, a);
	maxlda = maxldd;
	MAXLDD( maxldd, b );
	maxldb=maxldd;

	if (chrcmp(uplo,'u')==0) {
	  bandMATRIX("float", a, 0, bw, n);
	  bandDISTRIBUTE("float", a, 0, bw, n);
        } else {
	  bandMATRIX("float", a, bw, 0, n);
	  bandDISTRIBUTE("float", a, bw, 0, n);
        }
        
	MATRIX("float", b, ROW_b, COL_b);
	DISTRIBUTE("float", b, ROW_b, COL_b);

	laf =   (blocsize+2*bw)*bw;
	locaf = MALLOC(sizeof(float)*laf);
        assert(locaf);

	llocwork = worklen(nrhs, bw);
	WORK(locwork,llocwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	  FortranCall(pspbtrs)( &uplo, &n, &bw, &nrhs,
                                loca, &one, desca,
                                locb, &one, descb,
                                locaf, &laf,
                                locwork, &llocwork,
                                &linfo);

        if (chrcmp(uplo,'u')==0) {
            bandGATHER( "float", a, 0, bw, n);
	}else {
            bandGATHER( "float", a, bw, 0, n);
	}	

	GATHER("float", b, ROW_b, COL_b);

	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
		*info = linfo;
	} else {
	}
	FREE_MATRIX(a);
	FREE_MATRIX(b);
        FREE(locaf);
        FREE(locwork);
	
}

