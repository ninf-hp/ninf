#! /bin/sh
# $Id: ninf_gen.sh,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $

# Use this script when you can't get a gcc-like preprocessor.

NINF_GEN_ARGS=
NINF_IDL_FILES=
for arg in "$@" ; do
    case "$arg" in
	NINF_TOPDIR=*) 
	    TARGETENV=`expr "${arg}" : '\([^=]*\)='`
	    VAL="`expr "${arg}" : '[^=]*=\(.*\)'`"
	    eval ${TARGETENV}=\"${VAL}\"
        ;;
	NINF_GEN_CPP=*) 
	    TARGETENV=`expr "${arg}" : '\([^=]*\)='`
	    VAL="`expr "${arg}" : '[^=]*=\(.*\)'`"
	    eval ${TARGETENV}=\"${VAL}\"
        ;;
        *)
	    if [ -f "${arg}" ] ; then
		NINF_IDL_FILES="${NINF_IDL_FILES} ${arg}"
            else
		NINF_GEN_ARGS="${NINF_GEN_ARGS} ${arg}"
            fi
        ;;
    esac
done

check_ninf_ver() {
    if [ x"${NINF_TOPDIR}" = x"" ] ; then
	echo -n NONINF
	exit 1
    fi
    if [ x"$NG_DIR" = x"${NINF_TOPDIR}" -a x"${NINF_TOPDIR}" != x"" ] ; then
	echo -n NINFG2
	return 0
    fi
    if [ x"$NS_DIR" = x"${NINF_TOPDIR}" -a x"${NINF_TOPDIR}" != x"" ] ; then
	echo -n NINFG1
	return 0
    fi
    if [ x"$NINF_DIR" = x"${NINF_TOPDIR}" -a x"${NINF_TOPDIR}" != x"" ] ; then
	echo -n NINF1
	exit 0
    fi
    echo -n NONINF
    return 1
}

TMPFILE=.tmp.idl

cat > ${TMPFILE} <<EOF
#define NINFGENSH_ST_INCLUDE #include
#define NINFGENSH_ST_DEFINE  #define
EOF

NINF_VER=`check_ninf_ver`
NINFG2_GEN_OPT="--maxStubs=60 --maxExp=30"

[ x"${NINF_GEN_CPP}" = x"" ] && exit 3

case "$NINF_VER" in
    "NINFG2")
	    ${NINF_GEN_CPP} -E -xc  -DNINFG2 ${NINF_GEN_ARGS} ${NINF_IDL_FILES} |sed -e 's!#include!NINFGENSH_ST_INCLUDE!g;s!#define!NINFGENSH_ST_DEFINE!g' >> $TMPFILE
	    ng_gen ${NINFG2_GEN_OPT} -DNINFG2 ${NINF_GEN_ARGS} $TMPFILE
	    ;;
    "NINFG1")
	    ${NINF_GEN_CPP} -E -xc -DNINFG1 ${NINF_GEN_ARGS} ${NINF_IDL_FILES} |sed -e 's!#include!NINFGENSH_ST_INCLUDE!g;s!#define!NINFGENSH_ST_DEFINE!g' >> $TMPFILE
	    ns_gen -DNINFG1 ${NINF_GEN_ARGS} $TMPFILE
	    ;;
    "NINF1")
	    ${NINF_GEN_CPP} -E -xc -DNINF1 ${NINF_GEN_ARGS} ${NINF_IDL_FILES} |sed -e 's!#include!NINFGENSH_ST_INCLUDE!g;s!#define!NINFGENSH_ST_DEFINE!g' >> $TMPFILE
	    ninf_gen -DNINF1 ${NINF_GEN_ARGS} $TMPFILE
	    ;;
    *)
	echo NONINF
	rm $TMPFILE
	exit 1
		;;
esac	   

rm $TMPFILE
