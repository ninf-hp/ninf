package bricks.plugin.nws;
import bricks.environment.*;
import bricks.scheduling.*;
import bricks.util.*;
import nws.api.*;
import java.util.*;

public class NWSResourceDB extends ResourceDB implements SchedulingUnit {

    public boolean forecastLog = false;
    protected NWSAdapter adapter = new NWSAdapter();
    private int displaySize = 100;
    private Hashtable networkForecastCounter;
    private Hashtable serverForecastCounter;

    public NWSResourceDB(
	String nwsMemoryServer, String nwsForecaster, boolean forecastLog
    ) {
	adapter.setNwsMemoryServer(nwsMemoryServer);
	adapter.setNwsForecaster(nwsForecaster);
	this.forecastLog = forecastLog;
    }

    public NWSResourceDB(
	String nwsMemoryServer, String nwsForecaster, boolean forecastLog,
	int numNetworkHistory, int numServerHistory
    ) {
	adapter.setNwsMemoryServer(nwsMemoryServer);
	adapter.setNwsForecaster(nwsForecaster);
	this.forecastLog = forecastLog;
	this.numNetworkHistory = numNetworkHistory;
	this.numServerHistory = numServerHistory;
    }

    /************************* needed method *************************/
    public String getName() {
	return "NWSResourceDB";
    }

    /************************* override *************************/
    public void init(SimulationSet owner) {
	super.init(owner);

	if (forecastLog) {
	    // init network
	    networkForecastCounter = new Hashtable(networkState.size());
	    initCounter(networkForecastCounter, networkState);
	    
	    // init server
	    serverForecastCounter = new Hashtable(serverState.size());
	    initCounter(serverForecastCounter, serverState);
	}
    }

    public void finish() {
	if (forecastLog) {
	    printForecastLog(networkForecastCounter);
	    printForecastLog(serverForecastCounter);
	}
    }

    public void putHostInfo(HostInfo hostInfo) {

	SimulationDebug.println("NWSResourceDB: insert()");
	super.putHostInfo(hostInfo);

	// insert current_cpu
	double currentCpu = 1.0 / hostInfo.loadAverage;
	if (currentCpu > 1.0) {
	    currentCpu = 1.0;
	}
	adapter.insert(
	    adapter.currentCpuExperiment, (hostInfo.owner).toString(),
	    hostInfo.probeTime, currentCpu
	);
	// insert available_cpu
	double availableCpu = 1.0 / (hostInfo.loadAverage + 1.0);
	hostInfo.availableCpu = availableCpu;
	adapter.insert(
	    adapter.availableCpuExperiment, (hostInfo.owner).toString(),
	    hostInfo.probeTime, availableCpu
	);

	SimulationDebug.println(
	    "NWSResourceDB: " + adapter.currentCpuExperiment + ": " + 
	    hostInfo.probeTime + "  " + currentCpu
	);
	SimulationDebug.println(
	    "NWSResourcDB: " + adapter.availableCpuExperiment + ": " + 
	    hostInfo.probeTime + "  " + availableCpu
	);

	if (forecastLog) {
	    int count = ((Integer)serverForecastCounter.get(hostInfo.owner)).intValue();
	    count++;
	    if (count == displaySize) {
		count = 0;
		printForecastLog(adapter.currentCpuExperiment, hostInfo.owner);
		printForecastLog(
		    adapter.availableCpuExperiment, hostInfo.owner
		);
	    }
	    serverForecastCounter.put(hostInfo.owner, new Integer(count));
	}
    }

    public void putNetworkInfo(NetworkInfo networkInfo) {

	super.putNetworkInfo(networkInfo);

	NodePair pair = networkInfo.owner;
	// put bandwidth_tcp
	adapter.insert(
	    adapter.bandwidthTcpExperiment, 
	    (pair.source).toString(), (pair.destination).toString(),
	    networkInfo.probeTime, networkInfo.throughput
	);
	// put latency_tcp
	adapter.insert(
	    adapter.latencyTcpExperiment, 
	    (pair.source).toString(), (pair.destination).toString(),
	    networkInfo.probeTime, networkInfo.latency
	);

	SimulationDebug.println(
	    "NWSResourcDB: " + adapter.bandwidthTcpExperiment + ": " + 
	    networkInfo.probeTime + " " + networkInfo.throughput
	);
	SimulationDebug.println(
	    "NWSResourcDB: " + adapter.latencyTcpExperiment + ": " + 
	    networkInfo.probeTime + " " + networkInfo.latency
	);

	if (forecastLog) {
	    int count = ((Integer)networkForecastCounter.get(pair)).intValue();
	    count++;
	    if (count == displaySize) {
		count = 0;
		printForecastLog(adapter.bandwidthTcpExperiment, pair);
		printForecastLog(adapter.latencyTcpExperiment, pair);
	    }
	    networkForecastCounter.put(pair, new Integer(count));
	}
    }

    /*************** private / protected method ***************/
    private void initCounter(Hashtable table, Hashtable state) {
	Enumeration e = state.keys();
	while (e.hasMoreElements()) {
	    table.put(e.nextElement(), new Integer(0));
	}
    }

    private void printForecastLog(Hashtable counter) {
	Enumeration e = counter.keys();
	while (e.hasMoreElements()) {
	    Object o = e.nextElement();
	    if (o instanceof NodePair) { // network
		printForecastLog(
		    adapter.bandwidthTcpExperiment, (NodePair)o
		);
		printForecastLog(
		    adapter.latencyTcpExperiment, (NodePair)o
		);
	    } else { // server
		printForecastLog(adapter.availableCpuExperiment, (Host)o);
		printForecastLog(adapter.currentCpuExperiment, (Host)o);
	    }
	}
    }

    private void printForecastLog(String experiment, NodePair nodePair) {

	ForecastCollection[] forecast = adapter.extract(
	    experiment,
	    (nodePair.source).toString(),
	    (nodePair.destination).toString(),
	    displaySize
	);
	    
	for (int i = 0 ; i < forecast.length ; i++) {
	    System.out.println(
		experiment + " " + nodePair + " (" + i + ") " +
		adapter.toString(forecast[i])
	    );
	}
	System.out.println("");
    }

    private void printForecastLog(String experiment, Host host) {
	// debug
	//adapter.printNwsServers();

	ForecastCollection[] forecast = adapter.extract(
	    experiment, host.toString(), displaySize
	);

	for (int i = 0 ; i < forecast.length ; i++) {
	    System.out.println(
		experiment + " " + host + " (" + i + ") " +
		adapter.toString(forecast[i])
	    );
	}
	System.out.println("");
    }
}

