#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ninf.h"
#define MAX_LEN 1000

char ** hosts;
int  * ports;
int read_map_file(char * filename, char *** hosts, int ** ports, char * entry);

int main(int argc, char ** argv){
  double pi;
  long times, *count, sum;
  int i, NUM_HOSTS;

  if (argc < 3){
	fprintf(stderr, "USAGE: %s MAPFILE TIMES \n", argv[0]);
	exit(2);
  }

  NUM_HOSTS = read_map_file(argv[1], & hosts, & ports, "pi/pi_trial");
  if (NUM_HOSTS  == 0){
    fprintf(stderr, "No server available in the mapfile=\"%s\"\n", argv[1]);
    exit(3);
  }
  printf("Using %d server(s).\n", NUM_HOSTS);

  count = (long *)malloc(sizeof(long) * NUM_HOSTS);
  times = atol(argv[2]) / NUM_HOSTS;

  for (i = 0; i < NUM_HOSTS; i++){
	char entry[100];
	sprintf(entry, "ninf://%s:%d/pi/pi_trial", hosts[i], ports[i]);
	if (Ninf_call_async(entry, i, times, &count[i]) == NINF_ERROR){
	  Ninf_perror("pi_trial");
	  exit(2);
	}
  }
  Ninf_wait_all();
  for (i = 0, sum = 0; i < NUM_HOSTS; i++)  
	sum += count[i];
  pi = 4.0 * ( sum / ((double) times * NUM_HOSTS));
  printf("PI = %f\n", pi);
  exit(0);
}
