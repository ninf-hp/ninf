package bricks.environment;
import bricks.util.*;
import java.util.*;

public class ClientCreator extends ComponentCreator {

    // for bricks.tools.ShowUsage
    public ClientCreator() {}

    public ClientCreator(
	SimulationSet owner, SubComponentFactory subComponentFactory
    ) {
	this.owner = owner;
	this.subComponentFactory = subComponentFactory;
    }

    public String usage() {
	return "Client (<String key> <String keyOfScheduler> " +
	    "Requests(<Sequence dataSizeForSend>, <Sequence dataSizeForRecv>" +
	    ", <Sequence numInstructions>, <Sqeuence interarrivalTime>" +
	    "(, <Strings dataIDs>, " +
	    "<Strings dataDestinations>, <Sequence deadlineFactors>)))";
    }

    public Node createNode(String str) throws BricksParseException {
	try {
	    StringTokenizer st = new StringTokenizer(str);
	    String tmp = st.nextToken(" \t(),"); // client
	    if (!st.hasMoreElements()) {
		return new NullClient();
	    }
	    String key = st.nextToken(" \t(),");
	    String keyOfScheduler = st.nextToken(" \t(),");
	    tmp = st.nextToken(" \t(),"); // Requests
	    
	    Sequence dataSizeForSend = 
		(Sequence)subComponentFactory.create(st);
	    Sequence dataSizeForReceive = 
		(Sequence)subComponentFactory.create(st);
	    Sequence numInstructions =
		(Sequence)subComponentFactory.create(st);
	    Sequence throwingInterval = 
		(Sequence)subComponentFactory.create(st);

	    Client client = new Client(
		owner, key, keyOfScheduler, dataSizeForSend, 
		dataSizeForReceive, numInstructions, throwingInterval
	    );

	    if (st.hasMoreElements()) {
		SimulationDebug.println("ClientCreator: num = " + st.countTokens());
		Strings dataIDs = (Strings)subComponentFactory.create(st);
		if (dataIDs != null) {
		    // for RandomDataFragmentStrings
		    dataIDs.init(owner); 
		    client.setDataIDs(dataIDs);
		}
		Strings dataDestinations =
		    (Strings)subComponentFactory.create(st);
		if (dataDestinations != null) {
		    client.setDataDestinations(dataDestinations);
		}
		Sequence deadlineFactors = 
		    (Sequence)subComponentFactory.create(st);
		if (deadlineFactors != null) {
		    client.setDeadlineFactors(deadlineFactors);
		}
	    }

	    SimulationDebug.println("creates Client");
	    return client;

	} catch (NoSuchElementException e) {
	    e.printStackTrace();
	    throw new BricksParseException(usage());

	} catch (ClassCastException e) {
	    e.printStackTrace();
	    throw new BricksParseException(usage());

	} catch (BricksParseException e) {
	    e.addMessage(usage());
	    throw e;
	}
    }
}
