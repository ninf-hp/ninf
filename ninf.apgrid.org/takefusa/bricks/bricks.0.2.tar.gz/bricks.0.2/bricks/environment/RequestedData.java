package bricks.environment;
import bricks.util.*;
import java.util.*;

public class RequestedData extends TrafficData {

    public static int numRequestedData = 0;

    public Host source;
    public Host destination;
    protected String log;
    protected int indexOfDestination;

    public double dataSizeForSend;
    public double dataSizeForReceive;
    public double numInstructions;
    protected double[] listOfDataSize;

    public double startTime = Double.NEGATIVE_INFINITY;
    public int priority;

    // for Disk functions in simulation
    public Host dataSource = null;
    public Host dataDestination = null;
    public String requiredDataID = null;
    public boolean moveAtSend = false;
    public boolean moveAtRecv = false;
    public static long resultSerialNumber = 0;
    protected boolean sendReplication = false;
    protected boolean recvReplication = false;

    // for fallback
    public double elapsedTime = Double.NEGATIVE_INFINITY;

    public double estimatedSendDuration;
    public double estimatedExecDuration;
    public double estimatedRecvDuration;
    //public double estimatedDuration;

    public double sendDuration;
    public double execDuration;
    public double recvDuration;
    //public double duration;

    /**
     * for deadline scheduling
     **/
    public Vector scheduledHosts = null;
    public double deadlineFactor = Double.NEGATIVE_INFINITY;
    public double deadline = Double.NEGATIVE_INFINITY;
    public double expectedFinishTime;
    public int reschedule = 0;

    /*
      [ dataSizeForSend dataSizeForReceive numInstructions ]
      cn (schedule) (first out cn & in nq1) (nd in nq1) nq1 (nq1 top)
      (out nq1 & in sq) sq (sq top) (first out sq & in nq2) (nd in nq2) 
      nq2 (nq2 top) (out nq2 & in cn) cn
    */

    public RequestedData(
	Host source, double timeEventComes, 
	double dataSizeForSend,	double dataSizeForReceive, 
	double numInstructions
    ) {
	id = generateId();
	processingDuration = 0.0;
	this.source = source;
	this.timeEventComes = timeEventComes;
	this.dataSizeForSend = dataSizeForSend;
	this.dataSizeForReceive = dataSizeForReceive;
	this.numInstructions = numInstructions;
	this.dataSize = dataSizeForSend;
    }

    // for EPRequestedData
    public RequestedData(
	Host source, double timeEventComes, int numTask, 
	Sequence dataSizeForSendSq, Sequence dataSizeForReceiveSq,
	Sequence numInstructionsSq
    ) {;}

    /**
     * Functions which initialize RequestedData instances.
     */
    public void setDeadlineFactor(double deadlineFactor) {
	this.deadlineFactor = deadlineFactor;
    }

    public void setDataSource(Host host) {
	this.dataSource = host;
    }
    
    public void setDataDestination(Host host) {
	if (host == null)
	    BricksUtil.abort(
		"Bad destination host ID for " + this + " from " + source
		);
	this.dataDestination = host;
    }
    
    public void setRequiredDataID(String id) {
	this.requiredDataID = id;
    }


/************************* needed method *************************/
    /** 
     * generates a clone of the TrafficData.
     */
    public synchronized Object clone() {
	RequestedData d = (RequestedData)super.clone();
	d.source = this.source;
	d.dataSizeForSend = this.dataSizeForSend;
	d.dataSizeForReceive = this.dataSizeForReceive;
	d.numInstructions = this.numInstructions;
	return d;
    }

    protected double start = Double.NEGATIVE_INFINITY;

    public void gotoNextNode(double currentTime) {

	if (indexOfCurrentNode >= listOfRoute.size() - 1) {
	    error(getName() + " - No more nextNode Element [" + 
		  listOfRoute + "]");
	}
	currentNode = (Node)listOfRoute.elementAt(++indexOfCurrentNode);

	// for DataGrid
	if (requiredDataID != null) {
	    boolean reservationFail = false;
	    boolean releaseFail = false;

	    //send data
	    if (indexOfCurrentNode == 1) { 
		dataSourceDisk = (Disk)currentNode;
		dataFragment = 
		    new DataFragment(requiredDataID, dataSizeForSend);
		DataFragment original = dataSourceDisk.get(requiredDataID);
		SimulationDebug.println("id = " + requiredDataID + 
				   ", dataSourceDisk = " + dataSourceDisk);
		dataFragment.generatedTime = original.generatedTime;

		try {
		    dataSourceDisk.accessedAt(currentTime, dataFragment);
		} catch (BricksException e) {
		    e.printStackTrace();
		    System.err.println(
			this + ": dataSource = " + dataSource + 
			", destination" + destination  + 
			", dataDestination = " + dataDestination);
		    BricksUtil.abort("currentIndex = " + indexOfCurrentNode +
				     " of " + listOfRoute);
		}
		
		// for dataSource
		if (!dataSourceDisk.reserved(dataFragment)) {
		    reservationFail = true;
		    System.out.println("fail at A");
		}
		// for destination
		if (destination.equals(dataSource)) {
		    if (!(destination.getDisk()).reserved(dataSizeForReceive)) {
			reservationFail = true;
			System.out.println("fail at B");
		    }

		} else {
		    if (!(destination.getDisk()).reserved(
				dataSizeForSend + dataSizeForReceive
			)) {
			reservationFail = true;
			System.out.println("fail at C");
		    }
		}

		// for dataDestination
		if (!destination.equals(dataDestination)) {
		    if (!(dataDestination.getDisk()).reserved(dataSizeForReceive)) {
			reservationFail = true;
			System.out.println("fail at D");
		    }
		}

	    //arrived at destination
	    } else if (indexOfCurrentNode == indexOfDestination) {
		Disk disk = ((Host)currentNode).getDisk();
		if (!destination.equals(dataSource)) {
		    if (!dataSourceDisk.released(dataFragment))
			releaseFail = true;
		    if (!disk.released(dataSizeForSend))
			releaseFail = true;
		    if (!disk.reserved(dataFragment)) {
			reservationFail = true;
			System.out.println("fail at E");
		    }
		    if (moveAtSend)
			dataSourceDisk.remove(currentTime, dataFragment);
		}

	    // finish computation
	    } else if (indexOfCurrentNode == indexOfDestination + 1) {
		try {
		    Disk disk = (Disk)currentNode;
		    if (!disk.released(dataFragment))
			releaseFail = true;
		    if (!disk.released(dataSizeForReceive))
			releaseFail = true;

		    // make new dataFragment for results.
		    dataFragment = new DataFragment(
			"result" + resultSerialNumber++, dataSizeForReceive
		    );
		    dataFragment.generatedTime = currentTime;
		    dataFragment.stored(currentTime, disk);
		    if (!disk.reserved(dataFragment)) {
			reservationFail = true;
			System.out.println("fail at F");
		    }
		    dataSourceDisk = disk;

		} catch (BricksNoDiskSpaceException e) {
		    e.printStackTrace();
		    BricksUtil.abort();
		}

	    // arrived at dataDestination
	    } else if (indexOfCurrentNode == listOfRoute.size() - 1) {
		try {
		    if (!dataSourceDisk.released(dataFragment))
			releaseFail = true;
		    Disk disk = ((Host)currentNode).getDisk();
		    if (!currentNode.equals(dataDestination)) {
			if (!disk.released(dataFragment.size))
			    releaseFail = true;
			if (moveAtRecv)
			    dataSourceDisk.remove(currentTime, dataFragment);
			dataFragment.stored(currentTime, disk);
		    }

		    // for PassiveReplicaManager
		    dataDestination.replicate(currentTime, dataFragment);

		} catch (BricksNoDiskSpaceException e) {
		    e.printStackTrace();
		    BricksUtil.abort();
		}
	    }

	    if (reservationFail)
		BricksUtil.abort(this + ": Disk space reservation failed.");

	    if (releaseFail)
		BricksUtil.abort(this + ": Disk space release failed.");

	}

	// enqueue time
	//getLog(currentTime);
	getLog(currentTime, "e");
	getNodeLog(currentNode);

	if (start < 0) {
	    start = startTime;
	} else {
 	    if (indexOfCurrentNode == indexOfDestination) {
		dataSize = listOfDataSize[indexOfCurrentNode];
		sendDuration = currentTime - start;
		start = currentTime;

	    } else if (indexOfCurrentNode == indexOfDestination + 1) {
		dataSize = listOfDataSize[indexOfCurrentNode];
		execDuration = currentTime - start;
		start = currentTime;

	    } else if (indexOfCurrentNode == listOfRoute.size() - 1) {
		recvDuration = currentTime - start;
	    }
	}

	SimulationDebug.println(Format.format(currentTime, precision) + 
	    " : ND : " + this + " goto " + currentNode + "\n");
	currentNode.schedule(currentTime, this);
    }

    // override
    // caller: Network
    public void updateTimeEventComes(double currentTime) {
	timeEventComes = currentTime + processingDuration;
	// dequeue time
	//getLog(currentTime);
	getLog(currentTime, "d");
    }

    // override
    public void outLogString(double currentTime) {
	source.printLog(toLogString(currentTime));
	numRequestedData++;
    }

    // for EPClient
    public void outLogString(String str) {
	// time Request finished
	source.printLog(str);
    }

    public String toOriginalString() {
	String str = "RequestedData<" + id + "> " + 
	    Format.format(timeEventComes, precision) + ",  " +
	    Format.format(dataSizeForSend, precision) + ",  " + 
	    Format.format(dataSizeForReceive, precision) + ",  " + 
	    Format.format(numInstructions, precision) + "\n";
	str += "  from " + source + " to " + destination + "\n";
	//str += "  Route :: " + vectorToString(listOfRoute);
	return str;
    }

    // debug
    public String showLog() {
	return log;
    }

    public String getName() {
	return "RequestedData";
    }

/************************* public method *************************/
    public void initRoute(
	double currentTime, Host destination, SimulationSet set
    ) {
	//this.destination = destination;
	Vector stoc;
	if (dataSource == null) {
	    listOfRoute = (Vector)set.getRoute(source, destination);
	    stoc = (Vector)set.getRoute(destination, source);
	} else {
	    listOfRoute = (Vector)set.getRouteForLoad(dataSource, destination);
	    stoc = (Vector)set.getRouteForStore(destination, dataDestination);
	    if (!dataSource.equals(destination))
		sendReplication = true;
	    if (!destination.equals(dataDestination)) {
		recvReplication = true;
	    }
	}
	SimulationDebug.println(this + " 's ctos = {" + listOfRoute + "}");
	SimulationDebug.println(this + " 's stoc = {" + stoc + "}");
	indexOfDestination = listOfRoute.size() - 1;
	stoc.remove(0); // remove destination;
	Enumeration e = stoc.elements();
	while (e.hasMoreElements()) {
	    listOfRoute.addElement(e.nextElement());
	}
	SimulationDebug.println(this + " 's route = " + listOfRoute);
	SimulationDebug.println(
	    "(send, recv, ninst) = " + dataSizeForSend + ", " +
	    dataSizeForReceive + ", " + numInstructions);
	
	listOfDataSize = new double[listOfRoute.size()];
	for (int i = 0; i < indexOfDestination; i++) {
	    listOfDataSize[i] = dataSizeForSend;
	}
	listOfDataSize[indexOfDestination] = numInstructions;
	for (int i = indexOfDestination + 1; i < listOfRoute.size(); i++) {
	    listOfDataSize[i] = dataSizeForReceive;
	}

	currentNode = (Node)listOfRoute.firstElement();
	log = outInitData() + currentNode.toString();
	// schedule time
	//getLog(currentTime);
	getLog(currentTime, "s");
    }

    /*
    public void initRoute(
	double currentTime, Vector listOfRoute, Host destination, 
	int indexOfDestination
    ) {
	this.destination = destination;
	this.listOfRoute = listOfRoute;
	this.indexOfDestination = indexOfDestination;
	listOfDataSize = new double[listOfRoute.size()];

	for (int i = 0; i < indexOfDestination; i++) {
	    listOfDataSize[i] = dataSizeForSend;
	}
	listOfDataSize[indexOfDestination] = numInstructions;
	for (int i = indexOfDestination + 1; i < listOfRoute.size(); i++) {
	    listOfDataSize[i] = dataSizeForReceive;
	}

	// for Packets
	if (listOfRoute.size() == 0)
	BricksUtil.abort("route is null at " + this);

	currentNode = (Node)listOfRoute.firstElement();
	indexOfCurrentNode = 0;
	log = outInitData() + currentNode.toString();
	// schedule time
	//getLog(currentTime);
	getLog(currentTime, "s");
    }
    */

    // override
    public void updateDataSize() {
	SimulationDebug.println(
	    this + ": updateDataSize : indexOfCurrentNode = " +
	    indexOfCurrentNode
	);
	SimulationDebug.println(listOfRoute);
	//Node node = (Node)listOfRoute.elementAt(indexOfCurrentNode);
	dataSize = listOfDataSize[indexOfCurrentNode+1];
    }

    public void updateDataSize(double size) {
	this.dataSize = size;
    }

    public Vector getSubList(double currentTime) {
	// getLog of time (finished scheduling / enqueue firstpacket)
	getLog(currentTime, "t");

	Vector list = new Vector();
	if (requiredDataID  == null) {
	    if (indexOfDestination == indexOfCurrentNode) { // recv
		for (int i = indexOfCurrentNode; i < listOfRoute.size()-1; i++)
		    list.add(listOfRoute.elementAt(i));
	    } else {  // send
		for (int i = indexOfCurrentNode; i < indexOfDestination; i++)
		    list.add(listOfRoute.elementAt(i));
	    }

	} else {  // DataGrid

	    SimulationDebug.println("RequestedData.getSubList : indexOfDestination = " + indexOfDestination + ", indexOfCurrentNode = " + indexOfCurrentNode);
	    SimulationDebug.println(
		"source = " + dataSource + ", compServer = " + destination + 
		", detaDestination = " + dataDestination);

	    if (indexOfDestination + 1 == indexOfCurrentNode) { // recv
		for (int i = indexOfCurrentNode; i < listOfRoute.size()-1; i++)
		    list.add(listOfRoute.elementAt(i));
	    } else {  // send
		for (int i = indexOfCurrentNode; i < indexOfDestination; i++)
		    list.add(listOfRoute.elementAt(i));
	    }
	}
	list.addElement(new TerminalNode());
	return list;
    }

    /** 
     * caller: scheduler
     **/
    public void putDestination(Host host, int priority) {
	this.destination = host;
	this.priority = priority;
    }

    /** 
     * caller: scheduler
     **/
    public void putEstimate(double send, double recv, double exec) {
	estimatedSendDuration = send;
	estimatedExecDuration = exec;
	estimatedRecvDuration = recv;
	//estimatedDuration = send + recv + exec;
    }

    /** 
     * caller: deadline scheduler
     **/
    public void setElapsedTime(double time) {
	elapsedTime = time;
    }

    /** 
     * caller: ResourceDB.removeSchedulingInfo()
     **/
    public boolean equals(Object object) {
	if (object instanceof RequestedData) {
	    RequestedData data2 = (RequestedData)object;
	    if (this.serialNumber == data2.serialNumber)
		return true;
	}
	return false;
    }

    /** 
     * for fallback
     **/
    public void fallback(double currentTime) {
	source.fallback(currentTime, this);
    }
	    
    // for fallback
    public void flash() {
	if (scheduledHosts == null)
	    scheduledHosts = new Vector();
	scheduledHosts.addElement(destination);
	destination = null;
	log = "";
	destination = null;
	dataSize = dataSizeForSend;
	indexOfCurrentNode = 0;
    }

    public int numSchedule() {
	if (scheduledHosts != null)
	    return scheduledHosts.size();
	else 
	    return 0;
    }

    public boolean scheduled(Host host) {
	if (scheduledHosts != null) {
	    int index = scheduledHosts.indexOf(host);
	    if (index >= 0)
		return true;
	}
	return false;
    }

    public Enumeration scheduledHosts() {
	return scheduledHosts.elements();
    }

/************************* protected method *************************/
    protected String toLogString(double currentTime) {

	String str = this + " " + 
	    Format.format(dataSizeForSend, precision) + " " +
	    Format.format(dataSizeForReceive, precision) + " " + 
	    Format.format(numInstructions, precision) + " ";

	//Format.format(startTime, precision) + " " + 
	str +=  source + " " + destination + " " + 
	    Format.format(startTime, precision) + " " + 
	    Format.format(sendDuration, precision) + " " + 
	    Format.format(execDuration, precision) + " " + 
	    Format.format(recvDuration, precision) + " " + 
	    Format.format(sendDuration + execDuration + recvDuration, precision);
	if (dataSource != null)
	    str += " " + sendReplication + " " + recvReplication;

	if (deadlineFactor >= 0.) { /* deadline */
	    str += " deadline " + 
		Format.format(deadline, precision) + " " +
		Format.format(expectedFinishTime, precision) + " " + 
		Format.format(deadlineFactor, precision) + " " +
		priority + " ";
	    if (scheduledHosts == null)
		str += "0";
	    else
		str += scheduledHosts.size();
	}

	//return log + "\n" + str;
	return str;
    }

    protected String vectorToString(Vector vec) {
	Enumeration e = vec.elements();
	String str = null;
	while (e.hasMoreElements()) {
	    str += e.nextElement() + ", ";
	}
	return str;
    }

    protected String outInitData() {
	String str = "[ " + Format.format(dataSizeForSend, precision) + " " +
	    Format.format(dataSizeForReceive, precision) + " " + 
	    Format.format(numInstructions, precision) + " ] ";
	return str;
    }

    protected void getLog(double currentTime) {
	Double doubleObj = new Double(currentTime);
	log = log + " " + Format.format(doubleObj.doubleValue(), precision);
    }

    protected void getLog(double currentTime, String str) {
	Double doubleObj = new Double(currentTime);
	log = log + " " + str + Format.format(doubleObj.doubleValue(), precision);
    }

    protected void getNodeLog(Node node) {
	log = log + " " + node;
    }
}


