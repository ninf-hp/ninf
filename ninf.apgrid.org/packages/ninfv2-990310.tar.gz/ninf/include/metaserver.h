#ifndef __METASERVER__
#define __METASERVER__



typedef struct metaConnection {
  int socket;
  FILE * is;
  FILE * os;
} metaConnection;

metaConnection * metaserver_connect(char * host, char * port);
int metaserver_send(metaConnection * , char *, ...);
int metaserver_flush(metaConnection *);
int metaserver_close(metaConnection *);

#endif /* __METASERVER__ */
