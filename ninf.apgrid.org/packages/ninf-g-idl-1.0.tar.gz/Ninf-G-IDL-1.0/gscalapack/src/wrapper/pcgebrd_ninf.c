#define _WRAPPER_
/* $Id: pcgebrd_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define _DISTRIBUTE_1D_
#define SCOMPLEX
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n
static	int worklen(int m, int n) {
	  int ret;
	  int IROFFA, ICOFFA;
	  int IAROW, IACOL, MpA0, NqA0;
	  ret = n*(m+n+1) + n;
	  if NEED_BUFF {
#define NB blocsize
#define IA 1
#define JA 1
#define MYROW myprow
#define NPROW nprow
#define MYCOL mypcol
#define NPCOL npcol
#define NUMROC Cnumroc
#define RSRC_A 0
#define CSRC_A 0
	    IROFFA = MOD( IA-1, NB );
	    ICOFFA = MOD( JA-1, NB );
	    IAROW = INDXG2P( IA, NB, MYROW, RSRC_A, NPROW );
	    IACOL = INDXG2P( JA, NB, MYCOL, CSRC_A, NPCOL );
	    MpA0 = NUMROC( M+IROFFA, NB, MYROW, IAROW, NPROW );
	    NqA0 = NUMROC( N+ICOFFA, NB, MYCOL, IACOL, NPCOL );
	    ret = NB*( MpA0 + NqA0 + 1 ) + NqA0;
	  }
	  return ret;
}

void  pcgebrd_ninf(	 int m,
		 int n,
		 scomplex global_a[],
		 int lda,
		 float global_d[],
		 float global_e[],
		 scomplex global_tauq[],
		 scomplex global_taup[],
		 scomplex work[],
                 int lwork,
		 int *info
)
/* "pcgebrd reduces a complex general M-by-N distributed matrix A to upper or lower bidiagonal form B by an unitary transformation: Q' * A * P = B. If M >= N, B is upper bidiagonal; if M < N, B is lower bidiagonal." */
/* OPTIONS */
{
  int min_m_n;
	int maxldd;

	int maxlda;
	scomplex *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];

	float *locd=NULL;
	float *loce=NULL;
	int desctdd[DESCLEN], desc_gtdd[DESCLEN];
        
        scomplex *loctauq=NULL;
	scomplex *loctaup=NULL;

	scomplex *locwork=NULL;
	int llocwork;
        
	int row_loca;
	int col_loca;

	INITIALIZE();

	SCALAR( "int", m);
	SCALAR( "int", n);
	SCALAR("int", lda);
	SCALAR( "int", lwork);

	min_m_n=min(m,n);
	SIZE(min_m_n);

	ROW( a);
	COL( a);
	MAXLDD( maxldd, a );
	maxlda = maxldd;

	MATRIX( "scomplex", a, ROW_a, COL_a);
	tdMATRIX( "float", e, d, e, min_m_n);

	DISTRIBUTE( "scomplex", a, ROW_a  , COL_a);
	VECTOR( "c", "scomplex", tauq, min_m_n);
	VECTOR( "r", "scomplex", taup, min_m_n);

        llocwork = worklen( m, n);
	llocwork = max(lwork,llocwork);
	WORK(locwork,llocwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pcgebrd)( &m, &n,
                               loca, &one, &one, desca,
                               locd, loce,
                               loctauq, loctaup,
                               locwork, &llocwork, &linfo);

	GATHER( "scomplex", a, ROW_a  , COL_a);
	tdGATHER( "float", e, d, e, min_m_n);
	vGATHER( "c", "scomplex", tauq, min_m_n);
	vGATHER( "r", "scomplex",  taup, min_m_n);

	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
	  *info = linfo;
	} else {
	}

	FREE_MATRIX(a);
	FREE_MATRIX(d);
	FREE_MATRIX(e);
	FREE_VECTOR(taup);
	FREE_VECTOR(tauq);

	FREE(locwork);
}

