package bricks.environment;
import bricks.util.*;
import bricks.scheduling.ResourceDB;
import java.io.*;
import java.util.*;

/** NullDisk.java */
public class NullDisk extends Disk {

    /**
     * Constructor for NullDisk.
     */
    public NullDisk() {
	nextEventTime = Double.POSITIVE_INFINITY;
    }

/************************* needed method *************************/
    /** 
     * returns a type of the Disk.
     */
    public String getName() {
	return "NullDisk";
    }

    public void setHost(Host host, double packetSize) {;}
    public void setResourceDB(ResourceDB resourceDB) {;}
    public void init() {;}
    public void schedule(double currentTime, Data data) {;}
    public void processEvent(double currentTime) {;}
    public void updateNextEvent(double currentTime) {;}
    public String toInitString() {return null;}
    public Host host() {return null;}
    public double getThroughput() {return Double.POSITIVE_INFINITY;};
    public void addDiskInfo() {;}
    public Enumeration dataFragments() {return null;}
    public void remove(double currentTime, DataFragment fragment) {;}
    public void store(double currentTime, DataFragment fragment) 
	throws BricksNoDiskSpaceException {;}
    public boolean makeDiskSpace(
        double currentTime, double compactness, DataFragment dataFragment
    ) {return false;}
    public boolean makeDiskSpace(double currentTime, double compactness) {return false;}
    public void finish() {;}
    protected boolean makeDiskSpace(
	double currentTime, double removedSize, Vector table) {return false;}
    public boolean reserved(DataFragment dataFragment) {return false;}
    public boolean released(DataFragment dataFragment) {return false;}
    public boolean reserved(double dataSize) {return false;}
    public boolean released(double dataSize) {return false;}
    public void accessedAt(double currentTime, DataFragment dataFragment) {;}

    protected Data getNextData(double currentTime) {return null;}
    protected void addAccessInfo(
	double currentTime, double trackingTime, HostInfo hostInfo){};
    protected void printLog(double currentTime, String log) {;}
}
