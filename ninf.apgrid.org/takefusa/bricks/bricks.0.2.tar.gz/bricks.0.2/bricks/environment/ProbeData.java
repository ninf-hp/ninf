package bricks.environment;
import bricks.util.*;
import bricks.scheduling.*;
import java.util.*;

public class ProbeData extends TrafficData {

    protected NodePair probedNetwork;
    public NetworkMonitor networkMonitor;
    public double startTime;
    public double totalDataSize;

    public ProbeData(
	SimulationSet owner, NodePair probedNetwork, 
	NetworkMonitor networkMonitor, double dataSize, double currentTime
    ) {
	id = generateId();
	processingDuration = 0.0;
	this.probedNetwork = probedNetwork;
	this.networkMonitor = networkMonitor;
	this.dataSize = dataSize;
	totalDataSize = dataSize;
	startTime = currentTime;
	initListOfRoute(owner);
	currentNode = (Node)listOfRoute.firstElement();
	SimulationDebug.println(
	    "ProbeData: probedNetwork = " + probedNetwork + "(" + 
	    listOfRoute + ")"
	);
    }


/************************* needed method *************************/
    public String getName() {
	return "ProbeData";
    }

    public void killed(double currentTime) {
	SimulationDebug.println(
	    "ProbeData(" + this + "): " + Format.format(currentTime, 3) +
	    " : killed"
	);
	probedNetwork.finishProbing(currentTime, this);
    }

/************************* protected method *************************/
    /** 
     * initListOfRoute changes the route 
     *	from [[source] [network 0] ... [network n] [destination]]
     *	to   [[network 0] [network 0] ... [network n] TerminalNode]
     **/
    protected void initListOfRoute(SimulationSet owner) {
	listOfRoute = owner.getRoute(probedNetwork);
	if (listOfRoute == null)
	    System.out.println("Error:" + this + ": route is null!");
	listOfRoute.setElementAt(listOfRoute.elementAt(1), 0);
	listOfRoute.setElementAt(new TerminalNode(), listOfRoute.size() - 1);
    }
}
