#define _WRAPPER_
/* $Id: pdgbtrf_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define _DISTRIBUTE_1D_
#define DOUBLE
#define PIVOT
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n
static	int worklen() {
	  int ret=1;
	  ret = 10;
	  if NEED_BUFF {
	    ret = max(10,blocsize);
	  }
	  return ret;
}

void  pdgbtrf_ninf(	 int n,
		 int bwl,
		 int bwu,
		 double global_a[],
		 int lda,
		 int global_ipiv[],
		 int *info
)
/* "pdgbtrf computes a LU factorization of an N-by-N real banded distributed matrix with bandwidth BWL, BWU: A." */
/* OPTIONS */
{
    extern void FortranCall(pdgbtrf)( int*, int*, int*,
                               double*, int*, int*,
                               int*,
                               double*, int*,
                               double*, int*, int*);

	int maxldd;

	double *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];

	double *locaf=NULL;
	int laf;

	int *locipiv=NULL;

	double *locwork=NULL;
	int llocwork;



	INITIALIZE();

	SCALAR( "int", n);
	SCALAR( "int", bwl);
	SCALAR( "int", bwu);
	SCALAR("int", lda);

	SIZE(n);

	bandMATRIX( "double", a, bwl, bwu, n);
	bandDISTRIBUTE( "double", a, bwl, bwu, n);
	VECTOR( "c", "int", ipiv, n);

	llocwork=worklen();
	WORK(locwork,llocwork);

	laf=(blocsize+bwu)*(bwl+bwu)+6*(bwl+bwu)*(bwl+2*bwu);
	locaf=MALLOC(sizeof(double)*laf); assert(locaf);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pdgbtrf)( &n, &bwl, &bwu,
                               loca, &one, desca,
                               locipiv,
                               locaf, &laf,
                               locwork, &llocwork, &linfo);

	bandGATHER( "double", a,  bwl, bwu, n);
	vGATHER( "c", "int", ipiv, n);

	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
	  *info = linfo;
	} else {
	}
	FREE_MATRIX(a);
	FREE_MATRIX(ipiv);
	FREE_MATRIX(af);
        FREE(locaf);
	
}

