package ninf.basic;

import java.util.Vector;

class ThrottleThread implements Runnable{
  Throttle throttle;
  ThrottleThread(Throttle throttle){
    this.throttle = throttle;
  }
  public void run(){
    while (true){
      Runnable runnable = throttle.getRunnable();
      runnable.run();
    }
  }
}


public class Throttle{
  Vector runnables = new Vector();
  Vector threads = new Vector();

  public Throttle(int num){
    for (int i = 0; i < num; i++){
      Thread tmp = new Thread(new ThrottleThread(this));
      threads.addElement(tmp);
      tmp.start();
    }
  }

  public void kill(){
    if (threads == null)
      return;
    for (int i = 0; i < threads.size(); i++)
      ((Thread)threads.elementAt(i)).stop();
    threads = null;
  }

  public synchronized void addRunnable(Runnable runnable){
    runnables.addElement(runnable);
    notify();
  }

  synchronized Runnable getRunnable(){
    while (runnables.size() <= 0){
      try {
	wait();
      } catch (InterruptedException e){
      }
    }
    Runnable tmp = (Runnable)runnables.elementAt(0);
    runnables.removeElementAt(0);
    return tmp;
  }
}
