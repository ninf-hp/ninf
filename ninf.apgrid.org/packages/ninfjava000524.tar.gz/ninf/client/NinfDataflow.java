// NinfDataflow.java

package ninf.client;
import ninf.basic.*;
import ninf.client.*;


import java.io.IOException;

public class NinfDataflow {
  // *********************** NON STATIC VARIABLES ***********************
  public int index;
  public int stubNum;
  public NinfStub stub;
  public DependInfo dinfo[];
  NinfLog dbg = new NinfLog(this);

  // ***********************  INSTANCE  CREATION  ***********************
  public NinfDataflow(NinfPacketInputStream is, CallableCache callableCache)
    throws NinfException {
      read(is);
      getStub(callableCache);
    }
  
  // ***********************     I/O  METHODS     ***********************
  public void read(NinfPacketInputStream is) throws NinfException {
    index = is.readInt();
    stubNum = is.readInt();
    int args = is.readInt();
    dinfo = new DependInfo[args];
    for (int i = 0; i < args; i++)
      dinfo[i] = new DependInfo(is);
    dbg.println("dataflow.read. No:" + index);
    dbg.println(this);
  }

  public String toString() {
    String tmp = "stubNum:"+ stubNum +" [";
    for (int i = 0; i < dinfo.length; i++)
      tmp += dinfo[i].toString();
    tmp += "]";
    return tmp;
  }

  // ***********************  NON STATIC METHODS  ***********************
  public void getStub(CallableCache callableCache) throws NinfException{
    stub = callableCache.getCallable(stubNum).getStub();
  }

  public int[] dependent() {
    int c = 0, d = 0;
    for (int i = 0; i < dinfo.length; i++)
      if (!dinfo[i].isNoLower())
	c += dinfo[i].outputDepends.length;
    int tmp[] = new int[c];
    for (int i = 0; i < dinfo.length; i++)
      if (!dinfo[i].isNoLower()){
	for (int j = 0; j < dinfo[i].outputDepends.length; j++)
	  tmp[d++] = dinfo[i].outputDepends[j].functionIndex;
      }
    String tmpStr = "depend:";
    for (int i = 0; i < tmp.length; i++)
      tmpStr += tmp[i] + " ";
    dbg.println(tmpStr);
    return tmp;
  }
}

// end of NinfDataflow.java
