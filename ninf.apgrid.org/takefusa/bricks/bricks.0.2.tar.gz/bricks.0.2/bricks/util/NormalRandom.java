package bricks.util;
import java.util.Random;

/** 
 * NormalRandom(double mean, long seed)
 **/
public class NormalRandom extends Sequence implements SubComponent {
    protected Random random;

    public NormalRandom(long seed, double mean) {
	random = new Random(seed);
	this.mean = mean;
    }

    public String getName() {
	return "NormalRandom";
    }

    public double nextDouble(double currentTime) {
	return nextDouble();
    }

    public double nextDouble() {
	return Math.abs(mean * random.nextGaussian()) / 4.0;
    }

    // for debug
    public static void main(String[] argv) {
	if (argv.length < 3) {
	    System.out.println(
		"Usage: java ExponetRandom [mean] [seed] [num]"
	    );
	    return;
	}
	double mean = Double.valueOf(argv[0]).doubleValue();
	long seed = Long.valueOf(argv[1]).longValue();
	int num = Integer.valueOf(argv[2]).intValue();

	NormalRandom e = new NormalRandom(seed, mean);
	for (int i = 0 ; i < num ; i++) {
	    System.out.println(e.nextDouble());
	}
    }
}
