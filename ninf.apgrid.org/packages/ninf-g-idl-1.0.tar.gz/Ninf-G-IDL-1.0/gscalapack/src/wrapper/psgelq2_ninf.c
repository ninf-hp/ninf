#define _WRAPPER_
/* $Id: psgelq2_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define FLOAT
#include <gscalapack.h>

#define ROW_a  lda
#define COL_a  n
static	int worklen(int m, int n) {
	  int ret=1;
	  int IROFF, IAROW, IACOL, Mp0, Nq0, ICOFF;
	  ret = n+max(1,m);
	  if NEED_BUFF {
#define IA 1
#define JA 1
#define MB_A rbloc
#define NB_A cbloc
#define MYROW myprow
#define MYCOL mypcol
#define NPROW nprow
#define NPCOL npcol
#define RSRC_A 0
#define CSRC_A 0
	    IROFF = MOD( IA-1, MB_A );
	    ICOFF = MOD( JA-1, NB_A );
	    IAROW = INDXG2P( IA, MB_A, MYROW, RSRC_A, NPROW );
	    IACOL = INDXG2P( JA, NB_A, MYCOL, CSRC_A, NPCOL );
	    Mp0   = NUMROC( M+IROFF, MB_A, MYROW, IAROW, NPROW );
	    Nq0   = NUMROC( N+ICOFF, NB_A, MYCOL, IACOL, NPCOL );
	    ret = Nq0 + MAX( 1, Mp0 );
	  }
	  return ret;
}


void  psgelq2_ninf(	 int m,
		 int n,
		 float global_a[],
		 int lda,
		 float global_tau[],
		 int ldtau,
		 float work[],
		 int *info
)
/* "psgelq2 computes a LQ factorization of a real distributed M-by-N matrix A = L * Q." */
/* OPTIONS */
{
	int maxldd;

	int maxlda;
	float *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
	int row_loca, col_loca;

	float *loctau=NULL;

	float *locwork=NULL;
	int llocwork;

	INITIALIZE();

	SCALAR( "int", m);
	SCALAR( "int", n);
	SCALAR( "int", lda);

	ROW( a);
	COL( a);
	MAXLDD( maxldd, a );
	maxlda = maxldd;

	MATRIX( "float", a, ROW_a, COL_a);
	DISTRIBUTE( "float", a, ROW_a  , COL_a);

	VECTOR("r", "float",tau, min(m,n));

	llocwork=worklen(m, n);
	WORK(locwork,llocwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(psgelq2)( &m, &n,
                               loca, &one, &one, desca,
                               loctau,
                               locwork, &llocwork, &linfo);

	GATHER( "float", a, ROW_a, COL_a);
	vGATHER( "r", "float", tau, min(m,n));

	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
	  *info = linfo;
	} else {
	}

	FREE_MATRIX(a);
	FREE_VECTOR(tau);
	FREE(locwork);
        
}

