#include <stdio.h>
#include <stdlib.h>
#include "ninf.h"

#define N 10
#ifndef TRUE
#define TRUE (0 == 0)
#define FALSE (!TRUE)
#endif

void initMatI(int n, double * a){
  int i, j;
  for (i = 0; i < n; i++)
	for (j = 0; j < n; j++)
	  a[j + i * n] = (i == j)? 1 : 0;
}

void initMatRand(int n, double * a){
  int i, j;
  for (i = 0; i < n; i++)
	for (j = 0; j < n; j++)
	  a[j + i * n] = rand();
}

int checkMat(int n, double * a, double * b){
  int i, j;
  for (i = 0; i < n; i++)
	for (j = 0; j < n; j++)
	  if (a[j + i * n] != b[j + i * n])
		return FALSE;
  return TRUE;
}

void mmul(int n, double * a, double * b, double * c){
  double t;
  int i, j, k;
  for (i = 0; i < N; i++) {
	for (j = 0; j < N; j++) {
	  t = 0;
	  for (k = 0; k < N; k++){
		t += a[i * n + k] * b[k * n + j];
	  }
	  c[i*N+j] = t;
	}
  }
}

int main(int argc, char ** argv){
  double A[N*N], B[N*N], C[N*N]; 

  argc = Ninf_parse_arg(argc, argv);
  initMatRand(N, A);
  initMatI(N, B);

  if (Ninf_call("mmul/mmul", N, A, B, C) != NINF_OK)
	Ninf_perror("mmul");
  exit(0);
}
