package ninf.metaserver;
import ninf.basic.*;
import ninf.common.*;
import ninf.client.*;
import java.io.*;

class DirectoryServiceFront {
  static CommandParser endThroughputInfoParser = 
    new CommandParser(new CommandRepresent("endThroughputInfo", 0));
  static CommandParser serverParser = 
    new CommandParser(new CommandRepresent("server",            2));
  DirectoryService directoryService;

  DirectoryServiceFront(DirectoryService directoryService){
    this.directoryService = directoryService;
  }

  void throughputInfo(DataInputStream is, PrintStream os) 
  throws NinfException{
    ServerID serverFrom, serverTo;
    NinfCommand com;
    CommunicationInformation throughput, latency;
    com = serverParser.readCommand(is);
    serverFrom = new ServerID(com.args[0], 
			      (new Integer(com.args[1])).intValue());
    com = serverParser.readCommand(is);
    serverTo   = new ServerID(com.args[0], 
			      (new Integer(com.args[1])).intValue());
    throughput = new CommunicationInformation(is);
    latency    = new CommunicationInformation(is);    
    com = endThroughputInfoParser.readCommand(is);
    directoryService.addInterServerInfo(serverFrom, serverTo,
				       new InterServerInfo(throughput, latency));
  }

}
