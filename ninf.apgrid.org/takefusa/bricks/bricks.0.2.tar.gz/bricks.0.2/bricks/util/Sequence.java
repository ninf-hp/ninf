package bricks.util;

public abstract class Sequence {
    public double mean;

    public abstract double nextDouble(double currentTime);
    public abstract double nextDouble();

    public double max() {
	return -1;
    }

    public int nextInt() {
	return (int)nextDouble();
    }
}
