package bricks.util;
import java.io.*;
import java.util.*;

public class TraceFile extends Sequence implements SubComponent {

    protected String fileName;
    protected int numPoints;
    protected double[] t;
    protected double max = -1.0;
    protected int currentPoint = 0;

    public TraceFile(String fileName, int numPoints) {
	this.fileName = fileName;
	this.numPoints = numPoints;
    }

    public void init() throws BricksParseException {
	try {
	    InputStream is = new FileInputStream(fileName);
	    t = new double[numPoints];
	    init(is, numPoints);
	} catch (FileNotFoundException e) {
	    throw new BricksParseException("Cannot open '" + fileName + "'");
	}
    }

    public String getName() {
	return "TraceFile";
    }

    public double max() {
	return max;
    }

    public double nextDouble(double currentTime) {
	return t[currentPoint++];
    }

    public double nextDouble() {
	double x = 0.0;
	try {
	    x = t[currentPoint];
	    currentPoint++;
	} catch (ArrayIndexOutOfBoundsException e) {
	    e.printStackTrace();
	    System.err.println("fileName = " + fileName);
	    System.err.println("currentPoint = " + currentPoint);
	    System.exit(3);
	}
	return x;

    }

    public int nextInt() {
	    return (int)nextDouble();
    }

    private void init(InputStream is, int numPoints) {
	BufferedReader br = new BufferedReader(new InputStreamReader(is));
	try {
	    String line;
	    int i = 0;
	    while (i < numPoints) {
		if ((line = br.readLine()) != null) {
		    StringTokenizer st = new StringTokenizer(line);
		    while (st.hasMoreElements()) {
			t[i] = 
			    Double.valueOf(st.nextToken(" \t,")).doubleValue();
			if (t[i] > max)
			    max = t[i];
			i++;
		    }
		}
	    }
	} catch (IOException e) {
	    e.printStackTrace();
	}
    }
}
