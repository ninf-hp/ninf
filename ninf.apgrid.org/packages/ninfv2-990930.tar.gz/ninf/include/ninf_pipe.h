#ifndef _NINF_PIPE_H_
#define _NINF_PIPE_H_

#define NINF_PIPE_SOCKETPAIR 0
#define NINF_PIPE_UNIXDOMAIN 1
#define NINF_PIPE_FILENAME_LEN 1000
#define UNIX_SOCK_NAME_FMT 	"/tmp/ninf.%d"

typedef struct ninf_pipe {
  int flag;
  int fd[2];  /* 0 for child , 1 for parent */
  int l_sock; /* listen socket */
  char * filename;
  
} ninf_pipe;

ninf_pipe *    new_ninf_pipe(int flag);

void        delete_ninf_pipe(ninf_pipe * );

char *             ninf_pipe_description(ninf_pipe * );
int                ninf_pipe_parent_clean(ninf_pipe *);
int                ninf_pipe_child_clean(ninf_pipe *);
int                ninf_pipe_get_fd(ninf_pipe *);

int get_fd_from_description(char * description, int flag);

#endif /* _NINF_PIPE_H_ */
