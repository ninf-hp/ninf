/*
 *  $Id: ninf_stream.c,v 1.6 1999/02/27 06:45:52 tatebe Exp $
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/wait.h>
#include <unistd.h>

#include "ninf_macros.h"
#include "ninf_error.h"
#include "ninf_data_trans.h"
#include "ninf_serv_reg.h"
#include "ninf_stream.h"
#include "ninf_server_state.h"
#include "ninf_protocol.h"

#define UNIX_SOCK_NAME_FMT 	"/tmp/ninf.%d"
static char local_filename[100];
extern int ninf_debug_flag;
extern char * save_str(char *);

FILE *fdopen(int fildes, const char *type);

static void setup_argv_sub(char * str, char ** argv){
  char ** argp = argv;
  char * tmp = strtok(str, " \t");
  while (tmp != NULL){
    *(argp++) = save_str(tmp);
    tmp = strtok(NULL, " \t");
  }
  *argp = NULL;
}

static void setup_argv(char **program, char ** argv, char * stubname, int fd){
  static char buffer[1000];
  sprintf(buffer, "%s %d", stubname, fd);
  setup_argv_sub(buffer, argv);
  *program = argv[0];
}

/* returns stub_pid */

int ninf_local_forkexec_outerr(char * stubname, int checkPid, server_state * state){
  long pid;
  int fd[2], fdout[2], fderr[2];
  char * argv[30];
  char * program;
  
  if (socketpair(AF_UNIX, SOCK_STREAM, 0, fd) < 0){
    perror("socketpair");
    return -1;
  }
  if (socketpair(AF_UNIX, SOCK_STREAM, 0, fdout) < 0){
    perror("socketpair");
    return -1;
  }
  if (socketpair(AF_UNIX, SOCK_STREAM, 0, fderr) < 0){
    perror("socketpair");
    return -1;
  }
  
  if((state->stub_pid = fork()) == 0){
    if (ninf_debug_flag) fprintf(stderr, "child forked\n");
    
    close(fd[1]);  close(fdout[1]); close(fderr[1]);
    dup2(fdout[0],1);  /* redirect stdout to fdout[0] */
    dup2(fderr[0],2);  /* redirect stderr to fderr[0] */
    set_no_delay(1);
    set_no_delay(2);
    
    setup_argv(&program, argv, stubname, fd[0]);
    if (ninf_debug_flag){
      int i = 0;
      fprintf(stderr, "execute: %s ", program);
      while (argv[i] != NULL)
	fprintf(stderr, "%s ", argv[i++]);
      fprintf(stderr, "\n");
    }
    if (execvp(program, argv)<0){
      perror("ninf execvp failed:");
      ninf_log("server[%d]: failed to execstub %s", getppid(), program);
      return -1;
    }
    /* NEVER READHED HERE */
  } 
  close(fd[0]);  close(fdout[0]); close(fderr[0]);
  if(state->stub_pid < 0){
    /*  fork error */
    ninf_error("can't execute stub");
    return -1;
  }
  
  state->stub     = new_connection(fd[1],    FALSE);
  state->stub_out = new_connection(fdout[1], FALSE);
  state->stub_err = new_connection(fderr[1], FALSE);
  
  if(!trans_long(state->stub->rDT, &pid)){
    ninf_error("first packet read failed");
    return -1;
  }
  /* make sure of the connection */
  if((checkPid) && state->stub_pid != pid){
    ninf_error("bad first packet, %d != %d",state->stub_pid,pid);
    return -1;
  }
  return state->stub_pid;
}

int ninf_local_forkexec(char * stubname, int checkPid, connection ** pcon){
  int stub_pid;
  long pid;
  int fd[2];
  char * argv[30];
  char * program;

  if (socketpair(AF_UNIX, SOCK_STREAM, 0, fd) < 0){
    perror("socketpair");
    return -1;
  }
  if((stub_pid = fork()) == 0){
    if (ninf_debug_flag) fprintf(stderr, "child forked\n");
    /* child side: use fd[0] */
    close(fd[1]);
    
    setup_argv(&program, argv, stubname, fd[0]);
    if (ninf_debug_flag){
      int i = 0;
      fprintf(stderr, "execute: %s ", program);
      while (argv[i] != NULL)
	fprintf(stderr, "%s ", argv[i++]);
      fprintf(stderr, "\n");
    }
    if (execvp(program, argv)<0){
      perror("ninf execvp failed:");
      return -1;
    }
    /* NEVER READHED HERE */
  } 
  close(fd[0]);
  if(stub_pid < 0){
    /*  fork error */
    ninf_error("can't execute stub");
    return -1;
  }

  *pcon = new_connection(fd[1],    FALSE);

  if(!trans_long((*pcon)->rDT,&pid)){
    ninf_error("first packet read failed");
    return -1;
  }
  /* make sure of the connection */
  if((checkPid) && stub_pid != pid){
    ninf_error("bad first packet, %d != %d",stub_pid,pid);
    return -1;
  }
  return stub_pid;
}

int ninf_local_forkexec_state(char * stubname, int checkPid, server_state * state){
  state->stub_pid = 
    ninf_local_forkexec(stubname, checkPid, &(state->stub));
  return state->stub_pid;
}

int wait_for_killed(int stub_pid){
    int status,pid;

    /* wait for kill */
 again:
    if((pid = waitpid(stub_pid, &status, 0)) < 0) return(-1);
    if(WIFSTOPPED(status)) goto again;

    if(pid != stub_pid) {
      ninf_error("bad wait pid : waiting %d, returned %d", stub_pid, pid);
      return -1;
    }    
    if(WIFSIGNALED(status)) return(-1);
    else return(WEXITSTATUS(status));
}

int  ninf_local_kill_state(server_state *state){
  return ninf_local_kill(state->stub, state->stub_pid);
}

int  ninf_local_kill(connection * con, int stub_pid){
    /* send kill request */
    if (ninf_debug_flag) 
      fprintf(stderr, "killing stub(id: %d)", stub_pid);
    trans_request(con->sDT, NINF_REQ_KILL);
    write_flush(con->sDT);

    return wait_for_killed(stub_pid);
}

