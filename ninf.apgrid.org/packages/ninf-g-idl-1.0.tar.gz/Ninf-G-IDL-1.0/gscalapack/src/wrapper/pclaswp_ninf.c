#define _WRAPPER_
/* $Id: pclaswp_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define SCOMPLEX
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n
void  pclaswp_ninf(	 char direc,
		 char rowcol,
		 int n,
		 scomplex global_a[],
		 int lda,
		 int k1,
		 int k2,
		 int global_ipiv[],
		 int dummy_incx
)
/* "pclaswp performs a series of row or column interchanges on the distributed matrix A." */
/* OPTIONS */
{
	int maxldd;
	int maxlda;
	scomplex *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
	int row_loca, col_loca;

	int *locipiv=NULL;

	INITIALIZE();

	SCALAR( "char", direc);
	SCALAR( "char", rowcol);
	SCALAR( "int", n);
	SCALAR("int",lda);

	SCALAR( "int", k1);
	SCALAR( "int", k2);

	ROW( a);
	COL( a);
	MAXLDD( maxldd, a );
	maxlda = maxldd;

	MATRIX( "scomplex", a, ROW_a, COL_a);
	DISTRIBUTE( "scomplex", a, ROW_a  , COL_a);
	
	if (chrcmp(rowcol,'R')==0) {
	  VECTOR( "r", "int", ipiv, ROW_a);
	  vDISTRIBUTE( "r", "int", ipiv, ROW_a);
	}else {
	  VECTOR( "r", "int", ipiv, COL_a);
	  vDISTRIBUTE("r","int",ipiv, COL_a);
	}

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pclaswp)( &direc, &rowcol,
                               &n,
                               loca, &one, &one, desca,
                               &k1, &k2,
                               locipiv);

	GATHER( "scomplex", a, ROW_a, COL_a);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
	} else {
	}

	FREE_MATRIX(a);
	FREE_VECTOR(ipiv);
}

