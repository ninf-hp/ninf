package ninf.MetaServer;
import ninf.basic.*;
import ninf.client.*;



class NinfCommonData{
/*********************** NON STATIC VARIABLES ***********************/
  ArgPosition common[];
  
/***********************  INSTANCE  CREATION  ***********************/
  public NinfCommonData (NinfPacketInputStream is) throws NinfException{
    read(is);
  }

/***********************     I/O  METHODS     ***********************/
  void read(NinfPacketInputStream is) throws NinfException {
    int num = is.readInt();
    common = new ArgPosition[num];
    for (int i = 0; i < num; i++)
      common[i] = new ArgPosition(is);
  }
/***********************  NON STATIC METHODS  ***********************/
  int[] serialize(int argNums[]){
    int tmp[] = new int[common.length];
    for (int i = 0; i < common.length; i++)
      tmp[i] = common[i].serialize(argNums);
    return tmp;
  }
}
