#ifndef _GSCALAPACK_DISTRI_H_
#define _GSCALAPACK_DISTRI_H_

#ifdef _LOCAL_
extern void _scatter( const char*, void*, void*, int, int, int, int);
extern void _distribute( const char*, int, int, void*, int, int, int*, void*, int, int, int*);
extern void _tridistribute( char*, char*, const char*, int, int, void*, int, int, int*, void*, int, int, int*);
extern void _vdistribute( char *rowcol, const char* type, int size, void *v, void *locv);
extern void _tddistribute( const char*, const char*, const char*, int, void*, void*, void*, int, int, int*, void*, void*, void*, int, int, int*);
extern void _band_distribute( const char*, int, int, int, void*, int*, void*, int*, int);
#endif


#define SCALAR(type,v)        _scatter(type, &v, &v,    1, 1, 0, 0)

#define COMMON(type,pv,size)                        \
             if (mypnum!=0) {                       \
                     pv = NULL;                      \
                     pv = malloc(SIZEOF(type)*(size)); \
                     assert(pv);                     \
              }                                     \
              _scatter(type, pv, pv, size, 1, 0, 0) ; 

#define COMMON_MATRIX(type,pv,row,column)                  \
             if (mypnum!=0) {                              \
                     pv = NULL;                            \
                     pv = malloc(SIZEOF(type)*(row)*(column)); \
                     assert(pv);                           \
             }                                             \
             _scatter(type, pv, pv, row, column, 0, 0) ;

#define FREE_COMMON(pv) _free_matrix(pv)

#define RETRIEVE(type,v,size) _scatter(type, v, v, size, 1, 0, 1) // v is a pnt
#define RETRIEVE_MATRIX(type,v,row,column) _scatter(type, v, v, row, column, 0, 1)



#define DISTRIBUTE( type, a, m, n) \
                  _distribute( type,  \
                               m, n,  \
                         global_##a,  \
                               1, 1,  \
                          desc_g##a,  \
                             loc##a,  \
                               1, 1,  \
                            desc##a   \
)

// char diag='N' if needed.
#define DIAG "N"
#define trDISTRIBUTE( uplo, type, a, m, n) \
                  _tridistribute( &uplo,  \
                               DIAG,  \
                                type,  \
                                m, n,  \
                          global_##a,  \
                                1, 1,  \
                           desc_g##a,  \
                              loc##a,  \
                                1, 1,  \
                             desc##a   \
)


#define vDISTRIBUTE( rowcol, type, v, size) _vdistribute( rowcol, type, size, global_##v, loc##v)

#ifdef _DISTRIBUTE_1D_
#if defined(_REAL_DIAGONAL_) && defined(SCOMPLEX)
#define DIAG_TYPE "float"
#endif
#if defined(_REAL_DIAGONAL_) && defined(DCOMPLEX)
#define DIAG_TYPE "double"
#endif

#if defined(_REAL_DIAGONAL_)
#define tdDISTRIBUTE( type, dl, d, du, n) \
        _tddistribute( type,\
                  DIAG_TYPE,\
                       type,\
                          n,\
                global_##dl,\
                 global_##d,\
                global_##du,\
                        1,1,\
                desc_gtd##d,\
                    loc##dl,\
                     loc##d, \
                    loc##du, \
                        1,1, \
                  desctd##d \
)
#else
#define tdDISTRIBUTE( type, dl, d, du, n) \
        _tddistribute( type,\
                       type,\
                       type,\
                          n,\
                global_##dl,\
                 global_##d,\
                global_##du,\
                        1,1,\
                desc_gtd##d,\
                    loc##dl,\
                     loc##d, \
                    loc##du, \
                        1,1, \
                  desctd##d \
)
#endif
#endif

#ifdef _DISTRIBUTE_1D_

#define bandDISTRIBUTE( type, a, bwl, bwu, size) \
 _band_distribute(  type,                    \
		    size,                    \
		    bwl,                     \
		    bwu,                     \
		    (void*)global_##a,              \
		    desc_g##a,               \
		    (void*)loc##a,         \
		    desc##a,                 \
                    PIVOTING                   \
		    )

#endif


#endif
