import org.gridforum.gridrpc.*;
import ninf.basic.*;
import java.io.*;
import java.util.Vector;

public class MatGrpcTest{
  static boolean success = true;;
  static boolean verbose = false;

  static String[] parseMyArg(String arg[]){
    Vector tmpV = new Vector();
    int index = 0;
    for (int i = 0; i < arg.length; i++){
      if (arg[i].equalsIgnoreCase("-verbose"))
	verbose = true;
      else 
	tmpV.addElement(arg[i]);
    }
    String tmp[] = new String[tmpV.size()];
    for (int i = 0; i < tmpV.size(); i++)
      tmp[i] = (String)(tmpV.elementAt(i));
    return tmp;
  }
  public static void main(String args[]){
    int matsize = 103;
    args = parseMyArg(args);

    String config = args[0];
    if (args.length > 1)
      matsize = Integer.valueOf(args[1]).intValue();
    double a[][], b[][], c[][], c0[][];
    a = new double[matsize][matsize];
    b = new double[matsize][matsize];
    c = new double[matsize][matsize];
    c0 = new double[matsize][matsize];
    initMat(a, b);
    
    try {
      GrpcClient client =
	GrpcClientFactory.getClient("ninf.client.NinfGrpcClient");
      client.activate(config);

      GrpcHandle handle = client.getHandle("test/matmul");
      GrpcExecInfo info = handle.callWith(new Integer(matsize), a, b, c);
      handle.dispose();
      client.deactivate();
      if (verbose){System.out.println(info);}
    } catch (GrpcException e){
      if (verbose){System.out.println(e);}
      System.out.println(" failed");
      System.exit(3);
    }
    mmul(matsize, a, b, c0);
    if (!checkMat(c, c0))
      System.out.println("failed");
    System.out.println("OK");
  }

  static void initMat(double [][] a, double [][] b){
    int matsize = a.length;
    for (int i = 0; i < matsize; i++)
      for (int j = 0; j < matsize; j++){
	a[i][j] = 100.0; //i * matsize +j ; //Math.random();
	b[i][j] = i * matsize +j ;// Math.random();
      }
  }

  static boolean checkMat(double [][] c, double [][] c0){
    int matsize = c.length;
    for (int i = 0; i < matsize; i++)
      for (int j = 0; j < matsize; j++){
	if (c[i][j] != c0[i][j]){
	  System.out.println("c [" + i +"][" + j + "] =" +  c[i][j]);
	  System.out.println("c0[" + i +"][" + j + "] =" +  c0[i][j]);
	  return false;
	}
      }
    return true;
  }

  static void mmul(int N, double A[][], double B[][], double C[][]){
    double t;

    for (int i = 0; i < N; i++) {
      for (int j = 0; j < N; j++) {
	t = 0;
	for (int k = 0; k < N; k++){
	  t += A[i][k] * B[k][j];	/* inner product */
	}
	C[i][j] = t;
      }
    }
  }
}
