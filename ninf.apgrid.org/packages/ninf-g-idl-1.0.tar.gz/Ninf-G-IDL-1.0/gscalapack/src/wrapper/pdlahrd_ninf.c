#define _WRAPPER_
/* $Id: pdlahrd_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define DOUBLE
#include <gscalapack.h>

#define ROW_a lda
#define COL_a (n-k+1)
#define ROW_t ldt
#define COL_t nb
#define ROW_y ldy
#define COL_y n
static	int worklen(int n, int nb) {
	  int ret=1;
	  ret = n;
	  if NEED_BUFF {
	    ret = nb;
	  }
	  return ret;
}


void  pdlahrd_ninf(	 int n,
		 int k,
		 int nb,
		 double global_a[],
		 int lda,
		 double global_tau[],
		 double global_t[],
		 int ldt,
		 double global_y[],
		 int ldy
)
/* "pdlahrd reduces the first NB columns of a real general N-by-(N-K+1) distributed matrix A so that elements below the k-th subdiagonal are zero." */
/* OPTIONS */
{
	int maxldd;

	int maxlda;
	double *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
	int row_loca, col_loca;

	int maxldy;
	double *locy=NULL;
	int descy[DESCLEN];
	int desc_gy[DESCLEN];
	int row_locy, col_locy;

	double *loctau=NULL;

	int maxldt;
	double *loct=NULL;
	int desct[DESCLEN];
	int desc_gt[DESCLEN];
	int row_loct, col_loct;

	double *locwork=NULL;
	int llocwork;


	INITIALIZE();

	SCALAR( "int", n);
	SCALAR( "int", k);
	SCALAR( "int", nb);
	SCALAR("int", lda);
	SCALAR("int", ldt);
	SCALAR("int", ldy);

	ROW( a);
	COL( a);
	ROW(t);
	COL(t);
	ROW( y);
	COL( y);
	MAXLDD( maxldd, a );
	maxlda = maxldd;
	maxldt = maxldd;
	maxldy = maxldd;

	MATRIX( "double", a, ROW_a, COL_a);
	VECTOR("c", "double", tau, n-1);
	MATRIX( "double", t, ROW_t, COL_t);
	MATRIX( "double", y, ROW_y, COL_y);
	DISTRIBUTE( "double", a, ROW_a  , COL_a);

	llocwork = worklen(n, nb);
	WORK(locwork ,llocwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pdlahrd)( &n, &k, &nb,
                               loca, &one, &one, desca,
                               loctau,
                               loct,
                               locy, &one, &one, descy,
                               locwork);

	GATHER( "double", a, ROW_a  , COL_a);
	GATHER( "double", y, ROW_y  , COL_y);
	vGATHER( "c", "double", tau, n-1);
	GATHER( "double", t, ROW_t  , COL_t);

	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
	} else {
	}

	FREE_MATRIX(a);
	FREE_MATRIX(y);
	FREE_VECTOR(tau);
	FREE_MATRIX(t);
	FREE(locwork);
        
}

