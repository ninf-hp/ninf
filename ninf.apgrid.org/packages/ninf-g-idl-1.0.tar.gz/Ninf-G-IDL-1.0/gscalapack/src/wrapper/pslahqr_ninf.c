#define _WRAPPER_
/* $Id: pslahqr_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define FLOAT
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n
#define ROW_z ldz
#define COL_z n

static	int worklen(int n, int lda, int ldz) {
	  int ret=1;
	  int HBL;
	  ret = 3*n +
		  max( 2*max(ROW_a,ROW_z)
		       + 2*n, 7*n);
	  if NEED_BUFF {
	    HBL=max(rbloc, cbloc);
	    ret = 3*n +
	      max( 2*max(ROW_a,ROW_z)
		   + 2*LOCc(N), 7*ceil(n,HBL)/lcm(NPROW,NPCOL));
	  }
	  return ret;
}

static	int iworklen() {
	  int ret=1;
	  ret = 10;
	  return ret;
}


void  pslahqr_ninf(	 long wantt,
		 long wantz,
		 int n,
		 int ilo,
		 int ihi,
		 float a[],
		 int lda,
		 float wr[],
		 float wi[],
		 int iloz,
		 int ihiz,
		 float z[],
		 int ldz,
		 int *info
)
/* "pslahqr is an auxiliary routine used to find the Schur decomposition and or eigenvalues of a matrix already in Hessenberg form from cols ILO to IHI." */
/* OPTIONS */
{
extern void FortranCall(pslahqr)( long*, long*,
				  int*, int*, int*,
				  float*, int*,
				  float*, float*, int*, int*,
				  float*, int*,
				  float*, int*,
				  int*, int*,
				  int*);

	int maxldd;

	int desca[DESCLEN];

	int descz[DESCLEN];

	float *locwr=NULL, *locwi=NULL;

	float *locwork=NULL;
	int llocwork;
	int *lociwork=NULL;
	int llociwork;

	INITIALIZE();

	SCALAR( "long", wantt);
	SCALAR( "long", wantz);
	SCALAR( "int", n);
        SCALAR( "int", ilo);
	SCALAR( "int", ihi);
	SCALAR( "int", iloz);
	SCALAR( "int", ihiz);
	SCALAR( "int", lda);
	SCALAR( "int", ldz);

	COMMON_MATRIX("float", a, ROW_a, COL_a);
	Cdescinit(desca, ROW_a, COL_a, ROW_a, COL_a, 0, 0, PARA_CTXT,  ROW_a, &linfo);
	COMMON_MATRIX("float", z, ROW_z, COL_z);
	Cdescinit(descz, ROW_z, COL_z, ROW_z, COL_z, 0, 0, PARA_CTXT,  ROW_z, &linfo);

	locwr = MALLOC(sizeof(float)*n); assert(locwr);
	locwi = MALLOC(sizeof(float)*n); assert(locwi);

	llocwork = worklen(n,lda, ldz);
	WORK(locwork,llocwork);
	llociwork = iworklen();
	IWORK(lociwork,llociwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pslahqr)( &wantt, &wantz,
			       &n, &ilo, &ihi,
			       a, desca,
			       locwr, locwi, &iloz, &ihiz,
			       z, descz,
			       locwork, &llocwork,
			       lociwork, &llociwork,
			       &linfo);

	RETRIEVE("float", locwr, n);
	RETRIEVE("float", locwi, n);
	RETRIEVE("float", a, ROW_a*COL_a);
	RETRIEVE("float", z, ROW_z*COL_z);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
	  int i;
	  *info = linfo;
	  for(i=0;i<n;i++) wr[i] = locwr[i];
	  for(i=0;i<n;i++) wi[i] = locwi[i];
	} else {
	}
        FREE_COMMON(a);
        FREE_COMMON(z);

	FREE(locwr);
	FREE(locwi);
	FREE(locwork);
        FREE(lociwork);
        
}

