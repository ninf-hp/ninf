#define _WRAPPER_
/* $Id: psposvx_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define FLOAT
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n
#define ROW_af ldaf
#define COL_af n
#define ROW_b ldb
#define COL_b nrhs
#define ROW_x ldx
#define COL_x nrhs
#define NB cbloc
#define MB rbloc
#define LOCc_a(n) Cnumroc( (n), NB, mypcol, 0, npcol)
#define LOCr_a(m) Cnumroc( (m), MB, myprow, 0, nprow)
#define LOCc_b(n) Cnumroc( (n), NB, mypcol, 0, npcol)
#define LOCr_b(m) Cnumroc( (m), MB, myprow, 0, nprow)
static	int worklen(int n,int maxldd) {
	  int ret=1;
	  int pspocon,psporfs;
          pspocon = 2*n+2*n+max(2,2*n);
          psporfs = 3*n;
          ret = max(pspocon,psporfs)+COL_a;
          ret = max(ret,3*maxldd);
	  if NEED_BUFF {
	    pspocon = 2*LOCr(N+MOD(IA-1,MB_A)) + 2*LOCc(N+MOD(JA-1,NB_A))+
	      MAX( 2, MAX(NB_A*CEIL(NPROW-1,NPCOL),LOCc(N+MOD(JA-1,NB_A)) +
			  NB_A*CEIL(NPCOL-1,NPROW)) );
	    psporfs = 3*LOCr( N + MOD( IA-1, MB_A ) );

	    ret =  max( pspocon, psporfs) + LOCr_a(COL_a);
	    ret = max(ret, 3*maxldd);
	  }
	  return ret;
}

static	int iworklen(int n) {
	  int ret=1;
          ret = COL_a;
	  if NEED_BUFF {
	    ret = LOCr_a(COL_a);
	  }
	  return ret;
}


void  psposvx_ninf(	 char fact,
		 char uplo,
		 int n,
		 int nrhs,
		 float global_a[],
		 int lda,
		 float global_af[],
		 int ldaf,
		 char *equed,
		 float global_sr[],
		 float global_sc[],
		 float global_b[],
		 int ldb,
		 float global_x[],
		 int ldx,
		 float *rcond,
		 float global_ferr[],
		 float global_berr[],
		 float work[],
		 int global_work[],
		 int global_iwork[],
		 int *info
)
/* "psposvx uses the Cholesky factorization A = U**T*U or A = L*L**T to\\n compute the solution to a real system of linear equations\\n\\n        A(IA:IA+N-1,JA:JA+N-1) * X = B(IB:IB+N-1,JB:JB+NRHS-1),\\n\\n  where A(IA:IA+N-1,JA:JA+N-1) is an N-by-N matrix and X and\\n  B(IB:IB+N-1,JB:JB+NRHS-1) are N-by-NRHS matrices." */
/* OPTIONS */
{
    extern void FortranCall(psposvx)( char*, char*, int*, int*,
				      float*, int*, int*, int*,
				      float*, int*, int*, int*,
				      char*, float*, float*,
				      float*, int*, int*, int*,
				      float*, int*, int*, int*,
				      float*, float*, float*,
				      float*, int*,
				      int*, int*,
				      int*);

	int maxldd;

	int maxlda;
	float *loca;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];

	int maxldaf;
	float *locaf;
	int descaf[DESCLEN];
	int desc_gaf[DESCLEN];

	int maxldb;
	float *locb;
	int descb[DESCLEN];
	int desc_gb[DESCLEN];

	int maxldx;
	int descx[DESCLEN];
	int desc_gx[DESCLEN];
	float *locx;

        float *locsr;
        float *locsc;

	float locrcond[1];

	float *locferr;
	float *locberr;

        float *locwork;
	int llocwork;

        float *lociwork;
	int llociwork;

	int row_loca, col_loca;
	int row_locaf, col_locaf;
	int row_locb, col_locb;
	int row_locx, col_locx;

	INITIALIZE();

	SCALAR( "char", fact);
	SCALAR( "char", uplo);
	SCALAR( "int", n);
	SCALAR( "int", nrhs);
	SCALAR("int", lda);
	SCALAR( "int", ldaf);
	SCALAR( "int", ldb);
	SCALAR( "int", ldx);

	COMMON( "char", equed, 1);

	ROW( a);
	COL( a);
	ROW( af);
	COL( af);
	ROW( b);
	COL( b);
	ROW( x);
	COL( x);
	MAXLDD( maxldd, a);
	maxlda = maxldd;
	maxldaf = maxldd;
	maxldb = maxldd;
	maxldx = maxldd;

	MATRIX( "float", a, ROW_a, COL_a);
	MATRIX( "float", af, ROW_af, COL_af);
	MATRIX( "float", b, ROW_b, COL_b);
	MATRIX( "float", x, ROW_x, COL_x);
	VECTOR( "r", "float", sr, ROW_a);
	VECTOR( "c", "float", sc, COL_a);
	VECTOR( "c", "float", ferr, COL_b);
	VECTOR( "c", "float", berr, COL_b);

	DISTRIBUTE( "float", a, ROW_a  , COL_a);
	DISTRIBUTE( "float", b, ROW_b  , COL_b);
	vDISTRIBUTE( "r", "float", sr, ROW_a);
	vDISTRIBUTE( "c", "float", sc, COL_a);

        llocwork = worklen(n, maxldd);
        WORK(locwork, llocwork);
        llociwork = iworklen(n);
        IWORK(lociwork,llociwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	  FortranCall(psposvx)( &fact, &uplo, &n, &nrhs,
				loca, &one, &one, desca,
				locaf, &one, &one, descaf,
				equed, locsr, locsc,
				locb, &one, &one, descb,
				locx, &one, &one, descx,
				locrcond, locferr, locberr,
				locwork, &llocwork,
				lociwork, &llociwork,
				&linfo);

	GATHER( "float", a, ROW_a  , COL_a);
	GATHER( "float", af, ROW_af  , COL_af);
	GATHER( "float", b, ROW_b  , COL_b);
	GATHER( "float", x, ROW_x  , COL_x);

	vGATHER( "r", "float", sr, ROW_a);
	vGATHER( "c", "float", sc, COL_a);
	vGATHER( "c", "float", ferr, COL_b);
	vGATHER( "c", "float", berr, COL_b);

	RETRIEVE("float", locrcond, 1);
	RETRIEVE( "char", equed, 1);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
	  *info = linfo;
	  *rcond = *locrcond;
	} else {
	}

	FREE_COMMON(equed);
	FREE_MATRIX(a);
	FREE_MATRIX(af);
	FREE_MATRIX(b);
	FREE_MATRIX(x);
	FREE_VECTOR(sr);
	FREE_VECTOR(sc);
	FREE_VECTOR(ferr);
	FREE_VECTOR(berr);
	
}

