#define _WRAPPER_
/* $Id: pcgetf2_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define SCOMPLEX
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n
void  pcgetf2_ninf(	 int m,
		 int n,
		 scomplex global_a[],
		 int lda,
		 int global_ipiv[],
		 int *info
)
/* "pcgetf2 computes an LU factorization of a general M-by-N distributed matrix A using partial pivoting with row interchanges. The factorization has the form A = P * L * U, where P is a permutation matrix, L is lower triangular with unit diagonal elements (lower trapezoidal if m > n), and U is upper triangular (upper trapezoidal if m < n)." */
/* OPTIONS */
{
	int maxldd;

	int maxlda;
	scomplex *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
	int row_loca, col_loca;

	int *locipiv=NULL;

	INITIALIZE();

	SCALAR( "int", m);
	SCALAR( "int", n);
	SCALAR( "int", lda);

	ROW( a);
	COL( a);
	MAXLDD( maxldd, a );
	maxlda = maxldd;

	MATRIX( "scomplex", a, ROW_a, COL_a);
	DISTRIBUTE( "scomplex", a, ROW_a, COL_a);
	VECTOR("r", "int", ipiv, ROW_a);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pcgetf2)( &m, &n,
                               loca, &one, &one, desca,
                               locipiv,
                               &linfo);

	GATHER( "scomplex", a, ROW_a  , COL_a);
	vGATHER( "r", "int", ipiv, ROW_a);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
            *info = linfo;
	} else {
	}

	FREE_MATRIX(a);
	FREE_VECTOR(ipiv);
}

