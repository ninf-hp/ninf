#define _WRAPPER_
/* $Id: pslaswp_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define FLOAT
#include <gscalapack.h>

#define ROW_a  lda
#define COL_a n
void  pslaswp_ninf(	 char direc,
		 char rowcol,
		 int n,
		 float global_a[],
		 int lda,
		 int k1,
		 int k2,
		 int global_ipiv[],
		 int dummy_incx
)
/* "pslaswp performs a series of row or column interchanges on the distributed matrix A." */
/* OPTIONS */
{
	int maxldd;

	int maxlda;
	float *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
	int row_loca, col_loca;

	int *locipiv=NULL;

	INITIALIZE();

	SCALAR( "char", direc);
	SCALAR( "char", rowcol);
	SCALAR( "int", n);
	SCALAR("int", lda);

	SCALAR( "int", k1);
	SCALAR( "int", k2);

	ROW( a);
	COL( a);
	MAXLDD( maxldd, a );
	maxlda = maxldd;

	MATRIX( "float", a, ROW_a, COL_a);
	DISTRIBUTE( "float", a, ROW_a  , COL_a);
	if (chrcmp(rowcol,'R')==0) {
	  VECTOR( "r", "int", ipiv, ROW_a);
	  vDISTRIBUTE( "r", "int", ipiv, ROW_a);
	} else {
	  VECTOR( "c", "int", ipiv, ROW_a);
	  vDISTRIBUTE( "c", "int", ipiv, ROW_a);
	}

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pslaswp)( &direc, &rowcol,
                               &n,
                               loca, &one, &one, desca,
                               &k1, &k2,
                               locipiv);

	GATHER( "float", a, ROW_a, COL_a);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
	} else {
	}

	FREE_MATRIX(a);
	FREE_VECTOR(ipiv);
}

