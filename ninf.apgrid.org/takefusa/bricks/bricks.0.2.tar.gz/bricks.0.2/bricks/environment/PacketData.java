package bricks.environment;
import bricks.util.Format;
import java.util.*;

public class PacketData extends TrafficData {

    public PacketData(
	double dataSize, Vector listOfRoute, TrafficData originalData
    ) {
	this.processingDuration = 0.0;
	this.dataSize = dataSize;
	id = generateId();
	this.listOfRoute = listOfRoute;
	indexOfCurrentNode = 0;
	currentNode = (Node)listOfRoute.firstElement();
	this.originalData = originalData;
    }

/************************* needed method *************************/
    public String getName() {
	return "PacketData";
    }

    // override
    public Vector getSubList(double currentTime){
	return null;
    }
}
