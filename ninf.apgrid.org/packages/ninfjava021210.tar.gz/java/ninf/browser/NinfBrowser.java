package ninf.browser;

import java.io.*;
import java.awt.*;
import java.awt.event.*;
import java.applet.Applet ;

import ninf.client.*;
import ninf.basic.NinfException;
import ninf.basic.*;


public class NinfBrowser extends Applet implements Runnable {
    NinfQueryClient client;

    boolean   inbrowser = true;
    boolean   inpanel;
    TextField server_name;
    TextField server_port;
    Button    reload;

    List stub_list;
    TextField stub_name;
    TextArea param_info;
    TextArea description;
    Thread retriever;

    NinfStub stubs[];
    int selected_index;

    final static int N_ITEMS = 5;
    final static int WIDTH = 80;

    int port = 3000;
    String defaultServerHost = "localhost";

    public void init(){
	if (!inpanel) {
          defaultServerHost = getCodeBase().getHost();
	  if (defaultServerHost == null || 
	      defaultServerHost.equals("")) {
	      inbrowser = false;
	      String tmpHost = getParameter("host");
	      if (tmpHost != null)
		  defaultServerHost = tmpHost;
	      else
		  defaultServerHost = "localhost";
	  }
	  String portStr = getParameter("port");
	  if (portStr != null)
	      port = (new Integer(portStr)).intValue();
	} else {
	    inbrowser = false;
	}

	server_name = new TextField(30);
	server_name.setText(defaultServerHost);
	if (inbrowser)
	    server_name.setEditable(false);
	server_port = new TextField(10);
	server_port.setText("" + port);

	reload = new Button("Reload");

	/*	reload.addActionListener(this); */

	stub_list = new List(N_ITEMS);
	/*      stub_list.addActionListener(this); */

	stub_name = new TextField(30);
	stub_name.setEditable(false);

	param_info = new TextArea("",8,WIDTH,
				  TextArea.SCROLLBARS_VERTICAL_ONLY);
	param_info.setEditable(false);

	description = new TextArea("",8,WIDTH,TextArea.SCROLLBARS_BOTH);
	description.setEditable(false);

	/* setup panels */

	Panel topPanel = new Panel();
	topPanel.setLayout(new FlowLayout());
	topPanel.add(new Label("Server:"));
	topPanel.add(server_name);
	topPanel.add(new Label("Port"));
	topPanel.add(server_port);
	topPanel.add(reload);

	Panel underLeft = new Panel();
	double underLeftRatio[] = {0.5, 0.5};
	underLeft.setLayout(new RatioLayout(RatioLayout.VERTICAL, 
					    underLeftRatio));
	underLeft.add(new LabelPanel("Ninf Functions", stub_list));
	underLeft.add(new LabelPanel("Description", description));

	Panel underPanel = new Panel();
	double underRatio[] = {0.4, 0.6};
	underPanel.setLayout(new RatioLayout(RatioLayout.HORIZONTAL, 
					     underRatio));
	underPanel.add(underLeft);
	underPanel.add(new LabelPanel("Parameter Info", param_info));
	
	setLayout(new BorderLayout());
	add(underPanel, "Center");
	add(topPanel, "North");
    }

    public void run(){
	reload();
	retriever = null;
    }

    public void start(){
	if (retriever != null)
	    retriever.stop();
	retriever = new Thread(this);
	retriever.start();
    }

    void reload(){
	/* create QueryClient */
	try {
	  defaultServerHost = server_name.getText();
	  port = new Integer(server_port.getText()).intValue();

	  client = new NinfQueryClient(defaultServerHost,port);
	} catch(NinfException e){
	    System.err.println("an error occurred in constructor: " + e);
	    e.printStackTrace();
	}

	/* get stubs */
	try {
	    stubs = client.query("");
	} catch(NinfException e){
	    System.err.println("an error occurred in query: " + e);
	    e.printStackTrace();
	}
	stub_list.removeAll();
	for(int i = 0; i < stubs.length; i++){
	    stub_list.add(stubs[i].module_name+"/"+stubs[i].entry_name);
	}
    }

    /*
    public void actionPerformed(ActionEvent e){
	if(e.getSource() == stub_list){
	    selected_index = stub_list.getSelectedIndex();
	    NinfStub stub = stubs[selected_index];
	    stub_name.setText(stub.module_name+"/"+stub.entry_name);

	    StringBuffer tmp = new StringBuffer();
	    int pi = 0;
	    for(int i = 0; i < stub.nparam; i++, pi++) {
	      if (! stub.params[i].IS_FUNC())
		tmp.append("param["+pi+"] = "+ stub.params[i].toText(i) + "\n");
	      else {
		tmp.append("param["+pi+"] =   FUNC(");
		i++;
                if (i < stub.nparam && !stub.params[i].IS_FUNC())
		    tmp.append(stub.params[i].toText(i));
		i++;
                while (i < stub.nparam && !stub.params[i].IS_FUNC()){
		  tmp.append("\n                , ");
		  tmp.append(stub.params[i].toText(i));
		  i++;
		}
		tmp.append(")\n");
		if (i < stub.nparam)
		  i--;
	      }
	    }	    
	    if (stub.order_type == NinfVal.VALUE_BY_EXPR)
	      tmp.append("Calcuration Order: " + stub.order.toText());
	    param_info.setText(new String(tmp));

	    description.setText(stub.description);
	} 
	if (e.getSource() == reload){
	    start();
	}
    }
    */

    /** for 1.0 EventModel */
    public boolean action(Event e, Object Arg){
	if(e.target == stub_list){
	    selected_index = stub_list.getSelectedIndex();
	    NinfStub stub = stubs[selected_index];
	    stub_name.setText(stub.module_name+"/"+stub.entry_name);

	    StringBuffer tmp = new StringBuffer();
	    int pi = 0;
	    for(int i = 0; i < stub.nparam; i++, pi++) {
	      if (! stub.params[i].IS_FUNC())
		tmp.append("param["+pi+"] = "+ stub.params[i].toText(i) + "\n");
	      else {
		tmp.append("param["+pi+"] =   FUNC(");
		i++;
                if (i < stub.nparam && !stub.params[i].IS_FUNC())
		    tmp.append(stub.params[i].toText(i));
		i++;
                while (i < stub.nparam && !stub.params[i].IS_FUNC()){
		  tmp.append("\n                , ");
		  tmp.append(stub.params[i].toText(i));
		  i++;
		}
		tmp.append(")\n");
		if (i < stub.nparam)
		  i--;
	      }
	    }	    
	    if (stub.order_type == NinfVal.VALUE_BY_EXPR)
	      tmp.append("Calcuration Order: " + stub.order.toText());
	    param_info.setText(new String(tmp));

	    description.setText(stub.description);
	    return true;
	} 
	if (e.target == reload){
	    start();
	    return true;
	}
	return false;
    }


    public void stop(){

    }

    public static void main(String args[]){
	Frame f = new Frame("NinfBrower");
	NinfBrowser app = new NinfBrowser();
	app.inpanel = true;
	app.init();
	f.setSize(600, 400);
	f.add("Center",app);
	f.pack();
	f.show();
	app.start();
  }
}


