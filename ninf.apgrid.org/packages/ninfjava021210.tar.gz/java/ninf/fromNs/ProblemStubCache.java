package ninf.fromNs;
import ninf.basic.*;
import ninf.client.*;
import ninf.cproxy.*;
import ninf.netsolve.*;
import java.io.*;

class ProblemStubCache extends CallableCache {
  static NinfLog dbg = new NinfLog("ProblemStubCache");
  MetaServerReference metaServer;
  
  ProblemStubCache(MetaServerReference metaServer) throws NinfException{
    super();
    this.metaServer = metaServer;
    getProblemStubs();
  }

  void getProblemStubs() throws NinfException{
    StubRetrieve retrieve = new StubRetrieve(metaServer);
    NinfStub[] stubs = retrieve.getAllStubs();
    for (int i = 0; i < stubs.length; i++){
      Callable tmp;
      int index = getIndex();
      try {
	tmp = new ProblemStubCallable(stubs[i], index);
      } catch (NinfException e){
	dbg.log(stubs[i].getName() + " cannot be converted, is not registered.");
	continue;
      }
      dbg.log(tmp.getStub().getName() + " is registered.");
      registerCallable(tmp.getStub().getName(), tmp, index);
    }    
  }

}
