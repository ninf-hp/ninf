package bricks.environment;
import bricks.util.*;
import java.util.*;

public class EPClientCreator extends ComponentCreator {

    // for bricks.tools.ShowUsage
    public EPClientCreator() {}

    public EPClientCreator(
	SimulationSet owner, SubComponentFactory subComponentFactory
    ) {
	this.owner = owner;
	this.subComponentFactory = subComponentFactory;
    }

    public String usage() {
	return "EPClient <String key> <String keyOfScheduler> " +
	    "Requests(<Sequence numTasks>, " +
	    "<Sequence dataSizeForSend>, <Sequence dataSizeForRecv>" +
	    ", <Sequence numInstructions>, <Sqeuence interarrivalTime>" +
	    "(, <Strings dataIDs>, " +
	    "<Strings dataDestinations>, <Sequence deadlineFactors>)))";
    }

    public Node createNode(String str) throws BricksParseException {
	try {
	    StringTokenizer st = new StringTokenizer(str);
	    String tmp = st.nextToken(" \t(),"); // client
	    String key = st.nextToken(" \t(),");
	    String keyOfScheduler = st.nextToken(" \t");
	    tmp = st.nextToken(" \t(),"); // Requests
	    
	    Sequence numTasks = 
		(Sequence)subComponentFactory.create(st);
	    Sequence dataSizeForSend = 
		(Sequence)subComponentFactory.create(st);
	    Sequence dataSizeForReceive = 
		(Sequence)subComponentFactory.create(st);
	    Sequence numInstructions =
		(Sequence)subComponentFactory.create(st);
	    Sequence throwingInterval = 
		(Sequence)subComponentFactory.create(st);

	    EPClient client = new EPClient(
		owner, key, keyOfScheduler, numTasks, dataSizeForSend, 
		dataSizeForReceive, numInstructions, throwingInterval
	    );

	    if (st.hasMoreElements()) {
		Strings dataIDs = (Strings)subComponentFactory.create(st);
		if (dataIDs != null) {
		    // for RandomDataFragmentStrings
		    dataIDs.init(owner); 
		    client.setDataIDs(dataIDs);
		}
		Strings dataDestinations =
		    (Strings)subComponentFactory.create(st);
		if (dataDestinations != null) {
		    client.setDataDestinations(dataDestinations);
		}
		Sequence deadlineFactors = 
		    (Sequence)subComponentFactory.create(st);
		if (deadlineFactors != null) {
		    client.setDeadlineFactors(deadlineFactors);
		}
	    }
	    return client;

	} catch (NoSuchElementException e) {
	    e.printStackTrace();
	    throw new BricksParseException(usage());

	} catch (BricksParseException e) {
	    e.addMessage(usage());
	    throw e;
	}
    }
}
