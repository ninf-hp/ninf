package bricks.environment;
import bricks.util.*;
import java.util.*;

public class DiskCreator extends ComponentCreator {

    // for bricks.tools.ShowUsage
    public DiskCreator(){}

    public DiskCreator(
	SimulationSet owner, SubComponentFactory subComponentFactory
    ) {
	this.owner = owner;
	this.subComponentFactory = subComponentFactory;
    }

    public String usage() {
	return "Disk(<String key> <double diskSize> " + 
	    "<DataFragments preStoredDataFragments> <Queue queue> " +
	    "OthersData(<Sequence dataSize>, <Sqeuence interarrivalTime>))";
    }

    public Node createNode(String str) throws BricksParseException {
	SimulationDebug.println("create Disk...");
	try {
	    StringTokenizer st = new StringTokenizer(str);
	    String tmp = st.nextToken(" \t(),"); // disk
	    if (!st.hasMoreElements()) {
		return new NullDisk();
	    }
	    String key = st.nextToken(" \t(),");
	    double diskSize = 
		Double.valueOf(st.nextToken(" \t,()")).doubleValue();
	    DataFragments preStoredDataFragments = 
		(DataFragments)subComponentFactory.create(st);
	    Queue queue = (Queue)subComponentFactory.create(st);

	    tmp = st.nextToken(" \t(),"); // OthersData
	    Sequence dataSize = null;
	    Sequence interarrivalTime = null;
	    if (!tmp.equalsIgnoreCase("n/a")) {
		dataSize = (Sequence)subComponentFactory.create(
			st, (owner.logicalPacket).packetSize
		    );
		interarrivalTime = (Sequence)subComponentFactory.create(st);
	    }

	    return new Disk(
		owner, key, diskSize, preStoredDataFragments, 
		queue, dataSize, interarrivalTime
	    );

	} catch (NumberFormatException e) {
	    e.printStackTrace();
	    throw new BricksParseException(usage());

	} catch (NoSuchElementException e) {
	    e.printStackTrace();
	    throw new BricksParseException(usage());

	} catch (BricksParseException e) {
	    e.addMessage(usage());
	    throw e;
	}
    }
}
