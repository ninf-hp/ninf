package ninf.basic;

import java.net.*;

public class Util{
  
    public static String peerName(Socket s){
	return s.getInetAddress().toString();
    }
    public static String peerName(Socket s, boolean lookup){
	if (lookup)
	  return s.getInetAddress().getHostName();
	else
	  return s.getInetAddress().getHostAddress();
    }

}
