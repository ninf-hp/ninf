package ninf.scheduler;
import ninf.basic.*;

public class IncompleteScheduleException extends NinfException {
  
}

