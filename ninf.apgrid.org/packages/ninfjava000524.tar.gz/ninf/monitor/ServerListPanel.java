package ninf.monitor;
import java.awt.*;
import ninf.basic.*;
import ninf.common.*;
import ninf.client.*;
import ninf.metaserver.*;
import java.util.Hashtable;
import java.util.Vector;
import java.util.Enumeration;

public class ServerListPanel extends Panel {
  Monitor monitor;

  Font font = new Font("Helvetica", Font.BOLD, 10);
  
  List list;
  TextArea description;
  Button launch;
  ServerMonitor[] serverMonitors;
  
  ServerListPanel(Monitor monitor){
    this.monitor = monitor;
    this.setFont(font);
    this.setLayout(new BorderLayout());
    list = new List();
    list.setBackground(Color.white);
    Label label = new Label("SERVERS", Label.CENTER);
    label.setBackground(Color.darkGray);
    label.setForeground(Color.white);
    launch = new Button("launch");
    Panel launchPanel = new Panel();
    launchPanel.add(launch);
    launchPanel.setBackground(Color.darkGray);
    launch.setBackground(Color.lightGray);
    add("Center", list);
    add("North", label);
    add("South", launchPanel);
  }

  public void makeList(){
    serverMonitors = new ServerMonitor[monitor.serverMonitors.size()];
    int i = 0;
    Enumeration enum = monitor.serverMonitors.elements();
    list.clear();
    while (enum.hasMoreElements()){
      ServerMonitor tmp = (ServerMonitor)enum.nextElement();
      serverMonitors[i++] = tmp;
      list.addItem(tmp.holder.toString());
    }
  }
  
  void selectServers(FunctionName name){
    for (int i = 0; i < serverMonitors.length; i++)
      list.deselect(i);
    list.setMultipleSelections(true);
    for (int i = 0; i < serverMonitors.length; i++)
      if (serverMonitors[i].hasFunction(name))
	list.select(i);
  }

  void launch(){
    int[] selected = list.getSelectedIndexes();
    for (int i = 0; i < selected.length; i++)
      monitor.launch(serverMonitors[selected[i]].holder.struct);
  }

  public boolean action(Event evt, Object arg){
    if (evt.target == launch){
      launch();
      return true;
    }
    if (evt.target == list){         
      int selected = list.getSelectedIndex();
      System.out.println("list selected " + selected);
      for (int i = 0; i < serverMonitors.length; i++)
	list.deselect(i);
      list.setMultipleSelections(false);
      if (selected < 0 || selected >= serverMonitors.length)
	return true;
      list.select(selected);
      serverMonitors[selected].selectFuncs();
      return true;
    }
    return false;  
  }


  


}
