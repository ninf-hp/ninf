package bricks.scheduling;
import bricks.util.*;
import bricks.environment.*;
import java.util.*;
import java.io.*;

public class AccessBoundReplicaManager extends ReplicaManager implements SchedulingUnit {

    protected double minAccessScore;

    public AccessBoundReplicaManager(
	String keyOfResourceDB, String keyOfServerMonitor, 
	Sequence interEvaluationTime, double compactness, 
	double minAccessScore, double overstoredDiskRate
    ) {
	super(keyOfResourceDB, keyOfServerMonitor, 
	      interEvaluationTime, compactness, overstoredDiskRate);
	this.minAccessScore = minAccessScore;
    }


/************************* needed method *************************/
    public String getName() {
	return "AccessBoundReplicaManager";
    }

    // implement replication strategies
    public void processEvent(double currentTime) {
	if (!doneGC(currentTime))
	    replicate(currentTime);
    }

    protected boolean haveToReplicate(
	Host host, StaticHostInfo staticInfo, HostInfo info,
	Vector scoresOfSource, Vector scoresOfDestination
    ) {
	boolean replicate = false;
	double score = staticInfo.performance / (info.numAccesses + 1.0);
	if (staticInfo.performance > minAccessScore &&
	    info.numAccesses > 1.0 && score < minAccessScore) {
	    scoresOfSource.add(new Score(host, score));
	    replicate = true;
	} else {
	    scoresOfDestination.add(new Score(host, score));
	}
	SimulationDebug.println(
	    "score = " + score + ", minAccessScore = " + minAccessScore);
	return replicate;
    }
}
