#define _WRAPPER_
/* $Id: psporfs_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define FLOAT
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n
#define ROW_af ldaf
#define COL_af n
#define ROW_b ldb
#define COL_b nrhs
#define ROW_x ldx
#define COL_x nrhs
static	int worklen(int n) {
	  int ret=1;
	  ret = 3*n;
	  if NEED_BUFF {
              ret =  3*LOCr( N + MOD( IA-1, MB_A ) );
          }
	  return ret;
}

static	int iworklen(int n) {
	  int ret=1;
	  ret = n;
	  if NEED_BUFF {
              ret = LOCr( N + MOD( IB-1, MB_B ) );
          }
	  return ret;
}

void  psporfs_ninf(	 char uplo,
		 int n,
		 int nrhs,
		 float global_a[],
		 int lda,
		 float global_af[],
		 int ldaf,
		 float global_b[],
		 int ldb,
		 float global_x[],
		 int ldx,
		 float global_ferr[],
		 float global_berr[],
		 float work[],
		 int iwork[],
		 int *info
)
/* "psporfs improves the computed solution to a system of linear equations when the coefficient matrix is symmetric positive definite and provides error bounds and backward error estimates for the solutions." */
/* OPTIONS */
{
	int maxldd;

	int maxlda;
	float *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
	int row_loca, col_loca;

	int maxldaf;
	float *locaf=NULL;
	int descaf[DESCLEN];
	int desc_gaf[DESCLEN];
	int row_locaf, col_locaf;

	int maxldb;
	float *locb=NULL;
	int descb[DESCLEN];
	int desc_gb[DESCLEN];
	int row_locb, col_locb;

	int maxldx;
	float *locx=NULL;
	int descx[DESCLEN];
	int desc_gx[DESCLEN];
	int row_locx, col_locx;

	float *locferr=NULL;
	float *locberr=NULL;

	float *locwork=NULL;
	int llocwork;
	float *lociwork=NULL;
	int llociwork;


	INITIALIZE();

	SCALAR( "char", uplo);
	SCALAR( "int", n);
	SCALAR( "int", nrhs);
        SCALAR( "int", lda);
        SCALAR("int", ldaf);
        SCALAR("int", ldb);
        SCALAR("int", ldx);

	ROW( a);
	COL( a);
	ROW( af);
	COL( af);
	ROW( b);
	COL( b);
	ROW( x);
	COL( x);
	MAXLDD( maxldd, a );
	maxlda = maxldd;
	maxldaf = maxldd;
	maxldb = maxldd;
	maxldx = maxldd;

	MATRIX( "float", a, ROW_a, COL_a);
	MATRIX( "float", af, ROW_af, COL_af);
	MATRIX( "float", b, ROW_b, COL_b);
	MATRIX( "float", x, ROW_x, COL_x);
	VECTOR( "c", "float", ferr, nrhs);
	VECTOR( "c", "float", berr, nrhs);
	DISTRIBUTE( "float", a, ROW_a  , COL_a);
	DISTRIBUTE( "float", af, ROW_af  , COL_af);
	DISTRIBUTE( "float", b, ROW_b  , COL_b);
	DISTRIBUTE( "float", x, ROW_x  , COL_x);

	llocwork=worklen(n);
	WORK(locwork,llocwork);
	llociwork=iworklen(n);
	WORK(lociwork,llociwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(psporfs)( &uplo, &n, &nrhs,
                               loca, &one, &one, desca,
                               locaf, &one, &one, descaf,
                               locb, &one, &one, descb,
                               locx, &one, &one, descx,
                               locferr, locberr,
                               locwork, &llocwork,
                               lociwork, &llociwork,
                               &linfo);

	GATHER( "float", x, ROW_x, COL_x);
	vGATHER( "c", "float", ferr, nrhs);
	vGATHER( "c", "float", berr, nrhs);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
		*info = linfo;
	} else {
		
	}

	FREE_MATRIX(a);
	FREE_MATRIX(af);
	FREE_MATRIX(b);
	FREE_MATRIX(x);
        FREE(locwork);
        FREE(lociwork);
	
}

