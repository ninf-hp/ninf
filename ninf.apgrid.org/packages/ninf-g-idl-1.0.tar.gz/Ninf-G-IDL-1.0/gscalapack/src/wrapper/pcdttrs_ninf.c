#define _WRAPPER_
/* $Id: pcdttrs_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define SCOMPLEX
#define _DISTRIBUTE_1D_
#include <gscalapack.h>

#define ROW_b ldb
#define COL_b nrhs
#define ROW_af laf
#define COL_af n
static	int worklen(int nrhs) {
	  int ret=1;
	  ret = 10+4*nrhs;
	  if NEED_BUFF {
	    ret = 10*npcol+4*nrhs;
	  }
	  return ret;
}

void  pcdttrs_ninf(	 char trans,
		 int n,
		 int nrhs,
		 scomplex global_dl[],
		 scomplex global_d[],
		 scomplex global_du[],
		 scomplex global_b[],
		 int ldb,
		 scomplex af[],
		 int dummy_laf,
		 scomplex work[],
		 int lwork,
		 int *info
)
/* " pcdttrs solves a system of linear equations A * X = B or A' * X = B where A is the matrix used to produce the factors stored in A and AF by PCDTTRF.  A is an N-by-N complex tridiagonal diagonally dominant-like distributed matrix.  Routine PCDTTRF MUST be called first." */
/* OPTIONS */
{
extern void FortranCall(pcdttrs)( char*, int*, int*,
                               scomplex*, int*, int*, int*, int*,
                               scomplex*, int*, int*,
                               scomplex*, int*,
                               scomplex*, int*, int*);

	int maxldd;
	scomplex *locdl=NULL, *locd=NULL, *locdu=NULL;
	int desctdd[DESCLEN];
	int desc_gtdd[DESCLEN];

	scomplex *locb=NULL;
	int descb[DESCLEN];
	int desc_gb[DESCLEN];
	int row_locb, col_locb;
	int maxldb;

	scomplex *locaf=NULL,*global_af=NULL;
	int maxldaf;
	int descaf[DESCLEN];
	int desc_gaf[DESCLEN];
	int laf, llocaf;
	int row_locaf, col_locaf;
	
	scomplex *locwork=NULL;
	int llocwork;

	INITIALIZE();

	SCALAR( "char", trans);
	SCALAR( "int", n);
	SCALAR( "int", nrhs);
	SCALAR("int", dummy_laf);
	SCALAR( "int", lwork);

	SIZE(n);

	laf = 2*(blocsize+2)*nprocs/n;
	llocaf = laf*blocsize;
	if (mypnum==0) {
	  global_af=MALLOC(sizeof(float)*laf*n);
          assert(global_af);
	}

	ROW(b);
	COL(b);
	ROW(af);
	COL(af);
	MAXLDD( maxldd, b);
	maxldb=maxldd;
	maxldaf=maxldd;

	tdMATRIX( "scomplex", dl, d, du, n);
	MATRIX( "scomplex", b, ROW_b, COL_b);
	MATRIX( "scomplex", af, ROW_af, COL_af);
	tdDISTRIBUTE( "scomplex", dl, d, du, n);
	DISTRIBUTE( "scomplex", b, ROW_b, COL_b);

	llocwork = worklen(nrhs);
        llocwork = max(llocwork,lwork);
	WORK(locwork,llocwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pcdttrs)( &trans, &n, &nrhs,
                               locdl, locd, locdu, &one, desctdd,
                               locb, &one, descb,
                               locaf, &llocaf,
                               locwork, &llocwork, &linfo);

	tdGATHER( "scomplex", dl, d, du, n);
	GATHER( "scomplex", b, ROW_b, COL_b);
	GATHER( "scomplex", af, ROW_af, COL_af);

	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
	  int i;
	  *info = linfo;
	  for(i=0;i<min(dummy_laf,laf*n);i++) af[i] = global_af[i];
          FREE(global_af);
	} else {
	}

        FREE_MATRIX(dl);
        FREE_MATRIX(d);
        FREE_MATRIX(du);
        FREE_MATRIX(b);
        FREE_MATRIX(af);

        FREE(locwork);
}

