package org.gridforum.gridrpc;
import java.util.Properties;

public interface GrpcClient{

  /** initializes a Grpc Client */
  void activate(String propertiesFilename) throws GrpcException;

  /** initializes a Grpc Client */
  void activate(Properties prop) throws GrpcException;

  /** Create a GrpcHandler instance using specified properties
    and returns it. */
  GrpcHandle getHandle(String functionName, Properties prop) 
       throws GrpcException;
       
  /** Create a default GrpcHandler and returns */
  GrpcHandle getHandle(String functionName)       throws GrpcException;
       
  /** finalize a Client */
  void deactivate() throws GrpcException;
      
}
