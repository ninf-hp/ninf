package bricks.scheduling;
import bricks.environment.*;
import bricks.util.*;
import java.util.*;

public class LoadIntensiveScheduler extends Scheduler implements SchedulingUnit {

    public LoadIntensiveScheduler(String keyOfMetaPredictor) {
	this.keyOfMetaPredictor = keyOfMetaPredictor;
	schedulingOverhead = 0.0;
    }

/************************* needed method *************************/
    public String getName() {
	return "LoadIntensiveScheduler";
    }

    public void selectHosts (
	double currentTime, Host source, RequestedData data
    ) throws BricksNotScheduledException {
	double minScore = Double.POSITIVE_INFINITY;
	double maxScore = -1.0;
	Host selectedHost = null;
	Enumeration e = resourceDB.hosts(data);

	while (e.hasMoreElements()) {
	    Host host = (Host)e.nextElement();
	    HostInfo hostInfo = metaPredictor.getHostInfo(currentTime, host);

	    StaticHostInfo info = resourceDB.getStaticHostInfo(host);
	    double performance = info.performance;

	    if (hostInfo.availableCpu < 0.0) {
		double score = hostInfo.loadAverage / performance;
		if (minScore > score) {
		    minScore = score;
		    selectedHost = host;
		}
		SimulationDebug.println(hostInfo.toString());
		SimulationDebug.println("bandwidth = " + performance);
		SimulationDebug.println(host + " : load score = " + score);
	    } else {  // NWS
		double score = hostInfo.availableCpu * performance;
		if (maxScore < score) {
		    maxScore = score;
		    selectedHost = host;
		}
	    }
	}
	if (selectedHost == null)
	    throw new BricksNotScheduledException(this.toString());

	//debug
	SimulationDebug.primaryPrintln(
	    "LoadIntensiveScheduler : select " + selectedHost
	);
	updateStatus(currentTime, source, selectedHost, data);
    }
}

