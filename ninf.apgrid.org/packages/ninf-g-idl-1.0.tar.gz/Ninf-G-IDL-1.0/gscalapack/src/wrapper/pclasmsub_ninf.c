#define _WRAPPER_
/* $Id: pclasmsub_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define SCOMPLEX
#include <gscalapack.h>
#error
#define ROW_a lda
#define COL_a n
static	int worklen(int n) {
	  int ret=1;
	  int HBL;
	  ret = 2*n;
	  if NEED_BUFF {
	    HBL = rbloc;
	    ret =  2*ceil( ceil( (I-L),HBL ) ,  LCM(NPROW,NPCOL) );
	    // Here LCM is least common multiple, and NPROWxNPCOL is the
	    // logical grid size.
	  }
	  return ret;
}

void  pclasmsub_ninf(
		  scomplex a[]
		  int lda,
		  int n,
		  int i,
		  int l,
		  int *k,
		  float smlnum,
		  float work[],
		  int lwork

)
/* "pclasmsub looks for a small subdiagonal element from the bottom of the matrix that it can safely set to zero." */
/* OPTIONS */
{

	int maxldd;

	int desca[DESCLEN];

	int lock;

	scomplex *locwork=NULL;
	int llocwork;

	INITIALIZE();

	SCALAR( "int", i);
	SCALAR( "int", l);
	SCALAR( "float", smlnum);
	SCALAR("int",lda);
	SCALAR("int",n);
	SCALAR("int",lwork);

	COMMON_MATRIX("scomplex", a, ROW_a, COL_a);
	Cdescinit( desca, ROW_a, COL_a, ROW_a, COL_a, 0, 0, PARA_CTXT, ROW_a, &linfo);

	llocwork = worklen(n);
	llocwork = max( lwork, llocwork);
	WORK(locwork,llocwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pclasmsub)( a, desca,
				 &i, &l, &lock, &smlnum,
				 locwork, &llocwork);

	//	RETRIEVE("float", locwork, llocwork);
	RETRIEVE("int", &lock, 1);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
	  *info = linfo;
	  *k = lock;
	} else {
	}
	FREE_COMMON(a);
	FREE(locwork);
}

