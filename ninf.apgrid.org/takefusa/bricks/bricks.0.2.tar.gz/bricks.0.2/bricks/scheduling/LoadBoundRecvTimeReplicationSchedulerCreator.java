package bricks.scheduling;
import bricks.util.*;
import java.util.*;

public class LoadBoundRecvTimeReplicationSchedulerCreator extends SchedulingUnitCreator {

    public String usage() {
	return "LoadBoundRecvTimeReplicationScheduler(<String keyOfPredictor>, <String keyOfReplicaManager>, <String keyOfServerMonitor>, <double minLoadScore(=performance/(load+1))>)";
    }

    public SchedulingUnit create(StringTokenizer st) 
	throws BricksParseException 
    {
	try {
	    String keyOfMetaPredictor = st.nextToken(" \t,()");
	    String keyOfReplicaManager = st.nextToken(" \t,()");
	    String keyOfServerMonitor = st.nextToken(" \t,()");
	    double minLoadScore = 
		Double.valueOf(st.nextToken(" \t,()")).doubleValue();

	    return new LoadBoundRecvTimeReplicationScheduler(
		keyOfMetaPredictor, keyOfReplicaManager, 
		keyOfServerMonitor, minLoadScore
	    );

	} catch (NoSuchElementException e) {
	    e.printStackTrace();
	    throw new BricksParseException(usage());

	} catch (NumberFormatException e) {
	    e.printStackTrace();
	    throw new BricksParseException(usage());
	}
    }
}

