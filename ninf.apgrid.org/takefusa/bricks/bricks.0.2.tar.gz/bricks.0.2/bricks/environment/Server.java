package bricks.environment;
import bricks.util.*;
import java.io.*;
import java.util.*;

/** 
 * Server.java
 * <pre>
 * Server represents the host machine function which represents 
 * computational resources of the given Grid computing system, 
 * and is parameterized by e.g., performance, load, and
 * their variance over time.
 * The data injected by Server are decomposed into logical packets.
 * </pre>
 */
public class Server extends NodeWithQueue {

    /** 
     * The number of executed Instructions invoked by other users.
     */
    protected Sequence numInstructions;

    protected RingBuffer traceBuffer;
    protected Host host;

    /**
     * Constructor for NullServer.
     */
    public Server() {;}

    /**
     * Constructs a Server with
     *     owner : a SimulationSet of your configuration,
     *     key : a key of the Server,
     *     queue : a queue which represents performance, congestion, and
     *             their variance of the Server,
     *     numInstructions : numInstructions of the Server,
     *     interarrivalTime : The interval that the Server invokes 
     *                        extraneous jobs.
     */
    public Server(
	SimulationSet owner, String key, Queue queue,
	Sequence numInstructions, Sequence interarrivalTime
    ){
	this.owner = owner;
	this.key = key;
	this.queue = queue;
	queue.owner = this;
	this.numInstructions = numInstructions;
	this.interarrivalTime = interarrivalTime;
	this.logWriter = owner.serverLogWriter;
	traceBuffer = new RingBuffer(1024);
	init();
    }

    /**
     * Constructs a Server with
     *     traceBufferSize : the size of the trace buffer.
     */
    public Server(
	SimulationSet owner, String key, Queue queue,
	Sequence numInstructions, Sequence interarrivalTime,
	int traceBufferSize
    ){
	this.owner = owner;
	this.key = key;
	this.queue = queue;
	queue.owner = this;
	this.numInstructions = numInstructions;
	this.interarrivalTime = interarrivalTime;
	logWriter = owner.serverLogWriter;
	traceBuffer = new RingBuffer(traceBufferSize);
	init();
    }

/************************* needed method *************************/
    /** 
     * returns a type of the Server.
     */
    public String getName() {
	return "Server";
    }

    /**
     * sets host.
     */
    public void setHost(Host host) {
	this.host = host;
    }

    /** 
     * processEvent
     *     SEND : sends a processed job.
     *     QUEUE : processes queue event.
     *     OTHERSDATA : puts extraneous job into queue of the Server.
     */
    public void processEvent(double currentTime) {

	if (event == QUEUE) {
	    SimulationDebug.println(Format.format(currentTime, precision) +
				    " " + this + " 's event = QUEUE");
	    
	    Data top = queue.top();
	    // processEvent of servedJob
	    if (queue.processEventForPackets(currentTime)) {
		if (top instanceof TrafficData)
		    host.sendData(currentTime, (TrafficData)top);
		outQueueLength(currentTime, queue.size());
	    }
	    
	} else { // OthersData
	    // get OthersData from comingEventList
	    if (!queue.isFull()) {
		schedule(currentTime, nextData);
	    }
	    nextData = getNextData(currentTime);
	}
    }

    /**
     * updateNextEvent finds next event which occurs earliest.
     **/
    public void updateNextEvent(double currentTime) {
	event = OTHERSDATA;
	double earliestTime = nextData.timeEventComes;

	if (!queue.isEmpty()) {
	    if (queue.getTimeQueueEventComes() < earliestTime) {
		earliestTime = queue.getTimeQueueEventComes();
		event = QUEUE;
	    }
	}
	nextEventTime = earliestTime;
    }

    public String toInitString() {
	String str = "  [" + getName() + " " + key + "] : ";
	str += queue.getName() + ", " + 
	    numInstructions.mean + ", " + interarrivalTime.mean + "\n";
	str += queue.toOriginalString();
	return str;
    }

/************************* public method *************************/
    /**
     * returns StaticHostInfo at First
     */
    public StaticHostInfo getStaticHostInfo() {
	return new StaticHostInfo(host, queue.maxThroughput);
    }

    /** 
     * returns HostInfo that denotes current status of the Server.
     */
    public HostInfo getHostInfo(double currentTime, double trackingTime) {

	int index = 0;
	double busyTime = 0;
	double load = 0;
	double previousTime = currentTime;

	//System.out.println("traceBuffer.size = " + traceBuffer.size());
	for (int i = 0 ; i < traceBuffer.size() ; i++) {
	    ServerTrace serverTrace = (ServerTrace)traceBuffer.get(i);
	    if (serverTrace == null) {
		break;
	    }
	    if (!serverTrace.idle) {
		busyTime = busyTime + previousTime - serverTrace.time;
	    }
	    load = load + (double)serverTrace.queueLength * 
		(previousTime - serverTrace.time);
	    previousTime = serverTrace.time;

	    if (currentTime - previousTime >= trackingTime) {
		break;
	    }
	}

	if (currentTime == previousTime) {
	    load = 0.0;
	    busyTime = 0.0;
	} else {
	    load = load / (currentTime - previousTime);
	    busyTime = busyTime / (currentTime - previousTime);
	}

	if (queue.isInterpolationCpu()) {
	    load = queue.getLoad(currentTime, trackingTime) + load;
	    busyTime = queue.getCpuUtilization(currentTime, trackingTime) + 
		busyTime;
	    if (busyTime > 1.0) {
		busyTime = 1.0;
	    }
	}

	return new HostInfo(host, currentTime, trackingTime, load, busyTime);
    }

/************************* protected method *************************/
    protected void trace(double currentTime, boolean idle, int length){
	ServerTrace serverTrace = new ServerTrace(currentTime, idle, length);
	traceBuffer.put(serverTrace);
    }

    // override
    protected Data getNextData(double currentTime) {
	if (this.interarrivalTime != null) {
	    double timeEventComes = 
		currentTime + interarrivalTime.nextDouble(currentTime);
	    return new OthersData(
		this, timeEventComes, numInstructions.nextDouble(currentTime)
	    );
	} else {
	    return new OthersData(this, Double.POSITIVE_INFINITY, 0);
	}
    }

    // override
    protected void printLog(double currentTime, String log) {
	super.printLog(currentTime, log);
	trace(currentTime, queue.isEmpty(), queue.size());
    }
}
