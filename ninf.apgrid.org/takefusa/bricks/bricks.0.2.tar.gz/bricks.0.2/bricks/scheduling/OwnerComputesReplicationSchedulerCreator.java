package bricks.scheduling;
import bricks.util.*;
import java.util.*;

public class OwnerComputesReplicationSchedulerCreator extends SchedulingUnitCreator {

    public String usage() {
	return "OwnerComputesReplicationScheduler(<String keyOfPredictor>, <String keyOfReplicaManager>, <String keyOfServerMonitor>, <double maxLoad>)";
    }

    public SchedulingUnit create(StringTokenizer st) 
	throws BricksParseException 
    {
	try {
	    String keyOfMetaPredictor = st.nextToken(" \t,()");
	    String keyOfReplicaManager = st.nextToken(" \t,()");
	    String keyOfServerMonitor = st.nextToken(" \t,()");
	    double maxLoad = 
		Double.valueOf(st.nextToken(" \t,()")).doubleValue();
	    return new OwnerComputesReplicationScheduler(
		keyOfMetaPredictor, keyOfReplicaManager, 
		keyOfServerMonitor, maxLoad
	    );

	} catch (NoSuchElementException e) {
	    e.printStackTrace();
	    throw new BricksParseException(usage());

	} catch (NumberFormatException e) {
	    e.printStackTrace();
	    throw new BricksParseException(usage());
	}
    }
}

