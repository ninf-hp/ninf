#ifndef __NINF_GROUP_H__
#define __NINF_GROUP_H__

#include "session.h"
#include "nslib_utils.h"

/********************** NINF_GROUP_HOST *******************/
typedef struct {
  char * hostname;
  int    port;
} ninf_group_host_t;

ninf_group_host_t * 
        ninf_group_host_new(char * hostname, int port);
void    ninf_group_host_destruct (ninf_group_host_t * host);
boolean ninf_group_host_compare  (ninf_group_host_t *, ninf_group_host_t *);

typedef nslib_list_t * (* get_host_list_func)();

/********************** NINF_HOST_MANAGER *******************/
typedef struct {
  ninf_group_host_t    host;
  char *               entry;
  _Ninf_executable_t * exe;
  int                  sessionID;
  ninf_session       * session;
  boolean valid;       /* FALSE if it should not be used any more */

} ninf_host_manager_t;

ninf_host_manager_t * 
        ninf_host_manager_new(ninf_group_host_t * host, char * entry);
void    ninf_host_manager_destruct  (ninf_host_manager_t * manager);
void    ninf_host_manager_invalidate(ninf_host_manager_t * manager);
boolean ninf_host_manager_connect   (ninf_host_manager_t * manager);
void    ninf_host_manager_print     (ninf_host_manager_t * manager, FILE * fp);


typedef struct {
  char * entry;
  nslib_list_t * managers;
  nslib_map_t *  session_manager_map;
} _ninf_group_t;

_ninf_group_t * 
        ninf_group_new(char * entry);
void    ninf_group_remove_manager(_ninf_group_t *, ninf_host_manager_t *);

#endif


