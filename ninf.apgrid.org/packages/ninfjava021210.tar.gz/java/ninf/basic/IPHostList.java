package ninf.basic;

import java.util.*;
import java.net.Socket;

/** to represent host restriction based on IPAddress List*/
public class IPHostList{
  private Vector vec = new Vector();

  public void addHost(String addr, String mask) throws NinfException{
    vec.addElement(new IPHosts(addr, mask));
  }

  public boolean isAllowed(Socket s){
    return isAllowed(s.getInetAddress().getAddress());
  }

  public boolean isAllowed(byte [] addr){
    for (int i = 0; i < vec.size(); i++){
      if (((IPHosts)(vec.elementAt(i))).includes(addr))
	return true;
    }
    return false;
  }
  public Enumeration elements(){
    return vec.elements();
  }
}
