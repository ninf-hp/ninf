#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>

#include "ninf_stub_info.h"
#include "ninf_data_trans.h"
#include "dataflow.h"

char * myalloc(int size);
extern int ninf_debug_flag;

static int data_serial = 0;
static int func_serial = 0;
static func_node_list * Funclist = NULL;
static data_node_list * Datalist = NULL;

void free_func_node(func_node * n){
  free(n);
}
void free_data_node(data_node * n){
  free(n);
}

void free_func_node_list(func_node_list * l){
  if (l->func != NULL)
    free_func_node(l->func);
  if (l->next != NULL)
    free_func_node_list(l->next);
  free(l);
}

void free_data_node_list(data_node_list * l){
  if (l->data != NULL)
    free_data_node(l->data);
  if (l->next != NULL)
    free_data_node_list(l->next);
  free(l);
}

data_node * new_data_node(void * d){
  data_node * tmp = (data_node *)myalloc(sizeof(data_node));
  tmp->dataaddr = d;
  tmp->input = NULL;
  tmp->outputs = NULL;
  tmp->serial = data_serial++;
  return tmp;
}

func_node * new_func_node(NINF_STUB_INFO * info, int inum, int onum){
  func_node * tmp = (func_node *)myalloc(sizeof(func_node));
  tmp->info = info;
  tmp->input_nums = inum;
  tmp->output_nums = onum;  
  tmp->args =  (data_wrapper **)myalloc(sizeof(data_wrapper *) * (info->nparam));
  
/*  tmp->inputs  = (data_node **)myalloc(sizeof(data_node *) *inum);
  tmp->outputs = (data_node **)myalloc(sizeof(data_node *) *onum);
*/
  tmp->serial = func_serial++;
  return tmp;
}


data_node_list *  new_data_node_list(data_node * d, data_node_list * n){
  data_node_list * tmp = (data_node_list *)myalloc(sizeof(data_node_list));
  tmp->data = d;
  tmp->next = n;
  return tmp;
}

func_node_list *  new_func_node_list(func_node * d, func_node_list * n){
  func_node_list * tmp = (func_node_list *)myalloc(sizeof(func_node_list));
  tmp->func = d;
  tmp->next = n;
  return tmp;
}

arg_pos *  new_arg_pos(func_node * d, int i, arg_pos * n){
  arg_pos * tmp = (arg_pos *)myalloc(sizeof(arg_pos));
  tmp->func = d;
  tmp->argnum = i;
  tmp->next = n;
  return tmp;
}

void add_data_node(data_node * d){
  data_node_list * tmp = Datalist;
  if (tmp == NULL){
    Datalist = new_data_node_list(d, NULL);
  } else {
    while (tmp->next != NULL)
      tmp = tmp->next;
    tmp->next = new_data_node_list(d, NULL);
  }
}

void add_func_node_sub(func_node * d, func_node_list ** listp){
  func_node_list * tmp = *listp;
  if (*listp == NULL){
    *listp = new_func_node_list(d, NULL);
  } else {
    while (tmp->next != NULL)
      tmp = tmp->next;
    tmp->next = new_func_node_list(d, NULL);
  }
}

void add_func_node(func_node * d){
  add_func_node_sub(d, &Funclist);
}

void dump_func_node(func_node * t){
  int i;
  fprintf(stderr, "%d: %s\n", t->serial, t->info->entry_name);
  fprintf(stderr, "\tinputs:\t");
  for (i = 0; i < t->info->nparam; i++){
    if ((*(t->args + i))->io_flag == MODE_IN)
      fprintf(stderr, "%d ",(*(t->args + i))->data->serial);
  }
  fprintf(stderr, "\n");
  fprintf(stderr, "\toutputs:\t");
  for (i = 0; i < t->info->nparam; i++){
    if ((*(t->args + i))->io_flag == MODE_OUT)
      fprintf(stderr, "%d ",(*(t->args + i))->data->serial);
  }
  fprintf(stderr, "\n");
}

int func_node_list_length(){
  int i = 0;
  func_node_list * tmp = Funclist;
  while (tmp != NULL){
    i++;
    tmp = tmp->next;
  }
  return i;
}

void dump_func_node_list(){
  func_node_list * tmp = Funclist;
  while (tmp != NULL){
    dump_func_node(tmp->func);
    tmp = tmp->next;
  }
}


data_node * get_data_node(void * d){
  data_node_list * tmp = Datalist;
  data_node * dnode;
  while (tmp != NULL){
    if (tmp->data->dataaddr == d)
      return tmp->data;
    tmp = tmp->next;
  }
  dnode = new_data_node(d);
  add_data_node(dnode);
  return dnode;
}

void show_input_data_node(){
  data_node_list * tmp = Datalist;
  while (tmp != NULL){
    if (tmp->data->input == NULL)
      fprintf(stderr, "input data: %d\n", tmp->data->serial);
    if (tmp->data->outputs == NULL)
      fprintf(stderr, "output data: %d\n", tmp->data->serial);
    tmp = tmp->next;
  }
}

void init_dataflow(){
  if (Datalist != NULL) {
    free_data_node_list(Datalist);
    Datalist = NULL;
  }
  if (Funclist != NULL) {
    free_func_node_list(Funclist);
    Funclist = NULL;
  }
  data_serial = 0;
  func_serial = 0;
}

func_node * get_func_node(NINF_STUB_INFO * info, int inputNum, int outputNum){
  func_node * tmp;
  tmp = new_func_node(info, inputNum, outputNum);
  add_func_node(tmp);
  return tmp;
}

count_io(NINF_STUB_INFO * stub_info, int * in, int * out, int nparam){
  int i;
  struct ninf_param_desc *dp;

  for(i = 0; i < nparam; i++){
    dp = &(stub_info->params[i]);
    if(dp->ndim != 0){	/* not scalar */
      if (IS_IN_MODE(dp->param_inout))
	(*in)++;
      if (IS_OUT_MODE(dp->param_inout))
	(*out)++;
    }
  }
}

int get_arg_num(func_node * fnode, data_node * data)
{
  int i;
  for (i = 0; i < fnode->info->nparam; i++){
    if ((*(fnode->args + i))->data == data)
      return i;
  }
  return -1;
}

data_wrapper * new_data_wrapper(int flag, data_node * da)
{
  data_wrapper * tmp = (data_wrapper *) myalloc(sizeof(data_wrapper));
  tmp->io_flag = flag;
  tmp->data = da;
  return tmp;
}

func_node * get_input_func(data_node * data)
{
  return data->input;
}

int count_output_func(data_node * data){
  int c = 0;
  arg_pos *tmp = data->outputs;
  while (tmp != NULL){
    c++;
    tmp = tmp->next;
  }
  return c;
}

func_node * get_output_func(data_node * data)
{
  if (data->outputs == NULL)
    return NULL;
  return data->outputs->func;
}



link_data_node(func_node * fnode, any_t ninf_args[], int nparam)
{
  int i, iindex = 0, oindex =0;
  struct ninf_param_desc *dp;

  for(i = 0; i < nparam; i++){
    dp = &(fnode->info->params[i]);
    if(dp->ndim != 0){	/* not scalar */
      *((fnode->args  ) +  i)     = NULL;
      if (IS_IN_MODE(dp->param_inout)){
	data_node * tmp_data_node = get_data_node(ninf_args[i].u.p);
	tmp_data_node->outputs = 
	  new_arg_pos(fnode, i, tmp_data_node->outputs);

/*	*((fnode->inputs) + iindex) = tmp_data_node; */
	*((fnode->args  ) +  i)     = new_data_wrapper(MODE_IN, tmp_data_node);
	iindex++;
      }
      if (IS_OUT_MODE(dp->param_inout)){
	data_node * tmp_data_node = get_data_node(ninf_args[i].u.p);
	tmp_data_node->input = fnode;
/*	*((fnode->outputs) + oindex) = tmp_data_node; */
	*((fnode->args  ) +  i)      = new_data_wrapper(MODE_OUT, tmp_data_node);
	oindex++;
      }
    } else {  /* scalar */
      *((fnode->args  ) +  i)      = new_data_wrapper(MODE_NONE, NULL);
    }
  }
}

copy_ninf_args(func_node * tmp, any_t ninf_args[], int nparam){
  int i;
  for (i = 0; i < nparam; i++){
    tmp->ninf_args[i] = ninf_args[i];
  }
}
int sumup_ninf_args(){
  int sum = 0;
  func_node_list * tmp = Funclist;
  while (tmp != NULL){
    sum += tmp->func->info->nparam;
    tmp = tmp->next;
  }
  return sum;
}

any_t * merge_ninf_args(){
  int index = 0;
  int i;
  int sum = sumup_ninf_args();
  any_t * answer = (any_t *)myalloc(sum * sizeof(any_t));
  func_node_list * tmp = Funclist;
  while (tmp != NULL){
    for (i = 0; i < tmp->func->info->nparam; i++){
      answer[index + i] = tmp->func->ninf_args[i];
    }
    index += i;
    tmp = tmp->next;
  }
  return answer;
}

int ninf_make_dataflow(any_t ninf_args[], NINF_STUB_INFO * stub_info)
{
  int in = 0, out = 0;
  func_node * tmp;
  int nparam = stub_info->nparam;

  count_io(stub_info, &in, &out, nparam);
  tmp = get_func_node(stub_info, in, out);
  link_data_node(tmp, ninf_args, nparam);
  copy_ninf_args(tmp, ninf_args, nparam);
  return NINF_OK;
}
    

/************************* TRANS FUNCTIONS **************************/

int trans_func_num(dataTrans * dt, func_node * func, data_node * data)
{
  int tmp = get_arg_num(func, data);
  if (!trans_int(dt, &(func->serial))) return(FALSE); /* function num*/
  if (!trans_int(dt, &tmp)) return(FALSE);             /* arg num */
  return TRUE;
}

int trans_output_funcs(dataTrans *dt, data_node * data){
  int c = 0;
  arg_pos *tmp = data->outputs;
  while (tmp != NULL){
    if (!trans_func_num(dt, tmp->func, data)) return FALSE;
    tmp = tmp->next;
  }
  return TRUE;
}

int trans_data_wrapper(dataTrans * dt, data_wrapper * wrap)
{
  int num;
  func_node * func;
  if (wrap != NULL && wrap->io_flag == MODE_IN){
    func = get_input_func(wrap->data);
    if (func == NULL){
      num = 0;
      if (!trans_int(dt, &num)) return(FALSE); /* number of inputs*/
    } else {
      num = 1;
      if (!trans_int(dt, &num)) return(FALSE); /* number of inputs*/
      if (!trans_func_num(dt, func, wrap->data));
    }
    num = 0;
    if (!trans_int(dt, &num)) return(FALSE); /* number of outputs*/
  } else if (wrap != NULL && wrap->io_flag == MODE_OUT){
    num = 0;
    if (!trans_int(dt, &num)) return(FALSE); /* number of inputs*/

    num = count_output_func(wrap->data);
    if (!trans_int(dt, &num)) return(FALSE); /* number of outputs*/
    if (!trans_output_funcs(dt, wrap->data)) return(FALSE); 
  } else {
    num = 0;
    if (!trans_int(dt, &num)) return(FALSE); /* number of iputs*/
    if (!trans_int(dt, &num)) return(FALSE); /* number of outputs*/
  }
  return TRUE;
}

int trans_dataflow(dataTrans * dt, func_node * func, int index)
{
  int i;
  if (ninf_debug_flag){
    fprintf(stderr,"index is %d\n", index);
    fprintf(stderr,"stub_index is %d\n", func->info->stub_index);
    fprintf(stderr,"nparam is %d\n", func->info->nparam);
  }
  if (!trans_int(dt, &index)) return(FALSE); /* function index */
  if (!trans_int(dt, &(func->info->stub_index))) return(FALSE); /* stub_index */
  if (!trans_int(dt, &(func->info->nparam))) return(FALSE); /* nparam */
  for (i = 0; i < func->info->nparam; i++){
    if (!trans_data_wrapper(dt, *(func->args + i))) return (FALSE);
  }
  return TRUE;
}

int trans_dataflows(dataTrans * dt)
{
  int i;
  int length = func_node_list_length();
  func_node_list * tmp = Funclist;

  /*   fprintf(stderr, "length is %d\n", length); */
  if(!trans_int(dt, &length)) return(FALSE);
  for (i = 0; i < length; i++){
    if(!trans_dataflow(dt, tmp->func, i)) return(FALSE);
    tmp = tmp->next;
  }
  return TRUE;
}

int is_common_data(data_node * data){
  int in_num = count_input_data_node(data);
  int out_num = count_output_data_node(data);

  return (in_num + out_num > 1);
}

int count_output_data_node(data_node * data){
  int i = 0;
  arg_pos * tmp = data->outputs;
  while (tmp != NULL){
    i++;
    tmp = tmp->next;
  }
  return i;
}

int count_input_data_node(data_node * data){
  if (data->input == NULL)
    return 0;
  else
    return 1;
}

int trans_data_node(dataTrans * dt, data_node * data){
  arg_pos * tmp;
  int in_num = count_input_data_node(data);
  int out_num = count_output_data_node(data);
  int co = in_num + out_num;

  if(!trans_int(dt, &co)) return(FALSE);
  if (in_num > 0){
    if(!trans_int(dt, &(data->input->serial))) return(FALSE);  
    co = get_arg_num(data->input, data);
    if(!trans_int(dt, &co)) return(FALSE);
  }
  tmp = data->outputs;
  while (tmp != NULL){
    func_node * func = tmp->func;
    if(!trans_int(dt, &(func->serial))) return(FALSE);  
    if(!trans_int(dt, &(tmp->argnum))) return(FALSE);
    tmp = tmp->next;
  }
  return TRUE;
}

int count_common_data(){
  int co = 0;
  data_node_list * tmp = Datalist;
  while (tmp != NULL){
    if (is_common_data(tmp->data))
      co++;
    tmp = tmp->next;
  }
  return co;
}

int trans_common_data(dataTrans * dt){
  int i;
  int co = count_common_data();
  data_node_list * tmp = Datalist;
  if(!trans_int(dt, &co)) return(FALSE);
  while (tmp != NULL){
    if (is_common_data(tmp->data))
      if (!trans_data_node(dt, tmp->data)) return (FALSE);
    tmp = tmp->next;
  }
  return TRUE;
}
