package bricks.scheduling;
import bricks.util.*;
import java.util.*;

public class NormalServerMonitorCreator extends SchedulingUnitCreator {

    // for bricks.tools.ShowUsage
    public NormalServerMonitorCreator(){}

    public NormalServerMonitorCreator(SubComponentFactory subComponentFactory) {
	this.subComponentFactory = subComponentFactory;
    }

    public String usage() {
	return "NormalServerMonitor(<String keyOfResourceDB>, " +
	    "<Sequence interprobingTime>, <double trackingTime>" +
	    "(, <double trackingTimeForAccess>))";
    }

    public SchedulingUnit create(StringTokenizer st) 
	throws BricksParseException 
    {
	try {
	    String key = st.nextToken(" \t,()"); // ResourceDB

    	    Sequence interprobingTime = 
		(Sequence)subComponentFactory.create(st);
	    double trackingTime = 
		Double.valueOf(st.nextToken(" \t,()")).doubleValue();
	    double trackingTimeForAccess = -1.0;
	    if (st.hasMoreElements())
		trackingTimeForAccess = 
		    Double.valueOf(st.nextToken(" \t,()")).doubleValue();

	    if (trackingTimeForAccess > 0.0)
		return 
		    new NormalServerMonitor(
			key, interprobingTime, trackingTime, 
			trackingTimeForAccess
			);
	    else
		return 
		    new NormalServerMonitor(
			key, interprobingTime, trackingTime, trackingTime
			);

	} catch (NoSuchElementException e) {
	    e.printStackTrace();
	    throw new BricksParseException(usage());

	} catch (NumberFormatException e) {
	    e.printStackTrace();
	    throw new BricksParseException(usage());
	}
    }
}
