#include <stdio.h>
#include <stdlib.h>

long pi_trial(int seed, long times){
  long l, counter = 0;
  srandom(seed);

  for (l = 0; l < times; l++){
	double x = (double)random() /	RAND_MAX;
	double y = (double)random() /	RAND_MAX;
	if (x * x + y * y < 1.0)
	  counter++;
  }
  return counter;
}

