#include "ninf_read_config.h"
#include "throughput_measure.h"

#define MPI_COMMAND_NAME "mpirun"
extern int ninf_debug_flag;

extern struct read_stub_item * read_stub_item_root;
extern struct metaserver_item * metaserver_item_root;
extern char * logfile;

extern char * myname;
extern int myportno;
extern char * config_port;  

extern int redirect_outerr;

extern int linpack_size;
extern int performance;
extern int CPUs;
extern int MPI_PROCS;
extern char * MPIRUN;
extern char * TMP_FILE_ROOT;

extern measure_server * measure_servers;
extern int measure_interval;   /*  interval */
extern int measure_size;       /*  throughputSize */

extern int    NWSuse;
extern char * NWSdir;
extern char * NWSMemoryDir;
extern int    NWSinvokeSensor;
extern int    NWSinvokeForecaster;
extern char * NWSMemoryLog;
extern char * NWSMemoryErr;

/* HTTP related variables */
extern int    httpdStart;
extern int    httpdPort;
extern char * httpdJarPath;
extern char * httpdClassName;

/* process manage */
extern int    maxInvocation;

#ifdef CONFIG_MAIN 

/****************************************** 
    initial values for configurations 
******************************************/

struct read_stub_item * read_stub_item_root = NULL;
struct metaserver_item * metaserver_item_root = NULL;
char * logfile = NULL;
char * myname = NULL;           /* my hostname */
int    myportno;                /* my portnumber */
char * config_port = NULL;

int redirect_outerr = TRUE;

int linpack_size = 300;
int performance = -1;
int CPUs = 1;
int MPI_PROCS = 1;
char * MPIRUN = MPI_COMMAND_NAME;
char * TMP_FILE_ROOT = "/tmp";

measure_server * measure_servers = NULL; 
int measure_interval = 1000;   /*  interval */
int measure_size = 2000;       /*  throughputSize */

/*  NWS related variables */
int    NWSuse = FALSE;
char * NWSdir = NULL;
char * NWSMemoryDir = NULL;
int    NWSinvokeSensor = FALSE;
int    NWSinvokeForecaster = FALSE;
char * NWSMemoryLog = NULL;
char * NWSMemoryErr = NULL;


/* HTTP related variables */

int    httpdStart     = TRUE;
int    httpdPort      = 3080;

char * httpdJarPath   = HTTPD_JAR_PATH; /* have to be supplied by Makefile */
char * httpdClassName = "ninf.browser.NinfBrowser";

/* process manage */
int    maxInvocation  = 1000;

#endif 

