//
// NinfFunction.java
//

package ninf.MetaServer;
import ninf.basic.*;
import ninf.client.*;

import java.util.Vector;
import java.io.IOException;

public class NinfFunction implements NinfNativeCallable, NinfCallable {
  NinfFunctionStruct func;
  FunctionManager manager;
  public static boolean locking = true;

  public NinfFunction(NinfFunctionStruct func, FunctionManager manager){
    this.func = func;
    this.manager = manager;
  }
  
  public NinfStub getStub(){
    return func.getStub();
  }

  public Stoppable callNative(Vector args) throws NinfException{
    ServerIndex server = null;
    NinfServerConnection con = null;
    if (locking)
      server = manager.getQue().getServerLock(func, 1);
    else
      server = manager.getQue().getProperServer(func, 1);
    if (server != null){
      try {
	con = server.server.connect();
	con.callNative(func.getStub(), server.index, args);
      } catch (NinfException e) {
	System.err.println("server: " +server.server + "failed. Remove it from server pool");
	manager.removeNinfServer(server.server);
	throw e;
      } finally {
	server.server.loadDecrement();
	if (con != null) con.stop();
      }
    } else       
      throw new NinfIOException();
    return con;
  }

  public Stoppable callWith(Connected connected, Vector args) throws NinfException{
    NinfServerConnection con = (NinfServerConnection)connected.stop;
    try {
      con.callNative(func.getStub(), connected.server.index, args);
    } 
    catch (NinfStoppedByUserException e) {
      throw e;
    }
    catch (NinfException e) {
      System.err.println("server: " + connected.server.server + "failed. Remove it from server pool");
      manager.removeNinfServer(connected.server.server);
      throw e;
    } finally {
      connected.server.server.loadDecrement();
      if (con != null) con.stop();
    }
    return con;
  }

  public Connected connect() throws NinfException{
    ServerIndex server = null;
    NinfServerConnection con = null;
    if (locking)
      server = manager.getQue().getServerLock(func, 1);
    else
      server = manager.getQue().getProperServer(func, 1);
    if (server != null){
      try {
	con = server.server.connect();
      } catch (NinfException e) {
	System.err.println("server: " +server.server + "failed. Remove it from server pool");
	manager.removeNinfServer(server.server);
	throw e;
      }
    } else       
      throw new NinfIOException();
    return new Connected(con, server);
  }

  public Stoppable call(NinfPacket pkt, XDRInputStream is, XDROutputStream os) 
    throws NinfException {
    ServerIndex server = null;
    NinfServerConnection con = null;
    if (locking)
      server = manager.getQue().getServerLock(func, 1);
    else
      server = manager.getQue().getProperServer(func, 1);
    if (server != null){
      try {
	con = server.server.connect();
	con.startForward(pkt, server.index, is, os);
      } catch (NinfException e) {
	System.err.println("server: " +server.server + "failed. Remove it from server pool");
	manager.removeNinfServer(server.server);
	throw e;
      } finally {
	server.server.loadDecrement();
      }
    }
    return con;
  }
}


