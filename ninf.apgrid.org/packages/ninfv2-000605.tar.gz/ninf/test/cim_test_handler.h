
typedef struct c_pointer_handler{
  void * pointer;
  int ndim;
  int dim_size[10];
  int current[10];
  DATA_TYPE data_type;
} c_pointer_handler;

c_pointer_handler * new_c_pointer_handler(void * pointer, int ndim, int * dim_size, 
					  DATA_TYPE data_type);
int ninf_cim_init_c(obj_handler h);
int ninf_cim_finalize_c(obj_handler  h);
int ninf_cim_destruct_c(obj_handler  h);
int ninf_cim_proceed_c(obj_handler h, int rank, int n);
char * calc_pointer (c_pointer_handler * handler);
int ninf_cim_get_c(obj_handler h, void * p, DATA_TYPE d);
int ninf_cim_put_c(obj_handler h, void * p, DATA_TYPE d);
