#define _WRAPPER_
/* $Id: pcgeqpf_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define SCOMPLEX
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n
static	int worklen(int m, int n) {
	  int ret=1;
	  int IROFF,ICOFF,IAROW,IACOL,Mp0,Nq0;
	  int LOC;
	  ret = max(3,m+n) + n + n;
	  if NEED_BUFF {
#define IA 1
#define JA 1
#define MB_A rbloc
#define NB_A cbloc
#define MYROW myprow
#define MYCOL mypcol
#define NPROW nprow
#define NPCOL npcol
#define RSRC_A 0
#define CSRC_A 0

	    IROFF = MOD( IA-1, MB_A ), ICOFF = MOD( JA-1, NB_A );
	    IAROW = INDXG2P( IA, MB_A, MYROW, RSRC_A, NPROW );
	    IACOL = INDXG2P( JA, NB_A, MYCOL, CSRC_A, NPCOL );
	    Mp0   = NUMROC( M+IROFF, MB_A, MYROW, IAROW, NPROW );
	    Nq0   = NUMROC( N+ICOFF, NB_A, MYCOL, IACOL, NPCOL );
	    LOC = NUMROC( JA+N-1, NB_A, MYCOL, CSRC_A, NPCOL );
	    ret = MAX(3,Mp0 + Nq0) + LOC+Nq0;
	  }
	  return ret;
}

static  int rworklen(int n) {
            int ret=1;
            int ICOFF, IACOL;
            int Nq0;
            ret = n+n;
            if NEED_BUFF {
                ICOFF = MOD( JA-1, NB_A );
                IACOL = INDXG2P( JA, NB_A, MYCOL, CSRC_A, NPCOL );
                Nq0   = NUMROC( N+ICOFF, NB_A, MYCOL, IACOL, NPCOL );
                ret =  NUMROC( JA+N-1, NB_A, MYCOL, CSRC_A, NPCOL )+Nq0;
            }
            return ret;
}

void  pcgeqpf_ninf(	 int m,
		 int n,
		 scomplex global_a[],
		 int lda,
		 int global_ipiv[],
		 scomplex global_tau[],
		 scomplex work[],
		 int *info
)
/* "pcgeqpf computes a QR factorization with column pivoting of a M-by-N distributed matrix A: A * P = Q * R." */
/* OPTIONS */
{
	int maxldd;

	int maxlda;
	scomplex *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
	int row_loca, col_loca;

	int *locipiv=NULL;

	scomplex *loctau=NULL;

	scomplex *locwork=NULL;
	int llocwork;
        float *locrwork = NULL;
        int llocrwork;

	INITIALIZE();

	SCALAR( "int", m);
	SCALAR( "int", n);
	SCALAR( "int", lda);

	ROW( a);
	COL( a);
	MAXLDD( maxldd, a );
	maxlda = maxldd;

	MATRIX( "scomplex", a, ROW_a, COL_a);
	DISTRIBUTE( "scomplex", a, ROW_a  , COL_a);

	VECTOR( "c", "int", ipiv, n);
	VECTOR( "c", "scomplex", tau, min(m,n));

	llocwork = worklen(m,n);
	WORK( locwork, llocwork);
        llocrwork = rworklen(n);
        _work( "float", &locrwork, llocrwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pcgeqpf)( &m, &n,
                               loca, &one, &one, desca,
                               locipiv,
                               loctau,
                               locwork, &llocwork,
                               locrwork, &llocrwork,
                               &linfo);

	GATHER( "scomplex", a, ROW_a  , COL_a);
 	vGATHER( "c", "int", ipiv, n);
	vGATHER( "c", "scomplex", tau, min(m,n));
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
		*info = linfo;
	} else {
	}

	FREE_MATRIX(a);
	FREE_MATRIX(ipiv);
	FREE_MATRIX(tau);

	FREE(locwork);
}

