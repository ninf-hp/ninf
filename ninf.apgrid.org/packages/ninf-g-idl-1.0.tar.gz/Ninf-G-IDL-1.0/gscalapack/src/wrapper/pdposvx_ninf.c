#define _WRAPPER_
/* $Id: pdposvx_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define DOUBLE
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n
#define ROW_af ldaf
#define COL_af n
#define ROW_b ldb
#define COL_b nrhs
#define ROW_x ldx
#define COL_x nrhs
#define NB cbloc
#define MB rbloc
#define LOCc_a(n) Cnumroc( (n), NB, mypcol, 0, npcol)
#define LOCr_a(m) Cnumroc( (m), MB, myprow, 0, nprow)
#define LOCc_b(n) Cnumroc( (n), NB, mypcol, 0, npcol)
#define LOCr_b(m) Cnumroc( (m), MB, myprow, 0, nprow)
static	int worklen(int n, int  maxldd) {
	  int ret=1;
	  int pspocon,psporfs;
          pspocon = 2*n+2*n+max(2,2*n);
          psporfs = 3*n;
          ret = max(pspocon,psporfs)+COL_a;
          ret = max(ret,3*maxldd);
	  if NEED_BUFF {
	    pspocon = 2*LOCr(N+MOD(IA-1,MB_A)) + 2*LOCc(N+MOD(JA-1,NB_A))+
	      MAX( 2, MAX(NB_A*CEIL(NPROW-1,NPCOL),LOCc(N+MOD(JA-1,NB_A)) +
			  NB_A*CEIL(NPCOL-1,NPROW)) );
	    psporfs = 3*LOCr( N + MOD( IA-1, MB_A ) );

	    ret =  max( pspocon, psporfs) + LOCr_a(COL_a);
	    ret = max(ret, 3*maxldd);
	  }
	  return ret;
}

static	int iworklen(int n) {
	  int ret=1;
          ret = COL_a;
	  if NEED_BUFF {
	    ret = LOCr_a(COL_a);
	  }
	  return ret;
}

void  pdposvx_ninf(	 char fact,
		 char uplo,
		 int n,
		 int nrhs,
		 double global_a[],
		 int lda,
		 double global_af[],
		 int ldaf,
		 char *equed,
		 double global_sr[],
		 double global_sc[],
		 double global_b[],
		 int ldb,
		 double global_x[],
		 int ldx,
		 double *rcond,
		 double global_ferr[],
		 double global_berr[],
		 double work[],
		 int global_work[],
		 int global_iwork[],
		 int *info
)
/* "pdposvx uses the Cholesky factorization A = U**T*U or A = L*L**T to\\n compute the solution to a real system of linear equations\\n\\n        A(IA:IA+N-1,JA:JA+N-1) * X = B(IB:IB+N-1,JB:JB+NRHS-1),\\n\\n  where A(IA:IA+N-1,JA:JA+N-1) is an N-by-N matrix and X and\\n  B(IB:IB+N-1,JB:JB+NRHS-1) are N-by-NRHS matrices." */
/* OPTIONS */
{
    extern void FortranCall(pdposvx)( char*, char*, int*, int*,
				double*, int*, int*, int*,
				double*, int*, int*, int*,
				char*, double*, double*,
				double*, int*, int*, int*,
				double*, int*, int*, int*,
				double*, double*, double*,
				double*, int*,
				int*, int*,
				int*);

	int maxldd;

	int maxlda;
	double *loca;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];

	int maxldaf;
	double *locaf;
	int descaf[DESCLEN];
	int desc_gaf[DESCLEN];

	int maxldb;
	double *locb;
	int descb[DESCLEN];
	int desc_gb[DESCLEN];

	int maxldx;
	int descx[DESCLEN];
	int desc_gx[DESCLEN];
	double *locx;

        double *locsr;
        double *locsc;

	double locrcond[1];

	double *locferr;
	double *locberr;

        double *locwork;
	int llocwork;

        double *lociwork;
	int llociwork;

	int row_loca, col_loca;
	int row_locaf, col_locaf;
	int row_locb, col_locb;
	int row_locx, col_locx;


	INITIALIZE();

	SCALAR( "char", fact);
	SCALAR( "char", uplo);
	SCALAR( "int", n);
	SCALAR( "int", nrhs);
	SCALAR("int", lda);
	SCALAR( "int", ldaf);
	SCALAR( "int", ldb);
	SCALAR( "int", ldx);

	COMMON( "char", equed, 1);

	ROW( a);
	COL( a);
	ROW( af);
	COL( af);
	ROW( b);
	COL( b);
	ROW( x);
	COL( x);
	MAXLDD( maxldd, a);
	maxlda = maxldd;
	maxldaf = maxldd;
	maxldb = maxldd;
	maxldx = maxldd;

	MATRIX( "double", a, ROW_a, COL_a);
	MATRIX( "double", af, ROW_af, COL_af);
	MATRIX( "double", b, ROW_b, COL_b);
	MATRIX( "double", x, ROW_x, COL_x);
	VECTOR( "r", "double", sr, ROW_a);
	VECTOR( "c", "double", sc, COL_a);
	VECTOR( "c", "double", ferr, COL_b);
	VECTOR( "c", "double", berr, COL_b);

	DISTRIBUTE( "double", a, ROW_a  , COL_a);
	DISTRIBUTE( "double", b, ROW_b  , COL_b);
	vDISTRIBUTE( "r", "double", sr, ROW_a);
	vDISTRIBUTE( "c", "double", sc, COL_a);

        llocwork = worklen(n, maxldd);
        WORK(locwork, llocwork);
        llociwork = iworklen(n);
        IWORK(lociwork,llociwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	  FortranCall(pdposvx)( &fact, &uplo, &n, &nrhs,
				loca, &one, &one, desca,
				locaf, &one, &one, descaf,
				equed, locsr, locsc,
				locb, &one, &one, descb,
				locx, &one, &one, descx,
				locrcond, locferr, locberr,
				locwork, &llocwork,
				lociwork, &llociwork,
				&linfo);

	GATHER( "double", a, ROW_a  , COL_a);
	GATHER( "double", af, ROW_af  , COL_af);
	GATHER( "double", b, ROW_b  , COL_b);
	GATHER( "double", x, ROW_x  , COL_x);

	vGATHER( "r", "double", sr, ROW_a);
	vGATHER( "c", "double", sc, COL_a);
	vGATHER( "c", "double", ferr, COL_b);
	vGATHER( "c", "double", berr, COL_b);

	RETRIEVE("double", locrcond, 1);
	RETRIEVE( "char", equed, 1);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
	  *info = linfo;
	  *rcond = *locrcond;
	} else {
	}

	FREE_COMMON(equed);
	FREE_MATRIX(a);
	FREE_MATRIX(af);
	FREE_MATRIX(b);
	FREE_MATRIX(x);
	FREE_VECTOR(sr);
	FREE_VECTOR(sc);
	FREE_VECTOR(ferr);
	FREE_VECTOR(berr);
	
}

