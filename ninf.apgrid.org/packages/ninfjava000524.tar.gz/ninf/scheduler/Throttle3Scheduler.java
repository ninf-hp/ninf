package ninf.scheduler;
import ninf.metaserver.*;

public class Throttle3Scheduler extends ThrottleScheduler {
  static int THRESHOLD = 3;
}
