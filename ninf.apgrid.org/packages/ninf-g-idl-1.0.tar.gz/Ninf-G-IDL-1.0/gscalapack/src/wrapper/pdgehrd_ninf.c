#define _WRAPPER_
/* $Id: pdgehrd_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define DOUBLE
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n
static	int worklen(int n, int ilo, int ihi) {
	  int ret=1;
	  int IROFFA, ICOFFA, IOFF, IAROW, IHIP, ILROW, IHLP;
	  int ILCOL, INLQ;
	  IOFF = ilo-1;
	  IHIP = ihi;
	  ILROW = ilo;
	  IHLP =  ihi-ilo+1+IOFF;
	  ILCOL = ilo;
	  INLQ = n-ilo+1+IOFF;
	  ret = n*n + n*max( IHIP+1, IHLP+INLQ );
	  if NEED_BUFF {
#define NB cbloc
#define RSRC_A 0
#define CSRC_A 0
	    IROFFA = 0;
	    ICOFFA = 0;
	    IOFF = MOD( ilo-1, NB );
	    IAROW = INDXG2P( 1, NB, myprow, RSRC_A, nprow );
	    IHIP = NUMROC( ihi, NB, myprow, IAROW, nprow );
	    ILROW = INDXG2P( ilo, NB, myprow, RSRC_A, nprow );
	    IHLP = NUMROC( ihi-ilo+IOFF+1, NB, myprow, ILROW, nprow );
	    ILCOL = INDXG2P( ilo, NB, mypcol, CSRC_A, npcol );
	    INLQ = NUMROC( n-ilo+IOFF+1, NB, mypcol, ILCOL, npcol );
	    ret = NB*NB + NB*MAX( IHIP+1, IHLP+INLQ );
	  }
          return ret;
}

void  pdgehrd_ninf(	 int n,
		 int ilo,
		 int ihi,
		 double global_a[],
		 int lda,
		 double global_tau[],
		 double work[],
		 int lwork,
		 int *info
)
/* "pdgehrd reduces a real general distributed matrix A to upper Hessenberg form H by an orthogonal similarity transformation:  Q' * A * Q = H." */
/* OPTIONS */
{
	int maxldd;

	int maxlda;
	double *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
	int row_loca, col_loca;

	double *loctau=NULL;

	double *locwork=NULL;
	int llocwork;


	INITIALIZE();

	SCALAR( "int", n);
	SCALAR( "int", ilo);
	SCALAR( "int", ihi);
	SCALAR( "int", lda);
	SCALAR( "int", lwork);

	ROW( a);
	COL( a);
	MAXLDD( maxldd, a );
	maxlda = maxldd;

	MATRIX( "double", a, ROW_a, COL_a);
	DISTRIBUTE( "double", a, ROW_a  , COL_a);

	VECTOR("c", "double", tau, n-1);

	llocwork= worklen(n, ilo, ihi);
	WORK(locwork,llocwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pdgehrd)( &n, &ilo, &ihi,
                               loca, &one, &one, desca,
                               loctau,
                               locwork, &llocwork, &linfo);

	GATHER( "double", a, ROW_a  , COL_a);
	vGATHER( "c", "double", tau, n-1);

	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
	  *info = linfo;
	} else {
	}

	FREE_MATRIX(a);
	FREE_VECTOR(tau);
        FREE(locwork);
	
}

