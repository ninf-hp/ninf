echo "java -classpath ~/src/bricks/dist/bricks.jar bricks.Simulate -times 10 -server_log -network_log -server_monitoring_log -network_monitoring_log -prefix sample2 sample2.conf"
java -classpath ~/src/bricks/dist/bricks.jar bricks.Simulate -times 10 -server_log -network_log -server_monitoring_log -network_monitoring_log -prefix sample2 sample2.conf

