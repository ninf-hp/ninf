#include <stdio.h>
#include "ninf_stub_info.h"
#include "ninf_IDL.h"

#define THIS_INFO_TYPE	0

#define MAX_STUBS 	80

#define MAX_COMPILE_OPTIONS 	100
#define MAX_GLOBALS 		100
#define MAX_LIBS      		10

#define FORTRAN_STRING_CONVENTION_LAST          0
#define FORTRAN_STRING_CONVENTION_JUST_AFTER    1


struct stub_gen_entry 
{
    SYMBOL ent_id;	/* entry name */
    int nparam;
    struct param_gen_desc{
      enum data_type param_type;	/* argument type */
      enum mode_spec param_inout;	/* IN/OUT */
      SYMBOL param_id;		/* parameter name */
      int ndim;			/* number of dimension */
      struct dim_gen_desc{
	expr size_expr;		/* size */
	expr range_exprs;	/* range */
	VALUE_TYPE size_type;
	int size;		
	NINF_EXPRESSION size_exp;
	VALUE_TYPE start_type;
	int start;
	NINF_EXPRESSION start_exp;
	VALUE_TYPE end_type;
	int end;

	NINF_EXPRESSION end_exp;
	VALUE_TYPE step_type;
	int step;
	NINF_EXPRESSION step_exp;
      } dim[MAX_DIM];
    } params[MAX_PARAMS];
    char *body;
    expr body_expr;
    char *description;
    char *required;
    int order_type;
    NINF_EXPRESSION order;
    char *language;
    int backend;
    int shrink;
};

extern struct stub_gen_entry stubs[MAX_STUBS];
extern int n_stubs;

extern char *compile_options[MAX_COMPILE_OPTIONS];
extern int n_options;

extern char *globals[MAX_GLOBALS];
extern int n_globals;

extern char *libs[MAX_LIBS];
extern int n_libs;

extern char *current_module;

#define STR_EQ(s1,s2)	(strcmp(s1,s2) == 0)

extern char *program;	/* this program */
 
extern int lineno;
extern char *source_file_name,*output_file_name;
extern FILE *source_file,*output_file;

extern int gmake_f;

extern int debug_flag;
extern FILE *debug_fp;

expr read_rest_of_body();


