#define _WRAPPER_
/* $Id: pcgecon_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define SCOMPLEX
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n
static	int worklen(int n) {
	  int ret=1;
	  ret = 2*n + 2*n
		  + max( 2, 2*n);
#define LOCr_a LOCr
#define NB cbloc	  
	  if NEED_BUFF {
            ret = 2*LOCr_a(n) + 2*LOCc(n)
          + max( 2, max( NB*MAX( 1, CEIL(nprow-1,npcol) ), LOCc(n))
                 +  NB*MAX( 1, CEIL(npcol-1,nprow) ) );
	  }
	  return ret;
}

static	int rworklen(int n) {
	  int ret=1;
	  ret = n;
	  if NEED_BUFF {
            ret = LOCr_a(n);
	  }
	  return ret;
}

void  pcgecon_ninf(	 char norm,
		 int n,
		 scomplex global_a[],
		 int lda,
		 float anorm,
		 float *rcond,
		 scomplex work[],
		 float rwork[],
		 int *info
)
/* "pcgecon estimates the reciprocal of the condition number of a general distributed complex matrix A, in either the 1-norm or the infinity-norm, using the LU factorization computed by PCGETRF. An estimate is obtained for norm(inv(A)), and the reciprocal of the condition number is computed as RCOND = 1 / ( norm(A) * norm(inv(A)))." */
/* OPTIONS */
{
	int maxldd;

	int maxlda;
	scomplex *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
	int row_loca, col_loca;

        scomplex *locwork=NULL;
        int llocwork;
        float *locrwork=NULL;
	int llocrwork;

	float locrcond[1];

	INITIALIZE();

	SCALAR( "char", norm);
	SCALAR( "int", n);
	SCALAR( "float", anorm);
	SCALAR( "int", lda);

	ROW( a);
	COL( a);
	MAXLDD( maxldd, a );
	maxlda = maxldd;
        
	MATRIX( "scomplex", a, ROW_a, COL_a);
	DISTRIBUTE( "scomplex", a, ROW_a, COL_a);

	llocwork=worklen(n);
        WORK(locwork, llocwork);
	llocrwork = rworklen(n);
	WORK( locrwork, llocrwork);


	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pcgecon)( &norm, &n,
                               loca, &one, &one, desca,
                               &anorm, locrcond,
                               locwork, &llocwork,
                               locrwork, &llocrwork,
                               &linfo);

        RETRIEVE("float",locrcond,1);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
	  *info = linfo;
	  *rcond = *locrcond;
	} else {
	}

	FREE_MATRIX(a);
        
        FREE(locwork);
        FREE(locrwork);
	
}

