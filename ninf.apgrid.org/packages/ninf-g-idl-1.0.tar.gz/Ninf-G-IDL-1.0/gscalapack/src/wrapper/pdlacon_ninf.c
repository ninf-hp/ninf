#define _WRAPPER_
/* $Id: pdlacon_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define DOUBLE
#include <gscalapack.h>

#define ROW_v mv
#define COL_v nv
#define ROW_x mx
#define COL_x nx
#define ROW_isgn mx 
#define COL_isgn nx
void  pdlacon_ninf(	 int n,
		 double global_v[],
		 double global_x[],
		 int global_isgn[],
		 double *est,
		 int *kase
)
/* "pdlacon estimates the 1-norm of a square, real distributed matrix A." */
/* OPTIONS */
{
	int maxldd;

	int mv, nv;

	int maxldv;
	double *locv=NULL;
	int descv[DESCLEN];
	int desc_gv[DESCLEN];

	int row_locv, col_locv;

	int mx, nx;
	int maxldx;
	double *locx=NULL;
	int descx[DESCLEN];
	int desc_gx[DESCLEN];
	int row_locx, col_locx;

	int maxldisgn;
	int *locisgn=NULL;
	int descisgn[DESCLEN], desc_gisgn[DESCLEN];
	int row_locisgn, col_locisgn;

	double locest[1];

	INITIALIZE();

	SCALAR( "int", n);

	COMMON( "int", kase, 1);

	square( n, &mv, &nv);
	square( n, &mx, &nx);

	ROW( v);
	COL( v);
	ROW( x);
	COL( x);
	ROW( isgn);
	COL( isgn);
	MAXLDD( maxldd, x );

	maxldv = maxldd;
	maxldx = maxldd;
	maxldisgn = maxldd;

	MATRIX("double", v, ROW_v, COL_v);
	MATRIX( "double", x, ROW_x, COL_x);
	MATRIX( "int", isgn, ROW_isgn, COL_isgn);
	DISTRIBUTE( "double", x, ROW_x, COL_x);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pdlacon)( &n,
			       locv, &one, &one, descv,
			       locx, &one, &one, descx,
			       locisgn,
			       locest, kase);

	GATHER( "double", x, ROW_x  , COL_x);

	RETRIEVE("double", locest, 1);
	RETRIEVE("int", kase,1);

	if( mypnum == 0 ){
	  *est = *locest;
	} else {
	}

	FREE_COMMON(kase);
        FREE_MATRIX(v);
	FREE_MATRIX(x);
	FREE_MATRIX(isgn);

}

