#define _WRAPPER_
/* $Id: pcgbtrf_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define _DISTRIBUTE_1D_
#define SCOMPLEX
#define PIVOT
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n
static	int worklen() {
    int ret=1;
    ret = 10;
    return ret;
}

	//	int ipivlen() {
	//	  int ret=1;
	//	  ret = 2*maxldd;
	//	  return ret;
	//	}

void  pcgbtrf_ninf(	 int n,
		 int bwl,
		 int bwu,
		 scomplex global_a[],
		 int lda,
		 int global_ipiv[],
		 int *info
)
/* "pcgbtrf computes a LU factorization of an N-by-N complex banded distributed matrix with bandwidth BWL, BWU: A." */
/* OPTIONS */
{
    extern void FortranCall(pcgbtrf)( int*, int*, int*,
                               scomplex*, int*, int*,
                               int*,
                               scomplex*, int*,
                               scomplex*, int*, int*);

  int maxldd;

	int maxlda;
	scomplex *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];

	scomplex *locaf=NULL;
	int laf;
	scomplex *locwork=NULL;
	int llocwork;

	int *locipiv=NULL;

        
	INITIALIZE();

	SCALAR( "int", n);
	SCALAR( "int", bwl);
	SCALAR( "int", bwu);
	SCALAR("int", lda);

	SIZE(n);

	bandMATRIX("scomplex", a, bwl, bwu, n);
	bandDISTRIBUTE("scomplex", a, bwl, bwu, n);
	VECTOR( "c", "int", ipiv, n);

	llocwork = worklen();
	WORK(locwork,llocwork);

	laf=(cbloc+bwu)*(bwl+bwu)+6*(bwl+bwu)*(bwl+2*bwu);
	locaf=MALLOC(sizeof(scomplex)*laf);
        assert(locaf);
        
	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pcgbtrf)( &n, &bwl, &bwu,
                               loca, &one, desca,
                               locipiv,
                               locaf, &laf,
                               locwork, &llocwork, &linfo);

	bandGATHER( "scomplex", a,  bwl ,bwu, n);
	vGATHER( "c", "int", ipiv, n);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
	  *info = linfo;
	} else {
	}
	FREE_MATRIX(a);
	FREE_VECTOR(ipiv);
        
        FREE(locwork);
        FREE(locaf);
	
}

