#define _WRAPPER_
/* $Id: pslabrd_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define _DISTRIBUTE_1D_
#define FLOAT
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n
#define ROW_x ldx
#define COL_x nb
#define ROW_y ldy
#define COL_y nb
static	int worklen(n) {
	  int ret=1;
	  int NQ;
	  int IACOL;
	  ret = 2*n;
	  if NEED_BUFF {
	    IACOL = INDXG2P( 1, blocsize, mypcol, 0, npcol );
	    NQ = Cnumroc( n+ blocsize , blocsize, mypcol, 0, npcol );
	    ret = blocsize+NQ;
	  }
	  return ret;
}


void  pslabrd_ninf(	 int m,
		 int n,
		 int nb,
		 float global_a[],
		 int lda,
		 float global_d[],
		 float global_e[],
		 float global_tauq[],
		 float global_taup[],
		 float global_x[],
		 int ldx,
		 float global_y[],
		 int ldy
)
/* "pslabrd reduces the first NB rows and columns of a real general M-by-N distributed matrix A to upper or lower bidiagonal form by an orthogonal transformation Q' * A * P, and returns the matrices X and Y which are needed to apply the transformation to the unreduced part of  A." */
/* OPTIONS */
{
  int min_m_n;

	int maxldd;

	int maxlda;
	float *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
	int row_loca, col_loca;

	float *locd=NULL;
	float *loce=NULL;
	int desctdd[DESCLEN], desc_gtdd[DESCLEN];

	float *loctauq=NULL;
	float *loctaup=NULL;

	int maxldx;
	float *locx=NULL;
	int descx[DESCLEN];
	int desc_gx[DESCLEN];
	int row_locx, col_locx;

	int maxldy;
	float *locy=NULL;
	int descy[DESCLEN];
	int desc_gy[DESCLEN];
	int row_locy, col_locy;

	float *locwork=NULL;
	int llocwork;

	INITIALIZE();

	SCALAR( "int", m);
	SCALAR( "int", n);
	SCALAR( "int", nb);
	SCALAR("int", lda);
	SCALAR("int", ldx);
	SCALAR("int", ldy);
	min_m_n = min(m,n);

	SIZE(min_m_n);

	ROW( a);
	COL( a);
	ROW( x);
	COL( x);
	ROW( y);
	COL( y);
	MAXLDD( maxldd, a );
	maxlda = maxldd;
	maxldx = maxldd;
	maxldy = maxldd;

	MATRIX( "float", a, ROW_a, COL_a);
	tdMATRIX( "float", e, d, e, min_m_n);

	VECTOR( "c", "float", tauq, min_m_n);
	VECTOR( "r", "float", taup, min_m_n);

	MATRIX( "float", x, ROW_x, COL_x);
	MATRIX( "float", y, ROW_y, COL_y);
	DISTRIBUTE( "float", a, ROW_a  , COL_a);

	llocwork = worklen(n);
	WORK( locwork, llocwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pslabrd)( &m, &n, &nb,
                               loca, &one, &one, desca,
                               locd, loce,
                               loctauq, loctaup,
                               locx, &one, &one, descx,
                               locy, &one, &one, descy,
                               locwork);

	GATHER( "float", a, ROW_a  , COL_a);
	tdGATHER( "float" , e, d, e, min_m_n);
	vGATHER("c", "float", tauq, min_m_n);
	vGATHER("r", "float", taup, min_m_n);
	GATHER( "float", x, ROW_x  , COL_x);
	GATHER( "float", y, ROW_y  , COL_y);

	if( mypnum == 0 ){
	} else {
	}

	FREE_MATRIX(a);
	FREE_MATRIX(d);
	FREE_MATRIX(e);
	FREE_VECTOR(tauq);
	FREE_VECTOR(taup);
	FREE_MATRIX(x);
	FREE_MATRIX(y);
        FREE(locwork);
	
}

