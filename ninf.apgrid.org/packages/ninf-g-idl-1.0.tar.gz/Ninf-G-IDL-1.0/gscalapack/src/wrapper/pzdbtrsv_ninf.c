#define _WRAPPER_
/* $Id: pzdbtrsv_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define _DISTRIBUTE_1D_
#define DCOMPLEX
#define NO_PIVOT
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n
#define ROW_b ldb
#define COL_b nrhs
#define ROW_af laf
#define COL_af n
static	int worklen(int nrhs, int bwl, int bwu) {
	  int ret=1;
	  ret =  (max(bwl,bwu)*nrhs);
	  return ret;
}


void  pzdbtrsv_ninf(  char uplo,
		 char trans,
		 int n,
		 int bwl,
		 int bwu,
		 int nrhs,
		 dcomplex global_a[],
		  int lda,
		 dcomplex global_b[],
		  int ldb,
		    dcomplex af[],
		 int dummy_laf,
		 dcomplex work[],
		 int lwork,
		 int *info
)
/* "pzdbtrsv solves a banded triangular system of linear equations A * X = B or A^H * X = B where A is a banded triangular matrix factor produced by the Gaussian elimination code PC@(dom_pre)BTRF and is stored in A and AF." */
/* OPTIONS */
{
	extern void FortranCall(pzdbtrsv)( char*, char*,
                                 int*, int*, int*, int*,
                                 dcomplex*, int*, int*,
                                 dcomplex*, int*, int*,
                                 dcomplex*, int*,
                                 dcomplex*, int*, 
					   int*);

	int maxldd;

	dcomplex *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];

	int maxldb;
	dcomplex *locb=NULL;
	int descb[DESCLEN];
	int desc_gb[DESCLEN];
	int row_locb, col_locb;

	dcomplex *locaf=NULL, *global_af=NULL;
	int laf, llocaf;
	int descaf[DESCLEN], desc_gaf[DESCLEN];
	int row_locaf, col_locaf;
	int maxldaf;

	dcomplex *locwork;
	int llocwork;

	INITIALIZE();

	SCALAR( "char", uplo);
	SCALAR( "char", trans);
	SCALAR( "int", n);
	SCALAR( "int", bwl);
	SCALAR( "int", bwu);
	SCALAR( "int", nrhs);
	SCALAR( "int", lda);
	SCALAR("int", ldb);
	SCALAR("int", dummy_laf);
	SCALAR( "int", lwork);
	SIZE(n);

	laf = max(dummy_laf/n, bwl+bwu+6*max(bwl,bwu)*max(bwl,bwu)/n);
	llocaf = laf*blocsize;
	if (mypnum==0) {
	  global_af=MALLOC(sizeof(dcomplex)*laf*n);
          assert(global_af);
	}

	ROW(b);
	COL(b);
	ROW(af);
	COL(af);
	MAXLDD(maxldd, b);
	maxldb = maxldd;
	maxldaf = maxldd;

	bandMATRIX( "dcomplex", a, bwl ,bwu, n);
	MATRIX( "dcomplex", b, ROW_b, COL_b);
	MATRIX( "dcomplex", af, ROW_af, COL_af);
	bandDISTRIBUTE( "dcomplex", a, bwl, bwu, n);
	DISTRIBUTE( "dcomplex", b, ROW_b, COL_b);

	llocwork=worklen(nrhs, bwl, bwu);
        llocwork= max(llocwork,lwork);
	WORK(locwork,llocwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	  FortranCall(pzdbtrsv)( &uplo, &trans,
                                 &n, &bwl, &bwu, &nrhs,
                                 loca, &one, desca,
                                 locb, &one, descb,
                                 locaf, &llocaf,
                                 locwork, &llocwork, &linfo);

	bandGATHER( "dcomplex", a, bwl, bwu, n);
	GATHER( "dcomplex", b, ROW_b, COL_b);
	GATHER( "dcomplex", af, ROW_af, COL_af);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
	  int i;
	  *info = linfo;
	  for(i=0;i<dummy_laf; i++) af[i]=global_af[i];
          FREE(global_af);
	} else {
	}
        
	FREE_MATRIX(a);
	FREE_MATRIX(b);
	FREE_MATRIX(af);
        
        FREE(locwork);
	
}

