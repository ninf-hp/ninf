package ninf.basic;
import ninf.client.*;

abstract public class Callable {
  abstract public Stoppable call(NinfPacket pkt, int serial, 
				 XDRInputStream is, XDROutputStream os) 
    throws NinfException;
  abstract public NinfStub getStub();
  public int index;
}

// end of NinfCallable.java
