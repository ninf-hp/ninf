#define _WRAPPER_
/* $Id: pspoequ_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define FLOAT
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n
void  pspoequ_ninf(	 int n,
		 float global_a[],
		 int lda,
		 float global_sr[],
		 float global_sc[],
		 int ldsc,
		 float *scond,
		 float *amax,
		 int *info
)
/* "pspoequ computes row and column scalings intended to equilibrate a distributed symmetric positive definite matrix A and reduce its condition number (with respect to the two-norm)." */
/* OPTIONS */
{
    	int maxldd;

	int maxlda;
	float *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
	int row_loca, col_loca;

	float *locsr=NULL;
	float *locsc=NULL;

	float lscond[1];
	float lamax[1];

	INITIALIZE();

	SCALAR( "int", n);
        SCALAR( "int", lda);
	SCALAR( "int", ldsc);

	ROW( a);
	COL( a);
	MAXLDD( maxldd, a );
	maxlda = maxldd;

	MATRIX( "float", a, ROW_a, COL_a);
        DISTRIBUTE( "float", a, ROW_a, COL_a);
	VECTOR( "r", "float", sr, ROW_a);
	VECTOR( "c", "float", sc, COL_a);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pspoequ)( &n,
                               loca, &one, &one, desca,
                               locsr, locsc,
                               lscond,
                               lamax,
                               &linfo);

	vGATHER( "r", "float", sr, ROW_a);
	vGATHER( "c", "float", sc, COL_a);

	RETRIEVE("int", lscond, 1);
	RETRIEVE("int", lamax, 1);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
	  *scond = lscond[0];
	  *amax = lamax[0];
	  *info = linfo;
	} else {
	}

	FREE_MATRIX(a);
}

