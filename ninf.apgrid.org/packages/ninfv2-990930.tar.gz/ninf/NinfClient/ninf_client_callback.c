#include <stdio.h>
#include "ninf_stub_info.h"
#include "callback.h"
#include "ninf_error.h"

struct callback * find_callback(struct callback callbacks[], int n)
{
  int i;
  struct callback *tmp = callbacks;
  while (tmp->start_index > 0){
    if (tmp->start_index == n)
      return tmp;
    tmp++;
  }
  return NULL;
}

void init_callback(struct callback * call, void (*f)(), int start, int np){
  int i;
  call->func = f;
  call->start_index = start;
  call->nparam = np;
  for (i = 0; i < MAX_PARAMS; i++)
    call->allocated_size[i] = 0;
}

typedef void (*FUN1) (void *);
typedef void (*FUN2) (void *, void *);
typedef void (*FUN3) (void *, void *, void *);
typedef void (*FUN4) (void *, void *, void *, void *);
typedef void (*FUN5) (void *, void *, void *, void *, void *);
typedef void (*FUN6) (void *, void *, void *, void *, void *, void *);


void ninf_exec_callback_call(void (* func)(), int start, int params, any_t ninf_args[])
{
  switch (params){
  case  1:
    ((FUN1)(*func))(ninf_args[start+1].u.p);
    break;
  case  2:
    ((FUN2)(*func))(ninf_args[start+1].u.p, ninf_args[start+2].u.p);
    break;
  case  3:
    ((FUN3)(*func))(ninf_args[start+1].u.p, ninf_args[start+2].u.p, ninf_args[start+3].u.p);
    break;
  case  4:
    ((FUN4)(*func))(ninf_args[start+1].u.p, ninf_args[start+2].u.p, ninf_args[start+3].u.p, ninf_args[start+4].u.p);
    break;
  case  5:
    ((FUN5)(*func))(ninf_args[start+1].u.p, ninf_args[start+2].u.p, ninf_args[start+3].u.p, ninf_args[start+4].u.p, ninf_args[start+5].u.p);
    break;
  case  6:
    ((FUN6)(*func))(ninf_args[start+1].u.p, ninf_args[start+2].u.p, ninf_args[start+3].u.p, ninf_args[start+4].u.p, ninf_args[start+5].u.p, ninf_args[start+6].u.p);
    break;

  default:
    ninf_error("too many args for callback function \n");
  }

}


