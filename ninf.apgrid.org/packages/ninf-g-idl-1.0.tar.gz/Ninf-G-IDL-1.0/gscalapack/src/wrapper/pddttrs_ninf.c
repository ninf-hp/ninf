#define _WRAPPER_
/* $Id: pddttrs_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define _DISTRIBUTE_1D_
#define DOUBLE
#include <gscalapack.h>

#define ROW_b n
#define COL_b nrhs
#define ROW_af laf
#define COL_af n
static	int worklen(int nrhs) {
	  int ret=1;
	  ret = 10+4*nrhs;
	  if NEED_BUFF ret = 10*npcol+4*nrhs;
          return ret;
}


void  pddttrs_ninf(	 char trans,
		 int n,
		 int nrhs,
		 double global_dl[],
		 double global_d[],
		 double global_du[],
		 double global_b[],
		 double af[],
		 int dummy_laf,
		 double work[],
		 int lwork,
		 int *info
)
/* "pddttrs solves a system of linear equations A * X = B or A' * X = B where A is the matrix used to produce the factors stored in A and AF by psdttrf." */
/* OPTIONS */
{
extern void FortranCall(pddttrs)( char*, int*, int*,
                               double*, double*, double*, int*, int*,
                               double*, int*, int*,
                               double*, int*,
                               double*, int*, int*);

	int maxldd;
	double *locdl=NULL, *locd=NULL, *locdu=NULL;
	int desctdd[DESCLEN];
	int desc_gtdd[DESCLEN];

	double *locb=NULL;
	int maxldb;
	int descb[DESCLEN];
	int desc_gb[DESCLEN];
	int row_locb, col_locb;

	double *locaf=NULL, *global_af=NULL;
	int maxldaf;
	int descaf[DESCLEN];
	int desc_gaf[DESCLEN];
	int laf, llocaf;
	int row_locaf, col_locaf;
	
	double *locwork=NULL;
	int llocwork;

	INITIALIZE();

	SCALAR( "char", trans);
	SCALAR( "int", n);
	SCALAR( "int", nrhs);
	SCALAR("int", dummy_laf);
	SCALAR( "int", lwork);

	SIZE(n);

	laf = 2*(blocsize+2)*nprocs/n;
	llocaf = laf*blocsize;
	if (mypnum==0) {
	  global_af=MALLOC(sizeof(double)*laf*n);
          assert(global_af);
	}

	ROW(b);
	COL(b);
	ROW(af);
	COL(af);
	MAXLDD( maxldd, af);
	maxldaf=maxldd;
	maxldb=maxldd;

	tdMATRIX("double", dl, d, du, n);
	MATRIX("double", b, ROW_b, COL_b);
	MATRIX("double", af, ROW_af, COL_af);
	tdDISTRIBUTE("double", dl, d, du, n);
	DISTRIBUTE( "double", b, ROW_b, COL_b);

	llocwork = worklen(nrhs);
        llocwork = max(lwork,llocwork);
	WORK(locwork,llocwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pddttrs)( &trans, &n, &nrhs,
                               locdl, locd, locdu, &one, desctdd,
                               locb, &one, descb,
                               locaf, &laf,
                               locwork, &llocwork, &linfo);

	tdGATHER( "double", dl, d, du, n);
	GATHER( "double", b, ROW_b, COL_b);
	GATHER( "double", af, ROW_af, COL_af);

	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
	  int i;
	  *info = linfo;
	  for(i=0;i<min(dummy_laf,laf*n);i++) af[i]=global_af[i];
          FREE(global_af);
	} else {
	}
        FREE_MATRIX(dl);
        FREE_MATRIX(d);
        FREE_MATRIX(du);
        FREE_MATRIX(b);
        FREE_MATRIX(af);
	FREE(locwork);
}

