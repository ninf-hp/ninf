#define _WRAPPER_
/* $Id: pcporfs_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define SCOMPLEX
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n
#define ROW_af ldaf
#define COL_af n
#define ROW_b ldb
#define COL_b nrhs
#define ROW_x ldx
#define COL_x nrhs
static	int worklen(int n) {
	  int ret=1;
	  ret = 2*n;
	  if NEED_BUFF {
              ret = 2*LOCr( N + MOD( IA-1, MB_A ) );
          }
	  return ret; 
}

static	int rworklen(int n) {
	  int ret=1;
	  ret = n;
	  if NEED_BUFF {
              ret = LOCr( N + MOD( IB-1, MB_B ) );
          }
	  return ret;
}


void  pcporfs_ninf(	 char uplo,
		 int n,
		 int nrhs,
		 scomplex global_a[],
		 int lda,
		 scomplex global_af[],
		 int ldaf,
		 scomplex global_b[],
		 int ldb,
		 scomplex global_x[],
		 int ldx,
		 float global_ferr[],
		 float global_berr[],
		 scomplex work[],
		 int rwork[],
		 int *info
)
/* "pcporfs improves the computed solution to a system of linear equations when the coefficient matrix is Hermitian positive definite and provides error bounds and backward error estimates for the solutions." */
/* OPTIONS */
{
	int maxldd;

	int maxlda;
	scomplex *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
	int row_loca, col_loca;

	int maxldaf;
	scomplex *locaf=NULL;
	int descaf[DESCLEN];
	int desc_gaf[DESCLEN];
	int row_locaf, col_locaf;

	int maxldb;
	scomplex *locb=NULL;
	int descb[DESCLEN];
	int desc_gb[DESCLEN];
	int row_locb, col_locb;

	int maxldx;
	scomplex *locx=NULL;
	int descx[DESCLEN];
	int desc_gx[DESCLEN];
	int row_locx, col_locx;

	float *locferr=NULL;
	float *locberr=NULL;

	scomplex *locwork=NULL;
	int llocwork;
	float *locrwork=NULL;
	int llocrwork;

	INITIALIZE();

	SCALAR( "char", uplo);
	SCALAR( "int", n);
	SCALAR( "int", nrhs);
        SCALAR( "int", lda);
        SCALAR( "int", ldb);
        SCALAR("int", ldaf);
        SCALAR( "int", ldx);

	ROW( a); COL( a);
	ROW( af); COL( af);
	ROW( b); COL( b);
	ROW( x); COL( x);
	MAXLDD( maxldd, a );
	maxlda = maxldd;
	maxldaf = maxldd;
	maxldb = maxldd;
	maxldx = maxldd;

	MATRIX( "scomplex", a, ROW_a, COL_a);
	MATRIX( "scomplex", af, ROW_af, COL_af);
	MATRIX( "scomplex", b, ROW_b, COL_b);
	MATRIX( "scomplex", x, ROW_x, COL_x);
	VECTOR( "c","scomplex", ferr, nrhs);
	VECTOR( "c", "scomplex", berr, nrhs);
        
	DISTRIBUTE( "scomplex", a, ROW_a, COL_a);
	DISTRIBUTE( "scomplex", af, ROW_af, COL_af);
	DISTRIBUTE( "scomplex", b, ROW_b, COL_b);
	DISTRIBUTE( "scomplex", x, ROW_x, COL_x);

        llocwork = worklen(n);
        WORK(locwork,llocwork);
        llocrwork = rworklen(n);
        _work("float",&locrwork,llocrwork);
        
	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pcporfs)( &uplo, &n, &nrhs,
                               loca, &one, &one, desca,
                               locaf, &one, &one, descaf,
                               locb, &one, &one, descb,
                               locx, &one, &one, descx,
                               locferr, locberr,
                               locwork, &llocwork,
                               locrwork, &llocrwork,
                               &linfo);

	GATHER( "scomplex", x, ROW_x, COL_x);
	vGATHER( "c", "float", ferr, nrhs);
	vGATHER( "c", "float", berr, nrhs);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
		*info = linfo;
	} else {
	}

	FREE_MATRIX(a);
	FREE_MATRIX(af);
	FREE_MATRIX(b);
	FREE_MATRIX(x);
        FREE(locwork);
        FREE(locrwork);
	
}

