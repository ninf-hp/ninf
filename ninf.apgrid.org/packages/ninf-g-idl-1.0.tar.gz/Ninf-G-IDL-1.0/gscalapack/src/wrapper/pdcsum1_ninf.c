#define _WRAPPER_
/* $Id: pdcsum1_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define DOUBLE
#include <gscalapack.h>

#define ROW_x ldx
#define COL_x nx
void  pdcsum1_ninf(	
		 int n,
		 dcomplex global_x[],
		 int incx,
		 double *global_asum
)
/* "pdcsum1 returns the sum of absolute values of a complex vector X, and returns a single precision result." */
/* OPTIONS */
{
  int maxldd;

  int maxldx;
  dcomplex *locx=NULL;
  int descx[DESCLEN];
  int desc_gx[DESCLEN];
  int ldx, nx;
  int row_locx, col_locx;

  double locasum[1];

  INITIALIZE();

  SCALAR("int", n);
  SCALAR("int", incx);

  square( n, &ldx, &nx);
  
  ROW(x);
  COL(x);
  MAXLDD(maxldd, x);
  maxldx=maxldd;
  
  MATRIX( "dcomplex", x, ROW_x, COL_x);
  DISTRIBUTE( "dcomplex", x, ROW_x, COL_x);
  
  if  (( mypnum != 0 ) ^ (serial==1) ) {
     FortranCall(pdcsum1)( &n, locasum, locx, &one, &one, descx, &incx);
    Csgsum2d( PARA_CTXT, "A", MPI_TOP, 1, 1, &locasum,     1, 0, 0);
  }

  RETRIEVE( "double", locasum, 1);

  if( mypnum == 0 ){
    *global_asum = locasum[0];
  } else {
  }

  
}

