package bricks.scheduling;
import bricks.util.*;
import java.util.*;

public class LazyReplicaManagerCreator extends SchedulingUnitCreator {

    // for bricks.tools.ShowUsage
    public LazyReplicaManagerCreator(){}

    public LazyReplicaManagerCreator(SubComponentFactory subComponentFactory) {
	this.subComponentFactory = subComponentFactory;
    }

    public String usage() {
	return "LazyReplicaManager(<String keyOfRresourceDB>, <String keyOfServerMonitor>, <double compactness>)";
    }

    public SchedulingUnit create(StringTokenizer st) 
	throws BricksParseException 
    {
	try {
	    String keyOfResourceDB = st.nextToken(" \t,()");
	    String keyOfServerMonitor = st.nextToken(" \t,()");
	    double compactness = 
		Double.valueOf(st.nextToken(" \t,()")).doubleValue();

	    return new LazyReplicaManager(
		keyOfResourceDB, keyOfServerMonitor, compactness
	    );

	} catch (NoSuchElementException e) {
	    e.printStackTrace();
	    throw new BricksParseException(usage());

	} catch (NumberFormatException e) {
	    e.printStackTrace();
	    throw new BricksParseException(usage());
	}

    }
}

