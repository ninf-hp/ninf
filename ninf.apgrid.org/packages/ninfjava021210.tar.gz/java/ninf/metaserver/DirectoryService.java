package ninf.metaserver;
import ninf.basic.*;
import ninf.common.*;
import ninf.client.*;
import ninf.scheduler.*;
import java.io.*;
import java.util.Hashtable;
import java.util.Vector;
import java.util.Enumeration;


public class DirectoryService {
  Set servers;  /* NinfServerHolder Set */
  private boolean lock = false;
  static NinfLog dbg = new NinfLog("DirectoryService");

  Hashtable functionTable;  /* key = FunctionName, val = FunctionStruct */
  Hashtable interServerTable; /* key = NodePair, val = InterServerInfo */
  MetaServerRoot masterServer;
  Set serverObservers;
  DirectoryServiceFront front;


  DirectoryService(MetaServerRoot masterServer){
    servers = new Set();
    functionTable = new Hashtable();
    interServerTable = new Hashtable();
    this.masterServer = masterServer;
    serverObservers = new Set();
    front = new DirectoryServiceFront(this);
  }

  public synchronized void lock(){
    lock = true;
  }
  public synchronized void unlock(){
    lock = false;
    notify();
  }

  
  public synchronized ServerIndex getServerIndex(FunctionName name, 
					  NinfServerStruct struct){
    FunctionStruct functionStruct = (FunctionStruct)functionTable.get(name);
    return functionStruct.getServerIndex(struct);
  }

  public synchronized NinfServerHolder getHolder(NinfServerStruct struct){
    NinfServerHolder o = 
      (NinfServerHolder)servers.match(new ServerHolderMatch(struct));
    return o;
  }

  public synchronized LoadInformation getLoadInformation(NinfServerStruct struct){
    NinfServerHolder o = 
      (NinfServerHolder)servers.match(new ServerHolderMatch(struct));
    if (o == null)
      return null;
    return o.load;
  }

  synchronized ServerCharacter getServerCharacter(NinfServerStruct struct){
    NinfServerHolder o = 
      (NinfServerHolder)servers.match(new ServerHolderMatch(struct));
    if (o == null)
      return null;
    return o.serverChar;
  }

  synchronized void clearServer(NinfServerHolder server){
    //    while (lock)
    //      wait();
    
  }

  synchronized NinfStub getStub(FunctionName name){
    FunctionStruct tmp = (FunctionStruct)functionTable.get(name);
    if (tmp == null) 
      return null;
    return tmp.getStub();
  }

  boolean throughputInfo(DataInputStream is, PrintStream os) throws NinfException{
    front.throughputInfo(is, os);
    return true;
  }

  synchronized NinfServerHolder registerServer(NinfServerHolder tmpServer){
    NinfServerHolder server = (NinfServerHolder)servers.get(tmpServer);
    if (server == null){
      servers.add(tmpServer);
      tmpServer.updateTime = System.currentTimeMillis();
      server = tmpServer;
    }
    addObservable(server);
    return server;
  }

  synchronized Set getNewServers(long time){
    return servers.select(new NewerThan(time));
  }

  synchronized void addInterServerInfo(ServerID from, ServerID to,
				  InterServerInfo info){
    NodePair pair = new NodePair(from, to);
    interServerTable.put(pair, info);
    dbg.log("interServerInfo :" + pair + " " + info);

  }


  synchronized void registerStub(NinfServerHolder server, NinfStub stub, int index){
    FunctionName name;
    name = new FunctionName(stub.module_name, stub.entry_name);

    FunctionStruct tmp = (FunctionStruct)functionTable.get(name);
    if (tmp == null){
      tmp = new FunctionStruct(stub);
      functionTable.put(name, tmp);
    }
    tmp.addServer(new ServerIndex(server.struct, index));
  }    

  synchronized FunctionName[] getServerFuncs(NinfServerStruct struct){
    Vector vec = new Vector();

    Enumeration enum = functionTable.elements();
    while (enum.hasMoreElements()){
      FunctionStruct functionStruct = (FunctionStruct)enum.nextElement();
      Object o = functionStruct.serverIndexList.match(new ServerIndexMatch(struct));
      if (o != null)
	vec.addElement(functionStruct);
    }
    FunctionName[] ans = new FunctionName[vec.size()];
    for (int i = 0; i < vec.size(); i++)
      ans[i] = ((FunctionStruct)vec.elementAt(i)).stub.getName();
    return ans;
  }

  public void scheduled(RequestID request, CallInformation callInfo, 
			ScheduleResult result){
    NinfServerStruct struct = result.serverInfo.serverIndex.server;
    FunctionName funcName = request.funcName;
    serverObservers.doEach(
	  new InformObserver("scheduled", struct, funcName));
  }

  public void done(RequestID request, CallInformation callInfo, 
		   ScheduleResult result){
    NinfServerStruct struct = result.serverInfo.serverIndex.server;
    FunctionName funcName = request.funcName;
    serverObservers.doEach(
	  new InformObserver("done", struct, funcName));
  }

  /////////////////////////////////////////////////////
  //                 ServerObservers management
  /////////////////////////////////////////////////////

  void addObservable(NinfServerHolder holder){
    serverObservers.doEach(new AddObservable(holder));

  }
  void addObserver(ServerObserver obs){
    serverObservers.add(obs);
    servers.doEach(new AddObserver(obs));
  }

  void removeObserver(ServerObserver obs){
    obs.removeSelf();
    serverObservers.remove(obs);
  }

  /////////////////////////////////////////////////////
  //                 Inner functions  
  /////////////////////////////////////////////////////

  class NewerThan implements BooleanFunction{
    long time;
    public boolean eval(Object o){
      return ((NinfServerHolder)o).updateTime > time;
    }
    NewerThan(long time){
      this.time = time;
    }
  }

  class ServerHolderMatch implements BooleanFunction{
    NinfServerStruct serverStruct;
    public boolean eval(Object o){
      return (((NinfServerHolder)o).struct).equals(serverStruct);
    }
    ServerHolderMatch(NinfServerStruct serverStruct){
      this.serverStruct = serverStruct;
    }
  }

  class ServerIndexMatch implements BooleanFunction{
    NinfServerStruct serverStruct;
    public boolean eval(Object o){
      return (((ServerIndex)o).server).equals(serverStruct);
    }
    ServerIndexMatch(NinfServerStruct serverStruct){
      this.serverStruct = serverStruct;
    }
  }
  class AddObserver implements VoidFunction{
    ServerObserver obs;
    AddObserver(ServerObserver obs){
      this.obs = obs;
    }
    public void eval(Object o){
      obs.addObservable((NinfServerHolder)o);
    }
  }

  class InformObserver implements VoidFunction{
    String str;
    NinfServerStruct struct;
    FunctionName funcName;

    InformObserver(String str, NinfServerStruct struct, FunctionName funcName){
      this.str = str;
      this.struct = struct;
      this.funcName = funcName;
    }
    public void eval(Object o){
      ((ServerObserver)o).inform(str, struct, funcName);
    }
  }

  class AddObservable implements VoidFunction{
    NinfServerHolder holder;
    AddObservable(NinfServerHolder holder){
      this.holder = holder;
    }
    public void eval(Object o){
      ((ServerObserver)o).addObservable(holder);
    }
  }

}



