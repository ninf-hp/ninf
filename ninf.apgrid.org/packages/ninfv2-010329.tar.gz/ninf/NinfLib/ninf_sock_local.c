/*
 *  $Id: ninf_sock_local.c,v 1.4 2000/03/07 09:05:43 tatebe Exp $
 */

#include <stdio.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <netinet/in.h>
#include <strings.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include "ninf_error.h"

int ninf_sock_local(char * filename)
{
  int s, length;
  char * tmp;
  struct sockaddr_in * saddri;
  struct sockaddr_un saddr;
  FILE * fp;

  unlink(filename);
  
#ifndef NO_UNIX_DOMAIN
  if ((s = socket(AF_UNIX,SOCK_STREAM,0)) < 0){
    perror("socket");exit(1);
  }
  memset(&saddr, 0, sizeof(saddr));
  saddr.sun_family = AF_UNIX;
  strcpy(saddr.sun_path, filename);
  if(bind(s, (struct sockaddr *)&saddr, sizeof(saddr)) < 0){
    perror("local bind:");
    ninf_error("cannot bind");
  }
#else
  if ((tmp = (char *)malloc(sizeof(struct sockaddr_in))) == NULL)
    ninf_error("can't malloc in sock_local");
  saddri = (struct sockaddr_in *)tmp;
  memset(saddri, 0, sizeof(struct sockaddr_in));
  saddri->sin_family = AF_INET;
  saddri->sin_port = 0;  
  saddri->sin_addr.s_addr = htonl(INADDR_ANY);

  if ((s = socket(PF_INET,SOCK_STREAM,0))< 0){
    perror("socket");exit(1);
  }
/*  set_sock_no_delay(s); */
/*  set_no_delay(s); */
  if(bind(s, (struct sockaddr *)saddri, sizeof(struct sockaddr_in)) < 0){
    perror("local bind:");
    ninf_error("filename is %s", filename);
  }
  length = sizeof(struct sockaddr_in);
  if (getsockname(s, (struct sockaddr *)saddri, &length) < 0){
    perror("getting socket name");
    exit(1);
  }

/*  fprintf(stderr, "bound to port:%d address:%d\n", saddri->sin_port, saddri->sin_addr.s_addr);
*/
  if ((fp = fopen(filename,"w")) == NULL){
    ninf_error("can't open file %s", filename);
    exit(1);
  }
  fprintf(fp, "%ld %d", saddri->sin_addr.s_addr, saddri->sin_port);
  fclose(fp);
#endif

  return s;
}
