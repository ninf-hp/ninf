#define _WRAPPER_
/* $Id: pclahrd_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define SCOMPLEX
#include <gscalapack.h>

#define ROW_a lda
#define COL_a (n-k+1)
#define ROW_t ldt
#define COL_t nb
#define ROW_y ldy
#define COL_y n
static	int worklen(int n,int nb) {
	  int ret=1;
	  ret = n;
	  if NEED_BUFF {
	    ret = nb;
	  }
	  return ret;
}

void  pclahrd_ninf(	 int n,
		 int k,
		 int nb,
		 scomplex global_a[],
		 int lda,
		 scomplex global_tau[],
		 scomplex global_t[],
		 int ldt,
		 scomplex global_y[],
		 int ldy
)
/* "pclahrd reduces the first NB columns of a complex general N-by-(N-K+1) distributed matrix A so that elements below the k-th subdiagonal are zero. The reduction is performed by an unitary similarity transformation Q' * A * Q. The routine returns the matrices V and T which determine Q as a block reflector I - V*T*V', and also the matrix Y = A * V * T. This is an auxiliary routine called by PCGEHRD. " */
/* OPTIONS */
{

	int maxldd;

	int maxlda;
	scomplex *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
	int row_loca, col_loca;

	int maxldy;
	scomplex *locy=NULL;
	int descy[DESCLEN];
	int desc_gy[DESCLEN];
	int row_locy, col_locy;

	scomplex *loctau=NULL;

	int maxldt;
	scomplex *loct=NULL;
	int desct[DESCLEN];
	int desc_gt[DESCLEN];
	int row_loct, col_loct;

	scomplex *locwork=NULL;
	int llocwork;


	INITIALIZE();

	SCALAR( "int", n);
	SCALAR( "int", k);
	SCALAR( "int", nb);
	SCALAR("int", lda);
	SCALAR("int", ldt);
	SCALAR("int", ldy);

	ROW( a);
	COL( a);
	ROW(t);
	COL(t);
	ROW(y);
	COL(y);
	MAXLDD( maxldd, a );
	maxlda = maxldd;
	maxldt = maxldd;
	maxldy = maxldd;

	MATRIX( "scomplex", a, ROW_a, COL_a);
	VECTOR( "c", "scomplex", tau, n-1)
	MATRIX( "scomplex", t, ROW_t, COL_t);
	MATRIX( "scomplex", y, ROW_y, COL_y);
	DISTRIBUTE( "scomplex", a, ROW_a  , COL_a);

	llocwork = worklen(n,nb);
	WORK(locwork ,llocwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pclahrd)( &n, &k, &nb,
                               loca, &one, &one, desca,
                               loctau,
                               loct,
                               locy, &one, &one, descy,
                               locwork);

	GATHER( "scomplex", a, ROW_a  , COL_a);
	GATHER( "scomplex", y, ROW_y  , COL_y);
	vGATHER("c",  "scomplex", tau, n);
	GATHER( "scomplex", t, ROW_t  , COL_t);

	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
	} else {
	}

	FREE_MATRIX(a);
	FREE_MATRIX(t);
	FREE_VECTOR(tau);
	FREE_MATRIX(y);
        FREE(locwork);
}

