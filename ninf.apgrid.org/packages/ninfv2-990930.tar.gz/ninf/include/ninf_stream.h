#ifndef _NINF_STREAM_H_
#define _NINF_STREAM_H_

#include "ninf_data_trans.h"
#include "ninf_server_state.h"
int ninf_local_forkexec_outerr(char * stubname, int checkPid, server_state * state);
int ninf_local_forkexec       (char * stubname, int checkPid, connection ** pcon);
int ninf_local_forkexec_state (char * stubname, int checkPid, server_state * state);
int ninf_local_kill_state(server_state * state);
int ninf_local_kill(connection * con, int pid);
int ninf_connect_remote(char * hostname, char * service);

#endif
