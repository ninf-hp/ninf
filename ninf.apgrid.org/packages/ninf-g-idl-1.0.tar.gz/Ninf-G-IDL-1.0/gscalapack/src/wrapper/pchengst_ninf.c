#define _WRAPPER_
/* $Id: pchengst_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define SCOMPLEX
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n
#define ROW_b ldb
#define COL_b n
static	int worklen(int n) {
	  int ret;
	  int NP0, NQ0;
          ret = 2 * n * n + n *n + n * n;
	  if NEED_BUFF {
	    NP0 = NUMROC( N, NB, 0, 0, NPROW );
	    NQ0 = NUMROC( N, NB, 0, 0, NPROW );
	    ret = 2 * NP0 * NB + NQ0 * NB + NB * NB;
	  }
	  return ret;
}

void  pchengst_ninf(	 int ibtype,
			 char uplo,
			 int n,	/*  n >= 0 */
			 scomplex global_a[],
			 int lda,
			 scomplex global_b[],
			 int ldb,
			 float *scale,
			 scomplex work[],
			 int lwork,
			 int *info
)
/* "pchengst reduces a complex Hermitian-definite generalized\\n eigenproblem to standard form." */
/* OPTIONS */
{
	int maxldd;

	int maxlda;
	scomplex *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
	int row_loca, col_loca;

	int maxldb;
	scomplex *locb=NULL;
	int descb[DESCLEN];
	int desc_gb[DESCLEN];
	int row_locb, col_locb;

	scomplex *locwork=NULL;
	int llocwork;

	float locscale[1];

	INITIALIZE();

	SCALAR("int",ibtype);
	SCALAR("char",uplo);
	SCALAR("int",n);
	SCALAR("int",lda);
	SCALAR("int", ldb);
        SCALAR("int",lwork);

	ROW(a);
	COL(a);
	ROW(b);
	COL(b);
	MAXLDD(maxldd, a);
	maxlda=maxldd;
	maxldb=maxldd;

	trMATRIX( uplo,"scomplex", a, ROW_a ,COL_a );
	trDISTRIBUTE( uplo, "scomplex", a, ROW_a,COL_a  );
	MATRIX("scomplex", b, ROW_b,COL_b );
	DISTRIBUTE("scomplex", b, ROW_b,COL_b  );

	llocwork = worklen(n);
        llocwork = max(llocwork,lwork);
	WORK(locwork, llocwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pchengst)( &ibtype, &uplo, &n,
                                loca, &one, &one, desca,
                                locb, &one, &one, descb,
                                locscale,
                                locwork, &llocwork, &linfo);

	GATHER("scomplex", a, ROW_a, COL_a );
	RETRIEVE("float", locscale, 1);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
	  *info = linfo;
	  *scale = locscale[0];
	} else {
	}

	FREE_MATRIX(a);
	FREE_MATRIX(b);
	FREE(locwork);
}

