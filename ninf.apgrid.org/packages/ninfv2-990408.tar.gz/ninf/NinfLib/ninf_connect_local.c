#include <stdio.h>
#include <sys/types.h>
#include <sys/time.h>

#include <strings.h>
#include <stdlib.h>
#include <stdarg.h>
#ifndef WIN32
#include <sys/socket.h>
#else
#include <Winsock.h>
#endif
#include <netinet/in.h>
#include "ninf_macros.h"
#include "ninf_error.h"

#define SOCKADD_SIZE 100

int ninf_connect_local(char * filename)
{
  int s;
  char * tmp;
  struct sockaddr_in * saddri;
  struct sockaddr * saddr;
  char buf[10];
  FILE * fp;
  int port;
  long address;

  if ((tmp = (char *)malloc(SOCKADD_SIZE)) == NULL)
    ninf_error("can't malloc in connect_local");
  
#ifndef NO_UNIX_DOMAIN
  if ((s = socket(AF_UNIX,SOCK_STREAM,0))< 0){
    perror("socket");exit(1);
  }
  saddr = (struct sockaddr *)tmp;
  saddr->sa_family = AF_UNIX;
  strncpy(saddr->sa_data, filename, strlen(filename)+1);
/*  if(connect(s, saddr, strlen(filename)+2) < 0){ */
  if(connect(s, saddr, SOCKADD_SIZE) < 0){ 
    perror("local connect:");
    ninf_error("filename is %s", filename);
    return -1;
  }
#else 
  if ((fp = fopen(filename,"r")) == NULL){
    ninf_error("can't open file %s", filename);
    return -1;
  }
  fscanf(fp, "%ld%d", &address, &port);

/*  fprintf(stderr, "connecting to port:%d address:%ld\n",port, address);
*/
  saddri = (struct sockaddr_in *)tmp;
  saddri->sin_family = AF_INET;
  saddri->sin_port = port;
  saddri->sin_addr.s_addr = address;

  if ((s = socket(PF_INET,SOCK_STREAM,0))< 0){
    perror("socket");exit(1);
  }

  if(connect(s, (struct sockaddr *)saddri, sizeof(*saddri)) < 0){
    perror("local connect:");
    ninf_error("filename is %s", filename);
  }
#endif
  return s;
}


