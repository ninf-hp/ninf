#define _WRAPPER_
/* $Id: pdsytd2_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */

#define _DISTRIBUTE_1D_
#define DOUBLE
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n

static	int worklen(int n) {
	  int ret=1;
	  ret = 3*n;
	  return ret;
}

void  pdsytd2_ninf(	 char uplo,
		 int n,
		 double global_a[],
		 int lda,
		 double global_d[],
		 double global_e[], //uplo
		 double global_tau[],
		 int *info
)
/* "pdsytd2 reduces a real symmetric matrix A to symmetric tridiagonal form T by an orthogonal similarity transformation:  Q' * A * Q = T." */
/* OPTIONS */
{
	int maxldd;

	int maxlda;
	double *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
	int row_loca, col_loca;

	double *locd=NULL;
	double *loce=NULL;
	int desctdd[DESCLEN];
	int desc_gtdd[DESCLEN];

	double *loctau=NULL;

	double *locwork=NULL;
	int llocwork;


	INITIALIZE();

	SCALAR( "char", uplo);
	SCALAR( "int", n);
	SCALAR( "int", lda);
	SIZE(n);

	ROW( a);
	COL( a);
	MAXLDD( maxldd, a );
	maxlda = maxldd;
	//	maxldd = maxldd;
	//	maxlde = maxldd;

	trMATRIX( uplo, "double", a, ROW_a, COL_a);
	trDISTRIBUTE( uplo, "double", a, ROW_a  , COL_a);
	if (chrcmp(uplo,'U')==0) tdMATRIX("double" , 0, d, e, n);
	else tdMATRIX("double" , e, d, 0, n);
	VECTOR( "c", "double", tau, n);

	llocwork=worklen(n);
	WORK(locwork, llocwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pdsytd2)( &uplo, &n,
                               loca, &one, &one, desca,
                               locd, loce,
                               loctau,
                               locwork, &llocwork, &linfo);

	trGATHER( uplo, "double", a, ROW_a, COL_a);
	if (chrcmp(uplo,'U')==0) tdGATHER("double", 0, d, e, n);
	else tdGATHER( "double", e, d, 0, n);
	vGATHER( "c", "double", tau, n);

	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
	  *info = linfo;
	} else {
	}

	FREE_MATRIX(a);
	FREE_MATRIX(d);
	FREE_MATRIX(e);
        FREE_VECTOR(tau);
	FREE(locwork);
}

