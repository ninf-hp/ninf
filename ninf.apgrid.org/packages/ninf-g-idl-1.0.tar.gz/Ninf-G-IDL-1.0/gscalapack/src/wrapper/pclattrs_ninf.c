#define _WRAPPER_
/* $Id: pclattrs_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define SCOMPLEX
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n
#define ROW_x ldx
#define COL_x n

void  pclattrs_ninf(
		 char uplo,
		 char trans,
		 char diag,
		 char normin,
		 int n,	/*  n >= 0 */
		 scomplex global_a[],
		 int lda,
		 scomplex global_x[],
		 int ldx,
		 float *scale,	
		 float cnorm[],	
		 int *info
)
/* "pclattrs solves one of the triangular systems     A * x = s*b, A**T * x = s*b,  or  A**H * x = s*b,  with scaling to prevent overflow." */
/* OPTIONS */
{
	int maxldd;

	int maxlda;
	scomplex *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
	int row_loca, col_loca;

	int maxldx;
	scomplex *locx=NULL;
	int descx[DESCLEN];
	int desc_gx[DESCLEN];
	int row_locx, col_locx;

	float lscale[1];

	INITIALIZE();

	SCALAR("char",uplo);
	SCALAR("char",trans);
	SCALAR("char",diag);
	SCALAR("char",normin);
	SCALAR("int",n);
	SCALAR( "int", lda);
	SCALAR( "int", ldx);

	if (mypnum!=0) {
            cnorm = MALLOC(sizeof(float)*n);
            assert(cnorm);
        }

	ROW(a );
	COL(a );
	MAXLDD(maxldd,a );
	maxlda=maxldd;

	ROW(x);
	COL(x);
	MAXLDD(maxldd, x);
	maxldx=maxldd;

	MATRIX("scomplex",a,ROW_a,COL_a);
	MATRIX("scomplex",x,ROW_x,COL_x );
	DISTRIBUTE("scomplex", a,ROW_a,COL_a  );
	DISTRIBUTE("scomplex", x,ROW_x, COL_x );

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pclattrs)( &uplo, &trans, &diag,
                                &normin, &n,
                                loca, &one, &one, desca,
                                locx, &one, &one, descx,
                                lscale, cnorm, &linfo);

	GATHER("scomplex", x, ROW_x, COL_x);

	RETRIEVE( "float", lscale, 1);
	RETRIEVE( "float", cnorm, n);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
		*info = linfo;
		*scale = lscale;
	} else {
		FREE(cnorm);
	}

	FREE_MATRIX(a);
	FREE_MATRIX(x);
	
}

