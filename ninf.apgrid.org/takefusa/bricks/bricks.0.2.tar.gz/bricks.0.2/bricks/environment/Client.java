package bricks.environment;
import bricks.util.*;
import bricks.scheduling.*;
import java.io.*;
import java.util.*;

/** 
 * Client.java
 * <pre>
 * Client represents the host machine function, upon which Grid computing 
 * tasks are initiated by the user program.
 * </pre>
 */
public class Client extends Node implements Cloneable {

    /** The scheduler that allocates a new task of the client. */
    protected Scheduler scheduler;
    
    /** The host that contains this client. */
    protected Host host;
    
    /** The size of transmitted data from the client to a server. */
    protected Sequence dataSizeForSend;

    /** The size of transmitted data from a server to the client. */
    protected Sequence dataSizeForReceive;

    /** The number of executed instructions (operations) in the task. */
    protected Sequence numInstructions;

    /** The interval that the Client invokes tasks. */
    protected Sequence throwingInterval;

    /** Required DataFragment ID. */
    protected Strings dataIDs;

    /** Stored Result to these Hosts. */
    protected Strings dataDestinations;

    /** This is the factor which decides deadlines of each RequestData. */
    protected Sequence deadlineFactors;

    protected Hashtable hashtableOfRoutes = new Hashtable();
    protected Vector scheduledData = new Vector();

    /** 
     * The variable for event flags.
     */
    protected static final int DISPATCH      = 0;
    protected static final int SEND_DATA     = 1;
    protected static final int SEND_PACKET   = 2;
    protected static final int DIVIDE_PACKET = 3;
    protected static final int RESCHEDULE    = 4;

    protected Vector rescheduledList = new Vector();

    /**
     * Constructor for NullClient.
     */
    public Client() {;}

    /**
     * Constructs a Client for Obj.java's main().
     */
    public Client(String key) {
	this.key = key;
	init();
    }

    /** 
     * Constructs a Client with
     *     owner : a SimulationSet of your configuration,
     *     key : a key of the Client,
     *     keyOfScheduler : a key of the scheduler that allocates 
     *                      a new task of the Client,
     *     dataSizeForSend : dataSizeForSend of the Client,
     *     dataSizeForReceive : dataSizeForReceive of the Client,
     *     numInstructions : numInstructions of the Client,
     *     throwingInterval : throwingInterval of the Client.
     */
    public Client(
	SimulationSet owner, String key, String keyOfScheduler,
	Sequence dataSizeForSend, Sequence dataSizeForReceive,
	Sequence numInstructions, Sequence throwingInterval
    ) {
	this.owner = owner;
	this.key = key;
	scheduler = owner.getScheduler(keyOfScheduler);
	this.dataSizeForSend = dataSizeForSend;
	this.dataSizeForReceive = dataSizeForReceive;
	this.numInstructions = numInstructions;
	this.throwingInterval = throwingInterval;
	init();

	logWriter = null;
    }

    /**
     * Constructor for EPClient.
     **/
    public Client(
	SimulationSet owner, String key, String keyOfScheduler, 
	Sequence numTasks, 
	Sequence dataSizeForSend, Sequence dataSizeForReceive,
	Sequence numInstructions, Sequence throwingInterval
    ) {;}

    /**
     * Functions which initialize Client instances.
     */
    public void setDataIDs(Strings dataIDs) {
	this.dataIDs = dataIDs;
    }

    public void setDataDestinations(Strings dataDestinations) {
	this.dataDestinations = dataDestinations;
    }

    public void setDeadlineFactors(Sequence deadlineFactors) {
	this.deadlineFactors = deadlineFactors;
    }

/************************* needed method *************************/
    /** 
     * generates a clone of the Client.
     */
    public synchronized Object clone() {
        try {
            Client c = (Client)super.clone();
            return c;
        } catch (CloneNotSupportedException e) {
            // this shouldn't happen, since we are Cloneable
            throw new InternalError();
        }
    }

    /** 
     * returns a type of the Client.
     */
    public String getName() {
	return "Client";
    }

    /**
     * sets host.
     */
    public void setHost(Host host) {
	this.host = host;
	host.setScheduler(scheduler);
    }

    /** 
     * processEvent
     *     SEND_PACKET : sends the first packet of queue of the Packets.
     *     DISPATCH : dispatches the nextData.
     *     DIVIDE_PACKET : invokes data and decompose it into logical packets.
     *     RESCHEDUET : dispatch data whose schedule failed.
     */
    public void processEvent(double currentTime) {
	if (event == DISPATCH) {
	    //System.out.println(
	    SimulationDebug.println(
		"Client:" + Format.format(currentTime, precision) + 
		":" + host + ": DISPATCH [" + nextData + "]"
	    );
	    dispatchHosts(currentTime, (RequestedData)nextData);
	    nextData = getNextData(currentTime);

	} else if (event == DIVIDE_PACKET) {
	    RequestedData rd = (RequestedData)scheduledData.firstElement();
	    scheduledData.removeElementAt(0);
	    //System.out.println(
	    SimulationDebug.println(
		"Client:" + Format.format(currentTime, precision) + ":" +
		host + ": DIVIDE_PACKET [" + rd + "]"
	    );
	    host.sendData(currentTime, rd);

	} else { /* RESCHEDULE */
	    RequestedData d = (RequestedData)rescheduledList.firstElement();
	    //System.out.println(
	    SimulationDebug.println(
		"Client:" + Format.format(currentTime, precision) + 
		":" + host + ": RESCHEDULE [" + d + "]"
	    );
	    rescheduledList.removeElementAt(0);
	    dispatchHosts(currentTime, d);
	}
    }

    /** 
     * updates the event.
     */
    public void updateNextEvent(double currentTime) {
	event = DISPATCH;
	double earliestTime = nextData.timeEventComes;
	if (!scheduledData.isEmpty()) {
	    RequestedData td = (RequestedData)scheduledData.firstElement();
	    if (td.timeEventComes < earliestTime) {
		earliestTime = td.timeEventComes;
		event = DIVIDE_PACKET;
	    }
	}
	if (!rescheduledList.isEmpty()) {
	    RequestedData d = (RequestedData)rescheduledList.firstElement();
	    if (d.timeEventComes < earliestTime) {
		earliestTime = d.timeEventComes;
		event = RESCHEDULE;
	    }
	}
	nextEventTime = earliestTime;
    }

    public String toOriginalString(double currentTime) {
	String str = "  [" + getName() + " " + key + "]\n";
	str += "  nextData : " + nextData.toOriginalString();
	return str;
    }

    public String toInitString() {
	String str = "  [" + getName() + " " + key + "] : ";
	str += scheduler + ", " + dataSizeForSend.mean + ", " +
	    dataSizeForReceive.mean + ", " + numInstructions.mean + 
	    ", " + throwingInterval.mean + "\n";
	return str;
    }

    /** 
     * calls the data's outLogString when the RequestData 
     * returns to the Client.
     */
    public void schedule(double currentTime, Data data) {;}

    /**
     * for fallback
     **/
    public void fallback(double currentTime, RequestedData data) {
	//System.out.println("===== FALLBACK!! =====");
	scheduler.finishTask(data);
	data.flash();
	dispatchHosts(currentTime, data);
	updateNextEvent(currentTime);
    }

/************************* protected method *************************/
    protected Data getNextData(double currentTime) {
	double timeEventComes =
	    currentTime + throwingInterval.nextDouble(currentTime);
	RequestedData rd = new RequestedData(
	    host, timeEventComes, dataSizeForSend.nextDouble(), 
	    dataSizeForReceive.nextDouble(), numInstructions.nextDouble()
	);
	if (dataIDs != null) {
	    rd.setRequiredDataID(dataIDs.nextString(rd.dataSizeForSend));
	}
	if (dataDestinations != null) {
	    String hostID = dataDestinations.nextString();
	    rd.setDataDestination(owner.getHost(hostID));
	}
	if (deadlineFactors != null) { /* deadline scheduling */
	    SimulationDebug.println(host + ": has deadlineFactor!");
	    rd.setDeadlineFactor(deadlineFactors.nextDouble());
	}
	return rd;
    }

    protected void dispatchHosts(double currentTime, RequestedData data) {
	//System.out.println(
	SimulationDebug.println(
	    Format.format(currentTime, precision) + " : " + host + " : " +
	    scheduler + " [" + data + "]");
	if (data.startTime < 0.0) {
	    data.startTime = currentTime;
	}
	
	try {
	    if ((data.deadline < 0.) && (data.deadlineFactor > 0)) {
		data.deadline = scheduler.getDeadline(currentTime, data);
	    }
	    scheduler.selectHosts(currentTime, host, data);
	    /* Scheduled! */
	    //System.out.println(
	    SimulationDebug.println(
		Format.format(currentTime, precision) + " : " + host + 
		" [" + data + "] dispatched into " + data.destination);
	    data.initRoute(currentTime, data.destination, owner);
	    //scheduledData.addElement(nextData);
	    scheduledData.addElement(data);
	    //System.out.println("--- " + scheduledData + " ---");

	} catch (BricksNotScheduledException e) {
	    /* Reschedule! */
	    addIntoRescheduledList(data);
	    SimulationDebug.println(e);
	    //System.out.println(e);
	    //System.out.println(
	    SimulationDebug.println(
		Format.format(currentTime, precision) + ": RESCHEDULE " + 
		host + " [" + data + "] " + 
		Format.format(data.timeEventComes, precision) + "\n"
	    );
	}
    }

    /*
    protected void initRoute(
	double currentTime, RequestedData data, Host destination
    ) {
	Vector route = (Vector)owner.getRouteForLoad(host, destination);
	Vector stoc = (Vector)owner.getRouteForStore(destination, host);
	int indexOfDestination = route.size() - 1;
	stoc.remove(0); // remove destination;
	Enumeration e = stoc.elements();
	while (e.hasMoreElements()) {
	    route.addElement(e.nextElement());
	}
	//SimulationDebug.println(data + " 's route = {" + route + "}");
	data.initRoute(currentTime, route, destination, indexOfDestination);
    }
    */

    protected void addIntoRescheduledList(RequestedData data) {

	if (rescheduledList.size() == 0) {
	    rescheduledList.addElement(data);

	} else {
	    int cnt = 0;
	    Enumeration e = rescheduledList.elements();
	    while (e.hasMoreElements()) {

		RequestedData d = (RequestedData)e.nextElement();
		if (d.timeEventComes > data.timeEventComes) {
		    int index = rescheduledList.indexOf(d);
		    rescheduledList.insertElementAt(data, index);
		    break;
		}
		cnt++;
	    }
	    if (cnt == rescheduledList.size()) {
		rescheduledList.addElement(data);
	    }
	}
    }
}


