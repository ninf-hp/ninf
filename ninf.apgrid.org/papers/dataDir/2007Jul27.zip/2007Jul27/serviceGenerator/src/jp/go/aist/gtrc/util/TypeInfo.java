package jp.go.aist.gtrc.util;

public class TypeInfo {
	SchemaInfo schemaInfo;
	public String xmlName;
	public String name;

	public TypeInfo(SchemaInfo schemaInfo, String xmlName, String name) {
		this.schemaInfo = schemaInfo;
		this.xmlName = xmlName;
		this.name = name;
	}
}
