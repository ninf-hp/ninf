package ninf.metaserver;

public interface LPinger extends Runnable{
    public LPinger setup(NinfServerHolder target, int interval);
}
