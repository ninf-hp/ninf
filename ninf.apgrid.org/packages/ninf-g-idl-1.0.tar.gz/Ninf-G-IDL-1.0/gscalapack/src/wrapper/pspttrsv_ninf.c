#define _WRAPPER_
/* $Id: pspttrsv_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define _DISTRIBUTE_1D_
#define FLOAT
#include <gscalapack.h>

#define ROW_b ldb
#define COL_b nrhs
static	int worklen(int nrhs) {
	  int ret=1;
	  ret =  (10+2*min(100,nrhs))+4*nrhs;
	  if NEED_BUFF {
	    ret =  (10+2*min(100,nrhs))*npcol+4*nrhs;
	  }
	  return ret;
}


void  pspttrsv_ninf(	 char uplo,
			 int n,
			 int nrhs,
			 float global_d[],
			 float global_e[], //upper
			 float global_b[],
			 int ldb,
			 int *info
)
/* "pspttrsv solves a tridiagonal triangular system of linear equations A * X = B  or A^T * X = B where A is a tridiagonal triangular matrix factor produced by the Cholesky factorization code PSPTTRF and is stored in A and AF." */
/* OPTIONS */
{
    extern void FortranCall(pspttrsv)( char*, int*, int*,
                                float*, float*, int*, int*,
                                float*, int*, int*,
                                float*, int*,
                                float*, int*,
                                int*);

	int maxldd;

	float *locd=NULL,*loce=NULL;
	int desctdd[DESCLEN];
	int desc_gtdd[DESCLEN];

	int maxldb;
	float *locb=NULL;
	int descb[DESCLEN];
	int desc_gb[DESCLEN];
	int row_locb, col_locb;

	float *locwork=NULL;
	int llocwork;
	
	float *locaf=NULL;
	int laf;
	
	INITIALIZE();

	SCALAR( "char", uplo);
	SCALAR( "int", n);
	SCALAR( "int", nrhs);
	SCALAR( "int", ldb);
	SIZE(n);

	ROW(b);
	COL(b);
	MAXLDD( maxldd, b );
	maxldb=maxldd;

	tdMATRIX( "float", e, d, e, n);
	tdDISTRIBUTE( "float", e, d, e, n);

	MATRIX( "float", b, ROW_b, COL_b);
	DISTRIBUTE( "float" , b, ROW_b, COL_b);

	laf = blocsize+2;
	locaf = MALLOC(sizeof(float)*laf);
        assert(locaf);

	llocwork = worklen(nrhs);
	WORK(locwork, llocwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pspttrsv)( &uplo, &n, &nrhs,
                                locd, loce, &one, desctdd,
                                locb, &one, descb,
                                locaf, &laf,
                                locwork, &llocwork,
                                &linfo);

	tdGATHER( "float", e, d, e, n);
	GATHER( "float", b, ROW_b, COL_b);

	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
		*info = linfo;
	} else {
	}
	FREE_MATRIX(d);
	FREE_MATRIX(e);
	FREE_MATRIX(b);
        FREE(locaf);
        FREE(locwork);
	
}

