#include "ninf_data_trans.h"
#include "ninf_error.h"
#include "connection.h"
#include "ninf_macros.h"
#ifdef SSL_USE
#include "ninf_ssl.h"
#endif

#define SOCK_BUF_SIZE 0x10000

connection * new_connection(int fd, int withHeader, int accepting
#ifdef SSL_USE
   , SSL_CTX * ctx
#endif			    
){
  connection * tmp;
  int size = SOCK_BUF_SIZE;
#ifdef SSL_USE
  SSL * ssl = NULL;

  if (ctx != NULL) {
    ssl = SSL_new(ctx);
    if (ssl == NULL)
      return NULL;
    /* bind ssl and fd */
    SSL_set_fd (ssl, fd);
  }
#endif			    
  
  if ((tmp = (connection *)malloc(sizeof(connection))) == NULL)
    return NULL;

#ifdef SSL_USE
  tmp->ctx = ctx;
  tmp->ssl = ssl;
  tmp->sDT = new_dataTrans(fd, XDR_ENCODE, withHeader, ssl);
  tmp->rDT = new_dataTrans(fd, XDR_DECODE, withHeader, ssl);
  if (ctx != NULL){
    if (accepting){
      if (!ninf_ssl_accept(tmp))
	return NULL;
    } else {
      if (!ninf_ssl_connect(tmp))
	return NULL;
    }
  }
#else
  tmp->sDT = new_dataTrans(fd, XDR_ENCODE, withHeader);
  tmp->rDT = new_dataTrans(fd, XDR_DECODE, withHeader);
  setsockopt(fd, SOL_SOCKET, SO_SNDBUF, (char *)&size, sizeof(int));
  setsockopt(fd, SOL_SOCKET, SO_RCVBUF, (char *)&size, sizeof(int));
#endif			    
  if (tmp->rDT == NULL || tmp->sDT == NULL)
    return NULL;
  tmp->accepting = accepting;
  return tmp;
}

void free_dataTrans(dataTrans *);

int ninf_disconnect(connection * con){
  /*  shutdown(connection_get_fd(con), 1); */
  /* set_no_delay(connection_get_fd(con)); */

  if (con->accepting)
    connection_read_onemore(con); /* dummy read to flush input buffer 
				     to ensure reuse of address */
  /* to reuse the port, the accepting socket have to wait the peer
     to close the socket */
  if (close(con->rDT->fd) < 0)
    ninf_error("close in ninf_disconnect %s", strerror(errno));

  free_dataTrans(con->rDT);
  free_dataTrans(con->sDT);
  free(con);

  return 0;
}


/** This method just close the sockets and frees structure,
    without doing any closing manipulation. 
    This method is intended to be called by parent process. */
int connection_close(connection * con){
  if (close(con->rDT->fd) < 0)
    ninf_error("close in ninf_disconnect %s", strerror(errno));
  return 0;
}

int connection_get_fd(connection * con){
  if (con == NULL)
    return -1;
  return con->rDT->fd;
}

int connection_set_non_block(connection * con){
  int fd = connection_get_fd(con);
  return set_non_block(fd);
}

int connection_read_onemore(connection * con){
  return read_onemore(con->rDT);
}
