#define _WRAPPER_
/* $Id: pdpotri_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define DOUBLE
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n
void  pdpotri_ninf(	 char uplo,
		 int n,
		 double global_a[],
		 int lda,
		 int *info
)
/* "pdpotri computes the inverse of a real symmetric positive definite distributed matrix A using the Cholesky factorization  A = U**T*U or L*L**T computed by PSPOTRF." */
/* OPTIONS */
{
    extern void FortranCall(pdpotri)( char*, int*, double*, int*, int*, int*, int*);
	int maxldd;

	int maxlda;
	double *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
	int row_loca, col_loca;

	INITIALIZE();

	SCALAR( "char", uplo);
	SCALAR( "int", n);
	SCALAR( "int", lda);

	ROW( a);
	COL( a);
	MAXLDD( maxldd, a );
	maxlda = maxldd;
        
	trMATRIX( uplo, "double", a, ROW_a, COL_a);
	trDISTRIBUTE( uplo,  "double", a, ROW_a, COL_a);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pdpotri)( &uplo, &n, loca, &one, &one, desca, &linfo);

	GATHER( "double", a, ROW_a, COL_a);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
		*info = linfo;
	} else {
	}

	FREE_MATRIX(a);
}

