#include <stdio.h>
#include <math.h>
#include "ninf_stub.h"

#define N    5

print_info(FILE *fp, exec_info * e_info){
  fprintf(fp, "%lf  %lf  %lf  %lf  %s:%d %d\n",
	  e_info->client_exec_time,
	  e_info->fore_time,
	  e_info->exec_time,
	  e_info->back_time,
	  e_info->hostname,
	  e_info->port,
	  e_info->call_serial);
}

double A[N][N],B[N][N],C[N][N],C0[N][N];

extern int ninf_debug_flag;
main(int argc, char ** argv)
{
    int i,j,r;
    double a;
    double x,x0;
    int n;
    exec_info * e_info; 

    argc = Ninf_parse_arg(argc, argv);
        ninf_debug_flag = 1; 

    a = 123.334;
    x = sin(a);
#if 0
    printf("sin(%f) = %f\n",a,x);

    x = 1.0;	/* clear */


    r = Ninf_call("sin",a,&x); 

    {
      char *buffer;
      int  mode[2];
      any_t arg[2];
      Ninf_get_stub("sin", mode, &buffer);
      printf("mode[0] = %d. mode[1] = %d.\n", mode[0], mode[1]);
      /*      r = Ninf_call_body(buffer, a, &x); */
      arg[0].u.d = a;
      arg[1].u.p = &x;
      r = Ninf_call_body_v(buffer, arg);
      if (r < 0)
	Ninf_perror("Ninf_Call_body: ");
    }

    printf("Ninf_call: r=%d sin(%f) = %f\n",r,a,x);
#endif 

    for(i = 0; i < N; i++)
      for(j = 0; j < N; j++)
	{
	  A[i][j] = i + 0.1 * j;
	  B[i][j] = 1 + i + 0.1 * j;
/*	    A[i][j] = rand();
	    B[i][j] = rand();
*/
	}
/*
    A[0][0] = 0.0;
    A[0][1] = 0.1;
    A[1][0] = 1.0;
    A[1][1] = 1.1;

    B[0][0] = 2.0;
    B[0][1] = 2.1;
    B[1][0] = 3.0;
    B[1][1] = 3.1;
*/

/*
    r = Ninf_call_async("ninf://localhost/sample/mmul",N,A,B,C);
    r = Ninf_sync(r);

*/
    n = N;
    {
      int ack;
      NINF_STUB_INFO * buffer;
      int  mode[30];
      any_t arg[30];
      ack = Ninf_get_stub("sample/mmul", mode, &buffer);
      if (ack != NINF_OK){
	Ninf_perror("mmul ");
      } else { 
	any_set_long   (&(arg[0]), (long)N);
	any_set_pointer(&(arg[1]), A);
	any_set_pointer(&(arg[2]), B);
	any_set_pointer(&(arg[3]), C);
	r = Ninf_call_body_v(buffer, arg);
	printf("Ninf_call:mmul r = %d\n",r);
	Ninf_perror("mmul ");
      } 
    }
    
    if ((e_info = Ninf_get_last_info()) != NULL){ 
      print_info(stdout, e_info); 
    }    

    mmul(N,A,B,C0);

/*    for (i=0;i<N;i++) {
	for (j=0;j<N;j++) {
	  printf("%f ",C[i][j]);
	}
	printf("\n");
    }
*/
    for(i = 0; i < N; i++)
      for(j = 0; j < N; j++)
	if(C[i][j] != C0[i][j]){
	  printf("C[%d][%d]= %e != %e\n",
		 i,j,C[i][j],C0[i][j]);
	  exit(1);
	}
    exit(0);

}

/* test routine */
mmul(n,A,B,C)
     double *A,*B,*C;
{
    double t;
    int i,j,k;
    
    printf("n0=%d\n",n);
    printf("A0(1,1)=%e\n",A[1*n+1]);
    printf("B0(1,1)=%e\n",B[1*n+1]);
    for (i=0;i<n;i++) {
	for (j=0;j<n;j++) {
	    t = 0;
	    for (k=0;k<N;k++){
		t += A[i*n + k] * B[k*n+j];	/* inner product */
	    }
	    C[i*n+j] = t;
	}
    }
    printf("C0(1,1)=%e\n",C[1*n+1]);
}
