#include "common.h"


l_mp3dx(int l_num_xcell, int l_num_ycell, int l_num_zcell, int l_bc_cnt, int * tmpint, float * tmpdata)
{
      mp3dx(l_num_xcell, l_num_ycell, l_num_zcell, l_bc_cnt, tmpint, tmpdata);
}

