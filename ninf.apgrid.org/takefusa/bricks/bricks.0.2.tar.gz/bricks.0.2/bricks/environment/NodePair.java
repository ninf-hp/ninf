package bricks.environment;
import bricks.util.*;
import bricks.scheduling.*;
import java.util.*;

public class NodePair implements Cloneable {

    public Node source;
    public Node destination;

    public NodePair(Node source, Node destination) {
	this.source = source;
	this.destination = destination;
    }

    /******************** needed method ********************/

    public int hashCode() {
	return source.hashCode() + destination.hashCode();
    }

    public boolean equals(Object o) {
	if (!(o instanceof NodePair))
	    return false;

	if ((source.key).compareTo((((NodePair)o).source).key) == 0 &&
	    (destination.key).compareTo((((NodePair)o).destination).key) == 0)
	    return true;
	else
	    return false;
    }

    public String toString() {
	return "[" + source + " - " + destination + "]";
    }

    /******************** public method for monitoring ********************/

    public synchronized Object clone() {
        try {
	    NodePair p = (NodePair)super.clone();
	    return p;
        } catch (CloneNotSupportedException e) {
            // this shouldn't happen, since we are Cloneable
            throw new InternalError();
        }
    }

    public void probe(
	SimulationSet owner, NetworkMonitor networkMonitor,
	double currentTime, double dataSize
    ) {
	SimulationDebug.println(networkMonitor + ": [" + this + "] " +
				" currentTime = " + currentTime +
				", dataSize" + dataSize);
	ProbeData pd = new ProbeData(
	    owner, this, networkMonitor, dataSize, currentTime
	);
	Network firstNetwork = (Network)pd.getNodeAt(0);
	firstNetwork.probe(currentTime, pd);
    }

    public void finishProbing(double currentTime, ProbeData probeData) {
	SimulationDebug.println(
	    this + ".finishProbing: " + Format.format(currentTime, 3) + 
	    " : probeData = " + probeData
	);
	double latency = currentTime - probeData.startTime;
	double currentThroughput = probeData.totalDataSize / latency;

	NetworkMonitor networkMonitor = probeData.networkMonitor;
	networkMonitor.collectNetworkInfo(
	    this,  
	    new NetworkInfo(this, currentTime, currentThroughput, latency)
	);
    }


    /************************* test *************************/

    public static void main(String[] argv) {

	Client c1 = new Client("c1");
	System.out.println("new Client c1 : " + c1);
	Client c2 = new Client("c2");
	System.out.println("new Client c2 : " + c2);

	Client c3 = new Client("c3");
	System.out.println("new Client c3 : " + c3);
	Client c4 = new Client("c4");
	System.out.println("new Client c4 : " + c4);

	NodePair p1 = new NodePair(c1, c2);
	NodePair p2 = new NodePair(c3, c4);

	NodePair p3 = (NodePair)p1.clone();

	System.out.println("comparison: p1(" + p1 + ") & p2(" + p2 + ")");
	if (p1.equals(p2))
	    System.out.println("p1 == p2");
	else
	    System.out.println("p1 != p2");

	System.out.println("comparison: p1(" + p1 + ") & p3(" + p3 + ")");
	if (p1.equals(p3))
	    System.out.println("p1 == p3");
	else
	    System.out.println("p1 != p3");
    }
}
