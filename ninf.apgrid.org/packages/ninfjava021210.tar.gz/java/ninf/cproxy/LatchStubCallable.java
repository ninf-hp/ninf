package ninf.cproxy;
import ninf.basic.*;
import ninf.basic.NinfErrorException;
import ninf.client.*;
import java.util.Vector;
import java.io.*;


/* read all the sending data then forward it*/

class LatchStubCallable extends StubCallable {
  LatchStubCallable(NinfStub stub, int index, ScheduleProvider master){
    super(stub, index, master);
  }

  public Stoppable call(NinfPacket pkt, int serial,
			XDRInputStream is, XDROutputStream os) 
  throws NinfException{
    NinfServerConnection con;
    StubCallableContext context;

    NinfPacketInputStream pis = new NinfPacketInputStream(pkt, is);    
    XDRInputStream dis = new XDRInputStream(pis);

    context = receiveNinfCode(pis);

    CallContext callContext = stub.setupBuffers(dis);
    context.modifyBuffers(callContext.buffers);
    stub.serverReceive(callContext, dis);

    ServerIndex server;    
    try {
      server = master.schedule(stub, callContext, serial);
    } catch (NinfException e){
      throw new NinfErrorException(NinfError.CPROXY_CANNOT_SCHEDULE);
    }

    if (server != null){
      con = server.server.connect();
      con.startForward(stub, server.index, callContext, is, os);
      return con;
    }
    dbg.log(stub.module_name + "/" + stub.entry_name + ": failed to be scheduled");
    NinfPacket.getErrorPacket(NinfError.CANTEXECUTESTUB).write(os);
    try {
      os.close();
    } catch (java.io.IOException e) {}
    return null;
  }
}
