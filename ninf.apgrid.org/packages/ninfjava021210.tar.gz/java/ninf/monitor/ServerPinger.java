package ninf.monitor;
import ninf.basic.*;
import ninf.common.*;
import ninf.client.*;
import ninf.cproxy.*;
import ninf.metaserver.*;

class ServerPinger extends ninf.cproxy.ServerTablePingerRoot {
  Monitor monitor;
  
  ServerPinger(MetaServerReference target, int interval, Monitor monitor){
    super(target, interval);
    this.monitor = monitor;
  }

  public void addNewServer(NinfServerStruct serverStruct){
      monitor.addNewServer(serverStruct);    
      monitor.functionTablePing();
  }
}
