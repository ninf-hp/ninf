#define _WRAPPER_
/* $Id: psdttrsv_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define _DISTRIBUTE_1D_
#define FLOAT
#include <gscalapack.h>

#define ROW_b n
#define COL_b nrhs
#define ROW_af laf
#define COL_af n
static int worklen(int nrhs) {
	  int ret=1;
	  ret = 10+4*nrhs;
	  if NEED_BUFF ret = 10*npcol+4*nrhs;
          return ret;
}

void  psdttrsv_ninf(	 char uplo,
			 char trans,
			 int n,
			 int nrhs,
			 float global_dl[],
			 float global_d[],
			 float global_du[],
			 float global_b[],
			 float af[],
			 int dummy_laf,
			 float  work[],
			 int lwork,
			 int *info
)
/* "psdttrsv solves a tridiagonal triangular system of linear equations A * X = B or A^T * X = B where A is a tridiagonal triangular matrix factor produced by the Gaussian elimination code psttrf and is stored in A and AF." */
/* OPTIONS */
{
    extern void FortranCall(psdttrsv)( char*, char*, int*, int*,
                                float*, float*, float*, int*, int*,
                                float*, int*, int*,
                                float*, int*,
                                float*, int*, int*);

	int maxldd;

	float *locdl=NULL, *locd=NULL, *locdu=NULL;
	int desctdd[DESCLEN];
	int desc_gtdd[DESCLEN];

	int maxldb;
	float *locb=NULL;
	int descb[DESCLEN];
	int desc_gb[DESCLEN];
	int row_locb, col_locb;

	float *locaf=NULL, *global_af=NULL;
	int maxldaf;
	int descaf[DESCLEN];
	int desc_gaf[DESCLEN];
	int laf, llocaf;
	int row_locaf, col_locaf;

	float *locwork=NULL;
	int llocwork;

	INITIALIZE();

	SCALAR( "char", uplo);
	SCALAR( "char", trans);
	SCALAR( "int", n);
	SCALAR( "int", nrhs);
	SCALAR("int", dummy_laf);
	SCALAR( "int", lwork);

	SIZE(n);

	laf = 2*(blocsize+2)*nprocs/n;
	llocaf = laf*blocsize;
	if (mypnum==0) {
	  global_af=MALLOC(sizeof(float)*laf*n);
          assert(global_af);
	}

	ROW(b);
	COL(b);
	ROW(af);
	COL(af);
	MAXLDD( maxldd, b);
	maxldb = maxldd;
	maxldaf = maxldd;

	tdMATRIX( "float", dl, d, du, n);
	MATRIX(  "float", b, ROW_b, COL_b);
	MATRIX( "float",  af, ROW_af, COL_af);
	tdDISTRIBUTE( "float", dl, d, du, n);
	DISTRIBUTE( "float", af, ROW_af, COL_af);

	llocwork=worklen(nrhs);
	WORK(locwork,llocwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(psdttrsv)( &uplo, &trans, &n, &nrhs,
                                locdl, locd, locdu, &one, desctdd,
                                locb, &one, descb,
                                locaf, &llocaf,
                                locwork, &llocwork, &linfo);

	tdGATHER( "float", dl, d, du, n);
	GATHER( "float", b, ROW_b, COL_b);
	GATHER( "float", af, ROW_af, COL_af);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
	  int i;
	  *info = linfo;
	  for(i=0;i<dummy_laf;i++) af[i]=global_af[i];
          FREE(global_af);
	} else {
	}
	FREE_MATRIX(dl);
	FREE_MATRIX(d);
	FREE_MATRIX(du);
	FREE_MATRIX(b);
	FREE_MATRIX(af);
        FREE(locwork);
	
}

