package ninf.metaserver;

class LoadOnlyNaive extends LoadOnlyScheduler{
  void updateLoad(ServerInformation tmp){
    // nothing to do.
  }
}
