/*
 *  $Id: throughput_measure.c,v 1.5 1999/02/09 12:46:00 nakada Exp $
 */

#include <stdio.h>
#include <unistd.h>
#include <sys/time.h>

#include "metaserver.h"
#include "ninf_config.h"
#include "ninf_data_trans.h"

extern char * myname;
extern char * ninf_server_service;

/************* communication_information ********************/

void send_communication_information(communication_information * com, metaConnection * meta){
  metaserver_send(meta, "communicationInformation %ld %d %d %ld", 
		  com->rtt, com->size, com->mode, 0);
}
communication_information * new_communication_information(int size, int mode){
  communication_information * tmp = 
    (communication_information *)malloc(sizeof(communication_information));
  if (tmp != NULL);
  tmp->size = size;
  tmp->mode = mode;
  return tmp;
}


/***************** measure_server ******************/

void init_comm_measure_server(measure_server * m){
  m->throughput = new_communication_information(measure_size, 0); /* dual mode */
  m->latency    = new_communication_information(0, 0); /* dual mode */
}

int count_measure_server(measure_server * m){
  if (m == NULL) return 0;
  return count_measure_server_rec(m, 0);
}

int count_measure_server_rec(measure_server * m, int i){
  i++;
  if (m->next == NULL)
    return i;
  return count_measure_server_rec(m->next, i);
}

measure_server * nth_measure_server(measure_server * m, int index){
  int counter = 0;
  while (m != NULL){
    if (index == counter)
      return m;
    counter++;
    m = m->next;
  }
  return NULL;
}

measure_server * new_measure_server(measure_server * link){
  measure_server * tmp = (measure_server *) malloc(sizeof(measure_server));
  init_comm_measure_server(tmp);

  if (tmp != NULL) tmp->next = link;
  return tmp;
}

/********************** measure ***********************/

int measure_rtt(connection * con, communication_information * com){
  struct timeval t1, t2;
  int size = com->size;
  int mode = com->mode;
  gettimeofday(&t1, NULL);
  trans_flush(con->sDT, NINF_PKT_THROUGHPUT, size, mode);

  if (mode == 0 || mode == 1){
    trans_write_skip(con->sDT, size);
    write_flush(con->sDT);
  }
  if (trans_getPacket(con->rDT) != NINF_PKT_RPY_THROUGHPUT){
    ninf_log("error occured while measuring throughput");
    return FALSE;
  }  
  if (mode == 0 || mode == 2)
    trans_read_skip(con->rDT, size);
  
  gettimeofday(&t2, NULL);
  com->rtt = (t2.tv_sec - t1.tv_sec)*1000000L + (t2.tv_usec - t1.tv_usec);
  return TRUE;
}

void inform_communication_information(measure_server * server,
				      metaConnection * meta){
  
  metaserver_send(meta, "throughputInfo");
  metaserver_send(meta, "server %s %s", myname, ninf_server_service);
  metaserver_send(meta, "server %s %s", server->host, server->port);
  send_communication_information(server->throughput, meta);
  send_communication_information(server->latency, meta);
  metaserver_send(meta, "endThroughputInfo");
}

void measure_one_server(measure_server * server){
  metaConnection * meta;
  int fd;
  connection * con;

  fd = ninf_connect_remote(server->host, server->port);
  if (fd < 0) return;
  con = new_connection(fd, TRUE);
  if (con == NULL) return;

  measure_rtt(con, server->throughput);
  measure_rtt(con, server->latency);
  ninf_disconnect(con);

  ninf_debug("measure %s:%s, rtt= %ld, size=%d", 
	     server->host, server->port, 
	     server->throughput->rtt, server->throughput->size);
  ninf_debug("measure %s:%s, rtt= %ld, size=%d", 
	     server->host, server->port, 
	     server->latency->rtt, server->latency->size);

  meta = metaserver_connect(metaserver_item_root->hostname, 
			    metaserver_item_root->port);
  if (meta == NULL) return;
  inform_communication_information(server, meta);
  metaserver_close(meta);
}

void measure_inter_server_throughput(){
  int count = count_measure_server(measure_servers);
  int interval;
  int i;

  if (count == 0)return;
  interval = measure_interval / count;

  if (metaserver_item_root == NULL)
    return;

  while (TRUE){
    for (i = 0; i < count; i++){
      measure_server * tmp = nth_measure_server(measure_servers, i);
      measure_one_server(tmp);
      sleep(interval);
    }
  }
}

void start_throughput_measurement(){
  if (fork() == 0){ 
    measure_inter_server_throughput();
    exit(1);
  }    
}
