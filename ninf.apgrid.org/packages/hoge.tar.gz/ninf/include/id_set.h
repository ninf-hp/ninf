#ifndef __ID_SET_H__
#define __ID_SET_H__

#include <stdio.h>
#if defined(_AIX)
#include <sys/select.h>
#endif

#define ID_SET_SIZE (1000)

typedef struct _id_set_struct{
  int *content;
  int length;
} id_set;

id_set * new_id_set();                 /* creation */
void free_id_set(id_set * set);        /* destroy */
void clear_id_set(id_set * set);        /* re initialize */

int id_set_add(id_set * set, int id);  /* add id */
int id_set_rm(id_set * set, int id);   /* remove id */

int id_set_get_id(id_set * set, int index);  /* retreive indexed val */

int * id_set_content(id_set * set);    /* get index array */
int id_set_length(id_set * set);       /* get index array length */

void id_set_dump(id_set * set, FILE * fd);  /* printout contents */

#endif
