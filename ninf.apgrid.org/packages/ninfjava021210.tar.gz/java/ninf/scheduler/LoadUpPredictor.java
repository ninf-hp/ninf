package ninf.scheduler;

import ninf.basic.*;
import ninf.common.*;
import ninf.metaserver.*;
import ninf.client.*;
import java.util.Hashtable;
import java.util.Enumeration;

public class LoadUpPredictor extends Predictor{
  Hashtable loadTable;
  static NinfLog dbg = new NinfLog("LoadUpPredictor");
  static double UPVAL = 1.0;

  public LoadUpPredictor(){
    super();
    loadTable = new Hashtable();
  }

  public void scheduled(RequestID request, CallInformation callInfo, 
			ScheduleResult result){
    ServerIndex serverIndex = result.serverInfo.serverIndex;
    UpVal val = (UpVal)loadTable.get(serverIndex.server);
    if (val == null){
      val = new UpVal();
      loadTable.put(serverIndex.server, val);    
    }
    val.add(request, System.currentTimeMillis());
    dbg.println("load offset = " + val.upVal(0L));
    super.scheduled(request, callInfo, result);
  }

  public void done(RequestID request, CallInformation callInfo, 
			ScheduleResult result){
    ServerIndex serverIndex = result.serverInfo.serverIndex;
    UpVal val = (UpVal)loadTable.get(serverIndex.server);
    if (val == null){
      val = new UpVal();
      loadTable.put(serverIndex.server, val);    
    }
    val.remove(request);
    dbg.println("load offset = " + val.upVal(0L));
    super.done(request, callInfo, result);
  }
  
  public LoadInformation getLoadInformation(NinfServerStruct server)
  throws NinfException {
    LoadInformation tmp;
    tmp = super.getLoadInformation(server);
    UpVal val = (UpVal)loadTable.get(server);
    if (val == null)
      val = new UpVal();
    tmp = tmp.copy();
    tmp.loadAverage += val.upVal(tmp.time);
    dbg.println("load = " + tmp.loadAverage);
    return tmp;
  }
}

class UpVal {
  Hashtable table;

  UpVal(){
    table = new Hashtable();
  }

  void add(RequestID request, long time){
    table.put(request, new Long(time));
  }
  void remove(RequestID request){
    table.remove(request);
  }

  double upVal(long time){
    double value = 0.0;
    Enumeration enum = table.elements();
    while (enum.hasMoreElements()){
      Long val = (Long)enum.nextElement();
      if (val.longValue() > time) 
	value += LoadUpPredictor.UPVAL;
    }
    return value;
  }
}
