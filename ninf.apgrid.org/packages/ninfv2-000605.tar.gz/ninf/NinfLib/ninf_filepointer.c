#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "connection.h"
#include "ninf_macros.h"
#include "ninf_cim.h"
#include "ninf_error.h"

/**************************
 **** for file transfer ***
 **************************/
#define TMP_FILE_TEMPLATE "/tmp/ninf_tmp.XXXXXX"
#define TMP_BUFFER_SIZE 1000
#define max(x,y)    ((x)>(y) ? (x) : (y))
#define min(x,y)    ((x)<(y) ? (x) : (y))


static char * make_tmp_file_name(){
  char filename[100];
  strcpy(filename, TMP_FILE_TEMPLATE);
  mktemp(filename);
  return strdup(filename);
}

static void unlink_tmp_file(char * filename){
  if (unlink(filename) < 0)
    ninf_log("failed to remove tmp file %s: %s", 
	     filename, strerror(errno));
}

static int transfer_fp_to_dataTrans(int size, FILE * fp, dataTrans * dt){
  char buffer[TMP_BUFFER_SIZE];
  int items;

  while ((items = fread(buffer, 1, TMP_BUFFER_SIZE, fp)) > 0){
    if (!trans_char_array_with_padding(dt, items, buffer))
      return FALSE;
  }
  write_flush(dt);
  return TRUE;
}

static int transfer_dataTrans_to_fp(int size, dataTrans * dt, FILE * fp){
  char buffer[TMP_BUFFER_SIZE];
  int readed = 0;
  int reading;

  while (readed < size){
    reading = min((size - readed), TMP_BUFFER_SIZE);
    if (!trans_char_array_with_padding(dt, reading, buffer))
      return FALSE;
    fwrite(buffer, 1, reading, fp);
    readed += reading;
  }
  fflush(fp);
  return TRUE;

}

static int get_fp_size(FILE * fp){
  int current, end, size;

  if ((current = ftell(fp)) < 0){
    ninf_error("get_fp_size ftell:%s", strerror(errno));
    return -1;
  }

  if (fseek(fp, 0, SEEK_END) < 0){
    ninf_error("get_fp_size fseek:%s", strerror(errno));
    return -1;
  }

  if ((end = ftell(fp)) < 0){
    ninf_error("get_fp_size ftell:%s", strerror(errno));
    return -1;
  }
  
  size = end - current;
  if (fseek(fp, current, SEEK_SET) < 0){
    ninf_error("get_fp_size fseek:%s", strerror(errno));
    return -1;
  }
  return size;
}

static int trans_filepointer_send(any_t * pointer, dataTrans * dt){
  int size;
  FILE * fp = (FILE *)pointer->u.p;

  if ((size = get_fp_size(fp)) < 0)
    return FALSE;
  if (!trans_int(dt, &size))  /* send size */
    return FALSE;
  if (!transfer_fp_to_dataTrans(size, fp, dt))
    return FALSE;
  return TRUE;
}

static int trans_filepointer_recv(any_t * pointer, dataTrans * dt){
  int size;
  FILE * fp = (FILE *)pointer->u.p;

  if (!trans_int(dt, &size))  /* recv size */
    return FALSE;
  if (!transfer_dataTrans_to_fp(size, dt, fp))
    return FALSE;
  return TRUE;
}


FILE * make_tmp_fp(char * mode){
  char * filename;
  FILE * fp;
  filename = make_tmp_file_name();
  if ((fp = fopen(filename, mode)) == NULL){
    ninf_log("cannot open %s: %s\n", filename, strerror(errno));
    return NULL;
  }
  register_unlink(filename);
  if (ninf_debug_flag)
    ninf_log("tmp filename = %s", filename);
  
  return fp;
}

FILE * make_tmp_fp_filename(char * mode, char ** filenamep){
  char * filename;
  FILE * fp;
  filename = make_tmp_file_name();
  if ((fp = fopen(filename, mode)) == NULL){
    ninf_log("cannot open %s: %s\n", filename, strerror(errno));
    return NULL;
  }
  register_unlink(filename);
  if (ninf_debug_flag)
    ninf_log("tmp filename = %s", filename);
  *filenamep = filename;
  return fp;
}


int trans_filepointer(any_t * pointer, dataTrans * dt){
  if (isSend(dt))
    return trans_filepointer_send(pointer, dt);
  else
    return trans_filepointer_recv(pointer, dt);
}

int trans_filename(any_t * pointer, dataTrans * dt){
 if (isSend(dt))
    return trans_filepointer_send(pointer, dt);
 else 
    return trans_filepointer_recv(pointer, dt);
}

