#include <stdio.h>
#include <math.h>
#include "ninf_stub.h"

#define N    5
#define M    10

extern int ninf_debug_flag;
int verbose = FALSE;

void init_data(double a[][N], double b[][N]){
  int i, j;
  for (j = 0; j < M; j++){
    for (i = 0; i < N; i++){
      a[j][i] = i + 100 * j;
      b[j][i] = 0;
    }
  }
}


int check_data(double a[][N], double b[][N]){
  int i, j;
  for (j = 0; j < M; j++){
    for (i = 0; i < N; i++){
      if (a[j][i] != b[j][i]){
	if (verbose) 
	  printf ("a[%d][%d](%lf) != b[%d][%d](%lf)\n",j,i,a[j][i],j,i,b[j][i]);
	return FALSE;
      }
    }
  }
  return TRUE;
}

int wait_all_test(){
  double a[M][N], b[M][N];
  int i, j, id[M], res[M];

  init_data(a, b);
  printf("wait_all testing: ");
  for (j = 0; j < M; j++)
    id[j] = Ninf_call_async("test/double_test", N, a[j], b[j]);

  Ninf_wait_all();
  return check_data(a,b);
}

int wait_test(){
  double a[M][N], b[M][N];
  int i, j, id[M], res[M];
  init_data(a, b);
  printf("wait     testing: ");
  for (j = 0; j < M; j++){
    id[j] = Ninf_call_async("test/double_test", N, a[j], b[j]);
    if (id[j] < 0){
      Ninf_perror("call_async");
      return FALSE;
    }
  }
  for (j = 0; j < M; j++){
    if ((res[j] = Ninf_wait(id[j])) != NINF_OK)
      Ninf_perror("ninf_wait"); 
    if (verbose) printf("res[%d] = %d,", j, res[j]);
  }
  return check_data(a, b);
}

int cancel_test(){
  int id;
  printf("cancel   testing: ");
  id = Ninf_call_async("test/sleep", 10);
  Ninf_session_cancel(id);
  if (!Ninf_session_probe(id)){
    if (verbose) printf("session %d is already done\n", id);
    return TRUE;
  } else {
    if (verbose) printf("session %d is alive: something went wrong.\n", id);
    return FALSE;
  }
}

int and_test(){
  double a[M][N], b[M][N];
  int i, j, id[M];
  printf("and      testing: ");
  init_data(a, b);
  for (j = 0; j < M; j++){
    id[j] = Ninf_call_async("test/double_test", N, a[j], b[j]);
    if (id[j] < 0){
      Ninf_perror("call_async");
      return FALSE;
    }
  }
  Ninf_wait_and(id, 10);
  return check_data(a, b);
}

int or_test(){  
  int i, id[3], res[3];

  printf("or       testing: ");
  id[0] = Ninf_call_async("test/sleep", 1);
  id[1] = Ninf_call_async("test/sleep", 30);
  id[2] = Ninf_call_async("test/sleep", 30);

  Ninf_wait_or(id, 3);
  for (i = 0; i < 3; i++){
    res[i] = Ninf_session_probe(id[i]);
    if (verbose) printf("session %d is %s\n", id[i], res[i]? "alive": "dead");
  }
  if (!res[0] && res[1] && res[2])
    return TRUE;
  return FALSE;
}

int and_set_test(){
  double a[M][N], b[M][N];
  int i, j;
  id_set *set = new_id_set(), *set2;

  printf("and_set  testing: ");
  init_data(a, b);
  for (j = 0; j < M; j++){
    int id = Ninf_call_async("test/double_test", N, a[j], b[j]);
    if (id < 0){
      Ninf_perror("call_async");
      return FALSE;
    }
    id_set_add(set, id);
  }
  set2 = Ninf_wait_and_set(set);
  if (!check_data(a, b))
    return FALSE;
  if (set2 == NULL || id_set_length(set2) != 10 || id_set_length(set) != 0)
    return FALSE;
  return TRUE;
}

int or_set_test(){  
  int i, id[3], res[3];
  id_set *set = new_id_set(), *set2;

  printf("or_set   testing: ");
  id[0] = Ninf_call_async("test/sleep", 1);
  id[1] = Ninf_call_async("test/sleep", 30);
  id[2] = Ninf_call_async("test/sleep", 30);
  for (i = 0; i < 3; i++)
    id_set_add(set, id[i]);
  set2 = Ninf_wait_or_set(set);

  for (i = 0; i < 3; i++){
    res[i] = Ninf_session_probe(id[i]);
    if (verbose) printf("session %d is %s\n", id[i], res[i]? "alive": "dead");
  }

  if (set2 == NULL || id_set_length(set2) != 1 || id_set_length(set) != 2)
    return FALSE;

  if (!res[0] && res[1] && res[2])
    return TRUE;
  return FALSE;
}

main(int argc, char ** argv)
{
  argc = Ninf_parse_arg(argc, argv);
  while (argc > 1){
    argv++;
    if (strcasecmp(*(argv), "-verbose") == 0)
      verbose = TRUE;
    if (strcasecmp(*(argv), "-debug") == 0)
      ninf_debug_flag = TRUE;
    argc--;
  }
  
  if (wait_all_test())  {printf("\tOK\n");} else { printf("\tfailed\n");} 
  if (wait_test())      {printf("\tOK\n");} else { printf("\tfailed\n");}
  if (cancel_test())    {printf("\tOK\n");} else { printf("\tfailed\n");}
  if (and_test())       {printf("\tOK\n");} else { printf("\tfailed\n");}
  if (or_test())        {printf("\tOK\n");} else { printf("\tfailed\n");}
  if (and_set_test())   {printf("\tOK\n");} else { printf("\tfailed\n");}
  if (or_set_test())    {printf("\tOK\n");} else { printf("\tfailed\n");}

}


