/* ninf_debug.h */

#ifndef NINF_DEBUG_H
#define NINF_DEBUG_H

extern int ninf_debug_flag;

#endif

/* end of ninf_debug.h */
