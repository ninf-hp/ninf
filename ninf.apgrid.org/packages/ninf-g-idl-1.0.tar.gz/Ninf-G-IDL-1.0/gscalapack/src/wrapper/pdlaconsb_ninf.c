#define _WRAPPER_
/* $Id: pdlaconsb_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define DOUBLE
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n
static	int buflen(int i, int l) {
	  int ret=1;
	  ret = 15;
	  if NEED_BUFF {
	    ret = 7*ceil( ceil( (i-l),cbloc ) ,lcm(nprow,npcol) );
	  }
	  return ret;
}

void  pdlaconsb_ninf(
		  double global_a[],
		  int lda,
		  int n,
		  int i,
		  int l,
		  int *m,
		  double h44,
		  double h33,
		  double h43h34,
		 double global_buf[],
		 int lwork
)
/* "pdlaconsb looks for two consecutive small subdiagonal elements by seeing the effect of starting a double shift QR iteration  given by H44, H33, & H43H34 and see if this would make a subdiagonal negligible." */
/* OPTIONS */
{
	int maxldd;

	int maxlda;
	double *loca;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
	int row_loca, col_loca;

	int locm[1];
	double *locbuf;
	int llocbuf;


	INITIALIZE();

	SCALAR( "int", i);
	SCALAR( "int", l);
	SCALAR("int", lda);
	SCALAR("int",n);
	SCALAR("double", h44);
	SCALAR("double", h33);
	SCALAR("double", h43h34);
        SCALAR("int",lwork);

	ROW(a);
	COL(a);
	MAXLDD( maxldd, a );
	maxlda=maxldd;

	MATRIX("double", a, ROW_a, COL_a);
	DISTRIBUTE("double", a, ROW_a, COL_a);

	llocbuf=buflen(i,l)
	llocbuf=max(llocbuf,lwork);
	WORK(locbuf, llocbuf);

	if  (( mypnum != 0 ) ^ (serial==1) )
	  FortranCall(pdlaconsb)( loca, desca,
				  &i, &l, locm,
				  &h44, &h33, &h43h34,
				  locbuf, &llocbuf);

	RETRIEVE("int" , locm, 1);
	RETRIEVE("int",&llocbuf,1);

	RETRIEVE("double",locbuf, min(lwork,llocbuf));

	if( mypnum == 0 ){
	    int i;
	    for(i=0;i<min(lwork,llocbuf);i++) global_buf[i]=locbuf[i];
	    *m = *locm;
	} else {
	}
        FREE_MATRIX(a);
        FREE(locbuf);	
}

