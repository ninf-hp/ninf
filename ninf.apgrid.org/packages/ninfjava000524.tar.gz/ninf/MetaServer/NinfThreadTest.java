package ninf.MetaServer;
import ninf.basic.*;
import ninf.client.*;


public class NinfThreadTest extends NinfThread{
  int num;
  int[] a, b, c;
  
  public NinfThreadTest(int n, int[] a0, int[] b0, int[] c0){
    super();
    num = n;
    a = a0;
    b = b0;
    c = c0;
  }

  public void runSub(){
    c[0]= a[0] + b[0];
    System.out.println("No." + num + " " + a[0] + " + " + b[0] + " = " + c[0]);
    try {
      Thread.currentThread().sleep(3000);
    } catch (Exception e){
    }
  }

  public static void main(String args[]){
    int[] i0 = new int[1]; i0[0] = 1;
    int[] i1 = new int[1]; i1[0] = 2;
    int[] i2 = new int[1]; i2[0] = 3;
    int[] i3 = new int[1]; i3[0] = 4;
    int[] i4 = new int[1]; i4[0] = 0;
    int[] i5 = new int[1]; i5[0] = 0;
    int[] i6 = new int[1]; i6[0] = 0;

    NinfThreadTest a0 = new NinfThreadTest(0, i0, i1, i4);
    NinfThreadTest a1 = new NinfThreadTest(1, i2, i3, i5);
    NinfThreadTest a2 = new NinfThreadTest(2, i5, i4, i6);
    a0.addLower(a2);
    a1.addLower(a2);
    a2.start(); a1.start(); a0.start();
  }

}

