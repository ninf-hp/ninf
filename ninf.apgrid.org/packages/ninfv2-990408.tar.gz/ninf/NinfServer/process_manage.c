#include <stdio.h>
#include <sys/types.h>
#include <time.h>

#include "ninf_macros.h"
#include "process_manage.h"
#include "ninf_config.h"
#define MAX_PROC_NUMBER 1024

static int process_count;

typedef struct running_process{
  int  p_id;
  char peer[4];
  time_t time;  
} running_process;


static running_process processes[MAX_PROC_NUMBER];

static void processes_init(){
  int i;
  /* initialize */
  for (i = 0; i < MAX_PROC_NUMBER; i++)
    processes[i].p_id = 0;
}

static BOOLEAN processes_add(int p_id, char * peer){
  int i, j;
  for (i = 0; i < MAX_PROC_NUMBER; i++)
    if (processes[i].p_id == 0)
      break;
  if (i == MAX_PROC_NUMBER) /* run out of list */
    return FALSE;
  processes[i].p_id = p_id;
  memcpy(processes[i].peer, peer, 4);
  processes[i].time = time(NULL);
  return TRUE;
}

/* return TRUE if the p_id included */
static BOOLEAN processes_remove(int p_id){
  int i;
  for (i = 0; i < MAX_PROC_NUMBER; i++)
    if (processes[i].p_id == p_id){
      processes[i].p_id = 0;
      return TRUE;
    }
  return FALSE;
}  

/* return process which has the p_id*/
static running_process * processes_find(int p_id){
  int i;
  for (i = 0; i < MAX_PROC_NUMBER; i++)
    if (processes[i].p_id == p_id)
      return &(processes[i]);
  return NULL;
}

/********* PUBLIC FUNCTIONS ***********/
void process_manager_init(){
  process_count = 0;
  processes_init();
  ninf_log("Allowed invocation: %d", maxInvocation);
}

char * getpeerAddr(int ns); /* ninf_comm_lib */

void process_manager_forked(int pid, int socket){
  char * addr = getpeerAddr(socket);
  char buffer[] = {0,0,0,0};
  process_count++;
  if (addr == NULL)
    addr = buffer;
  processes_add(pid, addr);
  if (ninf_debug_flag) 
    ninf_log("%d processes: %d forked", process_count, pid);
}

void process_manager_died(int pid){
  running_process * tmp = processes_find(pid);
  char buffer[100];

  if (processes_remove(pid)){
    process_count--;
    if (ninf_debug_flag){ 
      sprintf(buffer, "%d.%d.%d.%d", 0xff & tmp->peer[0], 0xff & tmp->peer[1],
	      0xff & tmp->peer[2], 0xff & tmp->peer[3]);
      ninf_log("%d processes: %d died (from %s)", process_count, pid, buffer);
    } 
  }
}

BOOLEAN process_manager_is_exceed_limit(){
  return process_count + 1 > maxInvocation;
}
