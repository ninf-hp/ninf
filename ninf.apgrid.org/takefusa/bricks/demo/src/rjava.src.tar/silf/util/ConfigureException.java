package silf.util;

public class ConfigureException extends SilfException {
  public ConfigureException() {
    super();
  }
  public ConfigureException(String s) {
    super(s);
  }
}

// end of ConfigureException.java
