#define _WRAPPER_
/* $Id: pdlacpy_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define DOUBLE
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n
#define ROW_b ldb
#define COL_b n
void  pdlacpy_ninf(	 char uplo,
		 int m,
		 int n,
		 double global_a[],
		 int lda,
		 double global_b[],
		 int ldb
	)
/* "pdlacpy copies all or part of a distributed matrix A to another distributed matrix B." */
/* OPTIONS */
{
	int maxldd;

	int maxlda;
	double *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
	int row_loca, col_loca;

	int maxldb;
	double *locb=NULL;
	int descb[DESCLEN];
	int desc_gb[DESCLEN];
	int row_locb, col_locb;

	INITIALIZE();

	SCALAR( "char", uplo);
	SCALAR( "int", m);
	SCALAR( "int", n);

	ROW( a);
	COL( a);
	ROW( b);
	COL( b);
	MAXLDD( maxldd, a );
	maxlda = maxldd;
	maxldb = maxldd;
        
	MATRIX( "double", a, ROW_a, COL_a);
	MATRIX( "double", b, ROW_b, COL_b);
	DISTRIBUTE( "double", a, ROW_a, COL_a);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pdlacpy)( &uplo, &m, &n,
                               loca, &one, &one, desca,
                               locb, &one, &one, descb);

	GATHER( "double", b, ROW_b, COL_b);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
	} else {
	}

	FREE_MATRIX(a);
	FREE_MATRIX(b);
	
}

