/* @(#)rand.c	4.1 (Berkeley) 12/21/80 */
static	long	randx = 1;

srand(x)
unsigned x;
{
	randx = x;
}

rand()
{
	return((randx = randx * 1103515245 + 12345) & 0x7fff);
}
