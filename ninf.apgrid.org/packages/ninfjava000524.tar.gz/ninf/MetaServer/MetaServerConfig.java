// MetaServerConfig.java

package ninf.MetaServer;
import ninf.basic.*;
import ninf.client.*;


import java.io.*;
import java.util.StringTokenizer;
import java.util.Vector;

public class MetaServerConfig {
  public   String host = null;
  public   int port = 0;
  public int myport = 3001; // default my port number;
  public   String netsolve = null;
  public   String agent = null;
  public   String logfile = null;
  public   Vector servers = new Vector();


  public MetaServerConfig(String fileName) throws NinfIOException {
    readConfiguration(fileName);
  }

  Vector tokenize(String s) {  
    Vector v = null;
    StringTokenizer st = new StringTokenizer(s);
    while (st.hasMoreTokens()) {
      if (v == null) v = new Vector();
      v.addElement(st.nextToken());
    }
    return v;
  }

  void readConfiguration(String conf) throws NinfIOException {
    try {
      DataInputStream f;
      f = new DataInputStream(new FileInputStream(conf));
      String s;
      host = null;
      port = 0;
      logfile = null;
      while (f.available() != 0) {
	s = f.readLine();
	if (s.length() == 0) continue;    // skip empty line
	if (s.charAt(0) == '#') continue; // skip comment line
	Vector v = tokenize(s);
	if (v == null) continue;
	int tn = v.size();
	String first = (String)(v.elementAt(0));
	if (tn >= 3 && first.compareTo("metaserver") == 0) {
	  host = (String)(v.elementAt(1));
	  port = Integer.valueOf((String)(v.elementAt(2))).intValue();
	} else if (tn >= 2 && first.compareTo("log") == 0) {
	  logfile = (String)(v.elementAt(1));
	} else if (tn >= 2 && first.compareTo("port") == 0) {
	  myport = Integer.valueOf((String)(v.elementAt(1))).intValue();
	} else if (tn >= 2 && first.compareTo("netsolve") == 0) {
	  netsolve = (String)(v.elementAt(1));
	} else if (tn >= 2 && first.compareTo("agent") == 0) {
	  agent = (String)(v.elementAt(1));
	} else if (tn >= 2 && first.compareTo("server") == 0) {
	  for (int i = 1; i < tn; i++)
	    servers.addElement(v.elementAt(i));
	}
	
      }
      f.close();
    }
    catch(IOException e){new NinfIOException(e);}
    catch(Exception e){new NinfException();}
  }
}

// end of MetaServerConfig.java
