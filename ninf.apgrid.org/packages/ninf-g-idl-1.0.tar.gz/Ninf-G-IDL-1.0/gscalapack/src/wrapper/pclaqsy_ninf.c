#define _WRAPPER_
/* $Id: pclaqsy_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define SCOMPLEX
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n

void  pclaqsy_ninf(	 char uplo,
		 int n,
		 scomplex global_a[],
		 int lda,
		 float global_sr[],
		 float global_sc[],
		 float scond,
		 float amax,
		 char *equed
)
/* "pclaqsy equilibrates a symmetric distributed matrix A using the scaling factors in the vectors SR and SC." */
/* OPTIONS */
{
	int maxldd;

	int maxlda;
	scomplex *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
	int row_loca, col_loca;

	float *locsr;
	float *locsc;

	char locequed[1];

	INITIALIZE();

	SCALAR( "char", uplo);
	SCALAR( "int", n);
	SCALAR( "float", scond);
	SCALAR( "float", amax);
	SCALAR( "int", lda);

	ROW( a);
	COL( a);
	MAXLDD( maxldd, a );
	maxlda = maxldd;

	MATRIX( "scomplex", a, ROW_a, COL_a);
	DISTRIBUTE( "scomplex", a, ROW_a, COL_a);

	VECTOR("r","float",sr,ROW_a);
	VECTOR("c","float",sc,COL_a);
	vDISTRIBUTE("r","float",sr,ROW_a);
	vDISTRIBUTE("c","float",sc,COL_a);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pclaqsy)( &uplo, &n,
                               loca, &one, &one, desca,
                               locsr, locsc,
                               &scond, &amax, locequed);

	GATHER("scomplex", a, ROW_a, COL_a);
	RETRIEVE("char", locequed, 1);

	if( mypnum == 0 ){
	  *equed = locequed[0];
	} else {
	}

	FREE_MATRIX(a);
	FREE_VECTOR(sr);
	FREE_VECTOR(sc);

	
}

