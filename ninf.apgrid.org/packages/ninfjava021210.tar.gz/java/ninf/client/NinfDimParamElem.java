package ninf.client;


import java.io.*;
import ninf.basic.*;

public class NinfDimParamElem {
/*********************** NON STATIC VARIABLES ***********************/
  public int type;
  public int val;
  NinfExpression exp;

/***********************  INSTANCE  CREATION  ***********************/
  public NinfDimParamElem(XDRInputStream istream) throws IOException {
    type = istream.readInt();
    val  = istream.readInt();
    exp  = new NinfExpression();

    if (type == NinfVal.VALUE_BY_EXPR) exp.read(istream);
  }
  public NinfDimParamElem(int ty, int va, NinfExpression ex){
    type = ty; 
    val  = va;
    exp  = ex;
  }
  public NinfDimParamElem(int ty, int va){
    type = ty; 
    val  = va;
    exp  = new NinfExpression();
  }
  public NinfDimParamElem(){
    type = 0; 
    val  = 0;
    exp  = new NinfExpression();
  }

  public NinfDimParamElem copy(){
    return new NinfDimParamElem(type, val, exp.copy());
  }

  String makeVarName(int val){
    return (new Character((char)('A' + val))).toString();
  }

  public String toString(){
    return "("+type+","+ val+ (type == NinfVal.VALUE_BY_EXPR? (", " + exp): ""  )+ ")";
  }

  public String toText(){
    switch (type){
    case NinfVal.VALUE_NONE:
      return null;
    case NinfVal.VALUE_CONST:
      return ""+val;
    case NinfVal.VALUE_IN_ARG:
      return makeVarName(val);
    case NinfVal.VALUE_BY_EXPR:
      return exp.toText();
    }
    return "";
  }
/***********************     I/O  METHODS     ***********************/
  public void write(XDROutputStream ostream)  throws IOException {
    ostream.writeInt(type);
    ostream.writeInt(val);
    if (type == NinfVal.VALUE_BY_EXPR) exp.write(ostream);
  }
/***********************  NON STATIC METHODS  ***********************/
  public int calc_real_val(int arg[], int default_value) throws NinfTypeErrorException {
    return calc_real_val(arg, default_value, 0);
  }

  public int calc_real_val(int arg[], int default_value, int value_in_header) throws NinfTypeErrorException {
    int computed_val;
    switch(type){
    case NinfVal.VALUE_NONE:
      computed_val = default_value;
      break;
    case NinfVal.VALUE_CONST:
      computed_val = val;
      break;
    case NinfVal.VALUE_IN_ARG:
      computed_val = arg[val];
      break;
    case NinfVal.VALUE_BY_EXPR:
      computed_val = (int)exp.calc(arg);
      break;
    case NinfVal.VALUE_IN_HEADER:
      computed_val = value_in_header;
      break;
    default:
      throw new NinfTypeErrorException();
    }
    return computed_val;
  }

  public void shift(int i){
    if (type == NinfVal.VALUE_IN_ARG)
      val += i;
    exp.shift(i);
  }

//================== FOR NINF CALC ===================
// $B!V(BVALUE_IN_ARG$B!W!J0z?t$K$h$j@_Dj$5$l$k!K$+$I$&$+(B
  public boolean IS_VALUE_IN_ARG(){return (type == NinfVal.VALUE_IN_ARG);}
// $B!V(BVALUE_CONST$B!W!JDj?t!K$+$I$&$+(B
  public boolean IS_VALUE_CONST(){return (type == NinfVal.VALUE_CONST);}
// type $B$,5-=R$5$l$F$$$k$+(B
  public boolean IS_TYPE(){return (type > 0);}

  public boolean isUsedAsSize(int index){
    if (type == NinfVal.VALUE_IN_ARG && val == index)
      return true;
    if (type == NinfVal.VALUE_BY_EXPR)
      return exp.isUsedAsSize(index);
    return false;
  }

}


