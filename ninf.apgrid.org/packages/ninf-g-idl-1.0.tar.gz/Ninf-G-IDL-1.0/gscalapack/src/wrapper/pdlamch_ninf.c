#define _WRAPPER_
/* $Id: pdlamch_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define DOUBLE
#include <gscalapack.h>

void  pdlamch_ninf(	
		 char cmach,
		 double *ret /* return value */
)
/* "pdlamch determines single precision machine parameters." */
/* OPTIONS */
{
  extern double FortranCall(pdlamch)( int*, char*);

  double locpdlamch_[1];
	
	INITIALIZE();

	SCALAR( "char", cmach);

	if  (( mypnum != 0 ) ^ (serial==1) )
            FortranReturnSimple( pdlamch, locpdlamch_,
                           ( &PARA_CTXT, &cmach) );

	RETRIEVE("double", locpdlamch_, 1);

	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
	  *ret = *locpdlamch_;
	} else {
	}

	
}

