package jp.go.aist.gtrc.util;

import javassist.CtBehavior;
import javassist.CtClass;
import javassist.CtMethod;
import javassist.Modifier;
import javassist.NotFoundException;
import javassist.bytecode.CodeAttribute;
import javassist.bytecode.LocalVariableAttribute;
import javassist.bytecode.MethodInfo;

import javax.xml.namespace.QName;

class OperationInfo {
	String name;
	QName qName;
	String headCapitalName;
	ElementInfo requestElement;
	ParamInfo[] params;
	TypeInfo returnType;
	ElementInfo responseElement;

	OperationInfo(CtClass cc, CtMethod operation, String tns, TypeMapping typeMapping) throws NotFoundException {
		name = operation.getName();
		qName = new QName(tns, name);
		headCapitalName = name.substring(0, 1).toUpperCase() + name.substring(1);
		SchemaInfo schemaInfo = new SchemaInfo("tns", tns);
		{
			TypeInfo requestType = new TypeInfo(schemaInfo, headCapitalName, "XXX");  // XXX
			requestElement = new ElementInfo(schemaInfo, name, requestType);
		}
		{
			CtClass[] paramTypes = operation.getParameterTypes();
			String[] paramNames = getParameterNames(cc, operation);
			params = new ParamInfo[paramTypes.length];
			for (int i = 0; i < params.length; ++i) {
				params[i] = new ParamInfo(paramNames[i], typeMapping.get(paramTypes[i].getName()));
			}
		}
		{
			CtClass t = operation.getReturnType();
			returnType = ( (t == CtClass.voidType) ? null : (typeMapping.get(t.getName())) );
		}
		{
			TypeInfo responseType = new TypeInfo(schemaInfo, headCapitalName + "Response", "XXX");  // XXX
			responseElement = new ElementInfo(schemaInfo, name + "Response", responseType);
		}
	}

	/*
	 * getParameterNames, toStringArray was taken from
	 * Seasar2.3.17, org/seasar/framework/beans/impl/BeanDescImpl.java
	 * ll. 355-379
	 */
	static String[] getParameterNames(CtClass clazz, CtBehavior behavior) throws NotFoundException {
		MethodInfo methodInfo = behavior.getMethodInfo();
		CodeAttribute codeAttribute = (CodeAttribute)methodInfo.getAttribute("Code");
		if (codeAttribute == null) {
			return null;
		}
		LocalVariableAttribute lva = (LocalVariableAttribute)codeAttribute.getAttribute("LocalVariableTable");
		if (lva == null) {
			return null;
		}
		return toStringArray(behavior, lva);
	}

	static String[] toStringArray(CtBehavior behavior, LocalVariableAttribute lva) throws NotFoundException {
		String[] names = new String[behavior.getParameterTypes().length];
		int offset = Modifier.isStatic(behavior.getModifiers()) ? 0 : 1;
		for (int i = 0; i < names.length; ++i) {
			names[i] = lva.variableName(i + offset);
		}
		return names;
	}
}
