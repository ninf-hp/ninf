#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <time.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <netinet/in.h>
#include <string.h>
#include <signal.h>
#include <errno.h>

#include "ninf_config.h"
#include "ninf_macros.h"

#define BUFFERMAX 1024

static int http_master_socket;

#define SERVERNAME  "NinfServer builtin tiny-httpd"

#define COMMAND_GET  0
#define COMMAND_HEAD 1
#define COMMAND_OTHER -1

#define MAX_LISTEN 3

#define FORK



/** initialize variables */
static char * JARFILENAME;

static char * index_str;
static char * jarfile_buf;
static int    jarfile_size;
static char * gen_index_html(int portno);
static char * gen_jarfile_buf();


static int init_httpd(){
  if ((jarfile_buf = gen_jarfile_buf()) == NULL){
      ninf_log("failed to read Jar file: %s\n", 
	       httpdJarPath);
      return FALSE;
  }
  if ((index_str = gen_index_html(myportno)) == NULL){
      ninf_log("failed to generate index.html file\n");
      return FALSE;
  }      
}

/**************** Gen Jarfile String ******************/
static void setup_JARFILENAME(char * httpdJarPath){
    char * tmp;
    tmp = httpdJarPath;
    JARFILENAME = httpdJarPath;
    while (TRUE){
	if (*tmp == '\0')
	    break;
	if (*tmp == '/')
	    JARFILENAME = tmp + 1;
	tmp++;
    }
}

static int getFileSize(char *);
static char * gen_jarfile_buf(){
    int size;
    int readed = 0;
    FILE * fp;
    char * tmp;
    
    setup_JARFILENAME(httpdJarPath);

    size = getFileSize(httpdJarPath);
    jarfile_size = size;
    if (size == 0)
	return NULL;
    tmp = malloc(size + 1);
    if (tmp == NULL)
	return NULL;
    
    if ((fp = fopen(httpdJarPath, "r")) == NULL){
	perror("fopen");
	return NULL;
    }

    while (readed < size) {
	int treaded = fread(tmp + readed, 1, size - readed, fp);
	if (treaded == 0) {
	    ninf_log("cannot read whole file\n");
	    return NULL;
	}
	readed += treaded;
    }
    fclose(fp);
    return tmp;
}

/******************** Gen index ***********************/
#define INDEX_BUF_SIZE 2000
#define APPLET_WIDTH   600
#define APPLET_HEIGHT  400

#define TITLELINE  "<html><head><title> NinfBrowser </title></head><body>\n"
#define H1LINE     "<h1> Browser for NinfServer </h1>\n"
#define APPLETLINE "<applet archive=\"%s\" code=\"%s\" width=%d height=%d>\n"
#define ARGLINE    "<param name=port value=\"%d\">\n"
#define ENDLINE    "</applet></body></html>\n"


static char index_buf[INDEX_BUF_SIZE];

static char * gen_index_html(int portno){
    char * applet_jar = JARFILENAME;

    sprintf(index_buf, TITLELINE H1LINE APPLETLINE ARGLINE ENDLINE,
	    applet_jar, httpdClassName, APPLET_WIDTH, APPLET_HEIGHT, portno);
    return index_buf;
}



/******************** ***********************/
static void print_date(FILE * out){
  time_t clock;
  char * pc;

  clock = time(NULL);
  pc = ctime(&clock);
  fprintf(out, "Date: %s", pc);
}

static void print_server(FILE * out){
  fprintf(out, "Server: %s\n", SERVERNAME);
}

static void print_responce(FILE * out, int number, char * arg){
  fprintf(out, "HTTP/1.0 %d %s\n", number, arg);
}

static int getFileSize(char * filename){
    struct stat sbuf;
    if (stat(filename, &sbuf) < 0){
	perror("stat:");
	return 0;
    }
    return sbuf.st_size;
}

static void return_a_file(char * filename, FILE * out){
    FILE * fp;
    char buffer[BUFFERMAX];
    int readed;

    if ((fp = fopen(filename, "r")) == NULL){
	perror("fopen");
	fprintf(out, "cannot open %s\n", filename);
	return;
    }

    while ((readed = fread(buffer, 1, BUFFERMAX -1, fp)) > 0)
	fwrite(buffer, 1, readed, out);
}


static void return_index(int version1, int com_code, FILE *out){
 int size = strlen(index_str);

 /* int size = getFileSize("index.html"); */

 if (version1){
   print_responce(out, 200, "OK");
   print_date(out);
   print_server(out);
   fprintf(out, "Content-Type: text/html\n");
   fprintf(out, "Content-Length: %d\n", size);
   fprintf(out, "Connection: close\n");
   fprintf(out, "\n");
 }
  if (com_code == COMMAND_GET)
      /* return_a_file("index.html", out); */
      fprintf(out, index_str);
}

static void return_jarfile(int version1, int com_code, FILE *out){
 int size = jarfile_size;
 if (version1){
   print_responce(out, 200, "OK");
   print_date(out);
   print_server(out);
   fprintf(out, "Content-Type: application/java-archive\n");
   fprintf(out, "Content-Length: %d\n", size);
   fprintf(out, "Connection: close\n");
   fprintf(out, "\n");
 }
 if (com_code == COMMAND_GET){
   int writed = 0;
   while (writed < jarfile_size){
     int tmpwrite = fwrite(jarfile_buf + writed, 1, jarfile_size - writed, out);
     if (tmpwrite < 0){
	 ninf_log("failed to write all the jar file\n");
         break;
     }
     writed += tmpwrite;
   }
 }
}


static void return_error(int version1, int number, char * message, 
			 FILE * out){
  if (version1){
    fprintf(out, "HTTP/1.0 %d %s\n", number, message);
    print_date(out);
    print_server(out);
    fprintf(out, "Content-Type: text/html\n");
    fprintf(out, "\n");
  }
  fprintf(out, "<HTML><HEAD>\n");
  fprintf(out, "<TITLE>%d %s</TITLE>\n", number, message);
  fprintf(out, "</HEAD><BODY>\n");
  fprintf(out, "<H1>%s</H1>\n", message);
  fprintf(out, "</BODY></HTML>\n");
  fflush(out);
}



/** just do two things
 GET /             :  return index.html
 GET /welcome.html :  return index.html
 GET /index.html   :  return index.html
 GET /JARFILENAME  :  return the jarfile
 */
static void treat_http_request(int version1, int com_code, 
			       char * requested, FILE * out){
    ninf_log("httpd [%d]: Got request %s", getpid(), requested);
    if (requested == NULL)
	return_error(version1, 404, "Not Found", out);
    else
    if (strcmp(requested, "/" ) == 0 ||
	strcmp(requested, "/index.html" ) == 0 ||
	strcmp(requested, "/welcome.html" ) == 0 )
	return_index(version1, com_code, out);
    else
    if (requested[0] == '/' && 
	strcmp(requested + 1, JARFILENAME ) == 0)
	return_jarfile(version1, com_code, out);
    else
	return_error(version1, 404, "Not Found", out); 
}

static int parseRequest(char * buffer, int * version1, 
			 int * com_code, char * entry){
    char * ack;
    if ((ack = strtok(buffer, " \n\r")) == NULL) {
	return FALSE;
    }
    if (strcmp(ack, "GET") == 0)
	*com_code = COMMAND_GET;
    else if (strcmp(ack, "HEAD") == 0)
	*com_code = COMMAND_HEAD;
    else
	*com_code = COMMAND_OTHER;

    if ((ack = strtok(NULL, " \n\r")) == NULL) {
	return FALSE;
    }
    strcpy(entry, ack);
    if ((ack = strtok(NULL, " \n\r")) == NULL) {
	*version1 = FALSE;
	return TRUE;
    }

    if (strncmp(ack, "HTTP/1.", 7) != 0)
	*version1 = FALSE;
    else
	*version1 = TRUE;
    return TRUE;
}

static void httpd_body(int socket){
    FILE * fin, * fout;
    char buffer[BUFFERMAX];
    int  command;
    char entry[BUFFERMAX];
    int version1;


    fin  = fdopen(socket, "r");
    fout = fdopen(socket, "w");

    if (fgets(buffer, BUFFERMAX - 1, fin) == NULL){
       ninf_log("httpd failed to get request\n");
       goto END;
    }
    
    parseRequest(buffer, &version1, &command, entry);

    /* skiping headers */
    if (version1) {   
        while (TRUE){
	    if (fgets(buffer, BUFFERMAX - 1, fin) == NULL){
	      ninf_log("httpd failed to read skip");
	      goto END;
	    }
	    if (buffer[0] == '\r' && buffer[1] == '\n');
	    break;
	}
    }

    if (command < 0) { /* command != HEAD nor GET */
	return_error(version1, 501, "Not Implemented", fout);
	goto END;
    }
    treat_http_request(version1, command, entry, fout);
  END:
    fflush(fout);
    fclose(fin);
    fclose(fout);
    shutdown(socket, 2);
    close(socket);
}


static void start_httpd(int socket){
  int ns;

  ninf_log("httpd [%d]: Ninf httpd  Start up", getpid());
  while (TRUE){
    struct sockaddr_in client_addr;
    int size = sizeof(client_addr);
    ns = accept(socket, (struct sockaddr *)&client_addr,&size);
    if (ns < 0){
      if (errno != EINTR){
	perror("accept httpd");
	fprintf(stderr, "httpd accept failed: socket %d", socket);
	break;
      } else 
	continue;
    }
#ifdef FORK
    if (fork() == 0){
      /* child */
      close(socket);
#endif
      httpd_body(ns);
      close(ns);
#ifdef FORK
      exit(0);
    }
#endif
    close(ns);
  }
}

static void hookint_httpd(){
  ninf_log("httpd [%d]: Interruptted by Console User", getpid());
  close(http_master_socket);
  exit(3);
}

int ninf_httpd_start(int port){
    if (!httpdStart)
	return TRUE;
    if (!init_httpd())
	return FALSE;
    http_master_socket = init_server_socket(INADDR_ANY, port, MAX_LISTEN);
    if (http_master_socket <0)
	return FALSE;
    if (fork() == 0){
	signal(SIGINT, hookint_httpd);
	sleep(1);
	ninf_log("httpd [%d]: Ninf httpd  Start Up ...", getpid());
	start_httpd(http_master_socket);
	exit(0);
    } else {
	close(http_master_socket);
	return TRUE;
    }
}


/*
main(int argc, char ** argv){
    int port = 8000;
    if (argc > 1)
	port = atoi(argv[1]);
    ninf_httpd_start(port);
}
*/
