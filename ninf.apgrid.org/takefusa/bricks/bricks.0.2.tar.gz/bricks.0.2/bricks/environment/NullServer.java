package bricks.environment;
import bricks.util.*;
import java.io.*;
import java.util.*;

/** 
 * NullServer.java
 */
public class NullServer extends Server {

    /**
     * Constructs NullServer
     */
    public NullServer() {
	nextEventTime = Double.POSITIVE_INFINITY;
    }

    /** 
     * returns a type of the Server.
     */
    public String getName() {
	return "NullServer";
    }

    public void setHost(Host host) {;}
    public void processEvent(double currentTime) {;}
    public void updateNextEvent(double currentTime) {;}
    public void initSession(double currentTime) {;}

    public String toOriginalString(double currentTime) {
	return "  [" + getName() + "]\n";
    }

    public String toInitString() {
	return "  [" + getName() + "]\n";
    }

    /**
     * returns StaticHostInfo at First
     */
    public StaticHostInfo getStaticHostInfo() {
	return null;
    }

    /** 
     * returns HostInfo that denotes current status of the Server.
     */
    public HostInfo getHostInfo(double currentTime, double trackingTime) {
	return null;
    }
}
