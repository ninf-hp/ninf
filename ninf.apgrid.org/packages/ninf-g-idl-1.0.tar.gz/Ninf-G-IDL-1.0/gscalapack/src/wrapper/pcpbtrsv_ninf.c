#define _WRAPPER_
/* $Id: pcpbtrsv_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define _DISTRIBUTE_1D_
#define SCOMPLEX
#define NO_PIVOT
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n
#define ROW_b ldb
#define COL_b nrhs
static	int worklen(int nrhs, int bw) {
	    ret =  (bw*nrhs);
	    return ret;
}


void  pcpbtrsv_ninf(	 char uplo,
		 char trans,
		 int n,
		 int bw,
		 int nrhs,
		 scomplex global_a[],
		 int lda,
		 scomplex global_b[],
		 int ldb,
		 scomplex work[],
		 int lwork,
		 int *info
)
/* "pcpbtrsv solves a banded triangular system of linear equations A * X = B or A^H * X = B where A is a banded triangular matrix factor produced by the Cholesky factorization code PCPBTRF" */
/* OPTIONS */
{
    extern void FortranCall(pcpbtrsv)( char*, char*,
				       int*, int*, int*,
				       scomplex*, int*, int*,
				       scomplex*, int*, int*,
				       scomplex*, int*,
				       scomplex*, int*,
				       int*);

	int maxldd;

	int maxlda;
	scomplex *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];

	int maxldb;
	scomplex *locb=NULL;
	int descb[DESCLEN];
	int desc_gb[DESCLEN];
	int row_locb, col_locb;

	scomplex *locaf=NULL;
	int laf;
	
	scomplex *locwork=NULL;
	int llocwork;

	INITIALIZE();

	SCALAR( "char", uplo);
	SCALAR( "char", trans);
	SCALAR( "int", n);
	SCALAR( "int", bw);
	SCALAR( "int", nrhs);
	SCALAR( "int", lda);
	SCALAR( "int", ldb);
	SCALAR("int",lwork);

	SIZE(n);

	ROW(b);
	COL(b);
	MAXLDD( maxldd, b );
	maxldb=maxldd;


	if (chrcmp(uplo,'u')==0) {
	  bandMATRIX( "scomplex", a, 0, bw, n);
	  bandDISTRIBUTE( "scomplex", a, 0, bw, n);
	}else {
	  bandMATRIX( "scomplex", a, bw, 0, n);
	  bandDISTRIBUTE( "scomplex", a, bw, 0, n);
	}	

	MATRIX("scomplex", b, ROW_b, COL_b);
	DISTRIBUTE("scomplex", b, ROW_b, COL_b);

	laf= (blocsize+2*bw)*bw;
	locaf = MALLOC(sizeof(scomplex)*laf);

	llocwork = worklen(nrhs, bw);
	llocwork = max(lwork,llocwork);
	WORK(locwork,llocwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	  FortranCall(pcpbtrsv)( &uplo, &trans,
				 &n, &bw, &nrhs,
				 loca, &one, desca,
				 locb, &one, descb,
				 locaf, &laf,
				 locwork, &llocwork,
				 &linfo);

	if (chrcmp(uplo,'U')==0) {
	  bandGATHER( "scomplex", a, 0, bw, n);
	}else {
	  bandGATHER( "scomplex", a, bw, 0, n);
	}	
	GATHER( "scomplex", b, ROW_b, COL_b);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
		*info = linfo;
	} else {
	}
	FREE_MATRIX(a);
	FREE_MATRIX(b);
	FREE(locaf);
        FREE(locwork);
}

