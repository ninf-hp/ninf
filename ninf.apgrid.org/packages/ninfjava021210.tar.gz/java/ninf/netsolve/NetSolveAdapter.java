package ninf.netsolve;

import java.io.IOException;
import ninf.client.NinfStub;

public class NetSolveAdapter{
  static final String defaultAgent = "comet.cs.utk.edu";
  GetProblems getter;
  Problem problems[];
  NinfStub stubs[];

  public NetSolveAdapter(String host) {
    getter = new GetProblems(host);
  }

  public void getAllProblems() throws NetSolveException{
    getter.getAllProblems();
    problems = getter.problems;
    for (int i = 0; i < problems.length; i++){
      System.out.println(problems[i]);
    }
  }

  public Problem getOneProblem(String name) throws NetSolveException{
    return getter.getOneProblem(name);
  }
  

  public static void main(String args[]){
    try {
      NetSolveAdapter tmp = new NetSolveAdapter(defaultAgent);
      if (args.length > 0){
        Problem prob = tmp.getOneProblem(args[0]);
        System.out.println(prob);
        System.out.println(prob.toNinfStub());
	
      } else {
        tmp.getAllProblems();
      }
      
    } catch (NetSolveException e) {
      
    }
  }
}
