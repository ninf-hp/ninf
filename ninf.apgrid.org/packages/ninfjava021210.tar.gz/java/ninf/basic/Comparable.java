package ninf.basic;

public interface Comparable {
  boolean greaterOrEqual(Comparable o);
}
