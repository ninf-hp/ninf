#define _WRAPPER_
/* $Id: pstrti2_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define FLOAT
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n
void  pstrti2_ninf(	 char uplo,
		 char diag,
		 int n,
		 float global_a[],
		 int lda,
		 int *info
)
/* "pstrti2 computes the inverse of a real upper or lower triangular block matrix A. This matrix should be contained in one and only one process memory space (local operation)." */
/* OPTIONS */
{
	int maxldd;

	int maxlda;
	float *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
	int row_loca, col_loca;

	INITIALIZE();

	SCALAR( "char", uplo);
	SCALAR( "char", diag);
	SCALAR( "int", n);
	SCALAR( "int", lda);

	ROW( a);
	COL( a);
	MAXLDD( maxldd, a );
	maxlda = maxldd;

	trMATRIX( uplo, "float", a, ROW_a, COL_a);
	trDISTRIBUTE( uplo, "float", a, ROW_a, COL_a);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pstrti2)( &uplo, &diag, &n, loca, &one, &one, desca, &linfo);

	GATHER( "float", a, ROW_a, COL_a);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
		*info = linfo;
	} else {
		
	}

	FREE_MATRIX(a);
}

