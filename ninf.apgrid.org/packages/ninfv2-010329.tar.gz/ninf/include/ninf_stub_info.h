/*********************** ninf_stub_info.h *********************/

#ifndef  _NINF_STUB_INFO_H_
#define  _NINF_STUB_INFO_H_
#include "ninf_macros.h"
#include "ninf_entry.h"

#define MAJOR_VERSION 2
#define MINOR_VERSION 21

/* basic data type */
typedef enum data_type
{
    DT_UNDEF,	/* undefined */
    DT_VOID,
    DT_CHAR,
    DT_SHORT,
    DT_INT,
    DT_LONG,
    DT_LONGLONG,
    DT_UNSIGNED_CHAR,
    DT_UNSIGNED_SHORT,
    DT_UNSIGNED,
    DT_UNSIGNED_LONG,
    DT_UNSIGNED_LONGLONG,
    DT_FLOAT,
    DT_DOUBLE,
    DT_LONG_DOUBLE,
    DT_STRING_TYPE,
    DT_FUNC_TYPE,
    DT_SCOMPLEX,
    DT_DCOMPLEX,
    DT_FILEPOINTER,
    DT_FILENAME,
    BASIC_TYPE_END
} DATA_TYPE;

#define MAX_DATA_TYPE	((int)(BASIC_TYPE_END))
extern int xdr_data_length[];

/* IN/OUT mode specifier */
typedef enum mode_spec
{
    MODE_NONE = 0,
    MODE_IN = 1,	/* default */
    MODE_OUT = 2,
    MODE_INOUT = 3,

    MODE_WORK = 4,      /* mode for work space */

    MODE_CALL_BACK_FUNC = 8  /* call back function */
} MODE_SPEC;

#define IS_IN_MODE(x)	((int)(x)&1)
#define IS_OUT_MODE(x)	((int)(x)&2)
#define IS_WORK_MODE(x) ((int)(x)&4)

/* maxmum string length for xdr_string */

#define MAX_STRING_LEN	1000

#define MAX_DIM		10
#define MAX_PARAMS	30
#define NINF_EXPRESSION_LENGTH 20

typedef enum value_type
{
    VALUE_NONE = 0,	/* default */
    VALUE_CONST = 1,	/* default, give by constant */
    VALUE_IN_ARG = 2,	/* specified by IN scalar paramter */
    VALUE_BY_EXPR = 3, 	/* computed by interpreter */
    VALUE_OP = 4,       /* operation code */
    VALUE_END_OF_OP = 5, /* end of expression */
    VALUE_ERROR = -1,
    VALUE_IN_HEADER = 6 /* for interface to NetSolve */
} VALUE_TYPE;

/********          supported operators          ********/
#define OP_VALUE_PLUS  1
#define OP_VALUE_MINUS 2
#define OP_VALUE_MUL   3
#define OP_VALUE_DIV   4
#define OP_VALUE_MOD   5
#define OP_VALUE_UN_MINUS   6
#define OP_VALUE_BEKI   7
#define OP_VALUE_EQ     8   /*  ==  */
#define OP_VALUE_NEQ    9   /*  !=  */
#define OP_VALUE_GT    10   /*  >  */
#define OP_VALUE_LT    11   /*  <  */
#define OP_VALUE_GE    12   /*  >=  */
#define OP_VALUE_LE    13   /*  <=  */
#define OP_VALUE_TRY   14   /*  ? : */

typedef struct ninf_expression 
{
  VALUE_TYPE type[NINF_EXPRESSION_LENGTH];
  int val[NINF_EXPRESSION_LENGTH];
} NINF_EXPRESSION;

struct ninf_param_desc {
  enum data_type param_type;	/* argument type */
  enum mode_spec param_inout;	/* IN/OUT */
  int ndim;			/* number of dimension */
  struct {
    VALUE_TYPE size_type;
    int size;
    NINF_EXPRESSION size_exp;
    VALUE_TYPE start_type;
    int start;
    NINF_EXPRESSION start_exp;
    VALUE_TYPE end_type;
    int end;
    NINF_EXPRESSION end_exp;
    VALUE_TYPE step_type;
    int step;
    NINF_EXPRESSION step_exp;
  } dim[MAX_DIM];
};


#define MAT_STYLE_C       0
#define MAT_STYLE_FORTRAN 1

#define BACKEND_NORMAL   0
#define BACKEND_MPI      1
#define BACKEND_BLACS    2

typedef struct ninf_stub_information
{
  int version_major,version_minor;	/* protocol version */
  int info_type;			/* information type: fortran style of C*/  
  char module_name[NINF_MAX_NAME_LEN];	/* module name */
  char entry_name[NINF_MAX_NAME_LEN];	/* entry name */
  int nparam;
  struct ninf_param_desc * params;
  int order_type;
  NINF_EXPRESSION order;
  char * description;
  int shrink;                           /* boolean: specify server side shrink */

  int registered_time;                  /* used to ensure cache concistency */
  int stub_index;
  ninf_entry * entry;                   /* used only in client */

  int backend;                         /* used only in server */


} NINF_STUB_INFO;

NINF_STUB_INFO * new_ninf_stub_info();
#endif /* _NINF_STUB_INFO_H_ */

