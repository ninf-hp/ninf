package bricks.environment;
import bricks.scheduling.ResourceDB;
import bricks.util.*;
import java.io.*;
import java.util.*;

/** 
 * Disk.java
 * <pre>
 * Disk represents a disk system that a host machine has.
 * </pre>
 */
public class Disk extends NodeWithQueue {

    /** The number of executed Instructions invoked by other users. */
    protected Sequence dataSize;

    /** Data divided by page size using Packets. */
    protected Packets packets;

    //protected ResourceDB resourceDB;
    protected ResourceDB resourceDB;

    /** Variables for current stored data */
    protected Hashtable storedDataFragments = new Hashtable();
    protected double diskSize;
    protected double availableDiskSize;
    protected double reservedDiskSize = 0.0;
    protected Vector reservedDataFragments = new Vector();
    protected DataFragments preStoredDataFragments;

    // for GC
    protected static int numTableElements = 10;
    protected Vector accesses = new Vector();
    protected int totalNumAccesses = 0;

    /** inner class to investigate num of accessed data size 
	in a time duration */
    protected class Access {
	public double accessedTime;
	public double dataSize;

	public Access(double accessedTime, double dataSize) {
	    this.accessedTime = accessedTime;
	    this.dataSize = dataSize;
	}
    }
    
    /** Host of this disk */
    protected Host host;
    protected double packetSize;


    /**
     * Constructor for NullDisk.
     */
    public Disk() {;}

    /**
     * Constructs a Disk with
     *     owner : a SimulationSet of your configuration,
     *     key : a key of the Disk,
     *     queue : a queue which represents performance, congestion, and
     *             their variance of the Disk,
     *     dataSize : data size of OthersData,
     *     interarrivalTime : The interval that the Disk invokes 
     *                        extraneous jobs.
     */
    public Disk(
	SimulationSet owner, String key, 
	double diskSize, DataFragments preStoredDataFragments,
	Queue queue, Sequence dataSize, Sequence interarrivalTime
    ){
	this.owner = owner;
	this.key = key;
	this.diskSize = diskSize;
	this.availableDiskSize = diskSize;
	this.preStoredDataFragments = preStoredDataFragments;
	this.queue = queue;
	queue.owner = this;
	this.dataSize = dataSize;
	this.interarrivalTime = interarrivalTime;
	this.logWriter = owner.diskLogWriter;
	init();
    }

/************************* needed method *************************/
    /** 
     * returns a type of the Disk.
     */
    public String getName() {
	return "Disk";
    }

    /**
     * sets host.
     */
    public void setHost(Host host, double packetSize) {
	this.host = host;
	this.packetSize = packetSize;
    }

    /**
     * sets ResourceDB
     */
    public void setResourceDB(ResourceDB resourceDB) {
	this.resourceDB = resourceDB;
    }

    /** 
     * initialize for Interpolation and stored data.
     */
    public void init() {
	super.init();
	if (interarrivalTime instanceof InterpolationInterarrivalTime) {
	    ((InterpolationInterarrivalTime)interarrivalTime).init(
		queue.maxThroughput, dataSize.mean
	    );
	}
	/** initialize stored data fragments*/
	if (preStoredDataFragments != null) {
	    preStoredDataFragments.setSimulationSet(owner);
	    availableDiskSize -= 
		preStoredDataFragments.generate(storedDataFragments);
	}
	printLog(Format.format(availableDiskSize, 3) + "/" + 
		 Format.format(diskSize, 3));

	SimulationDebug.println("disk size = " + diskSize);
	SimulationDebug.println("available disk size = " + availableDiskSize);
	SimulationDebug.println("# of storedDataFragments = " + storedDataFragments.size());
    }

    public void schedule(double currentTime, Data data) {
	queue.enqueue(currentTime, data);
	outQueueLength(currentTime, queue.size());
	updateNextEvent(currentTime);
	host.updateNextEvent(currentTime);
    }

    /** 
     * processEvent
     *     SEND : sends a processed job.
     *     QUEUE : processes queue event.
     *     OTHERSDATA : puts extraneous job into queue of the Disk.
     */
    public void processEvent(double currentTime) {

	if (event == QUEUE) {
	    SimulationDebug.println(
		"Disk.processEvent: " + currentTime + " : QueueEvent");
	    Data top = queue.top();
	    // processEvent of servedJob
	    if (queue.processEventForPackets(currentTime)) {
		if (top instanceof TrafficData) {
		    host.sendData(currentTime, (TrafficData)top);
		}
		outQueueLength(currentTime, queue.size());

	    } else { // divide traffic data for data fragment. 
		Node next = top.nextNode();
		if (next != null)
		    return;
		if (!next.equals(host)) {
		    QueueTimeSharingForDisk q = (QueueTimeSharingForDisk)queue;
		    if (q.sendOnePacket(currentTime, (TrafficData)top, packetSize)) {
			host.sendOnePacket(currentTime, (TrafficData)top);
		    }
		}
	    }

	} else { // OthersData
	    // get OthersData from comingEventList
	    if (!queue.isFull()) {
		schedule(currentTime, nextData);
	    }
	    nextData = getNextData(currentTime);
	}
    }

    /**
     * updateNextEvent finds next event which occurs earliest.
     **/
    public void updateNextEvent(double currentTime) {
	event = OTHERSDATA;
	double earliestTime = nextData.timeEventComes;

	if (!queue.isEmpty()) {
	    if (queue.getTimeQueueEventComes() < earliestTime) {
		earliestTime = queue.getTimeQueueEventComes();
		event = QUEUE;
	    }
	    SimulationDebug.println(
		"Disk(" + host + ").updateNextEvent: " + 
		Format.format(currentTime, 3) + 
		" : queue.getTimeQueueEventComes() = " + 
		queue.getTimeQueueEventComes());
	}
	nextEventTime = earliestTime;
	SimulationDebug.println(
	    "Disk.updateNextEvent: " + Format.format(currentTime, 3) + 
	    " : " + this + ".nextEventTime = " + nextEventTime);
    }

    public String toInitString() {
	String str = "  [" + getName() + " " + key + "] : ";
	str += queue.getName() + ", " + 
	    dataSize.mean + ", " + interarrivalTime.mean + "\n";
	str += queue.toOriginalString();
	return str;
    }

/************************* public method *************************/
    /**
     * returns host
     */
    public Host host() {
	return host;
    }

    /**
     * returns I/O throughput
     */
    public double getThroughput() {
	return queue.maxThroughput;
    }

    public void addDiskInfo(
        double currentTime, double trackingTime, HostInfo hostInfo
    ) {
	hostInfo.diskSize = diskSize;
	hostInfo.availableDiskSize = availableDiskSize;
	hostInfo.use = (diskSize - availableDiskSize) / diskSize;
	addAccessInfo(currentTime, trackingTime, hostInfo);
    }

    /**
     * returns Enumeration of data fragments IDs.
     */
    public Enumeration dataFragments() {
	return storedDataFragments.elements();
    }

    /**
     * remove the DataFragment from this disk.
     */
    public void remove(double currentTime, DataFragment fragment) {
	availableDiskSize += fragment.size;
	if (storedDataFragments.get(fragment.id) == null)
	    BricksUtil.abort(
		"fragment: " + fragment.id + " has not been stored in "
		+ this + ".");
	
	storedDataFragments.remove(fragment.id);
	resourceDB.removeFragmentFrom(host, fragment.id);

	SimulationDebug.println(
	    currentTime + ": " + host + "(disk, available) = " + diskSize + 
	    ", " + availableDiskSize);

	//printLog(currentTime, Format.format(availableDiskSize, 3) + "/" + 
	//Format.format(diskSize, 3));
	// for debug
	printLog(currentTime, Format.format(availableDiskSize, 3) + "/" + 
		 Format.format(diskSize, 3) + " remove " + fragment);
    }

    /** 
     * stores the DataFragment to this disk.
     */
    public void store(double currentTime, DataFragment fragment) 
	throws BricksNoDiskSpaceException {

	SimulationDebug.println("Disk.store(): " + currentTime);
	SimulationDebug.println("Disk: store " + fragment + " into " + this);

	if (storedDataFragments.get(fragment.id) != null)
	    return;
	//BricksUtil.abort(
	//"fragment: " + fragment.id + " has been already stored in "
	//+ this + ".");

	availableDiskSize -= fragment.size;
	if (availableDiskSize < 0.0)
	    throw new BricksNoDiskSpaceException("No disk space on " + this + ".");

	storedDataFragments.put(fragment.id, fragment);
	resourceDB.addFragmentInto(host, fragment);

	SimulationDebug.println(
	    currentTime + ": " + host + "(disk, available) = " + diskSize + 
	    ", " + availableDiskSize);

	//printLog(currentTime, Format.format(availableDiskSize, 3) + "/" + 
	//Format.format(diskSize, 3));
	// for debug
	printLog(currentTime, Format.format(availableDiskSize, 3) + "/" + 
		 Format.format(diskSize, 3) + " store " + fragment);
    }

    // callee: ReplicaManager
    public boolean makeDiskSpace(
        double currentTime, double compactness, DataFragment dataFragment
    ) {
	double removedSize = diskSize * (1 - compactness);
	// add elements of storedDataFragments excepting dataFragment.
	Vector table = new Vector(storedDataFragments.size());
	Enumeration e = dataFragments();
	while (e.hasMoreElements()) {
	    DataFragment f = (DataFragment)e.nextElement();
	    if (!f.equals(dataFragment) || !reservedDataFragments.contains(f)
		|| resourceDB.howManyReplicas(f) > 1)
		table.add(new DataFragmentInfo(f));
	}	    
	return makeDiskSpace(currentTime, removedSize, table);
    }

    // callee: ReplicaManager
    public boolean makeDiskSpace(double currentTime, double compactness) {
	double removedSize = diskSize * (1 - compactness);
	// add elements of storedDataFragments excepting dataFragment.
	Vector table = new Vector(storedDataFragments.size());
	Enumeration e = dataFragments();
	while (e.hasMoreElements()) {
	    DataFragment f = (DataFragment)e.nextElement();
	    if (!reservedDataFragments.contains(f)
		|| resourceDB.howManyReplicas(f) > 1)
		table.add(new DataFragmentInfo(f));
	}	    
	return makeDiskSpace(currentTime, removedSize, table);
    }

    protected boolean makeDiskSpace(
        double currentTime, double removedSize, Vector table
    ) {
	if (table.size() == 0)
	    return false;

	// sort table by f.lastAccessedTime values
	HeapSortForDisk.sortByLastAccessedTime(table);

	while (availableDiskSize - removedSize < 0.0) {
	    int n = numTableElements;
	    if (n > table.size()) {
		n = table.size();
	    }
	    for (int i = 0; i < n; i++) {
		// check # of accesses and copies for each fragment
		((DataFragmentInfo)table.elementAt(i)).computeScore(
		    resourceDB, currentTime
		);
	    }
		
	    // sort by f.score values
	    HeapSortForDisk.sortByScore(table, n);

	    for (int i = 0; i < n; i++) {
		availableDiskSize += 
		    ((DataFragmentInfo)table.elementAt(i)).size();
		remove(currentTime, 
		       ((DataFragmentInfo)table.elementAt(i)).dataFragment);
		if (availableDiskSize - removedSize >= 0.0)
		    break;
	    }

	    if (availableDiskSize - removedSize < 0.0) {
		for (int i = 0; i < n; i++)
		    table.remove(0);
		if (table.size() == 0)
		    return false;
	    }
	}
	return true;
    }

    public DataFragment getMostAccessedDataFragment(
	double currentTime, double trackingTime
    ) {
	double max = -1.0;
	DataFragment dataFragment = null;

	Enumeration e = storedDataFragments.elements();
	while (e.hasMoreElements()) {
	    DataFragment f = (DataFragment)e.nextElement();
	    if (f.size != 10000.0) // MODIFY!
		continue;
	    if (f.lastAccessedTime < (currentTime - trackingTime))
		continue;
	    double score = f.numAccesses / (currentTime - f.storedTime);
	    SimulationDebug.println(this + " " + f + " : numAccess = " +
			       f.numAccesses + ", score = " + score);
	    if (max < score) {
		max = score;
		dataFragment = f;
	    }
	}
	SimulationDebug.println(this +" select " + dataFragment + " from " +
				storedDataFragments);
	return dataFragment;
    }

    public boolean reserved(DataFragment dataFragment) {
	reservedDataFragments.add(dataFragment);
	SimulationDebug.println("Disk: reserved " + dataFragment);
	return true;
    }

    public boolean released(DataFragment dataFragment) {
	SimulationDebug.println("Disk: released " + dataFragment);
	return reservedDataFragments.remove(dataFragment);
    }

    public boolean reserved(double dataSize) {
	//System.out.println(
	SimulationDebug.println(
	    this + ": reserved " + Format.format(dataSize, 3) + " / " +
	    availableDiskSize);
	if (availableDiskSize < dataSize) {
	    return false;
	} else {
	    reservedDiskSize += dataSize;
	    availableDiskSize -= dataSize;
	    return true;
	}
    }

    public boolean released(double dataSize) {
	SimulationDebug.println("Disk: released " + Format.format(dataSize, 3));
	reservedDiskSize -= dataSize;
	availableDiskSize += dataSize;
	if (reservedDiskSize < 0.0)
	    return false;
	return true;
    }

    public void accessedAt(double currentTime, DataFragment dataFragment) 
	throws BricksException 
    {
	    //System.out.println("accessed: " + this + ", " + currentTime + ", " + dataFragment.id);
	try {
	    DataFragment fragment = 
		(DataFragment)storedDataFragments.get(dataFragment.id);
	    fragment.accessedAt(currentTime);
	    accesses.insertElementAt(new Access(currentTime, dataFragment.size), 0);
	    //System.out.println("accesses = " + accesses);
	    totalNumAccesses++;

	} catch (NullPointerException exception) {
	    System.out.println(
		currentTime + " " + this + " " +dataFragment.id + " accessed");
	    Enumeration e = storedDataFragments.keys();
	    String str = "from ";
	    while (e.hasMoreElements())
		str += e.nextElement() + " ";
	    str += "\n";
	    throw new BricksException(str);
	}
    }

    public void finish() {
	printLog(host + " " + Format.format(availableDiskSize, 3) + " / " + 
		 Format.format(diskSize, 3) + " " + totalNumAccesses);

    }

    public DataFragment get(String id) {
	return (DataFragment)storedDataFragments.get(id);
    }

/************************* protected method *************************/
    // override
    protected void outQueueLength(double currentTime, int size) {;}

    // override
    protected Data getNextData(double currentTime) {
	if (this.interarrivalTime != null) {
	    double timeEventComes = 
		currentTime + interarrivalTime.nextDouble(currentTime);
	    return new OthersData(
		this, timeEventComes, dataSize.nextDouble(currentTime)
	    );
	} else {
	    return new OthersData(this, Double.POSITIVE_INFINITY, 0);
	}
    }

    protected void addAccessInfo(
	double currentTime, double trackingTime, HostInfo hostInfo
    ){
	double size = 0.0;
	double end = currentTime - trackingTime;
	int removeFrom = -1;

	//System.out.println("Disk.addAccessInfo: " + this + ", currentTime = " + currentTime);
	//System.out.println(accesses);
	for (int i = 0; i < accesses.size(); i++) {
	    Access access = (Access)accesses.elementAt(i);
	    if (access.accessedTime >= end) {
		size += access.dataSize;
	    } else {
		removeFrom = i;
		break;
	    }
	}
	// remove old access data
	if (removeFrom >= 0) {
	    for (int i = removeFrom; i < accesses.size(); i++) 
	        accesses.removeElementAt(i);
	} else {
	    removeFrom = accesses.size();
	}
	hostInfo.numAccesses = removeFrom;
	hostInfo.numAccessedDataSize = size / (trackingTime / 86400.0);
    }

    private String toDebugString() {
	return this + ": (disk, available) = " + diskSize + ", " + 
	    availableDiskSize;
    }
}
