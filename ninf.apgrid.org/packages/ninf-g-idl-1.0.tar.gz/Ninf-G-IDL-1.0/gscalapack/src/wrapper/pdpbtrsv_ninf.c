#define _WRAPPER_
/* $Id: pdpbtrsv_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define _DISTRIBUTE_1D_
#define DOUBLE
#define NO_PIVOT
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n
#define ROW_b ldb
#define COL_b nrhs
static	int worklen(int nrhs, int bw) {
	  int ret=1;
	  ret =  (bw*nrhs);
	  return ret;
}

void  pdpbtrsv_ninf(	 char uplo,
		 char trans,
		 int n,
		 int bw,
		 int nrhs,
		 double global_a[],
		 int lda,
		 double global_b[],
		 int ldb,
		 double work[],
		 int lwork,
		 int *info
)
/* "pdpbtrsv solves a banded triangular system of linear equations A * X = B or A^T * X = B where A is a banded triangular matrix factor produced by the Cholesky factorization code PSPBTRF and is stored in A and AF." */
/* OPTIONS */
{
    extern void FortranCall(pdpbtrsv)( char*, char*,
                                int*, int*, int*,
                                double*, int*, int*,
                                double*, int*, int*,
                                double*, int*,
                                double*, int*,
                                int*);

	int maxldd;

	int maxlda;
	double *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
	int row_loca, col_loca;

	int maxldb;
	double *locb=NULL;
	int descb[DESCLEN];
	int desc_gb[DESCLEN];
	int row_locb;
	int col_locb;

	double *locaf=NULL;
	int laf;

	double *locwork=NULL;
	int llocwork;


	INITIALIZE();

	SCALAR( "char", uplo);
	SCALAR( "char", trans);
	SCALAR( "int", n);
	SCALAR( "int", bw);
	SCALAR( "int", nrhs);
	SCALAR( "int", lda);
	SCALAR( "int", ldb);
	SCALAR("int",lwork);

	SIZE(n);

	ROW(a);
	COL(a);
	MAXLDD( maxldd, a);
	maxlda=maxldd;
	ROW(b);
	COL(b);
	MAXLDD( maxldd, b);
	maxldb=maxldd;

        if (chrcmp(uplo,'u')==0) {
            bandMATRIX("double", a, 0, bw, n);
            bandDISTRIBUTE("double", a, 0, bw, n);
        } else {
            bandMATRIX("double", a, bw, 0, n);
            bandDISTRIBUTE("double", a, bw, 0, n);
        }
        
	MATRIX("double", b, ROW_b, COL_b);
	DISTRIBUTE("double", a, ROW_a, COL_a);

	laf= (blocsize+2*bw)*bw;
	locaf = MALLOC(sizeof(double)*laf);
        assert(locaf);

	llocwork = worklen(nrhs, bw);
	llocwork = max(lwork, llocwork);
	WORK(locwork,llocwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pdpbtrsv)( &uplo, &trans,
                                &n, &bw, &nrhs,
                                loca, &one, desca,
                                locb, &one, descb,
                                locaf, &laf,
                                locwork, &llocwork,
                                &linfo);

        if (chrcmp(uplo,'u')==0) {
            bandGATHER("double", a, 0, bw, n);
        } else {
            bandGATHER("double", a, bw, 0, n);
        }
	GATHER( "double", b, ROW_b, COL_b);

	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
		*info = linfo;
	} else {
		
	}
	FREE_MATRIX(a);
	FREE_MATRIX(b);
        FREE(locaf);
        FREE(locwork);
}

