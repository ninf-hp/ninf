/* $Id: initialize.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */

#include <stdio.h>
#include <stdlib.h>
#include <mpi.h>
#include <assert.h>
#include <string.h>

#define _LOCAL_
#include "gscalapack.h"
#include "gscalapack-scalapack.h"

void initialize(int dim) {

  int *map=NULL;
  int nprow_tmp, npcol_tmp; /* blacs_gridinfo breaks nprow,npcol, so i need. */

  /* Initialize the process grid */
  Cblacs_pinfo( &mypnum, &nprocs ); /* Get # of process & my process ID */

  /* Build new processor grid */
  if( nprocs > 2 )  {


    if (dim == 1 ) ninf_make_grid1d( nprocs-1, &nprow, &npcol);
    else ninf_make_grid( nprocs-1, &nprow, &npcol);

    map = MALLOC(sizeof(int)*npcol*nprow);
    assert(map!=NULL);

    F77_procmap( &para_ctxt, &one, &one, &nprow, &npcol, map);
    F77_procmap( &seq_ctxt, &one, &zero, &one, &one , map);
    if (dim==1) F77_procmap( &para_ctxt1d, &one, &one, &npcol, &nprow, map);

   /* Initialize new grid */
    Cblacs_get( -1 , 0 , &all_ctxt );
    //    if (dim!=1) 
    Cblacs_gridinit( &all_ctxt, "r", 1, nprocs );
    // else
    // Cblacs_gridinit( &all_ctxt, "c", 1, nprocs );
    nprow_tmp=nprow; npcol_tmp=npcol;
    Cblacs_gridinfo( para_ctxt, &nprow_tmp, &npcol_tmp, &myprow, &mypcol );

    free(map);

  } else {
    /* In nprocs < 2, it runs ScaLAPACK in serial */

    serial = 1;
    map = MALLOC(sizeof(int)*nprocs);
    assert(map!=NULL);
    F77_procmap( &seq_ctxt, &one, &zero, &one, &one , map);
    free(map);

    nprow=1; npcol=1;

    if (nprocs==1) { /* when nprocs==2, they give erros, why ? */
      /* for some scalapack funcs e.g. pcgbsv */
      /* Initialize new grid */
      Cblacs_get( -1 , 0 , &all_ctxt );
      Cblacs_gridinit( &all_ctxt, "r", 1, nprocs );
    }

    all_ctxt    = seq_ctxt;
    my_ctxt     = seq_ctxt;
    para_ctxt   = seq_ctxt;
    para_ctxt1d = seq_ctxt;

  }

} /* end of initialize */
