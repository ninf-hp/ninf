package bricks.scheduling;
import bricks.util.*;
import bricks.environment.*;
import java.util.*;

public class AccessBoundRecvTimeReplicationScheduler extends AccessBoundSendTimeReplicationScheduler implements SchedulingUnit {

    public AccessBoundRecvTimeReplicationScheduler(
	String keyOfMetaPredictor, String keyOfReplicaManager, 
	String keyOfServerMonitor, double minAccessScore
    ) {
	super(keyOfMetaPredictor, keyOfReplicaManager, 
	      keyOfServerMonitor, minAccessScore);
    }

/************************* needed method *************************/
    public String getName() {
	return "AccessBoundRecvTimeReplicationScheduler";
    }

    // override
    protected Host select(
	double currentTime, RequestedData data, Enumeration e
    ) {
	return selectBySendAndComputeDuration(currentTime, data, e);
    }

    protected Host selectDataDestination(
	double currentTime, RequestedData data, Host computeHost
    ) {
	Host destinationHost = null;
	double accessScore = 0.0;
	
	Vector v = shuffle(resourceDB.hosts(data));
	Enumeration e = v.elements();

	while (e.hasMoreElements()) {
	    Host h = (Host)e.nextElement();
	    if (h.equals(computeHost))
		continue;
	    if (!hasAvailableDisk(currentTime, h, data.dataSizeForReceive))
		continue;

	    StaticHostInfo staticInfo = resourceDB.getStaticHostInfo(h);
	    HostInfo info = getHostInfo(currentTime, h);
	    double score = staticInfo.performance / (info.numAccesses+1.0);
	    if (accessScore < score) {
		destinationHost = h;
		accessScore = score;
	    }
	}
	return destinationHost;
    }
}

