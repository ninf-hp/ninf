#include <stdio.h>
#include <netdb.h>
#include <string.h>
#include <sys/types.h>
#include <netinet/in.h>
#include "ninf_macros.h"
#include "ninf_config.h"
#include "ninf_error.h"


/* IP restriction */
static struct IPHostList * allowedHosts = NULL;
static int    allowAll = TRUE;

#define CLASS_C_MASK "255.255.255.0"
#define CLASS_B_MASK "255.255.0.0"
#define HOST_MASK "255.255.255.255"

typedef struct IPHosts{
  int  addmaskflag;    /* if false, 'address' specifies lower bound */
  char address[4];     /*           'mask'    specifies upper bound */
  char mask[4];
} IPHosts;

typedef struct IPHostList{
  IPHosts * hosts;
  struct IPHostList * next;
} IPHostList;

/** the second parameter is 4 byte length notation of IP address */
static BOOLEAN IPHostsIncludes(IPHosts * iphosts, char * address){
  int i;
  if (iphosts->addmaskflag){
    for (i = 0; i < 4; i++){
      if ((iphosts->address[i] & iphosts->mask[i]) !=
	  (         address[i] & iphosts->mask[i]))
	
	return FALSE;
    }
    return TRUE;
  } else {
    for (i = 0; i < 3; i++){
      if ((iphosts->address[i] != address[i]))
	return FALSE;
    }
    if ((iphosts->address[3] <= address[3]) &&
	(iphosts->mask[3]    >= address[3]) )
      return TRUE;
    return FALSE;
  }
}

/** the second parameter is 4 byte length notation of IP address */
static BOOLEAN IPHostListIncludes(IPHostList * list, char * address){
  while (list != NULL){
    if (IPHostsIncludes(list->hosts, address))
	return TRUE;
    list = list->next;
  }
  return FALSE;
}

static char * IPHostsPrintBuffer(IPHosts * iphosts, char * buffer){
  if (iphosts->addmaskflag)
    sprintf(buffer, "%d.%d.%d.%d,\tmask:%d.%d.%d.%d",
	    (0xff & iphosts->address[0]),(0xff & iphosts->address[1]),
	    (0xff & iphosts->address[2]),(0xff & iphosts->address[3]),
	    (0xff & iphosts->mask[0]),(0xff & iphosts->mask[1]),
	    (0xff & iphosts->mask[2]),(0xff & iphosts->mask[3]));
  else
    sprintf(buffer, "%d.%d.%d.%d-%d",
	    (0xff & iphosts->address[0]),(0xff & iphosts->address[1]),
	    (0xff & iphosts->address[2]),(0xff & iphosts->address[3]),
	    (0xff & iphosts->mask[3]));
  return buffer;
}

static void IPHostsPrint(FILE * fp, IPHosts * iphosts){
  char buffer[1000];
  IPHostsPrintBuffer(iphosts, buffer);
  fprintf(fp, buffer);
}

static void IPHostListPrint(FILE * fp, IPHostList * list){
  while (list != NULL){
    IPHostsPrint(fp, list->hosts);
    fprintf(fp, "\n");
    list = list->next;
  }
}

static BOOLEAN isalldigit(char * str){
  while (*str != '\0'){
    if (!isdigit(*str))
      return FALSE;
    str++;
  }
  return TRUE;
}

#define ipboundcheck(i) (i >= 0 && i < 255)

/* try to parse something like "192.50.75.16-19" */
static BOOLEAN parseHosts(char * address, IPHosts * iphosts){  
  char buffer[100];
  char *a0, * a1, * a2, * a3, * a31, *a32, *a33;
  int  i0, i1, i2, i31, i32;

  if (strlen(address) > 100)
    return FALSE; /* too long to be true */
  
  strncpy(buffer, address, 100);
  a0 = strtok(buffer, ".");  /* divide by "." */
  a1 = strtok(NULL,   ".");
  a2 = strtok(NULL,   ".");
  a3 = strtok(NULL,   ".");
  a31 = strtok(NULL,   ".");
  if (a0 == NULL || a1 == NULL ||a2 == NULL ||a3 == NULL || a31 != NULL)
    return FALSE;
  if ((!isalldigit(a0)) || (!isalldigit(a1)) || (!isalldigit(a2)))
    return FALSE;
  i0 = atoi(a0); i1 = atoi(a1); i2 = atoi(a2);
  a31 = strtok(a3, "-");
  a32 = strtok(NULL, "-");
  a33 = strtok(NULL, "-");
  if (a31 == NULL || a32 == NULL || a33 != NULL)
    return FALSE;
  if ((!isalldigit(a31)) || (!isalldigit(a32)))
    return FALSE;
  i31 = atoi(a31); i32 = atoi(a32);

  if ((!ipboundcheck(i0)) || (!ipboundcheck(i1)) || (!ipboundcheck(i2)) || 
      (!ipboundcheck(i31))|| (!ipboundcheck(i32)))
    return FALSE;

  iphosts->address[0] = iphosts->mask[0] = i0;
  iphosts->address[1] = iphosts->mask[1] = i1;
  iphosts->address[2] = iphosts->mask[2] = i2;
  iphosts->address[3] = i31;
  iphosts->mask[3] = i32;    
  
  iphosts->addmaskflag = FALSE;
  return TRUE;
}

static IPHosts * new_IPHosts(char * address, char * mask){
  IPHosts * iphosts;
  struct hostent * he;
  char * orgmask = mask;

  if (mask == NULL)
    mask = HOST_MASK;
  else if (strcasecmp(mask, "CLASS_C") == 0)
    mask = CLASS_C_MASK;
  else if (strcasecmp(mask, "CLASS_B") == 0)
    mask = CLASS_B_MASK;

  if ((iphosts = (IPHosts *)malloc(sizeof(IPHosts))) == NULL){
    ninf_log("couldn't malloc iphosts");
    return NULL;
  }
  he = gethostbyname(address);
  if (he == NULL){
    if (orgmask == NULL)
      if (parseHosts(address, iphosts))
	return iphosts;
    perror("gethostbyname");
    return NULL;
  }
  memcpy(iphosts->address, *(he->h_addr_list), he->h_length);

  he = gethostbyname(mask);
  if (he == NULL){
    perror("gethostbyname");
    return NULL;
  }
  memcpy(iphosts->mask,    *(he->h_addr_list), he->h_length);
  iphosts->addmaskflag = TRUE;
  return iphosts;
}

static IPHostList * new_IPHostList(IPHosts * hosts, IPHostList * next){
  IPHostList * iphostlist;  
  if ((iphostlist = (IPHostList *)malloc(sizeof(IPHostList))) == NULL){
    ninf_log("couldn't malloc iphostlist");
    return NULL;
  }
  iphostlist->hosts = hosts;
  iphostlist->next  = next;
  return iphostlist;
}


/****** Public functions   ******/

void initAllowList(){
  IPHostList * list;
  /* always allow localhost */
  if (!allowAll)
    addIPHostList("127.0.0.1", HOST_MASK);  
  list = allowedHosts;
  if (allowAll){
    ninf_log("Allowed Hosts: ALL");
  } else {
    while (list != NULL){
      char buffer[100];
      ninf_log("Allowed Hosts: %s", 
	       IPHostsPrintBuffer(list->hosts, buffer));
      list = list->next;
    }
  }
}

/** add new IP to allowedList */
BOOLEAN addIPHostList(char * address, char * mask){
  IPHostList * list;
  IPHosts * tmp = new_IPHosts(address, mask);

  allowAll = FALSE;  /* disallow all */
  if (tmp == NULL)
    return FALSE;
  list = new_IPHostList(tmp, allowedHosts);
  if (list == NULL)
    return FALSE;
  allowedHosts = list; 
  return TRUE;
}

/** check the allowedList */
BOOLEAN isAllowed(int socket){
  struct sockaddr_in myaddr;
  struct hostent * hp;
  unsigned int peer;
  int size = sizeof(myaddr);
  char address[4];

  /* if no list setuped, allow all the connection */
  if (allowAll)
    return TRUE;
 
  if (getpeername(socket, (struct sockaddr *)&myaddr, &size) < 0){
    perror("getpeername");
    return FALSE;
  }
  peer = ntohl(myaddr.sin_addr.s_addr);

  address[0] = ((peer & (0xff << (8*3))) >> (8*3)) & 0xff;
  address[1] = ((peer & (0xff << (8*2))) >> (8*2)) & 0xff;
  address[2] = ((peer & (0xff << (8*1))) >> (8*1)) & 0xff,
  address[3] = ((peer & (0xff << (8*0))) >> (8*0)) & 0xff;

  return IPHostListIncludes(allowedHosts, address);
}
