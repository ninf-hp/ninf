#define _WRAPPER_
/* $Id: pdstein_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define _DISTRIBUTE_1D_
#define DOUBLE
#include <gscalapack.h>
#define ROW_z ldz
#define COL_z  m

static	int worklen(int m, int n){
		int np00, mq00;
		int ret=1;
                ret=max(5*n,n*m)+m*n;
		if NEED_BUFF {
			np00 = NUMROC( N, rbloc, 0, 0, NPROW );
			mq00 = NUMROC( M, cbloc, 0, 0, NPCOL );
			ret = max(5*n,np00*mq00) + ceil(m,nprocs)*n;
		}
		return ret;
}

static	int iworklen(int n) {
		int ret=1;
                ret = 3*n + nprocs + 1;
		return ret;
}

void  pdstein_ninf(	 int n,
		 double d[],
		 double e[],
		 int m,
		 double w[],
		 int iblock[],
		 int isplit[],
		 double orfac,
		 double global_z[],
		 int ldz,
		 double global_work[],
		 int global_iwork[],
		 int ifail[],
		 int *info
)
/* "pdstein computes the eigenvectors of a symmetric tridiagonal matrix in parallel, using inverse iteration." */
/* OPTIONS */
{
	int maxldd;

	int desctdd[DESCLEN], desc_gtdd[DESCLEN];
	double *locd=NULL;
	double *loce=NULL;

	int maxldz;
	double *locz=NULL;
	int descz[DESCLEN];
	int desc_gz[DESCLEN];
	int row_locz, col_locz;

	int *locifail=NULL;
        
	int *iclustr=NULL;
	int *gap=NULL;

	double *locwork=NULL;
	int llocwork;
	int *lociwork=NULL;
	int llociwork;

	INITIALIZE();

	SCALAR( "int", n);
	SCALAR( "int", m);
	SCALAR( "double", orfac);
	SCALAR("int",ldz);
	SIZE(n);

	ROW(z);
	COL(z);
	MAXLDD( maxldd, z );
	maxldz = maxldd;

	COMMON("double",w, m);
	COMMON("int", iblock, n);
	COMMON("int", isplit, n);

	locifail=MALLOC(sizeof(int)*min(m,n));
	iclustr=MALLOC(sizeof(int)* nprocs*2);
	gap=MALLOC(sizeof(int)* nprocs);

	MATRIX( "double", z, ROW_z, COL_z);

	COMMON( "double", d, n);
	COMMON( "double", e, n-1);

	llocwork=worklen(m, n);
	WORK(locwork,llocwork);
	llociwork=iworklen(n);
	IWORK(lociwork,llociwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
		FortranCall(pdstein)( &n, d, e, &m,
				      w,
				      iblock, isplit, &orfac,
				      locz, &one, &one, descz,
				      locwork, &llocwork,
				      lociwork, &llociwork,
				      locifail, iclustr, gap,
				      &linfo);

	GATHER( "double", z, ROW_z, COL_z);
	RETRIEVE("double", w, n);
	RETRIEVE("int", &linfo, 1);

	RETRIEVE("int", locifail, m);
/*	RETRIEVE("int", iclustr, nprocs*2); */
/*	RETRIEVE("double", gap, nprocs); */

	if( mypnum == 0 ){
		int i;
		*info = linfo;
		for(i=0;i<m;i++) ifail[i] = locifail[i];
	} else {
	}

	FREE_COMMON(w);
	FREE_COMMON(d);
	FREE_COMMON(e);
	FREE_COMMON(iblock);
	FREE_COMMON(isplit);

	FREE_MATRIX(d);
	FREE_MATRIX(e);
	FREE_MATRIX(z);

	FREE(locifail);

	FREE(locwork);
	FREE(lociwork);
}

