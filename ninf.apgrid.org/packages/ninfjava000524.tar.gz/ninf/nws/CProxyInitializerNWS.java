package ninf.nws;
import ninf.basic.*;
import ninf.cproxy.*;
import java.io.*;

public class CProxyInitializerNWS implements CProxyInitializer{
  static NinfLog dbg = new NinfLog("CProxyInitializerNWS");

  static final String sensorExecutable = "network_sensor";
  static final String memoryExecutable = "nws_memory";
  static final String forecasterExecutable = "nws_forecast";
    
  public void init(CProxyConfig conf) throws NinfException {
    dbg.println("initializing nws related modules.");
    try {
      if (conf.NWSuse)
	conf.TPingerClass = Class.forName("ninf.nws.TPingerNWS");
    } catch (ClassNotFoundException e){
      throw new ConfigureException("cannot get TPinger class for NWS");
    }

    // get NameServer address from scheduler

    try {
	MetaServerConnection con = conf.metaServer.connect();
	con.send(new NinfCommand("getNWSNameServer"));
	String res = con.readLine();
	if (res.charAt(0) != '+'){
	  dbg.log("cannot get NWSNameServer, failed to init NWS");
	  return;
	}
	conf.NWSNameServer = con.readLine();
	con.close();
	dbg.println("\tgot NWSNameServer: "+ conf.NWSNameServer);
    } catch (NinfException e) {
	  dbg.log("cannot get NWSNameServer, failed to init NWS");
	  return;
    }	    
    // invoke Memory, sensor, forecaster (if needed)	

    try {
	if (conf.NWSinvokeSensor)
	    invokeSensor(conf);
	if (conf.NWSinvokeForecaster)
	    invokeForecaster(conf);
    } catch (IOException e){
	throw new NinfIOException(e);
    }
    dbg.println("done.");
  }

  void invokeSensor(CProxyConfig conf) throws IOException{
    String nameServer = conf.NWSNameServer;
    Runtime runtime = Runtime.getRuntime();
    String memoryArgs[] = new String[9];
    memoryArgs[0] = conf.NWSdir + "/" + memoryExecutable;
    memoryArgs[1] = "-d";
    memoryArgs[2] = conf.NWSMemoryDir;
    memoryArgs[3] = "-N";
    memoryArgs[4] = conf.NWSNameServer;
    memoryArgs[5] = (conf.NWSMemoryErr == null)? "":"-e";
    memoryArgs[6] = (conf.NWSMemoryErr == null)? "":conf.NWSMemoryErr;
    memoryArgs[7] = (conf.NWSMemoryLog == null)? "":"-e";
    memoryArgs[8] = (conf.NWSMemoryLog == null)? "":conf.NWSMemoryLog;
    dbg.println("\tinvoking memory.");
    Process NWSMemory = runtime.exec(memoryArgs);

    String sensorArgs[] = new String[9];
    sensorArgs[0] = conf.NWSdir + "/" + sensorExecutable;
    sensorArgs[1] = "-M";
    sensorArgs[2] = conf.myhostname;
    sensorArgs[3] = "-N";
    sensorArgs[4] = conf.NWSNameServer;
    sensorArgs[5] = (conf.NWSSensorErr == null)? "":"-e";
    sensorArgs[6] = (conf.NWSSensorErr == null)? "":conf.NWSSensorErr;
    sensorArgs[7] = (conf.NWSSensorLog == null)? "":"-e";
    sensorArgs[8] = (conf.NWSSensorLog == null)? "":conf.NWSSensorLog;
    dbg.println("\tinvoking sensor.");
    Process NWSSensor = runtime.exec(sensorArgs);
  }
  
  void invokeForecaster(CProxyConfig conf) throws IOException{
    String nameServer = conf.NWSNameServer;
    Runtime runtime = Runtime.getRuntime();
    String forecasterArgs[] = new String[3];
    forecasterArgs[0] = conf.NWSdir + "/" + forecasterExecutable;
    forecasterArgs[1] = "-N";
    forecasterArgs[2] = conf.NWSNameServer;
    forecasterArgs[3] = (conf.NWSForecasterErr == null)? "":"-e";
    forecasterArgs[4] = (conf.NWSForecasterErr == null)? "":conf.NWSForecasterErr;
    forecasterArgs[5] = (conf.NWSForecasterLog == null)? "":"-e";
    forecasterArgs[6] = (conf.NWSForecasterLog == null)? "":conf.NWSForecasterLog;
    dbg.println("\tinvoking forecaster.");
    Process NWSForecaster = runtime.exec(forecasterArgs);
  }
}
