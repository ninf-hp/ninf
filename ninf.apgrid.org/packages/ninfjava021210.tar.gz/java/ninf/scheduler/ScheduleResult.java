package ninf.scheduler;
import ninf.metaserver.*;
import ninf.common.*;
import ninf.basic.*;
import ninf.client.*;

public class ScheduleResult {
  public ServerInformation serverInfo;
  public double[] predicted;  /* predicted time 0: whole, 1: fore,2:calc,3: back*/
  
  public ScheduleResult(ServerInformation serverInfo, double[] predicted){
    this.serverInfo = serverInfo;
    this.predicted = predicted;
  }
}
