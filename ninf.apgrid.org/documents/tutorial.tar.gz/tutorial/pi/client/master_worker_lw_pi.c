#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ninf.h"

#define DIV 10

char ** hosts;
int  * ports;
int read_map_file(char * filename, char *** hosts, int ** ports, char * entry);

int main(int argc, char ** argv){
  double pi;
  long times, whole_times, *count, sum = 0;
  int i, done = 0;
  int NUM_HOSTS;
  char ** entry;
  int * ids;
  Ninf_executable_t ** exe;

  if (argc < 3){
	fprintf(stderr, "USAGE: %s MAPFILE TIMES \n", argv[0]);
	exit(2);
  }

  NUM_HOSTS = read_map_file(argv[1], & hosts, & ports, "pi/pi_trial");
  if (NUM_HOSTS  == 0){
    fprintf(stderr, "No server available in the mapfile=\"%s\"\n", argv[1]);
    exit(3);
  }
  printf("Using %d server(s).\n", NUM_HOSTS);

  count = (long *)malloc(sizeof(long) * NUM_HOSTS);
  entry = (char **)malloc(sizeof(char *) * NUM_HOSTS);
  for (i = 0; i < NUM_HOSTS; i++)
    entry[i] = (char *)malloc(100);
  ids   = (int *)malloc(sizeof(int) * NUM_HOSTS);

  exe   = (Ninf_executable_t **)malloc(sizeof(Ninf_executable_t *) * NUM_HOSTS);

  if (argc < 2){
	fprintf(stderr, "USAGE: pi TIMES \n");
	exit(2);
  }
  whole_times = atol(argv[2]);
  times = (whole_times / NUM_HOSTS) / DIV ; 

  for (i = 0; i < NUM_HOSTS; i++){
	sprintf(entry[i], "ninf://%s:%d/pi/pi_trial", hosts[i], ports[i]);
	exe[i] = Ninf_get_executable(entry[i]);

	if ((ids[i] = 
		 Ninf_call_executable_async(exe[i], rand(), times, &count[i])) == NINF_ERROR){
	  Ninf_perror("pi_trial");
	  exit(2);
	}
  }
  while (1) {
	int id = Ninf_wait_any();        /* WAIT FOR ANY HOST */
	if (id == NINF_OK)
	  break;
	for (i = 0; i < NUM_HOSTS; i++)  /* FIND HOST */
	  if (ids[i] == id) break;
  
	sum += count[i];
	done += times;
	if (done >= whole_times){
	  Ninf_executable_finalize(exe[i]);
	  continue;
	}
	if ((ids[i] = 
		 Ninf_call_executable_async(exe[i], rand(), times, &count[i])) == NINF_ERROR){
	  Ninf_perror("pi_trial");
	  exit(2);
	}
  }
  pi = 4.0 * ( sum / (double)done);
  printf("PI = %f\n", pi);

  exit(0);
}
