#define _WRAPPER_
/* $Id: pdtrtrs_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define DOUBLE
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n
#define ROW_b ldb
#define COL_b nrhs
void  pdtrtrs_ninf(	 char uplo,
		 char trans,
		 char diag,
		 int n,
		 int nrhs,
		 double global_a[],
		 int lda,
		 double global_b[],
		 int ldb,
		 int *info
)
/* "pdtrtrs solves a triangular system of the form A * X = B or A**T * X =  B, where A is a triangular distributed matrix of order N, and B is an N-by-NRHS distributed matrix." */
/* OPTIONS */
{
extern void FortranCall(pdtrtrs)( char*, char*, char*,
				  int*, int*,
				  double*, int*, int*, int*,
				  double*, int*, int*, int*,
				  int*);
	int maxldd;

	int maxlda;
	double *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
	int row_loca, col_loca;

	int maxldb;
	double *locb=NULL;
	int descb[DESCLEN];
	int desc_gb[DESCLEN];
	int row_locb, col_locb;

	INITIALIZE();

	SCALAR( "char", uplo);
	SCALAR( "char", trans);
	SCALAR( "char", diag);
	SCALAR( "int", n);
	SCALAR( "int", nrhs);
	SCALAR( "int", lda);
	SCALAR( "int", ldb);

	ROW( a);
	COL( a);
	ROW( b);
	COL( b);
	MAXLDD( maxldd, a );
	maxlda = maxldd;
	maxldb = maxldd;

	trMATRIX( uplo, "double", a, ROW_a, COL_a);
	trDISTRIBUTE( uplo, "double", a, ROW_a, COL_a);
	MATRIX( "double", b, ROW_b, COL_b);
	DISTRIBUTE( "double", b, ROW_b, COL_b);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pdtrtrs)( &uplo, &trans, &diag,
                               &n, &nrhs,
                               loca, &one, &one, desca,
                               locb, &one, &one, descb,
                               &linfo);

	GATHER( "double", b, ROW_b, COL_b);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
		*info = linfo;
	} else {
	}

	FREE_MATRIX(a);
	FREE_MATRIX(b);
}

