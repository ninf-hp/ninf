package bricks.environment;
import bricks.util.*;
import java.io.*;
import java.util.*;

/** 
 * EPClient.java
 * <pre>
 * EPClient invoke EP tasks.
 * declaration: 
 * EPClient [name] [Scheduler name] Requests(\\<BR>
 *   [num of tasks] [data size for send] [data size for receive] \\
 *   [numInstruction] [interval of invoking])
 * </pre>
 */
public class EPClient extends Client {

    /**
     * The number sequence of tasks in the job.
     */
    protected Sequence numTasks;

    public Host scheduledHost;
    protected Hashtable tasks = new Hashtable();

    /** 
     * Constructs a EPClient with
     *     owner : a SimulationSet of your configuration,
     *     key : a key of the Client,
     *     keyOfScheduler : a key of the scheduler that allocates 
     *                      a new task of the Client,
     *     numTasks : number of tasks in the job.
     *     dataSizeForSend : dataSizeForSend of the Client,
     *     dataSizeForReceive : dataSizeForReceive of the Client,
     *     numInstructions : numInstructions of the Client,
     *     throwingInterval : throwingInterval of the Client.
     */
    public EPClient(
	SimulationSet owner, String key, String keyOfScheduler, 
	Sequence numTasks, 
	Sequence dataSizeForSend, Sequence dataSizeForReceive,
	Sequence numInstructions, Sequence throwingInterval
    ) {
	super(
	    owner, key, keyOfScheduler, numTasks, dataSizeForSend, 
	    dataSizeForReceive, numInstructions, throwingInterval
	);
	this.numTasks = numTasks;
    }

/************************* overriden method *************************/
    public String getName() {
	return "EPClient";
    }

    /** 
     * processEvent
     *     SEND_PACKET : sends the first packet of queue of the Packets.
     *     DISPATCH : dispatches the nextData.
     *     DIVIDE_PACKET : invokes data and decompose it into logical packets.
     */
    public void processEvent(double currentTime) {
	
	if (event == DISPATCH) {
	    //System.out.println(
	    SimulationDebug.println(
		"***** EPClient:" + Format.format(currentTime, 4) + 
		":" + host + ": DISPATCH " + nextData
	    );
	    //System.out.println("*****\n" + packets + "\n*****");
	    dispatchHosts(currentTime, (EPRequestedData)nextData);
	    nextData = getNextData(currentTime);

	} else if (event == DIVIDE_PACKET) { 
	    //System.out.println(
	    SimulationDebug.println(
		"EPClient: " + Format.format(currentTime, 4) + 
		": " + host + ": DIVIDE_PACKET " + nextData
	    );
	    RequestedData rd = (RequestedData)scheduledData.firstElement();
	    scheduledData.removeElementAt(0);
	    SimulationDebug.println(
		"EPClient:" + Format.format(currentTime, 4) + ":" +
		host + ": DIVIDE_PACKET " + rd
	    );
	    host.sendData(currentTime, rd);

	} else { /* RESCHEDULE */
	    //System.out.println(
	    SimulationDebug.println(
		"EPClient:" + Format.format(currentTime, 4) + 
		":" + host + ": RESCHEDULE "
	    );
	    EPRequestedData d = (EPRequestedData)rescheduledList.firstElement();
	    rescheduledList.removeElementAt(0);
	    dispatchHosts(currentTime, d);
	}
    }

    /** 
     * calls the data's outLogString when the RequestData 
     * returns to the Client.
     */
    public void schedule(double currentTime, Data data) {

	if (!(data instanceof EPRequestedData)) {
	    BricksUtil.abort("EPClient.schedule(): This is not an instance of EPRequestedData");
	}

	EPRequestedData epdata = (EPRequestedData)data;
	EPRequestedData org = (EPRequestedData)tasks.get(epdata.id);
	scheduler.finishTask(epdata.epTask);

	if (epdata.outLogString(currentTime, org)) { /* finish one job */
	    org.outOrgLogString(currentTime);
	    tasks.remove(org);

	} else { /* org is not completed. */
	    //System.out.println("schedule next!! -----" + org + "-----");
	    if (org.hasMoreNotScheduledTasks()) {
		//System.out.println("schedule next!! ===" + org + " ===");
		dispatchHosts(currentTime, org, epdata.epTask);
		updateNextEvent(currentTime);
	    }
	}
    }

    /**
     * for fallback
     **/
    public void fallback(double currentTime, RequestedData data) {
	if (data instanceof EPRequestedData) {
	    EPRequestedData epdata = (EPRequestedData)data;
	    scheduler.finishTask(epdata.epTask);
	    dispatchHosts(currentTime, epdata, epdata.epTask);
	    updateNextEvent(currentTime);
	} else {
	    BricksUtil.abort(host + "data is not EPRequestedData");
	}
    }


/************************* protected method *************************/
    // NEED TO MODIFY!!
    protected Data getNextData(double currentTime) {
	double timeEventComes =
	    currentTime + throwingInterval.nextDouble(currentTime);
	EPRequestedData d = new EPRequestedData(
	    host, timeEventComes, numTasks.nextInt(), dataSizeForSend,
	    dataSizeForReceive, numInstructions
	);
	if (deadlineFactors != null)
	    d.setDeadlineFactor(deadlineFactors.nextDouble());
	return d;
    }

    // error
    protected void dispatchHosts(double currentTime, RequestedData data) {
	BricksUtil.abort("EPClient.dispatchHosts(): This is not an instance of EPRequestedData");
    }

    // first
    protected void dispatchHosts(double currentTime, EPRequestedData epdata) {
	try {
	    if ((epdata.deadline < 0.) && (epdata.deadlineFactor > 0)) {
		epdata.deadline = scheduler.getDeadline(currentTime, epdata);
	    }
	    scheduler.selectHosts(currentTime, host, epdata);

	    epdata.startTime = currentTime;
	    epdata.first = false;

	    Vector scheduled = epdata.getScheduledTasks();
	    /* add epdata into tasks */
	    tasks.put(epdata.id, epdata);
	    
	    for (int i = scheduled.size() - 1; i >= 0; i--) {
		EPRequestedData d = (EPRequestedData)scheduled.elementAt(i);
		d.epTask.startTime = d.timeEventComes;
		Host node = (Host)d.destination;
		//initRoute(d.timeEventComes, d, node);
		d.initRoute(currentTime, d.destination, owner);
		/* moved from processEvent */
		scheduledData.addElement(d);
	    }
	    SimulationDebug.println(
	        "EPClient: scheduledData.size = " + scheduledData.size()
	    );

	} catch (BricksNotScheduledException e) {
	    SimulationDebug.println(e);
	    epdata.outLogString(epdata + " scheduling failed");
	    /* add epdata into reschedulingList */
	    addIntoRescheduledList(epdata);
	}
    }

    // second or more
    protected void dispatchHosts(
	double currentTime, EPRequestedData epdata, EPTask epTask
    ) {
	//System.out.println("second or more");
	try {
	    if ((epdata.deadline < 0.) && (epdata.deadlineFactor > 0)) {
		epdata.deadline = scheduler.getDeadline(currentTime, epdata);
	    }
	    scheduler.selectHosts(currentTime, host, epdata, epTask);
	    Vector scheduled = epdata.getScheduledTasks();

	    // some tasks scheduled
	    for (int i = scheduled.size() - 1; i >= 0; i--) {
		EPRequestedData d = (EPRequestedData)scheduled.elementAt(i);
		d.epTask.startTime = d.timeEventComes;
		Host node = (Host)d.destination;
		//initRoute(d.timeEventComes, d, node);
		d.initRoute(d.timeEventComes, d.destination, owner);
		// moved from processEvent 
		scheduledData.addElement(d);
	    }

	} catch (BricksNotScheduledException e) {
	    SimulationDebug.println(e);
	    epdata.outLogString(epdata + " scheduling failed");
	    // add epdata into reschedulingList
	    addIntoRescheduledList(epdata);
	}
    }
}

