package bricks.util;
import bricks.environment.*;
import bricks.scheduling.*;
import java.lang.reflect.*;
import java.util.*;

public class ComponentFactory {
    protected SimulationSet owner;
    protected Hashtable hashtableOfCreator = new Hashtable();
    protected SubComponentFactory subComponentFactory;
    protected SchedulingUnitFactory schedulingUnitFactory;

    public ComponentFactory(SimulationSet owner) {
	this.owner = owner;
	subComponentFactory = new SubComponentFactory(owner);
	schedulingUnitFactory = new SchedulingUnitFactory(owner, subComponentFactory);
	init();
    }
    
    public void create(String key, String information) throws BricksParseException {
	SimulationDebug.println("ComponentFactory : key = " + key);
	ComponentCreator componentCreator = 
	    (ComponentCreator)hashtableOfCreator.get(key.toLowerCase());
	try {
	    if (componentCreator == null) {
		componentCreator = (ComponentCreator)Class.forName(key + "Creator").newInstance();
		componentCreator.set(owner, subComponentFactory);
		hashtableOfCreator.put(key.toLowerCase(), componentCreator);
	    }
	    componentCreator.create(information);
	    
	}  catch (BricksParseException e) {
	    throw e;
	    
	} catch (ClassNotFoundException e) {
	    e.printStackTrace();
	    throw new BricksParseException(noEntryError(key));
	    
	} catch (IllegalAccessException e) {
	    e.printStackTrace();
	    throw new BricksParseException(noEntryError(key));
	    
	} catch (InstantiationException e) {
	    e.printStackTrace();
	    throw new BricksParseException(noEntryError(key));
	}
    }

    /** for HostCreator */
    public Node create(String str) throws BricksParseException {
	
	StringTokenizer st = new StringTokenizer(str);
	String key = st.nextToken(" \t(),");
	SimulationDebug.println("ComponentFactory : key = " + key);
	if (key.equalsIgnoreCase("n/a"))
	    return null;
	    
	try {
	    ComponentCreator componentCreator = 
		(ComponentCreator)hashtableOfCreator.get(key.toLowerCase());
	    if (componentCreator == null) {
		componentCreator = (ComponentCreator)Class.forName(key + "Creator").newInstance();
		componentCreator.set(owner, subComponentFactory);
		hashtableOfCreator.put(key.toLowerCase(), componentCreator);
	    }
	    return componentCreator.createNode(str);

	}  catch (BricksParseException e) {
	    throw e;

	} catch (ClassNotFoundException e) {
	    e.printStackTrace();
	    throw new BricksParseException(noEntryError(key));

	} catch (IllegalAccessException e) {
	    e.printStackTrace();
	    throw new BricksParseException(noEntryError(key));

	} catch (InstantiationException e) {
	    e.printStackTrace();
	    throw new BricksParseException(noEntryError(key));

	}
    }

/************************* protected method *************************/
    protected String noEntryError(String key) {
	return this + ": no creator entry for key [" + key + "]";
    }

    // init hashtableOfCreator
    protected void init() {
	// Host
	ComponentCreator creator = new HostCreator(
	    owner, this, subComponentFactory
	);
	hashtableOfCreator.put("host", creator);

	// Client
	creator = new ClientCreator(owner, subComponentFactory);
	hashtableOfCreator.put("client", creator);

	// EPClient
	creator = new EPClientCreator(owner, subComponentFactory);
	hashtableOfCreator.put("epclient", creator);

	// Server
	creator = new ServerCreator(owner, subComponentFactory);
	hashtableOfCreator.put("server", creator);

	// FallbackServer
	creator = new FallbackServerCreator(owner, subComponentFactory);
	hashtableOfCreator.put("fallbackserver", creator);

	// Disk
	creator = new DiskCreator(owner, subComponentFactory);
	hashtableOfCreator.put("disk", creator);

	// Network
	creator = new NetworkCreator(owner, subComponentFactory);
	hashtableOfCreator.put("network", creator);

	// ForwardNode
	creator = new ForwardNodeCreator(owner, subComponentFactory);
	hashtableOfCreator.put("node", creator);

	// Link
	creator = new LinkCreator(owner, subComponentFactory);
	hashtableOfCreator.put("link", creator);

	// Scheduler
	creator = new SchedulerCreator(
	    owner, schedulingUnitFactory, subComponentFactory
	);
	hashtableOfCreator.put("scheduler", creator);

	// NetworkMonitor
	creator = new NetworkMonitorCreator(
	    owner, schedulingUnitFactory, subComponentFactory
	);
	hashtableOfCreator.put("networkmonitor", creator);

	// ServerMonitor
	creator = new ServerMonitorCreator(
	    owner, schedulingUnitFactory, subComponentFactory
	);
	hashtableOfCreator.put("servermonitor", creator);

	// ReplicaManager
	creator = new ReplicaManagerCreator(
	    owner, schedulingUnitFactory, subComponentFactory
	);
	hashtableOfCreator.put("replicamanager", creator);

	// ResourceDB
	creator = new ResourceDBCreator(
	    owner, schedulingUnitFactory, subComponentFactory
	);
	hashtableOfCreator.put("resourcedb", creator);

	// MetaPredictor
	creator = new MetaPredictorCreator(owner, subComponentFactory);
	hashtableOfCreator.put("predictor", creator);
    }
}
