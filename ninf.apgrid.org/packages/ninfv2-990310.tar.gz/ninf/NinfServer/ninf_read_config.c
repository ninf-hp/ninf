#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>

#include "ninf_macros.h"
#include "ninf_read_config.h"
#include "throughput_measure.h"

#define CONFIG_MAIN
#include "ninf_config.h"

#define MAX_LINE_LEN 1000
void set_lookup_flag(int i);

char * save_str();
char * xmalloc();

add_last_read_stub_item(struct read_stub_item * tmp2)
{
  struct read_stub_item * tmp = read_stub_item_root;
  
  if (read_stub_item_root == NULL){
    read_stub_item_root = tmp2;
    return;
  }
  while (tmp->next != NULL)
    tmp = tmp->next;
  tmp->next = tmp2;
}

add_last_metaserver_item(struct metaserver_item * tmp2)
{
  struct metaserver_item * tmp = metaserver_item_root;
  
  if (metaserver_item_root == NULL){
    metaserver_item_root = tmp2;
    return;
  }
  while (tmp->next != NULL)
    tmp = tmp->next;
  tmp->next = tmp2;
}

char * read_configure_file(char * filename)
{
  char * service = NULL;
  char buffer[MAX_LINE_LEN];
  FILE * fp;
  if ((fp = fopen(filename, "r")) == NULL){
    fprintf(stderr, "Can't read configuration file: %s\n", filename);
    fprintf(stderr, "      Using default configuration ...\n");
    return NULL;
  }
  
  while (fgets(buffer, MAX_LINE_LEN - 2, fp) != NULL){
    char * command, * arg;
    if (buffer[0] == '#')
      continue;
    command = strtok(buffer, " \t\n:");
    if (command == NULL)
      continue;
    if (strncmp(command, "port", 5) == 0){
      service = save_str(strtok(NULL, " \t\n:"));
      if (atoi(service) == 0)
	service = NULL;
      continue;
    }
    if (strncmp(command, "performance", 12) == 0){
      performance = atoi(strtok(NULL, " \t\n:"));
      continue;
    }
    if (strncmp(command, "linpack_size", 13) == 0){
      linpack_size = atoi(strtok(NULL, " \t\n:"));
      continue;
    }
    if (strncmp(command, "CPUs", 5) == 0){
      CPUs = atoi(strtok(NULL, " \t\n:"));
      continue;
    }
    if (strncmp(command, "MPICPUs", 8) == 0){
      MPI_PROCS = atoi(strtok(NULL, " \t\n:"));
      continue;
    }
    if (strncmp(command, "mpirun", 7) == 0){
      MPIRUN = save_str(strtok(NULL, "#\n"));
      continue;
    }
    if (strncmp(command, "stubs", 6) == 0){
      struct read_stub_item * tmp = (struct read_stub_item *) xmalloc(sizeof(struct read_stub_item));
      arg = save_str(strtok(NULL, " \t\n:"));
      tmp->stub_file_name = arg;
      add_last_read_stub_item(tmp);
      continue;
    }
    if (strncmp(command, "measure", 8) == 0){
      measure_servers = new_measure_server(measure_servers);
      arg = save_str(strtok(NULL, " \t\n:"));
      measure_servers->host = arg;
      arg = save_str(strtok(NULL, " \t\n:"));
      measure_servers->port = arg;
      continue;
    }
    if (strncmp(command, "interval", 9) == 0){
      measure_interval = atoi(strtok(NULL, " \t\n:"));
      continue;
    }
    if (strncmp(command, "throughputSize", 15) == 0){
      measure_size = atoi(strtok(NULL, " \t\n:"));
      continue;
    }
    if (strncmp(command, "metaserver", 11) == 0) {
      struct metaserver_item * tmp =
	(struct metaserver_item *) xmalloc(sizeof(struct metaserver_item));
      
      tmp->hostname = save_str(strtok(NULL, " \t\n:"));
      tmp->port = save_str(strtok(NULL, " \t\n:"));
      
      /*      fprintf(stderr, "hostname = >%s< port = >%s<\n",
	      tmp->hostname, tmp->port); */
      add_last_metaserver_item(tmp);
      continue;
    }
    if (strncmp(command, "myname", 7) == 0) {
      myname = save_str(strtok(NULL, " \t\n:"));
      continue;
    }
    if (strncmp(command, "myhostname", 11) == 0) {
      myname = save_str(strtok(NULL, " \t\n:"));
      continue;
    }
    if (strncmp(command, "lookup", 7) == 0) {
      set_lookup_flag(strcasecmp("on", strtok(NULL, " \t\n:")) == 0);
      continue;
    }
    if (strncmp(command, "log", 4) == 0) {
      logfile = save_str(strtok(NULL, " \t\n:"));
      continue;
    }
    if (strncmp(command, "tmpFileRoot", 12) == 0) {
      TMP_FILE_ROOT = save_str(strtok(NULL, " \t\n:"));
      continue;
    }
    if (strncmp(command, "redirect", 9) == 0) {
      char * tmparg = strtok(NULL, " \t\n:");
      if (strncmp(tmparg, "no", 3) == 0)
	redirect_outerr = FALSE;
      else if (strncmp(tmparg, "yes", 4) == 0)
	redirect_outerr = TRUE;	
      else
	fprintf(stderr, "CONFIGERR: redirect argument must be [yes|no]\n");
      continue;
    }
    fprintf(stderr, "CONFIGERR: unknown command %s\n", command);
  }
  return service;
}
