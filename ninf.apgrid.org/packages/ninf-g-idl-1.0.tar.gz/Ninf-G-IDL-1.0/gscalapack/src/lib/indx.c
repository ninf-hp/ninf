int MOD( int a, int b)
{
  int ret=1;
  ret = a/b;
  ret = a - ret*b;
  return ret;
}

int Cindxg2p( int indxglob, int nb, int iproc, int isrcproc, int nprocs)
{
  int indxg2p;
  indxg2p = MOD( isrcproc + (indxglob - 1) /nb, nprocs );
  return indxg2p;
}

int Cindxg2l(  int indxglob, int nb, int iproc, int isrcproc, int nprocs)
{
  int indxg2l;
  indxg2l = nb*((indxglob-1)/(nb*nprocs))+MOD(indxglob-1,nb)+1;
  return indxg2l;
}

int Cindxl2g(  int indxloc, int nb, int iproc, int isrcproc, int nprocs)
{
  int indxl2g;
  indxl2g = nprocs*nb*((indxloc-1)/nb) + MOD(indxloc-1,nb) + MOD(nprocs+iproc-isrcproc, nprocs)*nb + 1;
  return indxl2g;
}



