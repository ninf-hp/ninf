#define _WRAPPER_
/* $Id: pdpbtrf_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define _DISTRIBUTE_1D_
#define DOUBLE
#define NO_PIVOT
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n
static	int worklen(int bw) {
	  int ret=1;
	  ret = bw*bw;
	  return ret;
}

void  pdpbtrf_ninf(	 char uplo,
		 int n,
		 int bw,
		 double global_a[],
		 int lda,
		 int *info
)
/* "pdpbtrf computes a Cholesky factorization of an N-by-N real banded symmetric positive definite distributed matrix with bandwidth BW: A." */
/* OPTIONS */
{
    extern void FortranCall(pdpbtrf)( char*, int*, int*,
                               double*, int*, int*,
                               double*, int*,
                               double*, int*,
                               int*);

	int maxldd;

	int maxlda;
	double *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];

	double *locaf=NULL;
	int laf;

	double *locwork=NULL;
	int llocwork;


	INITIALIZE();

	SCALAR( "char", uplo);
	SCALAR( "int", n);
	SCALAR( "int", bw);
	SCALAR("int", lda);
	SIZE(n);

	if (chrcmp(uplo,'u')==0) {
	  bandMATRIX( "double", a, 0, bw, n);
	  bandDISTRIBUTE( "double", a, 0, bw, n);
	}else {
	  bandMATRIX( "double", a, bw, 0, n);
	  bandDISTRIBUTE( "double", a, bw, 0, n);
	}

	laf=(blocsize+2*bw)*bw;
	locaf=MALLOC(sizeof(double)*laf);
        assert(locaf);
        
	llocwork = worklen(bw);
	WORK(locwork, llocwork);
	
	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pdpbtrf)( &uplo, &n, &bw,
                               loca, &one, desca,
                               locaf, &laf,
                               locwork, &llocwork,
                               &linfo);

	if (chrcmp(uplo,'u')==0) {
	  bandGATHER( "double", a, 0, bw, n);
	}else {
	  bandGATHER( "double", a, bw, 0, n);
	}

	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
	  *info = linfo;
	} else {
		
	}
	FREE_MATRIX(a);
        FREE(locaf);
        FREE(locwork);
	
}

