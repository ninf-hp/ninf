#define _WRAPPER_
/* $Id: pslacp2_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define FLOAT
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n
#define ROW_b ldb
#define COL_b n
void  pslacp2_ninf(	 char uplo,
		 int m,
		 int n,
		 float global_a[],
		 int lda,
		 float global_b[],
		 int ldb
	)
/* "pslacp2 copies all or part of a distributed matrix A to another distributed matrix B." */
/* OPTIONS */
{
	int maxldd;

	int maxlda;
	float *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
	int row_loca, col_loca;

	int maxldb;
	float *locb=NULL;
	int descb[DESCLEN];
	int desc_gb[DESCLEN];
	int row_locb, col_locb;


	INITIALIZE();

	SCALAR( "char", uplo);
	SCALAR( "int", m);
	SCALAR( "int", n);

	ROW( a);
	COL( a);
	ROW( b);
	COL( b);
	MAXLDD( maxldd, a );
	maxlda = maxldd;
	maxldb = maxldd;
	MATRIX( "float", a, ROW_a, COL_a);
	MATRIX( "float", b, ROW_b, COL_b);
	DISTRIBUTE( "float", a, ROW_a  , COL_a);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pslacp2)( &uplo, &m, &n,
                               loca, &one, &one, desca,
                               locb, &one, &one, descb);

	GATHER( "float", b, ROW_b  , COL_b);

	if( mypnum == 0 ){
	} else {
	}

	FREE_MATRIX(a);
	FREE_MATRIX(b);

	
}

