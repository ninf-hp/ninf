/*
 *  $Id
 */

#ifndef  __NINF_MACROS_H__
#define  __NINF_MACROS_H__

/* default sever port */
#define NINF_SERVER_PORT "3000"

#ifndef NINF_ERROR
#define NINF_ERROR	(-1)
#endif

#ifndef NINF_OK
#define NINF_OK		0
#endif 

#ifndef NINF_ALL_DONE
#define NINF_ALL_DONE   1
#endif

#ifndef BOOLEAN 
#define BOOLEAN int
#endif

#ifndef TRUE
#define TRUE	1
#endif

#ifndef FALSE
#define FALSE	0
#endif

#ifndef NULL
#define NULL ((void *) 0)
#endif 

#define NINF_SHELL_STREAM     2
#define NINF_SHELL_CALLBACK   1
#define NINF_SHELL_NO         0

#if defined(__sunos4__) || defined(__cray__) || defined(__linux__) || defined(WIN32)
#define _NO_LONGLONG_
#endif

#ifdef WIN32
#define strcasecmp(x, y) stricmp(x,y)
#endif

#define NINF_MAX_NAME_LEN	100

extern int ninf_debug_flag;

#if 0
char * myalloc(int size);
#define calloc(count, len) ({char * addr = (char *)calloc(count, len); fprintf(stderr,"%p A %s:%5d, %d\n", addr, __FILE__, __LINE__, count * len); addr;})
#define malloc(size) ({void * addr = (void *)myalloc(size); fprintf(stderr,"%p A %s:%5d, %d\n", addr, __FILE__, __LINE__, size); addr;})
#define free(ptr) (free(ptr), fprintf(stderr,"%p F %s:%5d\n", ptr, __FILE__, __LINE__))
#define realloc(ptr, size) ({\
  void * addr = (void *)realloc(ptr, size);\
  fprintf(stderr,"%p F %s:%5d, %d\n",  ptr, __FILE__, __LINE__);\
  fprintf(stderr,"%p A %s:%5d, %d\n", addr, __FILE__, __LINE__, size);\
  addr;})


#endif 

#endif

