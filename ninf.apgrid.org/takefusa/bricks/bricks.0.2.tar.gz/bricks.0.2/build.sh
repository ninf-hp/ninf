#! /bin/sh

# $Id: build.sh,v 1.1 2001/12/02 14:47:00 takefusa Exp $

if [ -z "$JAVA_HOME" ] ; then
  JAVA=`which java`
  if [ -z "$JAVA" ] ; then
    echo "Cannot find JAVA. Please set your PATH."
    exit 1
  fi
  JAVA_BIN=`dirname $JAVA`
  JAVA_HOME=$JAVA_BIN/..
fi

JAVA=$JAVA_HOME/bin/java
echo $JAVA

CLASSPATH=`echo lib/*.jar | tr ' ' ':'`:$CLASSPATH
CLASSPATH=$JAVA_HOME/lib/tools.jar:./build/classes:$CLASSPATH

($JAVA -classpath $CLASSPATH -DCOGBOX_HOME=$COGBOX_HOME -DCOGBOX_PROPERTIES_FILE=$COGBOX_PROPERTIES_FILE -DCOGBOX_RSL_DIRECTORY=$COGBOX_RSL_DIRECTORY -Dant.home=lib org.apache.tools.ant.Main "$@" -buildfile  ./bricks.xml)

