#define _WRAPPER_
/* $Id: pcdtsv_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define _DISTRIBUTE_1D_
#define SCOMPLEX
#include <gscalapack.h>

#define ROW_b ldb
#define COL_b nrhs
static	int worklen(int n, int nrhs) {
	  int ret=1;
	  ret = (12+3*n) +max(10+4*nrhs, 8);
	  if NEED_BUFF 
              ret =  (12*npcol+3*blocsize) +max(10*npcol+4*nrhs, 8*npcol);
	  return ret;
}

void  pcdtsv_ninf(	 int n,
		 int nrhs,
		 scomplex global_dl[],
		 scomplex global_d[],
		 scomplex global_du[],
		 scomplex global_b[],
		 int ldb,
		 scomplex work[],
		 int lwork,
		 int *info
)
/* "pcdtsv solves a system of linear equations A * X = B where A is an N-by-N complex tridiagonal diagonally dominant-like distributed matrix." */
/* OPTIONS */
{
	extern void FortranCall(pcdtsv)( int*, int*,
                              scomplex*, scomplex*, scomplex*, int*, int*,
                              scomplex*, int*, int*,
                              scomplex*, int*, int*);

	int maxldd;

	scomplex *locdl=NULL, *locd=NULL, *locdu=NULL;
	int desctdd[DESCLEN];
	int desc_gtdd[DESCLEN];

	int maxldb;
	scomplex *locb=NULL;
	int descb[DESCLEN];
	int desc_gb[DESCLEN];
	int row_locb, col_locb;

	scomplex *locwork=NULL;
	int llocwork;

	INITIALIZE();

	SCALAR( "int", n);
	SCALAR( "int", nrhs);
	SCALAR( "int", lwork);
	SCALAR("int", ldb);
	SCALAR( "int", lwork);

	SIZE(n);

	ROW(b);
	COL(b);
	MAXLDD( maxldd, b);
	maxldb = maxldd;

	tdMATRIX( "scomplex", dl, d, du, n);
	MATRIX( "scomplex", b, ROW_b, COL_b);
	tdDISTRIBUTE( "scomplex", dl, d, du, n);
	DISTRIBUTE( "scomplex", b, ROW_b, COL_b);

	llocwork = worklen(n, nrhs);
        llocwork = max( llocwork, lwork);
	WORK(locwork, llocwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pcdtsv)( &n, &nrhs,
                              locdl, locd, locdu, &one, desctdd,
                              locb, &one, descb,
                              locwork, &llocwork, &linfo);

	tdGATHER( "scomplex", dl, d, du, n);
	GATHER( "scomplex", b, ROW_b, COL_b);

	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
	  *info = linfo;
	} else {
	}
        
	FREE_MATRIX(dl);
	FREE_MATRIX(d);
	FREE_MATRIX(du);
	FREE_MATRIX(b);

        FREE(locwork);
}

