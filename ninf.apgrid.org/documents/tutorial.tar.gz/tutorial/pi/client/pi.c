#include <stdio.h>
#include <stdlib.h>

long pi_trial(int seed, long times){
  long l, counter = 0;
  srandom(seed);

  for (l = 0; l < times; l++){
	double x = (double)random() /	RAND_MAX;
	double y = (double)random() /	RAND_MAX;
	if (x * x + y * y < 1.0)
	  counter++;
  }
  return counter;
}


int main(int argc, char ** argv){
  double pi;
  long times, count;

  if (argc < 2){
	fprintf(stderr, "USAGE: pi TIMES \n");
	exit(2);
  }
  times = atol(argv[1]);
  count = pi_trial(10, times);

  pi = 4.0 * (count / (double) times);
  printf("PI = %f\n", pi);
  exit(0);
}
