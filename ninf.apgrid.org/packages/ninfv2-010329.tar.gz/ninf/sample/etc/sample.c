#include <stdio.h>
/* sample library */

mmul(N,A,B,C)
     double *A,*B,*C;
{
    double t;
    int i,j,k;
    
    printf("N=%d, A=0x%x, B=0x%x, C=0x%x\n",N,A,B,C);
    printf("A(1,1)=%e\n",A[1*N+1]);
    printf("B(1,1)=%e\n",B[1*N+1]);

    for (i=0;i<N;i++) {
	for (j=0;j<N;j++) {
	    t = 0;
	    for (k=0;k<N;k++){
		t += A[i*N + k] * B[k*N+j];	/* inner product */
	    }
	    C[i*N+j] = t;
	}
    }
    printf("C(1,1)=%e\n",C[1*N+1]);
    /*sleep(3);*/
}

FFT(n,x,y)
{
    printf("no FFT sorry!\n");
}
