package ninf.basic;

public interface Checkable{
  public boolean check();
}
