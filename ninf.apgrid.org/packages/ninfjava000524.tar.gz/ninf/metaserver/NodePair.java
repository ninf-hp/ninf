package ninf.metaserver;
import ninf.basic.*;
import ninf.common.*;
import ninf.client.*;

public class NodePair {
  public ServerID from;
  public ServerID to;

  public NodePair(ServerID from, ServerID to){
    this.from = from;
    this.to   = to;
  }

  public String toString(){
    return from + "-" + to;
  }
  
  public int hashCode(){
    return from.hashCode() + to.hashCode();
  }

  public boolean equals(Object o){
    if (!(o instanceof NodePair))
      return false;
    NodePair p = (NodePair)o;

    if ((p.from.equals(from) && p.to.  equals(to)) ||
	(p.to  .equals(from) && p.from.equals(to)))
      return true;
    return false;
  }
}
