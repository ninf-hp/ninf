package jp.go.aist.gtrc.util.impl;

import jp.go.aist.gtrc.util.OperationAN;
import jp.go.aist.gtrc.util.PropertyAN;

public class TestResource {
	@PropertyAN
	private int count;
}
