/* 
 * ninf_sever structures
 */

#ifndef __NINF_SERVER_STATE_H__
#define __NINF_SERVER_STATE_H__

#if defined(_AIX)
#include <sys/select.h>
#endif

#include "connection.h"

typedef struct server_state {
  connection * client;
  connection * stub;
  connection * stub_out;
  connection * stub_err;
  int stub_pid;
  char * clientname;
  char * username;
} server_state;


server_state * new_server_state(int socket, int withHeader, int accepting, 
				char * clientname, char * username
#ifdef SSL_USE
				, int ssl_use
#endif
);


void destruct_server_state(server_state * state);

int state_forward_stub_err(server_state * state);
int state_forward_stub_out(server_state * state);


/************ ninf_fd_set **************/
typedef struct ninf_fd_set {
  fd_set fds;  
  int max;
} ninf_fd_set;

void fd_set_zero(ninf_fd_set * prfds);
void fd_set_set_fd(ninf_fd_set * prfds, int fd);
void fd_set_set_connection(ninf_fd_set *prfds, connection * con);
int fd_set_max(ninf_fd_set * prfds);
int fd_set_is_set_fd(ninf_fd_set *prfds, int fd);
int fd_set_is_set_connection(ninf_fd_set *prfds, connection * con);



#endif /* __NINF_SERVER_STATE_H__ */
