package ninf.scheduler;
import ninf.common.*;
import ninf.metaserver.*;
import ninf.basic.*;
import ninf.client.*;
import ninf.cproxy.aggregate.*;
import java.util.Vector;

public abstract class AggregateScheduler {
  public abstract AggregateScheduled 
  schedule(DataFlow dataFlow, 
	   NinfServerStruct servers[], SchedulerRoot schedulerRoot, 
	   ServerID cproxy, StringBuffer sb)
       throws NinfException;
}
