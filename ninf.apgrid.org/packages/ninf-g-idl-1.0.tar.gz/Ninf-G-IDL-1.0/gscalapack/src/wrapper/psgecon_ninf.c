#define _WRAPPER_
/* $Id: psgecon_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define FLOAT
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n
static	int worklen(int n) {
	  int ret=1;
#define MB rbloc
#define NB cbloc
#define LOCr_a(m) Cnumroc( (m), rbloc, myprow, 0, nprow)
#define LOCc_a(n) Cnumroc( (n), cbloc, mypcol, 0, npcol)
	  ret = 2*n + 2*n + max( 2, n) + n;
	  if NEED_BUFF {
            ret = 2*LOCr_a(n) + 2*LOCc_a(n)
	      + max( 2, max( NB*MAX( 1, ceil(nprow-1,npcol) ), LOCc_a(n))
		     +  NB*MAX( 1, ceil(npcol-1,nprow) ) );
	  }
	  return ret;
}

static	int iworklen(int n) {
	  int ret=1;
	  ret = n;
	  if NEED_BUFF {
            ret = LOCr_a(n);
	  }
	  return ret;
}


void  psgecon_ninf(	 char norm,
		 int n,
		 float global_a[],
		 int lda,
		 float anorm,
		 float *rcond,
		 float work[],
		 int iwork[],
		 int *info
)
/* "psgecon estimates the reciprocal of the condition number of a general distributed real matrix A, in either the 1-norm or the infinity-norm, using the LU factorization computed by PSGETRF." */
/* OPTIONS */
{
	int maxldd;

	int maxlda;
	float *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
	int row_loca, col_loca;

	float locrcond[1];

        float *locwork=NULL;
        int llocwork;
        int *lociwork;
        int llociwork;

	INITIALIZE();

	SCALAR( "char", norm);
	SCALAR( "int", n);
	SCALAR( "float", anorm);
	SCALAR( "int", lda);

	ROW( a);
	COL( a);
	MAXLDD( maxldd, a );
	maxlda = maxldd;
        
	MATRIX( "float", a, ROW_a, COL_a);
	DISTRIBUTE( "float", a, ROW_a  , COL_a);

	llocwork=worklen(n);
	WORK(locwork,llocwork);
	llociwork=iworklen(n);
	WORK(lociwork,llociwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(psgecon)( &norm, &n,
                               loca, &one, &one, desca,
                               &anorm,
                               locrcond,
                               locwork, &llocwork,
                               lociwork, &llociwork,
                               &linfo);

        RETRIEVE("float",locrcond,1);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
	  *rcond = *locrcond;
	  *info = linfo;
	} else {
	}

	FREE_MATRIX(a);
        FREE(locwork);
        FREE(lociwork);
	
}

