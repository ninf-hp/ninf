#ifndef __CONNECTION__
#define __CONNECTION__

#ifdef SSL_USE
#include <ssl.h>
#endif

#include <ninf_data_trans.h>

typedef struct connection {
#ifdef SSL_USE
  SSL * ssl;
  SSL_CTX * ctx;
#endif
  dataTrans * sDT;
  dataTrans * rDT;
  int accepting;
  /* to reuse the port, the accepting socket have to wait the peer
     to close the socket */
} connection;

connection * new_connection(int fd, int withHeader, int accepting
#ifdef SSL_USE
   , SSL_CTX * ctx
#endif			    
);
int ninf_disconnect(connection * con);
int connection_close(connection * con);
int connection_get_fd(connection * con);
int connection_set_non_block(connection * con);
int connection_read_onemore(connection * con);

#endif 

