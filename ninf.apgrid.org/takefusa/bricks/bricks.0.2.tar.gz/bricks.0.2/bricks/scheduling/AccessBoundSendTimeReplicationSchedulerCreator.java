package bricks.scheduling;
import bricks.util.*;
import java.util.*;

public class AccessBoundSendTimeReplicationSchedulerCreator extends SchedulingUnitCreator {

    public String usage() {
	return "AccessBoundSendTimeReplicationScheduler(<String keyOfPredictor>, <String keyOfReplicaManager>, <String keyOfServerMonitor>, <double minAccessScore(=performance/(AccessFrequency+1))>)";
    }

    public SchedulingUnit create(StringTokenizer st) 
	throws BricksParseException 
    {
	try {
	    String keyOfMetaPredictor = st.nextToken(" \t,()");
	    String keyOfReplicaManager = st.nextToken(" \t,()");
	    String keyOfServerMonitor = st.nextToken(" \t,()");
	    double minAccessScore = 
		Double.valueOf(st.nextToken(" \t,()")).doubleValue();

	    return new AccessBoundSendTimeReplicationScheduler(
		keyOfMetaPredictor, keyOfReplicaManager, 
		keyOfServerMonitor, minAccessScore
	    );

	} catch (NoSuchElementException e) {
	    e.printStackTrace();
	    throw new BricksParseException(usage());

	} catch (NumberFormatException e) {
	    e.printStackTrace();
	    throw new BricksParseException(usage());
	}
    }
}

