/*
 * Cnumroc.c
 *
 *
 *
 * Written by Keita Teranishi
 * 8/9/1999
 */

#define max(a,b) ((a)>(b) ? (a) : (b))

/* numroc( n, nb, iproc, isrcproc, nprocs) is a utility which */
/* returns a size the iproc-th node has when a datum will be distributed */
/* in manners of block-cyclic(for general matrix) or block (for  */
/* band or tridiagonal matrix). */

/* n: global size */
/* nb: a size of one block */
/* iproc: iproc-th node */
/* isrcproc: an initial proc given the first block datum */
/* nprocs: # of procs */

int Cnumroc ( int n, int nb, int iproc, int isrcproc, int nprocs ) 
{

   int extrablks, mydist, nblocks, tmp;

   /* Figure PROC's distance from source process */

   mydist = (nprocs+iproc-isrcproc)%nprocs;

   /* Figure the total number of whole NB blocks N is split up into */

   nblocks = n/ nb;

   /* Figure the minimum number of rows/cols a process can have */

   tmp = (nblocks/nprocs) * nb;
   extrablks = nblocks%nprocs;

   /* If i have an extra block */

   if( mydist < extrablks ) 
      return max((tmp + nb),1);
   else if ( mydist == extrablks )
      return max((tmp + n%nb ),1);
   else
      return max(tmp,1);
}
