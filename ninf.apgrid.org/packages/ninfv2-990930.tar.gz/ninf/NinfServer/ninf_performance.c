/*
 *   LINPACK test program (Fortran)
 *
 *   % linpackf-local  <matrix size> <log file name>
 *   % linpackf-remote <matrix size> <log file name>
 *   % linpackf-ninf   <matrix size> <log file name>
 *
 *   $Id: ninf_performance.c,v 1.7 1999/02/27 10:18:31 tatebe Exp $
 */


/*#define   __TIMEF__*/
/*#define   FILE_OUT*/
#ifndef TIMES
#define   TIMES   10
#endif

#ifdef   FILE_OUT
#define   FILE_NAME   "%s.log"
#endif


#include <stdio.h>
#include <math.h>
#include <time.h>
#include <sys/time.h>
#include <stdlib.h>

#include "ninf_error.h"


#ifndef test
#define DP
#ifdef __j90__
#define ROLL
#else
#define UNROLL
#endif
#endif


#ifdef SP
#define REAL float
#define ZERO 0.0
#define ONE 1.0
#define PREC "Single "
#endif

#ifdef DP
#define REAL double
#define ZERO 0.0e0
#define ONE 1.0e0
#define PREC "Double "
#endif

#ifdef ROLL
#define ROLLING "Rolled "
#endif
#ifdef UNROLL
#define ROLLING "Unrolled "
#endif


#ifdef   __TIMEF__
double timef();
#endif
void   manage();
double laptime();
double ops;
int comment = 0;

int measure_performance();

#ifdef test

#define ninf_debug printf
main(argc, argv)
int  argc;
char *argv[];
{
  int n, times;
      if(argc < 3){
	printf("%s <matrix size> <times>\n", argv[0]);
	exit(0);
      }

    n = atoi(argv[1]);
    times = atoi(argv[2]);
    
    printf("%d\n", measure_performance(n,times));
}
#endif 

double mytime[TIMES][4];   /* 0 : dgefa
			      1 : dgesl
			      2 : total
			      3 : FLOPS */

int measure_performance(n, times) 
int n;
int times;
{
    double *a, *b;
    int    lda,info;  
    int    *ipiv;
    double norma;
    long   t;
    char   *ctime;
    struct timeval st, fn, md;
      double res[3];   /* 0 : max of FLOPS
			1 : average
			2 : standard */
      double time0;    /* empty time */
      int    i,j;
      
    lda = n;
    ops = (2.0e0*((double)n*n*n))/3.0 + 2.0*((double)n*n);

    ninf_debug("operation counts %.2lf\n", ops);

    time(&t);
    ctime = asctime(localtime(&t));


    ninf_debug("Local Execution..\n");

    ninf_debug("Matrix size: %d by %d\n",n,n);
    ninf_debug("             %s , %s\n", ROLLING, PREC);


    a = (double*) malloc(sizeof(double) * lda * n);
    b = (double*) malloc(sizeof(double) * lda );
    ipiv = (int*) malloc(sizeof(int) * lda );	

    gettimeofday(&st, 0);
    gettimeofday(&fn, 0);
    time0 = laptime(st, fn);

    /* start linpack calculation */
    for (i = 0 ; i < times ; i++){
      matgen(a, lda, n, b, &norma);

      gettimeofday( &st, 0 );
      linpack(a, lda, n, ipiv, b, &info); 
      gettimeofday( &fn, 0 );
      mytime[i][2] = laptime( st, fn ) - time0;
    }

    free(a);
    free(b);
    free(ipiv);

    manage(mytime, res, times);

    ninf_debug("      total       kflops\n");
    for(i = 0 ; i < times ; i++)
      ninf_debug("%11.2f%11.0f\n",
	      (double)mytime[i][2],
	      (double)mytime[i][3]);
    ninf_debug("MAX performance : %11.0f\n", res[0]);
    ninf_debug("average         : %11.2f\n", res[1]);
    ninf_debug("standard        : %11.2f\n\n", res[2]);

    return (long)res[1];
}
     

/*
 *  functions
 */
void manage(mytime, res, times)
int times;
double mytime[][4];   /* INOUT */
double res[3];             /* OUT */
{
  double sum = 0.0;
  int    i, j;

  res[0] = 0.0;
  for(i = 0 ; i < times ; i++){
    mytime[i][3] = ops / (1.0e3 * mytime[i][2]);
    sum += mytime[i][3];
    if(res[0] < mytime[i][3])
      res[0] = mytime[i][3];   /* max */
  }
  res[1] = sum / times;   /* average */
  sum = 0.0;
  for(i = 0 ; i < times ; i++)
    sum += (mytime[i][3] - res[1]) * (mytime[i][3] - res[1]);
  res[2] = sqrt(sum / times);   /* standard */
}


double laptime( st, fn )
struct timeval st;
struct timeval fn;
{
    return fn.tv_sec - st.tv_sec + (fn.tv_usec - st.tv_usec) * 1.0e-06;
}


matgen(a,lda,n,b,norma)
double a[],b[],*norma;
int lda, n;
{
	int init, i, j;

	init = 1325;
	*norma = 0.0;
	for (j = 0; j < n; j++) {
		for (i = 0; i < n; i++) {
			init = 3125*init % 65536;
			a[lda*j+i] = (init - 32768.0)/16384.0;
			*norma = (a[lda*j+i] > *norma) ? a[lda*j+i] : *norma;
		}
	}
	for (i = 0; i < n; i++) {
          b[i] = 0.0;
	}
	for (j = 0; j < n; j++) {
		for (i = 0; i < n; i++) {
			b[i] = b[i] + a[lda*j+i];
		}
	}
}

#ifdef USE_LIBSCI
linpack(a,lda,n,ipvt,b,info)
      int lda,n,ipvt[],*info;
      double a[],b[];
{
      char tmp[] = "n";
      int tmpint = 1;
      SGETRF(&n,&n,a,&lda,ipvt,b,info,info);
      SGETRS(tmp,&n,&tmpint,a,&lda,ipvt,b,&n,info, 1L);
}
#elif defined(USE_MURATA)
linpack(a,lda,n,ipvt,b,info)
      int lda,n,ipvt[],*info;
      double a[],b[];
{
  MURATA_LINPACK_STRING(a,&lda,&n,b,ipvt,info);
}
#else
linpack(a,lda,n,ipvt,b,info)
      int lda,n,ipvt[],*info;
      double a[],b[];
{
  dgefa(a, lda, n, ipvt, info);
  dgesl(a, lda, n, ipvt, b, info);

}


#include <sys/time.h>
#include <sys/resource.h>

/*
Caveat receptor.  (Jack) dongarra@mcs.anl.gov, (Eric Grosse) research!ehg
Careful! Anything free comes with no guarantee.
*** from netlib, Tue May 30 10:30:29 CDT 1989 ***
*/

/*

Translated to C by Bonnie Toy 5/88

To compile single precision version for Sun-4:

	cc -DSP -O4 -fsingle -fsingle2 clinpack.c -lm

To compile double precision version for Sun-4:

	cc -DDP -O4 clinpack.c -lm

To obtain rolled source BLAS, add -DROLL to the command lines.
To obtain unrolled source BLAS, add -DUNROLL to the command lines.

You must specify one of -DSP or -DDP to compile correctly.

You must specify one of -DROLL or -DUNROLL to compile correctly.

*/

#include <stdio.h>
#include <math.h>


dgefa(a,lda,n,ipvt,info)
REAL a[];
int lda,n,ipvt[],*info;

/* We would like to declare a[][lda], but c does not allow it.  In this
function, references to a[i][j] are written a[lda*i+j].  */
/*
     dgefa factors a double precision matrix by gaussian elimination.

     dgefa is usually called by dgeco, but it can be called
     directly with a saving in time if  rcond  is not needed.
     (time for dgeco) = (1 + 9/n)*(time for dgefa) .

     on entry

        a       REAL precision[n][lda]
                the matrix to be factored.

        lda     integer
                the leading dimension of the array  a .

        n       integer
                the order of the matrix  a .

     on return

        a       an upper triangular matrix and the multipliers
                which were used to obtain it.
                the factorization can be written  a = l*u  where
                l  is a product of permutation and unit lower
                triangular matrices and  u  is upper triangular.

        ipvt    integer[n]
                an integer vector of pivot indices.

        info    integer
                = 0  normal value.
                = k  if  u[k][k] .eq. 0.0 .  this is not an error
                     condition for this subroutine, but it does
                     indicate that dgesl or dgedi will divide by zero
                     if called.  use  rcond  in dgeco for a reliable
                     indication of singularity.

     linpack. this version dated 08/14/78 .
     cleve moler, university of new mexico, argonne national lab.

     functions

     blas daxpy,dscal,idamax
*/

{
/*     internal variables	*/

REAL t;
int idamax(),j,k,kp1,l,nm1;


/*     gaussian elimination with partial pivoting	*/

	*info = 0;
	nm1 = n - 1;
	if (nm1 >=  0) {
		for (k = 0; k < nm1; k++) {
			kp1 = k + 1;

          		/* find l = pivot index	*/

			l = idamax(n-k,&a[lda*k+k],1) + k;
			ipvt[k] = l;

			/* zero pivot implies this column already 
			   triangularized */

			if (a[lda*k+l] != ZERO) {

				/* interchange if necessary */

				if (l != k) {
					t = a[lda*k+l];
					a[lda*k+l] = a[lda*k+k];
					a[lda*k+k] = t; 
				}

				/* compute multipliers */

				t = -ONE/a[lda*k+k];
				dscal(n-(k+1),t,&a[lda*k+k+1],1);

				/* row elimination with column indexing */

				for (j = kp1; j < n; j++) {
					t = a[lda*j+l];
					if (l != k) {
						a[lda*j+l] = a[lda*j+k];
						a[lda*j+k] = t;
					}
					daxpy(n-(k+1),t,&a[lda*k+k+1],1,
					      &a[lda*j+k+1],1);
  				} 
  			}
			else { 
            			*info = k;
			}
		} 
	}
	ipvt[n-1] = n-1;
	if (a[lda*(n-1)+(n-1)] == ZERO) *info = n-1;
}

/*----------------------*/ 


dgesl(a,lda,n,ipvt,b,job)
int lda,n,ipvt[],job;
REAL a[],b[];

/* We would like to declare a[][lda], but c does not allow it.  In this
function, references to a[i][j] are written a[lda*i+j].  */

/*
     dgesl solves the double precision system
     a * x = b  or  trans(a) * x = b
     using the factors computed by dgeco or dgefa.

     on entry

        a       double precision[n][lda]
                the output from dgeco or dgefa.

        lda     integer
                the leading dimension of the array  a .

        n       integer
                the order of the matrix  a .

        ipvt    integer[n]
                the pivot vector from dgeco or dgefa.

        b       double precision[n]
                the right hand side vector.

        job     integer
                = 0         to solve  a*x = b ,
                = nonzero   to solve  trans(a)*x = b  where
                            trans(a)  is the transpose.

    on return

        b       the solution vector  x .

     error condition

        a division by zero will occur if the input factor contains a
        zero on the diagonal.  technically this indicates singularity
        but it is often caused by improper arguments or improper
        setting of lda .  it will not occur if the subroutines are
        called correctly and if dgeco has set rcond .gt. 0.0
        or dgefa has set info .eq. 0 .

     to compute  inverse(a) * c  where  c  is a matrix
     with  p  columns
           dgeco(a,lda,n,ipvt,rcond,z)
           if (!rcond is too small){
           	for (j=0,j<p,j++)
              		dgesl(a,lda,n,ipvt,c[j][0],0);
	   }

     linpack. this version dated 08/14/78 .
     cleve moler, university of new mexico, argonne national lab.

     functions

     blas daxpy,ddot
*/
{
/*     internal variables	*/

	REAL ddot(),t;
	int k,kb,l,nm1;

	nm1 = n - 1;
	if (job == 0) {

		/* job = 0 , solve  a * x = b
		   first solve  l*y = b    	*/

		if (nm1 >= 1) {
			for (k = 0; k < nm1; k++) {
				l = ipvt[k];
				t = b[l];
				if (l != k){ 
					b[l] = b[k];
					b[k] = t;
				}	
				daxpy(n-(k+1),t,&a[lda*k+k+1],1,&b[k+1],1);
			}
		} 

		/* now solve  u*x = y */

		for (kb = 0; kb < n; kb++) {
		    k = n - (kb + 1);
		    b[k] = b[k]/a[lda*k+k];
		    t = -b[k];
		    daxpy(k,t,&a[lda*k+0],1,&b[0],1);
		}
	}
	else { 

		/* job = nonzero, solve  trans(a) * x = b
		   first solve  trans(u)*y = b 			*/

		for (k = 0; k < n; k++) {
			t = ddot(k,&a[lda*k+0],1,&b[0],1);
			b[k] = (b[k] - t)/a[lda*k+k];
		}

		/* now solve trans(l)*x = y	*/

		if (nm1 >= 1) {
			for (kb = 1; kb < nm1; kb++) {
				k = n - (kb+1);
				b[k] = b[k] + ddot(n-(k+1),&a[lda*k+k+1],1,&b[k+1],1);
				l = ipvt[k];
				if (l != k) {
					t = b[l];
					b[l] = b[k];
					b[k] = t;
				}
			}
		}
	}
}

/*----------------------*/ 

daxpy(n,da,dx,incx,dy,incy)
/*
     constant times a vector plus a vector.
     jack dongarra, linpack, 3/11/78.
*/
REAL dx[],dy[],da;
int incx,incy,n;
{
	int i,ix,iy,m,mp1;

	if(n <= 0) return;
	if (da == ZERO) return;

	if(incx != 1 || incy != 1) {

		/* code for unequal increments or equal increments
		   not equal to 1 					*/

		ix = 1;
		iy = 1;
		if(incx < 0) ix = (-n+1)*incx + 1;
		if(incy < 0)iy = (-n+1)*incy + 1;
		for (i = 0;i < n; i++) {
			dy[iy] = dy[iy] + da*dx[ix];
			ix = ix + incx;
			iy = iy + incy;
		}
      		return;
	}

	/* code for both increments equal to 1 */

#ifdef ROLL
	for (i = 0;i < n; i++) {
		dy[i] = dy[i] + da*dx[i];
	}
#endif
#ifdef UNROLL

	m = n % 4;
	if ( m != 0) {
		for (i = 0; i < m; i++) 
			dy[i] = dy[i] + da*dx[i];
		if (n < 4) return;
	}
	for (i = m; i < n; i = i + 4) {
		dy[i] = dy[i] + da*dx[i];
		dy[i+1] = dy[i+1] + da*dx[i+1];
		dy[i+2] = dy[i+2] + da*dx[i+2];
		dy[i+3] = dy[i+3] + da*dx[i+3];
	}
#endif
}
   
/*----------------------*/ 

REAL ddot(n,dx,incx,dy,incy)
/*
     forms the dot product of two vectors.
     jack dongarra, linpack, 3/11/78.
*/
REAL dx[],dy[];

int incx,incy,n;
{
	REAL dtemp;
	int i,ix,iy,m,mp1;

	dtemp = ZERO;

	if(n <= 0) return(ZERO);

	if(incx != 1 || incy != 1) {

		/* code for unequal increments or equal increments
		   not equal to 1					*/

		ix = 0;
		iy = 0;
		if (incx < 0) ix = (-n+1)*incx;
		if (incy < 0) iy = (-n+1)*incy;
		for (i = 0;i < n; i++) {
			dtemp = dtemp + dx[ix]*dy[iy];
			ix = ix + incx;
			iy = iy + incy;
		}
		return(dtemp);
	}

	/* code for both increments equal to 1 */

#ifdef ROLL
	for (i=0;i < n; i++)
		dtemp = dtemp + dx[i]*dy[i];
	return(dtemp);
#endif
#ifdef UNROLL

	m = n % 5;
	if (m != 0) {
		for (i = 0; i < m; i++)
			dtemp = dtemp + dx[i]*dy[i];
		if (n < 5) return(dtemp);
	}
	for (i = m; i < n; i = i + 5) {
		dtemp = dtemp + dx[i]*dy[i] +
		dx[i+1]*dy[i+1] + dx[i+2]*dy[i+2] +
		dx[i+3]*dy[i+3] + dx[i+4]*dy[i+4];
	}
	return(dtemp);
#endif
}

/*----------------------*/ 
dscal(n,da,dx,incx)

/*     scales a vector by a constant.
      jack dongarra, linpack, 3/11/78.
*/
REAL da,dx[];
int n, incx;
{
	int i,m,mp1,nincx;

	if(n <= 0)return;
	if(incx != 1) {

		/* code for increment not equal to 1 */

		nincx = n*incx;
		for (i = 0; i < nincx; i = i + incx)
			dx[i] = da*dx[i];
		return;
	}

	/* code for increment equal to 1 */

#ifdef ROLL
	for (i = 0; i < n; i++)
		dx[i] = da*dx[i];
#endif
#ifdef UNROLL

	m = n % 5;
	if (m != 0) {
		for (i = 0; i < m; i++)
			dx[i] = da*dx[i];
		if (n < 5) return;
	}
	for (i = m; i < n; i = i + 5){
		dx[i] = da*dx[i];
		dx[i+1] = da*dx[i+1];
		dx[i+2] = da*dx[i+2];
		dx[i+3] = da*dx[i+3];
		dx[i+4] = da*dx[i+4];
	}
#endif

}

/*----------------------*/ 
int idamax(n,dx,incx)

/*
     finds the index of element having max. absolute value.
     jack dongarra, linpack, 3/11/78.
*/

REAL dx[];
int incx,n;
{
	REAL dmax;
	int i, ix, itemp;

	if( n < 1 ) return(-1);
	if(n ==1 ) return(0);
	if(incx != 1) {

		/* code for increment not equal to 1 */

		ix = 1;
		dmax = fabs((double)dx[0]);
		ix = ix + incx;
		for (i = 1; i < n; i++) {
			if(fabs((double)dx[ix]) > dmax)  {
				itemp = i;
				dmax = fabs((double)dx[ix]);
			}
			ix = ix + incx;
		}
	}
	else {

		/* code for increment equal to 1 */

		itemp = 0;
		dmax = fabs((double)dx[0]);
		for (i = 1; i < n; i++) {
			if(fabs((double)dx[i]) > dmax) {
				itemp = i;
				dmax = fabs((double)dx[i]);
			}
		}
	}
	return (itemp);
}


#endif
