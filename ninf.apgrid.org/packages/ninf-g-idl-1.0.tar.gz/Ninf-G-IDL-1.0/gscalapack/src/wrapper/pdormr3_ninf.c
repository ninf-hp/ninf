#define _WRAPPER_
/* $Id: pdormr3_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define DOUBLE
#include <gscalapack.h>

#define ROW_a lda
#define COL_a col_a
#define ROW_c ldc
#define COL_c n
static	int worklen(side, m, n) {
	  int ret=1;
	  int LCMP, IROFFC, ICOFFC, ICROW, ICCOL;
	  int MpC0, NqC0;
	  ret = 2*max(m,n);
	  if NEED_BUFF {
	    LCMP = LCM(NPROW, NPCOL) / NPROW ;

	    IROFFC = MOD( IC-1, MB_C );
	    ICOFFC = MOD( JC-1, NB_C );
	    ICROW = INDXG2P( IC, MB_C, MYROW, RSRC_C, NPROW );
	    ICCOL = INDXG2P( JC, NB_C, MYCOL, CSRC_C, NPCOL );
	    MpC0 = NUMROC( M+IROFFC, MB_C, MYROW, ICROW, NPROW );
	    NqC0 = NUMROC( N+ICOFFC, NB_C, MYCOL, ICCOL, NPCOL );
	    
	    if (chrcmp(side, 'L')==0)
	      ret = MpC0 + MAX( MAX( 1, NqC0 ), NUMROC( NUMROC( M+IROFFC,MB_A,0,0,NPROW ),MB_A,0,0,LCMP ) );
	    else
	      ret = NqC0 + MAX( 1, MpC0 );
	  }
	  return ret;
}


void  pdormr3_ninf(	 char side,
		 char trans,
		 int m,
		 int n,
		 int k,
		 int l,
		 double global_a[],
		 int lda,
		 double global_tau[],
		 double global_c[],
		 int ldc,
		 double work[],
		 int lwork,
		 int *info
)
/* "pdormr3 overwrites the general real M-by-N distributed matrix C with\\n\\n                       SIDE = 'L'          SIDE = 'R'\\n  TRANS = 'N':      Q * C           C  * Q\\n  TRANS = 'T':      Q**T * C       C  * Q**T\\n\\n  where Q is a real orthogonal distributed matrix defined as the product of K elementary reflectors\\n\\n        Q = H(1) H(2) ." */
/* OPTIONS */
{
	int maxldd;

	int col_a;
	int maxlda;
	double *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
	int row_loca, col_loca;

	double *loctau=NULL;

	int maxldc;
	double *locc=NULL;
	int descc[DESCLEN];
	int desc_gc[DESCLEN];
	int row_locc, col_locc;

	double *locwork=NULL;
	int llocwork;

	INITIALIZE();

	SCALAR( "char", side);
	SCALAR( "char", trans);
	SCALAR( "int", m);
	SCALAR( "int", n);
	SCALAR( "int", k);
	SCALAR( "int", l);
	SCALAR( "int", lda);
	SCALAR( "int", ldc);
	SCALAR( "int", lwork);

	if (chrcmp(side,'L')==0) col_a = m;
	else col_a = n;

	ROW( a);
	COL( a);
	ROW( c);
	COL( c);
	MAXLDD( maxldd, c );
	maxlda = maxldd;
	maxldc = maxldd;

	MATRIX( "double", a, ROW_a, COL_a);
	MATRIX( "double", c, ROW_c, COL_c);
	VECTOR( "c","double", tau, k);
	DISTRIBUTE( "double", a, ROW_a, COL_a);
	DISTRIBUTE( "double", c, ROW_c, COL_c);
	vDISTRIBUTE( "c","double", tau, k);

	llocwork = worklen(side, m, n);
	llocwork = max(lwork,llocwork);
	WORK(locwork,llocwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pdormr3)( &side, &trans,
                               &m, &n, &k, &l,
                               loca, &one, &one, desca,
                               loctau,
                               locc, &one, &one, descc,
                               locwork, &llocwork,
                               &linfo);

	GATHER( "double", c, ROW_c, COL_c);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
		*info = linfo;
	} else {
		
	}

	FREE_MATRIX(a);
	FREE_MATRIX(c);
	FREE_VECTOR(tau);
        FREE(locwork);
}

