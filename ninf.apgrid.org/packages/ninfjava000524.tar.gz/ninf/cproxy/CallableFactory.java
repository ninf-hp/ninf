package ninf.cproxy;
import ninf.basic.*;
import ninf.client.*;
import ninf.common.*;

public interface CallableFactory{
  public Callable generate(NinfStub stub, int index, ScheduleProvider master);
}
