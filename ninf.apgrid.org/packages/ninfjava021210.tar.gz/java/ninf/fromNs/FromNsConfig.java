package ninf.fromNs;
import ninf.basic.*;
import ninf.client.*;
import java.util.Vector;
import java.util.Hashtable;
import java.io.IOException;
import java.io.*;

public class FromNsConfig extends Configure{
  static final int DEFAULT_PORT = 2222;

  static CommandRepresent initAcceptedCommands[] = {
    new CommandRepresent("metaserver",    2), 
    new CommandRepresent("cproxy",        2), 
    new CommandRepresent("netsolveAgent", 1), 
    new CommandRepresent("myhostname",    1),
    new CommandRepresent("log",           1), 
    new CommandRepresent("port",          1),
    new CommandRepresent("lookup",        1),
  };
  static CommandRepresent initAcceptedOptions[] = {
    new CommandRepresent("-port",      1), 
    new CommandRepresent("-debug",     0),
    new CommandRepresent("-quiet",     0),
    new CommandRepresent("-version",   0)};

  MetaServerReference metaServer;
  NinfServerStruct    cproxy;
  String              netsolveAgent;

  FromNsConfig(String args[]) throws NinfException{
    super(args, initAcceptedCommands, initAcceptedOptions);
  }

  public void configure() throws NinfException{
    port = DEFAULT_PORT;
    super.configure();
    configureMetaServer();
    configureCproxy();
    configureNetsolveAgent();
  }

  void configureNetsolveAgent(){
    String tmp = getOneArg("netsolveAgent");
    if (tmp != null);
      netsolveAgent = tmp;
  }

  void configureCproxy() throws NinfException{
    String strs[] = getOneContent("cproxy");
    if (strs == null || strs.length == 0)
      throw new ConfigureException("cproxy must be defined in configuration file");
    cproxy = new NinfServerStruct(strs[0], (new Integer(strs[1]).intValue()));
  }

  void configureMetaServer() throws NinfException{
    String strs[] = getOneContent("metaserver");
    if (strs == null || strs.length == 0)
      throw new ConfigureException("metaserver must be defined in configuration file");
    metaServer = new MetaServerReference(strs[0], (new Integer(strs[1]).intValue()));
  }

}
