/*===========================================================================
Copyright (c) 2000
Information Promotion Agency of Japan (IPA),
Electrotechnical Laboratory, Agency of Industrial Science and Technology, and
NTT Software Corp.
2000 Network Enabled Server
Module : <����>
Filename : nslib_util.h
RCS :
    $Source: /usr/local/Ninf/cvsroot/ninf/include/nslib_utils.h,v $
    $Revision: 1.1 $
    $Author: nakada $
    $Date: 2001/08/21 07:22:53 $
    $Locker:  $
    $State: Exp $
Date : 1999.11 NTT SOFT
=============================================================================*/
/** 
  nslib_util.h : utils for generic use
  */
#ifndef __NSLIB_UTILS_H_
#define __NSLIB_UTILS_H_
#ifdef __cplusplus
extern "C" {
#endif
#include "ninf_macros.h"

typedef int boolean;

#define REALLOC(ptr, size) realloc(ptr,size)
#define MY_MALLOC(type) ((type *)malloc(sizeof(type)))
#define MY_FREE(ptr)    (free(ptr))


/*********************************
list: something like java.util.Vector 
  **********************************/
typedef struct nslib_boolean_func nslib_boolean_func_t;

typedef struct nslib_list {
    /** compare function: returns 0 if two items are equal */
    boolean (* compare)(void *, void *);
    /** contents */
    void ** contents;
    /** current used size in the list */
    int index;
    /** current size of the contents */
    int size;
    /** grow size for overflow */
    int grow;
} nslib_list_t;

#define NSLIB_LIST_DEFAULT_INITIAL 10
#define NSLIB_LIST_DEFAULT_GROW 10

nslib_list_t * nslib_list_new(boolean (* compare)(void *, void *));
nslib_list_t * nslib_list_new_init(boolean (* compare)(void *, void *),
   int initial, int grow);
void nslib_list_destruct (nslib_list_t *);

/* rewind the vector */
void    nslib_list_clear    (nslib_list_t *);

void *  nslib_list_at       (nslib_list_t *, int i);
void    nslib_list_at_put   (nslib_list_t *, int i, void * item);
boolean nslib_list_add      (nslib_list_t *, void *);
boolean nslib_list_add_first(nslib_list_t *, void *);
int     nslib_list_size     (nslib_list_t *);
void    nslib_list_foreach  (nslib_list_t *, void(* func)(void *));
void *  nslib_list_find     (nslib_list_t *, nslib_boolean_func_t *);
boolean nslib_list_remove   (nslib_list_t *, void *);
boolean nslib_list_includes (nslib_list_t *, void *);

/*********************************
  boolean: boolean func object
  *********************************/
struct nslib_boolean_func {
    void * user_data;
    boolean(* func)(void * user_data, void * target);
};
boolean nslib_boolean_func_call(nslib_boolean_func_t *, void *);

/*********************************
 pair:  for map.
  *********************************/
typedef struct nslib_pair {
    void * key;
    void * val;
} nslib_pair_t;

nslib_pair_t * nslib_pair_new(void * key, void * val);
void           nslib_pair_destruct(nslib_pair_t *);

/*********************************
 map: something like java.util.Map
  **********************************/
#define DEFAULT_ENTRYS 32
typedef struct nslib_map {
    boolean (* compare)(void *, void *);
    int (* hash)(void *);
    nslib_list_t ** lists;
    int entry_size;
} nslib_map_t;

nslib_map_t * nslib_map_new(boolean (* compare)(void *, void *),
			    int     (* hash)(void *));
nslib_map_t * nslib_map_new_default();
nslib_map_t * nslib_map_new_init(boolean (* compare)(void *, void *),
				 int     (* hash)(void *),
				 int entry_size, int size, int grow);
void   nslib_map_destruct(nslib_map_t *);
void   nslib_map_clear   (nslib_map_t *);
void   nslib_map_put     (nslib_map_t *, void *, void *);
void * nslib_map_get     (nslib_map_t *, void *);
void * nslib_map_remove  (nslib_map_t *, void *);
nslib_list_t * 
       nslib_map_keys    (nslib_map_t *);
int    nslib_map_size    (nslib_map_t *);

void * nslib_my_malloc(int);
#ifdef __cplusplus
}
#endif


#endif
