package jp.go.aist.gtrc.test3.impl;

import jp.go.aist.gtrc.util.OperationAN;
import jp.go.aist.gtrc.util.PropertyAN;
import jp.go.aist.gtrc.util.ResourceAN;

import org.ggf.schemas.jsdl._2005._11.jsdl.JobDefinition_Type;

@ResourceAN("http://gtrc.aist.go.jp/test3")
public class Sample3Resource {
	@OperationAN
	public JobDefinition_Type foo(JobDefinition_Type jobDefinition) {
		return jobDefinition;
	}
}
