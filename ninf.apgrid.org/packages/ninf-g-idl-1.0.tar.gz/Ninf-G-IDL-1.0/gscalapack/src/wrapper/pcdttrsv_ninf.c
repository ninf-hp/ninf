#define _WRAPPER_
/* $Id: pcdttrsv_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define _DISTRIBUTE_1D_
#define SCOMPLEX
#include <gscalapack.h>

#define ROW_b ldb
#define COL_b nrhs
#define ROW_af laf
#define COL_af n
static	int worklen(int nrhs) {
	  int ret=1;
	  ret = 10+4*nrhs;
	  if NEED_BUFF {
	    ret = 10*npcol+4*nrhs;
	  }
	  return ret;
	}

void  pcdttrsv_ninf(	 char uplo,
		 char trans,
		 int n,
		 int nrhs,
		 scomplex global_dl[],
		 scomplex global_d[],
		 scomplex global_du[],
		 scomplex global_b[],
			 int ldb,
			 scomplex af[],
		 int dummy_laf,
		 scomplex  work[],
		 int lwork,
		 int *info
)
/* "pcdttrsv solves a tridiagonal triangular system of linear equations A * X = B or A^T * X = B where A is a tridiagonal triangular matrix factor produced by the Gaussian elimination code PC@(dom_pre)TTRF and is stored in A and AF." */
/* OPTIONS */
{
    extern void FortranCall(pcdttrsv)( char*, char*, int*, int*,
                                scomplex*, scomplex*, scomplex*, int*, int*,
                                scomplex*, int*, int*,
                                scomplex*, int*,
                                scomplex*, int*, int*);

	int maxldd;
	float *locdl=NULL, *locd=NULL, *locdu=NULL;
	int desctdd[DESCLEN];
	int desc_gtdd[DESCLEN];

	scomplex *locb=NULL;
	int descb[DESCLEN];
	int desc_gb[DESCLEN];
	int row_locb, col_locb;
	int maxldb;

	scomplex *locaf=NULL, *global_af=NULL;
	int descaf[DESCLEN];
	int desc_gaf[DESCLEN];
	int row_locaf, col_locaf;
	int laf, llocaf;
	int maxldaf;

	scomplex *locwork=NULL;
	int llocwork;

	INITIALIZE();

	SCALAR( "char", uplo);
	SCALAR( "char", trans);
	SCALAR( "int", n);
	SCALAR( "int", nrhs);
	SCALAR("int", dummy_laf);
	SCALAR( "int", lwork);

	SIZE(n);

	laf = 2*(blocsize+2)*nprocs/n;
	llocaf = laf*blocsize;
	if (mypnum==0) {
	  global_af=MALLOC(sizeof(float)*laf*n);
          assert(global_af);
	}

	ROW(b);
	COL(b);
	ROW(af);
	COL(af);
	MAXLDD( maxldd, b);
	maxldb=maxldd;
	maxldaf=maxldd;

	tdMATRIX("scomplex", dl, d, du, n);
	MATRIX( "scomplex", b, ROW_b, COL_b);
	MATRIX( "scomplex", af, ROW_af, COL_af);
	tdDISTRIBUTE( "scomplex", dl, d, du, n);
	DISTRIBUTE("scomplex", b, ROW_b, COL_b);

	llocwork=worklen(nrhs);
        llocwork=max(lwork,llocwork);
	WORK(locwork,llocwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pcdttrsv)( &uplo, &trans, &n, &nrhs,
                                locdl, locd, locdu, &one, desctdd,
                                locb, &one, descb,
                                locaf, &llocaf,
                                locwork, &llocwork, &linfo);

	tdGATHER( "scomplex", dl, d, du, n);
	GATHER( "scomplex", b, ROW_b, COL_b);
	GATHER( "scomplex", af, ROW_af, COL_af);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
	  int i;
	  *info = linfo;
	  for(i=0;i<min(dummy_laf,laf*n);i++) af[i] = global_af[i];
          FREE(global_af);
	} else {
	}
        
	FREE_MATRIX(dl);
	FREE_MATRIX(d);
	FREE_MATRIX(du);
	FREE_MATRIX( b);
	FREE_MATRIX(af);

        FREE(locwork);
}

