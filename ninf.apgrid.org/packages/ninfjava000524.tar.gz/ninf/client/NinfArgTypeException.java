package ninf.client;
import ninf.basic.NinfException;

public
class NinfArgTypeException extends NinfException {
  int argNum;
  String acturalType;
  String requiredType;

  public NinfArgTypeException(int argNum, 
				String acturalType,  String requiredType){
    super();
    this.argNum = argNum;
    this.acturalType = acturalType;
    this.requiredType = requiredType;
  }
  public String toString(){
    return "Arg no." + argNum + " mismatch. \""+ acturalType +"\" supplied, while \"" + requiredType +"\" is required.";
  }
}
