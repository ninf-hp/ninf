#define _WRAPPER_
/* $Id: pcggqrf_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define SCOMPLEX
#include <gscalapack.h>

#define ROW_a lda
#define COL_a m

#define ROW_b ldb 
#define COL_b p
static	int worklen(int m, int n, int p) {
	  int ret=1;
	  int IROFFA, ICOFFA, IAROW, IACOL, NpA0, MqA0, IROFFB, ICOFFB;
	  int IBROW, IBCOL, NpB0, PqB0;
#define IA 1
#define JA 1
#define MB_A rbloc
#define NB_A cbloc
#define MYROW myprow
#define MYCOL mypcol
#define NPROW nprow
#define NPCOL npcol
#define RSRC_A 0
#define CSRC_A 0
#define IB 1
#define JB 1
#define MB_B rbloc
#define NB_B cbloc
	  ret =  MAX( n * ( n + m + n ),
		      max(MAX( (n*n)/2, (p + n)*n ) +
			  n * n,
			  m * ( n + p + m )) );
	  if NEED_BUFF {
	    IROFFA = MOD( IA-1, MB_A );
	    ICOFFA = MOD( JA-1, NB_A );
	    IAROW  = INDXG2P( IA, MB_A, MYROW, RSRC_A, NPROW );
	    IACOL  = INDXG2P( JA, NB_A, MYCOL, CSRC_A, NPCOL );
	    NpA0   = NUMROC( N+IROFFA, MB_A, MYROW, IAROW, NPROW );
	    MqA0   = NUMROC( M+ICOFFA, NB_A, MYCOL, IACOL, NPCOL );
	    IROFFB = MOD( IB-1, MB_B );
	    ICOFFB = MOD( JB-1, NB_B );
	    IBROW  = INDXG2P( IB, MB_B, MYROW, RSRC_B, NPROW );
	    IBCOL  = INDXG2P( JB, NB_B, MYCOL, CSRC_B, NPCOL );
	    NpB0   = NUMROC( N+IROFFB, MB_B, MYROW, IBROW, NPROW );
	    PqB0   = NUMROC( p+ICOFFB, NB_B, MYCOL, IBCOL, NPCOL );
	    ret =  MAX( NB_A * ( NpA0 + MqA0 + NB_A ),
			max(MAX( (NB_A*(NB_A-1))/2, (PqB0 + NpB0)*NB_A ) +
			NB_A * NB_A,
			MB_B * ( NpB0 + PqB0 + MB_B )) );
	  }
	    return ret;
}


void  pcggqrf_ninf(	 int n,
		 int m,
		 int p,
		 scomplex global_a[],
		 int lda,
		 scomplex global_taua[],
		 int ldtaua,
		 scomplex global_b[],
		 int ldb,
		 scomplex global_taub[],
		 int ldtaub,
		 scomplex work[],
		 int lwork,
		 int *info
)
/* "pcggqrf computes a generalized QR factorization of an N-by-M matrix A and an N-by-P matrix B:\\n              A = Q*R,         B = Q*T*Z,\\n where Q is an N-by-N unitary matrix, Z is a P-by-P unitary matrix, and R and T assume one of the forms:\\n if N >= M,  R = ( R11 ) M  ,   or if N < M,  R = ( R11  R12 ) N, \\n                 (  0  ) N-M                         N   M-N \\n                    M \\n" */
/* OPTIONS */
{
    extern void FortranCall(pcggqrf)( int*, int*, int*,
				      scomplex*, int*, int*, int*,
				      scomplex*,
				      scomplex*, int*, int*, int*,
				      scomplex*,
				      scomplex*, int*,
				      int*);

	int maxldd;

	int maxlda;
	scomplex *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
	int row_loca, col_loca;

	int maxldb;
	scomplex *locb=NULL;
	int descb[DESCLEN];
	int desc_gb[DESCLEN];
	int row_locb, col_locb;

	scomplex *loctaua=NULL;
	scomplex *loctaub=NULL;

	scomplex *locwork=NULL;
	int llocwork;

	INITIALIZE();

	SCALAR( "int", n);
	SCALAR( "int", m);
	SCALAR( "int", p);
	SCALAR( "int", lda);
	SCALAR( "int", ldb);
	SCALAR( "int", lwork);

	ROW( a);
	COL( a);
	ROW( b);
	COL( b);
	MAXLDD( maxldd, a );
	maxlda = maxldd;
	maxldb = maxldd;

	MATRIX( "scomplex", a, ROW_a, COL_a);
	MATRIX( "scomplex", b, ROW_b, COL_b);
	DISTRIBUTE( "scomplex", a, ROW_a  , COL_a);
	DISTRIBUTE( "scomplex", b, ROW_b  , COL_b);
	VECTOR( "c", "scomplex",taua, min(n,m));
	VECTOR("r", "scomplex",taub,min(n,p));

        llocwork=worklen(m,n,p);
	llocwork=max(lwork,llocwork);
	WORK(locwork,llocwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pcggqrf)( &n, &m, &p,
                               loca, &one, &one, desca,
                               loctaua,
                               locb, &one, &one, descb,
                               loctaub,
                               locwork, &llocwork,
                               &linfo);

	GATHER( "float", a, ROW_a, COL_a);
	GATHER( "float", b, ROW_b, COL_b);
	vGATHER( "c", "float", taua, min(n,m));
	vGATHER( "r", "float", taub, min(n,p));
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
		*info = linfo;
	} else {
	}

	FREE_MATRIX(a);
	FREE_VECTOR(taua);
	FREE_MATRIX(b);
	FREE_VECTOR(taub);
        FREE(locwork);
}

