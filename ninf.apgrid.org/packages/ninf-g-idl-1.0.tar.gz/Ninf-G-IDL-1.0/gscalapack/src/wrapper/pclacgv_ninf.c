#define _WRAPPER_
/* $Id: pclacgv_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define SCOMPLEX
#include <gscalapack.h>

void  pclacgv_ninf(	 int n,
#ifdef HAVE_ABS                
		 scomplex global_x[],
#else
                 scomplex global_x[],
#endif
		 int incx
)

{
    int maxldd;

	int maxldx;
	scomplex *locx=NULL;
	int descx[DESCLEN];
	int desc_gx[DESCLEN];
	int row_locx, col_locx;
	int ROW_x, COL_x;

	INITIALIZE();

	SCALAR("int",n);
	SCALAR("int",incx);
	square(1+(n-1)*abs(incx), &ROW_x, &COL_x);
	
	ROW(x );
	COL(x );
	MAXLDD(maxldd,x );
	maxldx=maxldd;

	MATRIX("scomplex",x, ROW_x ,COL_x );
	DISTRIBUTE("scomplex", x, ROW_x ,COL_x  );

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pclacgv)( &n, locx, &one, &one, descx, &incx);

	GATHER("scomplex", x, ROW_x ,COL_x);

	if( mypnum == 0 ){
	} else {
	}

	FREE_MATRIX(x);
	
}

