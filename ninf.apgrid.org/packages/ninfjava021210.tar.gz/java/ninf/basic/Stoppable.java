package ninf.basic;

public interface Stoppable{
  public void stop();
}
