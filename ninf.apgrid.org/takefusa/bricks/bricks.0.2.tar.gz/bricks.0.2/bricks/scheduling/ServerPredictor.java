package bricks.scheduling;
import bricks.util.*;
import bricks.environment.*;

public abstract class ServerPredictor {

    MetaPredictor owner;
    ResourceDB resourceDB;
    
    protected void init(MetaPredictor owner) {
	this.owner = owner;
	this.resourceDB = owner.resourceDB;
	owner.put(this);
    }

    public void addServerLoad(
        double currentTime, Host host, RequestedData data
    ) {;}

    public void addServerLoad(double currentTime, EPTask task) {;}

    public ServerPrediction getServerPrediction(
	double currentTime, Host host, HostInfo hostInfo
    ) {
	return null;
    }
}
