#define _WRAPPER_
/* $Id: pdgetri_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define DOUBLE
#include <gscalapack.h>

#define ROW_a  lda
#define COL_a  n

static	int worklen(int n) {
	  int ret=1;
	  ret = n*n;
#define IA 1
#define MB_A rbloc
#define NB_A cbloc
	  if NEED_BUFF {
	    ret =  LOCr(N+MOD(IA-1,MB_A))*NB_A;
	  }
	  return ret;
}

static	int iworklen(int n, int lda) {
	  int ret=1;
	  ret = 2*n;
	  if NEED_BUFF {
#define N_A n
#define JA 1
#define LCM lcm(nprow,npcol)	    
#define M_A ROW_a
	    if ( NPROW == NPCOL) {
	      ret = LOCc( N_A + MOD(JA-1, NB_A) ) + NB_A;
	    }  else {
	      ret =  LOCc( N_A + MOD(JA-1, NB_A) ) +
		MAX( CEIL(CEIL(LOCr(M_A),MB_A),(LCM/NPROW)),	 NB_A );
	    }
	  }
	  return ret;
}

void  pdgetri_ninf(	 int n,
		 double global_a[],
		 int lda,
		 int global_ipiv[],
		 double work[],
		 int lwork,
		 int *info
)
/* "pdgetri computes the inverse of a distributed matrix using the LU factorization computed by PSGETRF." */
/* OPTIONS */
{
    extern void FortranCall(pdgetri)( int*,
                               double*, int*, int*, int*,
                               int*,
                               double*, int*,
                               int*, int*,
                               int*);

	int maxldd;

	int maxlda;
	double *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
	int row_loca, col_loca;

	int *locipiv=NULL;

	double *locwork=NULL;
	int llocwork;
	int *lociwork=NULL;
	int llociwork;
	INITIALIZE();

	SCALAR( "int", n);
	SCALAR( "int", lda);
	SCALAR( "int", lwork);

	ROW( a);
	COL( a);
	MAXLDD( maxldd, a );
	maxlda = maxldd;

	MATRIX( "double", a, ROW_a, COL_a);
	DISTRIBUTE( "double", a, ROW_a  , COL_a);

	VECTOR( "r", "int", ipiv, ROW_a);
	vDISTRIBUTE( "r", "int", ipiv, ROW_a);

        llocwork = worklen(n);
	llocwork = max(lwork,llocwork);
	WORK(locwork,llocwork);
	llociwork = iworklen(n, lda);
	WORK(lociwork,llociwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pdgetri)( &n,
                               loca, &one, &one, desca,
                               locipiv,
                               locwork, &llocwork,
                               lociwork, &llociwork,
                               &linfo);

	GATHER( "double", a, ROW_a, COL_a);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
		*info = linfo;
	} else {
	}

	FREE_MATRIX(a);
	FREE_VECTOR(ipiv);
        FREE(locwork);
        FREE(lociwork);

}

