#include <stdio.h>
#include <math.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/timeb.h>
#include "ninf_debug.h"

#define N 10

double A[N][N],B[N][N],C[N][N],D[N][N],E[N][N],F[N][N],G[N][N],G0[N][N];

main(int argc, char* argv[])
{
  int i,j,r;
  struct timeb s, e;
  int m;
  
  m = (argc > 1);
  for(i = 0; i < N; i++) {
    for(j = 0; j < N; j++) {
      A[i][j] = rand();
      B[i][j] = rand();
      C[i][j] = rand();
      D[i][j] = rand();
      E[i][j] = 0;
      F[i][j] = 0;
      G[i][j] = 0;
    }
  }
  ninf_debug_flag = (1==1);

  Ninf_check_in();
  if ((r = Ninf_call("mmul",N,A,B,E)) != 0) printf("error");
  if ((r = Ninf_call("mmul",N,C,D,F)) != 0) printf("error");
  if ((r = Ninf_call("mmul",N,E,F,G)) != 0) printf("error"); 
  Ninf_check_out();
  exit(0);
}


/* test routine */
mmul(n,A,B,C)
     double *A,*B,*C;
{
  double t;
  int i,j,k;
  
  printf("n0=%d\n",n);
  printf("A0(10,5)=%e\n",A[10*n+5]);
  printf("B0(10,5)=%e\n",B[10*n+5]);
  for (i=0;i<n;i++) {
    for (j=0;j<n;j++) {
      t = 0;
      for (k=0;k<N;k++){
	t += A[i*n + k] * B[k*n+j];	/* inner product */
      }
      C[i*n+j] = t;
    }
  }
  printf("C0(10,5)=%e\n",C[10*n+5]);
}

