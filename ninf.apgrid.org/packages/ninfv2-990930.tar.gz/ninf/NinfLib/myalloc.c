#include <stdlib.h>
#include <stdio.h>

void * myalloc(int size){
  void * tmp;
  tmp = malloc(size);
  if (tmp != NULL){
    return tmp;
  }
  fprintf(stderr, "Can't malloc\n");

/* cause bus error intentionally */
  fprintf(stderr, "%s", NULL);
}
