package bricks.util;
import java.util.*;

public class NormalRandomDataFragmentStringsCreator extends SubComponentCreator {

    public String usage() {
	return "NormalRandomDataFragmentStrings(<long seed>, <String keyOfResourceDB>)";
    }

    public SubComponent create(StringTokenizer st) throws BricksParseException{
	try {
	    long seed = Long.valueOf(st.nextToken(" \t,()")).longValue();
	    String keyOfResourceDB = st.nextToken(" \t,()");
	    return new NormalRandomDataFragmentStrings(seed, keyOfResourceDB);

	} catch (NumberFormatException e) {
	    e.printStackTrace();
	    throw new BricksParseException(usage());

	} catch (NoSuchElementException e) {
	    e.printStackTrace();
	    throw new BricksParseException(usage());
	}
    }
}

