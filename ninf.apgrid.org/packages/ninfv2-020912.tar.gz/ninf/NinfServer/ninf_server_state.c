#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#include "ninf_data_trans.h"
#include "ninf_server_state.h"
#include "ninf_ssl.h"
#include "ninf_config.h"

server_state * new_server_state(int socket, int withHeader, int accepting,
						char * clientname, char * username
#ifdef SSL_USE
				,  int ssl_use
#endif
				){
  server_state * tmp = (server_state *)malloc(sizeof(server_state));

#ifdef SSL_USE
  SSL_CTX * ctx = NULL;
  if (ssl_use)
    ctx = ninf_server_new_ssl_ctx(ssl_cert, ssl_key, ssl_ca_cert);
#endif


#ifdef SSL_USE
  tmp->client   = new_connection(socket, TRUE, accepting, ctx);
#else
  tmp->client   = new_connection(socket, TRUE, accepting);
#endif

  tmp->stub     = NULL;
  tmp->stub_out = NULL;
  tmp->stub_err = NULL;

  tmp->clientname = clientname != NULL? strdup(clientname): NULL;
  tmp->username   = username   != NULL? strdup(username):   NULL;
  return tmp;
}


void destruct_server_state(server_state * state){
  if (state->client != NULL)
    ninf_disconnect(state->client);
  if (state->stub != NULL)
    ninf_disconnect(state->stub);
  if (state->stub_out != NULL)
    ninf_disconnect(state->stub_out);
  if (state->stub_err != NULL)
    ninf_disconnect(state->stub_err);
  if (state->client != NULL)
    free(state->client);
  if (state->username != NULL)
    free(state->username);
  free(state);
}

/** This method just close the sockets and frees structure,
    without doing any closing manipulation. 
    This method is intended to be called by parent process. */
void close_server_state(server_state * state){
  if (state->client != NULL)
    connection_close(state->client);
  if (state->stub != NULL)
    connection_close(state->stub);
  if (state->stub_out != NULL)
    connection_close(state->stub_out);
  if (state->stub_err != NULL)
    connection_close(state->stub_err);
  if (state->client != NULL)
    free(state->client);
  if (state->username != NULL)
    free(state->username);
  free(state);
}

/***************************/

void fd_set_zero(ninf_fd_set * prfds){
      FD_ZERO(&(prfds->fds));
      prfds->max = 0;
}

void fd_set_set_fd(ninf_fd_set * prfds, int fd){
  FD_SET(fd, &(prfds->fds));
  if (prfds->max < fd)
    prfds->max = fd;
}

void fd_set_set_connection(ninf_fd_set *prfds, connection * con){
  if (con != NULL)
    fd_set_set_fd(prfds, connection_get_fd(con));
}

int fd_set_max(ninf_fd_set * prfds){
  return prfds->max;
}

int fd_set_is_set_fd(ninf_fd_set *prfds, int fd){
  return FD_ISSET(fd, &(prfds->fds));
}

int fd_set_is_set_connection(ninf_fd_set *prfds, connection * con){
  if (con == NULL)  
    return FALSE;
  return fd_set_is_set_fd(prfds, connection_get_fd(con));
}
