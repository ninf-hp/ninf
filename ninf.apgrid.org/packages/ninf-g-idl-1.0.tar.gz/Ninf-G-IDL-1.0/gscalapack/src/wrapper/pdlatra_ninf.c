#define _WRAPPER_
/* $Id: pdlatra_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define DOUBLE
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n
void  pdlatra_ninf(	 int n,
		 double global_a[],
		 int lda,
		 double *ret /* return value */
)
/* "pdlatra computes the trace of an N-by-N distributed matrix A. The result is left on every process of the grid." */
/* OPTIONS */
{
  extern double FortranCall(pdlatra)(int*,double* ,int *, int *, int *);

	int maxldd;

	int maxlda;
	double *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
	int row_loca, col_loca;

	double locpdlatra[1];

	INITIALIZE();

	SCALAR( "int", n);
	SCALAR("int",lda);

	ROW( a);
	COL( a);
	MAXLDD( maxldd, a );
	maxlda = maxldd;

	MATRIX( "double", a, ROW_a, COL_a);
	DISTRIBUTE( "double", a, ROW_a, COL_a);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranReturnSimple(pdlatra,locpdlatra,
                       ( &n,
                       loca, &one, &one, desca) );

	RETRIEVE("double",locpdlatra, 1);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
	  *ret = *locpdlatra;
	} else {
	}

	FREE_MATRIX(a);
}

