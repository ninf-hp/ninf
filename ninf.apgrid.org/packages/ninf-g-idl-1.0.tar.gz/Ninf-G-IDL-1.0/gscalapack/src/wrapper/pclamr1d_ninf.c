#define _WRAPPER_
/* $Id: pclamr1d_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define SCOMPLEX
#include <gscalapack.h>

void  pclamr1d_ninf(	 int n,
			 scomplex global_a[],
			 scomplex global_b[]
)
/* "pclamr1d redistributes a one-dimensional row vector from one data decomposition to another." */
/* OPTIONS */
{
	int maxldd;

	scomplex *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
	int row_loca, col_loca;

	scomplex *locb=NULL;
	int descb[DESCLEN];
	int desc_gb[DESCLEN];
	int row_locb, col_locb;


	INITIALIZE();

	SCALAR( "int", n);

	VECTOR("c", "scomplex", a,n);
	vDISTRIBUTE( "c", "scomplex", a, n);
	Cdescinit( desca, 1, n, 1, n, 0, 0, PARA_CTXT, 1, &linfo);
        
	VECTOR("c", "scomplex", b,n);
	vDISTRIBUTE( "c", "scomplex", b, n);
	Cdescinit( descb, 1, n, 1, n, 0, 0, PARA_CTXT, 1, &linfo);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pclamr1d)( &n,
                                loca, &one, &one, desca,
                                locb, &one, &one, descb);

	vGATHER( "c","scomplex", a, n);
	vGATHER( "c", "scomplex", b, n);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
	} else {
	}

        FREE_VECTOR(a);
        FREE_VECTOR(b);
	
}

