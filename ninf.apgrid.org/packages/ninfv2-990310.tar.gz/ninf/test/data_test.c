#include <stdio.h>
#include <math.h>
#include <string.h>
#include "ninf.h"
#include "ninf_error.h"
#define N    5

extern int ninf_debug_flag;
extern int ninf_error_code;
int verbose = FALSE;

int segv_test(){
  printf("segv_testing: ");
  if (Ninf_call("test/die_test", 0) == NINF_OK)
    return FALSE;
 if (ninf_error_code == STUB_ERROR_SIGSEGV)
    return TRUE;
 Ninf_perror("test/die_test");
 return FALSE;
}

int fpe_test(){
  printf("fpe_testing: ");
  if (Ninf_call("test/fpe_die_test", 0) == NINF_OK)
    return FALSE;
 if (ninf_error_code == STUB_ERROR_SIGFPE)
    return TRUE;
 Ninf_perror("test/fpe_die_test");
 return FALSE;
}

int char_test(){
  char a[N], b[N];
  int i, success = TRUE;
  for (i = 0; i < N; i++){
    a[i] = i; b[i] = 0;
  }
  printf("char_testing: ");
  if (Ninf_call("test/char_test", (char)N, a, b) != NINF_OK){
    Ninf_perror("test/char_test");
    return FALSE;
  }
  for (i = 0; i < N; i++){
    if (a[i] != b[i]){
      success = FALSE;
      if (verbose) 
	printf("char_test: a[%d](%d) != b[%d](%d)\n", i, a[i], i, b[i]);
    }
  }
  return success;
}

int short_test(){
  short a[N], b[N];
  int i, success = TRUE;
  for (i = 0; i < N; i++){
    a[i] = i; b[i] = 0;
  }
  printf("short_testing: ");
  if (Ninf_call("test/short_test", (short)N, a, b) != NINF_OK){
    Ninf_perror("test/short_test");
    return FALSE;
  }
  for (i = 0; i < N; i++){
    if (a[i] != b[i]){
      success = FALSE;
      if (verbose) 
	printf("short_test: a[%d](%d) != b[%d](%d)\n", i, a[i], i, b[i]);
    }
  }
  return success;
}

int int_test(){
  int a[N], b[N];
  int i, success = TRUE;
  for (i = 0; i < N; i++){
    a[i] = i; b[i] = 0;
  }
  printf("int_testing: ");
  if (Ninf_call("test/int_test", N, a, b) != NINF_OK){
    Ninf_perror("test/int_test");
    return FALSE;
  }
  for (i = 0; i < N; i++){
    if (a[i] != b[i]){
      success = FALSE;
      if (verbose) 
	printf("int_test: a[%d](%d) != b[%d](%d)\n", i, a[i], i, b[i]);
    }
  }
  return success;
}
int float_test(){
  float a[N], b[N];
  int i, success = TRUE;
  for (i = 0; i < N; i++){
    a[i] = i; b[i] = 0;
  }
  printf("float_testing: ");
  if (Ninf_call("test/float_test", N, a, b) != NINF_OK){
    Ninf_perror("test/float_test");
    return FALSE;
  }
  for (i = 0; i < N; i++){
    if (a[i] != b[i]){
      success = FALSE;
      if (verbose) 
	printf("float_test: a[%d](%f) != b[%d](%f)\n", i, a[i], i, b[i]);
    }
  }
  return success;
}
int double_test(){
  double a[N], b[N];
  int i, success = TRUE;
  for (i = 0; i < N; i++){
    a[i] = i; b[i] = 0;
  }
  printf("double_testing: ");
  if (Ninf_call("test/double_test", N, a, b) != NINF_OK){
    Ninf_perror("test/double_test");
    return FALSE;
  }
  for (i = 0; i < N; i++){
    if (a[i] != b[i]){
      success = FALSE;
      if (verbose) 
	printf("double_test: a[%d](%lf) != b[%d](%lf)\n", i, a[i], i, b[i]);
    }
  }
  return success;
}

int dcomplex_test(){
  double a[N*2], b[N*2];
  int i, success = TRUE;
  for (i = 0; i < N; i++){
    a[i * 2] = i; a[i*2+1] = i+0.1; 
    b[i * 2] = 0; b[i*2+1] = 0; 
  }
  printf("dcomplex_testing: ");
  if (Ninf_call("test/dcomplex_test", N, a, b) != NINF_OK){
    Ninf_perror("test/dcomplex_test");
    return FALSE;
  }
  for (i = 0; i < N; i++){
    if (a[i*2] != b[i*2] || a[i*2+1] != b[i*2+1]){
      success = FALSE;
      if (verbose) 
	printf("dcomplex_test: a[%d](%lf, %lf) != b[%d](%lf, %lf)\n", 
	       i, a[i*2], a[i*2+1], i, b[i*2], b[i*2+1]);
    }
  }
  return success;
}

int scomplex_test(){
  float a[N*2], b[N*2];
  int i, success = TRUE;
  for (i = 0; i < N; i++){
    a[i * 2] = i; a[i*2+1] = i+0.1; 
    b[i * 2] = 0; b[i*2+1] = 0; 
  }
  printf("scomplex_testing: ");
  if (Ninf_call("test/scomplex_test", N, a, b) != NINF_OK){
    Ninf_perror("test/scomplex_test");
    return FALSE;
  }
  for (i = 0; i < N; i++){
    if (a[i*2] != b[i*2] || a[i*2+1] != b[i*2+1]){
      success = FALSE;
      if (verbose) 
	printf("scomplex_test: a[%d](%f, %f) != b[%d](%f, %f)\n", 
	       i, a[i*2], a[i*2+1], i, b[i*2], b[i*2+1]);
    }
  }
  return success;
}


int lda_test(){
  double a[N][N], b;
  int i,j;

  for (i = 0; i < N; i++)
    for (j = 0; j < N; j++)
      a[i][j] = i * N + j;

  printf("lda_testing: ");
  if (Ninf_call("test/lda_test", 3, 3, N, a, &b)){
    Ninf_perror("test/lda_test");
    return FALSE;
  }
  if (b != 54.0)
    return FALSE;
  return TRUE;
}

int lda_test2(){
  double a[N][N], b;
  int i,j;

  for (i = 0; i < N; i++)
    for (j = 0; j < N; j++)
      a[i][j] = i * N + j;

  printf("lda_testing2: ");
  if (Ninf_call("test/lda_test2", 3, 3, N, a, &b)){
    Ninf_perror("test/lda_test2");
    return FALSE;
  }
  if (b != 54.0)
    return FALSE;
  return TRUE;
}

#include <string.h>
int string_test(){
  char * buffer = NULL;
  char * teststring = "test";
  int success = TRUE;

  printf("string_testing: ");
  if (Ninf_call("test/string_test", teststring, &buffer) != NINF_OK){
    Ninf_perror("string_test: ");
    return FALSE;
  }
  if (strcmp(teststring, buffer) != 0){
    if (verbose) printf("%s != %s\n", teststring, buffer);
    return FALSE;
  }
  return TRUE;
}

#define SKIP 3
#define TIMES 10
int skip_int_test(){
  int in[SKIP * TIMES];
  int out[SKIP * TIMES];
  int i, j;

  printf("skip_testing: ");
  for (i = 0; i < SKIP * TIMES; i++)
    in[i] = i;
  for (i = 0; i < SKIP; i++){
    if (Ninf_call("test/skip_int_test", SKIP * TIMES, i, SKIP * TIMES, SKIP, in, out)
	!= NINF_OK){
      Ninf_perror("skip_int_test: ");
      return FALSE;
    }
  }
  for (i = 0; i < SKIP * TIMES; i++){
    if (out[i] != (SKIP * TIMES - i -1))
      return FALSE;
    if (verbose) printf("%d ", out[i]);
  }
  if (verbose) printf("\n");
  return TRUE;
}

int skip_char_test(){
  char in[SKIP * TIMES];
  char out[SKIP * TIMES];
  int i, j;

  printf("skip_char_testing: ");
  for (i = 0; i < SKIP * TIMES; i++)
    in[i] = i;
  for (i = 0; i < SKIP; i++){
    if (Ninf_call("test/skip_char_test", SKIP * TIMES, i, SKIP * TIMES, SKIP, in, out)
	!= NINF_OK){
      Ninf_perror("skip_char_test: ");
      return FALSE;
    }
  }
  for (i = 0; i < SKIP * TIMES; i++){
    if (out[i] != (SKIP * TIMES - i -1))
      return FALSE;
    if (verbose) printf("%d ", out[i]);
  }
  if (verbose) printf("\n");
  return TRUE;
}

int skip_short_test(){
  short in[SKIP * TIMES];
  short out[SKIP * TIMES];
  int i, j;
  int success = TRUE;

  printf("skip_short_testing: ");
  for (i = 0; i < SKIP * TIMES; i++)
    in[i] = i;
  for (i = 0; i < SKIP; i++){
    if (Ninf_call("test/skip_short_test", SKIP * TIMES, i, SKIP * TIMES, SKIP, in, out)
	!= NINF_OK){
      Ninf_perror("skip_short_test: ");
      return FALSE;
    }
  }
  for (i = 0; i < SKIP * TIMES; i++){
    if (verbose) printf("%d ", out[i]);
    if (out[i] != (SKIP * TIMES - i -1))
      success = FALSE;
  }
  if (verbose) printf("\n");
  return success;
}

int skip_scomplex_test(){
  float in[SKIP * TIMES * 2];
  float out[SKIP * TIMES * 2];
  int i, j;
  int success = TRUE;

  printf("skip_scomplex_testing: ");
  for (i = 0; i < SKIP * TIMES; i++){
    in[i*2]   = i;
    in[i*2+1] = i + 0.1;
  }
  for (i = 0; i < SKIP; i++){
    if (Ninf_call("test/skip_scomplex_test", SKIP * TIMES, i, SKIP * TIMES, SKIP, in, out)
	!= NINF_OK){
      Ninf_perror("skip_scomplex_test: ");
      return FALSE;
    }
  }
  for (i = 0; i < SKIP * TIMES; i++){
    if (out[i * 2] != (SKIP * TIMES - i -1) ||
	out[i*2+1] != (float)(SKIP * TIMES - i -1 + 0.1))
      success = FALSE;
    if (verbose) printf("(%f, %f)", out[i*2],out[i*2+1]);
  }
  if (verbose) printf("\n");
  return success;
}

int skip_dcomplex_test(){
  double in[SKIP * TIMES * 2];
  double out[SKIP * TIMES * 2];
  int i, j;
  int success = TRUE;

  printf("skip_dcomplex_testing: ");
  for (i = 0; i < SKIP * TIMES; i++){
    in[i*2]   = i;
    in[i*2+1] = i + 0.1;
  }
  for (i = 0; i < SKIP; i++){
    if (Ninf_call("test/skip_dcomplex_test", SKIP * TIMES, i, SKIP * TIMES, SKIP, in, out)
	!= NINF_OK){
      Ninf_perror("skip_dcomplex_test: ");
      return FALSE;
    }
  }
  for (i = 0; i < SKIP * TIMES; i++){
    if (out[i * 2] != (SKIP * TIMES - i -1) ||
	out[i*2+1] != (SKIP * TIMES - i -1)+0.1)
      success = FALSE;
    if (verbose) printf("(%lf, %lf)", out[i*2],out[i*2+1]);
  }
  if (verbose) printf("\n");
  return success;
}

int expr_test(){
  int out[10];
  printf("expr_testing: ");
  if (Ninf_call("test/expr_test", 0, 1, 10, out) != NINF_OK){
    Ninf_perror("expr_test: ");
    return FALSE;
  }
  return TRUE;
}

double global_dp[N][N];

callback2D_func(double dp[][N]){
  int i,j;
  for (i = 0; i < N; i++)
    for (j = 0; j < N; j++)
      global_dp[i][j] = dp[i][j];
}

int callback2D_test(){
  double a[N][N];
  int i,j;

  for (i = 0; i < N; i++)
    for (j = 0; j < N; j++)
      a[i][j] = i * N + j;

  printf("callback2D_testing: ");
  if (Ninf_call("test/callback2D_test", N, a, callback2D_func)){
    Ninf_perror("test/callback2D_test");
    return FALSE;
  }
  for (i = 0; i < N; i++)
    for (j = 0; j < N; j++)
      if (a[i][j] != global_dp[i][j])
	return FALSE;
  return TRUE;
}

callback_return_func(double c[][N], double d[][N]){
  int i,j;
  for (i = 0; i < N; i++)
    for (j = 0; j < N; j++)
      d[i][j] = c[i][j];
}

int callback_return_test(){
  double a[N][N], b[N][N];
  int i,j;

  for (i = 0; i < N; i++)
    for (j = 0; j < N; j++){
      a[i][j] = i * N + j;
      b[i][j] = 0.0;
    }
  printf("callback_return_testing: ");
  if (Ninf_call("test/callback_return_test", N, a, b, callback_return_func)){
    Ninf_perror("test/callback_return_test");
    return FALSE;
  }
  for (i = 0; i < N; i++)
    for (j = 0; j < N; j++)
      if (a[i][j] != b[i][j])
	return FALSE;
  return TRUE;
}

int callback_multi_test(){
  double a[N][N], b[N][N];
  int i,j;

  for (i = 0; i < N; i++)
    for (j = 0; j < N; j++){
      a[i][j] = i * N + j;
      b[i][j] = 0.0;
    }
  printf("callback_multi_testing: ");
  if (Ninf_call("test/callback_multi_test", N, a, b, 
		callback_return_func, callback_return_func)){
    Ninf_perror("test/callback_multi_test");
    return FALSE;
  }
  for (i = 0; i < N; i++)
    for (j = 0; j < N; j++)
      if (a[i][j] != b[i][j])
	return FALSE;
  return TRUE;
}

double sum;

callback_func(double * dp){
  if (verbose) printf("callbacked %lf\n", *dp);
  sum += *dp;
}

int callback_test(){
  int ack;
  double initial = 100.0, lsum = 0.0;
  int times = 1;
  
  printf("callback_testing: ");
  sum = 0.0;

  if (Ninf_call("test/callback_test", initial, times, callback_func) != NINF_OK){
    Ninf_perror("callback_test: ");
    return FALSE;
  }
  {
    int i;
    double d = 0.0;
    for (i = 0; i < times; i++){
      d += initial;
      lsum += d;
    }
  }
  if (sum != lsum){
    if (verbose) printf("sum = %lf(should be %lf)\n", sum, lsum);
    return FALSE;
  }
  return TRUE;
}

char * callbacked;
callbackstring_func(char ** str){
  callbacked = *str;
}

int callback_string_test(){
  char * strings[] = {"caller0","caller1","caller2","caller3","caller4"};
  char string[1000];
  int i;

  callbacked = "";
  string[0] = '\0';
  
  printf("callback_string_testing: ");
  for (i = 0; i < 5; i++)
	strcat(string, strings[i]);

  if (Ninf_call("test/callbackstr", strings, callbackstring_func) != 0) {
    Ninf_perror("callbackstr: ");
    return FALSE;
  }
  if (verbose) printf("\ncallbacked = '%s'", callbacked);
  if (verbose) printf("\nfrontend   = '%s'\n", string);
  if (strcmp(callbacked, string) == 0)
    return TRUE;
  return FALSE;
}

main(int argc, char ** argv)
{
    argc = Ninf_parse_arg(argc, argv);

    while (argc > 1){
      argv++;
      if (strcasecmp(*(argv), "-verbose") == 0)
	verbose = TRUE;
      if (strcasecmp(*(argv), "-debug") == 0)
	ninf_debug_flag = TRUE;
      argc--;
    }
    if (char_test())  {printf("\tOK\n");} else { printf("\tfailed\n");} 
    if (short_test()) {printf("\tOK\n");} else { printf("\tfailed\n");}
    if (int_test())   {printf("\tOK\n");} else { printf("\tfailed\n");}
    if (float_test()) {printf("\tOK\n");} else { printf("\tfailed\n");}
    if (double_test()){printf("\tOK\n");} else { printf("\tfailed\n");}
    if (string_test()){printf("\tOK\n");} else { printf("\tfailed\n");}
    if (scomplex_test()){printf("\tOK\n");} else { printf("\tfailed\n");}
    if (dcomplex_test()){printf("\tOK\n");} else { printf("\tfailed\n");}
    if (skip_int_test())  {printf("\tOK\n");} else { printf("\tfailed\n");}
    if (skip_char_test())  {printf("\tOK\n");} else { printf("\tfailed\n");}
    if (skip_short_test())  {printf("\tOK\n");} else { printf("\tfailed\n");}
    if (skip_scomplex_test())  {printf("\tOK\n");} else { printf("\tfailed\n");}
    if (skip_dcomplex_test())  {printf("\tOK\n");} else { printf("\tfailed\n");}
    if (lda_test())   {printf("\tOK\n");} else { printf("\tfailed\n");}
    if (lda_test2())  {printf("\tOK\n");} else { printf("\tfailed\n");}
    if (expr_test())  {printf("\tOK\n");} else { printf("\tfailed\n");}
    if (callback_test())  {printf("\tOK\n");} else { printf("\tfailed\n");}
    if (callback2D_test())  {printf("\tOK\n");} else { printf("\tfailed\n");}
    if (callback_return_test())  {printf("\tOK\n");} else { printf("\tfailed\n");}
    if (callback_string_test())  {printf("\tOK\n");} else { printf("\tfailed\n");}
    if (callback_multi_test())  {printf("\tOK\n");} else { printf("\tfailed\n");}
    if (segv_test())  {printf("\tOK\n");} else { printf("\tfailed\n");}
    if (fpe_test())  {printf("\tOK\n");} else { printf("\tfailed\n");}
}

