#define _WRAPPER_
/* $Id: pslatra_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define FLOAT
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n
void  pslatra_ninf(	 int n,
		 float global_a[],
		 int lda,
		 float *ret /* return value */
)
/* "pslatra computes the trace of an N-by-N distributed matrix A. The result is left on every process of the grid." */
/* OPTIONS */
{
  extern float FortranCall(pslatra)(int*,float* ,int *, int *, int *);

	int maxldd;

	int maxlda;
	float *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
	int row_loca, col_loca;

	float locpslatra[1];

	INITIALIZE();

	SCALAR( "int", n);
	SCALAR("int",lda);

	ROW( a);
	COL( a);
	MAXLDD( maxldd, a );
	maxlda = maxldd;

	MATRIX( "float", a, ROW_a, COL_a);
	DISTRIBUTE( "float", a, ROW_a, COL_a);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranReturnSimple(pslatra,locpslatra,
                       ( &n,
                       loca, &one, &one, desca ) );

	RETRIEVE("float",locpslatra, 1);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
	  *ret = *locpslatra;
	} else {
	}

	FREE_MATRIX(a);
}

