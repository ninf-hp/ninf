/* ========================================= */
/* This file is for Ninf_Q calling function. */
/* ========================================= */
/*
 * $Id
 */

#include <stdio.h>
#include <stdarg.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <signal.h>
#include <sys/wait.h>
#if defined(__svr4__)
#include <rpc/types.h>
#endif 
#include <sys/errno.h>
#include "ninf_stub_info.h"
#include "ninf_packet.h"
#include "ninf_Q_call.h"
#include "ninf_serv_reg.h"

#define CURRENT

#define MAX_GET_INFO 20

NINF_STUB_INFO * ninf_stubs;
/* struct sockaddr_in peer;  */

extern char ninf_pkt_buf[MAX_PKT_LEN*2]; 
               /* client packet buffer(ninf_Q) */
extern DECODED_HEADER decoded;

#define EXACT   0
#define PARTIAL 1

/* ================================================= */
/*       Ninf_Q client ����θƤӽФ��ؿ�            */
/* ------------------------------------------------- */
/* 
 * Ninf_Q(options,the_number_of_entry,"entry_name"...);
 */
Ninf_Q(options,keyword,falph,talph,entry_num,argv)
  int options;
  int entry_num;
  char *keyword, *falph, *talph;
  char *argv[];
{
  va_list ap;
  char *ninf_stub_entry,*words;
  NINF_STUB_INFO *curp,*stubp;
  struct ninf_param_desc *dp,*curparam;
  int nparam,err,ack;
  int i;
  int code,stub_index,check;
  int stub_max;
  int indexes[MAX_GET_INFO];


 /* file name and file pointer */
  FILE *nodefp;
  char node_name[NINF_MAX_NAME_LEN+10];

/* ---------------------------- */
/*  �ؿ��ꥹ�Ȥ��׵᤬������  */
/* ---------------------------- */
  /* keyword search */
  if (options & KOPTION){
    switch (check = get_indexes_by_keyword(keyword, indexes, PARTIAL, MAX_GET_INFO)) {
    case -1:
      ninf_error("can't read in NINF_PKT_RPY_STUB_INDEX_LIST");
      exit(3);
    case -2:
      non_specific_error();
    default:
      print_matched_number(check);
    }
    
    for(i = 0; i < check; i++){
      if(!(err = get_stub_info_by_index(indexes[i])))
	return (NINF_ERROR);
/*      if(!i && !m)   fprintf(stdout, "[Index]\n"); */
      name_list(ninf_stubs,stdout);
    }
  }

/* -------------------------- */
/*  �ؿ��ܺ٤��׵᤬������  */
/* -------------------------- */
  /* each functions search */
 if(options & EOPTION){
   for (i = 0; i < entry_num; i++){
     switch (check = get_indexes_by_keyword(argv[i], indexes, EXACT, MAX_GET_INFO)) {
     case  1:
       break;
     case -1:
       ninf_error("can't read in NINF_PKT_RPY_STUB_INDEX_LIST\n");
       exit(3);
     default:
       non_specific_error(check);
     }
     if(!(err = get_stub_info_by_index(indexes[0])))
       return (NINF_ERROR);

     fprintf(stdout,"<out---first No.%d(stub_max %d)>",i,check);
     node_file_writing(ninf_stubs,stdout);
#ifdef NON
     if (getenv("FROM_CGI")) {
       stub_info(ninf_stubs,stdout);
     }
#endif
    }
  }
/* ������������������� */
 return(NINF_OK);
}


/* =================================== */
/*   get indexes of matched stub       */
/*  -1: error    -2: overflow          */
/*      moved to ninf_call_remote      */
/*                      by Nakada      */
/* ----------------------------------- */



/* =============================== */
/*  data type ���Ѵ� ���� �� ʸ��  */
/* ------------------------------- */
char *EXdata_type(type)
   int type;
{
   switch(type){
     case DT_UNDEF:
         return("UNDEF");
     case DT_VOID:
         return("VOID");
     case DT_CHAR:
         return("CHAR");
     case DT_SHORT:
         return("SHORT");
     case DT_INT:
         return("INT");
     case DT_LONG:
         return("LONG");
     case DT_LONGLONG:
         return("LONGLONG");
     case DT_UNSIGNED_CHAR:
         return("UNSIGNED_CHAR");
     case DT_UNSIGNED_SHORT:
         return("UNSIGNED_SHORT");
     case DT_UNSIGNED:
         return("UNSIGNED");
     case DT_UNSIGNED_LONG:
         return("UNSIGNED_LONG");
     case DT_UNSIGNED_LONGLONG:
         return("UNSIGNED_LONGLONG");
     case DT_FLOAT:
         return("FLOAT");
     case DT_DOUBLE:
         return("DOUBLE");
     case DT_LONG_DOUBLE:
         return("LONG_DOUBLE");
     case DT_STRING_TYPE:
         return("STRING_TYPE");
     case BASIC_TYPE_END: 
         return("BASIC_TYPE_END");
     default:
         return("UNDEF");
   }
} /* DATA_TYPE */

/* =============================== */
/*  mode spec ���Ѵ� ���� �� ʸ��  */
/* ------------------------------- */
char *EXmode_spec(type)
   int  type;
{
   switch(type){
     case MODE_NONE:
         return("MODE_NONE");
     case MODE_IN:
         return("MODE_IN");
     case MODE_OUT:
         return("MODE_OUT");
     case MODE_INOUT:
         return("MODE_INOUT");
     default:
         return("MODE_NONE");
   }
} /*  MODE_SPEC */

/* =============================== */
/*  value type���Ѵ� ���� �� ʸ��  */
/* ------------------------------- */
char *EXVALUE_TYPE(type)
    int type;
{
   switch(type){
     case VALUE_NONE:
         return("VALUE_NONE");
     case VALUE_CONST:
         return("VALUE_CONST");
     case VALUE_IN_ARG:
         return("VALUE_IN_ARG");
     case VALUE_BY_EXPR:
         return("VALUE_BY_EXPR");
     case VALUE_ERROR:
         return("VALUE_ERROR");
     default:
         return("VALUE_NONE");
   }
} /* VALUE_TYPE */

/* ======================================== */
/*  �ؿ����֥롼����ΰ�����ʸ���γ������  */
/* ---------------------------------------- */
char EXi(num,type)
  int num;
  int type;
{
   int i,modnum,divnum;
   
   if(num > 26){
      for(i = 0,divnum = num; divnum < 27; i++){
        modnum = divnum%26;
        divnum = divnum/26;
        if(type == 0)  return ('a'+ modnum);
        else           return ('A'+ modnum);
      }
   }
   else
        if(type == 0)  return('a'+ num);
        else           return('A'+num);
}

/* ==================== */
/*  �ؿ��ꥹ���Ѥν���  */
/* -------------------- */
void name_list(curp,fp)
   NINF_STUB_INFO *curp;
   FILE *fp;
{
   fprintf(fp,"\t[name]%s\n",curp->entry_name);
   fprintf(fp,"\t[calling style] ");
   func_style(curp,fp);
   fprintf(fp,"\n\t[some other information]...\n");
}

/* ================== */
/*  �ؿ��ܺ��Ѥν���  */
/* ------------------ */
void node_file_writing(curp,fp)
   NINF_STUB_INFO *curp;
   FILE *fp;
{
   int i,k,j,l;
   struct ninf_param_desc *curparam;

   /* output node file */

    fprintf(fp,"***** %s *****\n",curp->entry_name);
    fprintf(fp, "(kinds)(NINF_INFO %d)", curp->info_type);
    fprintf(fp," MODULE %s (NINF Ver%d.%d)\n\n",
          curp->module_name,curp->version_major,curp->version_minor);
    fprintf(fp,"When you call Ninf_call(\"%s\",(some arguments)),"
                          ,curp->entry_name);
    fprintf(fp,"Ninf client calls Ninf_%s((some arguments)).\n",
                  curp->entry_name);
    fprintf(fp," Status information is returned.\n");
    fprintf(fp,"\n\t[Name] Ninf_%s \n\n", curp->entry_name);
    fprintf(fp,"\n\t[Synopsis] ");
    func_style(curp,fp);
    fprintf(fp,"\n");

    func_style(curp,fp);
    fprintf(fp,"\n");
    args_style(curp,fp);
    fprintf(fp,"\n");
    fprintf(fp,"\n\t[Calling Style] ");
    calling_style(curp,fp);

    if(getenv("FROM_CGI")) {    /* �������� */
         fprintf(fp," /* ");
         calling_info(curp,fp);
         fprintf(fp," */\n");
    }

    fprintf(fp,"\n\t[Example(C language)]\n");
    fprintf(fp,"\tint     r;\n\n");
    args_style(curp,fp);
    fprintf(fp,"\n");
    fprintf(fp,"\n\tr = ");
    calling_style(curp,fp);
    fprintf(fp,"\n");
    fprintf(fp,"\t[sample program(remote)]\n");


    fprintf(fp,"\n\t[Introduction of The Developer]\n");
    fprintf(fp,
     "\t\tIf you want to know about the developer of this function, please access ...\n");

}

/* =========================== */
/* �ؿ����֥롼����Υƥ�����  */
/* ��ɬ�פʤ��Ჾ�˽���        */
/* --------------------------- */
void stub_info(curp,rfp)
    NINF_STUB_INFO *curp;
    FILE *rfp;
{
   int i,j;
   struct ninf_param_desc *curparam;

   fprintf(rfp,"\n\n/********* NINF_STUB_INFO \"%s\" *******/ \n\n",curp->entry_name);
    fprintf(rfp,"entry_name:%s\t/* entry name */\n",curp->entry_name);
    fprintf(rfp,"nparam:%d\n",curp->nparam);
    for(i = 0; i < curp->nparam; i++){
      fprintf(rfp,"   param[%d]\n",i);
      curparam = &curp->params[i];
      fprintf(rfp,"\tparam_type:%d\t/* argument type */\n",
                                                curparam->param_type);
      fprintf(rfp,"\tparam_inout:%d\t/* IN/OUT */\n",curparam->param_inout);
      fprintf(rfp,"\tndim:%d\n",curparam->ndim);
#ifdef CURRENT 
        for(j = 0; j < curparam->ndim; j++){
          fprintf(rfp,"type: %d\n",curparam->dim[j].size_type);
          fprintf(rfp,"size: %d\n",curparam->dim[j].size);
          fprintf(rfp,"start_type: %d\n",curparam->dim[j].start_type);
          fprintf(rfp,"start: %d\n",curparam->dim[j].start);
          fprintf(rfp,"end_type: %d\n",curparam->dim[j].end_type);
          fprintf(rfp,"end: %d\n",curparam->dim[j].end);
          fprintf(rfp,"step: %d\n",curparam->dim[j].step_type);
          fprintf(rfp,"%d\n",curparam->dim[j].step);
        } 
#endif
    }
    fprintf(rfp,"/********* END STUB *****/\n");
}

void calling_info(curp,rfp)
    NINF_STUB_INFO *curp;
    FILE *rfp;
{
   int i,j;
   struct ninf_param_desc *curparam;

    fprintf(rfp,"%s+",curp->entry_name); /* entry_name */
    fprintf(rfp,"%d+",curp->nparam);     /* nparam */
    for(i = 0; i < curp->nparam; i++){   /* params info */
       if(i) fprintf(rfp,"+");
       curparam = &curp->params[i];
       fprintf(rfp,"%d-%d-%d"
          ,curparam->param_type,curparam->param_inout,curparam->ndim);
     }
}

void func_style(curp,fp)
       NINF_STUB_INFO *curp;
       FILE *fp;
{
      int k;

       fprintf(fp,"\tNinf_%s(",curp->entry_name);
       for(k = 0; k < curp->nparam; k++){
         if(k > 0) fprintf(fp,", ");
         if( curp->params[k].ndim > 0)
            fprintf(fp,"%c",EXi(k,1));
         else
            fprintf(fp,"%c",EXi(12+k,0));
       }
        fprintf(fp,");");
}

/* ======================== */
/*  �ؿ��ƤӽФ������ν���  */
/* ------------------------ */
void calling_style(curp,fp)
       NINF_STUB_INFO *curp;
       FILE *fp;
{
      int k;

       fprintf(fp,"Ninf_call(\"_stub_%s\"",curp->entry_name);
       for(k = 0; k < curp->nparam; k++){
         fprintf(fp,", ");
         if( curp->params[k].ndim > 0)
            fprintf(fp,"%c",EXi(k,1));
         else
            fprintf(fp,"%c",EXi(12+k,0));
       }
       fprintf(fp,");");
}

/* ================ */
/*  �ؿ������ν���  */
/* ---------------- */
void args_style(curp,fp)
      NINF_STUB_INFO *curp;
      FILE *fp;
{
      int j,l;
      struct ninf_param_desc *curparam;

       for(l = 0; l < curp->nparam; l++){
           curparam = &curp->params[l];
           if(l > 0) fprintf(fp,",\n");
           fprintf(fp,"\t%-8s%-10s",
                   EXdata_type(curparam->param_type),
                   EXmode_spec(curparam->param_inout));
           if(curp->params[l].ndim > 0)
                fprintf(fp,"%c",EXi(l,1));
           else
                fprintf(fp,"%c",EXi(12+l,0));

           if(curp->params[l].ndim > 0){
             for(j = 0; j < curp->params[l].ndim; j++){
                switch(curparam->dim[j].size_type){
                  case  VALUE_CONST:
                    fprintf(fp,"[%d]",curparam->dim[j].size);
                    break;
                  case  VALUE_IN_ARG:
                    fprintf(fp,"[%c]",EXi(12+curparam->dim[j].size,0));
                    break;
                  case  VALUE_BY_EXPR:
                    /* ????? */
                    break;
                  default:
                    fprintf(fp,"[]");
                    break;
		  }
	      }
	   }
	 }
}


/* require stub infomation */
NINF_STUB_INFO * Ninf_get_stub_by_index(int index);
int get_stub_info_by_index(int stub_index){
  ninf_stubs = Ninf_get_stub_by_index(stub_index);
  if (ninf_stubs == NULL)
    return FALSE;
  return TRUE;
}

non_specific_error(int check){
  fprintf(stdout,"There are %d functions which match your request.\n",check);
  fprintf(stdout,"It is too many functions to show.\n");
  fprintf(stdout,"You should make another request more detailed.\n");
  fprintf(stdout,"Anyway you can see the tops of the list.\n");
}

print_matched_number(int check){
  if(check == 1)
    fprintf(stdout,"There are %d function which match your request.\n",check);
  else
    fprintf(stdout,"There are %d functions which match your request.\n",check);
}
