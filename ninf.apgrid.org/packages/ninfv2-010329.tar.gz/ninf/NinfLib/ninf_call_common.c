/*
 *  $Id: ninf_call_common.c,v 1.6 1999/05/15 01:10:31 nakada Exp $
 */

#include <stdio.h>
#include <stdlib.h>

#include <stdarg.h>
#include <stdio.h>

#include "ninf_stub_info.h"
#include "resource.h"
#include "ninf_any_t.h"
#include "ninf_error.h"

void  set_resource_cont(char * p, resource * rsc);

int get_next_call_head(NINF_STUB_INFO * ninf_stub_info_p, int n){
  int i;
  DATA_TYPE type;
  struct ninf_param_desc *dp;

  for (i = n; i < ninf_stub_info_p->nparam; i++){
    dp = &(ninf_stub_info_p->params[i]);
    type = dp->param_type;
    if (type ==  DT_FUNC_TYPE)
      return i;
  }
  return i;
}


void
ninf_get_arg_sub2(va_list * app, NINF_STUB_INFO * ninf_stub_info_p, any_t ninf_args[], int start, int end, resource rsc[], int FortranFlag)
{
  int i;
  int nparam = ninf_stub_info_p->nparam;
  struct ninf_param_desc *dp;
  for(i = start; i < end; i++){
    dp = &(ninf_stub_info_p->params[i]);
    if (dp->ndim == 0) {  /* scalar */
      switch(dp->param_type){
      case DT_CHAR:
	if (FortranFlag)
	  ninf_args[i].u.c = (char)(*(va_arg(*app,int *)));
	else
	  ninf_args[i].u.c = (char)(va_arg(*app,int));
	break;
      case DT_SHORT:
	if (FortranFlag)
	  ninf_args[i].u.s = (short)(*(va_arg(*app,int *)));
	else
	  ninf_args[i].u.s = (short)(va_arg(*app,int));
	break;
      case DT_INT:
	if (FortranFlag)
	  ninf_args[i].u.i = *(va_arg(*app,int *));
	else
	  ninf_args[i].u.i = va_arg(*app,int);
	break;
      case DT_LONG:
	if (FortranFlag)
	  ninf_args[i].u.i = *(va_arg(*app,long *));
	else
	  ninf_args[i].u.l = va_arg(*app,long);
	break;
      case DT_UNSIGNED_CHAR:
	if (FortranFlag)
	  ninf_args[i].u.uc = (unsigned char)(*(va_arg(*app, unsigned int *)));
	else
	  ninf_args[i].u.uc = (unsigned char)(va_arg(*app,unsigned int));
	break;
      case DT_UNSIGNED_SHORT:
	if (FortranFlag)
	  ninf_args[i].u.us = (unsigned short)(*(va_arg(*app, unsigned int *)));
	else
	  ninf_args[i].u.us = (unsigned short)(va_arg(*app,unsigned int));
	break;
      case DT_UNSIGNED:
	if (FortranFlag)
	  ninf_args[i].u.ui = (unsigned int)(*(va_arg(*app, unsigned int *)));
	else
	  ninf_args[i].u.ui = va_arg(*app,unsigned int);
	break;
      case DT_UNSIGNED_LONG:
	if (FortranFlag)
	  ninf_args[i].u.ul = *(va_arg(*app, unsigned long *));
	else
	  ninf_args[i].u.ul = va_arg(*app,unsigned long);
	break;
      case DT_FLOAT:
	if (FortranFlag)
	  ninf_args[i].u.f = (float)(*(va_arg(*app, double *)));
	else
	  ninf_args[i].u.f = (float)(va_arg(*app,double));
	break;
      case DT_DOUBLE:
	if (FortranFlag)
	  ninf_args[i].u.d = *(va_arg(*app, double *));
	else
	  ninf_args[i].u.d = va_arg(*app,double);
	break;
      case DT_STRING_TYPE:
	ninf_args[i].u.p = va_arg(*app, char *);
	break;
      case DT_FILENAME:
	ninf_args[i].u.p = va_arg(*app, char *);
	break;
      case DT_FILEPOINTER:
	ninf_args[i].u.p = va_arg(*app, char *);
	break;
      case DT_LONG_DOUBLE:
      case DT_UNSIGNED_LONGLONG:
      case DT_LONGLONG:
	ninf_error("not supported data types");
	break;
      default:
	ninf_error("unknown data type");
	break;
      }
    } else {
      ninf_args[i].u.p = va_arg(*app,char *);
      set_resource_cont(ninf_args[i].u.p, &(rsc[i]));
    }
  }
}

void ninf_get_arg_sub(va_list * app, NINF_STUB_INFO * ninf_stub_info_p, any_t ninf_args[], int start, int end, resource rsc[]){
  ninf_get_arg_sub2(app, ninf_stub_info_p, ninf_args, start, end, rsc, FALSE);
}

char * save_str(char *);
#include <string.h>

static char * DEFAULT_HTTP_PORT = "80";

void set_resource_cont(char * p, resource * rsc){
  char * host, * index;

  if (ninf_debug_flag) printf("set_resource_cont %c%c%c%c\n", p[0], p[1], p[2],p[3]);
  if ((p[0] == 'h' && p[1] == 't'&& p[2] == 't' && p[3] == 'p') ||
      (p[0] == 's' && p[1] == 't'&& p[2] == 'o' && p[3] == 'r' && 
       p[4] == 'a' && p[5] == 'g' && p[6] == 'e')){
    p = save_str(p);
    strtok(p, "/");
    host = strtok(NULL, "/");
    index = strtok(NULL, "\0");
     rsc->host = strtok(host, ":");
    rsc->port = strtok(NULL, "\0");
    if (rsc->port == NULL)
      rsc->port = DEFAULT_HTTP_PORT;
    rsc->resource_name = save_str(index);
    if (p[0] == 'h')
      rsc->protocol = HTTP_RESOURCE;
    else
      rsc->protocol = NINF_STORAGE_RESOURCE;
   if (ninf_debug_flag) printf("host:%s, port:%s, resource:%s\n", rsc->host, rsc->port, rsc->resource_name); 
  } else if (p[0] == 'f' && p[1] == 'i'&& p[2] == 'l' && p[3] == 'e'){
    p = save_str(p);
    strtok(p, "/");
    index = strtok(NULL, "/");
    rsc->protocol = FILE_RESOURCE;
    rsc->host = "";
    rsc->port = "";
    rsc->resource_name = save_str(index);
    if (ninf_debug_flag) 
      printf("host:%s, port:%s, resource:%s\n", rsc->host, rsc->port, rsc->resource_name); 
  }    
}



