#! /bin/sh
# $Id: install.sh,v 1.1.1.1 2005/06/07 08:58:29 naotaka Exp $

for arg in "$@" ; do
    case $arg in
        *=*) eval `expr ${arg} : '\(.*\)='`=`expr ${arg} : '.*=\(.*\)'`
        ;;
        *)
        ;;
    esac
done

[ x"${TOPDIR}" = x"" ] && exit 3
[ x"${BINDIR}" = x"" ] && exit 3
[ x"${THISDIR}" = x"" ] && exit 3
[ x"${LDIF_INSTALL_DIR}" = x"" ] && exit 3

if [ ! -f ${TOPDIR}/src/fftw.idl ] ; then
    exit 2
fi


if [ -d ${BINDIR} ] ; then
    cd ${BINDIR} || exit 2
    for idl in ${THISDIR}/*idl ; do
	endmark=`basename ${idl} | sed -e 's!\([^/][^/]*\)\.idl!.\1!'`
	[ x"${endmark}" = x"" ] && exit 3
	if [ -f ${THISDIR}/${endmark} ] ; then
	    funclist=`grep Define ${idl} | sed -e 's!^.*Define !!;s!(.*$!!' `
	    for funcname in $funclist  ; do
		if [ -f fftw::${funcname}.ldif ] ; then
		    echo "Registering fftw/${funcname}"
		    cp -f fftw::${funcname}.ldif ${LDIF_INSTALL_DIR}
		fi
	    done
	fi
    done
    if [ -f fftw.mak ] ; then
	rm fftw.mak
    fi
    cd ${THISDIR}
fi
