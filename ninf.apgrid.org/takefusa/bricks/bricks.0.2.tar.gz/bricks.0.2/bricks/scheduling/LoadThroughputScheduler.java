package bricks.scheduling;
import bricks.util.*;
import bricks.environment.*;
import java.util.*;

public class LoadThroughputScheduler extends Scheduler implements SchedulingUnit {

    public LoadThroughputScheduler(String keyOfMetaPredictor) {
	this.keyOfMetaPredictor = keyOfMetaPredictor;
	schedulingOverhead = 0.0;
    }

    // for Deadline
    public LoadThroughputScheduler(
	String keyOfMetaPredictor, double optimisticFactor, double interval
    ) {
	this.keyOfMetaPredictor = keyOfMetaPredictor;
	schedulingOverhead = 0.0;
    }

/************************* needed method *************************/
    public String getName() {
	return "LoadThroughputScheduler";
    }

    public void selectHosts (
	double currentTime, Host source, RequestedData data
    ) throws BricksNotScheduledException {

	double minElapsedTime = Double.POSITIVE_INFINITY;
	Host selectedHost = null;

	Enumeration e = resourceDB.hosts(data);
	while (e.hasMoreElements()) {
	    Host h = (Host)e.nextElement();
	    if (!data.scheduled(h)) { //for fallback
		double elapsedTime = getEstimate(currentTime, source, h, data);
		if (minElapsedTime > elapsedTime) {
		    minElapsedTime = elapsedTime;
		    selectedHost = h;
		}
	    }
	}

	// for fallback
	if (selectedHost == null) {
	    if (data.numSchedule() == 0)
		throw new BricksNotScheduledException(this.toString());

	    e = data.scheduledHosts();
	    while (e.hasMoreElements()) {
		Host h = (Host) e.nextElement();
		double elapsedTime = getEstimate(currentTime, source, h, data);
		if (minElapsedTime > elapsedTime) {
		    minElapsedTime = elapsedTime;
		    selectedHost = h;
		}
	    }
	}

	//System.out.println(
	SimulationDebug.println(
	    "LoadThroughputScheduler : select " + selectedHost
	);
	updateStatus(currentTime, source, selectedHost, data);
	if (data.deadlineFactor > 0)
	    data.setElapsedTime(data.deadline - currentTime);
    }
}

