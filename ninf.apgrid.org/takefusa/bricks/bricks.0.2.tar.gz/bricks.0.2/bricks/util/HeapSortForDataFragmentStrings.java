package bricks.util;
import java.util.*;
import bricks.environment.DataFragment;

public class HeapSortForDataFragmentStrings {
    
    private static final String Usage = 
	"java bricks.util.HeapSortForDataFragmentStrings [int numData]";

    private static Vector v = new Vector();

    public static void sortByGeneratedTime(Vector list) {
	int bottom = list.size() / 2;
	int top = list.size() - 1;
	while (bottom > 0) {
	    bottom--;
	    shiftDownByGeneratedTime(list, top, bottom);
	}
	while (top > 0) {
	    swap(list, 0, top);
	    top--;
	    shiftDownByGeneratedTime(list, top, bottom);
	}
    }

    protected static void shiftDownByGeneratedTime(
	Vector list, int top, int bottom
    ) {
	int i = 2 * bottom;
	while (i <= top) {
	    if (i < top) {
		DataFragment fragment1 = (DataFragment)list.elementAt(i+1);
		DataFragment fragment0 = (DataFragment)list.elementAt(i);
		if (fragment1.generatedTime > fragment0.generatedTime)
		    i++;
	    }
	    if (((DataFragment)list.elementAt(bottom)).generatedTime
		>= ((DataFragment)list.elementAt(i)).generatedTime)
		break;
	    swap(list, bottom, i);
	    bottom = i;
	    i = 2 * bottom;
	}
    }

    public static void swap(Vector list, int indexA, int indexB) {
	Object tmp = list.elementAt(indexA);
	list.insertElementAt(list.elementAt(indexB), indexA);
	list.removeElementAt(indexA + 1);
	list.insertElementAt(tmp, indexB);
	list.removeElementAt(indexB + 1);
    }
}


