#define _WRAPPER_
/* $Id: pzdttrs_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define DCOMPLEX
#define _DISTRIBUTE_1D_
#include <gscalapack.h>

#define ROW_b ldb
#define COL_b nrhs
#define ROW_af laf
#define COL_af n
static	int worklen(int nths) {
	  int ret=1;
	  ret = 10+4*nrhs;
	  if NEED_BUFF {
	    ret = 10*npcol+4*nrhs;
	  }
	  return ret;
}


void  pzdttrs_ninf(	 char trans,
		 int n,
		 int nrhs,
		 dcomplex global_dl[],
		 dcomplex global_d[],
		 dcomplex global_du[],
		 dcomplex global_b[],
		 int ldb,
		 dcomplex af[],
		 int dummy_laf,
		 dcomplex work[],
		 int lwork,
		 int *info
)
/* " pzdttrs solves a system of linear equations A * X = B or A' * X = B where A is the matrix used to produce the factors stored in A and AF by PCDTTRF.  A is an N-by-N complex tridiagonal diagonally dominant-like distributed matrix.  Routine PCDTTRF MUST be called first." */
/* OPTIONS */
{
extern void FortranCall(pzdttrs)( char*, int*, int*,
                               dcomplex*, int*, int*, int*, int*,
                               dcomplex*, int*, int*,
                               dcomplex*, int*,
                               dcomplex*, int*, int*);

	int maxldd;
	dcomplex *locdl=NULL, *locd=NULL, *locdu=NULL;
	int desctdd[DESCLEN];
	int desc_gtdd[DESCLEN];

	dcomplex *locb=NULL;
	int descb[DESCLEN];
	int desc_gb[DESCLEN];
	int row_locb, col_locb;
	int maxldb;

	dcomplex *locaf=NULL,*global_af=NULL;
	int maxldaf;
	int descaf[DESCLEN];
	int desc_gaf[DESCLEN];
	int laf, llocaf;
	int row_locaf, col_locaf;
	
	dcomplex *locwork=NULL;
	int llocwork;

	INITIALIZE();

	SCALAR( "char", trans);
	SCALAR( "int", n);
	SCALAR( "int", nrhs);
	SCALAR("int", dummy_laf);
	SCALAR( "int", lwork);

	SIZE(n);

	laf = 2*(blocsize+2)*nprocs/n;
	llocaf = laf*blocsize;
	if (mypnum==0) {
	  global_af=MALLOC(sizeof(double)*laf*n);
          assert(global_af);
	}

	ROW(b);
	COL(b);
	ROW(af);
	COL(af);
	MAXLDD( maxldd, b);
	maxldb=maxldd;
	maxldaf=maxldd;

	tdMATRIX( "dcomplex", dl, d, du, n);
	MATRIX( "dcomplex", b, ROW_b, COL_b);
	MATRIX( "dcomplex", af, ROW_af, COL_af);
	tdDISTRIBUTE( "dcomplex", dl, d, du, n);
	DISTRIBUTE( "dcomplex", b, ROW_b, COL_b);

	llocwork = worklen(nrhs);
        llocwork = max(llocwork,lwork);
	WORK(locwork,llocwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pzdttrs)( &trans, &n, &nrhs,
                               locdl, locd, locdu, &one, desctdd,
                               locb, &one, descb,
                               locaf, &llocaf,
                               locwork, &llocwork, &linfo);

	tdGATHER( "dcomplex", dl, d, du, n);
	GATHER( "dcomplex", b, ROW_b, COL_b);
	GATHER( "dcomplex", af, ROW_af, COL_af);

	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
	  int i;
	  *info = linfo;
	  for(i=0;i<min(dummy_laf,laf*n);i++) af[i] = global_af[i];
          FREE(global_af);
	} else {
	}

        FREE_MATRIX(dl);
        FREE_MATRIX(d);
        FREE_MATRIX(du);
        FREE_MATRIX(b);
        FREE_MATRIX(af);

        FREE(locwork);
}

