package ninf.client;

import java.io.*;
import java.util.Vector;
import java.util.Stack;
import java.lang.Integer;
import ninf.basic.*;
import ninf.metaserver.*;

public class NinfParamDesc {
/***********************   STATIC VARIABLES   ***********************/
  public static final int     MODE_NONE  = 0;
  public   static final int     MODE_IN    = 1;
  public   static final int     MODE_OUT   = 2;
  public   static final int     MODE_INOUT = 3;
  public   static final int     MODE_WORK  = 4;
  public   static final int     MODE_CALL_BACK_FUNC = 8;  /* call back function */
  public   static final int     MODE_INTERNAL = 16;  /* used only in metaserver */

  public   static final int     MAX_DIM = 10;
  public   static final int     MAX_RDIM = 1;


  public boolean IS_IN_MODE()  { return ((param_inout & MODE_IN)  != 0);}
  public boolean IS_OUT_MODE() { return ((param_inout & MODE_OUT) != 0);}
  public boolean IS_WORK_MODE() { return ((param_inout & MODE_WORK) != 0);}
  public boolean IS_INTERNAL() { return ((param_inout & MODE_INTERNAL) != 0);}
  public boolean IS_SCALAR() { return (ndim == 0);}
  public boolean IS_FUNC() {return (param_inout == MODE_CALL_BACK_FUNC);}

  public static final String modeString[] = {
    "NONE", "IN", "OUT", "INOUT", "WORK", "", "", "", 
    "CALLBACK", "", "", "",  "", "", "", "", 
    "INTERNAL"
  };
/*********************** NON STATIC VARIABLES ***********************/
  public int param_type;    /* argument type */
  public int param_inout; 	/* IN/OUT */
  public int ndim; 	/* number of dimension */
  public NinfDimParam dim[];

  NinfLog dbg = new NinfLog(this);


//==============FOR NINF CALC===========================================
  public int nrdim; 	
         /* $B5U8~$-%]%$%s%?$N?t(B
           ($BJ#?t$N9TNs%5%$%:$,F1$8%5%$%:$r;X$7$F$$$k>l9g(B ndim $B$O(B2$B0J>e(B) */
  public NinfRetDimParam rdim[]; /* $B0z?t$NCM$,%5%$%:$H$J$C$F$$$k9TNs(B
                               (calling sequence $B$N9TNs$N$_$N0z?t$N=gHV(B) */



/***********************  INSTANCE  CREATION  ***********************/
  public NinfParamDesc(){
    dim = new NinfDimParam[MAX_DIM];
/** $BIU$1B-$7$?ItJ,(B **  $B$3$3$+$i(B ****/
// $B=i4|@_Dj(B
    rdim = new NinfRetDimParam[MAX_RDIM];
    rdim[0] = new NinfRetDimParam();
    nrdim = MAX_RDIM;
/*****  $B$3$3$^$G(B ****/

  }
  public NinfParamDesc(XDRInputStream istream) throws NinfIOException{
    this();
    try {
      param_type  = istream.readInt();
      param_inout  = istream.readInt();
      ndim  = istream.readInt();
      for (int i = 0; i < Math.abs(ndim); i++){
	dim[i] = new NinfDimParam(istream);
      }
    } catch (IOException e) {
      throw new NinfIOException(e);
    }
  }

  public NinfParamDesc copy(){
    NinfParamDesc tmp = new NinfParamDesc();
    tmp.param_type  = param_type;
    tmp.param_inout  = param_inout;
    tmp.ndim = ndim;
    for (int i = 0; i < Math.abs(ndim); i++)
      tmp.dim[i] = dim[i].copy();
    return tmp;
  }

/***********************     I/O  METHODS     ***********************/

  public void write(XDROutputStream ostream) throws NinfIOException {
    try {
      ostream.writeInt(param_type);
      ostream.writeInt(IS_INTERNAL()? MODE_WORK :param_inout);
      ostream.writeInt(ndim);
      for (int i = 0; i < Math.abs(ndim); i++)
      dim[i].write(ostream);
    } catch (IOException e){
      throw new NinfIOException(e);
    }
  }

  public String toString(){
    String tmp = "  type = " + param_type + ", inout = " + param_inout + ", dim = " + ndim + "\t";
    for (int i = 0; i < Math.abs(ndim); i++)
      tmp = tmp + " " + dim[i];
    return (tmp + "\n");
  }

  String makeVarName(int val){
    return (new Character((char)('A' + val))).toString();
  }

  public String typeString(){
    StringBuffer tmp = new StringBuffer(NinfVal.typeString[param_type]);
    for (int i = Math.abs(ndim) - 1; i >= 0 ; i--)
      tmp.append("[]");
    return tmp.toString();
  }


  public String toText(int val){
    StringBuffer tmp = new StringBuffer(
      FormatString.format("%6s %10s %s",
			  modeString[param_inout],
			  NinfVal.typeString[param_type],
			  makeVarName(val)));

    for (int i = Math.abs(ndim) - 1; i >= 0 ; i--)
      tmp.append(" " + dim[i].toText());
    return tmp.toString();
  }

  // ***********************  NON STATIC METHODS  ***********************

  public void send(BufferObject bo, NinfPacketOutputStream os) throws NinfIOException {
    dbg.println(" sending data:"+ bo.data.length);
    if (bo.rsc != null)
      return;
    if (ndim < 0)
      for (int i = 0; i < Math.abs(ndim); i++)
	os.writeInt(bo.sizes[i]);
    os.write(bo.data);
  }


  void  readStringsRec(int d_index, ArrayShape shape, XDROutputStream os, XDRInputStream is)
  throws NinfException {
    d_index--;
    int start = shape.dim[d_index].start;
    int end   = shape.dim[d_index].end;
    int step  = shape.dim[d_index].step;
    int size  = shape.dim[d_index].size;
    
    if (d_index == 0){
      for (int i = start; i < end; i+= step){
	try {
	  os.writeString(is.readString());
	} catch (IOException e){
	  throw new NinfIOException(e);
	}
      }
    } else {
      for (int i = start; i < end; i+= step){
	readStringsRec(d_index, shape, os, is);
      }
    }
  }

  void readStrings(ArrayShape shape, BufferObject bo, XDRInputStream is) 
    throws NinfException{
    ByteArrayOutputStream bs = new ByteArrayOutputStream();
    XDROutputStream os = new XDROutputStream(bs);
    if (ndim == 0) {
      try {
	os.writeString(is.readString());
      } catch (IOException e){
	throw new NinfIOException(e);
      }
    } else 
      readStringsRec(Math.abs(ndim), shape, os, is);
    bo.data = bs.toByteArray();
  }

  public void read(ArrayShape shape, BufferObject bo, 
		   XDRInputStream is) throws NinfException{
    try {
      dbg.println(" reading data:"+ bo.data.length);
      int total = 1;
      
      if (bo.rsc != null) return;
      if (param_type == NinfVal.STRING_TYPE ||
	  param_type == NinfVal.FILEPOINTER ||
	  param_type == NinfVal.FILENAME ){
	readStrings(shape, bo, is);
	return;
      }
      if (ndim < 0){
	bo.sizes = new int[Math.abs(ndim)];
	for (int i = 0; i < Math.abs(ndim); i++){
	  bo.sizes[i] = is.readInt();
	  total *= bo.sizes[i];
	}
	bo.data = new byte[total* NinfVal.DATA_TYPE_SIZE[param_type]];
      }
      is.read(bo.data);
    } catch (IOException e){
      throw new NinfIOException(e);
    }

    //    for (int i = 0; i < bo.data.length; i++)
    //      System.out.println(bo.data[i] + " " + (char)bo.data[i]);

  }

  public int scalarArg(Object o) throws NinfException{
    if (IS_IN_MODE() && ndim == 0){
      switch (param_type){
      case NinfVal.CHAR:
      case NinfVal.UNSIGNED_CHAR:
	return (int)(((Byte)o).byteValue());
      case NinfVal.SHORT:
      case NinfVal.UNSIGNED_SHORT:
	return (int)(((Short)o).shortValue());
      case NinfVal.INT:
      case NinfVal.UNSIGNED:
      case NinfVal.LONG:
      case NinfVal.UNSIGNED_LONG:
	return ((Integer)o).intValue();
	
      case NinfVal.UNSIGNED_LONGLONG:
      case NinfVal.LONGLONG:
	return (int)(((Long)o).longValue());
      case NinfVal.FLOAT:
	return (int)(((Float)o).floatValue());
	
      case NinfVal.DOUBLE:
	return (int)(((Double)o).doubleValue());
	
      case NinfVal.STRING_TYPE:
      case NinfVal.FILEPOINTER:
      case NinfVal.FILENAME:
	return 0;
      case NinfVal.LONG_DOUBLE:
	dbg.log("not supported data types");
	throw new NinfErrorException(NinfError.NINF_INTERNAL_ERROR);
      default:
	dbg.log("unknown data type");
	throw new NinfErrorException(NinfError.NINF_INTERNAL_ERROR);
      }
    }
    return -100;
  }

  public int scalarBuffer(BufferObject bo) throws NinfException{
    byte buf[] = bo.data;

    long tmp = 0;
    int i;
    if (IS_IN_MODE() && ndim == 0){
      switch (param_type){
      case NinfVal.CHAR:
      case NinfVal.UNSIGNED_CHAR:
	return (int)buf[0];
      case NinfVal.SHORT:
      case NinfVal.UNSIGNED_SHORT:
	for (i = 0; i < 2; i++)
	  tmp = (tmp << 8) + (0xff & buf[i]);
	return (int)tmp;
      case NinfVal.INT:
      case NinfVal.UNSIGNED:
      case NinfVal.LONG:
      case NinfVal.UNSIGNED_LONG:
	for (i = 0; i < 4; i++)
	  tmp = (tmp << 8) + (0xff & buf[i]);
	return (int)tmp;
      case NinfVal.UNSIGNED_LONGLONG:
      case NinfVal.LONGLONG:
	for (i = 0; i < 8; i++)
	  tmp = (tmp << 8) + (0xff & buf[i]);
	return (int)tmp;
      case NinfVal.FLOAT:
	for (i = 0; i < 4; i++)
	  tmp = (tmp << 8) + (0xff & buf[i]);
	return (int)(Float.intBitsToFloat((int)tmp));
      case NinfVal.DOUBLE:
	for (i = 0; i < 8; i++)
	  tmp = (tmp << 8) + (0xff & buf[i]);
	return (int)(Double.longBitsToDouble(tmp));
      case NinfVal.STRING_TYPE:
      case NinfVal.FILEPOINTER:
      case NinfVal.FILENAME:
	return 0;
      case NinfVal.LONG_DOUBLE:
	dbg.log("not supported data types");
	throw new NinfErrorException(NinfError.NINF_INTERNAL_ERROR);
      default:
	dbg.log("unknown data type");
	throw new NinfErrorException(NinfError.NINF_INTERNAL_ERROR);
      }
    }
    return -100;
  }

  public BufferObject transformArg(Object o, ArrayShape shape) 
  throws NinfException{
    return transformArg(o, shape, false);
  }

  public BufferObject transformArg(Object o, ArrayShape shape, boolean isCallback) 
  throws NinfException{
    dbg.println("arg :" + o);
    if (IS_FUNC()){
      return new BufferObject(0);
    } else if (param_type != NinfVal.STRING_TYPE &&
	       param_type != NinfVal.FILENAME &&
	       o instanceof String){
      return new BufferObject((String)(o));
    } else if (ndim == 0){
      byte[] tmp = transformArgScalar(o);
      // for (int i = 0; i < tmp.length; i++)
      // dbg.println("tmp["+i+"] = "+tmp[i]);
      return new BufferObject(tmp, null);
    }
    else
      return transformArgVector(o, shape, isCallback);
  }

  void transformArgVectorRec(Object o, int d_index, XDRBuffer xs, DataAccess access,
			     ArrayShape shape)
  throws NinfException {
    d_index--;
    
    int start = shape.dim[d_index].start;
    int end   = shape.dim[d_index].end;
    int step  = shape.dim[d_index].step;
    int size  = shape.dim[d_index].size;
    int i = 0;
    int array_len = 0;
    try {
      if (d_index == 0){
	for (i = start; i < end; i+= step){
	  array_len = access.length(o);
	  access.access(o, i, xs);
	} 
      } else {
	for (i = start; i < end; i+= step){
	  Object[] tmpArray = (Object[])o;
	  array_len = tmpArray.length;
	  transformArgVectorRec(tmpArray[i], d_index, xs, access, shape);
	}
      }	
    } catch (ArrayIndexOutOfBoundsException e){
	throw new NinfArgSizeException(array_len, i, d_index);
    }
  }

  public BufferObject transformArgVector(Object o, ArrayShape shape, boolean isCallback)
  throws NinfException{
    int data_size = NinfVal.DATA_TYPE_SIZE[param_type];
    int sizes[] = new int[Math.abs(ndim)];
    BufferObject bo = setupBuffer(shape);
    if (!IS_IN_MODE() && !isCallback)
      return bo;
    /*
    int size = countSize(shape, sizes) * data_size;
    dbg.println("size = " + size);
    */
    XDRBuffer xs = new XDRBuffer(bo.data);
    DataAccess access = DataAccess.getAccess(param_type);
    transformArgVectorRec(o, Math.abs(ndim), xs, access, shape);
    bo.data = xs.getBuf();
    return bo;
  }

  void  revtransformArgVectorRec(Object o, int d_index, XDRBuffer xs, 
				 DataAccess access, ArrayShape shape)
  throws NinfException {
    d_index--;
    
    int start = shape.dim[d_index].start;
    int end   = shape.dim[d_index].end;
    int step  = shape.dim[d_index].step;
    int size  = shape.dim[d_index].size;
    
    int i = 0;
    int array_len = 0;
    try {
      if (d_index == 0){
	for (i = start; i < end; i+= step){
	  array_len = access.length(o);
	  access.read(o, i, xs);
	}
      } else {
	if (param_type != NinfVal.STRING_TYPE && o instanceof String)
	  return;
	for (i = start; i < end; i+= step){
	  Object[] tmpArray = (Object[])o;
	  array_len = tmpArray.length;
	  revtransformArgVectorRec(tmpArray[i], d_index, xs, access, shape);
	}
      }
    } catch (ArrayIndexOutOfBoundsException e){
	throw new NinfArgSizeException(array_len, i, d_index);
    }
  }

  void reverseTransform(BufferObject bo, ArrayShape shape, Object o)
  throws NinfException{
    if (bo.rsc != null) return;  /* the argument is specified by URL */
    /*    if (bo.sizes != null)
          countSizeWithSize(context, bo.sizes);
    else {
      int sizes[] = new int[Math.abs(ndim)];
      countSize(iarg, sizes);
    }*/

    byte transed[] = bo.data;
    XDRBuffer xs = new XDRBuffer(transed);

    DataAccess access = DataAccess.getAccess(param_type);
    if (ndim == 0)
	revtransformScalar(o, xs, access);
    else
	revtransformArgVectorRec(o, Math.abs(ndim), xs, access, shape);
  }


  void revtransformScalar(Object o, XDRBuffer xs, DataAccess access) 
  throws NinfException{
      access.read(o, 0, xs);
  }

  int setupBufferRec(int d_index, ArrayShape shape, int sizes[])
  throws NinfException {
    d_index--;
    
    int start = shape.dim[d_index].start;
    int end   = shape.dim[d_index].end;
    int step  = shape.dim[d_index].step;
    int size  = shape.dim[d_index].size;
    
    int tmp = 0;
    for (int i = start; i < end; i+= step)
      tmp ++;

    sizes[d_index] = tmp;
    if (d_index == 0){
      return tmp;
    } else {
      return setupBufferRec(d_index, shape, sizes) * tmp;
    }
  }
  
  ArrayShape setupArrayShape(int iargs[]) throws NinfException{
    ArrayShape tmp = new ArrayShape(Math.abs(ndim));
    for (int i = 0; i < ndim; i++)
      tmp.dim[i] = dim[i].setupArrayShape(iargs);
    return tmp;
  }

  public long getSize(ArrayShape shape) throws NinfException{
      int data_size = NinfVal.DATA_TYPE_SIZE[param_type];
      int sizes[] = new int[Math.abs(ndim)];
      return countSize(shape, sizes) * data_size;
  }

  public BufferObject setupBuffer(ArrayShape shape) throws NinfException{
    int size = 0;
    int data_size = 0;
    if (IS_WORK_MODE())
      return new BufferObject(0);
    if (IS_FUNC())
      return new BufferObject(0);
    if (ndim < 0)
      return new BufferObject();
    data_size = NinfVal.DATA_TYPE_SIZE[param_type];
    int sizes[] = new int[Math.abs(ndim)];
    size = countSize(shape, sizes) * data_size;
    if (param_type == NinfVal.CHAR  || param_type == NinfVal.UNSIGNED_CHAR ||
	param_type == NinfVal.SHORT || param_type == NinfVal.UNSIGNED_SHORT)
      size += (4 - size % 4) % 4;   /* alignment for XDR convension */
    return new BufferObject(size, sizes);
  }

  public Object setupArg(ArrayShape shape) throws NinfException{
    DataAccess access = DataAccess.getAccess(param_type);
    /*    int sizes[] = new int[Math.abs(ndim)];
    int size = countSize(shape, sizes); */
    return access.setupArg(shape);
  }


  public int countSize(ArrayShape shape, int sizes[])
  throws NinfException{
    if (ndim < 0)
      return 0;
    return setupBufferRec(ndim, shape, sizes);
  }

  public int countSizeWithSize(ArrayShape shape, int sizes[])
  throws NinfException{
    return setupBufferRec(Math.abs(ndim), shape, sizes);
  }

  public BufferObject setupScalarBuffer(){
    int size = NinfVal.DATA_TYPE_SIZE[param_type];
    int padding = 4;
    size += (padding - (size % padding)) % padding;
    dbg.println("alloc scalar buffer " + size + "bytes");
    return new BufferObject(size);
  }

  public byte[] transformArgScalar(Object o) throws NinfException{
    ByteArrayOutputStream bs = new ByteArrayOutputStream();
    XDROutputStream xs = new  XDROutputStream(bs);
    byte tmp[];
    try {
      switch (param_type){
      case NinfVal.CHAR:
      case NinfVal.UNSIGNED_CHAR:
	xs.writeByte((byte)(((Byte)o).byteValue()));
	for (int i = 0; i < 3; i++)  /* padding */
	  xs.writeByte((byte)0);
	return bs.toByteArray();
      case NinfVal.SHORT:
      case NinfVal.UNSIGNED_SHORT:
	xs.writeShort((short)(((Short)o).shortValue()));
	for (int i = 0; i < 2; i++)  /* padding */
	  xs.writeByte((byte)0);
	return bs.toByteArray();
      case NinfVal.INT:
      case NinfVal.UNSIGNED:
      case NinfVal.LONG:
      case NinfVal.UNSIGNED_LONG:
	xs.writeInt((int)(((Integer)o).intValue()));
	return bs.toByteArray();
      case NinfVal.LONG_DOUBLE:
      case NinfVal.UNSIGNED_LONGLONG:
	xs.writeLong((((Long)o).longValue()));
	return bs.toByteArray();
      case NinfVal.FLOAT:
	xs.writeFloat(((Float)o).floatValue());
	return bs.toByteArray();
      case NinfVal.DOUBLE:
	xs.writeDouble(((Double)o).doubleValue());
	return bs.toByteArray();
      case NinfVal.STRING_TYPE:
	xs.writeString((String)o);
	return bs.toByteArray();
      case NinfVal.FILEPOINTER:
	if (IS_IN_MODE())
	    streamWriteTo((InputStream)o, xs);
	return bs.toByteArray();
      case NinfVal.FILENAME:
	if (IS_IN_MODE())
	    fileWriteTo((String)o, xs);
	return bs.toByteArray();
      case NinfVal.LONGLONG:
	dbg.log("not supported data types");
	throw new NinfErrorException(NinfError.NINF_INTERNAL_ERROR);
      default:
	dbg.log("unknown data type");
	throw new NinfErrorException(NinfError.NINF_INTERNAL_ERROR);
      }
    } catch (IOException e){
	e.printStackTrace();
      throw new NinfErrorException(NinfError.NINF_INTERNAL_ERROR);
    }
  }


  public void shift(int sh){
    for (int i = 0; i < ndim; i++)
      dim[i].shift(sh);
  }

  public void modify(DependInfo info){
    //    System.out.print("modify" + info);
    //    System.out.println("  " + info.isNoLower() + ", " + info.isNoUpper());
    if ((!info.isNoLower()) || (!info.isNoUpper()))
      param_inout |= MODE_INTERNAL;
  }

  public void setInternal(){
    param_inout |= MODE_INTERNAL;
  }

  void fileWriteTo(String filename,  XDROutputStream out) throws IOException{
      FileInputStream is = new FileInputStream(filename);
      streamWriteTo(is, out);
  }

    /** isnot used */
  void fileReadFrom(String filename, XDRInputStream in) throws IOException{
      FileOutputStream os = new FileOutputStream(filename);
      streamReadFrom(os, in);
  }


  void streamWriteTo(InputStream in, XDROutputStream out) throws IOException{
    int size = in.available();
    out.writeInt(size);
    byte [] buffer = new byte[10000];
    int readed = 0;
    int XDRLIMIT = 4;

    int rest = size % XDRLIMIT;
    rest = (rest != 0)? XDRLIMIT - rest: rest;

    while (readed < size){
      int reading = in.read(buffer);
      if (reading < 0)
	  throw new IOException();
      out.write(buffer, 0, reading);
      readed += reading;
    }
    out.writePad(rest);
  }    

    /** isnot used */
  void streamReadFrom(OutputStream out, XDRInputStream in) 
   throws IOException{
    int size = in.readInt();
    byte [] buffer = new byte[10000];
    int readed = 0;
    while (readed < size){
      int reading = Math.min(size - readed, buffer.length);
      reading = in.read(buffer, 0, reading);
      if (reading < 0)
	  throw new IOException();
      out.write(buffer, 0, reading);
      readed += reading;
    }
  }    


//================== << $B%a%=%C%I$NDI2C(B -- $B#1#48D(B -- >> =======================
// $B<!85?t$,(B 0 $B$G$"$k$+$I$&$+!JG[Ns$G$"$k$+$I$&$+!K(B
  public boolean IS_DIM_SIZE() { return (ndim == 0 && rdim[0].mat > 0);}

// size $B$,(B $B!V(BVALUE_IN_ARG$B!W!J0z?t$K$h$jM?$($i$l$k!K$+$I$&$+(B
  public boolean IS_DIM_SIZE_VALUE_IN_ARG(int i){
    return dim[i].IS_SIZE_VALUE_IN_ARG();
  }

// end $B$,(B $B!V(BVALUE_IN_ARG$B!W!J0z?t$K$h$jM?$($i$l$k!K$+$I$&$+(B
  public boolean IS_DIM_END_VALUE_IN_ARG(int i){
    return dim[i].IS_END_VALUE_IN_ARG();
  }

// size $B$,(B $B!V(BVALUE_CONST$B!W!JDj?t!K$+$I$&$+(B
  public boolean IS_DIM_SIZE_VALUE_CONST(int i){
    return dim[i].IS_SIZE_VALUE_CONST();
  }

// end $B$,(B $B!V(BVALUE_CONST$B!W!JDj?t!K$+$I$&$+(B
  public boolean IS_DIM_END_VALUE_CONST(int i){
    return dim[i].IS_END_VALUE_CONST();
  }

// end $B$,5-=R$5$l$F$$$k$+$I$&$+(B
  public boolean IS_DIM_END_TYPE(int i){
    return dim[i].IS_END_TYPE();
  }

// $B0z?t$N(B i $BHVL\$N(B size $B$NCM$rF@$k(B
  public int getDimSize(int i){
    return dim[i].getSizeVal();
  }

// $B0z?t$N(B i $BHVL\$N(B end $B$NCM$rF@$k(B
  public int getDimEnd(int i){
    return dim[i].getEndVal();
  }

// $B!V9TNs%5%$%:$r<($90z?t(B $B"*(B $B9TNs!W$N8!:w%]%$%s%?$r$D$1$k(B 
  public void inputRdim(int mat, int size){
    if(rdim[nrdim -1].IS_MAT()){
       nrdim++;
       NinfRetDimParam[] tmp = new NinfRetDimParam[nrdim];
       for(int i = 0; i < nrdim -1; i++){
          tmp[i] = rdim[i].copy();
       }
       tmp[nrdim -1] = new NinfRetDimParam(mat, size);
       rdim = tmp;
       return;
    }else{
       rdim[nrdim -1].putInfo(mat, size);
       return;
    }
  }

// $B0z?t$,5U8~$-8!:w%]%$%s%?$r;}$C$F$$$k$+(B
  public boolean IS_RDIM(){ return rdim[0].IS_MAT();}

// $B0z?t$,I=$9%5%$%:$O(B $B9TNs$N#1<!85$N%5%$%:$+(B
  public boolean IS_RDIM_SIZE_X(int i){
    return rdim[i].IS_SIZE_X();
  }

// $B0z?t$,I=$9%5%$%:$O(B $B9TNs$N#2<!85$N%5%$%:$+(B
  public boolean IS_RDIM_SIZE_Y(int i){
    return rdim[i].IS_SIZE_Y();
  }

// $B0z?t$,I=$99TNs$N=gHV!J(Bcalling sequence $B$N9TNs$N$_$N0z?t$N=gHV!K(B
  public int getRdimMatIndex(int i){
    return rdim[i].mat;
  }

// $B0z?t$,I=$99TNs%5%$%:$N<!85(B
  public int getRdimDim(int i){
    return rdim[i].dim;
  }



}
