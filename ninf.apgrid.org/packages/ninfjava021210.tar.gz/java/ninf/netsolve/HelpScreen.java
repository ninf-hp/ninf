package ninf.netsolve;
import java.awt.*;

public class HelpScreen extends Frame{
  private List topic_list;
  private Button  close_button;
  private TextArea message;
  private String [] help_topics, help_strings;
  public int cur_lang = Labels.language;

  public HelpScreen() {
    super("NetSolve Help");

    Color default_color = new Color(190,190,190);
    Font default_font = new Font("TimesRoman",Font.BOLD,12);
    int default_height = 20;
    int default_width = 70;
    HelpText htext;
    int i;

    htext = new HelpText();
    help_topics = htext.get_topics();
    help_strings = htext.get_help_text();

    this.setLayout(new BorderLayout(5,5));
    this.setBackground(default_color);

    topic_list = new List(15,false);
    for(i=0;i<help_topics.length;i++)
      topic_list.addItem(help_topics[i]);

    Panel p1 = new Panel();
    p1.setLayout(new FlowLayout(FlowLayout.CENTER,15,15));
    close_button = new Button(Labels.close[cur_lang]);
    close_button.setFont(new Font("TimesRoman",Font.BOLD,12));
    p1.add(close_button);

    message = new TextArea(default_height,default_width);
    message.setFont(default_font);
    message.setEditable(false);

    Panel p2 = new Panel();
    // p2.setLayout(new GridLayout(1,1,5,5));
    p2.setLayout(new FlowLayout(FlowLayout.CENTER,5,5));
    p2.add(topic_list);
    p2.resize(100,200);
 
    Panel p3 = new Panel();
    p3.setLayout(new FlowLayout(FlowLayout.CENTER,5,5));
    p3.add(message);

    this.add("West",p2);
    this.add("East",p3);
    this.add("South",p1);

    this.show();
    this.pack();
  }

  public boolean handleEvent(Event e) {
 
    switch(e.id) {
      case Event.ACTION_EVENT:
        if (e.target == close_button) {
          this.hide();
          this.dispose(); 
          return true;
        }
        break;
      case Event.LIST_SELECT:
        if (e.target == topic_list) {
          int selected = topic_list.getSelectedIndex();
          message.setText(help_strings[selected]);
          return true;
        }
        break;
      default:
        return super.handleEvent(e);
    }
    return false;
  }
}
