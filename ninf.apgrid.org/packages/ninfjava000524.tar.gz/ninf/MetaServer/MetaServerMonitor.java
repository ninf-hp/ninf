// MetaServerMonitor.java
/*
<applet  code=ninf.MetaServer.MetaServerMonitor.class   width=600 height=350>  
<param name=server value="etlwiz">
<param name=port value="3035">

</applet>
*/

package ninf.MetaServer;
import ninf.basic.*;
import ninf.client.*;


import java.applet.*;
import java.awt.*;
import java.io.IOException;
import java.util.Vector;
import java.net.InetAddress;
import java.net.UnknownHostException;

class MonitorCallBack extends NServer {
  MetaServerMonitor monitor = null;

  MonitorCallBack(MetaServerMonitor mon) {
    super();
    monitor = mon;
  }
  public void serviceRequest() {
    XDRInputStream is =  new XDRInputStream(clientInput);
    try {
      monitor.getPacketFromMetaServer(is);
    } catch(NinfException e) {
      monitor.metaInfo = null;
    }
    monitor.repaint();
  }
}

public class MetaServerMonitor extends Applet {
  Vector metaInfo = null;

  NinfServerStruct mServer = null;
  TextField hostField = null;
  List sList = null;
  Checkbox cBox = null;
  Button btnContact;
  MonitorCallBack callback = null;

  String myname = null;
  int myport;

  public MetaServerMonitor() {
    NinfLog.quiet(); // disable debug message

    try {
      myname = InetAddress.getLocalHost().getHostName();
    } catch(UnknownHostException e) {
      myname = null;
    }
    myport = 3002;
  }

  public void init() {
    String host = getParameter("server");
    int port    = Integer.valueOf(getParameter("port")).intValue();
    mServer = new NinfServerStruct(host, port);

    GridBagLayout l = new GridBagLayout();
    GridBagConstraints c = new GridBagConstraints();
    btnContact = null;

    setLayout(l);

    hostField = new TextField(mServer.toString());
    c.fill = GridBagConstraints.BOTH;
    c.weightx = 1.0;
    c.gridwidth = 3;
    l.setConstraints(hostField, c);
    add(hostField);

    cBox = new Checkbox("active");
    c.gridwidth = 2;
    l.setConstraints(cBox, c);
    add(cBox);

    btnContact = new Button("Contact");
    c.weightx = 0.0;
    c.gridwidth = GridBagConstraints.REMAINDER;
    l.setConstraints(btnContact, c);
    add(btnContact);

    sList = new List(5, false);
    c.weightx = 0.0;
    c.weighty = 1.0;
    c.gridwidth = GridBagConstraints.REMAINDER;
    l.setConstraints(sList, c);
    add(sList);

    sList.addItem("Not connected yet. Press 'Contact' button.");
  }

  public void start() {
    repaint();
    //if (callback != null) callback.start();
  }

  public void stop() {
    //if (callback != null) callback.stop();
  }

  public void destroy() {
    callback = null;
  }

  public boolean handleEvent(Event evt) {
    boolean ret = false;
    if ("Contact".equals(evt.arg)) {
      sList.clear();
      try {
	contactMetaServer(mServer, cBox.getState()); // for security reason
	//contactMetaServer(mServer, false);
	if (metaInfo != null) {
	  for (int i = 0; i < metaInfo.size(); i++) {
	    sList.addItem((String)(metaInfo.elementAt(i)));
	  }
	}
	repaint();
      } catch(NinfException e) {
	sList.addItem("Can't connect (maybe MetaServer is down)");
      }
      ret = true; // handled this 'evt'
    }
    return ret;
  }
  
  // ---------------------------------------
  // -- MetaServerMonitor Specifc  method --
  // ---------------------------------------

  void invokeCallbackThread() {
    if (callback != null) return;
    callback = new MonitorCallBack(this);
    callback.startServer(myport);
  }

  void contactMetaServer(NinfServerStruct srv, boolean bActive)
    throws NinfException {
    NinfServerConnection con;
    con = new NinfServerConnection(srv, 1);
    
    // prepare callback
    if (bActive) {
      if (myname == null) bActive = false;
      else invokeCallbackThread();
    }

    // request MetaServer information to srv
    NinfPacketOutputStream pos =
      new NinfPacketOutputStream(con.os,
				 NinfPktHeader.NINF_DUMP_MS_INFO,
				 15,
				 bActive ? 1 : 0);
    if (bActive) {
      pos.writeString(myname);
      pos.writeInt(myport);
    }
    pos.flush();
    try {
      getPacketFromMetaServer(con.is);
    } catch(NinfIOException e) {
      metaInfo=null;
    }
    pos.close();
    con.close();
  }

  void getPacketFromMetaServer(XDRInputStream is) throws NinfException {
    // get reply from MetaServer
    NinfPacket pkt = new NinfPacket(is);
    NinfPacketInputStream pis = new NinfPacketInputStream(pkt, is);
    
    String h;
    int p;
    int i;
    int load;
    int num;
    String s;
    int kind = pkt.hdr.arg1;
    metaInfo = new Vector();
    
    if ((kind & 1) != 0) {
      num = pis.readInt();
      s = "MetaServer: " + num;
      metaInfo.addElement(s);
      for (i = 0; i < num; i++) {
	h = pis.readString();
	p = pis.readInt();
	s = "  >" + h + ":" + p;
	metaInfo.addElement(s);
      }
    }
    
    if ((kind & 2) != 0) {
      num = pis.readInt();
      s = "NinfServer: " + num;
      metaInfo.addElement(s);
      for (i = 0; i < num; i++) {
	h = pis.readString();
	p = pis.readInt();
	load = pis.readInt();
	s = " >" + h + ":" + p +"  load:" +load;
	metaInfo.addElement(s);
      }
    }
    
    if ((kind & 4) != 0) {
      num = pis.readInt();
      s = "stub: " + num;
      metaInfo.addElement(s);
      for (i = 0; i < num; i++) {
	s = "  >" + pis.readString();
	metaInfo.addElement(s);
      }
    }
    
    if ((kind & 8) != 0) {
      num = pis.readInt();
      s = "requester: " + num;
      metaInfo.addElement(s);
      for (i = 0; i < num; i++) {
	h = pis.readString();
	p = pis.readInt();
	s = " >" + h + ":" + p;
	metaInfo.addElement(s);
      }
    }
  }
}

// end of MetaServerMonitor.java
