#define _WRAPPER_
/* $Id: pdggqrf_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define DOUBLE
#include <gscalapack.h>

#define ROW_a lda
#define COL_a m

#define ROW_b ldb 
#define COL_b p

static	int worklen(int m, int n, int p) {
	  int ret=1;
	  int IROFFA, ICOFFA, IAROW, IACOL, NpA0, MqA0, IROFFB, ICOFFB;
	  int IBROW, IBCOL, NpB0, PqB0;
#define IA 1
#define JA 1
#define MB_A rbloc
#define NB_A cbloc
#define MYROW myprow
#define MYCOL mypcol
#define NPROW nprow
#define NPCOL npcol
#define RSRC_A 0
#define CSRC_A 0
#define IB 1
#define JB 1
#define MB_B rbloc
#define NB_B cbloc
	  ret =  max( max( n * ( n + m + n ),
		      max( (n*(n-1))/2, (p + n)*n ) +
		      n * n) ,
		      m * ( n + p + m ) );
	  if NEED_BUFF {
	    IROFFA = MOD( IA-1, MB_A );
	    ICOFFA = MOD( JA-1, NB_A );
	    IAROW  = INDXG2P( IA, MB_A, MYROW, RSRC_A, NPROW );
	    IACOL  = INDXG2P( JA, NB_A, MYCOL, CSRC_A, NPCOL );
	    NpA0   = NUMROC( N+IROFFA, MB_A, MYROW, IAROW, NPROW );
	    MqA0   = NUMROC( M+ICOFFA, NB_A, MYCOL, IACOL, NPCOL );
	    IROFFB = MOD( IB-1, MB_B );
	    ICOFFB = MOD( JB-1, NB_B );
	    IBROW  = INDXG2P( IB, MB_B, MYROW, RSRC_B, NPROW );
	    IBCOL  = INDXG2P( JB, NB_B, MYCOL, CSRC_B, NPCOL );
	    NpB0   = NUMROC( N+IROFFB, MB_B, MYROW, IBROW, NPROW );
	    PqB0   = NUMROC( p+ICOFFB, NB_B, MYCOL, IBCOL, NPCOL );
	    ret =  MAX( max(NB_A * ( NpA0 + MqA0 + NB_A ),
			MAX( (NB_A*(NB_A-1))/2, (PqB0 + NpB0)*NB_A ) +
			NB_A * NB_A),
			MB_B * ( NpB0 + PqB0 + MB_B ) );
	  }
	    return ret;
}

void  pdggqrf_ninf(	 int n,
		 int m,
		 int p,
		 double global_a[],
		 int lda,
		 double global_taua[],
		 double global_b[],
		 int ldb,
		 double global_taub[],
		 double work[],
		 int lwork,
		 int *info
)
/* "pdggqrf computes a generalized QR factorization of an N-by-M matrix A and an N-by-P matrix B:\\n\\n              A = Q*R,         B = Q*T*Z,\\n\\n  where Q is an N-by-N orthogonal matrix, Z is a P-by-P orthogonal  matrix, and R and T assume one of the forms:\\n\\n  if N >= M,  R = ( R11 ) M  ,   or if N < M,  R = ( R11  R12 ) N,\\n                  (  0  ) N-M                         N   M-N\\n                     M\\n\\n  where R11 is upper triangular, and\\n\\n  if N <= P,  T = ( 0  T12 ) N,   or if N > P,  T = ( T11 ) N-P,\\n                   P-N  N                           ( T21 ) P\\n                                                       P\\n\\n  where T12 or T21 is upper triangular." */
/* OPTIONS */
{
    extern void FortranCall(pdggqrf)( int*, int*, int*,
				      double*, int*, int*, int*,
				      double*,
				      double*, int*, int*, int*,
				      double*,
				      double*, int*,
				      int*);

	int maxldd;

	int maxlda;
	double *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
	int row_loca, col_loca;

	int maxldb;
	double *locb=NULL;
	int descb[DESCLEN];
	int desc_gb[DESCLEN];
	int row_locb, col_locb;

	double *loctaua=NULL;
	double *loctaub=NULL;

	double *locwork=NULL;
	int llocwork;


	INITIALIZE();

	SCALAR( "int", n);
	SCALAR( "int", m);
	SCALAR( "int", p);
	SCALAR( "int", lda);
	SCALAR( "int", ldb);
	SCALAR( "int", lwork);

	ROW( a);
	COL( a);
	ROW( b);
	COL( b);
	MAXLDD( maxldd, a );
	maxlda = maxldd;
	maxldb = maxldd;

	MATRIX( "double", a, ROW_a, COL_a);
	MATRIX( "double", b, ROW_b, COL_b);
	VECTOR("c", "double",taua, min(m,n));
	VECTOR("r", "double",taub,n);
	DISTRIBUTE( "double", a, ROW_a  , COL_a);
	DISTRIBUTE( "double", b, ROW_b  , COL_b);

        llocwork = worklen(m,n,p);
	llocwork=max(lwork,llocwork);
	WORK(locwork,llocwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pdggqrf)( &n, &m, &p,
                               loca, &one, &one, desca,
                               loctaua,
                               locb, &one, &one, descb,
                               loctaub,
                               locwork, &llocwork, &linfo);

	GATHER( "double", a, ROW_a  , COL_a);
	GATHER( "double", b, ROW_b  , COL_b);
	vGATHER( "c","double", taua, min(n,m));
	vGATHER("r", "double", taub, n);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
		*info = linfo;
	} else {
	}

	FREE_MATRIX(a);
	FREE_MATRIX(taua);
	FREE_MATRIX(b);
	FREE_MATRIX(taub);
        FREE(locwork);
}

