#ifndef _NINF_SSL_H_
#define _NINF_SSL_H_
#ifdef  SSL_USE
#include <ssl.h>


/** make new SSL_CTX using files */
SSL_CTX * ninf_client_new_ssl_ctx(char * certfile , char * keyfile);

/** make new SSL_CTX using files */
SSL_CTX * ninf_server_new_ssl_ctx(char * certfile , char * keyfile, 
				  char * cafile);

void init_ssl();

/** return certfile name considering default */
char * ninf_client_ssl_cert_file(char * cert);
char * ninf_client_ssl_key_file(char * key);

/** do ssl_connect */
int ninf_ssl_connect(connection * con);

/** do ssl_accept */
int ninf_ssl_accept(connection * con);



#endif
#endif
