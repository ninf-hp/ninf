#define _WRAPPER_
/* $Id: pdgetrs_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define DOUBLE
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n
#define ROW_b ldb
#define COL_b nrhs
void  pdgetrs_ninf(	 char trans,
		 int n,
		 int nrhs,
		 double global_a[],
		 int lda,
		 int global_ipiv[],
		 double global_b[],
		 int ldb,
		 int *info
)
/* "pdgetrs solves a system of distributed linear equations op( A ) * X =  B with a general N-by-N distributed matrix A using the LU factorization computed by PSGETRF." */
/* OPTIONS */
{
extern void FortranCall(pdgetrs)( char*, int*, int*,
                               double*, int*, int*, int*,
                               int*,
                               double*, int*, int*, int*,
                               int*);

	int maxldd;

	int maxlda;
	double *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
	int row_loca, col_loca;

	int maxldb;
	double *locb=NULL;
	int descb[DESCLEN];
	int desc_gb[DESCLEN];
	int row_locb, col_locb;

	int *locipiv=NULL;

	INITIALIZE();

	SCALAR( "char", trans);
	SCALAR( "int", n);
	SCALAR( "int", nrhs);
	SCALAR( "int", lda);
	SCALAR( "int", ldb);
	
	ROW( a);
	COL( a);
	ROW( b);
	COL( b);
	MAXLDD( maxldd, a );
	maxlda = maxldd;
	maxldb = maxldd;

	MATRIX( "double", a, ROW_a, COL_a);
	MATRIX( "double", b, ROW_b, COL_b);
	VECTOR( "r", "int", ipiv, ROW_a);
	DISTRIBUTE( "double", a, ROW_a  , COL_a);
	DISTRIBUTE( "double", b, ROW_b  , COL_b);
	vDISTRIBUTE( "r", "int", ipiv, ROW_a);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pdgetrs)( &trans, &n, &nrhs,
                               loca, &one, &one, desca,
                               locipiv,
                               locb, &one, &one, descb,
                               &linfo);

	GATHER( "double", b, ROW_b, COL_b);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
		*info = linfo;
	} else {
	}

	FREE_MATRIX(a);
	FREE_MATRIX(b);
        FREE_VECTOR(ipiv);
}

