package jp.go.aist.gtrc.util;

public class SchemaInfo {
	String nsPrefix;
	String nsURL;
	String location;

	public SchemaInfo(String nsPrefix, String nsURL) {
		this.nsPrefix = nsPrefix;
		this.nsURL = nsURL;
	}

	public SchemaInfo(String nsPrefix, String nsURL, String location) {
		this(nsPrefix, nsURL);
		this.location = location;
	}
}
