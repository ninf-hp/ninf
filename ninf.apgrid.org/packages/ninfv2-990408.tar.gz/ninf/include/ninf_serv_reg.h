/* 
 * ninf_sever register process 
 */
#include "ninf_stub_info.h"

#ifndef __NINF_SERV_REG_H__
#define __NINF_SERV_REG_H__

#define MAX_REG_ENTRY_STUB	0x100	/* 256 entries */

#define NINF_REGISTER_SOCK_NAME	"/tmp/ninf.register%d"

#define NINF_REG_END		0
#define NINF_REG_ENTER_STUB	1
#define NINF_REG_REMOVE_STUB	2
#define NINF_REG_DUMP    	3
#define NINF_REG_DUMP_ANS    	4
#define NINF_REG_DUMP_ANS_END  	5
#define NINF_REG_STOP		0xFF

/* reply code */
#define NINF_REG_OK	0
#define NINF_REG_ERROR	(-1)

#define NINF_REG_PKT_SIZE	1024	/* 1K bytes */

struct ninf_reg_packet
{
    int code;	/* NINF_REG_STOP */
};

#define NINF_REG_PKT_CODE(p)   ((struct ninf_reg_packet *)(p))->code

struct ninf_reg_stub_packet
{
    int code;
    char program[MAX_NAME_LEN];		/* IN */
    int stub_index;			/* OUT */
    char module_name[MAX_NAME_LEN];	/* OUT */
    char entry_name[MAX_NAME_LEN];	/* OUT */
};


typedef struct ninf_reg_stub_entry
{
    char program[MAX_NAME_LEN];
    char module_name[MAX_NAME_LEN];
    char entry_name[MAX_NAME_LEN];
    char full_name[MAX_NAME_LEN * 2];
    int index;				/* back pointer */

    NINF_STUB_INFO * stub_info;
/*    int xdr_data_size;
    char *xdr_data; */
} NINF_REG_ENTRY;

NINF_REG_ENTRY *find_reg_stub_entry(/* entry_name */);
NINF_REG_ENTRY *find_reg_stub_entry_from(char * entry_name, int from, int option);
NINF_REG_ENTRY *find_reg_stub_index(/* index */);

int register_from_socket(int reg_sock);

#define make_reg_sockname(reg_sockname, port) \
        sprintf(reg_sockname, NINF_REGISTER_SOCK_NAME, port);

#endif /* __NINF_SERV_REG_H__ */
