#define _WRAPPER_
/* $Id: pctrrfs_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define SCOMPLEX
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n
#define ROW_b ldb
#define COL_b nrhs
#define ROW_x ldx
#define COL_x nrhs

static	int worklen(int n) {
	  int ret=1;
	  ret = 2*n;
	  if NEED_BUFF {
	    ret =  2*LOCr( N + MOD( IA-1, MB_A ));
	  }
	  return ret;
}

static	int rworklen(int n) {
	  int ret=1;
	  ret = n;
	  if NEED_BUFF {
	    ret = LOCr( N + MOD( IB-1, MB_B ) );
	  }
	  return ret;
}

void  pctrrfs_ninf(	 char uplo,
		 char trans,
		 char diag,
		 int n,
		 int nrhs,
		 scomplex global_a[],
		 int lda,
		 scomplex global_b[],
		 int ldb,
		 scomplex global_x[],
		 int ldx,
		 float global_ferr[],
		 float global_berr[],
		 scomplex work[],
		 float rwork[],
		 int *info
)
/* "pctrrfs provides error bounds and backward error estimates for the solution to a system of linear equations with a triangular coefficient matrix." */
/* OPTIONS */
{
	int maxldd;
	int maxlda;
	scomplex *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
	int row_loca, col_loca;

	int maxldb;
	scomplex *locb=NULL;
	int descb[DESCLEN];
	int desc_gb[DESCLEN];
	int row_locb, col_locb;

	int maxldx;
	scomplex *locx=NULL;
	int descx[DESCLEN];
	int desc_gx[DESCLEN];
	int row_locx, col_locx;

	float *locferr=NULL;
	float *locberr=NULL;

	scomplex *locwork=NULL;
	int llocwork;
	float *locrwork=NULL;
	int llocrwork;

	INITIALIZE();

	SCALAR( "char", uplo);
	SCALAR( "char", trans);
	SCALAR( "char", diag);
	SCALAR( "int", n);
	SCALAR( "int", nrhs);
	SCALAR( "int", lda);
	SCALAR( "int", ldb);
	SCALAR( "int", ldx);

	ROW( a);
	COL( a);
	ROW( b);
	COL( b);
	ROW( x);
	COL( x);
	MAXLDD( maxldd, a );
	maxlda = maxldd;
	maxldb = maxldd;
	maxldx = maxldd;

	trMATRIX( uplo, "scomplex", a, ROW_a, COL_a);
	trDISTRIBUTE( uplo, "scomplex", a, ROW_a, COL_a);

	MATRIX( "scomplex", b, ROW_b, COL_b);
	DISTRIBUTE( "scomplex", b, ROW_b  , COL_b);

	MATRIX( "scomplex", x, ROW_x, COL_x);
	DISTRIBUTE( "scomplex", x, ROW_x  , COL_x);

	VECTOR( "c", "float", ferr, nrhs);
	VECTOR( "c", "float", berr, nrhs);

	llocwork = worklen(n);
	WORK( locwork, llocwork);
	llocrwork = rworklen(n);
	_work("float", &locrwork, llocrwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pctrrfs)( &uplo, &trans, &diag,
                               &n, &nrhs,
                               loca, &one, &one, desca,
                               locb, &one, &one, descb,
                               locx, &one, &one, descx,
                               locferr, locberr,
                               locwork, &llocwork,
                               locrwork, &llocrwork,
                               &linfo);

	vGATHER( "c", "float", ferr, nrhs);
	vGATHER( "c", "float", berr, nrhs);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
		*info = linfo;
	} else {
	}

	FREE_MATRIX(a);
	FREE_MATRIX(b);
	FREE_MATRIX(x);
        FREE_VECTOR(berr);
        FREE_VECTOR(ferr);
        FREE(locwork);
        FREE(locrwork);
	
}

