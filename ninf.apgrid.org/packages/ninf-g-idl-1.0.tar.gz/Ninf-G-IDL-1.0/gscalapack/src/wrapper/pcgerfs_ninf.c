#define _WRAPPER_
/* $Id: pcgerfs_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define SCOMPLEX
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n
#define ROW_af ldaf
#define COL_af n
#define ROW_b ldb
#define COL_b nrhs
#define ROW_x ldx
#define COL_x nrhs
#define LOCc_a(n) Cnumroc( (n), cbloc, mypcol, 0, npcol)
#define LOCr_a(m) Cnumroc( (m), rbloc, myprow, 0, nprow)
#define IA 1
static  int worklen(int n)        {
            int ret;
            ret = 3*n;
            if NEED_BUFF 
                ret = 3*LOCr_a(n+(IA-1)%MB);
            return ret;
}

static  int iworklen(int n)         {
            int ret;
            ret = 2*3*n;
            if NEED_BUFF
                ret = 2*3*LOCr_a(n+(IA-1)%MB);
            return ret;
}

void  pcgerfs_ninf(	 char trans,
		 int n,
		 int nrhs,
		 scomplex global_a[],
		 int lda,
		 scomplex global_af[],
		 int ldaf,
		 int global_ipiv[],
		 scomplex global_b[],
		 int ldb,
		 scomplex global_x[],
		 int ldx,
		 float global_ferr[],
		 float global_berr[],
		 scomplex work[],
		 int iwork[],
		 int *info
)
/* "pcgerfs improves the computed solution to a system of linear equations and provides error bounds and backward error estimates for  the solutions." */
/* OPTIONS */
{
	int maxldd;

	int maxlda;
	scomplex *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];

	int maxldaf;
	scomplex *locaf=NULL;
	int descaf[DESCLEN];
	int desc_gaf[DESCLEN];

	int maxldb;
	scomplex *locb=NULL;
	int descb[DESCLEN];
	int desc_gb[DESCLEN];

	int maxldx;
	scomplex *locx=NULL;
	int descx[DESCLEN];
	int desc_gx[DESCLEN];

	int *locipiv=NULL;
        float *locferr=NULL;
	float *locberr=NULL;

        scomplex *locwork=NULL;
        int llocwork;
        
        int *lociwork=NULL;
        int llociwork;

	int row_loca, col_loca;
	int row_locaf, col_locaf;
	int row_locb, col_locb;
	int row_locx, col_locx;

#define LOCc_af(n) Cnumroc( (n), NB, mypcol, 0, npcol)
#define LOCr_af(m) Cnumroc( (m), MB, myprow, 0, nprow)


	INITIALIZE();

	SCALAR( "char", trans);
	SCALAR( "int", n);
	SCALAR( "int", nrhs);
	SCALAR("int", lda);
	SCALAR("int", ldb);
	SCALAR("int", ldx);
	SCALAR("int", ldaf);

	ROW( a);
	COL( a);
	ROW( af);
	COL( af);
	ROW( b);
	COL( b);
	ROW( x);
	COL( x);
	MAXLDD( maxldd, a );
	maxlda = maxldd;
	maxldaf = maxldd;
	maxldb = maxldd;
	maxldx = maxldd;

	MATRIX( "scomplex", a, ROW_a, COL_a);
	MATRIX( "scomplex", af, ROW_af, COL_af);
	MATRIX( "scomplex", b, ROW_b, COL_b);
	MATRIX( "scomplex", x, ROW_x, COL_x);
	VECTOR( "c" , "float", berr, nrhs);
	VECTOR( "c" , "float", ferr, nrhs);
	VECTOR( "r", "int", ipiv, ROW_af);
	DISTRIBUTE( "scomplex", a, ROW_a  , COL_a);
	DISTRIBUTE( "scomplex", af, ROW_af  , COL_af);
	DISTRIBUTE( "scomplex", b, ROW_b  , COL_b);
	DISTRIBUTE( "scomplex", x, ROW_x  , COL_x);
	vDISTRIBUTE( "r", "int" , ipiv, ROW_af);

	llocwork = worklen(n);
        WORK( locwork,  llocwork);
	llociwork = worklen(n);
	WORK( lociwork, llociwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pcgerfs)( &trans, &n, &nrhs,
                               loca, &one, &one, desca,
                               locaf, &one, &one, descaf,
                               locipiv,
                               locb, &one, &one, descb,
                               locx, &one, &one, descx,
                               locferr, locberr,
                               locwork, &llocwork,
                               lociwork, &llociwork,
                               &linfo);

	GATHER( "scomplex", x, ROW_x  , COL_x);
	vGATHER( "c", "float", berr, nrhs);
	vGATHER( "c", "float", ferr, nrhs);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
		*info = linfo;
	} else {

	}

	FREE_MATRIX(a);
	FREE_MATRIX(af);
	FREE_MATRIX(b);
	FREE_MATRIX(x);
        
	FREE_VECTOR(ipiv);
	FREE_VECTOR(ferr);
	FREE_VECTOR(berr);
        
        FREE(locwork);
        FREE(lociwork);
	
}

