#define _WRAPPER_
/* $Id: pslatrd_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define _DISTRIBUTE_1D_
#define FLOAT
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n

#define ROW_w ldw
#define COL_w nb

static	int worklen(int n) {
	  int ret=1;
	  ret = n+10;
	  if NEED_BUFF {
	    ret = cbloc + 10;
	  }
	  return ret;
}


void  pslatrd_ninf(	 char uplo,
		 int n,
		 int nb,
		 float global_a[],
		 int lda,
		 float global_d[],
		 float global_e[], //uplo
		 float global_tau[],
		 float global_w[],
		 int ldw,
		 float work[],
		 int lwork
)
/* "pslatrd reduces NB rows and columns of a real symmetric distributed matrix A to symmetric tridiagonal form by an orthogonal similarity transformation Q' * A * Q,  and returns the matrices V and W which are needed to apply the transformation to the unreduced part of A." */
/* OPTIONS */
{
	int maxldd;

	int maxlda;
	float *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
	int row_loca, col_loca;

	float *locd=NULL;
	float *loce=NULL;
	int desctdd[DESCLEN], desc_gtdd[DESCLEN];

	int maxldw;
	float *locw=NULL;
	int descw[DESCLEN];
	int desc_gw[DESCLEN];
	int row_locw, col_locw;

	float *loctau=NULL;

	float *locwork=NULL;
	int llocwork;

	INITIALIZE();

	SCALAR( "char", uplo);
	SCALAR( "int", n);
	SCALAR( "int", nb);
	SCALAR( "int", lda);
	SCALAR( "int", ldw);
	SCALAR( "int", lwork);

	SIZE(n);

	ROW( a);
	COL( a);
	ROW( w);
	COL( w);
	MAXLDD( maxldd, a );
	maxlda = maxldd;
	maxldw = maxldd;

	MATRIX( "float", a, ROW_a, COL_a);
	DISTRIBUTE( "float", a, ROW_a, COL_a);
	if (chrcmp(uplo,'U')==0) tdMATRIX( "float", 0, d, e,n);
	else tdMATRIX( "float", e, d, 0, n);
	MATRIX( "float", w, ROW_w, COL_w);
	VECTOR("c","float", tau, n);

	llocwork=worklen(n);
	llocwork = max(lwork, llocwork);
	WORK(locwork,llocwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pslatrd)( &uplo,
                               &n, &nb,
                               loca, &one, &one, desca,
                               locd, loce,
                               loctau,
                               locw, &one, &one, descw,
                               locwork);

	GATHER( "float", a, ROW_a  , COL_a);
	if (chrcmp(uplo,'U')==0) tdGATHER( "float", 0, d, e, n);
	else tdGATHER( "float", e, d, 0, n);
	vGATHER("c", "float", tau, n);
	GATHER( "float", w, ROW_w, COL_w);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
	} else {
	}

	FREE_MATRIX(a);
	FREE_MATRIX(d);
	FREE_MATRIX(e);
	FREE_VECTOR(tau);
	FREE_MATRIX(w);
	FREE(locwork);

}

