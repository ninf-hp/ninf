package ninf.MetaServer;
import ninf.basic.*;
import ninf.client.*;


import java.util.Vector;
import java.io.IOException;

public class NinfWriteBackThread extends NinfThread {
  XDROutputStream os;
  NinfStub stub;
  Vector args;
  NinfLog dbg = new NinfLog(this);
  NinfCompound comp;

  public NinfWriteBackThread(XDROutputStream s, NinfStub st, Vector a, NinfCompound comp){
    stub = st;
    os = s;
    args = a;
    this.comp = comp;
  }
  public void runSub(){
    try{
      dbg.println("NinfWriteBackThread Starts");
      if (succeeded){
	dbg.println("transaction endded successfully");	
	stub.serverSend(args, new NinfPacketOutputStream(os, false));
      }else {
	dbg.println("transaction failed");	
	NinfPacketOutputStream pos =
	  new NinfPacketOutputStream(os, NinfPktHeader.NINF_PKT_ERROR, 
				     NinfError.CANTEXECUTESTUB, 0);
	pos.writeInt(NinfConstant.NINF_ACK_ERROR);
	pos.flush();
      } 
      comp.finished();
    } catch (Exception e){
      dbg.println("A " + e +" occured in NinfWriteBackThread");
    }
  }
}
