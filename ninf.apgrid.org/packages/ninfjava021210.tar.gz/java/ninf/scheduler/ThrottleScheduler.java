package ninf.scheduler;
import ninf.metaserver.*;
import ninf.common.*;
import ninf.basic.*;
import ninf.client.*;
import java.util.Vector;
import java.util.Hashtable;

public class ThrottleScheduler extends Scheduler {
  static NinfLog dbg = new NinfLog("ThrottoleScheduler");
  static int THRESHOLD = 1;

  double[] predict(CallInformation info, ServerInformation serverInfo){
    double result[] = new double[4];
    double average = serverInfo.load.loadAverage;
    double throughput = serverInfo.throughput.throughput;
    double performance = serverInfo.serverChar.performance * 1000.0;
    long order = info.order;
    long communication = info.foreSize +info.backSize;

    double calc = (order / (performance * (1.0 /(average + 1.0))));
    double foreComm = (info.foreSize /throughput);
    double backComm = (info.backSize /throughput);
    
    result[0] = calc + foreComm + backComm;
    result[1] = foreComm;
    result[2] = calc;
    result[3] = backComm;
    
    return result;
  }

  ScheduleResult tryAgain(CallInformation info, ServerIndex serverIndexes[],
    SchedulerRoot schedulerRoot, ServerID cproxy, StringBuffer sb)
  throws NinfException {
    schedulerRoot.enque();
    return scheduleBody(info, serverIndexes, schedulerRoot, cproxy, sb, false);
  }

  public ScheduleResult schedule(CallInformation info, ServerIndex serverIndexes[],
    SchedulerRoot schedulerRoot, ServerID cproxy, StringBuffer sb)
  throws NinfException {

    return scheduleBody(info, serverIndexes, schedulerRoot, cproxy, sb, true);
  }

  public ScheduleResult scheduleBody(CallInformation info, 
				     ServerIndex serverIndexes[],
    SchedulerRoot schedulerRoot, ServerID cproxy, StringBuffer sb, boolean first)
  throws NinfException {
    
    int n = -1;
    double min = Double.MAX_VALUE;

    dbg.println(info);
    double predictedTime[][] = new double[serverIndexes.length][];
    if (serverIndexes.length == 0)
      return null;
    ServerInformation serverInfos[] = new ServerInformation[serverIndexes.length];
    for (int i = 0; i < serverIndexes.length; i++)
      serverInfos[i] = setupInfo(schedulerRoot, cproxy, serverIndexes[i]);

    for (int i = 0; i < serverInfos.length; i++){
      predictedTime[i] = predict(info, serverInfos[i]);
      dbg.println ("load of server " + i + " is " + 
		   serverInfos[i].load.loadAverage );

      if (serverInfos[i].load.loadAverage < THRESHOLD){
	n = i;
      }
    }
    if (n < 0) {
      dbg.println("no proper server, wait and try again.");
      if (!first)
	schedulerRoot.release();
      return tryAgain(info, serverIndexes, schedulerRoot, cproxy, sb);
    }
    dbg.log("select " + n + " th Server: "+ serverInfos[n]);
    sb.append(FormatString.format(
		"%10.4f %10.4f %10.4f", 
		new Double(predictedTime[n][1]),
		new Double(predictedTime[n][2]),
		new Double(predictedTime[n][3])));

    ServerInformation tmp = serverInfos[n];
    return new ScheduleResult(tmp, predictedTime[n]);
  }

}
