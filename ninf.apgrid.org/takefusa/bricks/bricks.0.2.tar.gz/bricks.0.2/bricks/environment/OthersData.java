package bricks.environment;
import bricks.util.*;
import java.util.*;

public class OthersData extends Data {
    protected NodeWithQueue node;
    protected double dataSize;

    public OthersData(
	NodeWithQueue node, double timeEventComes, double dataSize
    ) {
	id = generateId();
	processingDuration = 0.0;
	this.node = node;
	this.timeEventComes = timeEventComes;
	this.dataSize = dataSize;
    }

/************************* needed method *************************/
    public String toOriginalString() {
	return "thersData<" + id + "> " + node + ",  " + 
	    Format.format(timeEventComes, 3) + ", " + 
	    Format.format(dataSize, 3) + "\n";
    }

    public void updateProcessingDuration(
	double currentTime, double throughput
    ) {
	processingDuration = dataSize / throughput;
    }

    public String getName() {
	return "OthersData";
    }

    public double getDataSize() {
	return dataSize;
    }

/************************* protected method *************************/
    protected static String generateId() {
	return "od" + serialNumber++;
    }
}
