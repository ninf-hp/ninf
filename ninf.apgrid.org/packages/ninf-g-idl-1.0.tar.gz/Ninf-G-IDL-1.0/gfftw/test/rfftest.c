#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>

//#define N   1234567
//#define N   1000000
//#define N 2700000
//#define N 97210
//#define N 38884
//#define N 9721*7
#define N 103000

#include "assert.h"
#include <fftw.h>
#include <rfftw.h>

char *host;
int port = 0;

#define COUNT 100

extern double second();

#define dcomplex fftw_complex

int main(int argc,char ** argv) {

  double *in=NULL, *out=NULL, *rout=NULL;
  dcomplex *cin=NULL,*cdat=NULL;
  double resid;
  rfftw_plan plan;
  fftw_plan cplan;

  double *dat=NULL;
  int n=N;
  double x;
  int i;

  double time0, timef;

  in = malloc(sizeof(double)*n); assert(in);
  out = malloc(sizeof(double)*n); assert(out);
  rout = malloc(sizeof(double)*n); assert(rout);
  dat = malloc(sizeof(double)*n); assert(dat);

  cin = malloc(sizeof(dcomplex)*n); assert(cin);
  cdat = malloc(sizeof(dcomplex)*n); assert(cdat);

  x=0.2;
  for(i=0;i<N;i++) {
    //            x=4.*x*(1.-x);
    dat[i]=sin((double)i/64.);
  }

  for(i=0;i<N;i++) {
    in[i] = dat[i];
    out[i] = 0.;
    rout[i] = 0.;

    cin[i].re = dat[i];
    cin[i].im = 0.;
    cdat[i].re = 0.;
    cdat[i].im = 0.;
  }

  printf("size=%d\n",n);

  printf("\nMEASURE MODE:\n");
  plan = rfftw_create_plan( n, FFTW_FORWARD, FFTW_MEASURE);
  rfftw_print_plan(plan);
  time0 = second();
  printf("\ncount= ");
  for(i=0;i<COUNT;i++) {
    rfftw_one( plan, in, out);
    if ((i<5)||((i+1)%10==0)) { printf("%d ",i+1); fflush(stdout);}
  }
  timef = second();
  printf("\ntime= %f sec (%dtimes)\n",timef-time0, COUNT);

  rfftw_destroy_plan(plan);



  printf("\nESTIMATE MODE:\n");
  plan = rfftw_create_plan( n, FFTW_FORWARD, FFTW_ESTIMATE);
  rfftw_print_plan(plan);
  time0 = second();
  printf("\ncount= ");
  for(i=0;i<COUNT;i++) {
    rfftw_one( plan, in, out);
    if ((i<5)||((i+1)%10==0)) { printf("%d ",i+1); fflush(stdout);}
  }
  timef = second();
  printf("\ntime= %f sec (%dtimes)\n",timef-time0, COUNT);
  rfftw_destroy_plan(plan);


  printf("\n\nRESIDUE Check.\n");
  plan = rfftw_create_plan( n, FFTW_BACKWARD, FFTW_ESTIMATE);

  rfftw_one( plan, out, rout);
  rfftw_destroy_plan(plan);


  for(i=0;i<n;i++) rout[i] /= (double)n;

  printf("\n");
  for(i=0;i<10;i++) printf("%f %f\n",in[i], rout[i]);

   resid=0.;
   for(i=0;i<n;i++) {
     resid += (in[i]-rout[i])*(in[i]-rout[i]);
   }
   resid = sqrt(resid)/(double)n;

   printf("\nresid=%2.18f\n\n",resid);


   printf("\nDo the same calcuration with complex numbers.\n");
   

   cplan = fftw_create_plan( n, FFTW_FORWARD, FFTW_MEASURE);
   printf("\nMEASURE MODE:\n");
   time0 = second();
   printf("count= ");
   for(i=0;i<COUNT;i++) {
     fftw_one( cplan, cin, cdat);
    if ((i<5)||((i+1)%10==0)) { printf("%d ",i+1); fflush(stdout);}
   }
   timef = second();
   printf("\ntime= %f sec (%dtimes)\n",timef-time0, COUNT);
   fftw_destroy_plan(cplan);

   for(i=0;i<=n/2;i++)  out[i] = cdat[i].re;
   for(i=n-1;i>n/2;i--) out[i] = cdat[n-i].im;

   printf("\nRESIDUE Check.\n");
   plan = rfftw_create_plan( n, FFTW_BACKWARD, FFTW_ESTIMATE);
   rfftw_one( plan, out, rout);
   rfftw_destroy_plan(plan);

   for(i=0;i<n;i++) rout[i] /= (double)n;

   printf("\norg inv^2\n");
   for(i=0;i<10;i++) printf("%2.16f %2.16f\n",in[i], rout[i]);

   resid=0.;
   for(i=0;i<n;i++) {
     resid += (in[i]-rout[i])*(in[i]-rout[i]);
   }
   resid = sqrt(resid)/(double)n;

   printf("\nresid=%2.18f\n\n",resid);

   free(in);
   free(out);

   return 0;
}

double
second()
{
#include <sys/time.h>

  struct timeval tm;
  double t ;

  static int base_sec = 0,base_usec = 0;

  gettimeofday(&tm, NULL);
  
  if(base_sec == 0 && base_usec == 0)
    {
      base_sec = tm.tv_sec;
      base_usec = tm.tv_usec;
      t = 0.0;
    } else {
      t = (double) (tm.tv_sec-base_sec) + 
	((double) (tm.tv_usec-base_usec))/1.0e6 ;
    }

  return t ;
}
