package ninf.netsolve;
import java.io.IOException;
import java.util.StringTokenizer;
import java.util.Vector;

// import java.net.Socket;
// import java.io.DataInputStream;
// import java.io.DataOutputStream;
// import java.io.PrintStream;

public class GetProblems extends GlobalDefs {
  private MyStream str;
  public String hostname;
  public Problem [] problems;
  private final int DETAIL = 4;
  public int cur_lang = Labels.language;

  private void read_problems(int num_prob) throws java.io.IOException{  
    problems = new Problem [num_prob];
    for(int i=0;i<num_prob;i++) {
      Problem tmpProblem = new Problem();
      tmpProblem.name = str.get_string();
      read_problem(tmpProblem, DETAIL);
      problems[i] = tmpProblem;
    }
    System.out.println("done.");
  }


  private Problem read_problem(Problem tmpProblem, int detail) throws java.io.IOException{

    int i,j, resp, mid;
    String comp;
    int temp1, temp2, k;
    String temp_str;

    // read in dummy val for XDR_string

    tmpProblem.setpath(str.get_string());
    if (detail >= 2) 
      tmpProblem.description = str.get_string();
    
    if (detail >= 1){
      resp = str.server_in.readInt();
      
      tmpProblem.setinput(resp);
    /*
      if(resp == 0) {
      tmpProblem.upf = false;
      
      resp = str.server_in.readInt();
      tmpProblem.setinput(resp);
      }
      else {
      tmpProblem.upf = true;
      
      resp = str.server_in.readInt();
      tmpProblem.setinput(resp+1);
      }
      */
    
      for(j=0;j< resp ;j++) {
	tmpProblem.inputs[j] = new NetSolveObject();         
	tmpProblem.inputs[j].data_type = str.server_in.readInt();
	if(tmpProblem.inputs[j].data_type == NetSolveObject.NETSOLVE_EXTERNAL)
	  tmpProblem.upf++;
	tmpProblem.inputs[j].object_type = str.server_in.readInt();
	if (detail >= 3)
	  tmpProblem.inputs[j].description = str.get_string();
      }
    /*
      if(tmpProblem.upf > 0) {
      tmpProblem.inputs[resp] = new NetSolveObject();
      tmpProblem.inputs[resp].data_type = NetSolveObject.NETSOLVE_EXTERNAL;
      tmpProblem.inputs[resp].object_type = NetSolveObject.NETSOLVE_SCALAR;
      tmpProblem.inputs[resp].description = Labels.upf[cur_lang];
      }
      */
    
      resp = str.server_in.readInt();
      tmpProblem.setoutput(resp);
      for(j=0;j<tmpProblem.nb_output;j++) {
	tmpProblem.outputs[j] = new NetSolveObject();         
	tmpProblem.outputs[j].data_type = str.server_in.readInt();
	tmpProblem.outputs[j].object_type = str.server_in.readInt();
	if (detail >= 3)
	  tmpProblem.outputs[j].description = str.get_string();
      }
      if (detail < 5){
	comp = str.get_string();
	mid = parse_complexity(comp);

	if(mid == -1) {
	  tmpProblem.complexity_a = 0;
	  tmpProblem.complexity_b = 0;
	  System.out.println("Trouble parsing complexity string");
	} else {
	  tmpProblem.complexity_a = 
	    new Integer(comp.substring(0,mid)).intValue();
	  tmpProblem.complexity_b = 
	    new Integer(comp.substring(mid+1)).intValue();
	}
      }
    }    
    /***************************************************
    **** This stuff for detail level 4 is untested ****
    **** and probably doesn't work.                ****/

    if(detail >= 4) {
      if (detail == 4)
	resp = str.server_in.readInt();  /* this seems to be a protocol bug */
      else
	resp = 1;
      for(j=0;j<resp;j++) { 
	temp1 = str.server_in.readInt();
	tmpProblem.mnemonics = new String[temp1][];
	for(k=0;k<temp1;k++) {
	  String tmpStr = str.get_string();
	  Vector v = new Vector();
	  StringTokenizer st = new StringTokenizer(tmpStr, ", ");
	  while (st.hasMoreTokens())
	    v.addElement(st.nextToken());
	  String tmpArray[] = new String[v.size()];
	  for (int l = 0; l < v.size(); l++)
	    tmpArray[l] = (String)v.elementAt(l);
	  tmpProblem.mnemonics[k] = tmpArray;
	}
	temp1 = str.server_in.readInt();
	tmpProblem.constants = new Constant[temp1];
	for(k=0;k<temp1;k++) {
	  temp_str = str.get_string();
	  temp2 = str.server_in.readInt();
	  tmpProblem.constants[k] = new Constant(temp_str, temp2);
	}
	temp1 = str.server_in.readInt();
	tmpProblem.formulae = new Formula[temp1];
	for(k=0;k<temp1;k++) {
	  String str1 = str.get_string();
	  String str2 = str.get_string();
	  tmpProblem.formulae[k] = new Formula(str1, str2);
	}
      } 
    }
  /***************************************************/
    
    /* to skip matlab directives */
    if (detail >= 5){      /* 5 is used only for readOneProblem */
      temp1 = str.server_in.readInt();
      for (k = 0; k < temp1; k++){
	temp2 = str.server_in.readInt();
	temp2 = str.server_in.readInt();
      }
    }
    return tmpProblem;
  }


  private void sort_problems() {
    QSortAlgorithm qs;

    qs = new QSortAlgorithm();
    qs.sort(problems);
  }

  private void print_problems() {  
    for(int i = 0; i < problems.length; i++) {
      System.out.println(problems[i]);
    }
  }

  private int parse_complexity(String cstr) {
    int start=0, end=0;
 
    if(cstr.length() < 3) return -1;

    while((end < cstr.length()) && (cstr.charAt(end) != ',')) 
      end++;

    if((end == cstr.length()) || (start==end)) return -1;
    
    return end;
  }

  public GetProblems(String hostname){
    this.hostname = hostname;
  }

  public Problem getOneProblem(String name)  throws NetSolveException{
    short encoding;
    try {
      try {
	// always XDR
	str = new MyStream(hostname,AG_PORT,DATA_XDR);
      }
      catch(IOException e) {
	System.out.println("Could not connect to server: "+e);
	throw new NetSolveException(e.getMessage());
      }
      
      System.out.println("Sending some data to the server..");
      str.server_out.writeInt(INFO_REQUEST); // send request
      str.write_string(name); // send request
      str.server_out.writeInt(DETAIL);       // send detail
      System.out.println("...done.");
      
      System.out.println("Response from server:");
      encoding = str.server_in.readShort(); 
      str.init_recv(encoding);
      System.out.println("encoding = " + encoding); 

      int status = str.server_in.readInt();
      System.out.println("status = " + status);
      if (status == INVALID_CODE || status == NO_SUCH_PB){
	System.out.println("failed");
	return null;
      }
      Problem tmpProblem = new Problem();
      tmpProblem.name = name;
      read_problem(tmpProblem, 5);
      return tmpProblem;
      
    } catch(IOException e) {
      System.out.println("Data transfer error: "+e);
      e.printStackTrace();
      throw new NetSolveException(e.getMessage());
    } finally {
      try { 
        if (str != null)  
          if (str.s != null) 
            str.shut_down(); 
      }
      catch (IOException e2) { ; }
    }
  }
  
  public Problem[] getAllProblems()  throws NetSolveException {
    short encoding;
    int num_problems;

    try {
      try {
        // always XDR
        str = new MyStream(hostname,AG_PORT,DATA_XDR);
      }
      catch(IOException e) {
        System.out.println("Could not connect to server: "+e);
        throw new NetSolveException(e.getMessage());
      }

     System.out.println("Sending some data to the server..");
//     str.server_out.writeChar(DATA_RAW);    // send encoding
     str.server_out.writeInt(POLL_LIST_PB); // send request
     str.server_out.writeInt(DETAIL);       // send detail
     System.out.println("...done.");

     System.out.println("Response from server:");
     encoding = str.server_in.readShort();
     str.init_recv(encoding);
     System.out.println("encoding = " + encoding);

     num_problems = str.server_in.readInt();
     System.out.println("num_problems = " + num_problems);

     read_problems(num_problems);
     System.out.println("Sorting...");
     sort_problems();
     System.out.println("done.");
    }
    catch(IOException e) {
      System.out.println("Data transfer error: "+e);
      throw new NetSolveException(e.getMessage());
    }
    finally {
      try { 
        if (str != null)  
          if (str.s != null) 
            str.shut_down(); 
      }
      catch (IOException e2) { ; }
    }
    return problems;
  }
}
