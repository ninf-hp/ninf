#define _WRAPPER_
/* $Id: psposv_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define FLOAT
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n
#define ROW_b ldb
#define COL_b nrhs
void  psposv_ninf(	 char uplo,
		 int n,
		 int nrhs,
		 float global_a[],
		 int lda,
		 float global_b[],
		 int ldb,
		 int *info
)
/* "psposv computes the solution to a real system of linear equations A * X = B, where A denotes A and is an N-by-N symmetric distributed positive definite matrix and X and B denoting B are N-by-NRHS distributed matrices." */
/* OPTIONS */
{
    extern void FortranCall(psposv)( char*, int*, int*,
				     float*, int*, int*, int*,
				     float*, int*, int*, int*, int*);

	int maxldd;

	int maxlda;
	float *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];

	int maxldb;
	float *locb=NULL;
	int descb[DESCLEN];
	int desc_gb[DESCLEN];

	int row_loca, col_loca;
	int row_locb, col_locb;

	INITIALIZE();

	SCALAR( "char", uplo);
	SCALAR( "int", n);
	SCALAR( "int", nrhs);
	SCALAR( "int", lda);
	SCALAR( "int", ldb);

	ROW( a);
	COL( a);
	ROW( b);
	COL( b);
	MAXLDD( maxldd, a );
	maxlda = maxldd;
	maxldb = maxldd;

	trMATRIX( uplo, "float", a, ROW_a, COL_a);
	MATRIX( "float", b, ROW_b, COL_b);
	trDISTRIBUTE( uplo, "float", a, ROW_a  , COL_a);
	DISTRIBUTE( "float", b, ROW_b  , COL_b);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(psposv)( &uplo, &n, &nrhs,
                              loca, &one, &one, desca,
                              locb, &one, &one, descb, &linfo);

	GATHER( "float", a, ROW_a  , COL_a);
	GATHER( "float", b, ROW_b  , COL_b);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
		*info = linfo;
	} else {
		
	}

	FREE_MATRIX(a);
	FREE_MATRIX(b);
}

