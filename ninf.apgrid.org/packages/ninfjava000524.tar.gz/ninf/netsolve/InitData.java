package ninf.netsolve;
// import java.io.*;
// import java.util.*;
import java.util.Vector;

public class InitData extends Thread {
  private String [] str_array;
  private Problem prob;
  private Vector output_vec;

  public String [] get_strArray() {
    return str_array;
  }

  public InitData(Problem a, Vector b) {
    prob = a;
    output_vec = b;

    this.start();
  }
  
  public void run() {
    int j, k, m, length;
    StringBuffer temp = new StringBuffer(200);

    str_array = new String[prob.nb_output];
    for(j=0;j<prob.nb_output;j++) {          
      temp.setLength(0);
      this.yield();
      switch(prob.outputs[j].object_type) {
        case NetSolveObject.NETSOLVE_SCALAR:
          System.out.println("Scalar "+j+":");
          switch(prob.outputs[j].data_type) {
            case NetSolveObject.NETSOLVE_I:
              System.out.println(((Integer)output_vec.elementAt(j)).toString());
              str_array[j] = ((Integer)output_vec.elementAt(j)).toString();
              break;
            case NetSolveObject.NETSOLVE_S:
              System.out.println(((Float)output_vec.elementAt(j)).toString());
              str_array[j] = ((Float)output_vec.elementAt(j)).toString();
              break;
            case NetSolveObject.NETSOLVE_D:
              System.out.println(((Double)output_vec.elementAt(j)).toString());
              str_array[j] = ((Double)output_vec.elementAt(j)).toString();
              break;
            case NetSolveObject.NETSOLVE_C:
              if(((float [])(output_vec.elementAt(j)))[1] >= 0.0) 
                str_array[j] = 
                 String.valueOf(((float [])(output_vec.elementAt(j)))[0])+ " + "+
                 String.valueOf(((float [])(output_vec.elementAt(j)))[1])+ "i";
              else
                str_array[j] = 
                 String.valueOf(((float [])(output_vec.elementAt(j)))[0]) + " " +
                 String.valueOf(((float [])(output_vec.elementAt(j)))[1]) + "i";
              break;
            case NetSolveObject.NETSOLVE_Z:
              if(((double [])(output_vec.elementAt(j)))[1] >= 0.0)
                str_array[j] = 
                 String.valueOf(((double [])(output_vec.elementAt(j)))[0])+" + "+
                 String.valueOf(((double [])(output_vec.elementAt(j)))[1])+"i";
              else
                str_array[j] = 
                 String.valueOf(((double [])(output_vec.elementAt(j)))[0]) + " " +
                 String.valueOf(((double [])(output_vec.elementAt(j)))[1]) + "i";
              break;
            case NetSolveObject.NETSOLVE_CHAR:
              System.out.println(((Character)output_vec.elementAt(j)).toString());
              str_array[j] = ((Character)output_vec.elementAt(j)).toString();
              break;
          }
          break;
        case NetSolveObject.NETSOLVE_VECTOR:
          System.out.println("Vector "+j+":");
          switch(prob.outputs[j].data_type) {
            case NetSolveObject.NETSOLVE_I:
              length = ((int [])(output_vec.elementAt(j))).length;
              System.out.println("length = " + length);
              for(k=0;k<length;k++) {
                temp.append(String.valueOf(((int [])(output_vec.elementAt(j)))[k]) + " ");
                if(k != length - 1)
                  temp.append("\n");
              }
              break;
            case NetSolveObject.NETSOLVE_S:
              length = ((float [])(output_vec.elementAt(j))).length;
              System.out.println("length = " + length);
              for(k=0;k<length;k++) {
                temp.append(String.valueOf(((float [])(output_vec.elementAt(j)))[k]) + " ");
                if(k != length - 1)
                  temp.append("\n");
              }
              System.out.println("length = " + length);
              break;
            case NetSolveObject.NETSOLVE_D:
              length = ((double [])(output_vec.elementAt(j))).length;
              System.out.println("length = " + length);
              for(k=0;k<length;k++) {
                temp.append(String.valueOf(((double [])(output_vec.elementAt(j)))[k]) + " ");
                if(k != length - 1)
                  temp.append("\n");
              }
              System.out.println("length = " + length);
              break;
            case NetSolveObject.NETSOLVE_C:
              length = ((float [])(output_vec.elementAt(j))).length;
              System.out.println("length = " + length);
              for(k=0;k<length;k+=2) {
                if(((float [])(output_vec.elementAt(j)))[k+1] >= 0.0) {
                  temp.append(String.valueOf(
                       ((float [])(output_vec.elementAt(j)))[k]) + " + ");
                  temp.append(String.valueOf(
                       ((float [])(output_vec.elementAt(j)))[k+1]) + "i");
                }
                else {
                  temp.append(String.valueOf(
                       ((float [])(output_vec.elementAt(j)))[k]) + " ");
                  temp.append(String.valueOf(
                       ((float [])(output_vec.elementAt(j)))[k+1]) + "i");
                }
                if(k != length - 1)
                  temp.append("\n");
              }
              System.out.println("length = " + length);
              break;
            case NetSolveObject.NETSOLVE_Z:
              length = ((double [])(output_vec.elementAt(j))).length;
              System.out.println("length = " + length);
              for(k=0;k<length;k+=2) {
                if(((double [])(output_vec.elementAt(j)))[k+1] >= 0.0) {
                  temp.append(String.valueOf(
                     ((double [])(output_vec.elementAt(j)))[k]) + " + ");
                  temp.append(String.valueOf(
                     ((double [])(output_vec.elementAt(j)))[k+1]) + "i");
                }
                else {
                  temp.append(String.valueOf(
                     ((double [])(output_vec.elementAt(j)))[k]) + " ");
                  temp.append(String.valueOf(
                     ((double [])(output_vec.elementAt(j)))[k+1]) + "i");
                }
                if(k != length - 1)
                  temp.append("\n");
              }
              System.out.println("length = " + length);
              break;
            case NetSolveObject.NETSOLVE_CHAR:
              length = ((char [])(output_vec.elementAt(j))).length;
              System.out.println("length = " + length);
              for(k=0;k<length;k++) {
                temp.append(String.valueOf(((char [])(output_vec.elementAt(j)))[k]) + " ");
                if(k != length - 1)
                  temp.append("\n");
              }
              System.out.println("length = " + length);
              break;
          }
          str_array[j] = new String(temp.toString());
          System.out.println();
          break;
        case NetSolveObject.NETSOLVE_MATRIX:
          System.out.println("Matrix "+j+":");
          switch(prob.outputs[j].data_type) {
            case NetSolveObject.NETSOLVE_I:
              for(m=0;m < ((int [][])(output_vec.elementAt(j)))[0].length;m++){
                for(k=0;k< ((int [][])(output_vec.elementAt(j))).length;k++) { 
                  System.out.print( 
                    String.valueOf( ((int [][])(output_vec.elementAt(j)))[k][m]));
                  temp.append(
                    String.valueOf( ((int [][])(output_vec.elementAt(j)))[k][m]));
//                  if(k != ((int [][])(output_vec.elementAt(j)))[0].length - 1)
                    temp.append("\t");
                }
                temp.append("\n");
                System.out.println();
              }
              break;
            case NetSolveObject.NETSOLVE_S:
              for(m=0;m < ((float [][])(output_vec.elementAt(j)))[0].length;m++){
                for(k=0;k< ((float [][])(output_vec.elementAt(j))).length;k++) { 
                  System.out.print( 
                    String.valueOf( ((float [][])(output_vec.elementAt(j)))[k][m]));
                  temp.append(
                    String.valueOf( ((float [][])(output_vec.elementAt(j)))[k][m]));
//                  if(k != ((float [][])(output_vec.elementAt(j)))[0].length - 1)
                    temp.append("\t");
                }
                temp.append("\n");
                System.out.println();
              }
              break;
            case NetSolveObject.NETSOLVE_D:
              for(m=0;m < ((double [][])(output_vec.elementAt(j)))[0].length;m++){
                for(k=0;k< ((double [][])(output_vec.elementAt(j))).length;k++) { 
                  System.out.print( 
                    String.valueOf( ((double [][])(output_vec.elementAt(j)))[k][m]));
                  temp.append(
                    String.valueOf( ((double [][])(output_vec.elementAt(j)))[k][m]));
//                  if(k != ((double [][])(output_vec.elementAt(j)))[0].length - 1)
                    temp.append("\t");
                }
                temp.append("\n");
                System.out.println();
              }
              break;
            case NetSolveObject.NETSOLVE_C:
              for(k=0;k< ((float [][])(output_vec.elementAt(j))).length;k++) { 
                for(m=0;m < ((float [][])(output_vec.elementAt(j)))[0].length;m+=2){
                  System.out.print(String.valueOf( 
                     ((float [][])(output_vec.elementAt(j)))[k][m]));
                  System.out.print(String.valueOf( 
                     ((float [][])(output_vec.elementAt(j)))[k][m+1]));
                  if(((float [][])(output_vec.elementAt(j)))[k][m+1] >= 0.0) {
                    temp.append(String.valueOf( 
                       ((float [][])(output_vec.elementAt(j)))[k][m]) + " + ");
                    temp.append(String.valueOf( 
                       ((float [][])(output_vec.elementAt(j)))[k][m+1]));
                  }
                  else {
                    temp.append(String.valueOf( 
                       ((float [][])(output_vec.elementAt(j)))[k][m]) + " ");
                    temp.append(String.valueOf( 
                       ((float [][])(output_vec.elementAt(j)))[k][m+1]));
                  }
                  temp.append("i");
//                  if(m != ((float [][])(output_vec.elementAt(j)))[0].length - 1)
                    temp.append("\t");
                }
                temp.append("\n");
                System.out.println();
              }
              break;
            case NetSolveObject.NETSOLVE_Z:

              for(k=0;k< ((double [][])(output_vec.elementAt(j))).length;k++) { 
                for(m=0;m< ((double [][])(output_vec.elementAt(j)))[0].length;m+=2){
                  System.out.print(String.valueOf( 
                    ((double [][])(output_vec.elementAt(j)))[k][m]));
                  System.out.print(String.valueOf( 
                    ((double [][])(output_vec.elementAt(j)))[k][m+1]));
                  if(((double [][])(output_vec.elementAt(j)))[k][m+1] >= 0.0) {
                    temp.append(String.valueOf( 
                      ((double [][])(output_vec.elementAt(j)))[k][m]) + " + ");
                    temp.append(String.valueOf( 
                      ((double [][])(output_vec.elementAt(j)))[k][m+1]));
                  }
                  else {
                    temp.append(String.valueOf( 
                      ((double [][])(output_vec.elementAt(j)))[k][m]) + " ");
                    temp.append(String.valueOf( 
                      ((double [][])(output_vec.elementAt(j)))[k][m+1]));
                  }
                  temp.append("i");
//                  if(m != ((double [][])(output_vec.elementAt(j)))[0].length - 1)
                    temp.append("\t");
                }
                temp.append("\n");
                System.out.println();
              }
              break;
            case NetSolveObject.NETSOLVE_CHAR:
              for(m=0;m < ((char [][])(output_vec.elementAt(j)))[0].length;m++){
                for(k=0;k< ((char [][])(output_vec.elementAt(j))).length;k++) { 
                  System.out.print( 
                   String.valueOf( ((char [][])(output_vec.elementAt(j)))[k][m]));
                  temp.append(
                   String.valueOf( ((char [][])(output_vec.elementAt(j)))[k][m]));
//                  if(k != ((char [][])(output_vec.elementAt(j)))[0].length - 1)
                    temp.append("\t");
                }
                temp.append("\n");
                System.out.println();
              }
              break;
          }
          str_array[j] = new String(temp.toString());
          break;
      }
    }
  }
}
