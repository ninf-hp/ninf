#define _WRAPPER_
/* $Id: pcdbsv_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define _DISTRIBUTE_1D_
#define SCOMPLEX
#define NO_PIVOT
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n
#define ROW_b ldb
#define COL_b nrhs
static	int worklen(int n, int nrhs, int bwl, int bwu) {
	  int ret=1;
	  ret = n*(bwl+bwu)+6*max(bwl,bwu)*max(bwl,bwu)
		  +max((max(bwl,bwu)*nrhs), max(bwl,bwu)*max(bwl,bwu));
	  if NEED_BUFF {
		  ret =   blocsize*(bwl+bwu)+6*max(bwl,bwu)*max(bwl,bwu)
			  +max((max(bwl,bwu)*nrhs), max(bwl,bwu)*max(bwl,bwu));
	  }
	  return ret;
}

void  pcdbsv_ninf(	 int n,
		 int bwl,
		 int bwu,
		 int nrhs,
		 scomplex global_a[],
		 int lda,
		 scomplex global_b[],
		 int ldb,
		 scomplex work[],
		 int lwork,
		 int *info
)
/* "pcdbsv solves a system of linear equations A * X = B where A is an N-by-N complex banded diagonally dominant-like distributed matrix with bandwidth BWL, BWU." */
/* OPTIONS */
{
    extern void FortranCall(pcdbsv)( int*, int*, int*, int*,
                              scomplex*, int*, int*,
                              scomplex*, int*, int*,
                              scomplex*, int*, int*);

	int maxldd;

	scomplex *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];

	int maxldb;
	scomplex *locb=NULL;
	int descb[DESCLEN];
	int desc_gb[DESCLEN];
	int row_locb, col_locb;

	scomplex *locwork=NULL;
	int llocwork;

	INITIALIZE();

	SCALAR( "int", n);
	SCALAR( "int", bwl);
	SCALAR( "int", bwu);
	SCALAR( "int", nrhs);
	SCALAR("int", lda);
	SCALAR("int", ldb);
	SCALAR( "int", lwork);
	SIZE(n);

	ROW(b);
	COL(b);
	MAXLDD( maxldd, b);
	maxldb=maxldd;
	
	bandMATRIX("scomplex", a, bwl, bwu, n);
	MATRIX("scomplex", b, ROW_b, COL_b);
	bandDISTRIBUTE("scomplex", a, bwl, bwu, n);
	DISTRIBUTE("scomplex", b, ROW_b, COL_b);

	llocwork = worklen(n,nrhs, bwl, bwu);
        llocwork = max(llocwork,lwork);
	WORK(locwork,llocwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pcdbsv)( &n, &bwl, &bwu, &nrhs,
                              loca, &one, desca,
                              locb, &one, descb,
                              locwork, &llocwork, &linfo);

	bandGATHER("scomplex", a, bwl, bwu, n);
	GATHER("scomplex", b, ROW_b, COL_b);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
	  *info = linfo;
	} else {
	}
        
	FREE_MATRIX(a);
	FREE_MATRIX(b);

        FREE(locwork);
}

