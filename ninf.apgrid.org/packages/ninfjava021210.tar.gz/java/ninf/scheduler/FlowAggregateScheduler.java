package ninf.scheduler;
import ninf.common.*;
import ninf.metaserver.*;
import ninf.basic.*;
import ninf.client.*;
import ninf.cproxy.aggregate.*;
import java.util.Hashtable;
import java.util.Vector;

public class FlowAggregateScheduler extends AggregateScheduler {
  Hashtable serverLoad = new Hashtable();
  static NinfLog dbg = new NinfLog("FlowAggregateScheduler");

  int getLoad(NinfServerStruct id){
    Integer tmp = (Integer)serverLoad.get(id);
    if (tmp == null)
      return 0;
    return tmp.intValue();
  }

  void addLoad(NinfServerStruct id){
    Integer tmp = (Integer)serverLoad.get(id);
    int val;
    if (tmp == null)
      val = 0;
    else
      val = tmp.intValue();
    serverLoad.put(id, new Integer(val + 1));
  }

  double performance(SchedulerRoot schedulerRoot, NinfServerStruct server)
  throws NinfException{
    LoadInformation load = 
      schedulerRoot.getLoad      (server);
    ServerCharacter serverChar = 
      schedulerRoot.getServerChar(server);

    double average = load.loadAverage;
    double performance = serverChar.performance * 1000.0 * serverChar.CPUNum;
    int scheduled = getLoad(server);
    return (performance * (1.0 /(average + scheduled + 1.0)));
  }

  private void setDataLocations(FuncNode funcNodes[], DataNode dataNodes[]){
    for (int i = 0; i < dataNodes.length; i++)
      if (dataNodes[i].location == null){
	ServerIndex tmp = funcNodes[dataNodes[i].from].serverIndex;
	dataNodes[i].location = new ServerID(tmp.server.host, tmp.server.port);
      }
  }

  private void getServerIndex(FuncNode funcNode, DataNode dataNodes[],
				     NinfServerStruct servers[],
	     SchedulerRoot schedulerRoot, ServerID cproxy, StringBuffer sb)
  throws NinfException{
    if (funcNode.serverIndexes != null && funcNode.serverIndexes.length > 0)
      funcNode.serverIndex = funcNode.serverIndexes[0];
    
  }

  private void getServerIndex(FuncNode funcNode, SchedulerRoot schedulerRoot)
  throws NinfException{
    if (funcNode.serverIndexes != null && funcNode.serverIndexes.length > 0){
      double max = 0;
      ServerIndex ans = null;
      for (int i = 0; i < funcNode.serverIndexes.length; i++){
	double perf = performance(schedulerRoot, 
				  funcNode.serverIndexes[i].server);
	if (perf > max){
	  max = perf;
	  ans = funcNode.serverIndexes[i];
	}
      }
      addLoad(ans.server);
      funcNode.serverIndex = ans;
    }
  }

  private void scheduleEach(FlowPath path, SchedulerRoot schedulerRoot)
  throws NinfException{
    for (int i = 1; i < path.funcNodes.size() - 1; i++){
      FuncNode tmp = (FuncNode)path.funcNodes.elementAt(i);
      getServerIndex(tmp, schedulerRoot);
    }
  }

  private void schedule(FlowPath path, SchedulerRoot schedulerRoot)
  throws NinfException{
    Vector common = path.getCommonServers();
    if (common.size() == 0){
      dbg.println("cannot do flow schedule");
      scheduleEach(path, schedulerRoot);
      return;
    }
    NinfServerStruct ans = null;
    double max = 0;
    for (int i = 0; i < common.size(); i++){
      NinfServerStruct server = (NinfServerStruct)common.elementAt(i);
      double perf = performance(schedulerRoot, server);
      dbg.println(server +" performance " + perf );
				
      if (perf > max){
	max = perf;
	ans = (NinfServerStruct)common.elementAt(i);
      }
    }
    addLoad(ans);
    dbg.println(path +" is scheduled on " + ans );
    path.locate(ans);
  }

  private FlowPath selectPath(Vector pathes){
    long max = -1;
    FlowPath ans = null; 
    for (int i = 0; i < pathes.size(); i++){
      FlowPath tmp = (FlowPath)pathes.elementAt(i);
      dbg.println("considering Path: " + tmp);
      if (max < tmp.order()){
	max = tmp.order();
	ans = tmp;
      }
    }
    return ans;
  }

  private Vector newPathes(Vector pathes){
    Vector ans = new Vector();
    for (int i = 0; i < pathes.size(); i++){
      FlowPath tmp = (FlowPath)pathes.elementAt(i);
      Vector v = tmp.getSubPath();
      for (int j = 0; j < v.size(); j++){
	FlowPath tmp2 = (FlowPath)v.elementAt(j);
	ans.addElement(tmp2);
      }
    }
    return ans;
  }

  private void schedule(Vector pathes, SchedulerRoot schedulerRoot)
  throws NinfException{
    while (pathes.size() > 0){
      FlowPath path = selectPath(pathes);
      dbg.println("scheduling Path: " + path);

      schedule(path, schedulerRoot);
      pathes = newPathes(pathes);
    }
  }

  public AggregateScheduled schedule(DataFlow dataFlow,
				     NinfServerStruct servers[],
				     SchedulerRoot schedulerRoot, 
				     ServerID cproxy, StringBuffer sb)
  throws NinfException{
    FuncNode[] funcNodes = dataFlow.funcNodes;
    DataNode[] dataNodes = dataFlow.dataNodes;

    /*
    for (int i = 0; i < funcNodes.length; i++){
    getServerIndex(funcNodes[i], dataNodes, servers,
      schedulerRoot, cproxy, sb);
    }
    */
    schedule((Vector)dataFlow.pathes.clone(), schedulerRoot);

    for (int i = 0; i < funcNodes.length; i++){
      ServerIndex serverIndex = (funcNodes[i].serverIndex);
      String tmp = (serverIndex == null) ? "null" : serverIndex.server.toString();
      sb.append(tmp);
      sb.append(" ");
    }
    sb.append("\n");
    setDataLocations(funcNodes, dataNodes);
    return new AggregateScheduled(dataFlow);
    
  }

}


