#define _WRAPPER_
/* $Id: pddbtrsv_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define _DISTRIBUTE_1D_
#define DOUBLE
#define NO_PIVOT
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n
#define ROW_b ldb
#define COL_b nrhs
#define ROW_af laf
#define COL_af n

static	int worklen(int nrhs, int bwl, int bwu) {
	  int ret=1;
	  ret =  (max(bwl,bwu)*nrhs);
          return ret;
}

void  pddbtrsv_ninf(  char uplo,
		 char trans,
		 int n,
		 int bwl,
		 int bwu,
		 int nrhs,
		 double global_a[],
		  int lda,
		 double global_b[],
		  int ldb,
		  double af[],
		 int dummy_laf,
		 double work[],
		 int lwork,
		 int *info
)
/* "pddbtrsv solves a banded triangular system of linear equations A * X = B or A^T * X = B where A is a banded triangular matrix factor produced by the Gaussian elimination code pdbtrf and is stored in A and AF." */
/* OPTIONS */
{

	extern void FortranCall(pddbtrsv)( char*, char*,
					   int*, int*, int*, int*,
					   double*, int*, int*,
					   double*, int*, int*,
					   double*, int*,
					   double*, int*,
					   int*);

	int maxldd;

	double *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];

	int maxldb;
	double *locb=NULL;
	int descb[DESCLEN];
	int desc_gb[DESCLEN];
	int row_locb, col_locb;

	double *locwork=NULL;
	int llocwork;

	double *locaf=NULL,*global_af=NULL;
	int descaf[DESCLEN];
	int desc_gaf[DESCLEN];
	int maxldaf;
	int laf, llocaf;
	int row_locaf, col_locaf;


	INITIALIZE();

	SCALAR( "char", uplo);
	SCALAR( "char", trans);
	SCALAR( "int", n);
	SCALAR( "int", bwl);
	SCALAR( "int", bwu);
	SCALAR( "int", nrhs);
	SCALAR( "int", dummy_laf);
	SCALAR("int", lda);
	SCALAR( "int", lwork);

	SIZE(n);

	laf=max(dummy_laf, bwl+bwu+6*max(bwl,bwu)*max(bwl,bwu)/n);
	llocaf=laf*blocsize;
	if(mypnum==0){
            global_af=MALLOC(sizeof(double)*laf*n);
            assert(global_af);
	}

	ROW(af);
	COL(af);
	ROW(b);
	COL(b);
	MAXLDD( maxldd, b);
	maxldb =  maxldd;
	maxldaf = maxldd;

	bandMATRIX( "double", a, bwl ,bwu, n);
	MATRIX( "double", b, ROW_b, COL_b);
	MATRIX( "double", af, ROW_af, COL_af);
	bandDISTRIBUTE( "double", a, bwl, bwu, n);
	DISTRIBUTE( "double", b, ROW_b, COL_b);

	llocwork = worklen(nrhs, bwl, bwu);
        llocwork = max(lwork,llocwork);
	WORK(locwork,llocwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	  FortranCall(pddbtrsv)( &uplo, &trans, &n, &bwl, &bwu, &nrhs,
                                 loca, &one, desca,
                                 locb, &one, descb,
                                 locaf, &llocaf,
                                 locwork, &llocwork, &linfo);

	bandGATHER( "double", a, bwl, bwu, n);
	GATHER("double", b, ROW_b, COL_b);
	GATHER("double",  af, ROW_af, COL_af);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
	  int i;
	  *info = linfo;
	  for(i=0;i<min(dummy_laf,laf*n); i++) af[i] = global_af[i];
          FREE(global_af);
	} else {
	}
	FREE_MATRIX(a);
	FREE_MATRIX(b);
	FREE_MATRIX(af);
        FREE(locwork);
}

