package bricks.scheduling;
import bricks.util.*;
import bricks.environment.*;
import java.util.*;
import java.io.*;

public class PassiveReplicaManager extends ReplicaManager implements SchedulingUnit {
    int numOfReplications = 1;
    protected double specifiedSize = 10000.0;

    public PassiveReplicaManager(
	String keyOfResourceDB, String keyOfServerMonitor, 
	double compactness, double overstoredDiskRate, int numOfReplications
    ) {
	super(keyOfResourceDB, keyOfServerMonitor, compactness);
	this.overstoredDiskRate = overstoredDiskRate;
	this.numOfReplications = numOfReplications;
    }

/************************* needed method *************************/
    public String getName() {
	return "PassiveReplicaManager";
    }

    // implement replication strategies
    public void processEvent(double currentTime) {;}

    /** PassiveReplicaManager */
    public void replicate(
	double currentTime, Host source, DataFragment fragment
    ) {
	if (fragment.size != specifiedSize)
	    return;

	Vector scoresOfDestination = new Vector();

	Enumeration e = resourceDB.hosts();
	while (e.hasMoreElements()) {
	    Host host = (Host)e.nextElement();
	    if (host.equals(source))
		continue;
	    HostInfo info = serverMonitor.getHostInfo(currentTime, host);
	    StaticHostInfo staticInfo = resourceDB.getStaticHostInfo(host);
	    computeScoreOfDestination(
		host, staticInfo, info, scoresOfDestination
	    );
	}

	shuffle(scoresOfDestination);
	HeapSortForReplicaManager.sortByScore(scoresOfDestination);
	Vector v = new Vector(1);

	ReplicaData replica = null;
	for (int j = scoresOfDestination.size() - 1; j >= 0; j--) {
	    Score destinationScore = (Score)scoresOfDestination.elementAt(j);
	    if (!serverMonitor.hasAvailableDisk(
		currentTime, destinationScore.host, fragment.size))
		continue;

	    Host destination = ((Score)scoresOfDestination.elementAt(j)).host;
	    replica = new ReplicaData(
		owner, source, destination, this, fragment, false, currentTime
	    );
	    v.add(replica);
	    if (v.size() == numOfReplications)
		break;
	}

	if (v.size() > 0) {
	    replicatings.add(v);
	    replicate(currentTime, replicatings.size() - 1);
	}
    }

    protected void computeScoreOfDestination(
	Host host, StaticHostInfo staticInfo, HostInfo info, 
	Vector scoresOfDestination
    ) {
	double score = staticInfo.performance / (info.loadAverage + 1.0);
	scoresOfDestination.add(new Score(host, score));
    }
}
