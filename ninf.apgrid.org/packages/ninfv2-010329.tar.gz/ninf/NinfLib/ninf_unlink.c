#include <stdio.h>
#include <stdlib.h>
#include <strings.h>
#include "ninf_error.h"

struct NINF_UNLINK{
  char * filename;
  struct NINF_UNLINK * next;
};
typedef struct NINF_UNLINK ninf_unlink;

static ninf_unlink * unlink_list = NULL;

void clear_unlink(){
  while (unlink_list != NULL){
    ninf_unlink * tmp = unlink_list;
    unlink_list = unlink_list->next;
    free(tmp);
  }
  unlink_list = NULL;
}

void register_unlink(char * str)
{
  ninf_unlink * tmp;
  char * tmpchar;
  if ((tmp = (ninf_unlink *)malloc(sizeof(ninf_unlink))) == NULL){
    ninf_error("Can't malloc in regist_unlink");
  }
  if ((tmpchar = (char *)malloc(strlen(str) + 1)) == NULL){
    ninf_error("Can't malloc in regist_unlink");
  }
  strncpy(tmpchar, str, strlen(str)+1);
  tmp->next = unlink_list;
  tmp->filename = tmpchar;
  unlink_list = tmp;
}

void unlink_all(){
  while (unlink_list != NULL){
    unlink(unlink_list->filename);
    unlink_list = unlink_list->next;
  }
}
