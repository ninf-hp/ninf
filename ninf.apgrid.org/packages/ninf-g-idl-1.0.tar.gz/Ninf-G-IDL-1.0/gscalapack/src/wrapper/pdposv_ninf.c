#define _WRAPPER_
/* $Id: pdposv_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define DOUBLE
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n
#define ROW_b ldb
#define COL_b nrhs
void  pdposv_ninf(	 char uplo,
		 int n,
		 int nrhs,
		 double global_a[],
		 int lda,
		 double global_b[],
		 int ldb,
		 int *info
)
/* "pdposv computes the solution to a real system of linear equations A * X = B, where A denotes A and is an N-by-N symmetric distributed positive definite matrix and X and B denoting B are N-by-NRHS distributed matrices." */
/* OPTIONS */
{
    extern void FortranCall(pdposv)( char*, int*, int*,
				     double*, int*, int*, int*,
				     double*, int*, int*, int*, int*);

	int maxldd;

	int maxlda;
	double *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];

	int maxldb;
	double *locb=NULL;
	int descb[DESCLEN];
	int desc_gb[DESCLEN];

	int row_loca, col_loca;
	int row_locb, col_locb;

	INITIALIZE();

	SCALAR( "char", uplo);
	SCALAR( "int", n);
	SCALAR( "int", nrhs);
	SCALAR( "int", lda);
	SCALAR( "int", ldb);

	ROW( a);
	COL( a);
	ROW( b);
	COL( b);
	MAXLDD( maxldd, a );
	maxlda = maxldd;
	maxldb = maxldd;

	trMATRIX( uplo, "double", a, ROW_a, COL_a);
	MATRIX( "double", b, ROW_b, COL_b);
	trDISTRIBUTE( uplo, "double", a, ROW_a  , COL_a);
	DISTRIBUTE( "double", b, ROW_b  , COL_b);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pdposv)( &uplo, &n, &nrhs,
                              loca, &one, &one, desca,
                              locb, &one, &one, descb, &linfo);

	GATHER( "double", a, ROW_a  , COL_a);
	GATHER( "double", b, ROW_b  , COL_b);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
		*info = linfo;
	} else {
		
	}

	FREE_MATRIX(a);
	FREE_MATRIX(b);
}

