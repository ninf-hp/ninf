package ninf.monitor;
import java.awt.*;
import java.io.*;
import ninf.basic.*;
import ninf.client.*;
import ninf.metaserver.NinfServerHolder;
import ninf.common.*;


class ServerMonitor {
  ServerMonitorPanel panel;
  NinfServerHolder holder;
  ServerLoadMonitor loadMonitor;
  FunctionName[] funcs;
  Monitor monitor;
  static NinfLog dbg = new NinfLog("ServerMonitor");

  ServerMonitor(Monitor monitor, NinfServerHolder holder){
    this.monitor = monitor;
    this.holder = holder;
    loadMonitor = new ServerLoadMonitor(this, holder);
    this.panel = new ServerMonitorPanel(this, holder);
    funcs = monitor.getFuncs(holder.struct);
    (new Thread(loadMonitor)).start();
  }

  void selectFuncs(){
    monitor.selectFuncs(funcs);
  }

  boolean hasFunction(FunctionName func){
    for (int i = 0; i < funcs.length; i++)
      if (funcs[i].equals(func)) return true;
    return false;
  }

  public String toString(){
    return holder.toString();
  }
  
  void repaint(){
    if (panel != null)
      panel.repaint();
  }

  void show(){
    if (panel != null)
      panel.show();
  }

  void dispose(){
    if (panel != null)
      panel.dispose();
  }

  public void print(Object o){
    panel.print(o);
  }

  public void println(Object o){
    panel.println(o);
  }
}
