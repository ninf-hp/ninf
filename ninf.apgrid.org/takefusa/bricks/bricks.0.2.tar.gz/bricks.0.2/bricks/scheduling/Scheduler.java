package bricks.scheduling;
import bricks.environment.*;
import bricks.util.*;
import java.util.*;

public abstract class Scheduler {
    public String key;
    protected double schedulingOverhead;
    protected SimulationSet owner;
    protected String keyOfMetaPredictor;
    protected MetaPredictor metaPredictor;
    protected ResourceDB resourceDB;
    public abstract String getName();

    public abstract void selectHosts (
	double currentTime, Host source, RequestedData data
    ) throws BricksNotScheduledException;

/************************* public method *************************/
    // caller: EPClient
    public void selectHosts(
	double currentTime, Host soruce, EPRequestedData epdata, EPTask eptask
    ) throws BricksNotScheduledException {;}

    public void init(SimulationSet owner) {
	this.owner = owner;
	metaPredictor = owner.getMetaPredictor(keyOfMetaPredictor);
	resourceDB = metaPredictor.getResourceDB();
    }

    public void finishTask(RequestedData data) {
	resourceDB.removeSchedulingInfo(data);
    }

    public void finishTask(EPTask eptask) {
	resourceDB.removeSchedulingInfo(eptask);
    }

    public ResourceDB getResourceDB() {
	return resourceDB;
    }

/************************* protected method *************************/

    protected double getEstimate(
	double currentTime, Host source, Host destination, RequestedData data
    ) {
	// compute Comptation elapsedTime
	double comp = getComputationEstimate(
	    currentTime, destination, data.numInstructions
	);
	    
	// compute Communication elapsedTime: send
	double send = getCommunicationEstimate(
	    currentTime, source, destination, data.dataSizeForSend
	);

	// compute Communication elapsedTime: receive
	double recv = getCommunicationEstimate(
	    currentTime, destination, source, data.dataSizeForReceive
	);

	//System.out.println("elapsedTime: " + 
	SimulationDebug.println(
	    "elapsedTime: " + Format.format(comp+send+recv, 3) + " = " +
	    Format.format(send, 3) + " + " + Format.format(recv, 3) + " + " +
	    Format.format(comp, 3));

	return comp + send + recv;
    }

    protected double getComputationEstimate(
	double currentTime, Host host, double numInstructions
    ) {
	HostInfo hostInfo = metaPredictor.getHostInfo(currentTime, host);
	StaticHostInfo info = resourceDB.getStaticHostInfo(host);
	double performance = info.performance;

	double estimate;
	if (hostInfo.availableCpu < 0.0) {
	    estimate = numInstructions / 
		(performance / (hostInfo.loadAverage + 1.0));
	    
	} else {  // NWS
	    estimate = numInstructions / (performance * hostInfo.availableCpu);
	}
	SimulationDebug.println(hostInfo.toString());
	SimulationDebug.println("bandwidth = " + performance);
	SimulationDebug.println(this + ": " + host + 
				" : host estimate = " + estimate);
	return estimate;
    }

    protected double getCommunicationEstimate(
	double currentTime, Host source, Host destination, double dataSize
    ) {
	NetworkInfo networkInfo = metaPredictor.getNetworkInfo(
	    currentTime, source, destination
	);
	double estimate = dataSize / networkInfo.throughput;
	SimulationDebug.println(
	    this + ": " + source + "-" + destination + 
	    " : network estimate = " + estimate
	);
	return estimate;
    }

    protected void updateStatus(
	double currentTime, Host source, Host destination, RequestedData data
    ) {
	SimulationDebug.println("updateState for single task job");

	/* add scheduling overhead */
	//data.timeEventComes = data.timeEventComes + schedulingOverhead;
	data.timeEventComes = currentTime + schedulingOverhead;

	StaticHostInfo info = resourceDB.getStaticHostInfo(destination);
	data.putDestination(destination, info.priority);
	storeSchedulingInfo(currentTime, source, destination, data);
    }
	
    // for not-scheduled job
    protected  void updateStatus(RequestedData data, double interval) {
	SimulationDebug.println("updateState for rescheduling");
	// add scheduling overhead 
	data.timeEventComes = 
	    data.timeEventComes + schedulingOverhead + interval;
    }

    protected void storeSchedulingInfo(
	double currentTime, Host source, Host destination, RequestedData data
    ) {
	data.putEstimate(
	    getCommunicationEstimate(
	        currentTime, source, destination, data.dataSizeForSend
	    ), 
	    getCommunicationEstimate(
	        currentTime, destination, source, data.dataSizeForReceive
	    ), 
	    getComputationEstimate(
	        currentTime, destination, data.numInstructions
	    )
	);
	metaPredictor.addServerLoad(currentTime, destination, data);
	metaPredictor.addNetworkLoad(currentTime, source, destination, data);
	//metaPredictor.addNetworkLoad(currentTime, destination, source, data);
	resourceDB.putSchedulingInfo(data);
    }

    //for deadline scheduling
    public double getDeadline(double currentTime, RequestedData data) {

	double deadline = currentTime + 
	    (data.numInstructions / resourceDB.aveServerPerformance +
	     (data.dataSizeForSend + data.dataSizeForReceive) /
	     resourceDB.aveNetworkThroughput) * data.deadlineFactor;

	//System.out.println(
	SimulationDebug.println(
	    data + "'s deadline is " + data.deadline + " = " + 
	    currentTime + " + (" + 
	    data.numInstructions + "/" + resourceDB.aveServerPerformance
	    + "+(" + data.dataSizeForSend + "+" + data.dataSizeForReceive +
	    ")/" + resourceDB.aveNetworkThroughput+ ")) * " +
	    data.deadlineFactor
	);
	return deadline;
    }

/************************* for EP scheduling *************************/
    protected void updateStatus(
	double currentTime, EPRequestedData epdata
    ) {
	SimulationDebug.println("updateState for EP exe");
	//epdata.timeEventComes = epdata.timeEventComes + schedulingOverhead;
	epdata.timeEventComes = currentTime + schedulingOverhead;

	Enumeration e = epdata.epTasks();
	while (e.hasMoreElements()) {
	    EPTask task = (EPTask)e.nextElement();
	    if (task.status.equals("SCHEDULED"))
		updateTaskStatus(currentTime, task);
	}
    }

    protected void updateTaskStatus(double currentTime, EPTask eptask) {
	StaticHostInfo info = 
	    resourceDB.getStaticHostInfo((Host)eptask.destination);
	eptask.update(info.priority);
	storeSchedulingInfo(currentTime, eptask);
    }

    protected void storeSchedulingInfo(double currentTime, EPTask eptask) {
	eptask.putEstimate(
	    getCommunicationEstimate(
	        currentTime, eptask.source, eptask.destination, 
		eptask.dataSizeForSend), 
	    getCommunicationEstimate(
	        currentTime, eptask.destination, eptask.source, 
		eptask.dataSizeForReceive), 
	    getComputationEstimate(
	        currentTime, eptask.destination, eptask.numInstructions)
	);
	metaPredictor.addServerLoad(currentTime, eptask);
	metaPredictor.addNetworkLoad(currentTime, eptask);
	resourceDB.putSchedulingInfo(eptask);
    }

    // for deadline scheduling
    /*
    public double getDeadline(double currentTime, EPTask eptask) {
	double deadline = currentTime + 
	    (eptask.numInstructions / resourceDB.aveServerPerformance +
	     (eptask.dataSizeForSend + eptask.dataSizeForReceive) /
	     resourceDB.aveNetworkThroughput) * eptask.deadlineFactor;
	return deadline;
    }
    */
}

