#define _WRAPPER_
/* $Id: pclapiv_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define SCOMPLEX
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n
static	int ipivlen(char rowcol, char pivroc, int m, int n) {
	  int ret=1;

	  //   when ROWCOL='R' or 'r':
	  //      >= LOCr( IA+M-1 ) + MB_A      if PIVROC='C' or 'c',
	  //      >= LOCc( M + MOD(JP-1,NB_P) ) if PIVROC='R' or 'r', and,
	  //   when ROWCOL='C' or 'c':
	  //      >= LOCr( N + MOD(IP-1,MB_P) ) if PIVROC='C' or 'c',
	  //      >= LOCc( JA+N-1 ) + NB_A      if PIVROC='R' or 'r'.
	  //   This array contains the pivoting information. IPIV(i) is the
	  //   global row (column), local row (column) i was swapped with.
	  if (chrcmp(rowcol,'r')==0)
		  ret = m;
	  else
		  ret = n;
	  return ret;
}

static	int iworklen(char rowcol, char pivroc, int m, int n) {
	  int ret=1;
	  int LCM;
	  if ( (chrcmp(rowcol,'R')==0) && (chrcmp(pivroc,'R')==0) ) {
		  ret = 2*n;
	  } else if ( (chrcmp(rowcol,'C')==0) && (chrcmp(pivroc,'C')==0) ) {
		  ret = 2*m;
	  }
	  if NEED_BUFF {
	    LCM=lcm(nprow,npcol);
#define N_P n
#define NB_P rbloc
#define M_P m
#define MB_P cbloc
#define IP 1
#define JP 1
	    if ( (chrcmp(rowcol,'R')==0) && (chrcmp(pivroc,'R')==0) ) {
	      if ( nprow==npcol ) 
		ret = LOCr( N_P + MOD(JP-1, NB_P) ) + NB_P;
	      else
		ret = LOCr( N_P + MOD(JP-1, NB_P) ) +
		  NB_P * CEIL( CEIL(LOCc(N_P),NB_P) , (LCM/NPCOL) );
	    } else if ( (chrcmp(rowcol,'C')==0) && (chrcmp(pivroc,'C')==0) ) {
	      if ( nprow==npcol ) 
		ret = LOCc( M_P + MOD(IP-1, MB_P) ) + MB_P;
	      else
		ret = LOCc( M_P + MOD(IP-1, MB_P) ) +
		  MB_P * CEIL( CEIL(LOCr(M_P),MB_P) , (LCM/NPROW) );
	    }
	  }
	  return ret;
}


void  pclapiv_ninf(	 char direc,
		 char rowcol,
		 char pivroc,
		 int m,
		 int n,
		 scomplex global_a[],
		 int lda,
		 int global_ipiv[]
)
/* "pclapiv applies either P (permutation matrix indicated by IPIV) or inv( P ) to a general M-by-N distributed matrix A, resulting in row or column pivoting." */
/* OPTIONS */
{
	int maxldd;

	int maxlda;
	scomplex *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
	int row_loca, col_loca;

	int *locipiv=NULL;
	int maxldipiv;
	int descipiv[DESCLEN];
	int desc_gipiv[DESCLEN];
	int ROW_ipiv_row;
	int COL_ipiv_col;
        
	int *lociwork=NULL;
	int llociwork;

	INITIALIZE();

	SCALAR( "char", direc);
	SCALAR( "char", rowcol);
	SCALAR( "char", pivroc);
	SCALAR( "int", m);
	SCALAR( "int", n);
	SCALAR( "int", lda);

	ROW( a);
	COL( a);
	MAXLDD( maxldd, a );
	maxlda = maxldd;

	MATRIX( "scomplex", a, ROW_a, COL_a);
	DISTRIBUTE( "scomplex", a, ROW_a  , COL_a);

	if (chrcmp(pivroc,'r')==0) {
	  VECTOR( "c", "int", ipiv, ipivlen(rowcol, pivroc, m, n));
	  Cdescinit( descipiv, ipivlen(rowcol, pivroc, m, n), 1, rbloc, 1, 0, 0,PARA_CTXT, rbloc, &linfo);
	  vDISTRIBUTE( "c","int", ipiv, ipivlen(rowcol, pivroc, m, n));
	} else {
	  VECTOR( "r", "int", ipiv, ipivlen(rowcol, pivroc, m, n));
	  Cdescinit( descipiv, 1, ipivlen(rowcol, pivroc, m, n), 1, cbloc,  0, 0, PARA_CTXT, 1, &linfo);
	  vDISTRIBUTE( "r","int", ipiv, ipivlen(rowcol, pivroc, m,n));
	}

	llociwork = iworklen(rowcol, pivroc, m, n);
	IWORK(lociwork,llociwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pclapiv)( &direc, &rowcol, &pivroc,
                               &m, &n,
                               loca, &one, &one, desca,
                               locipiv, &one, &one, descipiv,
                               lociwork);

	GATHER( "scomplex", a, ROW_a, COL_a);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
	} else {
	}

	FREE_MATRIX(a);
	FREE_VECTOR(ipiv);
        
        FREE(lociwork);
}

