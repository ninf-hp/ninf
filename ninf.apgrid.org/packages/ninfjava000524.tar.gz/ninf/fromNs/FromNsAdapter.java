package ninf.fromNs;
import  ninf.basic.*;
import  ninf.client.*;
import  ninf.netsolve.*;

/**   Adapter for Ninf Server.
      Act as a Netsolve Server and gateway for the NinfServer */

public class FromNsAdapter{
  static FromNsConfig conf;
  
  public static NinfLog dbg = new NinfLog("FromNsAdapter");
  FromNsRoot fromNsRoot; 

  void usage(){
    dbg.println("USAGE: java ninf.fromNs.FromNsAdapter [-port PORT] [-debug] CONFIGFILE");
  }  

  void start(String args[]){
    try {
      conf = new FromNsConfig(args);
      conf.configure();
      fromNsRoot = new FromNsRoot(conf.myhostname, conf.port);
      fromNsRoot.start();
    } catch (ConfigureException ce){
      dbg.log("Error in configuration.");
      if (ce.str != null)
	dbg.log(ce.str);
      System.exit(3);
    } catch (NinfException e){
      usage();
      System.exit(3);
    }
  }

  public static void main(String args[]){
    new FromNsAdapter().start(args);
  }
}
