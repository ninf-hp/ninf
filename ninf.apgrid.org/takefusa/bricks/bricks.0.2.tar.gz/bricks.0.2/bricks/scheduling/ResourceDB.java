package bricks.scheduling;
import bricks.util.*;
import bricks.environment.*;
import java.io.*;
import java.util.*;

public abstract class ResourceDB {

    public String key;
    protected SimulationSet owner;

    protected LookupService lookupService = new LookupService();

    public double aveServerPerformance;
    public double aveNetworkThroughput;

    // key & node info
    protected Hashtable serverState = new Hashtable();
    protected Hashtable networkState = new Hashtable();
    protected int numNetworkHistory = 128;
    protected int numServerHistory = 128;

    protected Hashtable staticHostInfoDB = new Hashtable();
    protected Hashtable staticNetworkInfoDB = new Hashtable();
    protected Hashtable schedulingDB = new Hashtable();

/************************* public method *************************/
    public void init(SimulationSet owner) {

	this.owner = owner;

	SimulationDebug.println("init ServerState in ResourceDB");
	initServerState();
	initStaticHostInfoDB();
	initSchedulingDB();

	SimulationDebug.println("init NetworkState in ResourceDB, size = " +
				owner.routeService.size());
	initNetworkState();
	initStaticNetworkInfoDB();

	initLookupService();
    }

    public void finish() {;}

    public boolean hasData(Host host, String id) {
	return lookupService.hasData(host, id);
    }

    /** returns Vector of hosts which have the data */
    public Vector dataSourceHostList(RequestedData data) {
	String id;
	if ((id = data.requiredDataID) != null) {
	    return lookupService.get(id);
	}
	return null;
    }

    public Vector getFragments(double size) {
	return lookupService.getFragments(size);
    }

    /** returns enumeration of hosts which have the data */
    public Enumeration dataSourceHosts(RequestedData data) {
	String id;
	if ((id = data.requiredDataID) != null) {
	    Vector v = lookupService.get(id);
	    return v.elements();
	}
	return null;
    }

    /** returns enumeration of hosts which do not have the data */
    public Enumeration notDataSourceHosts(RequestedData data) {
	Enumeration e = serverState.keys();
	Vector sourceHosts = lookupService.get(data.requiredDataID);
	if (sourceHosts == null) {
	    return e;
	}
	Vector v = new Vector();
	while(e.hasMoreElements()) {
	    Host host = (Host)e.nextElement();
	    if (!sourceHosts.contains(host)) {
		v.add(host);
	    }
	}
	return v.elements();
    }

    public Enumeration hosts(RequestedData data) {
	return hosts();
    }

    public Enumeration hosts() {
	return serverState.keys();
    }

    // need to modify!!!
    public int numHosts(RequestedData requestedData) {
	return serverState.size();
    }

    public int numHosts() {
	return serverState.size();
    }

    public void putHostInfo(HostInfo hostInfo) {
	RingBuffer buffer = (RingBuffer)serverState.get(hostInfo.owner);
	buffer.put(hostInfo);
    }

    public void putNetworkInfo(NetworkInfo networkInfo) {
	NodePair pair = networkInfo.owner;
	SimulationDebug.println(
	   "Pair[" + pair.source + "-" + pair.destination + "]"
	);
	RingBuffer buffer = (RingBuffer)networkState.get(pair);
	buffer.put(networkInfo);
    }

    public Vector getHostList() {
	Vector v = new Vector(serverState.size());
	Enumeration e = serverState.keys();
	while (e.hasMoreElements()) {
	    v.addElement(e.nextElement());
	}
	return v;
    }

    public StaticHostInfo getStaticHostInfo(Host host) {
	try {
	    return (StaticHostInfo)staticHostInfoDB.get(host);
	} catch (NullPointerException e) {
	    return null;
	}
    }

    public HostInfo getHostInfo(Host host) {
	try {
	    RingBuffer buffer = (RingBuffer)serverState.get(host);
	    HostInfo info = (HostInfo)buffer.get();
	    if (info == null)
		info = new HostInfo(host, 1.0);
	    return info;

	} catch (NullPointerException e) {
	    return null;
	}
    }

    public NetworkInfo getNetworkInfo(NodePair pair) {
	/* debug 
	System.out.println("pair = " + pair);
	System.out.println("networkState.keys() = ");
	Enumeration e = networkState.keys();
	while (e.hasMoreElements())
	    System.out.print(e.nextElement() + " ");
	*/
	RingBuffer buffer = (RingBuffer)networkState.get(pair);
	NetworkInfo info = (NetworkInfo)buffer.get();
	if (info == null) {
	    StaticNetworkInfo sinfo = 
		(StaticNetworkInfo)staticNetworkInfoDB.get(pair);
	    //System.out.println(pair + " - " + sinfo);
	    info = new NetworkInfo(pair, sinfo.maxThroughput / 2.0);
	}
	return info;
    }

    public NetworkInfo getNetworkInfo(Node source, Node destination) {
	NodePair pair = new NodePair(source, destination);
	return getNetworkInfo(pair);
    }

    public NetworkInfo getNetworkInfoAt(
	Node source, Node destination, int index
    ) {
	NodePair pair = new NodePair(source, destination);
	return getNetworkInfoAt(pair, index);
    }

    public NetworkInfo getNetworkInfoAt(NodePair pair, int index) {
	RingBuffer buffer = (RingBuffer)networkState.get(pair);
	return (NetworkInfo)buffer.get(index);
    }

    public void putSchedulingInfo(RequestedData data) {
	Vector v = (Vector)schedulingDB.get(data.destination);
	v.addElement(data);
    }

    public void putSchedulingInfo(EPTask eptask) {
	Vector v = (Vector)schedulingDB.get(eptask.destination);
	v.addElement(eptask);
    }

    public Vector getSchedulingInfo(Host host) {
	return (Vector)schedulingDB.get(host);
    }

    public void removeSchedulingInfo(RequestedData data) {
	Vector v = (Vector)schedulingDB.get(data.destination);
	v.removeElement(data);
    }

    public void removeSchedulingInfo(EPTask eptask) {
	Vector v = (Vector)schedulingDB.get(eptask.destination);
	v.removeElement(eptask);
    }

    /******************** for LookupService ********************/
    /** get hosts storing the data fragment */
    /*
    public Vector lookupHosts(String id) {
	return lookupService.get(id);
    }
    */

    public void initLookupService() {
	Enumeration e = serverState.keys();
	while (e.hasMoreElements()) {
	    Host host = (Host)e.nextElement();
	    lookupService.init(host);
	}
	SimulationDebug.println(lookupService);
    }

    public void addFragmentInto(Host host, DataFragment fragment) {
	lookupService.addFragmentInto(host, fragment);
    }

    public void removeFragmentFrom(Host host, String id) {
	lookupService.removeFragmentFrom(host, id);
    }

    public int howManyReplicas(DataFragment fragment) {
	return lookupService.howManyReplicas(fragment);
    }

/************************* protected method *************************/
    protected void initServerState() {
	SimulationDebug.println("initServerState: numHosts = " + owner.numHosts());
	Enumeration e = owner.hosts();
	while (e.hasMoreElements()) {
	    Host host = (Host)e.nextElement();
	    if (host.isServer()) {
		RingBuffer buffer = new RingBuffer(numServerHistory);
		serverState.put(host, buffer);
		SimulationDebug.println(host + " is Server.");
	    }
	}
    }

    protected void initStaticHostInfoDB() {

	Enumeration e = serverState.keys();
	aveServerPerformance = 0.0;
	while (e.hasMoreElements()) {
	    Host host = (Host)e.nextElement();
	    StaticHostInfo info = host.getStaticHostInfo();
	    staticHostInfoDB.put(host, info);
	    aveServerPerformance = aveServerPerformance + info.performance;
	}
	aveServerPerformance = aveServerPerformance / staticHostInfoDB.size();
    }

    protected void initNetworkState() {

	Enumeration e = owner.routes();
	//SimulationDebug.println("- init NetworkState in ResourceDB");
	while (e.hasMoreElements()) {
	    NodePair pair = (NodePair)e.nextElement();
	    //SimulationDebug.println("init pair: " + pair + " at ResourceDB");
	    RingBuffer buffer = new RingBuffer(numNetworkHistory);
	    networkState.put(pair, buffer);
	}
    }

    protected void initStaticNetworkInfoDB() {

	Enumeration e = owner.routes();
	aveNetworkThroughput = 0.0;
	int numRoutes = 0;
	while (e.hasMoreElements()) {

	    NodePair pair = (NodePair)e.nextElement();
	    if (((pair.source instanceof Host) && 
		 (pair.destination instanceof Host))) {

		double throughput = 
		    getMinThroughput(pair.source, pair.destination);
		staticNetworkInfoDB.put(
		    pair, new StaticNetworkInfo(pair, throughput)
		);
		aveNetworkThroughput = aveNetworkThroughput + throughput;
		numRoutes++;
	    }
	}
	aveNetworkThroughput = aveNetworkThroughput / numRoutes;
	SimulationDebug.println("aveNetworkThroughput = " + aveNetworkThroughput);
    }

    protected double getMinThroughput(Node source, Node destination) {
	Vector route = owner.getRoute(source, destination);
	double throughput = 0.0;
	for (int i = route.size() - 2; i > 0 ; i--) {
	    Node node = (Node)route.elementAt(i);
	    if (node instanceof Network) {
		Network network = (Network)node;
		if (throughput < network.queue.maxThroughput) {
		    throughput = network.queue.maxThroughput;
		}
	    }
	}
	//System.out.println("minThroughput = " + throughput);
	return throughput;
    }

    protected void initSchedulingDB() {
	Enumeration e = serverState.keys();
	while (e.hasMoreElements()) {
	    Host host = (Host)e.nextElement();
	    Vector tmp = new Vector(100);
	    schedulingDB.put(host, tmp);
	}
    }
}
