package ninf.cproxy;
import ninf.basic.*;
import ninf.client.*;
import ninf.cproxy.aggregate.*;

public interface ScheduleProvider{
  public ServerIndex schedule(NinfStub stub, CallContext callContext, int serial)
       throws NinfException;
  public AggregateScheduled aggregateSchedule(FuncNode funcNodes[], 
				       DataNode dataNodes[], int serial)
    throws NinfException;
  public void done(int serial) throws NinfException;
  public int getSerial();
}
