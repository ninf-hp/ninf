package ninf.client;

import java.io.IOException;
import java.io.*;
import java.net.*;
import java.util.Vector;
import ninf.basic.*;
import ninf.common.*;

abstract public class NinfConnection {
  public XDRInputStream is;
  public XDROutputStream os;
  OutputStream stdoutStream, stderrStream;
  NinfExecInfo execInfo;
  NinfLog dbg = new NinfLog(this);
  boolean withHeader = true;

  abstract public NinfStub getStub(String stubname) throws NinfException;

  NinfExecInfo callBody(NinfStub currentStub, Vector args) 
       throws NinfException {
    CallContext context;
    context = currentStub.transformArgs(args);
    currentStub.sendArgs(context, 
			 new NinfPacketOutputStream(os, true, withHeader), 
			 new int[currentStub.nparam][]);
    receive(currentStub, context);

    currentStub.reverseTrans(context, args);
    return execInfo;
  }

  void receive(NinfStub currentStub, CallContext context) 
  throws NinfException{
    int ack;
    XDRInputStream istream = 
      new XDRInputStream(
      new NinfPacketInputStream(is, stdoutStream, stderrStream, withHeader));
    NinfPacketOutputStream ostream = 
      new NinfPacketOutputStream(os, true, withHeader);
    try {
      while (true){
	ack = istream.readInt();
	switch(ack){
	case NinfStub.NINF_ACK_OK:
	  currentStub.receive(context, istream);
	  if (execInfo == null)
	    execInfo = new NinfExecInfo();
	  execInfo.read_data(istream);
	  execInfo.end();
	  execInfo.calc_client_exec();
	  return;
	case NinfStub.NINF_CALLBACK:
	  currentStub.callback(istream, ostream);
	  break;
	case NinfStub.NINF_ACK_ERROR:
	  /* read error code */
	  int errorCode = istream.readInt();
	  throw new NinfErrorException(errorCode);
	default:
	  dbg.println("ack = " + ack);
	  throw new NinfTypeErrorException();
	}
      }
    } catch (IOException e) {throw new NinfIOException(e);}
  }

  public abstract void close() throws NinfException;

}
