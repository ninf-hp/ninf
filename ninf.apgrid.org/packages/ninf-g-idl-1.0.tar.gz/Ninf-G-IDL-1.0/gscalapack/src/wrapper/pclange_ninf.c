#define _WRAPPER_
/* $Id: pclange_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define SCOMPLEX
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n
static	int worklen(int m, int n) {
	  int ret=1;
	  int IROFFA,ICOFFA, IAROW, IACOL,Mp0, Nq0;
#define IA 1
#define JA 1
#define MB_A rbloc
#define NB_A cbloc
#define RSRC_A 0
#define CSRC_A 0
#define NPROW nprow
#define NPCOL npcol
	  ret = max(m,max(n,m));
	  if NEED_BUFF {
	    IROFFA = MOD( IA-1, MB_A );
	    ICOFFA = MOD( JA-1, NB_A );
	    IAROW = INDXG2P( IA, MB_A, MYROW, RSRC_A, NPROW );
	    IACOL = INDXG2P( JA, NB_A, MYCOL, CSRC_A, NPCOL );
	    Mp0 = NUMROC( M+IROFFA, MB_A, MYROW, IAROW, NPROW );
	    Nq0 = NUMROC( N+ICOFFA, NB_A, MYCOL, IACOL, NPCOL );
	    ret = max(m,max(Nq0,Mp0));
	  }
	  return ret;
}

void  pclange_ninf(	 char norm,
		 int m,
		 int n,
		 scomplex global_a[],
		 int lda,
		 float work[],
		 float *ret /* return value */
)
/* "pclange returns the value of the one norm, or the Frobenius norm, or the infinity norm, or the element of largest absolute value of a distributed matrix A." */
/* OPTIONS */
{
  extern float FortranCall(pclange)(char*, int*, int*, scomplex*, int*, int*, int*,     float*);

	int maxldd;

	int maxlda;
	scomplex *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
	int row_loca, col_loca;

	float *locwork=NULL;
	int llocwork;

	float locpclange_[1];


	INITIALIZE();

	SCALAR( "char", norm);
	SCALAR( "int", m);
	SCALAR( "int", n);
	SCALAR( "int", lda);

	ROW( a);
	COL( a);
	MAXLDD( maxldd, a );
	maxlda = maxldd;

	MATRIX( "scomplex", a, ROW_a, COL_a);
	DISTRIBUTE( "scomplex", a, ROW_a, COL_a);

	llocwork = worklen(m, n);
	_work("float", &locwork,llocwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranReturnSimple(pclange, locpclange_,
                       ( &norm, &m, &n,
                       loca, &one, &one, desca,
                       locwork ) );

	RETRIEVE("float", locpclange_, 1);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){

	  *ret = *locpclange_;
	} else {
		
	}

	FREE_MATRIX(a);
        FREE(locwork);
	
}

