#define _WRAPPER_
/* $Id: psdttrf_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define _DISTRIBUTE_1D_
#define NO_PIVOT
#define FLOAT
#include <gscalapack.h>

#define ROW_af laf
#define COL_af n
static	int worklen() {
	  int ret=1;
	  ret = 8;
	  if NEED_BUFF ret = 8*npcol;
	  return ret;
}

void  psdttrf_ninf(	 int n,
		 float global_dl[],
		 float global_d[],
		 float global_du[],
		 float af[],
		 int dummy_laf,
		 float work[],
		 int lwork,
		 int *info
)
/* "psdttrf computes a LU factorization of an N-by-N real tridiagonal diagonally dominant-like distributed matrix A." */
/* OPTIONS */
{
    extern void FortranCall(psdttrf)( int*,
                               float*, float*, float*, int*, int*,
                               float*, int*,
                               float*, int*, int*);

	int maxldd;

	float *locdl=NULL, *locd=NULL, *locdu=NULL;
	int desctdd[DESCLEN];
	int desc_gtdd[DESCLEN];

	float *locaf=NULL;
	float *global_af=NULL;
	int maxldaf;
	int descaf[DESCLEN];
	int desc_gaf[DESCLEN];
	int laf,llocaf;
	int row_locaf, col_locaf;
	
	float *locwork=NULL;
	int llocwork;

	INITIALIZE();

	SCALAR( "int", n);
	SCALAR( "int", lwork);
	SCALAR("int", dummy_laf);

	SIZE(n);

	laf = 2*(blocsize+2)*nprocs/n;
	llocaf = laf*blocsize;
	if (mypnum==0) {
	  global_af=MALLOC(sizeof(float)*laf*n);
          assert(global_af);
	}

	ROW(af);
	COL(af);
	MAXLDD( maxldd, af);
	maxldaf=maxldd;

	tdMATRIX( "float", dl, d, du, n);
	tdDISTRIBUTE( "float",  dl, d, du, n);
	MATRIX("float",  af, ROW_af, COL_af);

	llocwork = worklen();
        llocwork = max(lwork,llocwork);
	WORK(locwork,llocwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(psdttrf)( &n,
                               locdl, locd, locdu, &one, desctdd,
                               locaf, &llocaf,
                               locwork, &llocwork, &linfo);

	tdGATHER( "float", dl, d, du, n);
	GATHER("float",  af, ROW_af, COL_af);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
	  int i;
	  *info = linfo;
	  for(i=0;i<dummy_laf;i++) af[i] = global_af[i];
          FREE(global_af);
	} else {
	}
	FREE_MATRIX(dl);
	FREE_MATRIX(d);
	FREE_MATRIX(du);
	FREE_MATRIX(af);
        FREE(locwork);
	
}

