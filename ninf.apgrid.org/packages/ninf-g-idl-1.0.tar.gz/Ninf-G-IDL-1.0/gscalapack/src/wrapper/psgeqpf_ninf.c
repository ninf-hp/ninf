#define _WRAPPER_
/* $Id: psgeqpf_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define FLOAT
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n
static	int worklen(int m, int n) {
	  int ret=1;
	  int IROFF, ICOFF, IAROW, IACOL, Mp0, Nq0, LOC;
	  ret = MAX(3,m + n) + n +n;
	  if NEED_BUFF {
#define IA 1
#define JA 1
#define MB_A MB
#define NB_A NB
#define MYROW myprow
#define MYCOL mypcol
#define NPROW nprow
#define NPCOL npcol
#define RSRC_A 0
#define CSRC_A 0
	    IROFF = MOD( IA-1, MB_A );
	    ICOFF = MOD( JA-1, NB_A );
	    IAROW = INDXG2P( IA, MB_A, MYROW, RSRC_A, NPROW );
	    IACOL = INDXG2P( JA, NB_A, MYCOL, CSRC_A, NPCOL );
	    Mp0   = NUMROC( M+IROFF, MB_A, MYROW, IAROW, NPROW );
	    Nq0   = NUMROC( N+ICOFF, NB_A, MYCOL, IACOL, NPCOL );
	    LOC = NUMROC( JA+N-1, NB_A, MYCOL, CSRC_A, NPCOL );
	    ret = MAX(3,Mp0 + Nq0) + LOC +Nq0;
	  }
	  return ret;
}

#ifdef X
	int ipivlen() {
	  int ret=1;
	  if (mypnum !=0) {
#define LOCc(n) Cnumroc( (n), cbloc, mypcol, 0, npcol)
	    ret = LOCc(JA+N-1);
	  }
	  return ret;
	}
#endif

void  psgeqpf_ninf(	 int m,
		 int n,
		 float global_a[],
		 int lda,
		 int global_ipiv[],
		 float global_tau[],
		 float work[],
		 int *info
)
/* "psgeqpf computes a QR factorization with column pivoting of a M-by-N distributed matrix A: A * P = Q * R." */
/* OPTIONS */
{
        
	int maxldd;

	int maxlda;
	float *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
	int row_loca, col_loca;

	int *locipiv=NULL;

	float *loctau=NULL;

	float *locwork=NULL;
	int llocwork;

	INITIALIZE();

	SCALAR( "int", m);
	SCALAR( "int", n);
	SCALAR( "int", lda);

	ROW( a);
	COL( a);

	MAXLDD( maxldd, a );
	maxlda = maxldd;

	MATRIX( "float", a, ROW_a, COL_a);
	DISTRIBUTE( "float", a, ROW_a  , COL_a);

	VECTOR( "c" , "int", ipiv, n );
	VECTOR( "c", "float", tau,min(m,n) );

	llocwork = worklen(m, n);
	WORK(locwork, llocwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(psgeqpf)( &m, &n,
                               loca, &one, &one, desca,
                               locipiv,
                               loctau,
                               locwork, &llocwork, &linfo);

	GATHER( "float", a, ROW_a  , COL_a);

	vGATHER( "c", "int", ipiv, n);
	vGATHER( "c", "float", tau, min(m,n));

	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
		*info = linfo;
	} else {
	}

	FREE_MATRIX(a);
	FREE_VECTOR(ipiv);
	FREE_VECTOR(tau);
        FREE(locwork);
	
}

