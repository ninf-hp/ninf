/************************
generic utility library 

nslib_list:
nslib_map:  

*************************/

#include <stdio.h>
#include "nslib_utils.h"

/** list: automatic growing list */

static boolean nslib_list_default_compare(void *v0, void *v1);

nslib_list_t * 
nslib_list_new_init(
    boolean (* compare)(void *, void *),
    int initial, 
    int grow
)
{
    /* �ꥹ���Ѥ��ΰ����ݤ��롣   */
    nslib_list_t * tmp = MY_MALLOC(nslib_list_t);
    if ( tmp == NULL ) {
        return NULL;
    }

    if ( compare != NULL ) {
        tmp->compare = compare;
    } else {
        tmp->compare = nslib_list_default_compare;
    }

    /* ������������ǥå����ν�������Ԥ� */
    tmp->size = initial;
    tmp->grow = grow;
    tmp->index = 0;

    /* �����ΰ�γ���   */
    tmp->contents = (void **)malloc(sizeof(void *) * tmp->size);

    if ( tmp->contents == NULL ) {
        MY_FREE(tmp);
        return NULL;
    }
    return tmp;
}

nslib_list_t * 
nslib_list_new(
    boolean (* compare)(void *, void *)
)
{
    /* �ꥹ�Ȥν������Ԥ���   */
    return nslib_list_new_init(compare,
        NSLIB_LIST_DEFAULT_INITIAL,
        NSLIB_LIST_DEFAULT_GROW);
}

void 
nslib_list_destruct(
    nslib_list_t *list
)
{
    /* �ꥹ�ȤΥ��ꥢ   */
    MY_FREE(list->contents);
    MY_FREE(list);
}

void 
nslib_list_clear(
    nslib_list_t *list
)
{
  list->index = 0;
}



/*** get a content **/
void * 
nslib_list_at(
    nslib_list_t *list, 
    int i
)
{
    /* �оݥꥹ�Ȥλ���ǡ������֤����ƥݥ��󥿤��ֵѤ��롣 */
    return *((list->contents) + i);
}

/**  replace content **/
void 
nslib_list_at_put(
    nslib_list_t *list, 
    int i, 
    void *element
)
{
    /* �ꥹ�Ȥ�i�ΰ��֤˥�����Ȥ��ִ�����    */
    *((list->contents) + i) = element;
}

static boolean nslib_list_grow(nslib_list_t * list){
  void ** tmp;

  list->size += list->grow;
  tmp = (void **)REALLOC(list->contents, 
			 sizeof(void *) * list->size);
  if (tmp == NULL){
    return FALSE;
  }
  if (tmp != list->contents){
    memcpy(tmp, list->contents, list->size * sizeof(void *));
  }
  list->contents = tmp;
  return TRUE;
}

/** insert an item at the top of the list */
boolean 
nslib_list_add_first(
    nslib_list_t *list, 
    void * val
)
{
    int i;           /* �롼�ץ�����   */

    /* �ꥹ���ΰ�γ��� */
    if ( list->index >= list->size ) {
      if (!nslib_list_grow(list))
	return FALSE;
    }
    /* �ꥹ�ȹ��ܤ���Ƭ������   */
    for ( i = list->index; i >= 0 ; i-- ) {
        * ((list->contents) + i + 1) = * ((list->contents) + i);
    }
    *((list->contents) + 0) = val;
    list->index ++;
    return TRUE;
}

/* add an item at the last of the list*/
boolean
nslib_list_add(
    nslib_list_t *list, 
    void *val
)
{
    /* �ɲä����ΰ褬�ʤ���С��ΰ�γ�ĥ   */
    if ( list->index >= list->size ) {
      if (!nslib_list_grow(list))
	return FALSE;
    }
    /* �ͤ��ɲ� */
    *((list->contents) + ((list->index ++))) = val;
    return TRUE;
}

/** get the size */
int 
nslib_list_size(
    nslib_list_t *list
)
{
    return list->index;
}

/** iterate */
void 
nslib_list_foreach(
    nslib_list_t *list, 
    void(* func)(void *)
)
{
    int i;    /* �롼�ץ����� */

    /* ���ƤΥꥹ�ȹ��ܤ��Ф��ƽ�����Ԥ�   */
    for ( i = 0; i < nslib_list_size(list); i++ ) {
        /* �ꥹ�ȹ��ܤ��Ф��ơ�����ν�����¹Ԥ��� */
        (* func)(nslib_list_at(list, i));
    }
}

/* find an item matches the func */
void * 
nslib_list_find (
    nslib_list_t *list, 
    nslib_boolean_func_t *func
)
{
    int i;    /* �롼�ץ����� */
    /* ���ƤΥꥹ�ȹ��ܤ��Ф��ƽ�����Ԥ�   */
    for ( i = 0; i < nslib_list_size(list); i++ ) {
        
        /* �ꥹ�ȹ��ܤ��Ф��ơ�����ν�����¹Ԥ��� */
        void * tmp = nslib_list_at(list, i);

        /* Boolean�ؿ��μ¹�    */
        if ( nslib_boolean_func_call(func, tmp) ) {
            return tmp;
        }
    }
    return NULL;
}

/* remove item */
boolean 
nslib_list_remove(
    nslib_list_t *list, 
    void *target
)
{
    int i;                        /* �롼�ץ�����         */
    
    /* �оݥꥹ�ȹ��ܤθ��� */
    for ( i = 0; i < nslib_list_size(list); i++ ) {
        void * tmp = nslib_list_at(list, i);
        if ( tmp == target ) {
            break;
        }
    }

    /* shift  */
    for ( ; i < nslib_list_size(list) - 1; i++ ) {
        void * tmp = nslib_list_at(list, i + 1);
        nslib_list_at_put(list, i, tmp);
    }

    /* ����ǥå���������   */
    if ( i < list->index ) {
        list->index = i;
        return TRUE;
    }
    return FALSE;
}

/* remove all */
boolean
nslib_list_remove_all(
    nslib_list_t *list, 
    nslib_list_t *target_list
)
{
  int i;
  for (i = 0; i < nslib_list_size(target_list); i++){
    void * target = nslib_list_at(target_list, i);
    if (!nslib_list_remove(list, target))
      return FALSE;
  }
  return TRUE;
}

/** remove item */
boolean 
nslib_list_includes(
    nslib_list_t *list, 
    void *val
)
{
    int i;                        /* �롼�ץ�����         */

    /* ���ƤΥꥹ�ȹ��ܤ��Ф��ƽ�����Ԥ�   */
    for ( i = 0; i < nslib_list_size(list); i++ ) {
        /* �����оݥꥹ�ȹ��ܤǤ��뤫Ƚ��   */
        if ( (*(list->compare))(nslib_list_at(list, i), val) ) {
            return TRUE;
        }
    }
    return FALSE;
}

/***  STATIC  */

/*--------------------------------------------------------------------------*/
/* ID       =   nslib_list_default_compare                                  */
/* name     =   �ѿ������                                                  */
/* func     =   �ѿ�����Ӥ�Ԥ�                                            */
/* called   =   static boolean nalib_list_default_compare(                  */
/*                                      void *v0, void *v1)                 */
/* io       =   v0:void *:I:����ѿ���                                      */
/*              v1:void *:I:����ѿ���                                      */
/* return   =   TRUE:����                                                   */
/*              FALSE:������                                                */
/* using    =   �ʤ�                                                        */
/* common   =   �ʤ�                                                        */
/* note     =   �ʤ�                                                        */
/* data     =   2001.01.19 by NTTSOFT                                       */
/*--------------------------------------------------------------------------*/
static boolean 
nslib_list_default_compare(
    void *v0, 
    void *v1
)
{
    /* ����ѿ�����Ӥ�Ԥ� */
    return (v0 == v1);
}

/*********************************
boolean: boolean func object

struct nslib_boolean_func {
void * user_data;
boolean(* func)(void * user_data, void * )
};
*********************************/

boolean 
nslib_boolean_func_call(
    nslib_boolean_func_t *func, 
    void *val
)
{
    /* boolean�ؿ��μ¹�    */
    return (*(func->func))(func->user_data, val);
}

/*********************************/
/*             pair              */
/*********************************/

nslib_pair_t * 
nslib_pair_new(
    void *key, 
    void *val
)
{
    /* �ڥ�������ΰ����   */
    nslib_pair_t * tmp = MY_MALLOC(nslib_pair_t);
    if ( tmp == NULL ) {
        return NULL;
    }
    /* �ڥ�����ν������   */
    tmp->key = key;
    tmp->val = val;
    return tmp;
}

void nslib_pair_destruct(nslib_pair_t * pair){
  free(pair);
}

struct pair_find_struct {
    void * target;
    boolean (* compare)(void *, void *);
};

/*--------------------------------------------------------------------------*/
/* ID       =   local_pair_find_func                                        */
/* name     =   �ڥ���������                                              */
/* func     =   �ڥ��������Ӥ���                                          */
/* called   =   static boolean local_pair_find_func(void *user_data,        */
/*                                                  void *pair_v)           */
/* io       =   user_data:void *:I:�ڥ�����                                 */
/*              pair_v:void *:I:�ڥ�����                                    */
/* return   =   TRUE:����                                                   */
/*              FALSE��������                                               */
/* using    =   �ʤ�                                                        */
/* common   =   �ʤ�                                                        */
/* note     =   �ʤ�                                                        */
/* data     =   2001.01.19 by NTTSOFT                                       */
/*--------------------------------------------------------------------------*/
static boolean 
local_pair_find_func(
    void *user_data, 
    void *pair_v
)
{
    /* �ڥ���������   */
    struct pair_find_struct * st = (struct pair_find_struct *)user_data;
    nslib_pair_t * pair = (nslib_pair_t *)pair_v;
    return (*(st->compare))(st->target, pair->key);
}


int DEFAULT_MAP_HASH(void * a){
  return ((int)a) >> 3;
}

int DEFAULT_MAP_COMPARE(void * a, void * b){
  return a == b;
}

/*********************************
map: something like java.util.Map
typedef struct nslib_map {
int (* compare)(void *, void *);
nslib_list_t * list;
} nslib_map_t;
**********************************/

nslib_map_t * 
nslib_map_new(
    boolean (* compare)(void *, void *),
    int     (* hash)(void *)   
)
{
    /* �ޥåפ����� */
    return nslib_map_new_init(compare, hash,
        DEFAULT_ENTRYS,
        NSLIB_LIST_DEFAULT_INITIAL,
        NSLIB_LIST_DEFAULT_GROW);
}

nslib_map_t * 
nslib_map_new_default(){
    /* �ޥåפ����� */
    return nslib_map_new_init(
        DEFAULT_MAP_COMPARE,
        DEFAULT_MAP_HASH,
        DEFAULT_ENTRYS,
        NSLIB_LIST_DEFAULT_INITIAL,
        NSLIB_LIST_DEFAULT_GROW);
}


nslib_map_t * 
nslib_map_new_init(
    boolean (* compare)(void *, void *),
    int     (* hash)(void *),
    int entry_size,
    int list_size, 
    int grow
)
{
    int i;
    /* �ޥåפ��ΰ���� */
    nslib_map_t * tmp = MY_MALLOC(nslib_map_t);
    if ( tmp == NULL ) {
        return NULL;
    }
    tmp->lists = (nslib_list_t **) malloc(sizeof(nslib_list_t *) * entry_size);
    for (i = 0; i < entry_size; i++){
      nslib_list_t * list = nslib_list_new_init(NULL, list_size, grow);
      if (list == NULL) return NULL;
      *((tmp->lists) + i) = list;
    }
    /* �ޥåפν����   */
    tmp->hash    = hash;
    tmp->compare = compare;
    tmp->entry_size = entry_size;
    return tmp;
}

void 
nslib_map_destruct( nslib_map_t *map){
  int i, j;
  for (i = 0; i < map->entry_size; i++){
    nslib_list_t * list = *(map->lists + i);
    for (j = 0; j < nslib_list_size(list); j++){
      nslib_pair_t * pair = (nslib_pair_t *)(nslib_list_at(list, j));
      nslib_pair_destruct(pair);
    }
    nslib_list_destruct(list);
  }
  free(map->lists);
  free(map);
}

/** just clear all contents **/
void 
nslib_map_clear( nslib_map_t *map){
  int i, j;
  for (i = 0; i < map->entry_size; i++){
    nslib_list_t * list = *(map->lists + i);
    for (j = 0; j < nslib_list_size(list); j++){
      nslib_pair_t * pair = (nslib_pair_t *)(nslib_list_at(list, j));
      nslib_pair_destruct(pair);
    }
    nslib_list_clear(list);
  }
}

void 
nslib_map_put(
    nslib_map_t *map, 
    void *key, 
    void *val
)
{
    nslib_list_t * list;
    int index;

    /* �ڥ����������   */
    nslib_pair_t * pair = nslib_pair_new(key, val);

    index = (map->hash)(key) % (map->entry_size);
    list = *(map->lists +index);

    /* �ꥹ�Ȥؤ��ͤ��ɲ�   */
    nslib_list_add(list, pair);
}

void * 
nslib_map_get(
    nslib_map_t *map, 
    void *key
)
{
    nslib_pair_t * pair;              /* �ڥ�����  */
    nslib_boolean_func_t pair_find;   /* ��������  */
    struct pair_find_struct str;      /* ��������  */
    nslib_list_t * list;
    int index;

    str.target = key;
    str.compare = map->compare;
    pair_find.user_data = &str;
    pair_find.func = local_pair_find_func;

    index = (map->hash)(key) % (map->entry_size);
    list = *(map->lists +index);

    /* ���̻Ҥ���ޥå׹��ܤ򸡺�   */
    pair = (nslib_pair_t * )nslib_list_find(list, & pair_find);
    if ( pair == NULL ) {
        return NULL;
    }
    return pair->val;
}

void * 
nslib_map_remove(
    nslib_map_t *map, 
    void *key
)
{
    nslib_pair_t * pair;              /* �ڥ�����  */
    nslib_boolean_func_t pair_find;   /* ��������  */
    struct pair_find_struct str;      /* ��������  */
    nslib_list_t * list;
    int index;

    str.target = key;
    str.compare = map->compare;
    pair_find.user_data = &str;
    pair_find.func = local_pair_find_func;

    index = (map->hash)(key) % (map->entry_size);
    list = *(map->lists +index);

    /* ���̻Ҥ���ޥå׹��ܤ򸡺�   */
    pair = (nslib_pair_t * )nslib_list_find(list, &pair_find);
    if ( pair == NULL ) {
        return NULL;
    }

    /* �ꥹ�ȹ��ܤκ�� */
    nslib_list_remove(list, pair);
    nslib_pair_destruct(pair);
    return pair->val;
}

nslib_list_t * nslib_map_keys(nslib_map_t * map){
  int i, j;
  nslib_list_t * keys = nslib_list_new(map->compare);
  nslib_list_t * list;

  for (i = 0; i < map->entry_size; i++){
    list = *(map->lists + i);
    for (j = 0; j < nslib_list_size(list); j++){
      nslib_pair_t * pair = (nslib_pair_t *)(nslib_list_at(list, j));
      nslib_list_add(keys, pair->key);
    }
  }
  return keys;
}

int 
nslib_map_size(
    nslib_map_t *map
)
{
  int sum = 0, i;

  for (i = 0; i < map->entry_size; i++)
    sum += nslib_list_size(*(map->lists + i));
  return sum;
}




void *
nslib_my_malloc(
    int size
)
{
    void *p;  /* �ΰ�����ѥݥ��� */

    p = (void *)malloc(size);
    if ( p == NULL ) {
        /* �ΰ���ݤ˼��Ԥ����Ȥ� */
        perror("can't allocate memory");
    }
    return p;
}

#if 0

/** test main */
/** �ʲ����ƥ����Ѵؿ��� */
#include <string.h>

void print_str(void * str) {
    fprintf(stderr, "%s\n", (char *)str);
}

boolean my_strcmp(void * a, void * b) {
    return !(strcmp((char *) a, (char *) b));
}

void test_list() {
    char * str1 = "str1";
    nslib_list_t * list = nslib_list_new_init(my_strcmp, 1, 1);
    nslib_list_add(list, "str0");
    nslib_list_add(list, str1);
    nslib_list_add(list, "str2");

    nslib_list_foreach(list, print_str);

    fprintf(stderr, "list includes %s is %s\n", "str1", 
    nslib_list_includes(list, "str1")? "true": "false" );

    fprintf(stderr, "list includes %s is %s\n", "str5", 
    nslib_list_includes(list, "str5")? "true": "false" );


    fprintf(stderr, "removing %s \n", str1);
    nslib_list_remove(list, str1);

    nslib_list_foreach(list, print_str);    

}

void test_map() {
    nslib_map_t * map = nslib_map_new(my_strcmp);
    nslib_map_put(map, "key0", "val0");
    nslib_map_put(map, "key1", "val1");
    nslib_map_put(map, "key2", "val2");

    fprintf(stderr, "map_get(%s) = %s\n", "key1", (char *)(nslib_map_get(map, "key1")));
}

int main() {
    test_list();
    test_map();
    return 0;
}

#endif
