package bricks.environment;
import bricks.util.Format;

public class StaticHostInfo {

    public Host owner;
    public double performance;
    public int priority;
    public double diskThroughput = Double.NEGATIVE_INFINITY;

    public StaticHostInfo(Host owner, double performance) {
	this.owner = owner;
	this.performance = performance;
	this.priority = (int)performance;
    }

    public String toString() {
	return "StaticHostInfo[" + owner + " " +
	    Format.format(performance, 3) + " " + priority;
    }

    public void setDiskThroughput(double throughput) {
	this.diskThroughput = throughput;
    }
}
