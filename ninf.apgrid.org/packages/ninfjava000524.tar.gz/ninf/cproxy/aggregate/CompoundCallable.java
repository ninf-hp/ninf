package ninf.cproxy.aggregate;
import ninf.cproxy.*;
import ninf.basic.*;
import ninf.common.*;
import ninf.client.*;


import java.io.IOException;
import java.util.Vector;

public class CompoundCallable extends Callable implements Stoppable {
  static int counter = 0;

  // *********************** NON STATIC VARIABLES ***********************
  CallContext callContext;

  /**  Vector of indexlist correspond to funcs */
  NinfDataflow dataflows[];
  NinfCommonData commonData[];
  NativeCallable funcs[];
  CallContext subContexts[];
  int argNums[];
  NinfStub stub;
  CallableCache callableCache;
  ScheduleProvider master;
  NinfLog dbg = new NinfLog(this);
  Vector threads = new Vector();
  boolean finished = false;
  boolean aggregateSchedule = false;
  ServerID myID;


  /** Construct from packet, stream, and manager */
  public CompoundCallable(NinfPacket p, XDRInputStream is, 
			  CallableCache callableCache, ScheduleProvider master,
			  boolean aggregateSchedule, ServerID myID) 
  throws NinfException {
    this.callableCache = callableCache;
    this.master = master;
    NinfPacketInputStream pis = new NinfPacketInputStream(p, is);
    read(pis);
    stub = makeCompoundStub();
    this.aggregateSchedule = aggregateSchedule;
    this.myID = myID;
  }

  /** read stub body from stream */
  void read(NinfPacketInputStream is) throws NinfException {
    dbg.print("----reading CompoundCallable:" );

    int inputNum = is.readInt();
    dbg.println(" numbers:" + inputNum);
    dataflows = new NinfDataflow[inputNum];

    for (int i = 0; i < inputNum; i++) {
      dbg.println("------read one dataflow" );
      dataflows[i] = new NinfDataflow(is, callableCache);
    }
    dbg.println("   rest of packet ->" + is.rest());
    //is.dumpRest(dbg.os());
    inputNum = is.readInt();
    commonData = new NinfCommonData[inputNum];
    for (int i = 0; i < inputNum; i++) {
      dbg.println("------read one commonData" );
      commonData[i] = new NinfCommonData(is);
    }
  }

  // ***********************  NON STATIC METHODS  ***********************
  public NinfStub stub() {
    return stub;
  }

  public NinfThread forkWriteBack(XDROutputStream os) {
    return new NinfWriteBackThread(os, stub, callContext, this);
  }

  public NinfThread forkStub(int index, NativeCallable func, 
			     CallContext subContext, ServerIndex server) {
    int tmpSerial = master.getSerial();
    return new NinfConnectionThread(index, func, subContext, tmpSerial, server, this);
				    
  }


  public void recieveNinfCode(NinfPacketInputStream is) throws NinfException {
    int i;
    if ((i = is.readInt()) != 1)
      dbg.println("Invalid code:"  + i);
    else
      dbg.println("get Ninf Call Code: " + i);
  }

  /*
  public void setupBuffers(XDRInputStream is) throws NinfException {
    NinfPacketInputStream pis = new NinfPacketInputStream(is);
    recieveNinfCode(pis);
    stub.setupBuffers(buffers, pis);
    mergeBuffer();
    stub.serverReceive(buffers, pis);
  }
  */


  public void forkThreads(XDROutputStream os) {

    dbg.println("Fork Threads ");
    getfuncs();
    ServerIndex servers[] = aggregateSchedule();
    for (int i = 0; i < dataflows.length; i++) {
      threads.addElement(forkStub(i, funcs[i], subContexts[i], servers[i]));
				  
    }
    NinfThread writeBack = forkWriteBack(os);

    int dependentList[][] = getDependentList();

    for (int i = 0; i < dependentList.length; i++) {
      int tmp[] = dependentList[i];
//      dbg.print(i + " dependent: ");
      for (int j = 0; j < tmp.length; j++) {
//	dbg.print(tmp[j] + " ");
      }
//      dbg.println("");
      if (tmp.length == 0) {
	((NinfThread)threads.elementAt(i)).addLower(writeBack);
      } else {
	for (int j = 0; j < tmp.length; j++)
	  ((NinfThread)threads.elementAt(i)).
	    addLower(((NinfThread)threads.elementAt(tmp[j])));
      }
    }
    writeBack.start();
    for (int i = 0; i < threads.size(); i++) {
      ((NinfThread) threads.elementAt(i)).start();
    }
    threads.addElement(writeBack);
    
    try {
      
      //      writeBack.current.join(); /* wait for the end of write back */
      
    } catch (Exception e) {
      dbg.println("exception occured while waiting write back:" + e);
    }
  }

  public NinfStub modify(NinfStub stub, NinfDataflow dataflow) {
    for (int i = 0; i < stub.nparam; i++) {
      stub.params[i].modify(dataflow.dinfo[i]); // dinfo = DependInfo
    }
    return stub;
  }
  
  public NinfStub makeCompoundStub() {
    initArgNums();
    int size = 0;
    for (int i = 0; i < dataflows.length; i++) 
      size += dataflows[i].stub.nparam;
    NinfStub tmp = NinfStub.getEmptyStub(size);
    tmp.module_name = "_compound_function_";
    tmp.entry_name = "No." + (counter++);
    tmp.description = "Dynamically generated compound function";
    for (int i = 0; i < dataflows.length; i++) {
      tmp.add(modify(dataflows[i].stub.copy(), dataflows[i]));
//      dbg.println("dataflow : " + i + " done.");
    }

    mergeCommonInputs(tmp);
    return tmp;
  }

  void mergeCommonInputs(NinfStub stub){
    for (int i = 0; i < commonData.length; i++){
      int position = commonData[i].common[0].serialize(argNums);
      if (!stub.params[position].IS_INTERNAL())
	for (int j = 1; j < commonData[i].common.length; j++){
	  int position2 = commonData[i].common[j].serialize(argNums);
	  stub.params[position].setInternal();
	}
      
    }
  }


  //NinfCompounData <- here
  //  NinfDataFlow dataflows[]
  //    int index
  //    int stubNum
  //    NinfStub stub
  //    DependInfo dinfo[]
  //      ArgPosition inputDepend
  //        int functionIndex
  //        int argNum
  //      ArgPosition outputDepends[]
  //        int functionIndex
  //        int argNum
  
  /** must rewrite this method to calculate min{CPM} */
  public void getfuncs () {

    // current state, dataflows -> funcs[]
    // make [map1] w/dataflow -> CPM1
    // modify [map1] and derive [map2] -> CPM2
    //                :
    // modify [map n-1] and derive [map n] -> CPM n
    // make funcs[] from [map n]

    System.out.println(callContext);
    
    funcs = new NativeCallable[dataflows.length];
    subContexts = new CallContext[dataflows.length];
    try {
//      System.err.println("DataFlow Follows: ");

      int count = 0;
      for (int i = 0; i < dataflows.length; i++) {
//	String entry = funcManager.getFunctionName(dataflows[i].stubNum);

	//---- for debug
	//System.err.print("  " + i + ":" + dataflows[i].stubNum + ":"
	//+ entry + "(");
	//DependInfo di[] = dataflows[i].dinfo;
	//boolean first = true;
	//for (int j = 0; j < di.length; j++) {
	//if (!first) System.err.print(", ");
	//first = false;
	//System.err.print(di[j]);
	//}
	//System.err.println(")");
	//---- for debug

	funcs[i] =
	  (NativeCallable)(callableCache.getCallable(dataflows[i].stubNum));

	subContexts[i] = 
	  callContext.getSubContext(argNums[i], funcs[i].getStub().nparam);
	System.out.println(subContexts[i]);
      }
    } catch (Exception e) {
      dbg.println("getStub() : " + e);
    }
  }
  
  int[][] getDependentList() {
    int tmp[][] = new int[dataflows.length][];
    for (int i = 0; i < dataflows.length; i++)
      tmp[i] = dataflows[i].dependent();
    return tmp;
  }

  void initArgNums(){
    argNums = new int[dataflows.length];
    int index = 0;
    for (int i = 0; i < dataflows.length; i++) {
      argNums[i] = index;
      index += dataflows[i].stub.nparam;
    }
  }

  public Stoppable call(NinfPacket pkt, int serial, 
			XDRInputStream is, XDROutputStream os) 
  throws NinfException {
    NinfServerConnection con;
    StubCallableContext context;

    NinfPacketInputStream pis = new NinfPacketInputStream(pkt, is);    
    XDRInputStream dis = new XDRInputStream(pis);

    context = new StubCallableContext(pis);

    callContext = stub.setupBuffers(dis);
    context.modifyBuffers(callContext.buffers);
    callContext.mergeBuffer(dataflows, commonData, argNums);

    stub.serverReceive(callContext, dis);

    forkThreads(os);
    waitForKill(is, os);
    
    return this;
  }

  void waitForKill(XDRInputStream is, XDROutputStream os) throws NinfException {
    dbg.println("waiting for kill");

    boolean ret = true;
    NinfPacket pkt = null;
    pkt = new NinfPacket(is);
    switch (pkt.hdr.code) {
    case NinfPktHeader.NINF_PKT_KILL:
      NinfPacketOutputStream pos = 
	new NinfPacketOutputStream(os, NinfPktHeader.NINF_PKT_RPY_KILL);
      pos.flush();
    dbg.println("-------- freeing callContext ---------");
    callContext = null;
    subContexts = null;
    clearResources();
    return;
    default:
      dbg.log("Unknown Coded Packet " + pkt.hdr.code);
      return;
    }
  }

  public NinfStub getStub(){
    return stub;
  }

  public void stop() {
System.out.println("Compound: stop called: finished = " + finished +", threads.size = " + threads.size());
    if (!finished)
      for (int i = 0; i < threads.size(); i++)
	((NinfThread)threads.elementAt(i)).kill();
  }

  public void finished(){
    finished = true;
    callContext = null;
    dataflows = null;
    commonData = null;
    funcs = null;
    stub = null;
    threads = null;
  }

  public boolean succeeded (){
    for (int i = 0; i < threads.size(); i++){
      Object tmp = threads.elementAt(i);
      if (tmp instanceof NinfConnectionThread)
	if (!((NinfConnectionThread)tmp).succeeded)
	  return false;
    }
    return true;
  }

  /** generate unique path name for URLResouces */
  static int pathCounter = 0;
  synchronized String genPath(){ 
    return "path" + (pathCounter++);
  }

  URLResource makeResouce(ServerID id){
    URLResource tmp = 
      new URLResource(URLResource.NINF_STORAGE_RESOURCE, 
		  id.host,
		  ""+id.port,
		  genPath());
    if (usedResources == null)
      usedResources = new Vector();
    usedResources.addElement(tmp);
    return tmp;
  }

  public void setupBufferStorage(ServerID[] serverIDs){
    for (int i = 0; i < serverIDs.length; i++){
      if (!serverIDs[i].equals(myID))
	callContext.buffers[expandMap[i]].
	  setResource(makeResouce(serverIDs[i]));
    }
  }

  Vector usedResources;
  void clearResources(){
    if (usedResources == null)
      return;
    for (int i = 0; i < usedResources.size(); i++){
      URLResource rsc = (URLResource)usedResources.elementAt(i);
      if (rsc.protocol != URLResource.NINF_STORAGE_RESOURCE)
	continue;
      try {
	new NinfServerStruct(rsc.host, rsc.port).connect().
	  clearResource(rsc);
      } catch(NinfException e) {
	dbg.log("failed to clear: " + rsc);
	dbg.log(e);
      }
    }
  }

  FuncNode[] makeFuncNodes(){
    FuncNode funcNodes[] = new FuncNode[funcs.length];
    for (int i = 0; i < funcNodes.length; i++){
      long order = funcs[i].getStub().calcOrder(subContexts[i]);
      funcNodes[i] = new FuncNode(funcs[i].getStub().getName(), order);
    }
    return funcNodes;
  }

  int countData(){
    int count = callContext.buffers.length;
    for (int i = 0; i < commonData.length; i++)
      count -= (commonData[i].common.length - 1);

    for (int i = 0; i < stub.nparam; i++)
      if (stub.params[i].IS_SCALAR())
	count--;
    return count;
  }

  void clearCommon(){
    for (int i = 0; i < commonData.length; i++)
      commonData[i].reset();
  }

  /* included, first time : -1 
     not included         : -2
     included, not first  : position
   */
  int commonStatus(ArgPosition pos, int index){
    for (int i = 0; i < commonData.length; i++)
      if (commonData[i].includes(pos)){
	int mark;
	if ((mark = commonData[i].mark()) < 0){
	  commonData[i].mark(index);
	  return -1;
	} else {
	  return mark;
	}
      }
    return -2;
  }

  int expandMap[];

  DataNode[] makeDataNodes(){
    int count = countData();

    DataNode[] dataNodes = new DataNode[count];
    expandMap = new int[count];
    int counter = 0;
    long sizes[] = new long[count];
    //    System.out.println("size of data nodes = " + count);

    clearCommon();
    MergedInfo[] mergedInfo = new MergedInfo[count];
    for (int i = 0; i < count; i++)
      mergedInfo[i] = new MergedInfo();
    int serial = 0;
    for (int i = 0; i < dataflows.length; i++)
      for (int j = 0; j < dataflows[i].dinfo.length; j++, serial++){
	ArgPosition pos = new ArgPosition(i, j);
	if (stub.params[serial].IS_SCALAR())
	  continue;
	int res = commonStatus(pos, counter);
	System.out.println("status of "+ pos + " is " + res );
	System.out.println("mode = " +  stub.params[serial].param_inout);

	System.out.println("counter = " +  counter + ",serial = " +  serial);
	if (res ==  -1 || res == -2){ /* first */

	  sizes[counter] = callContext.buffers[serial].data.length;
	  mergedInfo[counter].add(dataflows[i].dinfo[j], 
				  stub.params[serial].IS_IN_MODE(),
				  pos);
	  expandMap[counter] = serial;
	  counter++;
	} else {
	  mergedInfo[res].add(dataflows[i].dinfo[j], 
			      stub.params[serial].IS_IN_MODE(),
			      pos);
	}

      }	  
    for (int i = 0; i < count; i++)
      dataNodes[i] = new DataNode(sizes[i], mergedInfo[i]);
    return dataNodes;
  }

  ServerIndex[] aggregateSchedule(){
    if (!aggregateSchedule)
      return new ServerIndex[dataflows.length];
    dbg.print("making funcnodes");
    FuncNode funcNodes[] = makeFuncNodes();
    dbg.print("making datanodes");
    DataNode dataNodes[] = makeDataNodes();
    int serial = master.getSerial();
    try {
      AggregateScheduled 
	result = master.aggregateSchedule(funcNodes, dataNodes, serial);
      dbg.print("got result");
      setupBufferStorage(result.dataLocations);
      return result.serverIndexes;
    } catch (NinfException e){
      if (dbg.isVerbose()) e.printStackTrace(dbg.os);
      dbg.log("failed to aggregate schedule: using usual schedule");
    }
    return new ServerIndex[dataflows.length];
  }

  double compTime, foreTime, backTime;

  synchronized void addCompTime(double time){
    compTime += time;
  }
  synchronized void addForeTime(double time){
    foreTime += time;
  }
  synchronized void addBackTime(double time){
    backTime += time;
  }


}

// end of CompoundCallable.java

