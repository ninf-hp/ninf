#define _WRAPPER_
/* $Id: pslarzb_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define FLOAT
#include <gscalapack.h>

#define ROW_v ldv
#define COL_v col_v
#define ROW_t ldt
#define COL_t n
#define ROW_c ldt
#define COL_c n
static	int worklen(char side, char storev, int m, int n, int k) {
		int ret=1;
		int IROFFV, ICOFFV, IVROW, IVCOL, MqV0, NpV0;
		int IROFFC, ICOFFC, ICROW, ICCOL, MpC0, NpC0;
		int NqC0;
		int LCMP, LCMQ;

		if (chrcmp(storev , 'C')==0) {
			if (chrcmp(side, 'L')==0)
				ret = ( n + m ) * k;
			else if (chrcmp(side , 'R')==0)
				ret = ( n + max( n+ n,  m ) ) * k;
		  } else {
			  if (chrcmp(side ,'L')==0)
				  ret = ( m  + MAX( m  + m, n ) ) * k;
		    else if (chrcmp(side , 'R')==0)
			    ret = ( m + n ) * k;
		  }
		if NEED_BUFF {
#define LCM Cilcm(nprow,npcol)
#define IV 1
#define JV 1
#define MB_V rbloc
#define NB_V cbloc
#define RSRC_V 0
#define CSRC_V 0
		  LCMP = LCM/NPROW;
		  LCMQ = LCM/NPCOL;
		  IROFFV = MOD( IV-1, MB_V );
		  ICOFFV = MOD( JV-1, NB_V );
		  IVROW = INDXG2P( IV, MB_V, MYROW, RSRC_V, NPROW );
		  IVCOL = INDXG2P( JV, NB_V, MYCOL, CSRC_V, NPCOL );
		  MqV0 = NUMROC( M+ICOFFV, NB_V, MYCOL, IVCOL, NPCOL );
		  NpV0 = NUMROC( N+IROFFV, MB_V, MYROW, IVROW, NPROW );

		  IROFFC = MOD( IC-1, MB_C ), ICOFFC = MOD( JC-1, NB_C );
		  ICROW = INDXG2P( IC, MB_C, MYROW, RSRC_C, NPROW );
		  ICCOL = INDXG2P( JC, NB_C, MYCOL, CSRC_C, NPCOL );
		  MpC0 = NUMROC( M+IROFFC, MB_C, MYROW, ICROW, NPROW );
		  NpC0 = NUMROC( N+ICOFFC, MB_C, MYROW, ICROW, NPROW );
		  NqC0 = NUMROC( N+ICOFFC, NB_C, MYCOL, ICCOL, NPCOL );

		  if (chrcmp(storev , 'C')==0) {
		    if (chrcmp(side, 'L')==0)
		      ret = ( NqC0 + MpC0 ) * k;
		    else if (chrcmp(side , 'R')==0)
		      ret = ( NqC0 + MAX( NpV0 + NUMROC( NUMROC( N+ICOFFC, NB_V, 0, 0, NPCOL ), NB_V, 0, 0, LCMQ ),  MpC0 ) ) * k;
		  } else {
		    if (chrcmp(side ,'L')==0)
		      ret = ( MpC0 + MAX( MqV0 + NUMROC( NUMROC( M+IROFFC, MB_V, 0, 0, NPROW ), MB_V, 0, 0, LCMP ), NqC0 ) ) * k;
		    else if (chrcmp(side , 'R')==0)
		      ret = ( MpC0 + NqC0 ) * k;
		  }
		}
		return ret;
}

static	int vlen(char side, int m, int n) {
	  int ret=1;
	  if (mypnum!=0) {
	    if (chrcmp(side,'l')==0)
	      ret= m;
	    else
	      ret = n;
	  }
	  return ret;
}

void  pslarzb_ninf(	 char side,
		 char trans,
		 char direct,
		 char storev,
		 int m,
		 int n,
		 int k,
		 int l,
		 float global_v[],
		 int ldv,
		 float global_t[],
		 int ldt,
		 float global_c[],
		 int ldc,
		 float work[],
		 int lwork
)
/* "pslarzb applies a real block reflector Q or its transpose Q**T to a real distributed M-by-N matrix C from the left or the right." */
/* OPTIONS */
{
	int maxldd;

	int maxldv;
	int col_v;
	float *locv=NULL;
	int descv[DESCLEN];
	int desc_gv[DESCLEN];
	int row_locv, col_locv;

	int maxldt;
	float *loct=NULL;
	int desct[DESCLEN];
	int desc_gt[DESCLEN];
	int row_loct, col_loct;

	int maxldc;
	float *locc=NULL;
	int descc[DESCLEN];
	int desc_gc[DESCLEN];
	int row_locc, col_locc;

	float *locwork=NULL;
	int llocwork;


	INITIALIZE();

	SCALAR( "char", side);
	SCALAR( "char", trans);
	SCALAR( "char", direct);
	SCALAR( "char", storev);
	SCALAR( "int", m);
	SCALAR( "int", n);
	SCALAR( "int", k);
	SCALAR( "int", l);
	SCALAR("int",ldv);
	SCALAR("int",ldt);
	SCALAR("int",ldc);
	SCALAR("int", lwork);

	col_v = vlen(side, m, n);

	ROW(v);
	COL(v);
	ROW(t);
	COL(t);
	ROW(c);
	COL(c);
	MAXLDD( maxldd, c );
	maxldv = maxldd;
	maxldt = maxldd;
	maxldc = maxldd;

	MATRIX( "float", v, ROW_v, COL_v);
	MATRIX( "float", t, ROW_t, COL_t);
	MATRIX( "float", c, ROW_c, COL_c);
	DISTRIBUTE( "float", v, ROW_v  , COL_v);
	DISTRIBUTE( "float", t, ROW_t  , COL_t);
	DISTRIBUTE( "float", c, ROW_c  , COL_c);

	llocwork = worklen(side, storev, m, n, k);
	llocwork = max(lwork,llocwork);
	WORK(work,llocwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pslarzb)( &side, &trans, &direct, &storev,
                               &m, &n, &k, &l,
                               locv, &one, &one, descv,
                               loct,
                               locc, &one, &one, descc,
                               locwork);

	GATHER( "float", c, ROW_c  , COL_c);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
	} else {
	}

	FREE_MATRIX(v);
	FREE_MATRIX(t);
	FREE_MATRIX(c);
        FREE(locwork);
	
}

