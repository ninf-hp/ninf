/* ninf_debug.c */

#include "ninf_debug.h"
#include "ninf_macros.h"

int ninf_debug_flag = FALSE;

/* end of ninf_debug.c */
