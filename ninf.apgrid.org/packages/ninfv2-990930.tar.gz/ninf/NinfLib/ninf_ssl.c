#ifdef SSL_USE
#include <stdio.h>
#include <stdlib.h>

#include <connection.h>
#include <ninf_ssl.h>


static int set_cert_stuff(SSL_CTX *ctx, char *cert_file, char *key_file);
static int verify_callback(int ok,X509_STORE_CTX *ctx);

#define CERTFILENAME ".ninf/usercert.pem"
#define KEYFILENAME  ".ninf/userkey.pem"

/** return certfile name considering default */
char * ninf_client_ssl_cert_file(char * cert){
  static char buffer[1000];
  if (cert != NULL)
    return cert;
  else {
    sprintf(buffer, "%s/%s", getenv("HOME"), CERTFILENAME);
    return buffer;
  }
}


/** return keyfile name considering default */
char * ninf_client_ssl_key_file(char * key){
  static char buffer[1000];
  if (key != NULL)
    return key;
  else {
    sprintf(buffer, "%s/%s", getenv("HOME"), KEYFILENAME);
    return buffer;
  }
}
			
/** do ssl_connect */
int ninf_ssl_connect(connection * con){
  int err;
  SSL * ssl = con->ssl;
  
  if ((err = SSL_connect(ssl)) < 0){
    ninf_log("failed to SSL_connect\n");
    return FALSE;
  }
  return TRUE;
}

/** do ssl_accept */
int ninf_ssl_accept(connection * con){
  int err;
  SSL * ssl = con->ssl;
  
  ninf_debug("ssl_accepting");

  if ((err = SSL_accept(ssl)) < 0){
    ninf_log("failed to SSL_accept\n");
    return FALSE;
  }
  return TRUE;
}


/** initialize once */
void init_ssl(){
  static done = FALSE;
  if (!done){
    SSLeay_add_ssl_algorithms();
    SSL_load_error_strings();
    done = TRUE;
  }
}

/** make new SSL_CTX using files */
SSL_CTX * ninf_client_new_ssl_ctx(char * certfile , char * keyfile){
  static SSL_CTX* ctx = NULL;
  SSL_METHOD *meth=NULL;

  init_ssl();

  if (ctx != NULL)
    return ctx;

  /** setup ctx */
  meth = SSLv3_method();
  ctx = SSL_CTX_new (meth);
  if (ctx == NULL){
    ninf_log("cannot make SSL context\n");
    return NULL;
  }

  if (!set_cert_stuff(ctx, certfile, keyfile))
    return NULL;
  return ctx;
}


/** make new SSL_CTX using files */
SSL_CTX * ninf_server_new_ssl_ctx(char * certfile , char * keyfile, 
				  char * cafile){
  static SSL_CTX * ctx = NULL;
  SSL_METHOD *meth=NULL;
  int verify_flag = SSL_VERIFY_PEER|SSL_VERIFY_FAIL_IF_NO_PEER_CERT|
	SSL_VERIFY_CLIENT_ONCE;

  init_ssl();

  if (ctx != NULL)
    return ctx;

  /** setup ctx */
  meth = SSLv3_method();
  ctx = SSL_CTX_new (meth);
  if (ctx == NULL){
    ninf_log("cannot make SSL context\n");
    return NULL;
  }

  if (!set_cert_stuff(ctx, certfile, keyfile))
    return NULL;

  if ((!SSL_CTX_load_verify_locations(ctx, cafile, NULL)) ||
      (!SSL_CTX_set_default_verify_paths(ctx))){
    ninf_log("failed to set CA");
  }
  
  SSL_CTX_set_verify(ctx,verify_flag, verify_callback);
  return ctx;
}

/**************************STATIC FUCNTIONS*************************/


static int verify_callback(int ok,X509_STORE_CTX *ctx){
  char buf[256];
  X509 *err_cert;
  int err,depth;
  int verify_depth = 2;
  int verify_error;

  err_cert = X509_STORE_CTX_get_current_cert(ctx);
  err      = X509_STORE_CTX_get_error(ctx);
  depth    = X509_STORE_CTX_get_error_depth(ctx);
  
  X509_NAME_oneline(X509_get_subject_name(err_cert),buf,256);
  fprintf(stderr,"depth=%d %s\n",depth,buf);
  if (!ok) {
    fprintf(stderr,"verify error:num=%d:%s\n",err,
	       X509_verify_cert_error_string(err));
#if 0
    if (err == 21) /** verify failed */
      ok = 0;
    else {
#endif
      if (verify_depth >= depth){
	ok=1;
	verify_error=X509_V_OK;
      } else {
	ok=0;
	verify_error=X509_V_ERR_CERT_CHAIN_TOO_LONG;
      }
#if 0
    }
#endif
  }
  switch (ctx->error){
  case X509_V_ERR_UNABLE_TO_GET_ISSUER_CERT:
    X509_NAME_oneline(X509_get_issuer_name(ctx->current_cert),buf,256);
    fprintf(stderr,"issuer= %s\n",buf);
    break;
  case X509_V_ERR_CERT_NOT_YET_VALID:
  case X509_V_ERR_ERROR_IN_CERT_NOT_BEFORE_FIELD:
    fprintf(stderr,"notBefore=");

    /*    ASN1_UTCTIME_print(bio_err,X509_get_notBefore(ctx->current_cert)); */

    fprintf(stderr,"\n");
    break;
  case X509_V_ERR_CERT_HAS_EXPIRED:
  case X509_V_ERR_ERROR_IN_CERT_NOT_AFTER_FIELD:
    fprintf(stderr,"notAfter=");
    /*    ASN1_UTCTIME_print(bio_err,X509_get_notAfter(ctx->current_cert)); */
    fprintf(stderr,"\n");
    break;
  }
  fprintf(stderr,"verify return:%d\n",ok);
  return(ok);
}


static int set_cert_stuff(SSL_CTX *ctx, char *cert_file, char *key_file){
  if (cert_file != NULL){
    SSL *ssl;
    X509 *x509;
    if (SSL_CTX_use_certificate_file(ctx,cert_file,
				     SSL_FILETYPE_PEM) <= 0){
      ninf_error("unable to get certificate from '%s'\n",cert_file);
      return(0);
    }
    if (key_file == NULL) key_file=cert_file;
    if (SSL_CTX_use_PrivateKey_file(ctx,key_file,
				    SSL_FILETYPE_PEM) <= 0){
      ninf_error("unable to get private key from '%s'\n",key_file);
      return(0);
    }
    ssl=SSL_new(ctx);
    x509=SSL_get_certificate(ssl);
    
    if (x509 != NULL)
      EVP_PKEY_copy_parameters(X509_get_pubkey(x509),
			       SSL_get_privatekey(ssl));
    SSL_free(ssl);

    /* If we are using DSA, we can copy the parameters from
     * the private key */
    
    
    /* Now we know that a key and cert have been set against
     * the SSL context */
    if (!SSL_CTX_check_private_key(ctx)){
      ninf_error("Private key does not match the certificate public key");
      return(0);
    }
    return (1);
  }
  return(0);
}

#endif
