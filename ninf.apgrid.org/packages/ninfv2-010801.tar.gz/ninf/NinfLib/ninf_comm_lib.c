/*
 *  $Id: ninf_comm_lib.c,v 1.19 2001/07/30 18:24:03 nakada Exp $
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <netdb.h>
char *save_str(char * s);

extern int ninf_debug_flag;
#include "connection.h"
#include "ninf_macros.h"
#include "ninf_data_trans.h"
#include "ninf_cim.h"
#include "ninf_error.h"

char * myalloc(int size);

int ninf_get_value(VALUE_TYPE value_type,int value,
		   NINF_EXPRESSION * exp, NINF_STUB_INFO *sp,
		   any_t *args, int default_value, int header_val);

NINF_STUB_INFO * new_ninf_stub_info(){
  NINF_STUB_INFO * tmp =
    (NINF_STUB_INFO *) myalloc(sizeof(NINF_STUB_INFO));
  tmp->params = NULL;
  tmp->description = NULL;
  return tmp;
}

struct ninf_param_desc * new_ninf_param_desc(int num){
  struct ninf_param_desc *  tmp = 
    (struct ninf_param_desc *) myalloc(sizeof(struct ninf_param_desc) * num);
  return tmp;
}

/* 
 * common routine for call end stub.
 */

static int EXP_STACK[NINF_EXPRESSION_LENGTH];  /* stack for eval expression */
static int EXP_STACK_POINTER = 0;

void init_EXP_STACK()
{
  EXP_STACK_POINTER = 0;
/* printf("init\n");
*/
}
void push_EXP_STACK(int item)
{
  if (EXP_STACK_POINTER >= NINF_EXPRESSION_LENGTH)
    ninf_error("Expression eval stack overflow");

  EXP_STACK[EXP_STACK_POINTER++] = item;
}
int pop_EXP_STACK()
{
  if (EXP_STACK_POINTER <= 0)
    ninf_error("Expression eval stack underflow");    

  return EXP_STACK[--EXP_STACK_POINTER];
}

int eval_expression( NINF_EXPRESSION * exp, 
		     NINF_STUB_INFO * sp, 
		     any_t * args)
{
  int i;
  init_EXP_STACK();
  for (i = 0; i < NINF_EXPRESSION_LENGTH; i++){
    VALUE_TYPE type = exp->type[i];
    int val =  exp->val[i];
    switch(type){
    case VALUE_NONE:
    case VALUE_CONST:
    case VALUE_IN_ARG:
      push_EXP_STACK(ninf_get_value(type,val,NULL,sp,args,0, 0));
      break;
    case VALUE_OP:
      switch(val){
      case OP_VALUE_PLUS:
	push_EXP_STACK(pop_EXP_STACK() + pop_EXP_STACK());
	break;
      case OP_VALUE_MINUS:
	{
	  int tmp = pop_EXP_STACK();
	  push_EXP_STACK(pop_EXP_STACK() - tmp);
	}
	break;
      case OP_VALUE_MUL:
	push_EXP_STACK(pop_EXP_STACK() * pop_EXP_STACK());
	break;
      case OP_VALUE_DIV:
	{
	  int tmp = pop_EXP_STACK();
	  push_EXP_STACK(pop_EXP_STACK() / tmp);
	}
	break;
      case OP_VALUE_MOD:
	{
	  int tmp = pop_EXP_STACK();
	  push_EXP_STACK(pop_EXP_STACK() % tmp);
	}
	break;
      case OP_VALUE_UN_MINUS:
	push_EXP_STACK(- pop_EXP_STACK());
	break;
      case OP_VALUE_EQ: {
	int right = pop_EXP_STACK();
	int left = pop_EXP_STACK();
	push_EXP_STACK(right == left);
	break;
      }
      case OP_VALUE_NEQ: {
	int right = pop_EXP_STACK();
	int left = pop_EXP_STACK();
	push_EXP_STACK(left != right);
	break;
      }
      case OP_VALUE_GT: {
	int right = pop_EXP_STACK();
	int left = pop_EXP_STACK();
	push_EXP_STACK(left > right);
	break;
      }
      case OP_VALUE_LT: {
	int right = pop_EXP_STACK();
	int left = pop_EXP_STACK();
	push_EXP_STACK(left < right);
	break;
      }
      case OP_VALUE_GE: {
	int right = pop_EXP_STACK();
	int left = pop_EXP_STACK();
	push_EXP_STACK(left >= right);
	break;
      }
      case OP_VALUE_LE: {
	int right = pop_EXP_STACK();
	int left = pop_EXP_STACK();
	push_EXP_STACK(left <= right);
	break;
      }
      case OP_VALUE_TRY: {
	int right = pop_EXP_STACK();
	int left = pop_EXP_STACK();
	int cond = pop_EXP_STACK();
	push_EXP_STACK(cond ? left : right);
	break;
      }
      case OP_VALUE_BEKI: {
		int i, tmp = 1;
		int right = pop_EXP_STACK();
		int left = pop_EXP_STACK();
		for (i = 0; i < right; i++){
		  tmp *= left;
		}
		push_EXP_STACK(tmp);
		break;
      }
      default:
	ninf_error("unknown OP_CODE");
      }
      break;
    case VALUE_END_OF_OP:
      return pop_EXP_STACK();
      /* break; */
    default:
      ninf_error("unknown VALUE_TYPE in eval expression");
    }
  }
  return pop_EXP_STACK();
}

int ninf_get_value(VALUE_TYPE value_type,  int value,
		   NINF_EXPRESSION * exp, NINF_STUB_INFO *sp,
		   any_t *args, int default_value, int header_val)
{
    int i;
    
    switch(value_type)
      {
      case VALUE_NONE:
	  return(default_value);
      case VALUE_CONST:
	  return(value);
      case VALUE_IN_ARG:
	  i = value;
	  switch(sp->params[i].param_type){
	  case DT_CHAR:
	    return(args[i].u.c);
	  case DT_SHORT:
	    return(args[i].u.s);
	  case DT_INT:
	    return(args[i].u.i);
	  case DT_LONG:
	    return(args[i].u.l);
	  case DT_UNSIGNED_CHAR:
	    return(args[i].u.uc);
	  case DT_UNSIGNED_SHORT:
	    return(args[i].u.us);
	  case DT_UNSIGNED:
	    return(args[i].u.ui);
	  case DT_UNSIGNED_LONG:
	    return(args[i].u.ul);
	  case DT_FLOAT:
	    return((int)args[i].u.f);
	  case DT_DOUBLE:
	    return((int)args[i].u.d);
	  case DT_STRING_TYPE:
	    return((int)args[i].u.d);  /* string cannot be index*/
	  case DT_LONG_DOUBLE:
	  case DT_UNSIGNED_LONGLONG:
	  case DT_LONGLONG:
	    ninf_error("not supported data types");
	    break;
	  case DT_SCOMPLEX:            /* complex should not be scalar */
	  case DT_DCOMPLEX:
	  default:
	    ninf_error("unknown data type");
	    break;
	  }
	  break;
      case VALUE_BY_EXPR:
	  if (exp == NULL)
	    ninf_error("Expression in Expression");
	  return eval_expression(exp,sp,args);
      case VALUE_IN_HEADER:
	return header_val;
      default:
	  ninf_error("unknown VALUE_TYPE %d", value_type);
      }
}

/*************** PACKET HEADER REORDER ROUTINES **********/

void reorder_int_inner(char * tmp, int * code)
{
  int ret = 0, i;
  unsigned char * tmp2 = (unsigned char *) tmp;
  for (i = 0; i < 4; i++, tmp2++){
    ret = (ret << 8) + (*tmp2);
  }
  *code = ret;
}

void reorder_header_inner(char * ninf_pkt_buf, DECODED_HEADER * decoded)
{
  NINF_PKT_HEADER * hdr;
  int i;
  hdr = (NINF_PKT_HEADER *)ninf_pkt_buf;

  reorder_int_inner(&(hdr->header[0]), & (decoded->size)); 
  reorder_int_inner(&(hdr->header[4]), & (decoded->code)); 
  reorder_int_inner(&(hdr->header[8]), & (decoded->arg1)); 
  reorder_int_inner(&(hdr->header[12]), & (decoded->arg2)); 
}

void reorder_int_network(int code, char * tmp)
{
  int ret = code, i; 
  *(tmp + 0) = (ret >> 24) & (0xff);
  *(tmp + 1) = (ret >> 16) & (0xff);
  *(tmp + 2) = (ret >>  8) & (0xff);
  *(tmp + 3) = (ret >>  0) & (0xff);
}

void reorder_header_network(DECODED_HEADER * decoded, char * ninf_pkt_buf)
{
  int i;
  NINF_PKT_HEADER * hdr;
  hdr = (NINF_PKT_HEADER *)ninf_pkt_buf;

  reorder_int_network(decoded->size, & (hdr->header[0])); 
  reorder_int_network(decoded->code, & (hdr->header[4])); 
  reorder_int_network(decoded->arg1, & (hdr->header[8])); 
  reorder_int_network(decoded->arg2, & (hdr->header[12])); 
}


/**************    NO DELAY TEST ROUTINES   **************/
#ifndef WIN32
void set_sock_no_delay(int s){
  int i = 1;
  if (setsockopt(s, IPPROTO_TCP, TCP_NODELAY,
		 (char*)&i, sizeof(int)) == -1 ) {
    ninf_error("set_sock_no_delay() setsockopt: %s", strerror(errno));
  } 
}
void set_no_delay(int s)
{
  int i;
  if ((i = fcntl(s, F_GETFL, 0)) == -1){
    ninf_error("set_no_delay: fcntl getfl: %s", strerror(errno));
    return;
  }
  i |= O_NDELAY;
  if ((i = fcntl(s, F_SETFL, i)) == -1){
    ninf_error("set_no_delay: fcntl setfl: %s", strerror(errno));
  }
}
int set_non_block(int s)
{
  int i;
  if ((i = fcntl(s, F_GETFL, 0)) == -1){
    ninf_error("set_non_block: fcntl getfl: %s", strerror(errno));
    return FALSE;
  }
  i |= O_NONBLOCK;
  if ((i = fcntl(s, F_SETFL, i)) == -1){
    ninf_error("set_non_block: fcntl setfl: %s", strerror(errno));
    return FALSE;
  }
  return TRUE;
}

#else 
int set_non_block(int s){
  return TRUE;  /* dummy for WIN32 */
}
#endif
/********************************************
    translate routines use dataTrans
 ********************************************/

int trans_stub_info_all(dataTrans *DT, NINF_STUB_INFO *sp, int send_description){
  if (!trans_stub_info(DT, sp, send_description)) return FALSE;
  if (!trans_int(DT, & sp->backend)) return FALSE;
  return TRUE;
}

int trans_stub_info(dataTrans *DT, NINF_STUB_INFO *sp, int send_description)
{
  int i,j, k;
  struct ninf_param_desc *dp;
  char *s;
  
  if(!trans_int(DT,&sp->version_major)) return(FALSE);
  if(!trans_int(DT,&sp->version_minor)) return(FALSE);
  if(!trans_int(DT,&sp->info_type)) return(FALSE);
  s = sp->module_name;
  if(!trans_string(DT,&s,NINF_MAX_NAME_LEN)) return(FALSE);
  s = sp->entry_name;
  if(!trans_string(DT,&s,NINF_MAX_NAME_LEN)) return(FALSE);
  if(!trans_int(DT,&sp->nparam)) return(FALSE);
  if (sp->params == NULL)
    sp->params = new_ninf_param_desc(sp->nparam);
  for(i = 0; i < sp->nparam; i++){
    dp = &sp->params[i];
    if(!trans_int(DT,(int *)&dp->param_type)) return(FALSE);
    if(!trans_int(DT,(int *)&dp->param_inout)) return(FALSE);
    if(!trans_int(DT,&dp->ndim)) return(FALSE);
    for(j = 0; j < abs(dp->ndim); j++){
      
      if(!trans_enum(DT,(int *)&dp->dim[j].size_type)) return(FALSE);
      if(!trans_int(DT,&dp->dim[j].size)) return(FALSE);
      if (dp->dim[j].size_type == VALUE_BY_EXPR)
	for(k = 0; k < NINF_EXPRESSION_LENGTH; k++){
	  if(!trans_int(DT,(int *)&dp->dim[j].size_exp.type[k])) return(FALSE);
	  if(!trans_int(DT,&dp->dim[j].size_exp.val[k])) return(FALSE);
	}
      if(!trans_enum(DT,(int *)&dp->dim[j].start_type)) return(FALSE);
      if(!trans_int(DT,&dp->dim[j].start)) return(FALSE);
      if (dp->dim[j].start_type == VALUE_BY_EXPR)
	for(k = 0; k < NINF_EXPRESSION_LENGTH; k++){
	  if(!trans_int(DT,(int *)&dp->dim[j].start_exp.type[k])) return(FALSE);
	  if(!trans_int(DT,&dp->dim[j].start_exp.val[k])) return(FALSE);
	}
      if(!trans_enum(DT,(int *)&dp->dim[j].end_type)) return(FALSE);
      if(!trans_int(DT,&dp->dim[j].end)) return(FALSE);
      if (dp->dim[j].end_type == VALUE_BY_EXPR)
	for(k = 0; k < NINF_EXPRESSION_LENGTH; k++){
	  if(!trans_int(DT,(int *)&dp->dim[j].end_exp.type[k])) return(FALSE);
	  if(!trans_int(DT,&dp->dim[j].end_exp.val[k])) return(FALSE);
	}
      if(!trans_enum(DT,(int *)&dp->dim[j].step_type)) return(FALSE);
      if(!trans_int(DT,&dp->dim[j].step)) return(FALSE);
      if (dp->dim[j].step_type == VALUE_BY_EXPR)
	for(k = 0; k < NINF_EXPRESSION_LENGTH; k++){
	  if(!trans_enum(DT,(int *)&dp->dim[j].step_exp.type[k])) return(FALSE);
	  if(!trans_int(DT,&dp->dim[j].step_exp.val[k])) return(FALSE);
	}
    }
  }
  if(!trans_enum(DT,(int *)&sp->order_type)) return(FALSE);
  if (sp->order_type == VALUE_BY_EXPR)
    for(k = 0; k < NINF_EXPRESSION_LENGTH; k++){
      if(!trans_enum(DT,(int *)&sp->order.type[k])) return(FALSE);
      if(!trans_int(DT,&sp->order.val[k])) return(FALSE);
    }
  if (send_description)
    if(!trans_string(DT,&(sp->description),NINF_MAX_NAME_LEN)) return(FALSE);
  if (!trans_int(DT,&(sp->shrink))) return(FALSE);
  return(TRUE);
}

int setup_resource_ft(NINF_STUB_INFO * stub_info_p, 
		      any_t *ninf_args, resource * rsc, int from, int to){
  int i, ncount;
  struct ninf_param_desc *dp;
  array_shape_info array_shape[MAX_DIM+1];
  int sizes_in_header[MAX_DIM + 1];

  for(i = from; i < to; i++){
    dp = &stub_info_p->params[i];
    if (dp->param_type == DT_FUNC_TYPE) break;  /* callback function */
    if (dp->ndim == 0) continue; /* scalar */
    ncount = trans_array_shape(dp, stub_info_p, ninf_args, 
			       array_shape, sizes_in_header);
    if (rsc != NULL && (rsc+i)->host != NULL){
      set_resource_array(&(rsc[i]), dp->param_type, abs(dp->ndim), 
			 dp->param_inout,
			 ncount, ninf_args[i].u.p, array_shape);
    }
  }
  return (TRUE);
}


/** returns sumation of transmitted data as the last argument */

int trans_vector_array_args_ft(dataTrans * dt, NINF_STUB_INFO * stub_info_p, 
			     any_t *ninf_args, resource * rsc, int from, int to,
			       int initiator, long * transmitted){
  int i, ncount;
  struct ninf_param_desc *dp;
  array_shape_info array_shape[MAX_DIM+1];
  int sizes_in_header[MAX_DIM + 1];

  for(i = from; i < to; i++){
    dp = &stub_info_p->params[i];
    if (dp->param_type == DT_FUNC_TYPE) break;  /* callback function */
    if (dp->ndim == 0) continue; /* scalar */
    if ((isReceive(dt) && IS_OUT_MODE(dp->param_inout) &&  initiator)||
		(isSend(dt)    && IS_IN_MODE (dp->param_inout) &&  initiator)||
        (isReceive(dt) && IS_IN_MODE (dp->param_inout) && !initiator)||
		(isSend(dt)    && IS_OUT_MODE(dp->param_inout) && !initiator)){
      if (dp->ndim < 0)
		if (! trans_size_header(dt, abs(dp->ndim), sizes_in_header))
		  return FALSE;
      ncount = trans_array_shape(dp, stub_info_p, ninf_args, 
								 array_shape, sizes_in_header);
	  /** sum up transmitted */
	  *transmitted += ncount * xdr_data_length(dp->param_type);
	  
      if (rsc != NULL && (rsc+i)->host != NULL){
		set_resource_array(&(rsc[i]), dp->param_type, abs(dp->ndim), dp->param_inout,
						   ncount, ninf_args[i].u.p, array_shape);
      } else {
		trans_mark_align(dt);
		if (ninf_args[i].isHandler){
		  if(!trans_array_handler(dt, dp->param_type, abs(dp->ndim), 
								  ninf_args[i].handler, array_shape))
			return (FALSE);
		} else {
		  if(!trans_array(dt, dp->param_type, abs(dp->ndim), 
						  ninf_args[i].u.p, array_shape))
			return (FALSE);
		}
		trans_align(dt);
      }
    }
  }
  return (TRUE);
}

int trans_size_header(dataTrans *dt, int size, int * sizes_in_header){
  int i;
  for (i = 0; i < size; i++)
    if (!trans_int(dt, sizes_in_header + i))
      return FALSE;
  return TRUE;
}

int trans_vector_any_args_ft(dataTrans * dt, NINF_STUB_INFO * stub_info_p, 
			     any_t *ninf_args, resource * rsc, int from, int to,
			     int initiator, long * transmitted){
  if (!(stub_info_p->shrink)) {
    return trans_vector_array_args_ft(dt, stub_info_p, ninf_args, rsc, from, to,
				      initiator, transmitted);
  } else {
    int i, ncount;
    int sizes_in_header[MAX_DIM + 1];
    array_shape_info array_shape[MAX_DIM + 1];

    for(i = from; i < to; i++){
      struct ninf_param_desc *dp = &stub_info_p->params[i];
      if(dp->param_type == DT_FUNC_TYPE) break;  /* callback function */
      if(dp->ndim == 0) continue; /* scalar */
      if (ninf_debug_flag) printf("trans_vector_any, %d th arg\n", i);
      if (dp->ndim < 0)
	if (! trans_size_header(dt, abs(dp->ndim), sizes_in_header))
	  return FALSE;
      if ((isReceive(dt) && IS_OUT_MODE(dp->param_inout) &&  initiator)||
	  (isSend(dt)    && IS_IN_MODE (dp->param_inout) &&  initiator)||
	  (isReceive(dt) && IS_IN_MODE (dp->param_inout) && !initiator)||
	  (isSend(dt)    && IS_OUT_MODE(dp->param_inout) && !initiator)){

	ncount = trans_array_shape(dp, stub_info_p, ninf_args, array_shape, 
				 sizes_in_header);

	/** sum up transmitted */
	*transmitted += ncount;
	
	if (rsc != NULL && (rsc + i)->host != NULL){
	  set_resource_any(&(rsc[i]), dp->param_type, abs(dp->ndim), dp->param_inout,
			   ncount, ninf_args[i].u.p, array_shape);
	} else {
	  trans_mark_align(dt);
	  if (!trans_any(dt, dp->param_type,ncount,ninf_args[i].u.p))
	    return(FALSE);
	  if (ninf_debug_flag) printf("trans_any, %d th arg: size = %d\n", i,ncount);
	  trans_align(dt);
	}
      }
    }
    return(TRUE);
  }
}


int trans_scalar_args(dataTrans * dt, NINF_STUB_INFO * sp, any_t *args, int initiator){
  return trans_scalar_args_ft(dt, sp, args, 0, sp->nparam, initiator);
}

static int call_before_hook(int initiator, int isSend, int type, any_t * arg,
			    int isIN){
  if (initiator){
    if (isSend)
       return EXEC_HOOK_CLIENT_BEFORE_SEND(type, arg, isIN);
    else 
       return EXEC_HOOK_CLIENT_BEFORE_RECV(type, arg, isIN);
  } else {
    if (isSend)
       return EXEC_HOOK_SERVER_BEFORE_SEND(type, arg, isIN);
    else 
       return EXEC_HOOK_SERVER_BEFORE_RECV(type, arg, isIN);
  }
}

static int call_after_hook(int initiator, int isSend, int type, any_t * arg,
			   int isIN){
  if (initiator){
    if (isSend)
       return EXEC_HOOK_CLIENT_AFTER_SEND(type, arg, isIN);
    else 
       return EXEC_HOOK_CLIENT_AFTER_RECV(type, arg, isIN);
  } else {
    if (isSend)
       return EXEC_HOOK_SERVER_AFTER_SEND(type, arg, isIN);
    else 
       return EXEC_HOOK_SERVER_AFTER_RECV(type, arg, isIN);
  }
}


int trans_scalar_args_ft(dataTrans * dt, NINF_STUB_INFO * sp, any_t *args,
  int from, int to, int initiator){
  struct ninf_param_desc *dp;
  int cc = TRUE;
  int i;
  int pos;
  
  /* send IN scalar variables */
  for(i = from; i < to; i++){
    dp = &sp->params[i];
    if(dp->param_type == DT_FUNC_TYPE) break;  /* callback function */

    if ((dp->ndim == 0)){
      if (!call_before_hook(initiator, isSend(dt), dp->param_type, &(args[i]),
			   IS_IN_MODE(dp->param_inout)))
	return FALSE;

      if ((isReceive(dt) && IS_OUT_MODE(dp->param_inout) &&  initiator)||
	  (isSend(dt)    && IS_IN_MODE (dp->param_inout) &&  initiator)||
	  (isReceive(dt) && IS_IN_MODE (dp->param_inout) && !initiator)||
	  (isSend(dt)    && IS_OUT_MODE(dp->param_inout) && !initiator)){
	if (args[i].isHandler){
	  if (ninf_cim_init(args[i].handler) != CIM_OK)
	    return FALSE;
	  if (ninf_cim_get(args[i].handler, &args[i].u.p, dp->param_type) != CIM_OK)
            return FALSE;
	}
	switch(dp->param_type){
	case DT_CHAR:
	    trans_mark_align(dt);
	    trans_char_raw_single(dt,(char *)(&args[i].u.c));
	    trans_align(dt);
	    break;
	case DT_SHORT:
	    trans_mark_align(dt);
	    trans_short_raw_single(dt,(char *)(&args[i].u.s));
	    trans_align(dt);
	    break;
	case DT_INT:
	    cc = trans_int(dt,&args[i].u.i);
	    break;
	case DT_LONG:
	    cc = trans_long(dt,&args[i].u.l);
	    break;
	case DT_UNSIGNED_CHAR:
	    trans_mark_align(dt);
	    trans_char_raw_single(dt,(char *)(&args[i].u.c));
	    trans_align(dt);
	    break;
	case DT_UNSIGNED_SHORT:
	    trans_mark_align(dt);
	    trans_short_raw_single(dt,(char *)(&args[i].u.s));
	    trans_align(dt);
	    break;
	case DT_UNSIGNED:
	    cc = trans_u_int(dt,&args[i].u.ui);
	    break;
	case DT_UNSIGNED_LONG:
	    cc = trans_u_long(dt,&args[i].u.ul);
	    break;
	case DT_FLOAT:
	    cc = trans_float(dt,&args[i].u.f);
	    break;
	case DT_DOUBLE:
	    cc = trans_double(dt,&args[i].u.d);
	    break;
	case DT_STRING_TYPE:
	    cc = trans_string(dt, (char **)(& args[i].u.p), MAX_STRING_LEN);
	    break;
	case DT_LONG_DOUBLE:
	case DT_UNSIGNED_LONGLONG:
	case DT_LONGLONG:
	    ninf_error("not supported data types");
	    break;
	case DT_FILEPOINTER:
	case DT_FILENAME:
	    if (!trans_filepointer(&(args[i]), dt))
		return FALSE;
	    break;
	case DT_SCOMPLEX:
	case DT_DCOMPLEX:   /* should not be scalar */
	default:
	    ninf_error("unknown data type");
	    break;
	}
      } else if ((dp->param_type == DT_FILEPOINTER) || 
		 (dp->param_type == DT_FILENAME)){
	if (!trans_filepointer_null_passing(&(args[i]), dt))
	  return FALSE;
      }
      if (!call_after_hook(initiator, isSend(dt), dp->param_type, &(args[i]),
			   IS_IN_MODE(dp->param_inout)))
	return FALSE;
    }
  }
  return(TRUE);
}


static int (*trans_routine[MAX_DATA_TYPE])(dataTrans *, void *) =
{
    NULL /* UNDEF */,	/* undefined */
     NULL /* VOID */,
    (transFunc)trans_char /* CHAR */,
    (transFunc)trans_short /* SHORT */,
    (transFunc)trans_int /* INT */,
    (transFunc)trans_long /* LONG */,
    NULL /* LONGLONG */,
    (transFunc)trans_char /* UNSIGNED_CHAR */,
    (transFunc)trans_short /* UNSIGNED_SHORT */,
    (transFunc)trans_u_int /* UNSIGNED */,
    (transFunc)trans_u_long /* UNSIGNED_LONG */,
    NULL /* UNSIGNED_LONGLONG */,
    (transFunc)trans_float /* FLOAT */,
    (transFunc)trans_double /* DOUBLE */,
    NULL /* LONG_DOUBLE */,
    (transFunc)trans_string_nolen /* STRING */,
    NULL /* FUNC_TYPE */,
    (transFunc)trans_scomplex /* SCOMPLEX */,    
    (transFunc)trans_dcomplex /* DCOMPLEX */,    

};
void init_resource(resource * rsc){
  rsc->host = NULL;
  rsc->port = NULL;
  rsc->protocol = 0;
  rsc->resource_name = NULL;
  rsc->size = 0;
  rsc->param_type = DT_UNDEF;
  rsc->base = NULL;
  rsc->dim = 0;
  rsc->array_shape = NULL;
}

resource * new_resources(int num){
  int i;
  resource * tmp = (resource *) (malloc(sizeof(resource) * num));
  if (tmp == NULL)
    ninf_fatal("Failed to alloc resources");

  for(i = 0; i < num; i++)
    init_resource(tmp + i);
  return tmp;
}

void resource_free(resource * rsc){
  if (rsc->array_shape != NULL)
    free(rsc->array_shape);
  free(rsc);
}

void set_resource_array(resource * rsc, enum data_type param_type, int dim, MODE_SPEC mode,
		   int size, char * base, array_shape_info * array_shape)
{ 
  rsc->param_type = param_type;
  rsc->base = base;
  rsc->size = size;
  rsc->dim = dim;
  rsc->io_mode = mode;
  rsc->array_shape = (array_shape_info *)malloc(sizeof(array_shape_info) * dim);
  memcpy((void *) (rsc->array_shape), (void *)array_shape, 
	 sizeof(array_shape_info) * dim);
}

void set_resource_any(resource * rsc,  enum data_type param_type, int dim, MODE_SPEC mode,
		 int size, char * base, array_shape_info * array_shape)
{
  rsc->param_type = param_type;
  rsc->base = base;
  rsc->size = size;
  rsc->dim = dim;
  rsc->io_mode = mode;
  rsc->array_shape = (array_shape_info *)malloc(sizeof(array_shape_info) * dim);
  memcpy((void *) (rsc->array_shape), 
	 (void *)array_shape, sizeof(array_shape_info) * dim);
}


/* fix array shape in array. return the number of data to be transfered. */
int trans_array_shape(struct ninf_param_desc *dp, 
		      NINF_STUB_INFO *sp,
		      any_t *args, array_shape_info * array_shape, 
		      int *in_header)
{
    int size,start,end,step,count,total_size,total_count;
    int d,ndim;

    ndim = abs(dp->ndim);
    total_size = DATA_TYPE_SIZE(dp->param_type); 	/* element size */
    total_count = 1;
    for (d = 0; d < ndim; d++){
      array_shape[d].elem_size = total_size;
      size = ninf_get_value(dp->dim[d].size_type,
			    dp->dim[d].size,
			    &(dp->dim[d].size_exp), sp,args,0, in_header[d]);
      total_size *= size;
      
      start = ninf_get_value(dp->dim[d].start_type,
			     dp->dim[d].start,
			     &(dp->dim[d].start_exp), sp,args,0, 0);
      array_shape[d].start = start;
      
      end = ninf_get_value(dp->dim[d].end_type,
			   dp->dim[d].end,
			   &(dp->dim[d].end_exp), sp,args,size, in_header[d]);
      array_shape[d].end = end;
      
      step = ninf_get_value(dp->dim[d].step_type,
			    dp->dim[d].step,
			    &(dp->dim[d].step_exp), sp,args,1, 0);
      array_shape[d].step = step;
      
      /* calculuate the number of element to be sent */

      if (sp->shrink){
	if(start < end && step > 0)
	  count = (end - start + step-1)/step;	/* round */
	else if(start > end & step < 0)
	  count = (start - end + step-1)/step;
	else ninf_error("bad range value %d:%d,%d,%d",size,start,end,step);
      } else {
	/* in no-shrink case, all the array shoud be transmitted */
	/*	if(start < end && step > 0)  
		count = end ;
		else if(start > end & step < 0)
		count = start ; 
		else ninf_error("bad range value %d:%d,%d,%d",size,start,end,step);
	*/
	count = size;
      }
      if(count != 0) total_count *= count;
    }
    return(total_count);
}


int trans_array_rec(dataTrans *dt, transFunc trans_func, char *base, int dim, 
		    array_shape_info * array_shape, enum data_type param_type)
{
  int i,size,start,end,step /*,cc */;
  int pos;
  
  dim--;
  start = array_shape[dim].start;
  end = array_shape[dim].end;
  step= array_shape[dim].step;
  size = array_shape[dim].elem_size;
  
  if (dim == 0){
    if (step == 1 && start == 0){
      if (!trans_any(dt, param_type, end - start, base))
	return FALSE;
    }else {
      for (i = start; i < end; i += step)
	(*trans_func)(dt,base + i*size);
    }
  } else {
    for(i = start; i < end; i += step)
      if(!trans_array_rec(dt,trans_func,base+i*size,dim, array_shape, param_type))
	return(FALSE);
  }
  return(TRUE);
}

/* xdr to request */
int trans_request(dataTrans *dt, int req)
{
    return(trans_int(dt,&req));
}

int trans_array(dataTrans *dt, enum data_type param_type, int dim, char *base, 
		array_shape_info * array_shape){
    int cc;
    cc = trans_array_rec(dt, trans_routine[param_type],
			 base, dim, array_shape, param_type);
    return(cc);
}

int trans_array_handler_rec(dataTrans *dt, transFunc trans_func, 
		    obj_handler handler, int dim, 
		    array_shape_info * array_shape, DATA_TYPE param_type)
{
  int i,size,start,end,step /*,cc */;
  int pos;
  
  dim--;
  start = array_shape[dim].start;
  end   = array_shape[dim].end;
  step  = array_shape[dim].step;
  size  = array_shape[dim].elem_size;
  
  if (dim == 0){
    for (i = start; i < end; i += step){
      char buffer[16];
      if (isSend(dt)){
	if (ninf_cim_get(handler, buffer, param_type) != CIM_OK)
	  return FALSE;
	if (!(*trans_func)(dt, buffer))
	  return FALSE;
      } else {
	if (!(*trans_func)(dt, buffer))
	  return FALSE;
	if (ninf_cim_put(handler, buffer, param_type) != CIM_OK)
	  return FALSE;
      }
      if (ninf_cim_proceed(handler, 0, step) != CIM_OK)
	return FALSE;
    }
  } else {
    for(i = start; i < end; i += step){
      if(!trans_array_handler_rec(dt, trans_func, handler, dim, array_shape, param_type))
	return(FALSE);
      if (ninf_cim_proceed(handler, dim, step) != CIM_OK)
	return(FALSE);
    }
  }
  return(TRUE);
}

int trans_array_handler(dataTrans *dt, enum data_type param_type, int dim, obj_handler handler,
		array_shape_info * array_shape){
  int ret;
  if (ninf_cim_init(handler) != CIM_OK)
    return FALSE;
  ret = trans_array_handler_rec(dt, trans_routine[param_type], handler, dim, array_shape, param_type);
  if (isReceive(dt)){
    if (ret == FALSE){
      ninf_cim_destruct(handler);
      return FALSE;
    }
    if (ninf_cim_finalize(handler) != CIM_OK){
      ninf_cim_destruct(handler);
      return FALSE;
    }
  }
  return ret;
}

/************************* functions ***********************/
char *save_str(char * s)
{
    char *p;
    if (s == NULL)
      return NULL;
    p = (char *)malloc(strlen(s)+1);
    if (p == NULL) {
      ninf_fatal("Failed to malloc in save_str");
      return NULL;
    }
    strcpy(p,s);
    return(p);
}


static int lookup_flag = TRUE;
void set_lookup_flag(int i){
  lookup_flag = i;
}


/* returns char[4] notation of ipaddress */
char * getpeerAddr(int ns){
  struct sockaddr_in myaddr;
  struct hostent * hp;
  int peer;
  int size = sizeof(myaddr);

  static char buffer[4];
  if (getpeername(ns, (struct sockaddr *)&myaddr, &size) < 0){
    perror("getpeername");
    return NULL;
  }
  peer = myaddr.sin_addr.s_addr;
  peer = ntohl(peer);
  buffer[0] = ((peer & ((unsigned int)0xff << (8*3))) >> (8*3)) & 0xff;
  buffer[1] = ((peer & ((unsigned int)0xff << (8*2))) >> (8*2)) & 0xff;
  buffer[2] = ((peer & ((unsigned int)0xff << (8*1))) >> (8*1)) & 0xff;
  buffer[3] = ((peer & ((unsigned int)0xff << (8*0))) >> (8*0)) & 0xff;
  return buffer;
}

#include <sys/utsname.h>
char * myhostname(){
  static char buffer[20];
  static struct utsname buf;
  struct hostent * hent;
  char * addr;

  if (uname(&buf) < 0){
    perror("uname");
    ninf_log("failed to uname");
    return NULL;
  }
  
  hent = gethostbyname(buf.nodename);
  addr = hent->h_addr_list[0];

  sprintf(buffer, "%d.%d.%d.%d", 
	  addr[0] & 0xff, addr[1] & 0xff, addr[2] & 0xff, addr[3] & 0xff);
  return buffer;
}


/*  returns string like "127.0.0.1" */
char * getpeer(int ns){
  static char buffer[20];
  struct sockaddr_in myaddr;
  struct hostent * hp;
  unsigned int peer;
  int size = sizeof(myaddr);
  int i;

  if (getpeername(ns, (struct sockaddr *)&myaddr, &size) < 0){
    perror("getpeername");
    return "FAILED";
  }
  peer = myaddr.sin_addr.s_addr;

  if (lookup_flag){
    hp = gethostbyaddr((char *)&peer, sizeof(peer), AF_INET);
    if (hp != NULL) {
      strncpy(buffer, hp->h_name, 127);
      return buffer;
    }
  }
  peer = ntohl(peer);
  sprintf(buffer, "%d.%d.%d.%d", 
	  ((peer & ((unsigned int)0xff << (8*3))) >> (8*3)) & 0xff,
	  ((peer & ((unsigned int)0xff << (8*2))) >> (8*2)) & 0xff,
	  ((peer & ((unsigned int)0xff << (8*1))) >> (8*1)) & 0xff,
	  ((peer & ((unsigned int)0xff << (8*0))) >> (8*0))& 0xff);

  return buffer;
}

int getpeerport(int ns){
  struct sockaddr_in myaddr;
  int size = sizeof(myaddr);
  int i;

  if (getpeername(ns, (struct sockaddr *)&myaddr, &size) < 0){
    perror("getpeername");
    return -1;
  }
  return ntohs(myaddr.sin_port);
}

/* returns the argument is socket or not */
int isSocket(int ns){
  struct sockaddr_in myaddr;
  int peer;
  int size = sizeof(myaddr);
  int i;

  if (getsockname(ns, (struct sockaddr *)&myaddr, &size) < 0)
    return FALSE;
  return TRUE;
}

/***** for server socket *****/
int init_server_socket(unsigned int addr, int port, int max_listen){
    struct sockaddr_in myaddr;
    int size, sock;

    myaddr.sin_port = port;
    myaddr.sin_port = htons(myaddr.sin_port);
    
    myaddr.sin_family = AF_INET;
    myaddr.sin_addr.s_addr = addr;
    size = sizeof(myaddr);
    sock = socket(PF_INET,SOCK_STREAM,0);
    if (sock < 0){
      perror("socket");
      ninf_log("socket failed");
      return -1;
    }
    if (bind(sock, (struct sockaddr *)&myaddr,size) < 0){
      perror("bind");
      ninf_log("bind failed for port[%d]", port);
      return -1;
    }
    if (listen(sock, max_listen) < 0){
	perror("listen failed");
	ninf_log("master listen failed: socket %d, Aborting", sock);
	return -1;
    }
    return sock;
}

/***** for server socket *****/
int init_server_socket_from(unsigned int addr, int * port_from, int max_listen, 
			    int try_max){
    struct sockaddr_in myaddr;
    int size, sock, i;
    int binded = FALSE;

    sock = socket(PF_INET,SOCK_STREAM,0);
    if (sock < 0){
      perror("socket");
      ninf_log("socket failed");
      return -1;
    }

    for (i = 0; i < try_max; i++, (*port_from)++){
      myaddr.sin_port = *port_from;
      myaddr.sin_port = htons(myaddr.sin_port);
    
      myaddr.sin_family = AF_INET;
      myaddr.sin_addr.s_addr = addr;
      size = sizeof(myaddr);
      if (bind(sock, (struct sockaddr *)&myaddr,size) == 0){
	binded = TRUE;
	break;
      }
    }
    if (!binded)
      return -1;

    if (listen(sock, max_listen) < 0){
	perror("listen failed");
	ninf_log("master listen failed: socket %d, Aborting", sock);
	return -1;
    }
    return sock;
}

/*** printversion ***/
void print_version(){
  fprintf(stderr, "Ninf Version %d.%d\n", MAJOR_VERSION, MINOR_VERSION);
  exit(0);
}

