#include "ninf_read_config.h"
#include "throughput_measure.h"

#define MPI_COMMAND_NAME "mpirun"
extern int ninf_debug_flag;

extern struct read_stub_item * read_stub_item_root;
extern struct metaserver_item * metaserver_item_root;
extern char * logfile;
extern char * myname;
extern int redirect_outerr;

extern int linpack_size;
extern int performance;
extern int CPUs;
extern int MPI_PROCS;
extern char * MPIRUN;
extern char * TMP_FILE_ROOT;

extern measure_server * measure_servers;
extern int measure_interval;   /*  interval */
extern int measure_size;       /*  throughputSize */

#ifdef CONFIG_MAIN 
/* initial value for configurations */
struct read_stub_item * read_stub_item_root = NULL;
struct metaserver_item * metaserver_item_root = NULL;
char * logfile = NULL;
char * myname = NULL;
int redirect_outerr = TRUE;

int linpack_size = 300;
int performance = -1;
int CPUs = 1;
int MPI_PROCS = 1;
char * MPIRUN = MPI_COMMAND_NAME;
char * TMP_FILE_ROOT = "/tmp";

measure_server * measure_servers = NULL; 
int measure_interval = 1000;   /*  interval */
int measure_size = 2000;       /*  throughputSize */


#endif 
