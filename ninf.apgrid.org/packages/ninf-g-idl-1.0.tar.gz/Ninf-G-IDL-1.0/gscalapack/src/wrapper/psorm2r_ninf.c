#define _WRAPPER_
/* $Id: psorm2r_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define FLOAT
#include <gscalapack.h>

#define ROW_a lda
#define COL_a k
#define ROW_c ldc
#define COL_c n
static	int worklen(char side, int m, int n) {
	  int ret=1;
	  int LCMQ, IROFFC, ICOFFC, ICROW, ICCOL, MpC0, NqC0;
#define MB_C rbloc
#define NB_C cbloc
#define RSRC_C 0
#define CSRC_C 0
	  if (chrcmp(side , 'L')==0)  ret = m + MAX( 1, n );
	  else ret = n + MAX( MAX( 1, m ), n );
	  if NEED_BUFF {
	    LCMQ = LCM(NPROW, NPCOL) / NPCOL;
	    IROFFC = MOD( IC-1, MB_C );
	    ICOFFC = MOD( JC-1, NB_C );
	    ICROW = INDXG2P( IC, MB_C, MYROW, RSRC_C, NPROW );
	    ICCOL = INDXG2P( JC, NB_C, MYCOL, CSRC_C, NPCOL );
	    MpC0 = NUMROC( M+IROFFC, MB_C, MYROW, ICROW, NPROW );
	    NqC0 = NUMROC( N+ICOFFC, NB_C, MYCOL, ICCOL, NPCOL );

	    if (chrcmp(side , 'L')==0)  ret = MpC0 + MAX( 1, NqC0 );
	    else ret = NqC0 + MAX( MAX( 1, MpC0 ), NUMROC( NUMROC( N+ICOFFC,NB_A,0,0,NPCOL ),NB_A,0,0,LCMQ ) );
	  }
	  return ret;
}

void  psorm2r_ninf(	 char side,
		 char trans,
		 int m,
		 int n,
		 int k,
		 float global_a[],
		 int lda,
		 float global_tau[],
		 float global_c[],
		 int ldc,
		 float work[],
		 int lwork,
		 int *info
)
/* "psorm2r overwrites the general real M-by-N distributed matrix C with\\n\\n                      SIDE = 'L'            SIDE = 'R'\\n  TRANS = 'N':      Q * C          C * Q\\n  TRANS = 'T':      Q**T * C       C * Q**T\\n\\n  where Q is a real orthogonal distributed matrix defined as the product of k elementary reflectors\\n\\n        Q = H(1) H(2) ." */
/* OPTIONS */
{
	int maxldd;

	int maxlda;
	float *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
	int row_loca, col_loca;

        float *loctau=NULL;
        
	int maxldc;
	float *locc=NULL;
	int descc[DESCLEN];
	int desc_gc[DESCLEN];
	int row_locc, col_locc;

	float *locwork=NULL;
	int llocwork;


	INITIALIZE();

	SCALAR( "char", side);
	SCALAR( "char", trans);
	SCALAR( "int", m);
	SCALAR( "int", n);
	SCALAR( "int", k);
	SCALAR( "int", lda);
	SCALAR( "int", ldc);
	SCALAR( "int", lwork);

	ROW( a);
	COL( a);
	ROW( c);
	COL( c);
	MAXLDD( maxldd, c );
	maxlda = maxldd;
	maxldc = maxldd;

	MATRIX( "float", a, ROW_a, COL_a);
	MATRIX( "float", c, ROW_c, COL_c);
	DISTRIBUTE( "float", a, ROW_a, COL_a);
	DISTRIBUTE( "float", c, ROW_c, COL_c);
	VECTOR("c","float", tau, k);
	vDISTRIBUTE( "c", "float", tau, k );

	llocwork = worklen(side, m, n);
	llocwork = max(lwork, llocwork);
	WORK(locwork,llocwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(psorm2r)( &side, &trans, &m, &n, &k,
                               loca, &one, &one, desca,
                               loctau,
                               locc, &one, &one, descc,
                               locwork, &llocwork,
                               &linfo);

	GATHER( "float", c, ROW_c, COL_c);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
		*info = linfo;
	} else {
	}

	FREE_MATRIX(a);
	FREE_MATRIX(c);
	FREE_VECTOR(tau);
        FREE(locwork);
}

