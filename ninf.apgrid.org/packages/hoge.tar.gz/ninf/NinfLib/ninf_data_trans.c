#include <stdio.h>
#define CONV_USE_XDR

#include <stdlib.h>
#include <string.h>
#include "ninf_data_trans.h"
#include "ninf_macros.h"
#include "ninf_error.h"

struct ninf_param_desc * new_ninf_param_desc(int num);

#ifdef  __cplusplus
extern "C" {
#endif
bool_t xdr_string_len(XDR *xdrs, char  **sp);
bool_t xdr_scomplex(XDR *xdrs, float *bp);
bool_t xdr_dcomplex(XDR *xdrs, double *bp);
#ifdef  __cplusplus
}
#endif

int filepointer_server_before_recv(any_t *args, int isIN){
  void * tmp;
  tmp = (void *) make_tmp_fp("w+");
  if (tmp == NULL) return FALSE;
  args->u.p = tmp;
  return TRUE;
}

int filepointer_server_after_recv(any_t *args, int isIN){
  rewind((FILE *)(args->u.p));
  return TRUE;
}

int filepointer_server_before_send(any_t *args, int isIN){
  rewind((FILE *)(args->u.p));
  return TRUE;
}
int filepointer_server_after_send(any_t *args, int isIN){
  fclose((FILE *)(args->u.p));
  return TRUE;
}


int filename_client_before_recv(any_t *args, int isIN){
  FILE * fp;
  args->filename = args->u.p;
  if (!isIN) {
    fp =  fopen(args->filename, "w");
    if (fp == NULL)
      return FALSE;
    args->u.p = (void *)fp;
    return TRUE;
  }
  return TRUE;
}

int filename_client_after_recv(any_t *args, int isIN){
  if (!isIN){
    fflush((FILE *)(args->u.p));
    fclose((FILE *)(args->u.p));
  }
  return TRUE;
}

int filename_client_before_send(any_t *args, int isIN){
  FILE * fp;
  args->filename = args->u.p;
  if (isIN) {
    if (args->filename == NULL){
      args->u.p = NULL;
      args->isFileNull = TRUE;
      return TRUE;
    }
    fp =  fopen(args->filename, "r");
    if (fp == NULL)
      return FALSE;
    args->u.p = (void *)fp;
  } else {
    if (args->filename == NULL)
      args->isFileNull = TRUE;
  }
  return TRUE;
}

int filename_client_after_send(any_t *args, int isIN){
  args->u.p = args->filename;
  return TRUE;
}


int filename_server_before_recv(any_t *args, int isIN){
  void * tmp;
  char * filename;
  tmp = (void *) make_tmp_fp_filename("w+", &filename);
  if (tmp == NULL) return FALSE;
  args->filename = filename;
  args->u.p = tmp;
  return TRUE;
}

int filename_server_after_recv(any_t *args, int isIN){
  fflush((FILE *)(args->u.p));
  fclose((FILE *)(args->u.p));

  /* fprintf(stderr, "filename_server_after_recv\n"); */

  if (args->isFileNull){
    args->u.p = NULL;
  }  else {
    /* replace the Filepointer with filename */
    args->u.p = args->filename;
  }
  return TRUE;
}

int filename_server_before_send(any_t *args, int isIN){
  FILE * fp;
  if (!isIN){
    if (args->isFileNull){
      args->u.p = NULL;
    }      
    fp =  fopen(args->filename, "r");
    if (fp == NULL)
      return FALSE;
    args->u.p = (void *)fp;
  }
  return TRUE;
}

int filename_server_after_send(any_t *args, int isIN){
  if (!isIN){
    if (args->isFileNull)
      return TRUE;
    fflush((FILE *)(args->u.p));
    fclose((FILE *)(args->u.p));
  }
  return TRUE;
}



data_description DataDescription[] = {
    /* UNDEF */  
    {0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL},
    
    /* VOID, */  
    {0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL},

    /* CHAR,*/   
    {1, sizeof(char), (xdrFunc)xdr_char, 
     NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL},

    /* SHORT,*/  
    {2, sizeof(short), (xdrFunc)xdr_short, 
     NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL},

    /* INT,*/
    {4, sizeof(int), (xdrFunc)xdr_int,
     NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL},

    /* LONG,*/
    {4, sizeof(long), (xdrFunc)xdr_long,
     NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL}, 

    /* LONGLONG,*/
#ifndef _NO_LONGLONG_
    {8, sizeof(long), (xdrFunc)xdr_longlong_t,
     NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL},
#else
    {8, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL},
#endif 

    /* UNSIGNED_CHAR,*/
    {1, sizeof(unsigned char), (xdrFunc)xdr_u_char,
     NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL},

    /* UNSIGNED_SHORT,*/
    {1, sizeof(unsigned short), (xdrFunc)xdr_u_short,
     NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL},

    /* UNSIGNED,*/
    {4, sizeof(unsigned int), (xdrFunc)xdr_u_int,
     NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL},

    /* UNSIGNED_LONG,*/
    {4, sizeof(unsigned long), (xdrFunc)xdr_u_long,
     NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL},

    /* UNSIGNED_LONGLONG,*/
#ifndef _NO_LONGLONG_
    {8, sizeof(unsigned long), (xdrFunc)xdr_u_longlong_t,
     NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL},
#else
    {8, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL},
#endif 

    /* FLOAT,*/
    {4, sizeof(float), (xdrFunc)xdr_float,
     NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL},

    /* DOUBLE,*/
    {8, sizeof(double), (xdrFunc)xdr_double,
     NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL},

    /* LONG_DOUBLE,*/
    {16, 0, NULL,
     NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL},

    /* STRING_TYPE,*/
    {0, sizeof(char *), (xdrFunc)xdr_string_len,
     NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL},

    /* FUNC_TYPE,*/
    {0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL},

    /* SCOMPLEX */
    {8,  sizeof(float) * 2, (xdrFunc)xdr_scomplex,
     NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL},

    /* DCOMPLEX */
    {16, sizeof(double) * 2, (xdrFunc)xdr_dcomplex,
     NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL},

    /* FILEPOINTER */
    {0, sizeof(void *), NULL,
     NULL, NULL, NULL, NULL, 
     filepointer_server_before_send,
     filepointer_server_after_send,
     filepointer_server_before_recv,
     filepointer_server_after_recv},

    /* FILENAME    */
    {0, sizeof(char *), NULL,
     filename_client_before_send,
     filename_client_after_send,
     filename_client_before_recv,
     filename_client_after_recv,
     filename_server_before_send,
     filename_server_after_send,
     filename_server_before_recv,
     filename_server_after_recv},
};

int do_onemore(dataTrans * dt){
  if (dt->flag == XDR_ENCODE) 
    return write_flush(dt);
  else 
    return read_onemore(dt);
}

void print_dt(dataTrans * dt){
  printf("%x: %x-%d-%x-%d-%x-%d-%x\n", dt, dt->start, dt->position - dt->start, dt->position, dt->valid_end - dt->position, dt->valid_end, dt->end - dt->valid_end, dt->end);
}

int isSend(dataTrans *dt){
  return (dt->flag == XDR_ENCODE);
}
int isReceive(dataTrans *dt){
  return (dt->flag == XDR_DECODE);
}

int trans_count(dataTrans *dt){
  if (dt->flag == XDR_ENCODE)
    return(dt->position - dt->start);
  return(dt->valid_end - dt->position);
}

/***************************************/
dataTrans * new_dataTrans(int fd, int flag, int withHeader
#ifdef SSL_USE
			  , SSL * ssl
#endif 
){
  dataTrans * tmp;
  if ((tmp = (dataTrans *)malloc(sizeof(dataTrans))) == NULL)
    return NULL;
  tmp->start = tmp->buffer;
  tmp->position = tmp->start;
  tmp->valid_end = tmp->start;
  tmp->end = tmp->start + STUB_BUF_SIZE;
  tmp->fd = fd;
  tmp->flag = flag;
  tmp->withHeader = withHeader;
  tmp->dying = FALSE;
#ifdef SSL_USE
  tmp->ssl   = ssl;
#endif 

/*
  {
    long flag;
    flag = fcntl(fd, F_GETFL);
    
    ninf_error("fd %d: no-blocking flag is %s", fd, ((flag & O_NONBLOCK) == 0)? "FALSE":"TRUE");

  }
*/

  /*  set_no_delay(fd); */
  return tmp;
}

void free_dataTrans(dataTrans * dt){
  free(dt);
}

void force_write_with(dataTrans *dt_out, dataTrans *dt_org, 
		      int code, int arg1, int arg2){
  dt_out->decoded.code = code;
  dt_out->decoded.arg1 = arg1;
  dt_out->decoded.arg2 = arg2;
  force_write(dt_out, dt_org);
}

/** writeout the content of dt_org to dt_out */
void force_write(dataTrans *dt_out, dataTrans *dt_org){
#ifdef SSL_USE
  SSL * sslBack      = dt_out->ssl;
#endif 
  int RWFlagBack     = dt_out->flag;
  int headerFlagBack = dt_out->withHeader;
  int fdBack         = dt_out->fd;

#ifdef SSL_USE
  dt_out->ssl        = dt_org->ssl;
#endif 
  dt_out->flag       = dt_org->flag;
  dt_out->withHeader = dt_org->withHeader;
  dt_out->fd         = dt_org->fd;
  dt_out->position   = dt_out->valid_end;

  write_flush(dt_out);

#ifdef SSL_USE
  dt_out->ssl        = sslBack;
#endif 
  dt_out->fd         = fdBack;
  dt_out->valid_end  = dt_out->start;
  dt_out->flag       = RWFlagBack;
  dt_out->withHeader = headerFlagBack;
}

void trans_flush(dataTrans * dt, int code, int arg1, int arg2){
  dt->decoded.code = code;
  dt->decoded.arg1 = arg1;
  dt->decoded.arg2 = arg2;
  write_flush(dt);
}

void set_trans_header(dataTrans * dt, int code, int arg1, int arg2){
  dt->decoded.code = code;
  dt->decoded.arg1 = arg1;
  dt->decoded.arg2 = arg2;
}

void trans_destroy(dataTrans * dt){
  if (dt->flag == XDR_ENCODE)
    write_flush(dt);
}

#ifdef linux
#define READ_FAIL 0
#else
#define READ_FAIL 0
#endif  

int timeout(int fd, int sec, int usec){
    fd_set rfds;
    int n;
    struct timeval timeoutval;
    timeoutval.tv_sec = sec;
    timeoutval.tv_usec = usec;

    FD_ZERO(&rfds);
    FD_SET(fd, &rfds);
    n = select(fd + 1, &rfds, NULL, NULL, &timeoutval);
    if (n == 0)
      return TRUE;
    return FALSE;
}


int write_to(int fd, char * buffer, int bytes, dataTrans * env){
#ifdef WIN32
  return send(fd, startPoint, dt->position - startPoint, NO_FLAGS_SET);
#elif defined(SSL_USE)
  if (env->ssl == NULL)
    return write(fd, buffer, bytes);
  else
    return SSL_write(env->ssl, buffer, bytes);
#else
  return write(fd, buffer, bytes);
#endif
}


int read_from(int fd, char * buffer, int bytes, dataTrans * env){
#ifdef WIN32   
  return recv(fd, buffer, bytes, NO_FLAGS_SET);
#elif defined(SSL_USE)
  if (env->ssl == NULL)
    return read(fd, buffer, bytes);
  else
    return SSL_read(env->ssl, buffer, bytes);
#else  
  return read(fd, buffer, bytes);
#endif
}

int read_stick(int fd, char * buffer, int bytes, dataTrans * env){
  int count = 0, tmp;
  int dying = env->dying;
  while (count < bytes){
#ifndef WIN32    /** usual case */
    if (dying)
      if (timeout(fd, 1, 0))
	return 0;
#endif
    if ((tmp = read_from(fd, buffer, bytes - count, env)) <= READ_FAIL)
      return count;

    count += tmp;
    buffer += tmp;
  }
  return count;
}

/*
FILE * stub_out = stdout;
FILE * stub_err = stderr;
*/
FILE * stub_out = NULL;
FILE * stub_err = NULL;

char outerr_buffer[MAX_PKT_LEN];
handle_outerr(dataTrans * dt){
  int len, readed, i;
  FILE * fp;
  if (stub_out == NULL)
    stub_out = stdout;
  if (stub_err == NULL)
    stub_err = stderr;

  len = dt->decoded.size - NINF_PKT_HEADER_SIZE;

  if ((readed = read_stick(dt->fd, outerr_buffer, len, dt)) < len){
    ninf_debug("readed = %d, len = %d", readed, len);

    return FALSE;   /* what to do */
  }
  if (NINF_PKT_CODE(&(dt->decoded)) == NINF_PKT_STDOUT)
    fp = stub_out;
  else
    fp = stub_err;
  for (i = 0; i < readed; i++)
    putc(outerr_buffer[i], fp);
  fflush(fp);
}

int read_onemore_org(dataTrans * dt, int stick_to_read);

int read_onemore(dataTrans * dt){
  return read_onemore_org(dt, TRUE);
}


int read_onemore_org(dataTrans * dt, int stick_to_read){
  int offset = 0;
  int len, readed;
  if (dt->withHeader){
    char tbuf[NINF_PKT_HEADER_SIZE];
    if (read_stick(dt->fd, tbuf, NINF_PKT_HEADER_SIZE, dt) < NINF_PKT_HEADER_SIZE){
	  ninf_error_code = NINF_ERROR_CANTCONNECTSERVER;
      return FALSE;
	}
    reorder_header_inner(tbuf, &(dt->decoded));
    ninf_debug("reading: size = %d, code = %d, arg1 = %d, arg2 = %d", 
	       dt->decoded.size, dt->decoded.code, 
	       dt->decoded.arg1, dt->decoded.arg2);      
    ninf_error_code = NINF_PKT_ARG1(&(dt->decoded));
    len = dt->decoded.size - NINF_PKT_HEADER_SIZE;
    if ((NINF_PKT_CODE(&(dt->decoded)) == NINF_PKT_STDOUT) ||
	(NINF_PKT_CODE(&(dt->decoded)) == NINF_PKT_STDERR)){
      ninf_debug("stdout forwarded");
      handle_outerr(dt);
      if (stick_to_read) 
	return read_onemore(dt);
      else
	return TRUE;
    } else if (NINF_PKT_CODE(&(dt->decoded)) == NINF_PKT_ERROR){
      return FALSE;
    }
  }
  if (dt->valid_end > dt->position){
    offset = dt->valid_end - dt->position;
    memcpy(dt->start, dt->position, offset);
  }
  dt->position = dt->start + offset;
  if (dt->withHeader){
    if ((readed = read_stick(dt->fd, dt->position, len, dt)) < len){
	  ninf_error_code = NINF_ERROR_CANTCONNECTSERVER;
      return FALSE;
	}
  } else {
    if ((readed = read_from(dt->fd, dt->position, STUB_BUF_SIZE - offset, dt)) <= READ_FAIL){
      dt->valid_end = dt->position;
      dt->position = dt->start;
	  ninf_error_code = NINF_ERROR_CANTCONNECTSERVER;
      return FALSE;
    }
  }

  dt->valid_end = dt->position + readed;
  dt->position = dt->start;
  ninf_debug("READ : %d", readed);
  return TRUE;
}

int write_flush(dataTrans * dt){
  int tmp, size;
  int i;
  char * startPoint;
  if (dt->withHeader){
    dt->decoded.size = dt->position - dt->start + NINF_PKT_HEADER_SIZE;
    reorder_header_network(&(dt->decoded), dt->header);
    startPoint = dt->header;
    ninf_debug("write size = %d, code = %d, arg1 = %d, arg2 = %d", 
	       dt->decoded.size, dt->decoded.code, 
	       dt->decoded.arg1, dt->decoded.arg2);
  }else
    startPoint = dt->start;
  size = dt->position - startPoint;
  tmp = write_to(dt->fd, startPoint, dt->position - startPoint, dt);

  ninf_debug("write result: %d", tmp);
  dt->position = dt->start;
  if (tmp < 0)
    return FALSE;
  return TRUE;
}

/* returns a pointer points VOLATILE string.
   User must copy the string before calling the next dataTrans 
   functions. */
char * read_line_dataTrans(dataTrans * dt){
  char * ans = NULL;
  char * tmp;
  int proceed = 0;
  for (;;){
    for (tmp = dt->position; tmp < dt->valid_end - 1; tmp++){
      if (*tmp == 0x0d) {
	if (*(tmp+1) == 0x0a)
	  proceed = 2;
	else
	  proceed = 1;
	*tmp = 0x0;
	ans = dt->position;
	dt->position = tmp + proceed;
	return ans;
      } else if (*tmp == 0x0a) {
	proceed = 1;
	*tmp = 0x0;
	ans = dt->position;
	dt->position = tmp + proceed;
	return ans;
      }
    }
    if (!read_onemore(dt)){
      if (dt->position != dt->valid_end){
	*(dt->valid_end) = 0x0;
	return dt->position;
      } else
	return NULL;
    }
  }
}

int trans_read_skip(dataTrans * dt, int count){
  int rest_items;
  rest_items = (dt->valid_end - dt->position);
  while (TRUE){
    if (rest_items < count){
      dt->position += rest_items;
      if (!read_onemore(dt))
	return FALSE;
      count -= rest_items;
      rest_items = (dt->valid_end - dt->position);
    }else{
      dt->position += count;
      break;
    }
  }
  return TRUE;
}

int trans_write_skip(dataTrans * dt, int count){
  int rest_items;

  rest_items = (dt->end - dt->position);
  while (TRUE){
    if (rest_items < count){
      dt->position += rest_items;
      write_flush(dt);
      count -= rest_items;
      rest_items = (dt->end - dt->position);
    }else{
      dt->position += count;
      break;
    }
  }
  return TRUE;
}

int read_dataTrans(dataTrans * dt, char * buffer, DATA_TYPE type, int count){
  int rest_items;
  if (type == DT_STRING_TYPE)
    return write_dataTrans_string(dt, buffer, count);
  rest_items = (dt->valid_end - dt->position) / xdr_data_length(type);
  ninf_debug("read_dataTrans count: %d, rest_items: %d", count, rest_items);
  while (TRUE){
    if (rest_items < count){
      trans_dataTrans_sub(dt, buffer, type, rest_items);
      if (!read_onemore(dt))
	return FALSE;
      count -= rest_items;
      buffer += rest_items * DATA_TYPE_SIZE(type);
      rest_items = (dt->valid_end - dt->position) / xdr_data_length(type);
    }else{
      trans_dataTrans_sub(dt, buffer, type, count);
      break;
    }
  }
  return TRUE;
}

int write_dataTrans_string(dataTrans * dt, char * buffer, int count){
  int i;
  char ** tmp = (char**)buffer;
  for (i = 0; i < count; i++)
    if (!trans_string(dt, tmp++, MAX_STRING_LEN))
      return FALSE;
  return TRUE;
}


int write_dataTrans(dataTrans * dt, char * buffer, DATA_TYPE type, int count){
  int rest_items;

  if (type == DT_STRING_TYPE)
    return write_dataTrans_string(dt, buffer, count);
  rest_items = (dt->end - dt->position) / xdr_data_length(type);
  while (TRUE){
    if (rest_items < count){
      trans_dataTrans_sub(dt, buffer, type, rest_items);
      write_flush(dt);
      count -= rest_items;
      buffer += rest_items * DATA_TYPE_SIZE(type);
      rest_items = (dt->end - dt->position) / xdr_data_length(type);
    }else{
      trans_dataTrans_sub(dt, buffer, type, count);
      break;
    }
  }
  return TRUE;
}


int trans_any(dataTrans *dt, DATA_TYPE t, int ncount, char * p){
  if (dt->flag == XDR_DECODE)
    return read_dataTrans(dt, p, t, ncount);
  return write_dataTrans(dt, p, t, ncount);
}


int  getArg1(dataTrans * dt){
  return dt->decoded.arg1;
}
int  getArg2(dataTrans * dt){
  return dt->decoded.arg2;
}

int trans_getPacket(dataTrans * dt){
  if (!read_onemore(dt)){
    return -1;
  }
  return dt->decoded.code;
}

void trans_mark_align(dataTrans * dt){
  dt->align_base = dt->position;
}

void trans_align(dataTrans * dt){
  int diff = ((dt->position - dt->start) - (dt->align_base - dt->start)) % 4;
  if (diff != 0)
    dt->position += 4 - diff;
  ninf_debug("add %d for alignment", (4 - diff) % 4);
}
