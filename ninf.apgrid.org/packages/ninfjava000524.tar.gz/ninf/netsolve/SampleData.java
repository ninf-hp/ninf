package ninf.netsolve;
// import java.util.*;
import java.util.StringTokenizer;
import java.util.Random;

public class SampleData {
  public static final int SAMPLE_RANDOM = 1;
  public static final int SAMPLE_PREDEF = 2;

  private String [] int_array =  {"1  2  3  4" , 
                                  "5  6  7  8" , 
                                  "9 10 11 12",
                                  "13 14 15 16"};

/*
  private String [] float_array = { "      1.1      2.2        3.3       4.4" ,
                                    "5.3e-2 6.6e+5        7.0  8.1234" ,
                                    "  9.423   10.23 11.5489  12.0e6",
                                    "  234.2  244.32 6576.34   832.3"};
*/

  private String [] float_array = { "      1.1      2.2        3.3       4.4" ,
                                    "      5.1      6.2        7.3       8.4" ,
                                    "      9.1     10.2       11.3      12.4" ,
                                    "     13.1     14.2       15.3      16.4"};

  private String [] char_array = {"A B C D" , 
                                  "E F G H" , 
                                  "I J K L",
                                  "M N O P"};

/*
  private String [] complex_array = {
   "-0.2407 - 1.7337i  0.0849 + 1.7026i -0.6679 + 1.5993i -0.8093 + 1.1975i",
   "-1.6757 + 0.7538i  1.3753 + 0.8795i 0.7261 - 0.7910i -1.4673 - 1.5228i",
   "-0.4059 + 0.8289i  0.5129 + 0.5800i -0.7450 + 0.3785i -1.1554 + 0.7040i",
   "-0.6679 + 1.5993i  1.3119 + 0.3059i 0.6653 - 1.2907i 0.9009 - 0.6753i"};
*/
  private String [] complex_array = {
     "1+0i 2+0i 3+0i 4+0i",
     "5+0i 6+0i 7+0i 8+0i",
     "9+0i 10+0i 11+0i 12+0i",
     "13+0i 14+0i 15+0i 16+0i"};

  public SampleData(int num_type, int data_type) {
    int i;

    if(num_type == SAMPLE_RANDOM) {
      Random rnd = new Random();
      switch(data_type) {
        case NetSolveObject.NETSOLVE_I:
          for(i=0;i<int_array.length;i++)
            int_array[i] = Integer.toString(rnd.nextInt()) + "  " + 
                           Integer.toString(rnd.nextInt()) + "  " + 
                           Integer.toString(rnd.nextInt()) + "  " + 
                           Integer.toString(rnd.nextInt());
          break;
        case NetSolveObject.NETSOLVE_S:
          for(i=0;i<float_array.length;i++)
            float_array[i] = Float.toString(rnd.nextFloat()) + "  " + 
                             Float.toString(rnd.nextFloat()) + "  " + 
                             Float.toString(rnd.nextFloat()) + "  " + 
                             Float.toString(rnd.nextFloat());
          break;
        case NetSolveObject.NETSOLVE_D:
          for(i=0;i<float_array.length;i++)
            float_array[i] = Double.toString(rnd.nextDouble()) + "  " + 
                             Double.toString(rnd.nextDouble()) + "  " + 
                             Double.toString(rnd.nextDouble()) + "  " + 
                             Double.toString(rnd.nextDouble());
          break;
        case NetSolveObject.NETSOLVE_C:
        case NetSolveObject.NETSOLVE_Z:
          for(i=0;i<complex_array.length;i++)
            complex_array[i] = Double.toString(rnd.nextDouble() * 10.0 - 5.0) 
                             + ((rnd.nextInt() % 2) == 0?" + ":" - ") +
                             Double.toString(rnd.nextDouble() * 10.0 - 5.0) 
                             + "i " +
                             Double.toString(rnd.nextDouble() * 10.0 - 5.0) 
                             + ((rnd.nextInt() % 2) == 0?" + ":" - ") +
                             Double.toString(rnd.nextDouble() * 10.0 - 5.0) 
                             + "i " +
                             Double.toString(rnd.nextDouble() * 10.0 - 5.0) 
                             + ((rnd.nextInt() % 2) == 0?" + ":" - ") +
                             Double.toString(rnd.nextDouble() * 10.0 - 5.0) 
                             + "i " +
                             Double.toString(rnd.nextDouble() * 10.0 - 5.0) 
                             + ((rnd.nextInt() % 2) == 0?" + ":" - ") +
                             Double.toString(rnd.nextDouble() * 10.0 - 5.0) 
                             + "i";
          break;
        case NetSolveObject.NETSOLVE_CHAR:
          for(i=0;i<char_array.length;i++)
            char_array[i] = (char)((rnd.nextInt() % 13) + 12 + 'A') + "  " + 
                            (char)((rnd.nextInt() % 13) + 12 + 'A') + "  " + 
                            (char)((rnd.nextInt() % 13) + 12 + 'A') + "  " + 
                            (char)((rnd.nextInt() % 13) + 12 + 'A');
          break;
        case NetSolveObject.NETSOLVE_EXTERNAL:
          break;
      }
    }
  }

  public String getSampleData(int data_type, int obj_type) {
    switch(data_type) {
      case NetSolveObject.NETSOLVE_I:
        return(getStuff(int_array, obj_type));
      case NetSolveObject.NETSOLVE_S:
      case NetSolveObject.NETSOLVE_D:
        return(getStuff(float_array, obj_type));
      case NetSolveObject.NETSOLVE_C:
      case NetSolveObject.NETSOLVE_Z:
        if(obj_type == NetSolveObject.NETSOLVE_SCALAR) {
          StringTokenizer st = new StringTokenizer(complex_array[0],"i");
          return(st.nextToken() + "i");
        }
        else
          return(getStuff(complex_array, obj_type));
      case NetSolveObject.NETSOLVE_CHAR:
        return(getStuff(char_array, obj_type));
      case NetSolveObject.NETSOLVE_EXTERNAL:
        return(new String("Type your UPF here."));
      default:
        return(new String("UNKNOWN DATA TYPE"));
    }
  }

  private String getStuff(String [] str, int obj_type) {
    switch(obj_type) {
      case NetSolveObject.NETSOLVE_MATRIX:
        return(str[0] + "\n" + str[1] + "\n" + str[2] + "\n" + str[3]);
      case NetSolveObject.NETSOLVE_VECTOR:
        return(str[0]);
      case NetSolveObject.NETSOLVE_SCALAR:
        StringTokenizer st = new StringTokenizer(str[0]);
        return(st.nextToken());
      case NetSolveObject.NETSOLVE_UPF:
        // this case shouldn't be reached
        System.err.println("SampleData.getStuff(): invalid object type!");
        return null;
      default:
        return(new String("UNKNOWN OBJECT TYPE"));
    }
  }
}
