package ninf.MetaServer;
import ninf.basic.*;
import ninf.basic.NinfIOException;
import ninf.client.*;

import java.io.IOException;
import java.util.Vector;
import java.util.Hashtable;
import java.util.Enumeration;

public class FunctionManager {
  //********************** NON STATIC VARIABLES ***********************

  /** Vector of NinfServerStruct */
  Vector ninfServerList;

  /** Vector of MetaServer */
  Vector metaServerList;

  /** table: entry name -> NinfFunction */
  Hashtable functionDic;

  /** Vector NinfFunction : no -> NinfFunction */
  Vector functionTable;

  FunctionStructFactory functionStructFactory;

  //*********************** INSTANCE CREATION  ***********************
  public FunctionManager() {
    ninfServerList = new Vector();
    functionDic = new Hashtable();
    functionTable = new Vector();
    metaServerList = new Vector();
    functionStructFactory = new FunctionStructFactory();
  }

  public void setFunctionStructFactory(FunctionStructFactory functionStructFactory){
    this.functionStructFactory = functionStructFactory;
  }

  // ********************** NON STATIC METHODS   ***********************
  public void addNinfServer(String name, int port, int performance) {
    ninfServerList.addElement(new NinfServerStruct(name, port, performance));
  }

  public void addNinfServer(NinfServerStruct s) {
    ninfServerList.addElement(s);
    s.addManager(this);
  }

  public void removeNinfServer(NinfServerStruct s) {
    ninfServerList.removeElement(s);
    for (int i = 0; i < functionTable.size(); i++){
      CallableStruct tmp = (CallableStruct)functionTable.elementAt(i);
      if (tmp instanceof NinfFunctionStruct)
	((NinfFunctionStruct)tmp).rmServer(s);
    }
  }

  public void addMetaServer(String name, int port) {
    metaServerList.addElement(new NinfServerStruct(name, port));
  }

  public int getMetaServerNum() {
    return metaServerList.size();
  }

  public int getNinfServerNum() {
    return ninfServerList.size();
  }

  public int getNinfFunctionNum() {
    return functionTable.size();
  }

  public Vector  getFunctions(){
    return functionTable;
  }

  public NinfServerStruct getMetaServer(int num)
    throws ArrayIndexOutOfBoundsException {
    return (NinfServerStruct)(metaServerList.elementAt(num));
  }

  public NinfServerStruct getNinfServer(int num)
    throws ArrayIndexOutOfBoundsException {
    return (NinfServerStruct)(ninfServerList.elementAt(num));
  }

  synchronized int addNewFunction(String name, CallableStruct f) {
    return addNewFunction(new FunctionName(null, name), f);
  }

  synchronized int addNewFunction(FunctionName name, CallableStruct f) {
    CallableStruct l = (CallableStruct)(functionDic.get(name));
    if (l == null) {
      functionDic.put(name, f);
      functionTable.addElement(f);
      f.addManager(this);
      return functionTable.size() - 1;
    } else {
      return -1;
    }
  }


/*
  synchronized public NinfCallable getOneFunc(String name) {
    Vector tmpVec = (Vector) (functionDic.get(name));
    if (tmpVec == null)
      return null;

    int minLoad = 10000;
    NinfCallable minCallable = null;
    for (int i = 0; i < tmpVec.size(); i++){
      NinfCallable tmp = (NinfCallable)(tmpVec.elementAt(i));
      int tmpload = tmp.load();
      System.out.println("(" + tmp + ")'s load = " + tmpload + " minload = " +minLoad);
      if (tmpload <= 0){
	minCallable = tmp;
	break;
      }
      if (minLoad > tmpload){
	minLoad = tmpload;
	minCallable = tmp;
     }
   }
  System.out.println(minCallable + " is selected.");
    return minCallable;
  }

  public NinfCallable getOneFunc(String name, int count) {
    Vector tmp = (Vector) (functionDic.get(name));
    if (tmp == null)
      return null;
    if (tmp.size() <= count) count = 0;
    return (NinfCallable)(tmp.elementAt(count));
  }
*/  

  /** function name -> CallableStruct */
  public CallableStruct getFunction(String name) {
    System.out.println(functionDic + "," + name);
    FunctionName funcName = new FunctionName(null, name);

    Enumeration en =  functionDic.keys();
    while (en.hasMoreElements()){
      Object next = en.nextElement();
      System.out.println(funcName + "  and  " + next + " are equal? :" + funcName.equals(next));
    }
    return (CallableStruct)functionDic.get(funcName);
  }

  /** index no -> function name */
  public CallableStruct getFunction(int i)     
    throws ArrayIndexOutOfBoundsException {
    return (CallableStruct)functionTable.elementAt(i);
  }

  public Vector getServerList(String entry) {
    NinfFunctionStruct s = (NinfFunctionStruct)functionDic.get(new FunctionName(null, entry));
    if (s == null) return null;
    Vector ret = new Vector();
    int i;
    for (i = 0; i < s.servers.size(); i++) {
      ServerIndex si = (ServerIndex)(s.servers.elementAt(i));
      ret.addElement(si.server);
    }
    return ret;
  }

  int getFunctionIndex(CallableStruct c) {
    return functionTable.indexOf(c);
  }

  public String getFunctionName(int i){
    CallableStruct c = (CallableStruct)(functionTable.elementAt(i));
    Enumeration enum = functionDic.keys();
    while (enum.hasMoreElements()){
      Object key = enum.nextElement();
      if (functionDic.get(key) == c)
	return ((FunctionName)key).entry_name;
    }
    return null;
  }

  /** return indexlist which match string */
  int[] getStubIndexList(String str, int option){
    Vector tmpVec = new Vector();
    Enumeration enum = functionDic.keys();
    while (enum.hasMoreElements()){
      FunctionName each = (FunctionName)(enum.nextElement());
      if (each.match(str, option))
	tmpVec.addElement(new Integer(
	  getFunctionIndex((CallableStruct)(functionDic.get(each)))));
    }

    int ans[] = new int[tmpVec.size()];
    for (int i = 0; i < tmpVec.size(); i++)
      ans[i] = ((Integer)(tmpVec.elementAt(i))).intValue();
    return ans;
  }

  /** should be rewritten */
//  NinfCallable selectFunction(int index) throws Exception {
//    return (NinfCallable)functionTable(index);
    
//    String name = getFunctionName(index);
//    return getOneFunc(name);
//    Vector tmp = (Vector) (functionDic.get(name));
//    return (NinfCallable)tmp.elementAt(0);
//  }


/*  NinfFunction getNewFunction(String name) {
    NinfFunction tmp;
    for (int i = 0; i < ninfServerList.size(); i++) {
      try {
	tmp = new NinfFunction((NinfServerStruct)ninfServerList.elementAt(i),
			       name);
      } catch(NinfException e) {
	// update ninfServerList.
	continue;
      }
      if (tmp.stub != null)
	return tmp;
    }
    return null;
  }
*/

  public synchronized int addNewStub(NinfServerStruct srv, String name) {
    return addNewStub(srv, new FunctionName(null, name));
  }

  public synchronized int addNewStub(NinfServerStruct srv, FunctionName name) {
    try {
      NinfServerConnection con = srv.connect();
      return addNewStub(srv, con.getStub(name.entry_name), con.currentIndex);
    }  catch (NinfException e) {return -1;}

  }
  
  public synchronized int addNewStub(NinfServerStruct srv, NinfStub stub, 
				     int index){
    FunctionName name = stub.getName();
    NinfFunctionStruct func;
    int ans;
    if ((func = (NinfFunctionStruct)functionDic.get(name)) == null){
      try {
	func = functionStructFactory.make(srv, stub, index);
      } catch (NinfException e){
	System.out.println("cannot register: " + stub.entry_name);
	e.printStackTrace();
	return -1;
      }
      ans = addNewFunction(name, func);
    } else {
      ans = functionTable.indexOf(func);
    }
    func.addServer(srv, index);
    return ans;
  }


  /****************** SCHEDULING ********************/
  FunctionQue que = new FunctionQue(this);

  public FunctionQue getQue(){return que;}
  
  public ServerIndex getProperServer(NinfFunctionStruct func, 
						  int load) throws NinfException {
    ServerIndex tmp = func.getProperStruct();
    if (tmp != null)tmp.server.loadAdd(load);
    return tmp;
  }

  public ServerIndex getServerLock(NinfFunctionStruct func, 
						int load) throws NinfException {
    ServerIndex tmp = func.getServerLock();
    if (tmp != null)tmp.server.loadAdd(load);
    return tmp;
  }

  public void serverReleased(){
    System.out.println("FunctionManager:serverReleased");
    que.serverReleased();
  }

  public NinfServerConnection connect(NinfFunctionStruct func) throws NinfException {
    ServerIndex tmp;
    if ((tmp = func.getProperStruct())== null)
      return tmp.server.connect();
    throw new NinfIOException();
  }


}

// end of FunctionManager.java
