
package ninf.cproxy.aggregate;
import ninf.basic.*;
import ninf.client.*;

import java.io.IOException;
import java.util.Vector;

public class NinfConnectionThread extends NinfThread {
  int index;
  NativeCallable func;
  Stoppable con;
  CallContext context;
  NinfLog dbg = new NinfLog(this);
  int retryCount = 3;
  int serial;
  ServerIndex server;
  CompoundCallable comp;

  public NinfConnectionThread(int i, NativeCallable f, CallContext context, 
			      int serial, ServerIndex server, 
			      CompoundCallable comp){
    index = i;
    func = f;
    this.context = context;
    this.serial = serial;
    this.server = server;
    this.comp = comp;
  }
  public void runSub() {
    dbg.println("NinfConnectionThread No."+ index + " Starts");
    if (!succeeded){
      dbg.println("NinfConnectionThread No."+ index + " already failed");
      return;
    }
    try {
      NinfExecInfo info = func.callNative(context, serial, server);
      comp.addForeTime(info.fore_time);
      comp.addCompTime(info.exec_time);
      comp.addBackTime(info.back_time);
    } catch(NinfStoppedByUserException e) {
      dbg.println("NinfConnectionThread No."+ index + " stopped by user");
      succeeded = false;
    } catch(NinfException e) {
      dbg.println("NinfConnectionThread No."+ index + " failed");
      if (--retryCount >= 0)
	runSub();
      else
	succeeded = false;
    } finally {
      dbg.println("NinfConnectionThread No."+ index + " finished");
    }
  }
  public void kill(){
    dbg.println("NinfConnectionThread No."+ index + " killed. con = " + con);
    if (con != null) con.stop();
//    super.kill();
  }
}

// end of NinfConnectionThread.java
