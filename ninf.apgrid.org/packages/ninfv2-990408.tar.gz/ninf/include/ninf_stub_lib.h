#ifndef _NINF_STUB_LIB_H_
#define _NINF_STUB_LIB_H_

#include "ninf_stub_info.h"
#include "ninf_macros.h"
#include "ninf_error.h"

#ifdef  __cplusplus
extern "C" {
#endif
	int Ninf_stub_BEGIN();
	int Ninf_stub_INIT(int argc, char ** argv);
	int Ninf_stub_REQ();
	int Ninf_stub_SET_ARG(void *, int);
	int Ninf_stub_END();
	void Ninf_stub_EXIT();
#ifdef  __cplusplus
};
#endif

#endif
