package ninf.client;

import java.util.Vector;
import ninf.basic.*;

public interface CallbackFunc {
  public void callback(Vector args);
}

