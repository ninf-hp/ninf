#define _WRAPPER_
/* $Id: pdtrcon_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define DOUBLE
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n

static	int worklen(int n) {
	  int ret=1;
	  ret = 2*n + n + MAX( 2, MAX( n,  n + n ));
	  if NEED_BUFF {
	    ret = 2*LOCr(N+MOD(IA-1,MB_A))
	      + LOCc(N+MOD(JA-1,NB_A))
	      + MAX( 2, MAX( NB_A*MAX( 1, CEIL(NPROW-1,NPCOL) ),  LOCc(N+MOD(JA-1,NB_A)) +  NB_A*MAX( 1, CEIL(NPCOL-1,NPROW) ) ));
	  }
	  return ret;
}

static	int iworklen(int n) {
	  int ret=1;
	  ret = n;
	  if NEED_BUFF {
	    ret =  LOCr(N+MOD(IA-1,MB_A));
	  }
	  return ret;
}

void  pdtrcon_ninf(	 char norm,
		 char uplo,
		 char diag,
		 int n,
		 double global_a[],
		 int lda,
		 double *rcond,
		 double work[],
		 int iwork[],
		 int *info
)
/* "pdtrcon estimates the reciprocal of the condition number of a triangular distributed matrix A, in either the 1-norm or the infinity-norm." */
/* OPTIONS */
{
	int maxldd;

	int maxlda;
	double *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
	int row_loca, col_loca;

	double lrcond[1];

	double *locwork=NULL;
	int llocwork;
	int *lociwork=NULL;
	int llociwork;


	INITIALIZE();

	SCALAR( "char", norm);
	SCALAR( "char", uplo);
	SCALAR( "char", diag);
	SCALAR( "int", n);
	SCALAR( "int", lda);

	ROW( a);
	COL( a);
	MAXLDD( maxldd, a );
	maxlda = maxldd;

	trMATRIX( uplo, "double", a, ROW_a, COL_a);
	trDISTRIBUTE( uplo, "double", a, ROW_a, COL_a);

	llocwork=worklen(n);
	WORK(locwork,llocwork);
	llociwork=iworklen(n);
	IWORK(lociwork,llociwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pdtrcon)( &norm, &uplo, &diag,
                               &n,
                               loca, &one, &one, desca,
                               lrcond,
                               locwork, &llocwork,
                               lociwork, &llociwork,
                               &linfo);

	RETRIEVE("int", &linfo, 1);
	RETRIEVE("double", lrcond, 1);

	if( mypnum == 0 ){
	  *rcond=lrcond[0];
	  *info = linfo;
	} else {
		
	}

	FREE_MATRIX(a);
	FREE(locwork);
        FREE(lociwork);
}

