#ifndef _ARRAY_INFO_H_
#define _ARRAY_INFO_H_

#include "ninf_stub_info.h"

/* array shape information.
 * 	0 for element data, ndim for the entire array */
typedef struct array_shape_info 
{
    int elem_size;
    int start;
    int end;
    int step;
} array_shape_info;

/* array shape information for client API builder */

typedef struct size_info{
  enum data_type param_type;	/* argument type */
  enum mode_spec param_inout;	/* IN/OUT */
  int ndim;			/* number of dimension */
  array_shape_info shape[MAX_DIM];
} size_info;

#endif /* _ARRAY_INFO_H_ */

