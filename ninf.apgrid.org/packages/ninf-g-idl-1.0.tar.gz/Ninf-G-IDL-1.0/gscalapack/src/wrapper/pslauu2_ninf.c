#define _WRAPPER_
/* $Id: pslauu2_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define FLOAT
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n
void  pslauu2_ninf(	 char uplo,
		 int n,
		 float global_a[],
		 int lda,
		 int *info
	)
/* "pslauu2 computes the product U * U' or L' * L, where the triangular factor U or L is stored in the upper or lower triangular part of the matrix A." */
/* OPTIONS */
{
	int maxldd;

	int maxlda;
	float *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
	int row_loca, col_loca;

	INITIALIZE();

	SCALAR( "char", uplo);
	SCALAR( "int", n);
	SCALAR("int", lda);

	ROW( a);
	COL( a);
	MAXLDD( maxldd, a );
	maxlda = maxldd;

	MATRIX( "float", a, ROW_a, COL_a);
	DISTRIBUTE( "float", a, ROW_a, COL_a);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pslauu2)( &uplo, &n, loca, &one, &one, desca);

	GATHER( "float", a, ROW_a, COL_a);

	if( mypnum == 0 ){
	} else {
	}

	FREE_MATRIX(a);
}

