package ninf.netsolve;

import ninf.basic.XDROutputStream;
import java.io.IOException;

public class Constant{

  public String mnemonic;
  public int    value;

  public Constant(String mnemonic, int value){
    this.mnemonic = mnemonic;
    this.value = value;
  }

  public String toString(){
    return "Const:( " + mnemonic + " " + value + ")";
  }

  public void write(XDROutputStream os) throws IOException{
    os.writeString(mnemonic);
    os.writeInt(value);
  }
} // End class Constant

