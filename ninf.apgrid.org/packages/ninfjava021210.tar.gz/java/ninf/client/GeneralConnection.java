package ninf.client;
import ninf.basic.*;
import java.io.*;
import java.net.*;

class GeneralConnection{
  static NinfLog dbg = new NinfLog("GeneralConnection");

  ClientConfig config;
  Socket socket;
  Process proc;

  GeneralConnection(ClientConfig config){
    this.config = config;
  }

  static synchronized Socket getSocket(String host, int port) 
      throws IOException{
    return new Socket(host, port);
  }

  private void setupStream() throws IOException{
    String fmt = "%s %s %s %d";
    String commandline;
    Runtime runtime = Runtime.getRuntime();
    commandline = FormatString.format(fmt,
				      config.shell_command,
				      config.server,
				      config.proxy_command,
				      new Integer(config.port));
    dbg.println("invoking " + commandline);
    proc = runtime.exec(commandline);
  }

  private void setupCallback() throws IOException{
    String fmt = "%s %s %s %d %s %d";
    String commandline;
    
    ServerSocket callbackSocket = setCallbackSocket(config.callback_port,
						    config.callback_try);

    Runtime runtime = Runtime.getRuntime();
    commandline = 
      FormatString.format(fmt,
			  config.shell_command,
			  config.server,
			  config.proxy_command,
			  new Integer(config.port),
			  InetAddress.getLocalHost().getHostAddress(),  
			  new Integer(callbackSocket.getLocalPort()));
    dbg.println("invoking " + commandline);
    proc = runtime.exec(commandline);
    socket = callbackSocket.accept();
    dbg.println("accepted");
  }

  private ServerSocket setCallbackSocket(int port, int tryMax) 
  throws IOException{
    IOException e = null;
    if (port == 0)
      return new ServerSocket(port);
    for (int i = 0; i < tryMax; i++){
      try {
	return new ServerSocket(port);
      } catch (IOException e1){
	e = e1;
      }
    }
    throw e;
  }

  GeneralConnection connect() throws IOException {
    if (config.shell_mode == ClientConfig.NINF_SHELL_NO){
      socket = getSocket(config.server, config.port);
    } else if (config.shell_mode == ClientConfig.NINF_SHELL_STREAM){
      setupStream();   
    } else {
      setupCallback();
    }
    return this;
  }


  String peerName(boolean lookup){
      if (socket != null)
	  return Util.peerName(socket, lookup);
      else 
	  return config.server;
  }

  void close() throws IOException{
      if (socket != null)
	  socket.close();
      if (proc != null)
	  proc.destroy();
  }
  InputStream getInputStream() throws IOException{
      if (socket != null)
	  return socket.getInputStream();
      return proc.getInputStream();
  }
  OutputStream getOutputStream() throws IOException{
      if (socket != null)
	  return socket.getOutputStream();
      return proc.getOutputStream();
  }

}
