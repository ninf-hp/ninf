#include <stdio.h>
#include <math.h>

#include "ninf_stub.h"
#include "ninf_cim.h"
#include "cim_test_handler.h"
#define N 10

int verbose = FALSE;

int cim_test(){
  double A[N][N], B[N][N], C[N][N], C0[N][N];
  int i, j;

  for(i = 0; i < N; i++)
    for(j = 0; j < N; j++){
      A[i][j] = i + 0.1 * j;
      B[i][j] = 1 + i + 0.1 * j;
    }
  printf("cim_testing: ");
  {
    c_pointer_handler * args[4];
    int result;
    long n = N;
    int dim[2];
    dim[0] = N;
    dim[1] = N;

    args[0] = new_c_pointer_handler(&n, 0, NULL, DT_LONG);
    args[1] = new_c_pointer_handler(A, 2, dim, DT_DOUBLE);
    args[2] = new_c_pointer_handler(B, 2, dim, DT_DOUBLE);
    args[3] = new_c_pointer_handler(C, 2, dim, DT_DOUBLE);

    if (Ninf_cim_main("test/matmul", (void *)args) != NINF_OK){
      Ninf_perror("cim:");
    }
    mmul(N,A,B,C0);
    for(i = 0; i < N; i++)
      for(j = 0; j < N; j++){
	if(fabs((C[i][j] - C0[i][j])/C0[i][j]) > 1.0e-10){ 
	  if (verbose) printf("C[%d][%d]= %e != %e\n",
			      i,j,C[i][j],C0[i][j]);
	  return FALSE;
	}
      }
    return TRUE;
  }
}

/******************** Test Main *********************/

main(int argc, char ** argv){
  argc = Ninf_parse_arg(argc, argv);
  while (argc > 1){
    argv++;
    if (strcasecmp(*(argv), "-verbose") == 0)
      verbose = TRUE;
    if (strcasecmp(*(argv), "-debug") == 0)
      ninf_debug_flag = TRUE;
    argc--;
  }
  
  Ninf_set_cim_funcs(ninf_cim_init_c,
		ninf_cim_finalize_c, 
		ninf_cim_proceed_c,
		ninf_cim_get_c,
		ninf_cim_put_c,
		ninf_cim_destruct_c);

  if (cim_test())  {printf("\tOK\n");} else { printf("\tfailed\n");}

}

/* test routine */
mmul(n,A,B,C)
     double *A,*B,*C;
{
    double t;
    int i,j,k;

    for (i=0;i<n;i++) {
	for (j=0;j<n;j++) {
	    t = 0;
	    for (k=0;k<N;k++){
		t += A[i*n + k] * B[k*n+j];	/* inner product */
	    }
	    C[i*n+j] = t;
	}
    }
}

