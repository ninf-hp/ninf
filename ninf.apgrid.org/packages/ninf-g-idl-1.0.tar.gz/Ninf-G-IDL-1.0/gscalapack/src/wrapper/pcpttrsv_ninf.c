#define _WRAPPER_
/* $Id: pcpttrsv_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define _DISTRIBUTE_1D_
#define SCOMPLEX
#define _REAL_DIAGONAL_
#include <gscalapack.h>

#define ROW_b ldb
#define COL_b nrhs
static	int worklen( int nrhs) {
	  int ret=1;
	  ret =  (10+2*min(100,nrhs))+4*nrhs;
	  if (mypnum!=0) {
	    ret =  (10+2*min(100,nrhs))*npcol+4*nrhs;
	  }
	  return ret;
}


void  pcpttrsv_ninf(	 char uplo,
			 int n,
			 int nrhs,
			 float global_d[],
			 scomplex global_e[], //upper
			 scomplex global_b[],
			 int ldb,
			 int *info
)
/* "pcpttrsv solves a tridiagonal triangular system of linear equations A * X = B or A^H * X = B where A is a tridiagonal triangular matrix factor produced by the Cholesky factorization code PCPTTRF and is stored in A and AF." */
/* OPTIONS */
{
	extern void FortranCall(pcpttrsv)( char*, int*, int*,
                                float*, scomplex*, int*, int*,
                                scomplex*, int*, int*,
                                scomplex*, int*,
                                scomplex*, int*, int*);

	int maxldd;

	float *locd=NULL;
        scomplex *loce=NULL;
	int desctdd[DESCLEN];
	int desc_gtdd[DESCLEN];

	scomplex *locb=NULL;
	int descb[DESCLEN];
	int desc_gb[DESCLEN];
	int row_locb;
	int col_locb;
	int maxldb;

	scomplex *locwork=NULL;
	int llocwork;
	
	scomplex *locaf=NULL;
	int laf;
	
	INITIALIZE();

	SCALAR( "char", uplo);
	SCALAR( "int", n);
	SCALAR( "int", nrhs);
        SCALAR( "int", ldb);
	SIZE(n);

	ROW(b);
	COL(b);
	MAXLDD( maxldd, b );
	maxldb = maxldd;

	tdMATRIX( "scomplex", e, d, e, n); // d is float.
	tdDISTRIBUTE( "scomplex", e, d, e, n);

	MATRIX( "scomplex", b, ROW_b, COL_b);
	DISTRIBUTE( "scomplex" , b, ROW_b, COL_b);

	laf = blocsize+2;
        if (serial==1) laf = n+2;
	locaf = MALLOC(sizeof(float)*laf);
        assert(locaf);

	llocwork = worklen(nrhs);
	WORK(locwork, llocwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pcpttrsv)( &uplo, &n, &nrhs,
                                locd, loce, &one, desctdd,
                                locb, &one, descb,
                                locaf, &laf,
                                locwork, &llocwork, &linfo);

	tdGATHER( "scomplex", e, d, e, n);
	GATHER( "scomplex", b, ROW_b, COL_b);

	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
		*info = linfo;
	} else {
	}
        
	FREE_MATRIX(d);
	FREE_MATRIX(e);
	FREE_MATRIX(b);
	FREE(locaf);
        FREE(locwork);
}

