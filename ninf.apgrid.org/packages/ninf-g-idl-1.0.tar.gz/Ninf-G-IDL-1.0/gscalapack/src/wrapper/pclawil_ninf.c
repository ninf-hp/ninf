#define _WRAPPER_
/* $Id: pclawil_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define SCOMPLEX
#include <gscalapack.h>

#define ROW_a lda
#define COL_a m
void  pclawil_ninf(	 int ii,
		 int jj,
		 int m,
		 scomplex a[],
		 int lda,
		 float h44,
		 float h33,
		 float h43h34,
		 scomplex global_v[]
)
/* " pclawil gets the transform given by H44,H33, & H43H34 into V starting at row M." */
/* OPTIONS */
{
	int maxldd;

	int desca[DESCLEN];

	scomplex locv[3];

	INITIALIZE();

	SCALAR( "int", ii);
	SCALAR( "int", jj);
	SCALAR( "int", m);
	SCALAR("int",lda);
	SCALAR( "float", h44);
	SCALAR( "float", h33);
	SCALAR( "float", h43h34);
	SCALAR( "int", lda);

	COMMON_MATRIX( "scomplex", a, ROW_a, COL_a);
	Cdescinit( desca, ROW_a, COL_a, ROW_a, COL_a, 0, 0, PARA_CTXT, ROW_a, &linfo);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pclawil)( &ii, &jj, &m,
			       a, desca,
			       &h44, &h33, &h43h34,
			       locv);

	RETRIEVE("scomplex", locv, 3);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
	  int i;
	  for(i=0;i<3;i++) global_v[i]=locv[i];
	} else {
	}

	FREE_COMMON(a);
}

