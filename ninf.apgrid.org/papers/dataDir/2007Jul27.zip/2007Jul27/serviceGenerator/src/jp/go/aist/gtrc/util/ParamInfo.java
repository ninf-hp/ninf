package jp.go.aist.gtrc.util;

class ParamInfo {
	String name;
	TypeInfo type;

	ParamInfo(String name, TypeInfo type) {
		this.name = name;
		this.type = type;
	}
}
