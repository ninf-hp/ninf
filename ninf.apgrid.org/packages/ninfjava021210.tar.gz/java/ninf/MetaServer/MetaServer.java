//
//  MetaServer.java - Ninf Meta Server
//

package ninf.MetaServer;
import ninf.basic.*;
import ninf.client.*;
import ninf.netsolve.*;

import java.util.Vector;
import java.util.Hashtable;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.io.*;
import java.io.IOException;

//  PrintStream clientOutput;
//  InputStream clientInput;

class Requester {
  NinfServerStruct server;
  int reqitem;
  Requester(NinfServerStruct s, int r) {
    server = s;
    reqitem = r;
  }
  public boolean equals(Object obj) {
    if (obj.getClass() != this.getClass()) return false;
    NinfServerStruct s = ((Requester)obj).server;
    if (!s.host.equalsIgnoreCase(server.host)) return false;
    return (s.port == server.port);
  }
}

/**
  Ninf MetaServer class.
  Receive request from NinfClient, and lookup NinfServer.
*/
public class MetaServer extends NServer {

  public static FunctionManager funcManager = new FunctionManager();
  static RequestRecorder requestRecorder = new RequestRecorder();
  //static Vector stubTable;
  static Vector dumpRequesters = null;
  public static String myname = null;
  static int myport = 0;

  static final int CONSULT_NUM_DEFAULT = 10;
  static final int CONSULT_RETRY_COUNT = 10;
  static final int CONSULT_RETRY_INTERVAL = 1000; /* msec */

  public NinfLog dbg = new NinfLog(this);

  Stoppable stop;

  void notifyChanges() {
    if (dumpRequesters == null) return;
    for (int i = 0; i < dumpRequesters.size(); i++) {
      Requester req = (Requester)(dumpRequesters.elementAt(i));
      NinfServerConnection con;
      try {
	System.err.println("notify change to " + req.server);
	con = new NinfServerConnection(req.server, 1);
	sendMsInfo(con.os, req.reqitem, 0);
      } catch(NinfException e) {
	System.err.println("Can't connect requester:" + e);
      }
    }
  }

  void addNinfServer(String name, int port, int performance) {
    addNinfServer(new NinfServerStruct(name, port, performance));
  }

  void addNinfServer(NinfServerStruct s){
    funcManager.addNinfServer(s);
    notifyChanges();
  }

  void addMetaServer(String name, int port) {
    funcManager.addMetaServer(name, port);
  }
  
  String getPeerName() {
    return clientSocket.getInetAddress().getHostName();
  }

  int getRemotePort() {
    return clientSocket.getPort();
  }

  String generateUniqId() {
    String ret = String.valueOf(System.currentTimeMillis()) + "@" + myname;
    return ret;
  }

  static boolean alreadyConsulted(String uniqid) {
    return requestRecorder.isRecorded(uniqid);
  }

  static synchronized void recordRequest(String uniqid) {
    requestRecorder.addRequestRecord(uniqid);
  }

  static synchronized void recordDumpRequester(NinfServerStruct srv,
					       int reqitem) {
    if (dumpRequesters == null) dumpRequesters = new Vector();
    Requester req = new Requester(srv, reqitem);
    boolean toadd = true;
    for (int i = 0; i < dumpRequesters.size(); i++) {
      if (req.equals(dumpRequesters.elementAt(i))) toadd = false;
    }
    if (toadd) dumpRequesters.addElement(req);
  }

  public void sendBackStub(int i, XDROutputStream os) throws NinfException {
    CallableStruct tfunc = funcManager.getFunction(i);
    if (tfunc == null) {
      dbg.println("sendBackStub: can't get Stub, index = " + i);
      throw new NinfStubFindException();
    }
    dbg.println("send back stub No."+i);
    NinfPacketOutputStream nos = 
      new NinfPacketOutputStream(os, NinfPktHeader.NINF_PKT_RPY_STUB_INFO, i, 0);
    nos.write(tfunc.getStub().toByteArray());
    nos.flush();
//    NinfPacket.getRpyStubPacket(tfunc.getStub().toByteArray(), i).write(os);
  }

  public int getCompound(NinfPacket p, XDRInputStream is) throws NinfException {
    NinfCompound func = new NinfCompound(p, is, funcManager);
    if (func == null) return -1;
    return funcManager.addNewFunction("__compound_stub_" +
				      funcManager.getNinfFunctionNum(), func);
  }

  public int getStub(String str) throws NinfException {
    CallableStruct callable = funcManager.getFunction(str);
    if (callable == null) return -1;
    return funcManager.getFunctionIndex(callable);
  } 

  void processKill(NinfPacket pkt) throws NinfException {
    System.out.println("packet: NINF_PKT_KILL");
    dbg.println("kill");
  }

  void processReqCall(NinfPacket pkt, XDRInputStream is, XDROutputStream os)  
  throws NinfException {
    System.out.println("packet: NINF_PKT_REQ_CALL");
    dbg.println("processReqCall()");
    CallableStruct tmpFunction = funcManager.getFunction(pkt.hdr.arg1);
    dbg.println("tmpFunction = " + tmpFunction);
    if (tmpFunction != null){
      stop = tmpFunction.getCallable().call(pkt, is, os);
    } else {
      NinfPacketOutputStream pos =
	new NinfPacketOutputStream(os, NinfPktHeader.NINF_PKT_ERROR, 0, 0);
      pos.flush();
    }
    dbg.println("tmpFunction = " + tmpFunction);
  }

  /** process NINF_PKT_REQ_COMPOUND packet */
  void processReqCompound(NinfPacket pkt,
			  XDRInputStream is, XDROutputStream os) {
    System.out.println("packet: NINF_PKT_REQ_COMPOUND");
    dbg.println("reqest compound");
    try {
      int index = getCompound(pkt, is);
      dbg.println("processReqCompund:got compound stub");
      if (index < 0) {
	dbg.println("processReqCompound: can't get stub"+pkt.readString());
	return;
      }
      sendBackStub(index, os);
      return;
    } catch (Exception e) {
      dbg.println("processReqCompound: " + e);
      e.printStackTrace();
      return;
    }
  }

  int consultOtherMS(String entry) {
    System.err.println("** I don't know about " + entry + ", so consult other MS **");
    String uniqid = generateUniqId();
    recordRequest(uniqid);
    delegateConsultStub(entry, uniqid, CONSULT_NUM_DEFAULT,
			myname, myport, null, 0);
    int index = -1;
    int retrycount = 0;
    while (retrycount++ < CONSULT_RETRY_COUNT) {
      CallableStruct tmp = funcManager.getFunction(entry);
      if (tmp != null){
	index = funcManager.getFunctionIndex(tmp);
	if (index >= 0) {
	  dbg.println("");
	  return index;
	}
      }
      try {
	Thread.currentThread().sleep(CONSULT_RETRY_INTERVAL);
      } catch(InterruptedException e) {
	return -1;
      }
    }
    return -1;
  }

  void processReqStubInfo(NinfPacket pkt, XDROutputStream os) {
    try {
      String entry = pkt.readString();
      //dbg.println("NINF_PKT_REQ_STUB_INFO : entry=" + entry);
      int index = getStub(entry);
      if (index < 0) {
	index = consultOtherMS(entry);
      }
      if (index < 0) {
	dbg.println("processReqStubInfo: can't get stub"+pkt.readString());
	NinfPacket.getErrorPacket(NinfError.CANTFINDSTUB).write(os);
	return;
      }
      System.err.println("NINF_PKT_REQ_STUB_INFO : entry(" + entry +
		  ") -> index=" + index);
      sendBackStub(index, os);
      return;
    } catch (Exception e) {
      dbg.println("processReqStubInfo: " + e);
      e.printStackTrace();
      return;
    }
  }

  /** process NINF_PKT_REQ_STUB_INDEX_LIST
   returns the list of matched stub index */
  void processReqStubIndexList(NinfPacket pkt,
			 XDRInputStream is, XDROutputStream os) 
  throws NinfException {
    System.err.println("packet: NINF_PKT_REQ_STUB_INDEX_LIST");
    int option = pkt.hdr.arg1;
    NinfPacketInputStream pis = new NinfPacketInputStream(pkt, is);
      System.err.println("reading string");
  String str = pis.readString();
      System.err.println("readed: " + str);
    int indexes[] = funcManager.getStubIndexList(str, option);
    NinfPacketOutputStream pos =
      new NinfPacketOutputStream(os, NinfPktHeader.NINF_PKT_RPY_STUB_INDEX_LIST,
				 indexes.length, 0);
    for (int i = 0; i < indexes.length; i++){
      System.err.println("writing index["+i+"] = " + indexes[i]);
      pos.writeInt(indexes[i]);
    }
    pos.flush();
  }

  /** process NINF_PKT_REQ_STUB_BY_INDEX
   returns stubinfo of index in arg1*/
  void processReqStubByIndex(NinfPacket pkt,
			 XDRInputStream is, XDROutputStream os) 
  throws NinfException {
    System.err.println("packet: NINF_PKT_REQ_STUB_BY_INDEX");
    int index = pkt.hdr.arg1;
    try {
      sendBackStub(index, os);
    } catch (NinfStubFindException e){
      NinfPacketOutputStream pos =
	new NinfPacketOutputStream(os, NinfPktHeader.NINF_PKT_ERROR, 0, 0);
      pos.flush();
    }
  }

  /** process NINF_DUMP_MS_INFO packet */
  void processDumpMsInfo(NinfPacket pkt,
			 XDRInputStream is, XDROutputStream os) {
    System.err.println("packet: NINF_DUMP_MS_INFO");
    int reqitem = pkt.hdr.arg1;
    int reqmethod = pkt.hdr.arg2;
    if (reqitem == 0) reqitem = 15;
    if (reqmethod == 1) { // notify the MetaServer when state change
      NinfPacketInputStream pis =  new NinfPacketInputStream(pkt, is);
      String h=null; int p=0;
      try {
	h = pis.readString();
	p = pis.readInt();
      } catch(NinfException e) {
	// error;
	return;
      }
      if (h == null || p == 0) {
	// error;
	return;
      }
      NinfServerStruct srv = new NinfServerStruct(h, p);
      System.err.println("requester = " + srv);
      recordDumpRequester(srv, reqitem);
    }
    try {
      sendMsInfo(os, reqitem, 0);
    } catch(NinfException e) {
    }
  }

  void sendMsInfo(XDROutputStream os, int reqitem, int method)
  throws NinfException {
    NinfPacketOutputStream pos =
      new NinfPacketOutputStream(os, NinfPktHeader.NINF_RPY_MS_INFO,
				 reqitem,
				 method);
    int num;
    int i;
    String n;
    
    // list of MetaServer(s)
    if ((reqitem & 1) != 0) {
      num = funcManager.getMetaServerNum();
      pos.writeInt(num);
      for (i = 0; i < num; i++) {
	NinfServerStruct srv = funcManager.getMetaServer(i);
	srv.writeTo(pos);
      }
    }
    
    // list of NinfServer(s)
    if ((reqitem & 2) != 0) {
      num = funcManager.getNinfServerNum();
      pos.writeInt(num);
      for (i = 0; i < num; i++) {
	NinfServerStruct srv = funcManager.getNinfServer(i);
	srv.writeTo(pos);
      }
    }
    
    if ((reqitem & 4) != 0) {
      num = funcManager.getNinfFunctionNum();
      pos.writeInt(num);
      for (i = 0; i < num; i++) {
	n = funcManager.getFunctionName(i);
	pos.writeString(n);
      }
    }
    
    if ((reqitem & 8) != 0) {
      num = (dumpRequesters != null) ? dumpRequesters.size() : 0;
      pos.writeInt(num);
      for (i = 0; i < num; i++) {
	Requester req =
	  (Requester)(dumpRequesters.elementAt(i));
	NinfServerStruct srv = req.server;
	srv.writeTo(pos);
      }
    }
    
    pos.flush();
    pos.close();
  }
  
  /** process NINF_PKT_NEW_SERVER packet */
  void processNewServer(NinfPacket pkt, XDRInputStream is) {
    System.err.println("packet: NINF_PKT_NEW_SERVER");
    try {
      NinfPacketInputStream pis = new NinfPacketInputStream(pkt, is);
      String srv = pis.readString();
      int port = pkt.hdr.arg1;
      int performance = pis.readInt();
      String peer = getPeerName();
      dbg.println("New NinfServer : host=" + srv + "(" + peer + ") port="
		  + port + " performance=" + performance);
      /* TODO: collect server<->metaserver RTT info. */
      addNinfServer(srv, port, performance);
    } catch(NinfException e) {
      dbg.println("processNewServer: connect: exception: " + e);
    }
  }

  /** process NINF_PKT_NEW_STUB packet */
  void processNewStub(NinfPacket pkt, XDRInputStream is) {
    System.err.println("packet: NINF_PKT_NEW_STUB");
    try {
      NinfPacketInputStream pis = new NinfPacketInputStream(pkt, is);
      String entry = pis.readString();
      NinfServerStruct srv = new NinfServerStruct(pis);
      dbg.println("---NINF_PKT_NEW_STUB : entry=" + entry +
		  " port=" + srv.port);
      int idx = funcManager.addNewStub(srv, entry);
      dbg.println("---NINF_PKT_NEW_STUB : stub index on MetaServer = " + idx);
    } catch(NinfException e) {
      dbg.println("processNewStub: connect: exception: " + e);
    }
  }

  /** process NINF_PKT_NEW_MS packet */
  void processNewMS(NinfPacket pkt, XDRInputStream is, XDROutputStream os) {
    System.err.println("packet: NINF_PKT_NEW_MS");
    try {
      NinfPacketInputStream pis = new NinfPacketInputStream(pkt, is);
      NinfServerStruct srv = new NinfServerStruct(pis);
      dbg.println("processNewMS: host = " + srv.host + " port = " + srv.port);
      addMetaServer(srv.host, srv.port);
    } catch(NinfException e) {
      dbg.println("processNewMS: connect: exception: " + e);
    }
  }

  /** process NINF_PKT_RTT1 packet */
  void processNinfPktRtt1(NinfPacket pkt, XDROutputStream os) {
    NinfPacket rpy = new NinfPacket(NinfPktHeader.NINF_PKT_RTT_2,0,0,0);
    try {
      rpy.write(os);
    } catch(NinfIOException e) {}
  }
  
  /** Send NINF_PKT_NEW_STUB packets to host:port */
  void sendServerListToInitiator(String entry, Vector slist,
				 String host, int port) {
    int i;
    for (i = 0; i < slist.size(); i++) {
      NinfServerStruct srv = (NinfServerStruct)(slist.elementAt(i));
      NinfServerStruct initiator = new NinfServerStruct(host, port);
      NinfServerConnection con;
      try {
	con = new NinfServerConnection(initiator);
      } catch(NinfException e) {
	// can't connect initiator
	System.err.println("!!! I can't connect to initiator.");
	continue;
      }
      NinfPacketOutputStream pos;
      pos = new NinfPacketOutputStream(con.os,
				       NinfPktHeader.NINF_PKT_NEW_STUB);
      try {
	pos.writeString(entry);
	srv.writeTo(pos);
	pos.flush();
	pos.close();
      } catch(NinfException e) {
	System.err.println("!!! I can't send stub to initiator");
      }
    }
  }

  void delegateConsultStub(String entry, String uniqid, int count,
			   String ininame, int iniport,
			   String reqname, int reqport) {
    int max = funcManager.getMetaServerNum();
    NinfPacketOutputStream pos;
    int i;
    for (i = 0; i < max; i++) {
      NinfServerStruct srv = funcManager.getMetaServer(i);
      if (reqname != null) {
	if (srv.host.equalsIgnoreCase(reqname) && srv.port == reqport) {
	  continue;
	}
      }
      NinfServerConnection con;
      try {
	con = new NinfServerConnection(srv);
      } catch(NinfException e) {
	// can't connect srv.
	// must change functiontable here.
	continue;
      }
      System.err.println(" consult \"" + entry + "\" to " + srv);
      pos = new NinfPacketOutputStream(con.os,
				       NinfPktHeader.NINF_PKT_CONSULT_STUB);
      try {
	pos.writeString(entry);
	pos.writeString(uniqid);
	pos.writeInt(count);
	pos.writeString(ininame);
	pos.writeInt(iniport);
	pos.flush();
	pos.close();
      } catch(NinfIOException e) {
	dbg.println("delegateConsultStub(" + srv.host + ":" + srv.port + 
		    "): " + e);
      }
    }
  }

  void processConsultStub(NinfPacket pkt, XDRInputStream is) {
    NinfPacketInputStream pis = new NinfPacketInputStream(pkt, is);
    String entry=null, uniqid=null, ininame=null;
    int count=0, iniport=0;
    try {
      entry   = pis.readString();
      uniqid  = pis.readString();
      count   = pis.readInt();
      ininame = pis.readString();
      iniport = pis.readInt();
    } catch(NinfException e) {
      dbg.println("processConsultStub: read packet " + e);
      return;
    }
    if (entry == null || uniqid == null || count <= 0 || ininame == null
	|| iniport <= 0) {
      return;
    }
    System.err.println("** Now, I'm consulted about " + entry);
    if (alreadyConsulted(uniqid)) {
      System.err.println("** I've already consulted about this request from another MS. ignore.");
      return;
    }
    recordRequest(uniqid);
    Vector slist = funcManager.getServerList(entry);
    if (slist != null) {
      System.err.println("** ok, I know about " + entry + ", so reply to "
			 + ininame + ":" + iniport);
      sendServerListToInitiator(entry, slist, ininame, iniport);
    } else if (--count > 0) {
      System.err.println("** I don't know about " + entry + ", so consult other MS **");
      delegateConsultStub(entry, uniqid, count,
			  ininame, iniport,
			  getPeerName(), getRemotePort());
    }
  }

  /** dispatch jobs according to packet code */
  public boolean dispatchNinfRequest(XDRInputStream is, XDROutputStream os) {
    boolean ret = true;
    NinfPacket pkt = null;
    try {
      pkt = new NinfPacket(is);
    } catch (NinfIOException e) {
      //      dbg.println("dispatchNinfRequst: " + e);
      //e.printStackTrace(dbg.os);
      if (stop != null) {stop.stop(); stop = null;}
      return false;
    }
    try {
      dbg.println("MetaServer Read Pkt" + pkt.hdr);
      switch (pkt.hdr.code) {
      case NinfPktHeader.NINF_PKT_REQ_STUB_INFO:
	processReqStubInfo(pkt, os);
	break;
      case NinfPktHeader.NINF_PKT_REQ_COMP:
	processReqCompound(pkt, is, os);
	break;
      case NinfPktHeader.NINF_PKT_REQ_CALL:
	processReqCall(pkt, is, os);
	break;
      case NinfPktHeader.NINF_PKT_KILL:
	processKill(pkt);
	break;
      case NinfPktHeader.NINF_PKT_NEW_SERVER:
	processNewServer(pkt, is);
	break;
      case NinfPktHeader.NINF_PKT_NEW_STUB:
	processNewStub(pkt, is);
	break;
      case NinfPktHeader.NINF_PKT_NEW_MS:
	processNewMS(pkt, is, os);
	break;
      case NinfPktHeader.NINF_DUMP_MS_INFO:
	processDumpMsInfo(pkt, is, os);
	break;

      case NinfPktHeader.NINF_PKT_REQ_STUB_INDEX_LIST:
	processReqStubIndexList(pkt, is, os);
	break;
      case NinfPktHeader.NINF_PKT_REQ_STUB_BY_INDEX:
	processReqStubByIndex(pkt, is, os);
	break;

      case NinfPktHeader.NINF_PKT_RTT_1:
	processNinfPktRtt1(pkt, os);
	break;
      case NinfPktHeader.NINF_PKT_RTT_2:
	break;
      case NinfPktHeader.NINF_PKT_CONSULT_STUB:
	processConsultStub(pkt, is);
	break;
      default:
	dbg.println("Unknown Coded Packet " + pkt.hdr.code);
	ret = false;
	break;
      }
    } catch (NinfException e) {
      dbg.println("exception occured in execution " + pkt.hdr.code);
      e.printStackTrace(dbg.os);
      NinfPacketOutputStream pos =
	new NinfPacketOutputStream(os, NinfPktHeader.NINF_PKT_ERROR, 0, 0);
      try {pos.flush();} catch(Exception ie){
	dbg.println("Can't return error pkt");
      }
      ret = false;
    }
    return ret;
  }

  /** process one clinet-connection */
  public void serviceRequest() {
    XDRInputStream is = new XDRInputStream(clientInput);
    XDROutputStream os = new XDROutputStream(clientOutput);
    
    while (dispatchNinfRequest(is, os))
      ;
  }

  void introduceMyselfToOtherMS() {
    int max = funcManager.getMetaServerNum();
    int i;
    try {
      for (i = 0; i < max; i++) {
	NinfServerStruct srv = funcManager.getMetaServer(i);
	
	NinfServerConnection con = new NinfServerConnection(srv);
	NinfPacketOutputStream pos = 
	  new NinfPacketOutputStream(con.os, NinfPktHeader.NINF_PKT_NEW_MS);
	pos.writeString(myname);
	pos.writeInt(srv.port);
	pos.flush();
	pos.close();
      }
    } catch(Exception e) {
      e.printStackTrace();
    }
  }

  public void setEnvironment(MetaServerConfig cnf) {
    if (cnf.host != null && cnf.port != 0) {
      addMetaServer(cnf.host, cnf.port);
    }
    if (cnf.logfile != null) {
      try {
	NinfLog.changeOutput(cnf.logfile);
      } catch(NinfIOException e) {
	System.err.println("Can't open logfile : " + cnf.logfile);
      }
    } else {
//      NinfLog.quiet();
    }
    try {
      for (int i = 0; i < cnf.servers.size(); i++)
	registerServer((String)cnf.servers.elementAt(i));
      //      registerNetSolve(cnf.netsolve);
    } catch (NinfException e){e.printStackTrace();}
  }

  public void registerServer(String server) throws NinfException {
    NinfServerStruct srv = new NinfServerStruct(server);
    NinfServerConnection con = new NinfServerConnection(srv);
    con.connectServer(2);
    int indexes[] = con.getIndexes("");
    NinfStub stubs[] = con.query(indexes);
    con.close();

    addNinfServer(srv);
    for (int i = 0; i < stubs.length; i++)
      funcManager.addNewStub(srv, stubs[i], indexes[i]);

  }

  /*
  void registerNetSolve(String server) throws NinfIOException {
    try {
      if (server == null)
	return;
      GetProblems getter = new GetProblems(server);
      Problem problems[] = getter.getAllProblems();
      //      Problem problems[] = new Problem[1];
      //      problems[0] = getter.getOneProblem("dgesv");
      //      problems[1] = getter.getOneProblem("dgtsv");
      //      problems[2] = getter.getOneProblem("dmatmul");

      for (int i = 0; i < problems.length; i++){
	System.out.println("try to register "+ problems[i].name);
	ProblemStruct pStruct = new ProblemStruct(server, problems[i]);
	if (pStruct.getStub() != null){
	  funcManager.addNewFunction(new FunctionName("NetSolve", problems[i].name),
				     pStruct);
	  System.out.println(problems[i].name + " is registered");
	}
      }
    } catch (NetSolveException e){
      e.printStackTrace();
      throw new NinfIOException();
    }
  } 
  */

//************************************************
  static int DefaultPort = -1;
  public static String[] parseArg(String arg[]){
    Vector tmpV = new Vector();
    int index = 0;
    for (int i = 0; i < arg.length; i++){
      if (arg[i].equalsIgnoreCase("-port"))
	DefaultPort = Integer.valueOf(arg[++i]).intValue();
      else 
	tmpV.addElement(arg[i]);
    }
    String tmp[] = new String[tmpV.size()];
    for (int i = 0; i < tmpV.size(); i++)
      tmp[i] = (String)(tmpV.elementAt(i));
    return tmp;
  }

  static public void main(String argv[]) {
    MetaServer instance = new MetaServer();
//    instance.dbg.quiet();

    // set myname
    try {
      InetAddress localaddr = InetAddress.getLocalHost();
      myname = localaddr.getHostName();
    } catch(UnknownHostException e) {
      instance.dbg.println("getLocalHost(): " + e);
      System.exit(1);
    }

    // set myport
    myport = 3001;

    argv = parseArg(argv);
    if (DefaultPort > 0)
      myport = DefaultPort;
    if (argv.length == 2) {
      instance.addNinfServer(argv[0], Integer.parseInt(argv[1]), 0);
    } else if (argv.length == 1) {
      try {
	MetaServerConfig conf = new MetaServerConfig(argv[0]);
	instance.setEnvironment(conf);
	instance.introduceMyselfToOtherMS();
	if (DefaultPort < 0)
	  myport = conf.myport;
      } catch(NinfException e) {
	e.printStackTrace();
	instance.dbg.println("exit");
      }
    }
    instance.startServer(myport);
  }
}

// end of MetaServer.java
