package ninf.cproxy.aggregate;
import ninf.cproxy.*;
import ninf.basic.*;
import ninf.common.*;
import ninf.client.*;
import java.io.*;

/* 
  data SIZE
  dataFrom FUNCNUM
  dataTo   NUM FUNCNUM FUNCNUM ...
  */

public class DataNode {
  public long size;
  public int from;
  public int[] to;
  public int no;

  static int serial = 0;

  public FuncNode   upperFunc;
  public FuncNode[] lowerFuncs;
  
  public ServerID   location = null;

  static CommandParser dataParser = 
    new CommandParser(new CommandRepresent("data",     1));
  static CommandParser dataFrom = 
    new CommandParser(new CommandRepresent("dataFrom", 1));
  static CommandParser dataTo = 
    new CommandParser(new CommandRepresent("dataTo",  -1));
  

  public DataNode(DataInputStream is) throws NinfException{
    NinfCommand com;
    com = dataParser.readCommand(is);
    size = new Long(com.args[0]).longValue();
    com = dataFrom.readCommand(is);
    from = new Integer(com.args[0]).intValue();
    com = dataTo.readCommand(is);
    int len = new Integer(com.args[0]).intValue();
    to = new int[len];
    for (int i = 0; i < len; i++)
      to[i] = new Integer(com.args[i+1]).intValue();
    no = serial++;
  }

  public DataNode(long size, MergedInfo depend){
    this.size = size;
    if (depend.inputArgs.size() != 0)
      this.from = depend.getInputArg(0).functionIndex;
    else
      this.from = -1;
    this.to = new int[depend.outputArgs.size()];
    for (int i = 0; i < this.to.length; i++)
      this.to[i] = depend.getOutputArg(i).functionIndex;
    no = serial++;
  }

  public void send(PrintStream ps) throws NinfException {
    ps.println("data " + size);
    ps.println("dataFrom " + from);
    int outputSize = to.length;
    ps.print("dataTo " + outputSize);
    for (int i = 0; i < outputSize; i++)
      ps.print(" " + to[i]);
    ps.println("");
  }

  public boolean noFrom(){
    return from < 0;
  }
  public boolean noTo(){
    return (to == null) || (to.length == 0);
  }
  
  public String toString(){
    return "Data."+no+"("+ size +")";
  }

  /************* make data links ************/
  
  public void makeLink(FuncNode funcNodes[], FuncNode source, FuncNode sink){
    if (noFrom())
      upperFunc = source;
    else 
      upperFunc = funcNodes[from];
    upperFunc.registerLower(this);

    if (noTo()){
      lowerFuncs = new FuncNode[1];
      lowerFuncs[0] = sink;
      lowerFuncs[0].registerUpper(this);
    } else {
      lowerFuncs = new FuncNode[to.length];
      for (int i = 0; i < to.length; i++){
	lowerFuncs[i] = funcNodes[to[i]];
	lowerFuncs[i].registerUpper(this);
      }
    }
  }

}
