package bricks.scheduling;
import bricks.util.*;
import bricks.environment.*;
import java.util.*;

public class OwnerComputesScheduler extends DataGridScheduler implements SchedulingUnit {

    public OwnerComputesScheduler(
	String keyOfMetaPredictor, String keyOfReplicaManager,
	String keyOfServerMonitor
    ) {
	this.keyOfMetaPredictor = keyOfMetaPredictor;
	this.keyOfReplicaManager = keyOfReplicaManager;
	this.keyOfServerMonitor = keyOfServerMonitor;
	schedulingOverhead = 0.0;
    }

    // for OwnerComputesReplicationScheduler
    public OwnerComputesScheduler(
	String keyOfMetaPredictor, String keyOfReplicaManager, 
	String keyOfServerMonitor, double maxLoad
    ) {
	this.keyOfMetaPredictor = keyOfMetaPredictor;
	this.keyOfReplicaManager = keyOfReplicaManager;
	this.keyOfServerMonitor = keyOfServerMonitor;
	schedulingOverhead = 0.0;
    }

/************************* needed method *************************/
    public String getName() {
	return "OwnerComputesScheduler";
    }

    public void selectHosts(
	double currentTime, Host source, RequestedData data
    ) throws BricksNotScheduledException {

	boolean doneGC = false;
	Host selectedHost = null;
	while (selectedHost == null){
	    Enumeration e = resourceDB.dataSourceHosts(data);
	    if (e == null) {  // no dataSource hosts
		throw new BricksNotScheduledException(
		    this.toString() + ": no dataSource hosts"
		);
	    }
	    selectedHost = select(currentTime, data, e);

	    /* copy version only
	    // REPLICATION!!
	    if (selectedHost == null) {
	    e = resourceDB.notDataSourceHosts(data);
	    selectedHost = select(currentTime, data, e);
	    data.moveAtSend = false;  // copy the dataFragment
	    }
	    */

	    if (selectedHost != null) {
		updateStatus(
		    currentTime, selectedHost, selectedHost, 
		    data.dataDestination, data
	        );
		//System.out.println(
		SimulationDebug.println(
		    "OwnerComputesScheduler : select " + selectedHost
		);

	    } else {
		//if (data.numSchedule() == 0)
		//throw new BricksNotScheduledException(this.toString());

		if (doneGC) {
		    BricksUtil.abort(
			"The specified environment does not have " +
			"enough disk space at " + currentTime + "."
		    );
		} else {
		    replicaManager.garbageCollection(
			currentTime, data.dataFragment
		    );
		    doneGC = true;
		}
	    }
	}
	SimulationDebug.println(
	    "OwnerComputesScheduler: select " + selectedHost + 
	    " for " + data + " at " + currentTime
	);
    }

    protected Host select(
	double currentTime, RequestedData data, Enumeration e
    ) {
	Host selectedHost = null;
	double minElapsedTime = Double.POSITIVE_INFINITY;
	while (e.hasMoreElements()) {
	    Host h = (Host)e.nextElement();
	    if (data.scheduled(h))  //for fallback
		continue;
	    if (!hasAvailableDisk(currentTime, data, h))
		continue;
	    HostInfo info = getHostInfo(currentTime, h);
	    if (info.availableDiskSize < data.dataSizeForReceive)
		continue;

	    double elapsedTime = Double.POSITIVE_INFINITY;
	    elapsedTime = getEstimate(
		currentTime, h, h, data.dataDestination, data
	    );
	    if (minElapsedTime > elapsedTime) {
		minElapsedTime = elapsedTime;
		selectedHost = h;
	    }
	}
	return selectedHost;
    }
}

