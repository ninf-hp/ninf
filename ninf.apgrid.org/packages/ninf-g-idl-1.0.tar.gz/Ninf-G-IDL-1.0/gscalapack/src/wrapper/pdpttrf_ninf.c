#define _WRAPPER_
/* $Id: pdpttrf_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define _DISTRIBUTE_1D_
#define DOUBLE
#include <gscalapack.h>

static	int worklen() {
	  int ret=1;
	  ret = 8;
	  if NEED_BUFF {
	    ret = 8*npcol;
	  }
	  return ret;
}

void  pdpttrf_ninf(	 int n,
		 double global_d[],
		 double global_e[],
		 int *info
)
/* "pdpttrf computes a Cholesky factorization of an N-by-N real tridiagonal symmetric positive definite distributed matrix A." */
/* OPTIONS */
{
    extern void FortranCall(pdpttrf)( int*,
                               double*, double*, int*, int*,
                               double*, int*,
                               double*, int*,
                               int*);

	int maxldd;

	double *locd=NULL;
	double *loce=NULL;
	int desctdd[DESCLEN];
	int desc_gtdd[DESCLEN];

	double *locaf=NULL;
	int laf;
	
	double *locwork=NULL;
	int llocwork;


	INITIALIZE();

	SCALAR( "int", n);
	SIZE(n);

	tdMATRIX( "double", e, d, e, n);
        tdDISTRIBUTE( "double", e, d, e, n);
        
	laf = blocsize+2;
        locaf = MALLOC(sizeof(double)*laf);
        assert(locaf);
	
	llocwork = worklen();
	WORK(locwork,llocwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pdpttrf)( &n,
                               locd, loce, &one, desctdd,
                               locaf, &laf,
                               locwork, &llocwork,
                               &linfo);

	tdGATHER( "double", e, d, e, n);

	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
		*info = linfo;
	} else {
	}
	FREE_MATRIX(d);
	FREE_MATRIX(e);
	FREE(locaf);
        FREE(locwork);
	
}

