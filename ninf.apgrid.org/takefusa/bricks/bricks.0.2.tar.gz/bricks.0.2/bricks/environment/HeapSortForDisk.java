package bricks.environment;
import java.util.*;

public class HeapSortForDisk {
    
    private static final String Usage = 
	"java bricks.util.HeapSortForDisk [int numData]";

    private static Vector v = new Vector();


    public static void sortByLastAccessedTime(Vector data) {
	int bottom = data.size() / 2;
	int top = data.size() - 1;
	while (bottom > 0) {
	    bottom--;
	    shiftDownByLastAccessedTime(data, top, bottom);
	}
	while (top > 0) {
	    swap(data, 0, top);
	    top--;
	    shiftDownByLastAccessedTime(data, top, bottom);
	}
    }

    protected static void shiftDownByLastAccessedTime(
	Vector data, int top, int bottom
    ) {
	int i = 2 * bottom;
	while (i <= top) {
	    if (i < top) {
		DataFragmentInfo info1 = (DataFragmentInfo)data.elementAt(i+1);
		DataFragmentInfo info0 = (DataFragmentInfo)data.elementAt(i);
		if (info1.lastAccessedTime() > info0.lastAccessedTime())
		    i++;
	    }
	    if (((DataFragmentInfo)data.elementAt(bottom)).lastAccessedTime()
		>= ((DataFragmentInfo)data.elementAt(i)).lastAccessedTime())
		break;
	    swap(data, bottom, i);
	    bottom = i;
	    i = 2 * bottom;
	}
    }

    public static void sortByScore(Vector data) {
	int bottom = data.size() / 2;
	int top = data.size() - 1;
	while (bottom > 0) {
	    bottom--;
	    shiftDownByScore(data, top, bottom);
	}
	while (top > 0) {
	    swap(data, 0, top);
	    top--;
	    shiftDownByScore(data, top, bottom);
	}
    }

    public static void sortByScore(Vector data, int num) {
	int bottom = num / 2;
	int top = num - 1;
	while (bottom > 0) {
	    bottom--;
	    shiftDownByScore(data, top, bottom);
	}
	while (top > 0) {
	    swap(data, 0, top);
	    top--;
	    shiftDownByScore(data, top, bottom);
	}
    }

    protected static void shiftDownByScore(Vector data, int top, int bottom) {
	int i = 2 * bottom;
	while (i <= top) {
	    if (i < top) {
		DataFragmentInfo info1 = (DataFragmentInfo)data.elementAt(i+1);
		DataFragmentInfo info0 = (DataFragmentInfo)data.elementAt(i);
		if (info1.score > info0.score)
		    i++;
	    }
	    if (((DataFragmentInfo)data.elementAt(bottom)).score
		>= ((DataFragmentInfo)data.elementAt(i)).score)
		break;
	    swap(data, bottom, i);
	    bottom = i;
	    i = 2 * bottom;
	}
    }

    public static void swap(Vector data, int indexA, int indexB) {
	Object tmp = data.elementAt(indexA);
	data.insertElementAt(data.elementAt(indexB), indexA);
	data.removeElementAt(indexA + 1);
	data.insertElementAt(tmp, indexB);
	data.removeElementAt(indexB + 1);
    }

    public static void main(String[] argv) {

	if (argv.length == 0) {
	    System.out.println(Usage);
	    return;
	}

	int numData = Integer.valueOf(argv[0]).intValue();

	Random random = new Random();
	Vector data = new Vector(numData);

	for (int i = 0; i < numData; i++) {
	    DataFragment fragment = new DataFragment(
		(new Integer(i)).toString(), random.nextInt()
	    );
	    fragment.stored(random.nextDouble() * 10);
	    DataFragmentInfo info = new DataFragmentInfo(fragment);
	    info.setScore(random.nextDouble());
	    data.add(info);
	}

	HeapSortForDisk.sortByLastAccessedTime(data);
	System.out.println("SortByLastAccessedTime");
	System.out.println("id size lastAccessedTime score");
	for (int i = 0; i < data.size(); i++) {
	    System.out.println((DataFragmentInfo)data.elementAt(i));
	}
	
	HeapSortForDisk.sortByScore(data);
	System.out.println("SortByScore");
	for (int i = 0; i < data.size(); i++) {
	    System.out.println((DataFragmentInfo)data.elementAt(i));
	}
    }
}


