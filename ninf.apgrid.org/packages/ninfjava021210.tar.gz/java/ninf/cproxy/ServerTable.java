package ninf.cproxy;
import ninf.basic.*;
import ninf.client.*;
import java.io.PrintStream;
import java.util.Vector;
import java.util.Enumeration;

class ServerTable{
  static NinfLog dbg = new NinfLog("ServerTable");

  Vector servers = new Vector();
  Vector pingers = new Vector();

  CProxyServer master;
  ServerTablePinger tablePinger;

  ServerTable(CProxyServer master){
    this.master = master;
    CProxyConfig conf = master.masterProxy.conf;
    tablePinger = new ServerTablePinger(master.metaServer, conf.metaInterval, this);
    tablePinger.start();

  }

  public synchronized void addNewServer(NinfServerStructComm server){
    int minimumSize, maximumSize;
    if (servers.contains(server))
      return;
    servers.addElement(server);
    CProxyConfig conf = master.masterProxy.conf;

    TPinger pinger;
    try {
      pinger = (TPinger)(conf.TPingerClass.newInstance());
    } catch (IllegalAccessException e){
	dbg.log("cannot make pinger");
	return;
    } catch (InstantiationException e){
	dbg.log("cannot make pinger");
	return;
    }
    pinger.setup(server, conf.interval, conf.throughputSize, 
		 conf.minimumSize, conf.maximumSize,
		 conf.measureTime, conf.throughputLogStream);
    pingers.addElement(pinger);
    new Thread(pinger).start();
  }
  
  public synchronized void sendServers(MetaServerConnection con){
    int serverNum = servers.size();
    con.send(new NinfCommand("servers", "" + serverNum));
    Enumeration enum = servers.elements();
    while (enum.hasMoreElements()){
      NinfServerStructComm server = (NinfServerStructComm)enum.nextElement();
      server.writeOut(con.os);
    }
  }


}

