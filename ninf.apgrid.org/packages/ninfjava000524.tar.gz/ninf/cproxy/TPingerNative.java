package ninf.cproxy;
import ninf.basic.*;
import ninf.common.*;
import ninf.client.*;
import java.util.Vector;
import java.util.Hashtable;
import java.io.IOException;
import java.io.PrintStream;
import java.net.*;

public class TPingerNative implements TPinger{
  int interval;               /* interval in second */
  int size;                   /* size in byte */
  int minimumSize, maximumSize;
  int psize;
  NinfServerStructComm target;
  double throughput;
  static NinfLog dbg = new NinfLog("TPingerNative");
  double measureTime;
  PrintStream throughputLogStream;

  static Class getPingerClass(){
    return (new TPingerNative()).getClass();
  }

  public TPinger setup(NinfServerStructComm target, int interval, int size){
    setup(target, interval, size, 100, 100000, 1.0, null);
    return this;
  }

  public TPinger setup(NinfServerStructComm target, int interval, 
	  int size, int minimumSize, int maximumSize, 
	  double measureTime, PrintStream throughputLogStream){
    this.target = target;
    this.interval = interval;
    this.size = size;
    this.minimumSize = minimumSize;
    this.maximumSize = maximumSize;
    this.measureTime = measureTime;
    if (throughputLogStream != null)
      this.throughputLogStream = throughputLogStream;
    else 
      this.throughputLogStream = System.out;
    return this;
  }

  void ping(){
    try {
      long rtt;      
      NinfServerConnection con = target.connect();
      rtt = con.getThroughput(size, 0);
      target.throughput = new CommunicationInformation(rtt, size, 0);
      rtt = con.getThroughput(0, 0);
      target.latency = new CommunicationInformation(rtt, 0, 0);
      con.close();
      throughput = target.throughput.throughput;
      psize = size;

      size = (int)(throughput * measureTime / 2);
      if (size > maximumSize)
	size = maximumSize;
      if (size < minimumSize)
	size = minimumSize;
      
      if (throughputLogStream != null)
	throughputLogStream.println(FormatString.format(
	    "%.2lf %30s %11.2lf", 
	    new Double(System.currentTimeMillis() / 1000.0),
	    target, 
	    new Double(target.throughput.throughput)));

    } catch (NinfException e){
      System.err.println(e);
    }
  }

  public void run(){
    while (true){
      ping();
      //      System.out.println("Throughput to " + target + ": " 
      //	  + throughput + "[byte/sec] at size = " + psize);
      try {
	Thread.sleep(interval * 1000);
      } catch (InterruptedException e){
	break;
      }
    }
  }


  public static void main(String args[]){
    NinfLog.verbose();
    //    NinfLog.log();
    NinfServerStructComm tmp = 
      new NinfServerStructComm(args[0], new Integer(args[1]).intValue());
					
    new Thread(new TPingerNative().setup(tmp, 5, 
			   new Integer(args[2]).intValue(),
			   new Integer(args[2]).intValue(),
			   new Integer(args[2]).intValue(),
			   new Double (args[3]).doubleValue(),
			   null)).start();
  }
}
