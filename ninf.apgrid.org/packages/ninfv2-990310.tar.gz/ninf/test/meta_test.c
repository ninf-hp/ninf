#include <stdio.h>
#include <math.h>
#include "ninf.h"

int verbose = FALSE;
#define N    5
#define MMAX  100
int M = 3;

int throttle_test(){
  int j, res;
  int success = TRUE;
  printf("throttle_testing: ");

  Ninf_transaction_begin();
  for (j = 0; j < M; j++){
    res = Ninf_call("test/sleep", 10);
    if (res != NINF_OK)
      Ninf_perror("sleep:");
  }
  res = Ninf_transaction_end();
  if (res != NINF_OK)
    success = FALSE;
  return success;
}

int transaction_test(){
  int success = TRUE;
  double a[MMAX][N], b[MMAX][N];
  int i, j, res;

  for (j = 0; j < M; j++){
    for (i = 0; i < N; i++){
      a[j][i] = i + 100 * j;
      b[j][i] = 0;
    }
  }
  printf("transaction_testing: ");

  Ninf_transaction_begin();
  for (j = 0; j < M; j++){
    res = Ninf_call("test/double_test", N, a[j], b[j]);
    if (res != NINF_OK)
      Ninf_perror("double_test:");
  }
  res = Ninf_transaction_end();

  if (verbose) printf("res = %d\n", res);

  for (j = 0; j < M; j++){
    for (i = 0; i < N; i++){
      if (a[j][i] != b[j][i]){
	if (verbose)
	  printf("double_test: a[%d][%d](%f) != b[%d][%d](%f)\n", 
		 j, i, a[j][i], j, i, b[j][i]);
	success = FALSE;
      }
    }
  }
  return success;
}

int transaction_test2(){
  int success = TRUE;
  double a[MMAX][N];
  int i, j, res;

  for (i = 0; i < N; i++)
    a[0][i] = i + 100;

  for (j = 1; j < M; j++)
    for (i = 0; i < N; i++)
      a[j][i] = 0;

  printf("transaction_testing2: ");

  Ninf_transaction_begin();
  for (j = 0; j < M - 1; j++){
    res = Ninf_call("test/double_test", N, a[j], a[j+1]);
    if (res != NINF_OK)
      Ninf_perror("double_test:");
  }
  res = Ninf_transaction_end();
  
  if (verbose) printf("res = %d\n", res);

  for (i = 0; i < N; i++){
    if (a[0][i] != a[M-1][i]){
      if (verbose)
	printf("double_test: a[%d][%d](%f) != a[%d][%d](%f)\n", 
	       0, i, a[0][i], M-1, i, a[M-1][i]);
      success = FALSE;
    }
  }
  return success;
}

init_mat(double A[][N],double B[][N],double C[][N],double C0[][N]){
  int i, j;
 for(i = 0; i < N; i++)
    for(j = 0; j < N; j++){
      A[i][j] = i + 0.1 * j;
      B[i][j] = (i == j)? 1 : 0;
      C[i][j] = 0.0;
      C0[i][j] = 0.0;
    }
}

/* test routine */
mmul(n,A,B,C)
     double *A,*B,*C;
{
    double t;
    int i,j,k;

    for (i=0;i<n;i++) {
	for (j=0;j<n;j++) {
	    t = 0;
	    for (k=0;k<N;k++){
		t += A[i*n + k] * B[k*n+j];	/* inner product */
	    }
	    C[i*n+j] = t;
	}
    }
}

int dataflow_test(){
  double A[N][N], B[N][N], C[N][N], D[N][N], E[N][N], F[N][N], G[N][N];
  double G0[N][N];
  char buffer[1000];
  int i, j;
  int res;

  init_mat(A,B,E,F);
  init_mat(C,D,G,G0);
  printf("dataflow_testing: ");


  Ninf_transaction_begin();
  if (Ninf_call("test/matmul", N, A, B, E) != NINF_OK){
    Ninf_perror("matmul:"); return FALSE;}
  if (Ninf_call("test/matmul", N, C, D, F) != NINF_OK){
    Ninf_perror("matmul:"); return FALSE;}
  if (Ninf_call("test/matmul", N, E, F, G) != NINF_OK){
    Ninf_perror("matmul:"); return FALSE;}
  res = Ninf_transaction_end();
  if (verbose) printf("res = %d\n", res);

  mmul(N,A,B,E); 
  mmul(N,C,D,F); 
  mmul(N,E,F,G0); 

  for(i = 0; i < N; i++)
    for(j = 0; j < N; j++){
      if(G[i][j] != G0[i][j]){ 
	if (verbose) printf("G[%d][%d]= %e != %e\n",
			    i,j,G[i][j],G0[i][j]);
	return FALSE;
      }
    }
  return TRUE;
}

int dataflow_test2(){
  double A[N][N], B[N][N], C[N][N], D[N][N], G[N][N], G0[N][N];
  char buffer[1000];
  int i, j;
  int res;
  int success = TRUE;

  init_mat(A,B,G,G0);
  printf("dataflow_testing2: ");

  Ninf_transaction_begin();
  if (Ninf_call("test/throughMatC", N,N, A, B) != NINF_OK){
    Ninf_perror("throughMatC:"); return FALSE;}
  if (Ninf_call("test/throughMatC", N,N, B, C) != NINF_OK){
    Ninf_perror("throughMatC:"); return FALSE;}
  if (Ninf_call("test/throughMatC", N,N, B, D) != NINF_OK){
    Ninf_perror("throughMatC:"); return FALSE;}
  if (Ninf_call("test/matmul", N, C, D, G) != NINF_OK){
    Ninf_perror("matmul:"); return FALSE;}
  res = Ninf_transaction_end();
  if (verbose) printf("res = %d\n", res);

  mmul(N,A,A,G0); 

  for(i = 0; i < N; i++)
    for(j = 0; j < N; j++){
      if(G[i][j] != G0[i][j]){ 
	if (verbose) printf("G[%d][%d]= %e != %e\n",
			    i,j,G[i][j],G0[i][j]);
	success = FALSE;
      }
    }
  return success;
}

int dataflow_test3(){
  double A[N][N], B[N][N], C[N][N], D[N][N], G[N][N], G0[N][N];
  char buffer[1000];
  int i, j;
  int res;
  int success = TRUE;

  init_mat(A,B,G,G0);
  printf("dataflow_testing3: ");

  Ninf_transaction_begin();
  if (Ninf_call("test/throughMatC", N,N, B, C) != NINF_OK){
    Ninf_perror("throughMatC:"); return FALSE;}
  if (Ninf_call("test/throughMatC", N,N, B, D) != NINF_OK){
    Ninf_perror("throughMatC:"); return FALSE;}
  if (Ninf_call("test/matmul", N, C, D, G) != NINF_OK){
    Ninf_perror("matmul:"); return FALSE;}
  res = Ninf_transaction_end();
  if (verbose) printf("res = %d\n", res);

  mmul(N,B,B,G0); 

  for(i = 0; i < N; i++)
    for(j = 0; j < N; j++){
      if(G[i][j] != G0[i][j]){ 
	if (verbose) printf("G[%d][%d]= %e != %e\n",
			    i,j,G[i][j],G0[i][j]);
	success = FALSE;
      }
    }
  return success;
}

int dataflow_test4(){
  double A[N][N], B[N][N], C[N][N], D[N][N], E[N][N], F[N][N], G[N][N], G0[N][N];
  char buffer[1000];
  int i, j;
  int res;
  int success = TRUE;

  init_mat(A,B,G,G0);
  printf("dataflow_testing4: ");

  Ninf_transaction_begin();
  if (Ninf_call("test/throughMatC", N,N, A, C) != NINF_OK){
    Ninf_perror("throughMatC:"); return FALSE;}
  if (Ninf_call("test/throughMatC", N,N, B, D) != NINF_OK){
    Ninf_perror("throughMatC:"); return FALSE;}
  if (Ninf_call("test/matmul", N, C, D, E) != NINF_OK){
    Ninf_perror("matmul:"); return FALSE;}
  if (Ninf_call("test/throughMatC", N,N, E, F) != NINF_OK){
    Ninf_perror("throughMatC:"); return FALSE;}
  if (Ninf_call("test/throughMatC", N,N, E, G) != NINF_OK){
    Ninf_perror("throughMatC:"); return FALSE;}
  res = Ninf_transaction_end();
  if (verbose) printf("res = %d\n", res);

  mmul(N,A,B,G0); 

  for(i = 0; i < N; i++)
    for(j = 0; j < N; j++){
      if(G[i][j] != G0[i][j]){ 
	if (verbose) printf("G[%d][%d]= %e != %e\n",
			    i,j,G[i][j],G0[i][j]);
	success = FALSE;
      }
    }
  return success;
}

extern int ninf_debug_flag;

main(int argc, char ** argv)
{
  argc = Ninf_parse_arg(argc, argv);
  while (argc > 1){
    argv++;
    if (strcasecmp(*(argv), "-verbose") == 0)
      verbose = TRUE;
    else if (strcasecmp(*(argv), "-debug") == 0)
      ninf_debug_flag = TRUE;
    else 
      M = atoi(*argv);
    argc--;
  }
  
  /*
  if (transaction_test())  {printf("\tOK\n");} else { printf("\tfailed\n");} 
  if (transaction_test2()) {printf("\tOK\n");} else { printf("\tfailed\n");} 
  if (throttle_test()) {printf("\tOK\n");} else { printf("\tfailed\n");}
  if (dataflow_test()) {printf("\tOK\n");} else { printf("\tfailed\n");}
  if (dataflow_test2()) {printf("\tOK\n");} else { printf("\tfailed\n");}
  if (dataflow_test3()) {printf("\tOK\n");} else { printf("\tfailed\n");}
  */

  if (dataflow_test4()) {printf("\tOK\n");} else { printf("\tfailed\n");}

}

