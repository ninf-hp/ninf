#define _WRAPPER_
/* $Id: pslarft_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define FLOAT
#include <gscalapack.h>

#define ROW_v ldv
#define COL_v col_v
#define ROW_t ldt
#define COL_t col_t
static	int worklen(int k) {
	  int ret=1;
	  ret = (k*(k-1)/2);
	  return ret;
}


void  pslarft_ninf(	 char direct,
		 char storev,
		 int n,
		 int k,
		 float global_v[],
		 int ldv,
		 float global_tau[],
		 float global_t[],
		 int ldt
)
/* "pslarft forms the triangular factor T of a real block reflector H of order n, which is defined as a product of k elementary reflectors." */
/* OPTIONS */
{
	int maxldd;

	int maxldv;
	int col_v;
	float *locv=NULL;
	int descv[DESCLEN];
	int desc_gv[DESCLEN];
	int row_locv, col_locv;

	float *loctau=NULL;

	int maxldt;
	int col_t;
	float *loct=NULL;
	int desct[DESCLEN];
	int desc_gt[DESCLEN];
	int row_loct, col_loct;

	float *locwork=NULL;
	int llocwork;

	INITIALIZE();

	SCALAR( "char", direct);
	SCALAR( "char", storev);
	SCALAR( "int", n);
	SCALAR( "int", k);

	if (chrcmp(storev,'c')==0) col_v = k;
	else col_v = n;
	col_t = max(k,n);

	ROW(v);
	COL(v);
	ROW(t);
	COL(t);
	MAXLDD( maxldd, v);
	maxldv = maxldd;
	maxldt = maxldd;
	  
	MATRIX("float", v, ROW_v, COL_v);
	DISTRIBUTE( "float", v, ROW_v, COL_v);
	MATRIX("float", t, ROW_t, COL_t);

	/* ? */
	if (chrcmp(storev,'c')==0) {
	  VECTOR( "c", "float", tau, k);
	  vDISTRIBUTE( "c", "float", tau, k);
	} else {
	  VECTOR( "r", "float", tau, k);
	  vDISTRIBUTE( "r", "float", tau, k);
	}

	llocwork = worklen(k);
	WORK(locwork,llocwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pslarft)( &direct, &storev,
                               &n, &k,
                               locv, &one, &one, descv,
                               loctau,
                               loct,
                               locwork);

	if (chrcmp(storev,'c')==0)
	  vGATHER( "c", "float", tau, k);
	else
	  vGATHER( "r", "float", tau, k);
	GATHER( "float", t, ROW_t, COL_t);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){

	} else {
	}
	FREE_MATRIX(v);
	FREE_VECTOR(tau);
	FREE_MATRIX(t);
        FREE(locwork);
	
}

