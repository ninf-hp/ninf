#define _WRAPPER_
/* $Id: pdlared2d_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define DOUBLE
#include <gscalapack.h>
/* ?? */
static	int worklen(int n) {
	  int ret=1;
	  ret = n;
	  if NEED_BUFF {
	    ret= NUMROC(N, NB , 0, 0, NPCOL);
	  }
	  return ret;
}

void  pdlared2d_ninf(	 int n,
		 double global_byrow[],
		 double byall[],
		 double work[],
		 int lwork
)
/* "pdlared2d redistributes a 1D array. It assumes that the input array, BYROW, is distributed across columns and that all process rows contain the same copy of  BYROW." */
/* OPTIONS */
{
	int maxldd;

	int desc[DESCLEN];
	int desc_g[DESCLEN];

	double *locbyrow=NULL;

	double *locwork=NULL;
	int llocwork;



	INITIALIZE();

	SCALAR( "int", n);
	if (mypnum!=0) {
            byall = MALLOC(sizeof(double)*n);
            assert(byall);
        }
        

	VECTOR("c","double", byrow, n);
	vDISTRIBUTE("c","double", byrow, n);
	Cdescinit(desc, 1, n, 1, cbloc, 0, 0,PARA_CTXT, 1, &linfo);

	llocwork=worklen(n);
	WORK(locwork,llocwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pdlared2d)( &n, &one, &one, desc, locbyrow, byall, locwork, &llocwork);

	RETRIEVE("double", byall, n);

	if( mypnum == 0 ){
	} else {
            FREE(byall);
	}
        FREE(locwork);
	
}

