package ninf.netsolve;
public class HelpText {

/* This class contains the text for the main help screen.
 It's here, rather than in a file, because at some point,
 this will run as an applet and then we won't have to worry
 about security restrictions on file access, etc... */

  private static String [] english_topics = {
    "Viewing Problem Information",
    "Solving a Problem",
    "Viewing Server Information",
    "Exiting this Program",
    "Closing this Screen"
  };

  private static String [] italian_topics = {
    "Per visualizzare le informazioni di un problema",
    "Per risolvere un problema",
    "Per avere informazione sui servers",
    "Per Chiudere questo Help",
    "Per uscire dal programma"
  };

  private static String [] english_strings = {
    "To view information about a problem:\n" +
    " -click on the name of the problem you are interested in\n" + 
    "\t(choose from the list of problems on the left side of the main screen).\n" +
    " -read the text in the \"Description\" box.\n" +
    " -click on any of the items in the \"Inputs\" list and read the description\n" +
    "\tof that input object in the box immediately to the right of the \n" +
    "\tInput object list.  \n" +
    " -similarly, you may click on any of the items in the \"Outputs\" list to\n" +
    "\tget a description of that Output object.\n" +
    "\n",

    "To solve a problem:\n" +
    " -click on the name of the problem you want to solve (your\n" +
    "\tselection should now be highlighted).\n" +
    " -click the \"Solve\" button (located in the lower right region of the main screen).\n" +
    " -as an alternative to the previous two steps, you may simply\n" +
    "\tdouble-click the name of the problem you want to solve.\n" +
    " -momentarily, an Input window will appear.\n" +
    " -enter the data, filenames, and/or URLs and click the \"Compute\" button.\n" +
    " -wait for the results.\n" +
    "\n",

    "To view information about the servers in the NetSolve system:\n" +
    " -click the \"Server Info\" button on the main screen.\n" +
    " -a window will appear containing a list of the servers and agents\n" +
    "\tin the NetSolve system.\n" +
    " -you may update the list with current information at any time by\n" +
    "\tclicking the \"Update\" button\n" +
    " -when you have finished viewing the information, click the \"Dismiss\"\n" +
    "\tbutton.\n" +
    "\n",

    "To get rid of this help screen:\n" +
    " -click the \"Close\" button.\n" +
    "\n",

    "To exit this program:\n" +
    " -click the \"Quit\" button on the main screen.\n"
  };

  private static String [] italian_strings = { 
    "Per visualizzare le informazioni di un problema:\n" +
    " -cliccare sul nome del problema di cui si e' interessati\n" + 
    "\t(scegli un problema dalla lista che appare sul lato sinistro dello schermo principale).\n" +
    " -leggi il testo dal box \"Descrizione\".\n" +
    " -clicca su una entry qualsiasi della lista \"Inputs\" e leggi la descrizione\n" +
    "\tdi quella entry nel box che si trova sulla destra della \n" +
    "\tlista degli inputs.  \n" +
    " -allo stesso modo puoi cliccare su una delle entry della lista degli \"Outputs\" per\n" +
    "\tottenere una descrizione di quel output.\n" +
    "\n",

    "Per risolvere un problema:\n" +
    " -clicca sul nome del problema che vuoi usare (la tua\n" +
    "\tselezione verra' evidenziata).\n" +
    " -clicca sul bottone \"Risolvere\" (si trova nella parte piu' in basso a destra dello schermo).\n" +
    " -come alternativa ai precedenti due passaggi puoi semplicemente fare un\n" +
    "\tdoppio-click sul nome del problema che vuoi risolvere.\n" +
    " -Apparira' una finestra di inputs.\n" +
    " -introduci i dati, il nome del file e/o l'URL e clicca sul bottone \"Computa\".\n" +
    " -aspetta la visualizzazione dei risultati.\n" +
    "\n",

    "Per avere informazione sui servers in un sistema Netsolve:\n" +
    " -clicca sul bottone \"Info dal Server\" dello schermo principale .\n" +
    " -apparira' una finestra contenente una lista di servers e agents\n" +
    "\tdi un sistema Netsolve.\n" +
    " -Puoi aggiornare la lista con le informazioni semplicemente\n" +
    "\tcliccando sul bottone \"Aggiorna\" \n" +
    " -quando hai finito di visionare le informazioni, clicca sul bottone \"Abbandona\"\n" +
    "\n",

    "Per Chiudere questo Help:\n" +
    " -clicca sul bottone \"Chiudi\" .\n" +
    "\n",

    "Per uscire dal programma:\n" +
    " -clicca sul bottone \"Esci\" dello schermo principale .\n"
  };

  public static String [] get_topics() {
    switch(Labels.language) {
      case Labels.ENGLISH:
        return english_topics;
      case Labels.ITALIAN:
        return italian_topics;
      default:
        return english_topics;
    }
  }

  public static String [] get_help_text() {
    switch(Labels.language) {
      case Labels.ENGLISH:
        return english_strings;
      case Labels.ITALIAN:
        return italian_strings;
      default:
        return english_strings;
    }
  }
}
