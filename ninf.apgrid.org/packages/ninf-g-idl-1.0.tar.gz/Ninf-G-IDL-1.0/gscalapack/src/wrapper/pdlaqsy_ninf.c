#define _WRAPPER_
/* $Id: pdlaqsy_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define DOUBLE
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n

void  pdlaqsy_ninf(	 char uplo,
		 int n,
		 double global_a[],
		 int lda,
		 double global_sr[],
		 double global_sc[],
		 double scond,
		 double amax,
		 char *equed
)
/* "pdlaqsy equilibrates a symmetric distributed matrix A using the scaling factors in the vectors SR and SC." */
/* OPTIONS */
{

	int maxldd;

	int maxlda;
	double *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
	int row_loca, col_loca;

	double *locsr=NULL;
	double *locsc=NULL;

	char locequed[1];

	INITIALIZE();

	SCALAR( "char", uplo);
	SCALAR( "int", n);
	SCALAR( "double", scond);
	SCALAR( "double", amax);
	SCALAR( "int", lda);

	ROW( a);
	COL( a);
	MAXLDD( maxldd, a );
	maxlda = maxldd;

	MATRIX( "double", a, ROW_a, COL_a);
	DISTRIBUTE( "double", a, ROW_a, COL_a);
        
	VECTOR("r","double",sr, ROW_a);
	VECTOR("c","double",sc, COL_a);
	vDISTRIBUTE("r","double",sr, ROW_a);
	vDISTRIBUTE("c","double",sc, COL_a);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pdlaqsy)( &uplo, &n,
                               loca, &one, &one, desca,
                               locsr, locsc,
                               &scond, &amax,
                               locequed);

	GATHER("double", a, ROW_a, COL_a);
	RETRIEVE("char", locequed, 1);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
            *equed = locequed[0];
	} else {
		
	}

	FREE_MATRIX(a);
	FREE_VECTOR(sr);
	FREE_VECTOR(sc);
	
}

