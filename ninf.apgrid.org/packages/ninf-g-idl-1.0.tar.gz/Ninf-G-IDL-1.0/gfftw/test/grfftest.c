#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>

#define N   103000

#if defined(NINFG1)
#include "grpc.h"
#include "ns.h"
#include "ns_complex.h"
#include "nsapi.h"
#elif defined(NINFG2)
#include "grpc.h"
#include "ng.h"
#else
#error NINF Version is unknown.
#endif
#include "assert.h"

#include <gfftest.h>

char *host;
int port = 0;

#define COUNT 100

extern double second();

int main(int argc,char ** argv) {

  grpc_function_handle_t handle;
  double *in=NULL, *out=NULL, *rout=NULL;
  dcomplex *cin=NULL,*cdat=NULL;
  double resid;
  char plan[WISDOMLEN];

  double *dat=NULL;
  int n=N;
  double x;
  int i;

  double time0, timef;

  if (argc>1) {
    if (grpc_initialize(argv[1]) != GRPC_NO_ERROR) {
      grpc_perror_np("grpc initialize");
      exit(2);
    }
  } else {
    fprintf(stderr, "You need to put config_file.\n");
    exit(0);
  }

  in = malloc(sizeof(double)*n); assert(in);
  out = malloc(sizeof(double)*n); assert(out);
  rout = malloc(sizeof(double)*n); assert(rout);
  dat = malloc(sizeof(double)*n); assert(dat);

  cin = malloc(sizeof(dcomplex)*n); assert(cin);
  cdat = malloc(sizeof(dcomplex)*n); assert(cdat);

  x=0.2;
  for(i=0;i<N;i++) {
    //            x=4.*x*(1.-x);
    dat[i]=sin((double)i/64.);
  }

  for(i=0;i<N;i++) {
    in[i] = dat[i];
    out[i] = 0.;
    rout[i] = 0.;

    cin[i].r = dat[i];
    cin[i].i = 0.;
    cdat[i].r = 0.;
    cdat[i].i = 0.;
  }

#if defined(NINFG1)
  host = strdup(nslib_conf_getserverhostname());
  port = nslib_conf_getserverport();
#else
  if ((host = getenv("NG_SERVER"))==NULL ) {
      fprintf(stderr, "env 'NG_SERVER' is not defined and set my hostname instead.\n");
#define HOSTNAMELEN 512
      host = calloc(HOSTNAMELEN, sizeof(char));
      if (gethostname(host, HOSTNAMELEN) != 0) {
          strcpy(host,"localhost");
      }
  }
  {
      char *dummyc;
      if ((dummyc = getenv("NG_SERVER_PORT")) != NULL) {
          port = atoi(dummyc);
      }
  }
#endif
  printf("size=%d\n",n);

  printf("\nMEASURE MODE:\n");
  time0 = second();
  if (grpc_function_handle_init( &handle, host, "fftw/rfftw_create_plan") 
      != GRPC_NO_ERROR ) {
    grpc_perror_np( "handle_init");
    exit(2);
  }


  if (grpc_call( &handle,
		 n, FFTW_FORWARD, FFTW_MEASURE,
		 plan)
      != GRPC_NO_ERROR) {
    fprintf(stderr,"Failed in grpc_call:create_plan\n");
    exit(2);
  }
  grpc_function_handle_destruct(&handle);
  timef = second();
  printf("create_plan(MEASURE): time= %f sec\n",timef-time0);


   if (grpc_function_handle_init( &handle, host, "fftw/rfftw_one") 
       != GRPC_NO_ERROR ) {
     grpc_perror_np( "handle_init");
     exit(2);
   }

   time0 = second();
   printf("count= ");
   for(i=0;i<COUNT;i++) {
     if (grpc_call(&handle, plan, in, out, n, n)!= GRPC_NO_ERROR) {
       fprintf(stderr,"Failed in grpc_call:one\n");
       exit(2);
     }
     if ((i<5)||((i+1)%10==0)) { printf("%d ",i+1); fflush(stdout);}
   }
   timef = second();
   printf("\ntime= %f sec (%dtimes)\n",timef-time0, COUNT);
   grpc_function_handle_destruct(&handle);


   printf("\nESTIMATE MODE:\n");
   for(i=0;i<WISDOMLEN;i++) plan[i]='\0';
   if (grpc_function_handle_init( &handle, host, "fftw/rfftw_one") 
       != GRPC_NO_ERROR ) {
     grpc_perror_np( "handle_init");
     exit(2);
   }
   time0 = second();
   printf("count= ");
   for(i=0;i<COUNT;i++) {
     if (grpc_call(&handle, plan, in, out, n, n)!= GRPC_NO_ERROR) {
       fprintf(stderr,"Failed in grpc_call:one\n");
       exit(2);
     }
     if ((i<5)||((i+1)%10==0)) { printf("%d ",i+1); fflush(stdout);}
   }
   timef = second();
   printf("\ntime= %f sec (%dtimes)\n",timef-time0, COUNT);
   grpc_function_handle_destruct(&handle);


   printf("\n\nRESIDUE Check.\n");

   if (grpc_function_handle_init( &handle, host, "fftw/irfftw_one") 
       != GRPC_NO_ERROR ) {
     grpc_perror_np( "handle_init");
     exit(2);
   }
   if (grpc_call(&handle, plan, out, rout, n, n)!= GRPC_NO_ERROR) {
     fprintf(stderr,"Failed in grpc_call:ione\n");
     exit(2);
   }
  grpc_function_handle_destruct(&handle);

  for(i=0;i<n;i++) rout[i] /= (double)n;

  printf("\n");
  for(i=0;i<10;i++) printf("%f %f\n",in[i], rout[i]);

   resid=0.;
   for(i=0;i<n;i++) {
     resid += (in[i]-rout[i])*(in[i]-rout[i]);
   }
   resid = sqrt(resid)/(double)n;

   printf("\nresid=%2.18f\n\n",resid);


   printf("\nDo the same calcuration with complex numbers.\n");
   printf("\nMEASURE MODE:\n");

   time0 = second();
  if (grpc_function_handle_init( &handle, host, "fftw/fftw_create_plan") 
      != GRPC_NO_ERROR ) {
    grpc_perror_np( "handle_init");
    exit(2);
  }

  if (grpc_call( &handle,
		 n, FFTW_FORWARD, FFTW_MEASURE,
		 plan)
      != GRPC_NO_ERROR) {
    fprintf(stderr,"Failed in grpc_call:create_plan\n");
    exit(2);
  }
  grpc_function_handle_destruct(&handle);
  timef = second();
  printf("create_plan: time= %f sec\n",timef-time0);


  if (grpc_function_handle_init( &handle, host, "fftw/fftw_one") 
      != GRPC_NO_ERROR ) {
    grpc_perror_np( "handle_init");
    exit(2);
  }


   time0 = second();
   printf("count= ");
   for(i=0;i<COUNT;i++) {
     if (grpc_call(&handle, plan, cin, cdat, n, n)!= GRPC_NO_ERROR) {
       fprintf(stderr,"Failed in grpc_call:one\n");
       exit(2);
     }
     if ((i<5)||((i+1)%10==0)) {printf("%d ",i+1); fflush(stdout);}
   }
   timef = second();
   printf("\ntime= %f sec (%dtimes)\n",timef-time0, COUNT);

  grpc_function_handle_destruct(&handle);

  for(i=0;i<=n/2;i++)  out[i] = cdat[i].r;
  for(i=n-1;i>n/2;i--) out[i] = cdat[n-i].i;

  printf("\nRESIDUE Check.\n");

  if (grpc_function_handle_init( &handle, host, "fftw/irfftw_one") 
      != GRPC_NO_ERROR ) {
    grpc_perror_np( "handle_init");
    exit(2);
  }
  if (grpc_call(&handle, plan, out, rout, n, n)!= GRPC_NO_ERROR) {
    fprintf(stderr,"Failed in grpc_call:ione\n");
    exit(2);
  }
  grpc_function_handle_destruct(&handle);


  for(i=0;i<n;i++) rout[i] /= (double)n;

  printf("\norg inv^2\n");
  for(i=0;i<10;i++) printf("%2.16f %2.16f\n",in[i], rout[i]);

  resid=0.;
  for(i=0;i<n;i++) {
    resid += (in[i]-rout[i])*(in[i]-rout[i]);
  }
  resid = sqrt(resid)/(double)n;

  printf("\nresid=%2.18f\n\n",resid);

   grpc_finalize();

   free(in);
   free(out);

   return 0;
}

double
second()
{
#include <sys/time.h>

  struct timeval tm;
  double t ;

  static int base_sec = 0,base_usec = 0;

  gettimeofday(&tm, NULL);
  
  if(base_sec == 0 && base_usec == 0)
    {
      base_sec = tm.tv_sec;
      base_usec = tm.tv_usec;
      t = 0.0;
    } else {
      t = (double) (tm.tv_sec-base_sec) + 
	((double) (tm.tv_usec-base_usec))/1.0e6 ;
    }

  return t ;
}
