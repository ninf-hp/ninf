/* 
 * Ninf stub header file
 */
#ifndef  __NINF_STUB__
#define  __NINF_STUB__

#include <stdio.h>
#include "ninf_macros.h"
#include "id_set.h"
#include "ninf.h"
#include "ninf_error.h"



#endif /* __NINF_STUB__ */
