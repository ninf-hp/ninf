#define _WRAPPER_
/* $Id: pdpttrs_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define _DISTRIBUTE_1D_
#define DOUBLE
#include <gscalapack.h>

#define ROW_b ldb
#define COL_b nrhs
static	int worklen() {
	  int ret=1;
	  ret = 8;
	  if NEED_BUFF {
	    ret = 8*npcol;
	  }
	  return ret;
}

void  pdpttrs_ninf(	 int n,
		 int nrhs,
		 double global_d[],
		 double global_e[],
		 double global_b[],
		 int ldb,
		 int *info
)
/* "pdpttrs solves a system of linear equations A * X = B where A is the matrix used to produce the factors stored in A and AF by PSPTTRF." */
/* OPTIONS */
{
extern void FortranCall(pdpttrs)( int*, int*,
                               double*, double*, int*, int*,
                               double*, int*, int*,
                               double*, int*,
                               double*, int*,
				 int*);

	int maxldd;

	double *locd=NULL;
	double *loce=NULL;
	int desctdd[DESCLEN];
	int desc_gtdd[DESCLEN];

	int maxldb;
	double *locb=NULL;
	int descb[DESCLEN];
	int desc_gb[DESCLEN];

	int row_locb,col_locb;

	double *locaf=NULL;
	int laf;

	double *locwork=NULL;
	int llocwork;


	INITIALIZE();

	SCALAR( "int", n);
	SCALAR( "int", nrhs);
	SCALAR("int", ldb);
	SIZE(n);

	ROW(b);
	COL(b);
	MAXLDD( maxldd, b );
	maxldb = maxldd;

	tdMATRIX( "double", e, d, e, n);
        tdDISTRIBUTE( "double", e, d, e, n);
	MATRIX( "double", b, ROW_b, COL_b);
	DISTRIBUTE("double", b, ROW_b, COL_b);

	laf=blocsize+2;
	locaf = MALLOC(sizeof(double)*laf);
        assert(locaf);
        
	llocwork = worklen();
	WORK(locwork, llocwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pdpttrs)( &n, &nrhs,
                               locd, loce, &one, desctdd,
                               locb, &one, descb,
                               locaf, &laf,
                               locwork, &llocwork,
                               &linfo);

	tdGATHER("double", e, d, e, n);
	GATHER( "double", b, ROW_b, COL_b);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
		*info = linfo;
	} else {
	}
	FREE_MATRIX(d);
	FREE_MATRIX(e);
	FREE_MATRIX(b);
	FREE(locaf);
        FREE(locwork);
	
}

