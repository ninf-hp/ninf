#define _WRAPPER_
/* $Id: pdstebz_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define DOUBLE
#include <gscalapack.h>

static  int worklen(int n){
    int ret=1;
    ret = MAX( 5*n, 7 );
    return ret;
}

static  int iworklen(int n){
      int ret = 1;
      ret = MAX( 4*n, 14 );
    return ret;
}

void  pdstebz_ninf(	 char range,
		 char order,
		 int n,
		 double vl,
		 double vu,
		 int il,
		 int iu,
		 double abstol,
		 double d[],
		 double e[],
		 int *m,
		 int *nsplit,
		 double w[],
		 int iblock[],
		 int isplit[],
		 double work[],
		 int iwork[],
		 int *info
)
/* "pdstebz computes the eigenvalues of a symmetric tridiagonal matrix in parallel. The user may ask for all eigenvalues, all eigenvalues in the interval [VL, VU], or the eigenvalues indexed IL through IU. " */
/* OPTIONS */
{

  int maxldd;

  int locm[1];
  int locnsplit[1];
  
  double *locw=NULL;
  int *lociblock=NULL;
  int *locisplit=NULL;
  
  double *locwork=NULL;
  int llocwork;
  int *lociwork=NULL;
  int llociwork;


  INITIALIZE();

  SCALAR( "char", range);
  SCALAR( "char", order);
  SCALAR( "int", n);
  SCALAR( "double", vl);
  SCALAR( "double", vu);
  SCALAR( "int", il);
  SCALAR( "int", iu);
  SCALAR( "double", abstol);

  /* MATRIX <- d,e */

  COMMON( "double", d, n);
  COMMON( "double", e, n-1);

  locw = MALLOC(sizeof(double)*n); assert(locw);
  lociblock = MALLOC(sizeof(int)*n); assert(lociblock);
  locisplit = MALLOC(sizeof(int)*n); assert(locisplit);
  
  llocwork=worklen(n);
  WORK(locwork,llocwork);
  llociwork=iworklen(n);
  IWORK(lociwork, llociwork);
  
  if  (( mypnum != 0 ) ^ (serial==1) )
    FortranCall(pdstebz)( &PARA_CTXT, &range, &order, &n,
			  &vl, &vu, &il, &iu, &abstol,
			  d, e,
			  locm, locnsplit,
			  locw, lociblock, locisplit,
			  locwork, &llocwork,
			  lociwork, &llociwork,
			  &linfo);

  RETRIEVE("double", locw, n);
  RETRIEVE("int", locm, 1);
  RETRIEVE("int", locnsplit, 1);
  RETRIEVE("int", lociblock, n);
  RETRIEVE("int", locisplit, n);
  RETRIEVE("int", &linfo, 1);

  if( mypnum == 0 ){
    int i;
    *info = linfo;
    *m = *locm;
    *nsplit = *locnsplit;
    for(i=0;i<n;i++) w[i] = locw[i];
    for(i=0;i<n;i++)  iblock[i] = lociblock[i];
    for(i=0;i<n;i++)  isplit[i] = locisplit[i];
  } else {
  }
  
  FREE_COMMON(d);
  FREE_COMMON(e);
  
  FREE(locw);
  FREE(lociblock);
  FREE(locisplit);
  
}

void  pdlaebz_ninf(	 int ijob,
		 int n,
		 int mmax,
		 int minp,
		 double abstol,
		 double reltol,
		 double pivmin,
		 double d[],
		 int nval[],
		 double intvl[],
		 int intvlct[],
		 int *mout,
		 double *lsave,
		 int ieflag,
		 int *info
)
/* "pdlaebz contains the iteration loop which computes the eigenvalues contained in the input intervals [ INTVL(2*j-1), INTVL(2*j) ] where j = 1,...,MINP. It uses and computes the function N(w), which is the count of eigenvalues of a symmetric tridiagonal matrix less than or equal to its argument w." */
/* OPTIONS */
{


  INITIALIZE();

  SCALAR("int",ijob);
  SCALAR("int",n);
  SCALAR("int",mmax);
  SCALAR("int",minp);
  SCALAR("double",abstol);
  SCALAR("double",reltol);
  SCALAR("double",pivmin);
  SCALAR("int",ieflag);


  COMMON( "double", d, 2*n-1);
  COMMON( "int", nval, 4);
  COMMON( "int", intvl, 2*mmax);
  COMMON( "int", intvlct, 2*mmax);
  COMMON("int", mout, 1);
  COMMON("double", lsave, 1);

  if  (( mypnum != 0 ) ^ (serial==1) )
    FortranCall(pdlaebz)( &ijob, &n, &mmax, &minp, &abstol, &reltol, &pivmin, d, nval, intvl, intvlct, mout, lsave, &ieflag, &linfo);

  RETRIEVE("int", nval, 4);
  RETRIEVE( "int", intvl, 2*mmax);
  RETRIEVE( "int", intvlct, 2*mmax);
  RETRIEVE("int", mout, 1);
  RETRIEVE( "double", lsave, 1);
  RETRIEVE("int", &linfo, 1);

  if( mypnum == 0 ){
    *info = linfo;
  } else {
  }

    FREE_COMMON(lsave);
    FREE_COMMON(mout);
    FREE_COMMON(d);
    FREE_COMMON(intvl);
    FREE_COMMON(intvlct);
  
}


void  pdlaecv_ninf(	 int ijob,
		 int *kf,
		 int kl,
		 double intvl[],
		 int intvlct[],
		 int nval[],
		 double abstol,
		 double reltol
)
/* "pdlaecv checks if the input intervals [ INTVL(2*i-1), INTVL(2*i) ], i = KF, ... , KL-1, have 'converged'. pdlaecv modifies KF to be the index of the last converged interval, i.e., on output, all intervals [ INTVL(2*i-1), INTVL(2*i) ], i < KF,  have converged. Note that the input intervals may be reordered by pdlaecv." */
/* OPTIONS */
{
	int maxldd;
	int oldkf;

	INITIALIZE();

	SCALAR("int",ijob);


	SCALAR("int",kl);
	SCALAR("double",abstol);
	SCALAR("double",reltol);

	COMMON("int",kf,1);
	COMMON( "int", intvl, 2*(kl-*kf));
	COMMON( "int", intvlct, 2*(kl-*kf));
	COMMON( "int", nval, 2*(kl-*kf));
	oldkf = *kf;

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pdlaecv)( &ijob, kf, &kl, intvl, intvlct, nval, &abstol, &reltol);

	RETRIEVE( "int", intvl, 2*(kl-oldkf));
	RETRIEVE( "int", intvlct, 2*(kl-oldkf));
	RETRIEVE( "int", nval, 2*(kl-oldkf));

	if( mypnum == 0 ){
	} else {
	}
	FREE_COMMON(kf);
	FREE_COMMON(intvl);
	FREE_COMMON(intvlct);
	FREE_COMMON(nval);
}



void  pdlapdct_ninf(	 double sigma,
		 int n,
		 double d[],
		 double pivmin,
		 int *count
)
/* "pdlapdct counts the number of negative eigenvalues of (T - SIGMA I). This implementation of the Sturm Sequence loop has conditionals in the innermost loop to avoid overflow and determine the sign of a doubleing point number. " */
/* OPTIONS */
{


	INITIALIZE();

	SCALAR("double",sigma);
	SCALAR("int",n);
	SCALAR("double",pivmin);
	
	COMMON( "double", d, 2*n-1);
	COMMON("int", count, 1);

	if  (( mypnum != 0 ) ^ (serial==1) )
		FortranCall(pdlapdct)( &sigma, &n, d, &pivmin, count);

	
	RETRIEVE("int", count, 1);

	if( mypnum == 0 ){
	} else {

	}
	FREE_COMMON(d);
	FREE_COMMON(count);
	
}
