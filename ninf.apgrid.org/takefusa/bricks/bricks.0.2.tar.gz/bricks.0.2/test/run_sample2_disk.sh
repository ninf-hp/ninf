echo "java -classpath ~/src/bricks/dist/bricks.jar bricks.Simulate -times 10 -server_log -network_log -disk_log -network_monitoring_log -server_monitoring_log -prefix sample2_disk sample2_disk.conf"
java -classpath ~/src/bricks/dist/bricks.jar bricks.Simulate -times 10 -server_log -network_log -disk_log -network_monitoring_log -server_monitoring_log -prefix sample2_disk sample2_disk.conf

