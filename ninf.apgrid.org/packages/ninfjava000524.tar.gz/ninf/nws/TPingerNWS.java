package ninf.nws;
import ninf.basic.*;
import ninf.common.*;
import ninf.client.*;
import ninf.cproxy.*;
import nws.api.*;

import java.io.PrintStream;
import java.net.*;

public class TPingerNWS implements TPinger{
  private static final String BANDWIDTHEXP = "bw.exp.rich";

  int interval;               /* interval in second */
  int size;                   /* size in byte */
  int minimumSize, maximumSize;
  int psize;
  NinfServerStructComm target;
  double throughput;
  static NinfLog dbg = new NinfLog("TPingerNWS");
  double measureTime;
  PrintStream throughputLogStream;
  NWSClient forecaster;
  ExperimentSpec experimentT = new ExperimentSpec();
  ExperimentSpec experimentL = new ExperimentSpec();

  public TPinger setup(NinfServerStructComm target, int interval, int size){
    setup(target, interval, size, 100, 100000, 1.0, null);
    return this;
  }     

  public TPinger setup(NinfServerStructComm target, int interval, 
	  int size, int minimumSize, int maximumSize, 
	  double measureTime, PrintStream throughputLogStream){
    this.target = target;
    this.interval = interval;
    this.size = size;
    this.minimumSize = minimumSize;
    this.maximumSize = maximumSize;
    this.measureTime = measureTime;
    if (throughputLogStream != null)
      this.throughputLogStream = throughputLogStream;
    else 
      this.throughputLogStream = System.out;
    HostSpec forecasterSpec  = new HostSpec(CProxy.conf.myhostname,
					    ConfigSite.DEFAULTFOREPORT);
    try {
      forecaster = new NWSClient();
      forecaster.setForecaster(forecasterSpec);
      HostSpec nsSpec 
	  = forecaster.getNameServer(new HostCookie(forecasterSpec));
      forecaster.setNameServer(nsSpec);
    } catch (NWSException e){
      dbg.println("Unable to determine NWS name server, using default\n");
      try {
	forecaster.useDefaultNameServer();
      } catch (NWSException e2){
	dbg.log("couldn't set NWSname server");
      } 
    }
    experimentT.experimentName = ExperimentSpec.DEFAULT_BANDWIDTH_EXPERIMENT;
    experimentT.sourceMachine = CProxy.conf.myhostname;
    experimentT.destinationMachine = target.host;

    experimentL.experimentName = ExperimentSpec.DEFAULT_LATENCY_EXPERIMENT;
    experimentL.sourceMachine = CProxy.conf.myhostname;
    experimentL.destinationMachine = target.host;

    setupClique();

    return this;
  }

  /** encode IPaddress based on 64 */
  private final String encodeIP64(byte bytes[]){
    StringBuffer buf = new StringBuffer("");
    long tmp = 0;
    for (int i = 0; i < bytes.length; i++)
      tmp = tmp * 256 + bytes[i];
    System.out.println(FormatString.format("%x", new Long(tmp)));
    
    for (int i = 0; i < 6; i++){
      buf.append((char)((tmp & 0x3f) + '0'));
      tmp = tmp >> 6;
    }
    return buf.toString();
  }

  /** decode IPaddress based on 64 */  
  private byte[] decodeIP64(String str){
    int tmp = 0;
    for (int i = str.length() - 1; i >= 0; i--){
      tmp = (tmp << 6) + (str.charAt(i) - '0') ;
    }
    System.out.println(FormatString.format("%x", new Long(tmp)));    

    byte ans[] = new byte[4];
    for (int i = 4 -1 ; i >= 0; i--){
      ans[i] = (byte)(tmp & 0xff);
      tmp = tmp >> 8;
    }
    return ans;
  }

  private static int name_counter = 0;

  private String getCliqueName(String hostA, String hostB){
    try {
      InetAddress a = InetAddress.getByName(hostA);
      InetAddress b = InetAddress.getByName(hostB);
      return "n_" + encodeIP64(a.getAddress()) + "-" 
	+ encodeIP64(b.getAddress());
    } catch (UnknownHostException e){
      dbg.log("failed to create encoded filename");
      return hostB + name_counter;
    }
  }

  private void setupClique(){
    HostSpec sensorSpec  = new HostSpec(CProxy.conf.myhostname,
					ConfigSite.DEFAULTSENSORPORT);
    HostSpec targetSpec  = new HostSpec(target.host,
					ConfigSite.DEFAULTSENSORPORT);
    SensorControlClient sensorControl = new SensorControlClient(sensorSpec);
    CliqueDesc[] cliques = new CliqueDesc[1];
    CliqueDesc clique = new CliqueDesc();
    cliques[0] = clique;

    try {
	clique.clique_name = getCliqueName(CProxy.conf.myhostname, 
					   target.host);
	clique.period      = interval;
	clique.clique_timeout = 2.5 * interval;
	clique.exp_tag     = BANDWIDTHEXP;;
	clique.addHost(sensorSpec);
	clique.addHost(targetSpec);

	dbg.println("seting up clique: " + clique.clique_name);
	sensorControl.doInitCliques(cliques, 1);

    } catch (NWSException e) {
      e.printStackTrace();
      dbg.log("Cannot setup the clique. start Native TPinger.");
      startNative();
    }
  }

  private void startNative(){
    (new Thread
     ((new TPingerNative()).
      setup(target, interval, size, minimumSize,
	   maximumSize, measureTime, throughputLogStream))).start();
  }

  boolean ping(){
    try {
      ForecastCollection[] forecasts = 
	  forecaster.getForecasts(experimentT, 1);
      if (forecasts == null)
	throw new NWSException("canot get forecast");
	
      double mbs = forecasts[0].forecasts[0].forecast;
      double rtt = ((double)size / (mbs * 1024.0 * 1024.0 / 8.0) );
      target.throughput = new CommunicationInformation(rtt, size, 0);

      ForecastCollection[] forecasts2 = 
	  forecaster.getForecasts(experimentL, 1);
      if (forecasts2 == null)
	throw new NWSException("canot get forecast");

      rtt = (forecasts[0].forecasts[0].forecast);
      target.latency = new CommunicationInformation(rtt, 0, 0);

      throughput = target.throughput.throughput;
      psize = size;

      dbg.println("throughput detect using NWS: " + 
		  target.throughput.throughput);
    
      if (throughputLogStream != null)
	throughputLogStream.println(FormatString.format(
	    "%.2lf %30s %11.2lf", 
	    new Double(System.currentTimeMillis() / 1000.0),
	    target, 
	    new Double(target.throughput.throughput)));
    } catch (NWSException e) {
      e.printStackTrace();	
      dbg.log("nws exception caught. start Native TPinger.");
      startNative();
      return false;
    }
    return true;
  }

  public void run(){
    while (ping()){
      //      System.out.println("Throughput to " + target + ": " 
      //	  + throughput + "[byte/sec] at size = " + psize);
      try {
	Thread.sleep(interval * 1000);
      } catch (InterruptedException e){
      }
    }
  }

  public void start(){
    new Thread(this).start();
  }

  public static void main(String args[]){
    NinfLog.verbose();
    //    NinfLog.log();
    NinfServerStructComm tmp = 
      new NinfServerStructComm(args[0], new Integer(args[1]).intValue());
					
    new Thread(new TPingerNWS().setup(tmp, 5, 
			   new Integer(args[2]).intValue(),
			   new Integer(args[2]).intValue(),
			   new Integer(args[2]).intValue(),
			   new Double (args[3]).doubleValue(),
			   null)).start();
  }
}
