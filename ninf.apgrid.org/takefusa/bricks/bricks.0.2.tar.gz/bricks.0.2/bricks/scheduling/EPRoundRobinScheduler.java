package bricks.scheduling;
import bricks.util.*;
import bricks.environment.*;
import java.util.*;

/**
 * EPRoundRobinScheduler is a round robin scheduler for EP programs.<BR>
 * Usage:<BR>
 * EPRoundRobinScheduler(String keyOfMetaPredictor(, int index))
 **/
public class EPRoundRobinScheduler extends RoundRobinScheduler {

    public EPRoundRobinScheduler(String keyOfMetaPredictor, int index) {
	super(keyOfMetaPredictor, index);
    }

    public EPRoundRobinScheduler(String keyOfMetaPredictor) {
	super(keyOfMetaPredictor);
    }

/************************* needed method *************************/
    public String getName() {
	return "EPRoundRobinScheduler";
    }

    // first
    public void selectHosts (
	double currentTime, Host source, RequestedData data
    ) throws BricksNotScheduledException {

	SimulationDebug.println("EPRoundRobinScheduler.selectHosts");
	if (!(data instanceof EPRequestedData)) {
	    super.selectHosts(currentTime, source, data);
	    return;
	}

	EPRequestedData epdata = (EPRequestedData)data;
	boolean schedule = false;

	if (epdata.first) { /* first time */
	    //System.out.println("first time: " + epdata);
	    schedule = allocateTasksToAllHosts(currentTime, epdata);
	    if (!schedule)
		throw new BricksNotScheduledException(this.toString());
	} else { /* not first time */
	    System.err.println("Host calls this method at first time only");
	    System.exit(3);
	}
    }

    // second or more
    public void selectHosts (
	double currentTime, Host source, EPRequestedData epdata, EPTask eptask
    ) throws BricksNotScheduledException {
	System.err.println(getName() + ": This method is never called.");
	System.exit(3);
    }

    protected boolean allocateTasksToAllHosts(
	double currentTime, EPRequestedData epdata
    ) {
	hosts = resourceDB.getHostList();
	if (hosts.size() == 0)
	    return false;

	EPTask task = epdata.getNextTask();
	while (task != null) {
	    Enumeration e = hosts.elements();
	    while (e.hasMoreElements()) {
		Host host = (Host)e.nextElement();
		task.allocateHost(host);
		task = epdata.getNextTask();
		if (task == null)
		    break;
	    }
	}			
	return true;
    }
}
