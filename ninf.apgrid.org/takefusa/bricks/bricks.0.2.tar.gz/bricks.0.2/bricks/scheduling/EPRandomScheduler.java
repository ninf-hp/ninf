package bricks.scheduling;
import bricks.util.*;
import bricks.environment.*;
import java.util.*;

/**
 * EPRandomScheduler is a random allocation scheduler for EP programs.<BR>
 * Usage:<BR>
 * EPRandomScheduler(String keyOfMetaPredictor, Long seed, double interval)
 **/
public class EPRandomScheduler extends RandomScheduler {

    protected double interval;

    public EPRandomScheduler(
	String keyOfMetaPredictor, long seed, double interval
    ) {
	super(keyOfMetaPredictor, seed);
	this.interval = interval;
    }

/************************* needed method *************************/
    public String getName() {
	return "EPRandomScheduler";
    }

    // first
    public void selectHosts (
	double currentTime, Host source, RequestedData data
    ) throws BricksNotScheduledException {

	if (!(data instanceof EPRequestedData)) {
	    super.selectHosts(currentTime, source, data);
	    return;
	}
	EPRequestedData epdata = (EPRequestedData)data;

	boolean schedule = false;
	SimulationDebug.println("EPRandomScheduler.selectHosts");
	hosts = resourceDB.getHostList();

	Host host = nextHost();
	while (host != null) {
	    EPTask task = epdata.getNextTask();
	    task.allocateHost(host);
	    schedule = true;
	    host = nextHost();
	    SimulationDebug.println("allocate task: " + task);
	}

	if (schedule) { /* schedule successed */
	    updateStatus(currentTime, epdata);
	} else { /* schedule failed */
	    updateStatus(epdata, interval);
	    throw new BricksNotScheduledException(this.toString());
	}
    }

    // second or more
    public void selectHosts (
	double currentTime, Host source, EPRequestedData epdata, EPTask eptask
    ) throws BricksNotScheduledException {
	boolean schedule = false;
	hosts = resourceDB.getHostList();

	Host host = nextHost();
	if (host != null) {
	    EPTask task = epdata.getNextTask();
	    task.allocateHost(host);
	    schedule = true;
	}

	if (schedule) { /* schedule successed */
	    updateStatus(currentTime, epdata);
	} else { /* schedule failed */
	    updateStatus(epdata, interval);
	    throw new BricksNotScheduledException(this.toString());
	}
    }

    protected Host nextHost() {
	//System.out.println("***** hosts.size = " + hosts.size());
	if (hosts.size() == 0)
	    return null;
	Host host = (Host)hosts.elementAt(
	    Math.abs(random.nextInt()) % hosts.size()
	);
	hosts.removeElement(host);
	return host;
    }
}

