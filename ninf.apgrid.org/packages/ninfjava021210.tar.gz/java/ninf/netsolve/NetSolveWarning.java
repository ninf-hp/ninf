package ninf.netsolve;
// import java.io.*;
// import java.awt.*;

public class NetSolveWarning{

  /*   private Button  ok_button;
  private Frame   parent; */
  public int cur_lang = Labels.language; 


  public NetSolveWarning(int dummy,String message) {
    System.out.println("NetSolveWarinig: " + message);
  }

  /*  public NetSolveWarning(Frame f,String message) { 
    super();
    super.setTitle(Labels.warning_title[cur_lang]);
    parent = f;
    parent.disable();
    this.setLayout(new BorderLayout(5,5));
    this.setBackground(new Color(50,200,240));

    Panel p1 = new Panel();
    p1.setLayout(new FlowLayout(FlowLayout.CENTER,15,15));
    Label label = new Label(message);
    label.setFont(new Font("Courier",Font.BOLD,18));
    p1.add(label);

    ok_button = new Button("OK");
    ok_button.setFont(new Font("TimesRoman",Font.BOLD,20));
    Panel p2 = new Panel();
    p2.setLayout(new FlowLayout(FlowLayout.CENTER,15,15));
    p2.add(ok_button);

    this.add("Center",p1);
    this.add("South",p2);
    this.show();
    this.pack();
    
  } 


  public boolean action(Event e, Object arg) {
 
   if (e.target == ok_button) {
     this.hide();
     this.dispose(); 
     parent.enable();
   }
   return true;
  } */ // action




} // End class NetSolveWarning
