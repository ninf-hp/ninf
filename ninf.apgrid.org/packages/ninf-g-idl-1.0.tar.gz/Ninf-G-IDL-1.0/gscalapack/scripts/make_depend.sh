#! /bin/sh
# $Id: make_depend.sh,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $

if [ -f .dep ] ; then
    exit 0
fi

cat Makefile.in > Makefile

for f in p*.idl [^p]*.idl ; do
    LIBSELECT=
    WRAPPER=
    if [ x"`basename ${f} | grep '^p.*idl'`" != x"" ] ; then
	LIBSELECT=lib
	WRAPPER=wrapper/"`basename ${f} |sed -e 's!\.idl$!!'`"_ninf.c
    fi

    f=`basename $f`
    head=`echo $f|sed -e 's!\.idl$!!'`
    cat >> Makefile <<EOF
${head}: .${head}
.${head}: ${LIBSELECT} ${WRAPPER} $f
	\$(MAKE_STUB)

EOF
done

touch .dep
