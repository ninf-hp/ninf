#include <string.h>
#include <stdlib.h>

#define _LOCAL_
#include <fftw.h>
#include <gfftw.h>

extern void alloc_tmpbuffer( int rank, const int *pn, int flags,
                             fftw_complex **ptmp_in, int is, 
                             fftw_complex **ptmp_out, int os );

/* load and reproduce a previous plan */
void* rloadplan( char const *plan, MEASURE measure) {
    int rank, pn[MAXDIM], dir, flags;
    int is, os;
    fftw_complex *tmp_in, *tmp_out;
    void* ret=(void*)0;

    if ( loadplan_opts( plan, &rank, pn, &dir, &flags, &is, &os, measure) !=0 )
    {
/*        *plan = '\0'; */
        return (void*)0;
    }

    /* NULL arrays are used for ESTIMATE */
    tmp_in = tmp_out = (fftw_complex*)0;

    /* But if (flags & MEASURE), allocate tmps */
    alloc_tmpbuffer( 1, pn, flags, &tmp_in, is, &tmp_out, os);

    ret = rfftw_create_plan_specific( pn[0], dir, flags | FFTW_USE_WISDOM,
                                      tmp_in,  is,
                                      tmp_out, os);

    free_tmpbuffer( tmp_in, tmp_out);
    
    return ret;
} /* end of rloadplan */


/* load and reproduce a previous plan for N-dim */
void* rloadplannd( char const *plan, MEASURE measure) {
    int rank, pn[MAXDIM], flags;
    int dir;
    int is, os;
    fftw_complex *tmp_in, *tmp_out;
    void* ret=(void*)0;

    if ( loadplan_opts( plan, &rank, pn, &dir, &flags, &is, &os, measure)<0 ) {
        return (void*)0;
    }

    /* NULL arrays are used for ESTIMATE */
    tmp_in = tmp_out = (fftw_complex*)0;

    /* But if (flags & MEASURE), allocate tmps */
    alloc_tmpbuffer( rank, pn, flags, &tmp_in, is, &tmp_out, os);

    ret = rfftwnd_create_plan_specific( rank, pn, dir,
                                        flags | FFTW_USE_WISDOM,
                                        tmp_in, is,
                                        tmp_out, os);

    free_tmpbuffer(tmp_in,tmp_out);
    return ret;
} /* end of loadplannd */

