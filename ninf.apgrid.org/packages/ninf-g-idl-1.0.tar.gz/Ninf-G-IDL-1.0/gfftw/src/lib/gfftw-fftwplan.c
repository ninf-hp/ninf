#include <string.h>
#include <stdlib.h>

#define _LOCAL_
#include <fftw.h>
#include <gfftw.h>

#ifdef HAVE_NO_STRNCMP
int strncmp( const char *s1, const char *s2, size_t n) {
    int i=0;
    if(n<=0) {
	return -1;
    }
    while(i<n) {
	if ( *(s1+i) != *(s2+i) ) {
	    return (int)(*(s1+i) - *(s2+i));
	}
	i++;
    }
    return 0;
}
#endif

/* n, dir and flags are loaded from string '_plan_' */
int loadplan_opts( char const *plan,
		   int *prank,
		   int *pn,
		   int *pdir,
		   int *pflags,
		   int *pis,
		   int *pos,
		   MEASURE measure
    )
{
    int error=ERROR_OK;
    /* stac */
    static char plan0[PLANLEN]="\0";
    static int len0=1;
    static int rank0=1;
    static int pn0[MAXDIM]={1,0};
    static int dir0=-1;
    static int flags0=0;
    static int is0=1;
    static int os0=1;

    if ((strncmp(plan,plan0,len0)==0)&&(plan[0]!='\0')) {
	int i;

	*prank = rank0;
	for(i=0;i<min(rank0,MAXDIM);i++) pn[i] = pn0[i];
	*pdir = dir0;
	*pflags = flags0;
	*pflags = *pflags & ~FFTW_MEASURE | FFTW_ESTIMATE;
	*pis = is0; *pos = os0;
        
        return ERROR_OK;
    }

    if (plan[0]=='\0') {
	*prank = 1;
	*pn = 1;
	*pdir = -1;
	*pflags = 0;
	*pis = 1;  *pos = 1;
        return ERROR_ILLEGAL;
    }

    if ((error = 
	 pops_opts( plan, prank, pn, pdir, pflags, pis, pos) )
	!= 0) {
	*prank = 1;
	*pn = 1;
	*pdir = -1;
	*pflags = 0;
	*pis = 1;  *pos = 1;

	return error;
    }

    else {
	int i;

	if (measure & FORCE_FLAG == 0) 
	    *pflags = *pflags & ~FFTW_MEASURE | FFTW_ESTIMATE;

	error = fftw_import_wisdom_from_string(plan);

	/* save stacs */
	for( len0=0; len0<PLANLEN&&plan[len0]!='\0'; len0++) {
	    plan0[len0] = plan[len0];
	}
	rank0 = *prank;
	for( i=0; i<min(*prank,MAXDIM); i++) pn0[i] = pn[i];
	dir0 = *pdir;
	flags0 = *pflags;
	is0 = *pis; os0 = *pos;

        return ERROR_OK;
    }

    return ERROR_INVALID; /* don't reach */
} /* end of loadplan_opts */


int work_size( int rank, const int *pn, int stride, int flags, int ncopies) {
    extern int fftwnd_work_size(int,const int*, int, int);
    int ret=1;

    if (rank<=0) return ret;
    if (rank==1) ret = pn[0]*stride;
    else {
	int i;
	ret = 1;
	for(i=0;i<rank;i++) ret *= pn[i]*stride;
    }
    return ret;
} /* end of work_size */

void alloc_tmpbuffer( int rank, const int *pn, int flags,
		      fftw_complex **ptmp_in, int is, 
		      fftw_complex **ptmp_out, int os )
{
    if (flags & FFTW_MEASURE ) { 
	int nbuffers;
	/* if (measure & FORCE_FLAG) and then, if (flags & FFTW_MEASURE) */
#define FFTWND_NBUFFERS 8
#define FFTWND_DEFAULT_NBUFFERS 0
	if (flags & FFTWND_FORCE_BUFFERED) nbuffers = FFTWND_NBUFFERS;
	else nbuffers = FFTWND_DEFAULT_NBUFFERS;

	*ptmp_in = MALLOC(sizeof(fftw_complex)*
			  work_size( rank, pn, is, flags, nbuffers+1));
	if (!(flags & FFTW_IN_PLACE))
	    *ptmp_out =	MALLOC( sizeof(fftw_complex)*
				work_size( rank, pn, os, flags, nbuffers+1));
    }

} /* end of alloc_tmpbuffer */

void free_tmpbuffer( fftw_complex *tmp_in, fftw_complex *tmp_out) {
    if (tmp_in) free(tmp_in);
    if (tmp_out) free(tmp_out);
}


/* load and reproduce a previous plan */
void* loadplan( char const *plan, MEASURE measure) {
    int rank, pn[MAXDIM], dir, flags;
    int is, os;
    fftw_complex *tmp_in, *tmp_out;
    void* ret=(void*)0;

    if (loadplan_opts( plan, &rank, pn, &dir, &flags, &is, &os, measure)!=0) {
/*        *plan = '\0'; */
        return (void*)0;
    }

    /* NULL arrays are used for ESTIMATE */
    tmp_in = tmp_out = (fftw_complex*)0;

    /* But if (flags & MEASURE), allocate tmps */
    alloc_tmpbuffer( 1, pn, flags, &tmp_in, is, &tmp_out, os);

    ret = fftw_create_plan_specific( pn[0], dir, flags | FFTW_USE_WISDOM,
				       tmp_in,  is,
				       tmp_out, os);

    free_tmpbuffer( tmp_in, tmp_out);
    
    return ret;
} /* end of loadplan */


/* load and reproduce a previous plan for N-dim */
void* loadplannd( char const *plan, MEASURE measure) {
    int rank, pn[MAXDIM], flags;
    int dir;
    int is, os;
    fftw_complex *tmp_in, *tmp_out;
    void* ret=(void*)0;

    if (loadplan_opts( plan, &rank, pn, &dir, &flags, &is, &os, measure)<0) return (void*)0;

    /* NULL arrays are used for ESTIMATE */
    tmp_in = tmp_out = (fftw_complex*)0;

    /* But if (flags & MEASURE), allocate tmps */
    alloc_tmpbuffer( rank, pn, flags, &tmp_in, is, &tmp_out, os);

    ret = fftwnd_create_plan_specific( rank, pn, dir,
					 flags | FFTW_USE_WISDOM,
					 tmp_in, is,
					 tmp_out, os);

    free_tmpbuffer(tmp_in,tmp_out);
    return ret;
} /* end of loadplannd */



void saveplannd( char *plan,
		 int rank,
		 int *pn,
		 int dir,
		 int flags,
		 int is,
		 int os
    )
{
    /* save a present plan, rank, n, dir and flags
     * as string using wisdom */
    char *wisdom;

    wisdom = fftw_export_wisdom_to_string();
    strncpy( plan, wisdom, PLANLEN);

    pushs_opts( plan, rank, pn, dir, flags, is, os);
} /* end of saveplannd */


void saveplan(char *plan, int n, int dir, int flags, int is, int os ) {
    saveplannd( plan, 1, &n, dir, flags, is, os);
} /* end of saveplan */


#define LENDBL 12
#define NOPTS  5
void pushs_opts( char *s, int rank, int *pn, int dir, int flags, int is, int os) {

    char *str;
    int i;
    int len;
    for( len=0; len<PLANLEN && *(s+len) != '\0' ; len++) ;
    str = s+len; 

    if (len>PLANLEN-rank*LENDBL-LENDBL*NOPTS ) {
	strcpy( s, ERROR_BUFFEROVER);
	return;
    }

    str+=sprintf( str, " (Ninf is=%d os=%d flag=%d dir=%d rank=%d size=", is, os, flags, dir, rank);
    for( i=0 ; i<rank&&i<MAXDIM ; i++) {
        str+=sprintf( str, " %d", pn[i]);
    }
    str+=sprintf( str, ")\0");

    for( len=0; len<PLANLEN+2 && *(s+len) != '\0' ; len++) ;

    if (len>PLANLEN) {
	strcpy( s, ERROR_BUFFEROVER);
	return;
    }

} /* end of pushs_opts */

  
#define CHARLEN 32
int pops_opts( char const *s, int *prank, int *pn, int *pdir, int *pflags, int *pis, int *pos) {

    char c[CHARLEN];
    char const *p;
    int i;
    int read;
    int len;

    for( len=0; len<PLANLEN && *(s+len) != '\0' ; len++) ;
    if (len<5) return ERROR_INVALID;
    read = 0;
    for(p=s;p<s+len;p+=read) {
	sscanf( p, "%10s %n", c, &read);
	if(strcmp(c,"(Ninf")==0) break;
    }
    if (p>=s+len) return ERROR_INVALID;
    sscanf( p+=read, "is=%d %n", pis, &read);
    sscanf( p+=read, "os=%d %n", pos, &read);
    sscanf( p+=read, "flag=%d %n", pflags, &read);
    sscanf( p+=read, "dir=%d %n", pdir, &read);
    sscanf( p+=read, "rank=%d %n", prank, &read);
    if (p>=s+len) return ERROR_INVALID;
    sscanf( p+=read, "size= %n", &read);
    for(i=0;i<*prank&&i<MAXDIM;i++) {
	if (p>s+len) return ERROR_INVALID;
	sscanf( p+=read, " %d%n", pn+i,&read);
    }
    return ERROR_OK;
} /* end of pops_opts */
