package ninf.scheduler;
import ninf.metaserver.*;
import ninf.common.*;
import ninf.basic.*;
import ninf.client.*;
import java.util.Vector;

public class RoundRobinScheduler extends Scheduler {
  static NinfLog dbg = new NinfLog("RoundRobinScheduler");
  int counter = 0;

  public ScheduleResult schedule(CallInformation info, ServerIndex serverIndexes[],
    SchedulerRoot schedulerRoot, ServerID cproxy, StringBuffer sb)
  throws NinfException{
    dbg.println(info);
    for (int i = 0; i < serverIndexes.length; i++){
      dbg.println(serverIndexes[i]);
    }
    if (serverIndexes.length == 0)
      return null;

    int n = (counter++) % serverIndexes.length;
    dbg.println("select " + n + " th Server");
    return new ScheduleResult(setupInfo(schedulerRoot, cproxy, serverIndexes[n]), 
			      null);
  }
}
