package bricks.util;
import bricks.scheduling.ResourceDB;
import bricks.environment.DataFragment;
import java.util.*;

public class RandomDataFragmentStrings extends Strings implements SubComponent {

    protected Random random;
    protected Vector fragments;
    protected ResourceDB resourceDB;
    protected String keyOfResourceDB;

    public RandomDataFragmentStrings(long seed, String keyOfResourceDB) {
	this.random = new Random(seed);
	this.keyOfResourceDB = keyOfResourceDB;
    }

    public String getName() {
	return "RandomDataFragmentStrings";
    }

    public void init(SimulationSet owner) {
	resourceDB = owner.getResourceDB(keyOfResourceDB);
    }

    public String nextString(double size) {
	fragments = resourceDB.getFragments(size);
	SimulationDebug.println(fragments);
	int index = (int)(Math.abs(random.nextInt()) % fragments.size());
	DataFragment fragment = (DataFragment)fragments.elementAt(index);
	SimulationDebug.println("requiredDataID = " + fragment.id);
	return fragment.id;
    }

    public String nextString() {
	System.err.println(
	    "The " + this + " class has to be specified for Client's dataIDs."
	);
	System.exit(3);
	return null;
    }
}
