#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <netdb.h>
#include <unistd.h>
#include <sys/types.h>
#include <pwd.h>
#define ERROR_MAIN
char * program_context = "TUNNEL";


#include "ninf_data_trans.h"
#include "ninf_macros.h"
#include "ninf_error.h"

int connect_remote_privileged(char * hostname, char * service);
void forword(int s1, int s2);
int  authenticate(int s1, int s2);
/*  arguments
1 = connectted descripter
2 = target host 
3 = target service  */

main (int argc, char ** argv){
  int s;
  int cs;

  if (argc != 4){
    fprintf(stderr, "%s, argument length must be 4, %d\n",  argv[0], argc);
    
    exit(3);
  }
  
  s = connect_remote_privileged(argv[2], argv[3]);
  if (s < 0)
    exit(3);

  cs = atoi(argv[1]);
  if (authenticate(cs, s))
    forword(cs, s);
}

int connect_remote_privileged(char * hostname, char * service)
{
  int s,size;
  int initial_port = 1023;
  struct sockaddr_in peer;
  struct hostent *hp;
  struct servent *sp;

  if (hostname != NULL){
    hp = gethostbyname(hostname);
    if (hp == NULL){
      fprintf(stderr, "%s: unknown hostname\n", hostname);
      return -1;
    }
#if defined(__j90__) || defined(__t3e__)
    memcpy(&peer.sin_addr.s_da,hp->h_addr,hp->h_length);
#else
    memcpy((char *)(&peer.sin_addr.s_addr),hp->h_addr,hp->h_length);
#endif 

  } else
    peer.sin_addr.s_addr = INADDR_ANY; /* default, current host */
  
  if (service == NULL || atoi(service) == 0)
    service = NINF_SERVER_PORT;
  
  peer.sin_port = atoi(service);
  peer.sin_port = htons(peer.sin_port);	/* in net order */
  
  /* make connenction to ninf_server */
  peer.sin_family = AF_INET;
  size = sizeof(peer);


  /*  s = socket(PF_INET,SOCK_STREAM,0); */

  s = rresvport(&initial_port);

  if(s < 0) {
    fprintf(stderr, "cannot create socket: %s\n", strerror(errno));
    return -1;
    /* exit(1); */
  }
  if(connect(s,(struct sockaddr *)&peer,size) < 0){
    fprintf(stderr, "cannot connect: %s\n", strerror(errno));
    return -1;
    /* exit(1); */
  }
  return s;
}

#define max(x,y)	((x)>(y) ? (x) : (y))
#define MAX_BUFFER_SIZE 0x1000

static char buffer1[MAX_BUFFER_SIZE];
static char buffer2[MAX_BUFFER_SIZE];

void forword(int s1, int s2){
  fd_set rfds;
  int max_nfd, nfd;

  while (!(s1 == 0 && s2 == 0)){
    FD_ZERO(&rfds);
    if (s1 != 0)
      FD_SET(s1, &rfds);
    if (s2 != 0)
      FD_SET(s2, &rfds);
    max_nfd = max(s1, s2);
    nfd = select(max_nfd+1, &rfds, NULL, NULL, NULL);
    if (nfd <= 0){
      if (errno != EINTR){
	perror("select");
	exit(3);
      }
      continue;
    }
    if (FD_ISSET(s1, &rfds)){
      int readed;
      if ((readed = read(s1, buffer1, MAX_BUFFER_SIZE - 1)) != 0)
	write(s2, buffer1, readed);
      else 
	break;
    }	
    if (FD_ISSET(s2, &rfds)){
      int readed;
      if ((readed = read(s2, buffer1, MAX_BUFFER_SIZE - 1)) != 0)
	write(s1, buffer1, readed);
      else 
	break;
    }	
  }
  close(s1);
  close(s2);

}

int authenticate(int s1, int s2){
  char buffer[128], *pointer, *username;
  struct passwd *pwd;
    
#ifdef SSL_USE
  dataTrans * c_sDT = new_dataTrans(s1, XDR_ENCODE, TRUE, NULL);
  dataTrans * c_rDT = new_dataTrans(s1, XDR_DECODE, TRUE, NULL);
  dataTrans * s_sDT = new_dataTrans(s2, XDR_ENCODE, TRUE, NULL);
#else 
  dataTrans * c_sDT = new_dataTrans(s1, XDR_ENCODE, TRUE);
  dataTrans * c_rDT = new_dataTrans(s1, XDR_DECODE, TRUE);
  dataTrans * s_sDT = new_dataTrans(s2, XDR_ENCODE, TRUE);
#endif

  read_onemore(c_rDT);

  pointer = &(buffer[0]);
  if (!trans_string(c_rDT, &pointer, NINF_MAX_NAME_LEN)){
    if(ninf_debug_flag)
      fprintf(stderr, "failed to get auth string\n");
    trans_flush(c_sDT, NINF_PKT_ERROR, NINF_AUTHENTICATION_FAILED,0);
    return FALSE;
  }

/*  username = cuserid(NULL); */  /**  cuserid() is obsolete.  **/
  pwd = getpwuid(geteuid());
  username = pwd->pw_name;

  fprintf(stderr, "comparing %s and %s\n", username, pointer);
  if (strncmp(username, pointer, NINF_MAX_NAME_LEN)== 0){
    trans_string(s_sDT, &pointer, NINF_MAX_NAME_LEN);
    trans_flush(s_sDT,
		NINF_PKT_CODE(&(c_rDT->decoded)),
		NINF_PKT_ARG1(&(c_rDT->decoded)),
		NINF_PKT_ARG2(&(c_rDT->decoded)));
    return TRUE;
  } 
  trans_flush(c_sDT, NINF_PKT_ERROR, NINF_AUTHENTICATION_FAILED,0);
  return FALSE;
}
