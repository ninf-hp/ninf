#include <stdio.h>
#include <math.h>
#include "ninf_stub.h"

main(int argc, char ** argv)
{
  int i;
  
/*  ninf_debug_flag = 1; */
    argc = Ninf_parse_arg(argc, argv);
  if (Ninf_call("die_test", 1) != NINF_OK){
    Ninf_perror("die_test");
  }
}

