package ninf.scheduler;

import ninf.basic.*;
import ninf.common.*;
import ninf.metaserver.*;
import ninf.client.*;
import java.util.Vector;

public abstract class Predictor {
  DirectoryService service;
  Predictor upper;

  public Predictor(){
  }

  public Predictor(DirectoryService service){
    this.service = service;
  }

  public Predictor(DirectoryService service, Predictor upper){
    this.service = service;
    this.upper = upper;
  }

  public void setService(DirectoryService service){
    this.service = service;
  }

  public void pushOn(Predictor upper){
    this.upper = upper;
  }

  protected Predictor[] getPredictors(Vector tmp){
    tmp.addElement(this);
    if (upper == null){
      Predictor[] ans =  new Predictor[tmp.size()];
      for (int i = 0; i < tmp.size(); i++)
	ans[i] = (Predictor)tmp.elementAt(tmp.size() - i - 1);
      return ans;
    } 
    return upper.getPredictors(tmp);
  }
  
  public Predictor[] getPredictors(){
    return this.getPredictors(new Vector());
  }

  /*******************************************************************
   *******************************************************************/

  /**  called when a request is allocated on a server */
  public void scheduled(RequestID request, CallInformation callInfo, 
			ScheduleResult result){
    if (upper != null)
      upper.scheduled(request, callInfo, result);
  }

  /**  called when a request is done */
  public void done(RequestID request, CallInformation callInfo, 
		   ScheduleResult result){
    if (upper != null)
      upper.done(request, callInfo, result);
  }
  
  public LoadInformation getLoadInformation(NinfServerStruct server)
  throws NinfException {
    if (upper != null)
      return upper.getLoadInformation(server);
    throw new PredictorException();    
  }

  public CommunicationInformation getThroughput(NinfServerStruct server, 
						ServerID cproxy)
  throws NinfException {
    if (upper != null)
      return upper.getThroughput(server, cproxy);    
    throw new PredictorException();
  }

  public CommunicationInformation getLatency(NinfServerStruct server, 
						ServerID cproxy)
  throws NinfException {
    if (upper != null)
      return upper.getLatency(server, cproxy);    
    throw new PredictorException();
  }
}
