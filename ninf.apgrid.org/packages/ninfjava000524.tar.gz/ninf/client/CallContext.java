package ninf.client;
import ninf.basic.*;

public class CallContext{
  public int iargs[];
  public ArrayShape shapes[];
  public BufferObject buffers[];
  static NinfLog dbg = new NinfLog("CallContext");
  
  public CallContext(int n){
    shapes = new ArrayShape[n];
    iargs = new int[n];
    buffers = new BufferObject[n];
  }

  public CallContext getSubContext(int from, int nparam){
    CallContext tmp = new CallContext(nparam);
    for (int i = 0; i < nparam; i++){
      tmp.iargs[i]   = iargs  [from + i];
      tmp.shapes[i]  = shapes [from + i];
      tmp.buffers[i] = buffers[from + i];
    }
    return tmp;
  }

  public void mergeBufferSub(int serial[]) {
    BufferObject tmp = buffers[serial[0]];
    for (int i = 1; i < serial.length; i++) {
      BufferObject tmp2 = buffers[serial[i]];
      buffers[serial[i]] = tmp;
      /*      if (tmp.length != tmp2.length)
	dbg.println("Buffer size conflict: " + serial[0] +
		    " is " + tmp.length+ " ,while " + serial[i] +
		    " is " + tmp2.length);
		    */
    }
  }

  public void mergeBuffer(NinfDataflow dataflows[], NinfCommonData commonData[], int argNums[]) {
    dbg.println("Merging Buffer");
    for (int i = 0; i < commonData.length; i++) {
      int se[] = commonData[i].serialize(argNums);
      String tmpStr = " Merging Buffer: ";
      for (int j = 0; j < se.length; j++)
	tmpStr += " " + se[j];
      dbg.println(tmpStr);
      mergeBufferSub(se);
    }
  }

  public String toString(){
    String tmp = "Context: ";
    for (int i = 0; i < buffers.length; i++)
      tmp +=  buffers[i].toString() + " ";
    return tmp;

  }

}
