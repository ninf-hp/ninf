#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include "ninf_macros.h"
#include "metaserver.h"

metaConnection * metaserver_connect(char * host, char * port){
  metaConnection * tmp;
  tmp = (metaConnection *)(malloc(sizeof(metaConnection)));
  if (tmp == NULL)
    return NULL;
  tmp->socket = ninf_connect_remote(host, port);
  if (tmp->socket < 0)
    return NULL;
  if ((tmp->is = fdopen(tmp->socket, "r")) == NULL){
    ninf_log("cannot fdopen metaserver connection: %s", strerror(errno));
    return NULL;
  }
  if ((tmp->os = fdopen(tmp->socket, "w")) == NULL){
    ninf_log("cannot fdopen metaserver connection: %s", strerror(errno));
    return NULL;
  }
  return tmp;
}


int metaserver_send(metaConnection * meta, char * fmt, ...)
{
  va_list args;
  
  va_start(args, fmt);
  vfprintf(meta->os, fmt, args);
  fprintf(meta->os, "\n");
  if (ninf_debug_flag){
    vfprintf(stderr, fmt, args); 
    fprintf(stderr, "\n");
  }
  va_end(args);
}

int metaserver_flush(metaConnection * meta){
  fflush(meta->os);
}


int metaserver_close(metaConnection * meta){
  metaserver_flush(meta);
  shutdown(meta->socket, 2);
  close(meta->socket);
  free(meta);
  return TRUE;
}
