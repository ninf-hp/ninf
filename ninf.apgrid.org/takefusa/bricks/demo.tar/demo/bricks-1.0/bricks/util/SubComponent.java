package bricks.util;

public interface SubComponent {
    public String getName();
}
