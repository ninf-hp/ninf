package bricks.util;
import bricks.scheduling.ResourceDB;
import bricks.environment.DataFragment;
import java.util.*;


public class NormalRandomDataFragmentStrings extends RandomDataFragmentStrings implements SubComponent {

    public NormalRandomDataFragmentStrings(long seed, String keyOfResourceDB) {
	super(seed, keyOfResourceDB);
    }

    public String getName() {
	return "NormalRandomDataFragmentStrings";
    }

    public String nextString(double size) {
	fragments = resourceDB.getFragments(size);
	double dindex = 
	    Math.abs(random.nextGaussian()) / 4.0 * (double)fragments.size();
	int index = (int)dindex;
	if (index > fragments.size() - 1)
	    index = 0;

	HeapSortForDataFragmentStrings.sortByGeneratedTime(fragments);

	DataFragment fragment = 
	    (DataFragment)fragments.elementAt(fragments.size() - 1 - index);
	SimulationDebug.println("requiredDataID = " + fragment.id);
	return fragment.id;
    }
}
