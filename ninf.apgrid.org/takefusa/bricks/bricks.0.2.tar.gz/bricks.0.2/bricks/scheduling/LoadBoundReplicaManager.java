package bricks.scheduling;
import bricks.util.*;
import bricks.environment.*;
import java.util.*;
import java.io.*;

public class LoadBoundReplicaManager extends ReplicaManager implements SchedulingUnit {

    protected double minLoadScore;

    public LoadBoundReplicaManager(
	String keyOfResourceDB, String keyOfServerMonitor, 
	Sequence interEvaluationTime, double compactness, 
	double minLoadScore, double overstoredDiskRate
    ) {
	super(keyOfResourceDB, keyOfServerMonitor, 
	      interEvaluationTime, compactness, overstoredDiskRate);
	this.minLoadScore = minLoadScore;
    }


/************************* needed method *************************/
    public String getName() {
	return "LoadBoundReplicaManager";
    }

    // implement replication strategies
    public void processEvent(double currentTime) {
	if (!doneGC(currentTime)) {
	    SimulationDebug.println(currentTime + ": check replicate");
	    replicate(currentTime);
	}
    }

    protected boolean haveToReplicate(
	Host host, StaticHostInfo staticInfo, HostInfo info, 
	Vector scoresOfSource, Vector scoresOfDestination
    ) {
	boolean replicate = false;
	double score = staticInfo.performance / (info.loadAverage + 1.0);
	if (staticInfo.performance > minLoadScore && 
	    info.loadAverage > 1.0 && score < minLoadScore) {
	    scoresOfSource.add(new Score(host, score));
	    replicate = true;
	} else {
	    scoresOfDestination.add(new Score(host, score));
	}
	return replicate;
    }
}

