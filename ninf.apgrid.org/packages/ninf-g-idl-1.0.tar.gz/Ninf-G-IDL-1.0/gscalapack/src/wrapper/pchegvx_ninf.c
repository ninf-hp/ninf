#define _WRAPPER_
/* $Id: pchegvx_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define SCOMPLEX
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n
#define ROW_b ldb
#define COL_b n
#define ROW_z ldz
#define COL_z n
static	int worklen(int n) {
	  int ret=1;
	  int NP0, NQ0, MQ0, ANB, SQNPC, NPS;
	  int NHETRD_LWOPT, NHEGST_LWOPT;
	  int three=3;
          
          ANB = max(n,100);
          NP0 = n;
          NQ0 = n;
          NPS = n;
          
          NHETRD_LWOPT = 2*( ANB+1 )*( 4*NPS+2 ) + ( NPS + 1 ) * NPS;
          NHEGST_LWOPT =  2*NP0*n + NQ0*n + n*n;

          ret =  n + ( NP0 + MQ0 + n ) * n;
          ret = MAX( ret, max(N + NHETRD_LWOPT, NHEGST_LWOPT) );
          
#define NB cbloc
	  if NEED_BUFF {
	    NP0 = NUMROC( N, NB, 0, 0, NPROW );
	    NQ0 = NUMROC( N, NB, 0, 0, NPCOL );
#if defined(SCOMPLEX)
	    ANB = FortranCall(pjlaenv)( &PARA_CTXT, &three, "PCHETTRD", "L", &zero, &zero, &zero, &zero );
#elif defined(DCOMPLEX)
	    ANB = FortranCall(pjlaenv)( &PARA_CTXT, &three, "PZHETTRD", "L", &zero, &zero, &zero, &zero );
#endif
	    SQNPC = (int)sqrt( (double)( NPROW * NPCOL ) );
	    NPS = MAX( NUMROC( N, 1, 0, 0, SQNPC ), 2*ANB );

	    NHETRD_LWOPT = 2*( ANB+1 )*( 4*NPS+2 ) + ( NPS + 1 ) * NPS;
	    NHEGST_LWOPT =  2*NP0*NB + NQ0*NB + NB*NB;

            ret =  N + ( NP0 + MQ0 + NB ) * NB;
	    ret = MAX( ret, max(N + NHETRD_LWOPT, NHEGST_LWOPT) );
	  }
	  return ret;
}

static	int rworklen(char jobz, int n) {
	  int ret=1;
	  int NEIG, NP0, MQ0;
	  int NN;

          if (chrcmp(jobz,'N')==0)
	      ret = 5 * n + 4 * n;
          if (chrcmp(jobz,'V')==0)
	      ret = 4*n + MAX( 5*n, n * n ) + n*n;
	  if NEED_BUFF {
	    NEIG = n;
	    NN = MAX( N, max(NB, 2) );
	    NP0 = NUMROC( NN, NB, 0, 0, NPROW );
	    MQ0 = NUMROC( MAX( NEIG, max(NB, 2) ), NB, 0, 0, NPCOL );
	    if (chrcmp(jobz,'N')==0)
	      ret = 5 * NN + 4 * N;
	    if (chrcmp(jobz,'V')==0)
	      ret = 4*N + MAX( 5*NN, NP0 * MQ0 ) + CEIL( NEIG, NPROW*NPCOL)*NN;
	  }
	  return ret;
}

static	int iworklen(int n) {
	  int ret=1;
	  int NNP;
          ret = 6*max(n,4);
	  if NEED_BUFF {
	    NNP = MAX( N,max( NPROW*NPCOL + 1, 4) );
	    ret = 6*NNP;
	  }
	  return ret;
}


void  pchegvx_ninf(	 int ibtype,
		 char jobz,
		 char range,
		 char uplo,
		 int n,	/*  n >= 0 */
		 scomplex global_a[],
		 int lda,
		 scomplex global_b[],
		 int ldb,
		 float vl,	/*  not referenced if range = 'a' or 'i' */
		 float vu,	/*  not referenced if range = 'a' or 'i' */
		 int il,	/* not referenced if range = 'a' or 'v' */
		 int iu,	/* not referenced if range = 'a' or 'v' */
		 float abstol,
		 int *m,	/*  0 <= m <= n */
		 float w[],	/*  n >= 0 */
		 float orfac,
		 scomplex global_z[],
		 int ldz,
		 scomplex work[],
		 int lwork,
		 float rwork[],
		 int iwork[],
		 int  ifail[],
		 int *info
)
/* "pchegvx computes all the eigenvalues, and optionally, the eigenvectors of a complex generalized Hermitian-definite eigenproblem, of the form\\n  A *x=(lambda)* B *x,   A * B x=(lambda)*x,  or\\n   B * A *x=(lambda)*x.\\n  Here A is assumed to be Hermitian, and  B is assumed to be Hermitian positive definite." */
/* OPTIONS */
{
    extern void FortranCall(pchegvx)( int*, char*, char*, char*, int*,
			       scomplex*, int*, int*, int*,
			       scomplex*, int*, int*, int*,
			       float*, float*, int*, int*,
			       float*, int*, int*, float*, float*,
			       scomplex*, int*, int*, int*,
			       scomplex*, int*,
			       float*, int*,
			       int*, int*,
			       int*, int*, float*,
			       int*);

	int maxldd;

	int maxlda;
	scomplex *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
	int row_loca, col_loca;

	int maxldb;
	scomplex *locb=NULL;
	int descb[DESCLEN];
	int desc_gb[DESCLEN];
	int row_locb, col_locb;

	int maxldz;
	scomplex *locz=NULL;
	int descz[DESCLEN];
	int desc_gz[DESCLEN];
	int row_locz, col_locz;
	
	int locm[1];
	float *locw=NULL;
	int *lociclustr=NULL;
	float *locgap=NULL;
	int *locifail=NULL;

	int locnz[1];

	scomplex *locwork=NULL;
	int llocwork;

	float *locrwork=NULL;
	int llocrwork;

	int *lociwork=NULL;
	int llociwork;

	INITIALIZE();

	SCALAR("int",ibtype);
	SCALAR("char",jobz);
	SCALAR("char",range);
	SCALAR("char",uplo);
	SCALAR("float", abstol);
	SCALAR("int",n);
	SCALAR("float", vl);
	SCALAR("float", vu);
	SCALAR("int", il);
	SCALAR("int", iu);
	SCALAR("int", lda);
	SCALAR("int", ldb);
	SCALAR("int", ldz);
        SCALAR("int", lwork);

	ROW(a );
	COL(a );
	ROW(b);
	COL(b);
	ROW(z);
	COL(z);
	MAXLDD(maxldd, a );
	maxlda=maxldd;
	maxldb=maxldd;
	maxldz=maxldd;

	trMATRIX( uplo, "scomplex", a, ROW_a, COL_a );
	trDISTRIBUTE( uplo, "scomplex", a, ROW_a, COL_a  );
	MATRIX("scomplex", b, ROW_b, COL_b);
	DISTRIBUTE("scomplex", b, ROW_b,COL_b  );
	MATRIX("scomplex",z, ROW_z, COL_z );

	locifail = MALLOC(sizeof(int)*n);                 assert(locifail);
	lociclustr = MALLOC(sizeof(int) * 2*nprow*npcol); assert(lociclustr);
	locgap = MALLOC(sizeof(float)*nprow*npcol);       assert(locgap);
	locw=MALLOC(sizeof(float)*n);                     assert(locw);

	llocwork=worklen(n);
	llocwork = max( lwork, llocwork);
	WORK(locwork,llocwork);
	llocrwork = rworklen(jobz, n);
	_work("float", &locrwork, llocrwork);
	llociwork = iworklen(n);
	IWORK(lociwork, llociwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pchegvx)( &ibtype, &jobz, &range, &uplo, &n,
			       loca, &one, &one, desca,
			       locb, &one, &one, descb,
			       &vl, &vu, &il, &iu,
			       &abstol, locm, locnz, locw, &orfac,
			       locz, &one, &one, descz,
			       locwork, &llocwork,
			       locrwork, &llocrwork,
			       lociwork, &llociwork,
			       locifail, lociclustr, locgap,
			       &linfo);

	GATHER("scomplex", a, ROW_a, COL_a  );
	GATHER("scomplex", b, ROW_b, COL_b  );
	GATHER("scomplex", z, ROW_z, COL_z  );
	RETRIEVE("int", locm, 1);
	RETRIEVE("float", locw, n);
	RETRIEVE("int", locifail, n);
	RETRIEVE("int", locgap, n);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
	  int i;
	  *info = linfo;
	  for(i=0;i<n;i++) ifail[i]=locifail[i];
	  for(i=0;i<n;i++) w[i]=locw[i];
	  *m = locm[0];
	} else {
	}

	FREE_MATRIX(a);
	FREE_MATRIX(b);
	FREE_MATRIX(z);
        
	FREE(locifail);
	FREE(lociclustr);
	FREE(locgap);
        FREE(locw);

	FREE(locwork);
        FREE(locrwork);
        FREE(lociwork);
        
}

