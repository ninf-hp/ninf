#define _WRAPPER_
/* $Id: pdlase2_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define DOUBLE
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n
void  pdlase2_ninf(	 char uplo,
		 int m,
		 int n,
		 double alpha,
		 double beta,
		 double global_a[],
		 int lda
	)
/* "pdlase2 initializes an M-by-N distributed matrix A to BETA on the diagonal and ALPHA on the  offdiagonals.  PSLASE2 requires that only dimension of the matrix operand is distributed." */
/* OPTIONS */
{
	int maxldd;

	int maxlda;
	double *loca;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
	int row_loca, col_loca;

	INITIALIZE();

	SCALAR( "char", uplo);
	SCALAR( "int", m);
	SCALAR( "int", n);
	SCALAR( "double", alpha);
	SCALAR( "double", beta);
	SCALAR("int",lda);

	ROW(a);
	COL(a);
	MAXLDD( maxldd, a );
	maxlda = maxldd;
	MATRIX( "double", a, ROW_a, COL_a);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pdlase2)( &uplo,
                               &m, &n,
                               &alpha, &beta,
                               loca, &one, &one, desca);

	GATHER( "double", a, ROW_a  , COL_a);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){

	} else {
	}

	FREE_MATRIX(a);
}

