package ninf.toNs;
import ninf.basic.*;
import ninf.client.*;
import ninf.cproxy.*;
import ninf.netsolve.*;

import java.io.IOException;
import java.util.Vector;


class NetSolveBuffer {
  int m[];
  int n[];
  BufferObject buffers[];

  NetSolveBuffer(int i){
    m = new int[i];
    n = new int[i];
  }

  void dump(){
   for (int i = 0; i < buffers.length; i++){
     System.out.println(buffers[i]);
   }
  }
}
