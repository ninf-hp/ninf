#define B_ITEM(s)  fprintf(s,"<DL>\n");
#define E_ITEM(s)  fprintf(s,"</DL>\n");
#define ITEM(s)    fprintf(s,"  <DD>");

#define B_ENUM(s)  fprintf(s,"<UL>\n");
#define E_ENUM(s)  fprintf(s,"</UL>\n");
#define ENUM(s)    fprintf(s,"  <LI>");

#define B_TABLE(s) fprintf(s,"<PRE>");
#define E_TABLE(s) fprintf(s,"</PRE>");

#define TAB(s)     fprintf(s,"\t");
#define TAB2(s)    fprintf(s,"\t\t");
#define TAB3(s)    fprintf(s,"\t\t\t");
#define RET(s)     fprintf(s,"\n");
#define RET2(s)    fprintf(s,"\n\n");
#define RET3(s)    fprintf(s,"\n\n\n");

#define LINE(s)    fprintf(s,"<HR>\n");

#define SPACE      "&#32;"
#define PARAG      "&#182;"
