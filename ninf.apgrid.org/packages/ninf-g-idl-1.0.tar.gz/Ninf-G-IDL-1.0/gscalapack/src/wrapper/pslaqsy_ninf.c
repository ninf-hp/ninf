#define _WRAPPER_
/* $Id: pslaqsy_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define FLOAT
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n

void  pslaqsy_ninf(	 char uplo,
		 int n,
		 float global_a[],
		 int lda,
		 float global_sr[],
		 float global_sc[],
		 float scond,
		 float amax,
		 char *equed
)
/* "pslaqsy equilibrates a symmetric distributed matrix A using the scaling factors in the vectors SR and SC." */
/* OPTIONS */
{

	int maxldd;

	int maxlda;
	float *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
	int row_loca, col_loca;

	float *locsr=NULL;
	float *locsc=NULL;

	char locequed[1];

	INITIALIZE();

	SCALAR( "char", uplo);
	SCALAR( "int", n);
	SCALAR( "float", scond);
	SCALAR( "float", amax);
	SCALAR( "int", lda);

	ROW( a);
	COL( a);
	MAXLDD( maxldd, a );
	maxlda = maxldd;

	MATRIX( "float", a, ROW_a, COL_a);
	DISTRIBUTE( "float", a, ROW_a, COL_a);
        
	VECTOR("r","float",sr, ROW_a);
	VECTOR("c","float",sc, COL_a);
	vDISTRIBUTE("r","float",sr, ROW_a);
	vDISTRIBUTE("c","float",sc, COL_a);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pslaqsy)( &uplo, &n,
                               loca, &one, &one, desca,
                               locsr, locsc,
                               &scond, &amax,
                               locequed);

	GATHER("float", a, ROW_a, COL_a);
	RETRIEVE("char", locequed, 1);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
            *equed = locequed[0];
	} else {
		
	}

	FREE_MATRIX(a);
	FREE_VECTOR(sr);
	FREE_VECTOR(sc);
	
}

