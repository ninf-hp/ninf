#define _WRAPPER_
/* $Id: pcheevx_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define SCOMPLEX
#include <gscalapack.h>
#define ROW_a lda
#define COL_a n
#define ROW_z ldz
#define COL_z n
static	int worklen(int n) {
	  int ret=1;
	  int three=3;
          int ABS;
	  int ANB, SQNPC, NPS, NHETRD_LWORK;
          int NP0, NN, MQ0, NEIG;

          ABS=max(n,100);
          NPS = MAX( n, 2*ANB );
          NHETRD_LWORK = n + 2*( ANB+1 )*( 4*NPS+2 ) +  ( NPS + 1 ) * NPS;

          NEIG = n;
          NP0 = max(n,2);
          MQ0 =  max(n,2);
          ret = n + (NP0 +MQ0+n)*n;
          
          ret = max( NHETRD_LWORK, ret);
          
	  if NEED_BUFF {
#if defined(SCOMPLEX)
	    ANB = FortranCall(pjlaenv)( &PARA_CTXT, &three, "PCHETTRD", "L", &zero, &zero, &zero, &zero );
#elif defined(DCOMPLEX)
	    ANB = FortranCall(pjlaenv)( &PARA_CTXT, &three, "PZHETTRD", "L", &zero, &zero, &zero, &zero );
#endif
	    SQNPC = (int)sqrt( (double)( NPROW * NPCOL ) );
	    NPS = MAX( NUMROC( N, 1, 0, 0, SQNPC ), 2*ANB );
	    NHETRD_LWORK = N + 2*( ANB+1 )*( 4*NPS+2 ) +  ( NPS + 1 ) * NPS;

            NEIG=n;
            NN = MAX( N, max(NB, 2) );
	    NP0 = NUMROC( NN, NB, 0, 0, NPROW );
            MQ0 = NUMROC( MAX( NEIG,max( NB, 2) ), NB, 0, 0, NPCOL );
            ret = n + (NP0 +MQ0+NB)*NB;
            ret = max( NHETRD_LWORK, ret);
	  }
	  return ret;
}

static	int rworklen(char jobz, int n) {
	  int ret=1;
	  int NEIG, NN, NP0, MQ0;
          if (chrcmp(jobz, 'N') ==0)
	      ret = 5 * n + 4 * n;
          if (chrcmp(jobz , 'V' ) ==0)
	      ret = 4*n + MAX( 5*n, n * n ) + n*n;
	  if NEED_BUFF {
	    NEIG=n;
	    NN = MAX( N, max(NB, 2) );
	    NP0 = NUMROC( NN, NB, 0, 0, NPROW );
	    MQ0 = NUMROC( MAX( NEIG,max( NB, 2) ), NB, 0, 0, NPCOL );
	    if (chrcmp(jobz, 'N') ==0)
	      ret = 5 * NN + 4 * N;
	    if (chrcmp(jobz , 'V' ) ==0)
	      ret = 4*N + MAX( 5*NN, NP0 * MQ0 ) +CEIL( NEIG, NPROW*NPCOL)*NN;
	  }
	  return ret;
}

static	int iworklen(int n) {
	  int ret=1;
	  int NNP;
          ret = 6*max(n,4);
	  if NEED_BUFF {
	    NNP = MAX( N, max(NPROW*NPCOL + 1, 4) );
	    ret=6*NNP;
	  }
	  return ret;
}

void  pcheevx_ninf(	 char jobz,
		 char range,
		 char uplo,	
		 int n,
		 scomplex global_a[],
		 int lda,
		 float vl,
		 float vu,
		 int il,	
		 int iu,	
		 float abstol,
		 int *m,	
		 int *nz,
		 float w[],
		 float orfac,
		 scomplex global_z[],
		 int ldz,
		 scomplex work[],
		 int lwork,
		 float rwork[],
		 int iwork[],
		 int ifail[],
		 int *info
)
/* "pcheevx computes selected eigenvalues and, optionally, eigenvectors of a complex hermitian matrix A.  Eigenvalues/vectors can be selected by  specifying a range of values or a range of indices for the desired  eigenvalues." */
/* OPTIONS */
{
    extern void FortranCall(pcheevx)( char*, char*, char*, int*,
			       scomplex*, int*, int*,  int*,
			       float*, float*, int*, int*,
			       float*, int*, int*, float*, float*,
			       scomplex*, int*, int*, int*,
			       scomplex*, int*,
			       float*, int*,
			       int*, int*,
			       int*, int*, float*, int*);
	int maxldd;

	int maxlda;
        scomplex *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
	int row_loca, col_loca;

	int maxldz;
	scomplex *locz=NULL;
	int descz[DESCLEN];
	int desc_gz[DESCLEN];
	int row_locz, col_locz;

	int locm[1], locnz[1];
        
	float *locw=NULL;
	int *locifail=NULL;

	int *iclustr=NULL;
	float *gap=NULL;
	
	scomplex *locwork=NULL;
	int llocwork;
	float *locrwork=NULL;
	int llocrwork;
	int *lociwork=NULL;
	int llociwork;

	INITIALIZE();

	SCALAR("char",jobz);
	SCALAR("char",range);
	SCALAR("char",uplo);
	SCALAR( "int", n);

	SCALAR("float",vl);
	SCALAR("float",vu);

	SCALAR("float",abstol);
	SCALAR("float",orfac);

	SCALAR( "int", lda);
	SCALAR( "int", ldz);
        SCALAR( "int", lwork);

	ROW(a);
	COL(a);
	ROW(z);
	COL(z);
	MAXLDD(maxldd,a );
	maxlda=maxldd;
	maxldz=maxldd;
	MATRIX("scomplex", a, ROW_a, COL_a);
	MATRIX("scomplex", z,ROW_z, COL_z);

	DISTRIBUTE("scomplex", a, ROW_a, COL_a);
	DISTRIBUTE("scomplex", z, ROW_z, COL_z);

	llocwork=worklen(n);
        llocwork=max(lwork,llocwork);
	WORK(locwork,llocwork);
	llocrwork=rworklen(jobz, n);
	_work("float", &locrwork, llocrwork);
	llociwork=iworklen(n);
	IWORK(lociwork, llociwork);

	locw = MALLOC(sizeof(float)*n); assert(locw);
	locifail = MALLOC(sizeof(int)*n); assert(locifail);
	iclustr = MALLOC(sizeof(int)*(2*nprow*npcol)); assert(iclustr);
	gap = MALLOC(sizeof(float)*nprow*npcol); assert(gap);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pcheevx)( &jobz, &range, &uplo, &n,
			       loca, &one, &one,  desca,
			       &vl, &vu, &il, &iu,
			       &abstol, locm, locnz, locw, &orfac,
			       locz, &one, &one, descz,
			       locwork, &llocwork,
			       locrwork, &llocrwork,
			       lociwork, &llociwork,
			       locifail, iclustr, gap, &linfo);

	GATHER("scomplex", a, ROW_a, COL_a);
	GATHER("scomplex", z, ROW_z, COL_z);

	RETRIEVE("int", locm, 1);
	RETRIEVE( "int", locnz, 1);
	RETRIEVE( "float", locw, n);

	RETRIEVE("int", locifail, n);
	RETRIEVE("int", iclustr, 2*nprow*npcol);
	RETRIEVE("int", gap, nprow*npcol);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
	  int i;
	  *info = linfo;
	  for( i=0;i<n;i++) {
	    w[i] = locw[i];
	    ifail[i] = locifail[i];
	  }
	  *m = *locm;
	  *nz = *locnz;
	} else {
	}

	FREE_MATRIX(a);
	FREE_MATRIX(z);

        FREE(locwork);
        FREE(locrwork);
        FREE(lociwork);
        
	FREE(locw);
	FREE(locifail);
	FREE(iclustr);
	FREE(gap);
	
}

