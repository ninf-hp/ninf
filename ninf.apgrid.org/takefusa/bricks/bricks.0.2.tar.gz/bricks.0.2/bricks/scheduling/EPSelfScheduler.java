package bricks.scheduling;
import bricks.util.*;
import bricks.environment.*;
import java.util.*;

/**
 * EPSelfScheduler is a self scheduler for EP programs.<BR>
 * Usage:<BR>
 * EPSelfScheduler(String keyOfMetaPredictor)
 **/
public class EPSelfScheduler extends RoundRobinScheduler {

    public EPSelfScheduler(String keyOfMetaPredictor) {
	super(keyOfMetaPredictor);
    }

/************************* needed method *************************/
    public String getName() {
	return "EPSelfScheduler";
    }

    // first
    public void selectHosts (
	double currentTime, Host source, RequestedData data
    ) throws BricksNotScheduledException {

	SimulationDebug.println("EPSelfScheduler.selectHosts");
	if (!(data instanceof EPRequestedData)) {
	    super.selectHosts(currentTime, source, data);
	    return;
	}

	EPRequestedData epdata = (EPRequestedData)data;

	if (epdata.first) { /* first time */
	    //System.out.println("first time: " + epdata);
	    if (!allocateTasksToAllHosts(currentTime, epdata))
		throw new BricksNotScheduledException(this.toString());
	} else { /* not first time */
	    System.err.println("Host calls this method at first time only");
	    System.exit(3);
	}
    }

    // second or more
    public void selectHosts (
	double currentTime, Host source, EPRequestedData epdata, EPTask eptask
    ) throws BricksNotScheduledException {

	hosts = resourceDB.getHostList();
	if (!hosts.contains(eptask.source)) { /* schedule failed */
	    SimulationDebug.println("Schedule failed!!");
	    throw new BricksNotScheduledException(this.toString());
	}

	/* schedule successed */
	EPTask task = epdata.getNextTask();
	if (task == null) {
	    System.err.println(this + ": All tasks scheduled");
	    System.exit(3);
	}
	SimulationDebug.println("Schedule successed!!");
	task.allocateHost(eptask.source);
	updateStatus(currentTime, epdata);
    }

    protected boolean allocateTasksToAllHosts(
	double currentTime, EPRequestedData epdata
    ) {
	hosts = resourceDB.getHostList();
	if (hosts.size() == 0)
	    return false;

	Enumeration e = hosts.elements();
	while (e.hasMoreElements()) {
	    Host host = (Host)e.nextElement();
	    EPTask task = epdata.getNextTask();
	    task.allocateHost(host);
	}			
	return true;
    }
}
