/*
 *  $Id: ninf_error.h,v 1.12 1999/04/16 00:49:26 nakada Exp $
 */

#ifndef __NINF_ERROR__
#define __NINF_ERROR__

#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <sys/errno.h>

/*  This file specifies ninf error codes.
    These codes should be embedded in the arg1 field of packets */

extern int ninf_debug_flag;

typedef enum _ninf_error_code{
  NINF_ERROR_NOERROR,

  NINF_ERROR_CANTFINDSTUB,
  NINF_ERROR_CANTEXECUTESTUB,
  NINF_ERROR_STUBREMOVED,
  NINF_ERROR_STUBALREADY,

  NINF_ERROR_STUBREADFAIL,
  NINF_ERROR_DATASENDFAIL,
  NINF_ERROR_DATARECVFAIL,

  NINF_ERROR_CANTCONNECTSERVER,

  NINF_ERROR_CANTFINDSESSION,
  NINF_ERROR_CANTALLOCSESSION,

  SERVER_CANNOT_ALLOC,

  HTTP_CANNOT_CONNECT,
  HTTP_NOT_FOUND,
  HTTP_HEADER_READ_ERROR,
  HTTP_UNKNOWN_FORMAT,
  HTTP_FORMAT_ERROR,
  HTTP_TYPE_MISMATCH,

  NINF_PROTOCOL_ERROR,
  NINF_INTERNAL_ERROR,
  NINF_AUTHENTICATION_FAILED,
  NINF_ERROR_SESSION_ISNOT_DONE,
  NINF_ERROR_SESSION_CANCELED,
  NINF_ERROR_SESSION_FINISHED,
  NINF_FILE_CANNOT_OPEN,
  NINF_FILE_CANNOT_WRITE,
  MALFORMED_URL,
  UNKNOWN_URL_PROTOCOL,

  CIM_OK,
  CIM_ERROR_NOT_DEFINED,
  CIM_ERROR_TYPE_MISMATCH,
  CIM_ERROR_CANNOT_ALLOC,
  CIM_ERROR_ARRAY_BOUND,

  CPROXY_CANNOT_SCHEDULE,
  CPROXY_CANNOT_MAKE_COMPOUND,

  STORAGE_CANNOT_OPEN,
  STORAGE_CANNOT_UNLINK,
  STORAGE_TRANSFER_ERROR,
  STORAGE_CANNOT_CONNECT,

  STUB_ERROR_SIGFPE,
  STUB_ERROR_SIGSEGV,

  NINF_ERROR_COMPUTATION_REFUSED,

} NINF_ERROR_CODE;

extern char * ninf_error_string[];
extern int ninf_error_code;
extern char * ninf_error_user_string;

extern void (*finalizer)();

char * Ninf_perror_string();
void Ninf_perror(char * str);
void Ninf_perror_fp(FILE * fp, char * str);
char * Ninf_perror_string_id(int id);
void Ninf_perror_id(int id, char * str);
void Ninf_perror_id_fp(FILE *fp, int id, char * str);

void ninf_set_error_string(char *str);

void ninf_log_header();
void ninf_log(char * fmt, ...);
void ninf_error(char * fmt, ...);
void ninf_debug(char * fmt, ...);
void ninf_fatal(char * fmt, ...);
void ninf_set_log_file(char * filename);

extern int ninf_debug_flag;
extern char * program_context;
extern FILE * logfp;

#define debug_log if (ninf_debug_flag) ninf_log

/***********************************************************************/
/***********************************************************************/
/***********************************************************************/

#ifdef ERROR_MAIN

int ninf_error_code;
int ninf_debug_flag = FALSE;

FILE * setUpLog();
FILE * logfp = NULL;

char *save_str(char *s);
char * ninf_error_user_string = NULL;

char * ninf_error_string[] = {
  "Normal execution.",

  "Can't find the stub.",
  "Can't execute the stub.",
  "Specified stub was removed.",
  "The stub was already executed.",

  "Stub read failed: May be died.", 
  "Data send failed.", 
  "Data recv failed.", 

  "Can't connect Server.",

  "Can't find Session.",
  "Can't alloc Session.",

  "Server side: cannot alloc enough memory.",

  "Server side: cannot connect the specified httpd.",
  "Server side: the URL is not found.",
  "Server side: cannot read the http header.",
  "Server side: cannot read the format.",
  "Server side: unexpected content format.",
  "Server side: the specified content does not match with the expected type.",

  "Protocol mismatch: check version no. of client and server",
  "Ninf Internal Error: Contact ninf person.",
  "Authentication Failed: Server refused the connection.",
  "The session is not done, yet.",
  "The session was canceled.",
  "The session was already finished.",
  "The specified file cannot be opened.",
  "Failed to write to the specified file.",
  "The specified url is malformed.",
  "Unknown URL protocol.",

  "CIM OK ",
  "CIM : routine not defined",
  "CIM : in user routine: type mismatch",
  "CIM : in user routine: cannot alloc",
  "CIM : in user routine: array boundary over run ",

  "CProxy: Cannot Schedule.",
  "CProxy: Could not make compound stub info.",

  "Storage: cannot open specified file.",
  "Storage: cannot unlink specified file.",
  "Storage: data transfer error.",
  "Storage: cannot connect specified storage server.",

  "Error: in computational routine: 'floating point exception' caught.",
  "Error: in computational routine: 'segmentation violation' caught.",

  "Computation Refused: too many request on the server.",

};

void ninf_set_error_string(char * str){
  if (str != NULL)
    ninf_error_user_string = save_str(str);

}

#endif


#endif /* __NINF_ERROR__ */
