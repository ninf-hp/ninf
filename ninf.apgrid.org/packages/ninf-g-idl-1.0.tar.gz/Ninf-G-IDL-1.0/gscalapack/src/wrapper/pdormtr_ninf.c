#define _WRAPPER_
/* $Id: pdormtr_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define DOUBLE
#include <gscalapack.h>

#define ROW_a lda
#define COL_a col_a
#define ROW_c ldc
#define COL_c n
static	int worklen(char side, char uplo, int m, int n) {
	  int ret=1;
	  int IROFFA, ICOFFA, IAROW, NpA0, IROFFC, ICOFFC, ICROW;
	  int ICCOL, MpC0, NqC0;
          int LCMQ;
	  int IAA, JAA, ICC, JCC, MI, NI;
	  int max_m_n;

	  max_m_n = max(m,n);
	  ret = MAX( (max_m_n*(max_m_n-1))/2, (max_m_n + max_m_n)*max_m_n ) + max_m_n * max_m_n;
	  if NEED_BUFF {
	    LCMQ = LCM(NPROW, NPCOL) / NPCOL;

	    IROFFA = MOD( IAA-1, MB_A );
	    ICOFFA = MOD( JAA-1, NB_A );
	    IAROW = INDXG2P( IAA, MB_A, MYROW, RSRC_A, NPROW );
	    NpA0 = NUMROC( NI+IROFFA, MB_A, MYROW, IAROW, NPROW );

	    IROFFC = MOD( ICC-1, MB_C ); ICOFFC = MOD( JCC-1, NB_C );
	    ICROW = INDXG2P( ICC, MB_C, MYROW, RSRC_C, NPROW );
	    ICCOL = INDXG2P( JCC, NB_C, MYCOL, CSRC_C, NPCOL );
	    MpC0 = NUMROC( MI+IROFFC, MB_C, MYROW, ICROW, NPROW );
	    NqC0 = NUMROC( NI+ICOFFC, NB_C, MYCOL, ICCOL, NPCOL );

	    if (chrcmp(uplo, 'U')==0) {
	      IAA = IA; JAA = JA+1; ICC = IC; JCC = JC;
	    }else {
	      IAA = IA+1; JAA = JA;
	      if (chrcmp(side, 'L')==0) {
		ICC = IC+1; JCC = JC;
	      }else{
		ICC = IC; JCC = JC+1;
	      }
            }
            

            if (chrcmp(side , 'L')==0) {
		MI = M-1; NI = N;
		ret = MAX( (NB_A*(NB_A-1))/2, (NqC0 + MpC0)*NB_A ) + NB_A * NB_A;
            }else {
		MI = M; MI = N-1;
		ret = MAX( (NB_A*(NB_A-1))/2, ( NqC0 + MAX( NpA0 + NUMROC( NUMROC( NI+ICOFFC, NB_A, 0, 0, NPCOL ), NB_A, 0, 0, LCMQ ), MpC0 ) )*NB_A ) +  NB_A * NB_A;
            }
	  }
	  return ret;
}

static	int taulen(char side, char uplo, int m, int n, int lda, int col_a) {
	  int ret=1;
	  if (chrcmp(side, 'L' )==0) {
	    if (chrcmp(uplo,'U')==0) ret = ROW_a;
	    else ret = M-1;
	  } else {
	    if (chrcmp(uplo,'U')==0) ret = COL_a;
	    else ret = N;
	  }
	  return ret;
}

void  pdormtr_ninf(	 char side,
		 char uplo,
		 char trans,
		 int m,
		 int n,
		 double global_a[],
		 int lda,
		 double global_tau[],
		 double global_c[],
		 int ldc,
		 double work[],
		 int lwork,
		 int *info
)
/* "pdormtr overwrites the general real M-by-N distributed matrix C with\\n\\n                       SIDE = 'L'           SIDE = 'R'\\n  TRANS = 'N':      Q * C          C * Q\\n  TRANS = 'T':      Q**T *  C       C * Q**T\\n\\n  where Q is a real orthogonal distributed matrix of order nq, with nq = m if SIDE = 'L' and nq = n if SIDE = 'R'." */
/* OPTIONS */
{
	int maxldd;

	int maxlda;
	double *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
	int col_a;
	int row_loca, col_loca;

	double *loctau=NULL;

	int maxldc;
	double *locc=NULL;
	int descc[DESCLEN];
	int desc_gc[DESCLEN];
	int row_locc, col_locc;

	double *locwork=NULL;
	int llocwork;


	INITIALIZE();

	SCALAR( "char", side);
	SCALAR( "char", uplo);
	SCALAR( "char", trans);
	SCALAR( "int", m);
	SCALAR( "int", n);
	SCALAR( "int", lda);
	SCALAR( "int", ldc);
	SCALAR( "int", lwork);

	if (chrcmp(side,'L')==0) col_a = m;
	else col_a = n;

	ROW( a);
	COL( a);
	ROW( c);
	COL( c);
	MAXLDD( maxldd, c );
	maxlda = maxldd;
	maxldc = maxldd;

	MATRIX( "double", a, ROW_a, COL_a);
	MATRIX( "double", c, ROW_c, COL_c);
	VECTOR("c", "double", tau, taulen( side, uplo, m, n,lda, col_a));

	DISTRIBUTE( "double", a, ROW_a, COL_a);
	DISTRIBUTE( "double", c, ROW_c, COL_c);
	vDISTRIBUTE("c","double", tau, taulen( side, uplo, m, n, lda, col_a));

	llocwork = worklen(side, uplo, m , n);
	llocwork = max(lwork,llocwork);
	WORK(locwork,llocwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pdormtr)( &side, &uplo, &trans,
                               &m, &n,
                               loca, &one, &one, desca,
                               loctau,
                               locc, &one, &one, descc,
                               locwork, &llocwork,
                               &linfo);

	GATHER( "double", c, ROW_c, COL_c);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
		*info = linfo;
		// cp locwork to work[lwork]
	} else {
		
	}

	FREE_MATRIX(a);
	FREE_MATRIX(c);
	FREE_VECTOR(tau);
        FREE(locwork);
	
}

