#define _WRAPPER_
/* $Id: psgeequ_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define FLOAT
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n
void  psgeequ_ninf(	 int m,
		 int n,
		 float global_a[],
		 int lda,
		 float global_r[],
		 float global_c[],
		 float *rowcnd,
		 float *colcnd,
		 float *amax,
		 int *info
)
/* "psgeequ computes row and column scalings intended to equilibrate an M-by-N distributed matrix A and reduce its condition number." */
/* OPTIONS */
{
	int maxldd;

	int maxlda;
	float *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
	int row_loca, col_loca;
        
	float *locr=NULL;
	float *locc=NULL;

	float locrowcond[1], loccolcond[1], locamax[1];

	INITIALIZE();

	SCALAR( "int", m);
	SCALAR( "int", n);
	SCALAR( "int", lda);

	ROW( a);
	COL( a);
	MAXLDD( maxldd, a );
	maxlda = maxldd;

	MATRIX( "float", a, ROW_a, COL_a);
	DISTRIBUTE( "float", a, ROW_a  , COL_a);
	VECTOR("r", "float", r, m);
	VECTOR("c", "float", c, n);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(psgeequ)( &m, &n,
                               loca, &one, &one, desca,
                               locr, locc,
                               locrowcond, loccolcond, locamax,
                               &linfo);

	vGATHER("r", "float", r, m);
	vGATHER("c", "float", c, n);
        RETRIEVE("float",locrowcond,1);
        RETRIEVE("float",loccolcond,1);
        RETRIEVE("float",locamax,1);

	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
	  *rowcnd = *locrowcond;
	  *colcnd = *loccolcond;
	  *amax = *locamax;
	  *info = linfo;
	} else {
	}

	FREE_MATRIX(a);
        FREE_VECTOR(r);
        FREE_VECTOR(c);
	
}

