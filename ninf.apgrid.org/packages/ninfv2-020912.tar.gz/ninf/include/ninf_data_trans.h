#ifndef __NINF_DATA_TRANS__
#define __NINF_DATA_TRANS__ 

#include <sys/types.h>
#include <sys/time.h>
#include <rpc/rpc.h>

#ifndef WIN32
#include <sys/socket.h>
#include <netinet/in.h>
#ifndef NO_TCP_H
#include <netinet/tcp.h>
#endif
#include <unistd.h>
#else
#define NO_FLAGS_SET 0
#include <winsock.h>
#include <windows.h>
#include <io.h>
#endif
#if defined(_AIX)
#include <sys/select.h>
#endif

#include <sys/stat.h>
#include <fcntl.h>

#include "ninf_macros.h"
#include "ninf_packet.h"
#include "ninf_stub_info.h"
#include "ninf_any_t.h"
#include "resource.h"
#ifdef SSL_USE
#include <ssl.h>
#endif

#define STUB_BUF_SIZE (MAX_PKT_LEN - NINF_PKT_HEADER_SIZE)
typedef struct dataTrans {
#ifdef SSL_USE
  SSL * ssl;
#endif
  char header [NINF_PKT_HEADER_SIZE]; /* header area */
  char buffer [STUB_BUF_SIZE * 2]; /* the last 1 word is dummy word for j90 */
                                   /* duplicated for buffer */
  char * start;    /* top of buffer */
  char * position; /* current point */
  char * valid_end;/* end of valid data for reading */
  char * end;      /* end of buffer */
  char * align_base;
  int fd; /* file descriptor */
  int flag;        /* XDR_ENCODE or XDR_DECODE */
  int withHeader;   /* withHeader is for client */
  DECODED_HEADER decoded;
  int dying;
} dataTrans;

typedef int (* transFunc )(dataTrans *, void *);
dataTrans * new_dataTrans(int fd, int flag, int withHeader
#ifdef SSL_USE
   , SSL * ssl
#endif			    
);

typedef int (*xdrFunc)(XDR *, void *);
typedef int (*dataHook)(any_t * arg, int io_mode);

typedef struct data_description {
    int      xdr_length;        /* data length when it encoded in xdr */
    int      data_length;       /* data length on this architechture  */
    xdrFunc  xdr_func;          /* xdr function to encode the data    */
    dataHook hook_client_before_send;
    dataHook hook_client_after_send;
    dataHook hook_client_before_recv;
    dataHook hook_client_after_recv;
    dataHook hook_server_before_send;
    dataHook hook_server_after_send;
    dataHook hook_server_before_recv;
    dataHook hook_server_after_recv;

} data_description;

extern data_description DataDescription[];

#define xdr_data_length(t)	(DataDescription[(t)].xdr_length)
#define DATA_TYPE_SIZE(t)	(DataDescription[(t)].data_length)
#define DATA_TYPE_XDR_FUNC(t)	(DataDescription[(t)].xdr_func)
#define EXEC_HOOK_CLIENT_BEFORE_SEND(t, data, io) \
       ((DataDescription[(t)].hook_client_before_send == NULL) ? TRUE :\
         (*(DataDescription[(t)].hook_client_before_send))(data, io))
#define EXEC_HOOK_CLIENT_AFTER_SEND(t, data, io) \
       ((DataDescription[(t)].hook_client_after_send == NULL) ? TRUE :\
         (*(DataDescription[(t)].hook_client_after_send))(data, io))
#define EXEC_HOOK_CLIENT_BEFORE_RECV(t, data, io) \
       ((DataDescription[(t)].hook_client_before_recv == NULL) ? TRUE :\
         (*(DataDescription[(t)].hook_client_before_recv))(data, io))
#define EXEC_HOOK_CLIENT_AFTER_RECV(t, data, io) \
       ((DataDescription[(t)].hook_client_after_recv == NULL) ? TRUE :\
         (*(DataDescription[(t)].hook_client_after_recv))(data, io))
#define EXEC_HOOK_SERVER_BEFORE_SEND(t, data, io) \
       ((DataDescription[(t)].hook_server_before_send == NULL) ? TRUE :\
         (*(DataDescription[(t)].hook_server_before_send))(data, io))
#define EXEC_HOOK_SERVER_AFTER_SEND(t, data, io) \
       ((DataDescription[(t)].hook_server_after_send == NULL) ? TRUE :\
         (*(DataDescription[(t)].hook_server_after_send))(data, io))
#define EXEC_HOOK_SERVER_BEFORE_RECV(t, data, io) \
       ((DataDescription[(t)].hook_server_before_recv == NULL) ? TRUE :\
         (*(DataDescription[(t)].hook_server_before_recv))(data, io))
#define EXEC_HOOK_SERVER_AFTER_RECV(t, data, io) \
       ((DataDescription[(t)].hook_server_after_recv == NULL) ? TRUE :\
         (*(DataDescription[(t)].hook_server_after_recv))(data, io))

int read_onemore(dataTrans * dt);
int do_onemore(dataTrans * dt);

int trans_char_array(dataTrans * dt, int count, char * buffer);


int trans_char(dataTrans * dt, char * );

int trans_short(dataTrans * dt, short * );
int trans_int(dataTrans * dt, int * );
int trans_enum(dataTrans * dt, int * val);
int trans_long(dataTrans * dt, long * );
int trans_u_char(dataTrans * dt, unsigned char * );
int trans_u_short(dataTrans * dt, unsigned short * );
int trans_u_int(dataTrans * dt, unsigned int * );
int trans_u_long(dataTrans * dt, unsigned long * );
int trans_float(dataTrans * dt, float *);
int trans_double(dataTrans * dt, double *);
int trans_string_nolen(dataTrans * dt, char ** buf);
int trans_string(dataTrans * dt, char ** buf, int maxlen);
int trans_string_primitive(dataTrans * dt, char ** buf, int maxlen);
void trans_dataTrans_sub(dataTrans * dt, char * buffer, DATA_TYPE type, int items);

int trans_scomplex(dataTrans * dt, float * val);
int trans_dcomplex(dataTrans * dt, double * val);

int read_dataTrans(dataTrans * dt, char * buffer, DATA_TYPE type, int count);
int write_flush(dataTrans * dt);
int trans_any(dataTrans *dt, DATA_TYPE t, int ncount, char * p);
int trans_array(dataTrans *dt, enum data_type param_type, int dim, char *base, 
		array_shape_info * array_shape);
int trans_request(dataTrans *dt, int req);

void trans_destroy(dataTrans * dt);

int isSend(dataTrans *dt);
int isReceive(dataTrans *dt);

int trans_size_header(dataTrans *dt, int size, int * sizes_in_header);

int trans_array_shape(struct ninf_param_desc *dp, 
		      NINF_STUB_INFO *sp,
		      any_t *args, array_shape_info * array_shape, 
		      int *in_header);
int trans_stub_info(dataTrans *DT, NINF_STUB_INFO *sp, int send_description);

int trans_scalar_args(dataTrans * dt, NINF_STUB_INFO * sp, any_t *args, 
		      int initiator);
int trans_scalar_args_ft(dataTrans * dt, NINF_STUB_INFO * sp, any_t *args,
			 int from, int to, int initiator);

int trans_vector_array_args_ft(dataTrans * dt, NINF_STUB_INFO * stub_info_p, 
			     any_t *ninf_args, resource * rsc, int from, int to,
			     int initiator, long * transmitted);
int trans_vector_any_args_ft(dataTrans * dt, NINF_STUB_INFO * stub_info_p, 
			     any_t *ninf_args, resource * rsc, int from, int to,
			     int initiator, long * transmitted);


int trans_vector_any_to_stream(resource * rsc, int from, int to);
int trans_vector_any_from_stream(resource * rsc, int from, int to);

#include "ninf_cim.h"

int trans_array_handler(dataTrans *dt, enum data_type param_type, int dim, obj_handler handler,
		array_shape_info * array_shape);

void set_resource_array(resource * rsc, enum data_type param_type, 
			int dim, MODE_SPEC mode,
			int size, char * base, array_shape_info * array_shape);
void set_resource_any(resource * rsc,  enum data_type param_type, 
		      int dim, MODE_SPEC mode,
		      int size, char * base, array_shape_info * array_shape);


void trans_flush(dataTrans * dt, int code, int arg1, int arg2);


void set_trans_header(dataTrans * dt, int code, int arg1, int arg2);
int  getArg1(dataTrans * dt);
int  getArg2(dataTrans * dt);

int trans_getPacket(dataTrans * dt);


int write_dataTrans_string(dataTrans * dt, char * buffer, int count);

void force_write(dataTrans *dt_out, dataTrans *dt_org);
void force_write_with(dataTrans *dt, dataTrans *dt_org, int code, int arg1, int arg2);
int trans_count(dataTrans *dt);

char * read_line_dataTrans(dataTrans *dt);

int trans_write_skip(dataTrans * dt, int count);
int trans_read_skip(dataTrans * dt, int count);


int trans_char_raw_single(dataTrans * dt, char * buffer);
int trans_char_raw_balk(dataTrans * dt, char * buffer, int items);
int trans_short_raw_single(dataTrans * dt, char * buffer);
int trans_short_raw_balk(dataTrans * dt, char * buffer, int items);
void trans_mark_align(dataTrans * dt);
void trans_align(dataTrans * dt);


#endif 
