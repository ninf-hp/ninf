#define _WRAPPER_
/* $Id: pcgesv_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define SCOMPLEX
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n
#define ROW_b ldb
#define COL_b nrhs
void  pcgesv_ninf( int n,
		 int nrhs,
		 scomplex global_a[],
		 int lda,
		 int global_ipiv[],
		 scomplex global_b[],
		 int ldb,
		 int *info
)
/* "pcgesv computes the solution to a real system of linear equations  A * X =  B , where A is an N-by-N distributed matrix and X and  B are N-by-NRHS distributed matrices." */
/* OPTIONS */
{
    extern void FortranCall(pcgesv)( int*, int*,
                              scomplex*, int*, int*, int*,
                              int*,
                              scomplex*, int*, int*, int*,
                              int*);

	int maxldd;

	int maxlda;
	scomplex *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];

	int maxldb;
	scomplex *locb=NULL;
	int descb[DESCLEN];
	int desc_gb[DESCLEN];

        int *locipiv=NULL;
	
	int row_loca, col_loca;
	int row_locb, col_locb;

	INITIALIZE();

	SCALAR( "int", n);
	SCALAR( "int", nrhs);
	SCALAR( "int", lda);
	SCALAR( "int", ldb);

	ROW( a);
	COL( a);
	ROW( b);
	COL( b);
	MAXLDD( maxldd, a );
	maxlda = maxldd;
	maxldb = maxldd;

	MATRIX( "scomplex", a, ROW_a, COL_a);
	MATRIX( "scomplex", b, ROW_b, COL_b);
	VECTOR( "r", "int", ipiv, ROW_a);
        
	DISTRIBUTE( "scomplex", a, ROW_a  , COL_a);
	DISTRIBUTE( "scomplex", b, ROW_b  , COL_b);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pcgesv)( &n, &nrhs,
                              loca, &one, &one, desca,
                              locipiv,
                              locb, &one, &one, descb,
                              &linfo);

	GATHER( "scomplex", a, ROW_a  , COL_a);
	GATHER( "scomplex", b, ROW_b  , COL_b);
	vGATHER( "r", "int", ipiv, ROW_a);

	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
		*info = linfo;
	} else {
	}

	FREE_MATRIX(a);
	FREE_MATRIX(b);
	FREE_VECTOR(ipiv);
	
}

