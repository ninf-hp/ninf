#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#ifndef WIN32
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#else
#include <windows.h>
#include <Winsock.h>
#endif
#include <errno.h>
#include <string.h>
#include "ninf_error.h"
#include "ninf_macros.h"

#define TUNNEL_PROGRAM "ninf_tunnel"

#ifndef WIN32
int ninf_connect_remote_privileged(char * hostname, char * service){
  int fd[2];
  int pid;
  char buffer[10];
  if (socketpair(AF_UNIX, SOCK_STREAM, 0, fd) < 0){
    perror("socketpair");
    return -1;
  }
  if ((pid = fork()) == 0){
    sprintf(buffer, "%d", fd[0]);
    close(fd[1]);
    if (execlp(TUNNEL_PROGRAM, TUNNEL_PROGRAM, buffer, hostname, service, NULL))
      perror("execl failed:");
  }
  if (pid < 0){
    perror("fork error");
    return -1;
  }
  close(fd[0]);
  return fd[1];
}
#else
int ninf_connect_remote_privileged(char * hostname, char * service){
	return ninf_connect_remote(hostname, service);
}
#endif

/* returns socket if succeed, return -1 if failed */ 
int ninf_connect_remote(char * hostname, char * service)
{
  int s,size;
  struct sockaddr_in peer;
  struct hostent *hp;
  struct servent *sp;

#ifdef WIN32
  WSADATA Data;
  WSAStartup(MAKEWORD(1,1), &Data);
#endif

  if (hostname != NULL){
    hp = gethostbyname(hostname);
    if (hp == NULL){
      ninf_debug("%s: unknown hostname\n", hostname);
      return -1;
    }
#if defined(__j90__) || defined(__t3e__)
    memcpy(&peer.sin_addr.s_da,hp->h_addr,hp->h_length);
#else
    memcpy((char *)(&peer.sin_addr.s_addr),hp->h_addr,hp->h_length);
#endif 

  } else
    peer.sin_addr.s_addr = INADDR_ANY; /* default, current host */
  
  if (service == NULL || atoi(service) == 0)
    service = NINF_SERVER_PORT;
  
  peer.sin_port = atoi(service);
  peer.sin_port = htons(peer.sin_port);	/* in net order */
  
  /* make connenction to ninf_server */
  peer.sin_family = AF_INET;
  size = sizeof(peer);
  s = socket(PF_INET,SOCK_STREAM,0);
  if(s < 0) {
    ninf_debug("cannot create socket: %s", strerror(errno));
    return -1;
    /* exit(1); */
  }
  if(connect(s,(struct sockaddr *)&peer,size) < 0){
    ninf_debug("cannot connect: %s", strerror(errno));
    return -1;
    /* exit(1); */
  }
  return s;
}

/*  this definition have to be overriden by definition in Makefile */
#ifndef SHELL_DEFAULT_COMMAND 
#define SHELL_DEFAULT_COMMAND "/usr/bin/ssh"
#endif
/*  this definition have to be overriden by definition in Makefile */
#ifndef PROXY_DEFAULT_COMMAND 
#define PROXY_DEFAULT_COMMAND "ninf_ssh_proxy"
#endif
#define PROXY_ENV_NAME "NINF_SHELL_PROXY"

static char * get_proxy_command(){
  static char * command = NULL;
  if (command == NULL){
    command = getenv(PROXY_ENV_NAME);
    if (command == NULL)
      command = PROXY_DEFAULT_COMMAND;
  } 
  return command;
}


#define SHELL_TEMPLATE "%s %s '%s'"
#define SHELL_ENV_NAME "NINF_SHELL_COMMAND"

int connectShell(char *hostname, char * command){
  int fdpair[2];
  char buffer[1000];
  char * shell_command;
  
  if (hostname == NULL)
    hostname = "localhost";

  if ((shell_command = getenv(SHELL_ENV_NAME)) == NULL)
    shell_command = SHELL_DEFAULT_COMMAND;

  sprintf(buffer, SHELL_TEMPLATE, shell_command, hostname, command);

  if (socketpair(AF_UNIX, SOCK_STREAM, 0, fdpair) < 0){
    perror("socketpair");
    return -1;
  }

  if (fork() == 0){ /* child */
    close(fdpair[0]);

    dup2(fdpair[1],0);  /* bind stdin  */
    dup2(fdpair[1],1);  /*  bind stdout */
    
    if (ninf_debug_flag)
      ninf_error("executing : %s\n", buffer);

    if (execl("/bin/sh", "sh", "-c", buffer, (char *)0) < 0){
      perror("execl");
      ninf_error("exec failed: %s\n", buffer);
      close(fdpair[1]);
      exit(3);
    }
  }                 /* parent */
  close(fdpair[1]);
  return fdpair[0];

}


#define SHELL_PROXY_FMT    "%s %s"

int ninf_connect_remote_shell(char * hostname, char * service){
  char buffer[1000];
  char * proxy_command = get_proxy_command();
  sprintf(buffer, SHELL_PROXY_FMT, proxy_command, service);
  return connectShell(hostname, buffer);
}
extern char * myhostname();

#define SHELL_PROXY_CALLBACK_FMT    "%s %s %s %d"
#define BIND_TRY_MAX 20
#define MAX_LISTEN 1

int ninf_connect_remote_shell_callback(char * hostname, char * service, 
				     int callback_port){
  char buffer[1000];
  char * proxy_command = get_proxy_command();
  char * clienthostname = myhostname();
  int sock, ns;
  struct sockaddr_in client_addr;
  int size;

  if (callback_port < 0)
    callback_port = 5000;

  sock = init_server_socket_from(INADDR_ANY, &callback_port, 
				 MAX_LISTEN, BIND_TRY_MAX);
  if (sock < 0)
    return -1;
  {
    const char i = 1;
    if (setsockopt(sock, SOL_SOCKET, SO_REUSEADDR, &i, sizeof(i)) <0)
      perror("setsockopt");
  }
    
  sprintf(buffer, SHELL_PROXY_CALLBACK_FMT, proxy_command,
	  service, clienthostname, callback_port);
  if (connectShell(hostname, buffer) < 0)
    return -1;

  size = sizeof(client_addr);
  ns = accept(sock, (struct sockaddr *)&client_addr,&size);
  if (ns < 0){
    perror("callback socket accept");
    return -1;
  }    
  close(sock);
  return ns;
}

