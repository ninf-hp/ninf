package ninf.basic;
import ninf.basic.*;
import ninf.client.*;
import java.io.*;

public interface ConnectionManager{
  public void closed(ForeServer foresever);
  public void exception(Exception e);
}
