#! /bin/sh
# $Id: make_stub.sh,v 1.3 2005/06/20 13:25:54 naotaka Exp $

for arg in "$@" ; do
    case "$arg" in
       [^=]*=*) 
	    TARGETENV=`expr "${arg}" : '\([^=]*\)='`
	    VAL="`expr "${arg}" : '[^=]*=\(.*\)'`"
	    eval ${TARGETENV}=\"${VAL}\"
        ;;
        *)
        ;;
    esac
done

[ x"${TARGET}" = x"" ] && exit 3
[ x"${TOPDIR}" = x"" ] && exit 3
[ x"${BINDIR}" = x"" ] && exit 3
[ x"${THISDIR}" = x"" ] && exit 3
[ x"${INCLUDEDIR}" = x"" ] && exit 3
[ x"${SRCDIR}" = x"" ] && exit 3
[ x"${NINF_GEN}" = x"" ] && exit 3
[ x"${MAKE}" = x"" ] && exit 3
[ x"${CC}" = x"" ] && exit 3
[ x"${MAKE}" = x"" ] && exit 3

if [ ! -f ${TOPDIR}/src/fftw.idl ] ; then
    exit 2
fi

tgt="`echo ${TARGET} | sed -e s'!^.!!' `"
[ x"$tgt" = x"" ] && exit 3

if [ -d ${BINDIR} ] ; then
    cd ${BINDIR} || exit 2
    if [ -e gfftw.h -o -L gfftw.h ] ; then
	rm -f gfftw.h
    fi
    ln -s ${INCLUDEDIR}/gfftw.h 
    if [ -e gplan.h -o -L gplan.h ] ; then
	rm -f gplan.h
    fi
    ln -s ${INCLUDEDIR}/gplan.h

    ng_gen -I./ ${SRCDIR}/${tgt}.idl || exit 2
    ${MAKE} -f fftw.mak || exit 2
    ${MAKE} -f fftw.mak clean
    for def in nsdef ngdef ; do
	if [ -f fftw."`globus-hostname`".${def} ] ; then
	    mv fftw."`globus-hostname`".${def} fftw."`globus-hostname`".${def}${TARGET}
	fi
    done
    touch ${SRCDIR}/${TARGET}
    cd ${THISDIR}
fi
