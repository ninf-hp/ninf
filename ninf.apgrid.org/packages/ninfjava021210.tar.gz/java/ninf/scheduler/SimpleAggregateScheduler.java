package ninf.scheduler;
import ninf.common.*;
import ninf.metaserver.*;
import ninf.basic.*;
import ninf.client.*;
import ninf.cproxy.aggregate.*;
import java.util.*;

/** use usual Scheduler as a backend */

public class SimpleAggregateScheduler extends AggregateScheduler {
  Hashtable serverLoad = new Hashtable();

  int getLoad(NinfServerStruct id){
    Integer tmp = (Integer)serverLoad.get(id);
    if (tmp == null)
      return 0;
    return tmp.intValue();
  }

  void addLoad(NinfServerStruct id){
    Integer tmp = (Integer)serverLoad.get(id);
    int val;
    if (tmp == null)
      val = 0;
    else
      val = tmp.intValue();
    serverLoad.put(id, new Integer(val + 1));
  }

  private void setDataLocations(FuncNode funcNodes[], DataNode dataNodes[]){
    for (int i = 0; i < dataNodes.length; i++)
      if (dataNodes[i].location == null){
	ServerIndex tmp = funcNodes[dataNodes[i].from].serverIndex;
	dataNodes[i].location = new ServerID(tmp.server.host, tmp.server.port);
      }
  }


  double performance(SchedulerRoot schedulerRoot, NinfServerStruct server)
  throws NinfException{
    LoadInformation load = 
      schedulerRoot.getLoad      (server);
    ServerCharacter serverChar = 
      schedulerRoot.getServerChar(server);

    double average = load.loadAverage;
    double performance = serverChar.performance * 1000.0 * serverChar.CPUNum;

    int scheduled = getLoad(server);
    return (performance * (1.0 /(average + scheduled + 1.0)));
  }

  private void getServerIndex(FuncNode funcNode, DataNode dataNodes[],
				     NinfServerStruct servers[],
	     SchedulerRoot schedulerRoot, ServerID cproxy, StringBuffer sb)
  throws NinfException{

    /*
    DirectoryService service = schedulerRoot.service;
    for (int i = 0; i < servers.length; i++){
      ServerIndex serverIndex = 
	schedulerRoot.getServerIndex(servers[i],funcNode.name);
      if (serverIndex != null)
	return serverIndex;
    }
    return null;
    */
    
    if (funcNode.serverIndexes != null && funcNode.serverIndexes.length > 0){
      double max = 0;
      ServerIndex ans = null;
      for (int i = 0; i < funcNode.serverIndexes.length; i++){
	double perf = performance(schedulerRoot, 
				  funcNode.serverIndexes[i].server);
	if (perf > max){
	  max = perf;
	  ans = funcNode.serverIndexes[i];
	}
      }
      addLoad(ans.server);
      funcNode.serverIndex = ans;
    }
  }

  public AggregateScheduled schedule(DataFlow dataFlow,
				     NinfServerStruct servers[],
				     SchedulerRoot schedulerRoot, 
				     ServerID cproxy, StringBuffer sb)
  throws NinfException{
    FuncNode[] funcNodes = dataFlow.funcNodes;
    DataNode[] dataNodes = dataFlow.dataNodes;

    for (int i = 0; i < funcNodes.length; i++){
      getServerIndex(funcNodes[i], dataNodes, servers,
		     schedulerRoot, cproxy, sb);
    }
    

    for (int i = 0; i < funcNodes.length; i++){
      ServerIndex serverIndex = (funcNodes[i].serverIndex);
      String tmp = (serverIndex == null) ? "null" : serverIndex.server.toString();
      sb.append(tmp);
      sb.append(" ");
    }
    sb.append("\n");

    setDataLocations(funcNodes, dataNodes);
    return new AggregateScheduled(dataFlow);
    
  }

}

