#define _WRAPPER_
/* $Id: pspotrs_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define FLOAT
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n
#define ROW_b ldb
#define COL_b nrhs
void  pspotrs_ninf(	 char uplo,
		 int n,
		 int nrhs,
		 float global_a[],
		 int lda,
		 float global_b[],
		 int ldb,
		 int *info
)
/* "pspotrs solves a system of linear equations A*X = B where A is a N-by-N symmetric positive definite distributed matrix using the Cholesky factorization A = U**T*U or L*L**T computed by PSPOTRF." */
/* OPTIONS */
{
extern void FortranCall(pspotrs)( char*, int*, int*,
			       float*, int*, int*, int*,
			       float*, int*, int*, int*,
			       int*);
	int maxldd;

	int maxlda;
	float *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
	int row_loca, col_loca;

	int maxldb;
	float *locb=NULL;
	int descb[DESCLEN];
	int desc_gb[DESCLEN];
	int row_locb, col_locb;

	INITIALIZE();

	SCALAR( "char", uplo);
	SCALAR( "int", n);
	SCALAR( "int", nrhs);
	SCALAR( "int", lda);
	SCALAR( "int", ldb);

	ROW( a);
	COL( a);
	ROW( b);
	COL( b);
	MAXLDD( maxldd, a );
	maxlda = maxldd;
	maxldb = maxldd;
        
	MATRIX( "float", a, ROW_a, COL_a);
        DISTRIBUTE( "float", a, ROW_a, COL_a);
        
	MATRIX( "float", b, ROW_b, COL_b);
	DISTRIBUTE( "float", b, ROW_b  , COL_b);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pspotrs)( &uplo, &n, &nrhs,
                               loca, &one, &one, desca,
                               locb, &one, &one, descb,
                               &linfo);

	GATHER( "float", b, ROW_b, COL_b);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
		*info = linfo;
	} else {
	}

	FREE_MATRIX(a);
	FREE_MATRIX(b);
}

