package bricks.util;
import bricks.environment.*;
import java.util.*;

public class QueueTimeSharingForDisk extends QueueTimeSharing {

    public QueueTimeSharingForDisk (Sequence throughput, double timeSlice) {
	super(throughput, timeSlice);
    }

/************************* needed method *************************/
    public String getName() {
	return "QueueTimeSharingForDisk";
    }

/************************* overridden method *************************/
    public boolean processEvent(double currentTime) {return false;}

    /* callee: Disk */
    public boolean processEventForPackets(double currentTime) {
	if (currentTop.finish) {
	    SimulationDebug.println(
		"QueueTimeSharingForDisk: " + currentTime + " : dequeue");
	    top().updateDataSize(
		currentTop.data.getDataSize() - currentTop.sentDataSize
	    );
	    dequeue(currentTime);
	    return true;
	} else {
	    SimulationDebug.println(
		"QueueTimeSharingForDisk: " + currentTime+" : changeQueueTop");
	    changeQueueTop(currentTime);
	    return false;
	}
    }

    /* callee: Disk */
    public boolean sendOnePacket(
	double currentTime, TrafficData data, double packetSize
    ) {
	int index = queue.indexOf(currentTop);
	if (index == queue.size() - 1)
	    index = 0;
	else
	    index++;

	EnqueuedData d = (EnqueuedData)queue.elementAt(index);
	if (data.getDataSize() - d.currentDataSize - 
	    d.nextProcessedDataSize - d.sentDataSize > packetSize) {
	    d.sentDataSize += packetSize;
	    return true;
	} else {
	    return false;
	}
    }
}
