package ninf.client;

import org.gridforum.gridrpc.*;
import ninf.basic.*;
import java.util.*;
import java.io.*;


public class LocalGrpcHandle extends GrpcHandle{
  protected NinfConnection con;
  protected NinfStub stub;

  LocalGrpcHandle(String executableName) throws GrpcException{
    try {
      con = new NinfLocalConnection(executableName);
      stub = con.getStub(null);
    } catch (NinfException e){
      throw new GrpcException(e);
    }
  }

  public GrpcExecInfo call(List args) throws GrpcException{
    NinfExecInfo execInfo;
    if (con == null)
      throw new GrpcException(new NinfException("connection closed"));
    try {
      execInfo = con.callBody(stub, (Vector)args);
    } catch (NinfException e){
      throw new GrpcException(e);
    }
    return new NinfGrpcExecInfo(execInfo);
  }

  public void cancel() throws GrpcException{
    // not implemented
  }

  public void dispose() throws GrpcException{
    finalize();
  }

  protected void finalize() throws GrpcException{
    try {
      if (con != null){
	con.close();
	con = null;
      }
    } catch (NinfException e){
      throw new GrpcException(e);
    }
  }
}
