#define _WRAPPER_
/* $Id: pzdotu.c_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define DCOMPLEX
#include <gscalapack.h>

void  pzdotu_ninf(
	       int n,
	       dcomplex *dotu,
	       dcomplex global_x[],
	       int incx,
	       dcomplex global_y[],
	       int incy
)
/* "PZDOTC forms the dot product of two distributed vectors,\\n\\n     dotc := sub( X )**H * sub( Y )\\n\\n where sub( X ) denotes X(IX,JX:JX+N-1) if INCX = M_X,\\n                         X(IX:IX+N-1,JX) if INCX = 1 and INCX <> M_X,\\n\\n        sub( Y ) denotes Y(IY,JY:JY+N-1) if INCY = M_Y,\\n                         Y(IY:IY+N-1,JY) if INCY = 1 and INCY <> M_Y." */
/* OPTIONS */
{
	int maxldd;

	dcomplex *locx;
	int descx[DESCLEN], desc_gx[DESCLEN];
	int maxldx;
	int row_locx, col_locx;
	int ROW_x, COL_x;

	dcomplex *locy;
	int descy[DESCLEN], desc_gy[DESCLEN];
	int maxldy;
	int row_locy, col_locy;
	int ROW_y, COL_y;
	

	INITIALIZE();

	SCALAR( "int", n);
	SCALAR( "int", incx);
	SCALAR( "int", incy);

	square( 1+(n-1)*abs(incx), &ROW_x, &COL_x);
	square( 1+(n-1)*abs(incy), &ROW_y, &COL_y);

	ROW(x );
	COL(x );
	MAXLDD(maxldd,x );
	maxldx=maxldd;

	ROW(y );
	COL(y );
	MAXLDD(maxldd,y );
	maxldy=maxldd;

	MATRIX( "dcomplex", x, ROW_x, COL_x);
	DISTRIBUTE( "dcomplex", x, ROW_x, COL_x);
	MATRIX( "dcomplex", y, ROW_y, COL_y);
	DISTRIBUTE( "dcomplex", y, ROW_y, COL_y);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pzdotu)(&n, &dotu, locx, &one, &one, descx, &incx, locy, &one, &one, descy, &incy);

	RETRIEVE( "dcomplex", dotu, 1);

	if( mypnum == 0 ){

	} else {
	}

	return;
}

