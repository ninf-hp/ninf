#define _WRAPPER_
/* $Id: pcunmtr_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define SCOMPLEX
#include <gscalapack.h>
#define ROW_a lda
#define COL_a col_a
#define ROW_c ldc
#define COL_c n
static	int worklen(char side, char uplo, int m, int n) {
	  int ret=1;
	  int LCM, LCMP;
	  int LCMQ, IROFFA, ICOFFA, IAROW, NpA0;
	  int IROFFC, ICOFFC, ICROW, ICCOL, MpC0, NqC0;
	  int IAA, JAA, ICC, JCC;
	  int MI, NI;
	  int max_m_n;
	  max_m_n = max(m, n);
	  ret = MAX( (max_m_n*(max_m_n-1))/2, 2*max_m_n*max_m_n ) +
	      max_m_n * max_m_n;

	  if (mypnum==0) {
	    LCM = LCM( NPROW, NPCOL );
	    LCMQ = LCM / NPROW ;
	    LCMQ = LCM / NPCOL ;


	    if (chrcmp(uplo,'U')==0) 
	      {IAA = IA; JAA = JA+1; ICC = IC; JCC = JC;}
	    else if (chrcmp(uplo, 'L')==0)
	      {IAA = IA+1; JAA = JA;}
	    if (chrcmp(side,'L')==0)
	      {ICC = IC+1; JCC = JC;}
	    else
	      {ICC = IC; JCC = JC+1;}

	    IROFFA = MOD( IAA-1, MB_A ); ICOFFA = MOD( JAA-1, NB_A );
	    IAROW = INDXG2P( IAA, MB_A, MYROW, RSRC_A, NPROW );
	    NpA0 = NUMROC( NI+IROFFA, MB_A, MYROW, IAROW, NPROW );

	    IROFFC = MOD( ICC-1, MB_C ); ICOFFC = MOD( JCC-1, NB_C );
	    ICROW = INDXG2P( ICC, MB_C, MYROW, RSRC_C, NPROW );
	    ICCOL = INDXG2P( JCC, NB_C, MYCOL, CSRC_C, NPCOL );
	    MpC0 = NUMROC( MI+IROFFC, MB_C, MYROW, ICROW, NPROW );
	    NqC0 = NUMROC( NI+ICOFFC, NB_C, MYCOL, ICCOL, NPCOL );
	    

	    if (chrcmp(side,'L')==0)
	      {MI = M-1; NI = N;
	      ret = MAX( (NB_A*(NB_A-1))/2, (NqC0 + MpC0)*NB_A ) +
		NB_A * NB_A;}
	    else if (chrcmp(side,'R')==0)
	      {MI = M; MI = N-1;
	      ret = MAX( (NB_A*(NB_A-1))/2, ( NqC0 + MAX( NpA0 +
              NUMROC( NUMROC( NI+ICOFFC, NB_A, 0, 0, NPCOL ),
                      NB_A, 0, 0, LCMQ ), MpC0 ) )*NB_A ) +
		NB_A * NB_A;}
	  }
	  return ret;
}

static	int taulen(char side, char uplo, int m, int n, int lda, int col_a) {
	  int ret;
	  if ((chrcmp(side,'L') == 0) && (chrcmp(uplo,'U') == 0)) ret = ROW_a;
	  if ((chrcmp(side,'L')==0) && (chrcmp(uplo,'L') == 0)) ret = m-1;
	  if ((chrcmp(side,'R') ==0 ) && (chrcmp(uplo,'U') == 0))  ret = COL_a;
	  if ((chrcmp(side,'R') == 0) && (chrcmp(uplo,'L') == 0))  ret = n-1;
	  return ret;
}


void  pcunmtr_ninf(	 char side,
		 char uplo,
		 char trans,
		 int m,	/*  m >= 0 */
		 int n,	/*  n >= 0 */
		 scomplex global_a[],
		 int lda,
		 scomplex global_tau[],
		 scomplex global_c[],
		 int ldc,
		 scomplex work[],
		 int lwork,
		 int *info
)
/* "pcunmtr overwrites the general complex M-by-N distributed matrix C  with\\n */
/*                        SIDE = 'L'           SIDE = 'R'\\n */
/*   TRANS = 'N':           Q *  C               C * Q\\n */
/*   TRANS = 'C':      Q**H * C                  C * Q**H\\n */
/* where Q is a complex unitary distributed matrix of order nq, with nq = m if SIDE = 'L' and nq = n if SIDE = 'R'. Q is defined as the product of nq-1 elementary reflectors, as returned by PCHETRD:\\n */
/*  if UPLO = 'U', Q = H(nq-1) . . . H(2) H(1);\\n */
/*  if UPLO = 'L', Q = H(1) H(2) . . . H(nq-1)." */
/* OPTIONS */
{
	int maxldd;

	int col_a;
	int maxlda;
	scomplex *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
	int row_loca, col_loca;

	scomplex *loctau=NULL;

	int maxldc;
	scomplex *locc=NULL;
	int descc[DESCLEN];
	int desc_gc[DESCLEN];
	int row_locc, col_locc;

	scomplex *locwork=NULL;
	int llocwork;

	INITIALIZE();

	SCALAR("char",side);
	SCALAR("char",uplo);
	SCALAR("char",trans);
	SCALAR("int",m);
	SCALAR("int",n);
	SCALAR("int",lda);
	SCALAR("int",ldc);
	SCALAR("int",lwork);

	if (chrcmp(side,'L')==0) col_a = m;
	col_a = n;

	ROW(a );
	COL(a );
	ROW(c);
	COL(c);
	MAXLDD(maxldd,a );
	maxlda=maxldd;
	maxldc=maxldd;

	MATRIX("scomplex",a,ROW_a  ,COL_a );
	DISTRIBUTE("scomplex", a, ROW_a , COL_a );

	MATRIX("scomplex",c, ROW_c , COL_c);
	DISTRIBUTE("scomplex", c,ROW_c  , COL_c );

	VECTOR("c","scomplex",tau,taulen( side, uplo, m, n, lda, col_a));
	vDISTRIBUTE("c","scomplex", tau, taulen( side, uplo, m, n, lda, col_a));

	llocwork=worklen(side, uplo, m, n);
	llocwork = max(lwork,llocwork);
	WORK(locwork,llocwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pcunmtr)( &side, &uplo, &trans,
                               &m, &n,
                               loca, &one, &one, desca,
                               loctau,
                               locc, &one, &one, descc,
                               locwork, &llocwork, &linfo);

	GATHER("scomplex", c,ROW_c, COL_c);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
		*info = linfo;
	} else {

	}

	FREE_MATRIX(a);
	FREE_VECTOR(tau);
	FREE_MATRIX(c);
	FREE(locwork);
        
}

