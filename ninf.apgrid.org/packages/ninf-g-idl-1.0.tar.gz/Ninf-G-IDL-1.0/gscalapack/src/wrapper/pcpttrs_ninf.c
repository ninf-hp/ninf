#define _WRAPPER_
/* $Id: pcpttrs_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define _DISTRIBUTE_1D_
#define _REAL_DIAGONAL_
#define SCOMPLEX
#include <gscalapack.h>

#define ROW_b ldb
#define COL_b nrhs
static	int worklen(int nrhs) {
	  int ret=1;
	  ret = (10+2*min(100,nrhs))+4*nrhs;
	  if (mypnum!=0) {
              ret = (10+2*min(100,nrhs))*npcol+4*nrhs;
	  }
	  return ret;
}

void  pcpttrs_ninf(	 int n,
		 int nrhs,
		 float global_d[],
		 scomplex global_e[],
		 scomplex global_b[],
		 int ldb,
		 int *info
)
/* "pcpttrs solves a system of linear equations A * X = B where A is the matrix used to produce the factors stored in A and AF by PCPTTRF. A is an N-by-N complex */
/*  tridiagonal symmetric positive definite distributed matrix." */
/* OPTIONS */
{
extern void FortranCall(pcpttrs)( int*, int*,
                               float*, scomplex*, int*, int*,
                               scomplex*, int*, int*,
                               scomplex*, int*,
                               scomplex*, int*,
				 int*);

	int maxldd;

	float *locd=NULL;
	scomplex *loce=NULL;
	int desctdd[DESCLEN];
	int desc_gtdd[DESCLEN];

	int maxldb;
	scomplex *locb=NULL;
	int descb[DESCLEN];
	int desc_gb[DESCLEN];
	int row_locb, col_locb;

	scomplex *locaf=NULL;
	int laf;

	scomplex *locwork=NULL;
	int llocwork;

	INITIALIZE();

	SCALAR( "int", n);
        SCALAR("int",ldb);
	SCALAR( "int", nrhs);
	SIZE(n);

	ROW(b);
	COL(b);
	MAXLDD( maxldd, b );
	maxldb=maxldd;

	tdMATRIX( "scomplex", e, d, e, n);
	MATRIX( "scomplex", b, ROW_b, COL_b);
	tdDISTRIBUTE( "scomplex", e, d, e, n);
	DISTRIBUTE("scomplex", b, ROW_b, COL_b);

        laf=blocsize+2;
        if (serial==1) laf=n+2;
        locaf=MALLOC(sizeof(scomplex)*laf);
        assert(locaf);
        
	llocwork = worklen(nrhs);
	WORK(locwork, llocwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pcpttrs)( &n, &nrhs,
                               locd, loce, &one, desctdd,
                               locb, &one, descb,
                               locaf, &laf,
                               locwork, &llocwork, &linfo);

	GATHER( "scomplex", b, ROW_b, COL_b);
        tdGATHER( "scomplex", e, d, e, n);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
		*info = linfo;
	} else {
	}
	FREE_MATRIX(d);
	FREE_MATRIX(e);
	FREE_MATRIX(b);
	FREE(locaf);
        FREE(locwork);
}

