package ninf.MetaServer;

public interface Stoppable{
  public void stop();
}
