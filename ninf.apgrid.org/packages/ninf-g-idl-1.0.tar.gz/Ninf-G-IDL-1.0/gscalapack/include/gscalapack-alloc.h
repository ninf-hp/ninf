#ifndef _GSCALAPACK_ALLOC_H_
#define _GSCALAPACK_ALLOC_H_

#ifdef _LOCAL_
extern void _matrix_alloc( const char *, int, int, void*, int*, void**, int*, int, int, int*);
extern void _matrix_alloc1d( const char*, int, int, void*, int*, void**, int*, int, int, int *);
extern void _tdmatrix_alloc( const char*, const char*, const char*, int, void*, void*, void*, int*, void**, void**, void**, int*, int*);
extern void _bandmatrix_alloc( const char*, int, int, int, void*, int*, void**, int*, int , int, int*);
extern void _vector_alloc( char *rowcol, const char *type, int size, void *global, void **plocal);
extern void _free_matrix(void*);
extern void _work( char*, void**, int);
extern void _ipiv( int**, int);
#endif

#ifndef _DISTRIBUTE_1D_
#define MATRIX( type, a, m, n)  \
                _matrix_alloc( type, \
                               m, n, \
                            global_##a, \
                             desc_g##a, \
                               (void**)&loc##a, \
                               desc##a, \
                               col_loc##a, \
                              maxld##a, \
                              &linfo \
)
#else
#define MATRIX( type, a, m, n)         \
                _matrix_alloc1d( type, \
                               m, n, \
                            global_##a, \
                             desc_g##a, \
                               (void**)&loc##a, \
                               desc##a, \
                               row_loc##a, \
                              maxld##a, \
                             &linfo \
)

#endif

#define trMATRIX( uplo, type, a, m, n) MATRIX( type, a, m, n)

#if defined(_DISTRIBUTE_1D_)
#if defined(_REAL_DIAGONAL_) && defined(SCOMPLEX)
#define DIAG_TYPE "float"
#endif
#if defined(_REAL_DIAGONAL_) && defined(DCOMPLEX)
#define DIAG_TYPE "double"
#endif

#define global_0 NULL
#define loc0 zero
#if defined(_REAL_DIAGONAL_)
#define tdMATRIX( type, dl, d, du, n) \
               _tdmatrix_alloc( type, \
                            DIAG_TYPE, \
                                type, \
                                   n, \
                         global_##dl, \
                         global_##d,  \
                         global_##du, \
                         desc_gtd##d, \
                    (void**)&loc##dl, \
                     (void**)&loc##d, \
                    (void**)&loc##du, \
                           desctd##d, \
                              &linfo  \
)
#else
#define tdMATRIX( type, dl, d, du, n) \
               _tdmatrix_alloc( type, \
                                type, \
                                type, \
                                   n, \
                         global_##dl, \
                         global_##d,  \
                         global_##du, \
                         desc_gtd##d, \
                    (void**)&loc##dl, \
                     (void**)&loc##d, \
                    (void**)&loc##du, \
                           desctd##d, \
                              &linfo  \
)
#endif
#endif

#ifdef _DISTRIBUTE_1D_
#define bandMATRIX( type, a,  bwl, bwu, size) \
{                                            \
 SCALAR("int", ld##a);                         \
 _bandmatrix_alloc( type,                    \
		    size,                    \
		    bwl,                     \
		    bwu,                     \
		    (void*)global_##a,              \
		    desc_g##a,               \
		    (void**)&loc##a,         \
		    desc##a,                 \
                    ld##a,                   \
                    PIVOTING,                \
		    &linfo                   \
		    );                       \
} ;
#endif

#define VECTOR( rowcol, type, v, size)_vector_alloc( rowcol, type, size, global_##v, (void**)&loc##v);

#define FREE_MATRIX(a) {if (loc##a!=NULL) _free_matrix(loc##a);}
#define FREE_VECTOR(a) {if (loc##a!=NULL) _free_matrix(loc##a);}
#define FREE(a)        {if (a!=NULL) free(a);}


#ifdef FLOAT
#define WORK( w, l) _work( "float", (void**)&w, l)
#endif
#ifdef DOUBLE
#define WORK( w, l) _work( "double", (void**)&w, l)
#endif
#ifdef SCOMPLEX
#define WORK( w, l) _work( "scomplex", (void**)&w, l)
#endif
#ifdef DCOMPLEX
#define WORK( w, l) _work( "dcomplex", (void**)&w, l)
#endif

#define IWORK( w, l) _work( "int", (void**)&w, l)


#define IPIV(i,length) _ipiv(&i, length)

#endif
