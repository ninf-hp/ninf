package ninf.netsolve;

import ninf.basic.*;
import java.io.*;

public class ServerInfo {
  public String name;
  public byte ip_addr[];
  public int data_format;
  public int expected;
  public int speed;
  public int number_proc;
  public int mpp;

  public int host_status;
  public int server_status;


  public int workload;


  public String problems[];

  public ServerInfo() {
    name = null;
    ip_addr = new byte[4];
    data_format = 0;
    expected = 0;
  }

  public void ipRead(XDRInputStream is) throws IOException{
    for (int i = 0; i <4; i++){
      ip_addr[i] = (byte)is.readInt();
    }
  }

  public void ipWrite(XDROutputStream os) throws IOException{
    for (int i = 0; i <4; i++){
      os.writeInt(ip_addr[i]);
    }
  }

  public static ServerInfo readFull(XDRInputStream is) throws NinfException{
    ServerInfo tmp = new ServerInfo();
    try {
      tmp.name = is.readString();
      tmp.ipRead(is);
      tmp.data_format = is.readInt();
      tmp.speed = is.readInt();
      tmp.host_status = is.readInt();
      tmp.server_status = is.readInt();
      tmp.workload = is.readInt();
      tmp.number_proc = is.readInt();
      tmp.mpp= is.readInt();
      
      int nproblem = is.readInt();
      tmp.problems = new String[nproblem];
      for (int i = 0; i < nproblem; i++)
	tmp.problems[i] = is.readString();

    } catch (IOException e){
      throw new NinfIOException();
    }
    return tmp;
  }

  public void writeTo(XDROutputStream os) throws NinfException{
    try {
      os.writeString(name);
      ipWrite(os);
      os.writeInt(data_format);
      os.writeInt(speed);
      os.writeInt(workload);
      os.writeInt(number_proc);
      os.writeInt(mpp);
    } catch (IOException e){
      throw new NinfIOException();
    }
  }

}
