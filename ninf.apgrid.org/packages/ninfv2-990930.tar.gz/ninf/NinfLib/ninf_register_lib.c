#include <stdio.h>
#include "ninf_error.h"
#include "ninf_serv_reg.h"

static int myread(int sock, char * reg_pkt_buf, int size){
  int n, readed = 0;

  while (readed < size){
    if ((n = read(sock, reg_pkt_buf + readed, size - readed)) <= 0)
      return n;
    readed += n;
  }
  return size;
}

static int ninf_reg_recv_gen(int sock, char *reg_pkt_buf, int server){
  int n;
  if((n = myread(sock,reg_pkt_buf,NINF_REG_PKT_SIZE)) 
     != NINF_REG_PKT_SIZE){
    if (!(server && n == 0))
      ninf_log("Failed to receive reg. packet. n=%d\n",n);
    return FALSE;
  }
  return TRUE;
}

int ninf_reg_recv(int sock, char *reg_pkt_buf){
  return ninf_reg_recv_gen(sock, reg_pkt_buf, FALSE);
}

int ninf_reg_recv_server(int sock, char *reg_pkt_buf){
  return ninf_reg_recv_gen(sock, reg_pkt_buf, TRUE);
}

int ninf_reg_send(int sock, char *reg_pkt_buf){
  int n;

  if((n = write(sock,reg_pkt_buf,NINF_REG_PKT_SIZE)) 
     != NINF_REG_PKT_SIZE){
    ninf_log("Failed to send reg. packet.  n=%d\n",n);
    return FALSE;
  }
  return TRUE;
}
