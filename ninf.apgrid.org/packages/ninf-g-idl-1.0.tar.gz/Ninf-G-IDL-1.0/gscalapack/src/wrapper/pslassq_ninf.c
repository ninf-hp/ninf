#define _WRAPPER_
/* $Id: pslassq_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define FLOAT
#include <gscalapack.h>

void  pslassq_ninf(	 int n,
		 float global_x[],
		 int incx,
		 float *scale,
		 float *sumsq
)
/* "pslassq returns the values  scl  and  smsq  such that ( scl**2 )*smsq = x( 1 )**2 +...+ x( n )**2 + ( scale**2 )*sumsq, where  x( i ) X( IX+(JX-1)*DESCX(M_)+(i-1)*INCX ). The value of sumsq is assumed to be non-negative and scl returns the value scl = max( scale, abs( x( i ) ) )." */
/* OPTIONS */
{
	int maxldd;

	int maxldx;
	float *locx=NULL;
	int descx[DESCLEN];
	int desc_gx[DESCLEN];
	int row_locx, col_locx;
	int ROW_x, COL_x;

	float lscale[1];
	float lsumsq[1];

	INITIALIZE();

	SCALAR("int", n);
	SCALAR("int",incx);

	COMMON("float", scale, 1);
	COMMON("float", sumsq, 1);

	*lscale=*scale;
	*lsumsq=*sumsq;

	square(n, ROW_x, COL_x);
	if (incx!=1) incx=ROW_x;

	ROW(x);
	COL(x);
	MAXLDD( maxldd, x );
	maxldx=maxldd;

	MATRIX("float", x, ROW_x, COL_x);
	DISTRIBUTE("float", x, ROW_x, COL_x);

	if  (( mypnum != 0 ) ^ (serial==1) ) {
	 FortranCall(pslassq)( &n,
			       locx, &one, &one, descx,
			       &incx,
			       &lscale, &lsumsq);
	  Csgsum2d( PARA_CTXT, "A", MPI_TOP, 1, 1, lscale, 1, 0, 1);
	  Csgsum2d( PARA_CTXT, "A", MPI_TOP, 1, 1, lsumsq, 1, 0, 1);
	}

	RETRIEVE("float", &lscale, 1);
	RETRIEVE("float", &lsumsq, 1);

	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
	  *scale=*lscale;
	  *sumsq=*lsumsq;
	} else {
	}
        FREE_COMMON(scale);
        FREE_COMMON(sumsq);
        FREE_MATRIX(x);

}

