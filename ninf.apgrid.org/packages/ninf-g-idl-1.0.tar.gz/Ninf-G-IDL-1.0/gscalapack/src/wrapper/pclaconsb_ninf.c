#define _WRAPPER_
/* $Id: pclaconsb_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define SCOMPLEX
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n
static	int buflen(int i) {
	  int ret=1;
	  ret = 15;
	  if NEED_BUFF {
	    ret = 7*ceil( ceil( (i-l),MB_A ) , LCM(nprow,npcol) );
	  }
	  return ret;
}

void  pclaconsb_ninf(
		  scomplex global_a[],
		  int lda,
		  int n,
		 int i,
		 int l,
		  int *m,
		 scomplex  h44,
		 scomplex  h33,
		  scomplex h43h34,
		 scomplex global_buf[],
		 int lwork
)
/* "pclaconsb looks for two consecutive small subdiagonal elements by seeing the effect of starting a double shift QR iteration given by H44, H33, & H43H34 and see if this would make a subdiagonal negligible." */
/* OPTIONS */
{
	int maxldd;

	int locm[1];

	int maxlda;
	scomplex *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
	int row_loca, col_loca;

	scomplex *locbuf=NULL;
	int llocbuf;


	INITIALIZE();

	SCALAR("int",lda);
	SCALAR("int",n);
	SCALAR( "int", i);
	SCALAR( "int", l);
        SCALAR( "int", lwork);
	SCALAR( "scomplex", h44);
	SCALAR( "scomplex", h33);
	SCALAR( "scomplex", h43h34);

	ROW(a);
	COL(a);
	MAXLDD( maxldd, a );
	maxlda = maxldd;

	MATRIX( "scomplex", a, ROW_a, COL_a);
	DISTRIBUTE("scomplex", a, ROW_a, COL_a);

	llocbuf=buflen(i);
        llocbuf=max(lwork,llocbuf);
	WORK( locbuf, llocbuf);

	if  (( mypnum != 0 ) ^ (serial==1) )
	  FortranCall(pclaconsb)( loca, &desca,
                                  &i, &l,
                                  locm,
                                  &h44, &h33, &h43h34,
                                  locbuf, &llocbuf);

	RETRIEVE("int", locm, 1);
	RETRIEVE("int", &llocbuf, 1);

	RETRIEVE("scomplex", locbuf, min(lwork,llocbuf));
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
	  int i;
	  for(i=0;i<min(lwork,llocbuf);i++) global_buf[i]=locbuf[i];
	  *m = *locm;
	} else {
		
	}
	FREE_MATRIX(a);
	FREE(locbuf);
}

