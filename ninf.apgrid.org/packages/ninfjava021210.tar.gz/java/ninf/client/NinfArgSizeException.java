package ninf.client;
import ninf.basic.NinfException;

public
class NinfArgSizeException extends NinfException {
  public int argNum = 0;
  public int size;
  public int accessing;
  public int dimension;

  public NinfArgSizeException(int size, int accessing, int dimension){
    this.size = size;
    this.accessing = accessing;
    this.dimension = dimension;
  }

  public String toString(){
    return "Arg no." + argNum + " dim. " + dimension + " access error. " +
      "Accessing " + accessing + " th elem, while the size is " + size + ".";
  }
}
