#define _WRAPPER_
/* $Id: pdlarfg_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define DOUBLE
#include <gscalapack.h>

void  pdlarfg_ninf(	 int n,
		 double *alpha,
#ifdef HAVE_ABS                
		 double global_x[],
#else
                 double global_x[],
#endif                
		 int incx,
		 double *global_tau
)
/* "pdlarfg generates a real elementary reflector H of order n, such that H * X = =  alpha,   H' * H = I." */
/* OPTIONS */
{
	int maxldd;

	int maxldx;
	double *locx=NULL;
	int lx;
	int ROW_x, COL_x;
	int descx[DESCLEN];
	int desc_gx[DESCLEN];
	int row_locx, col_locx;

	int iax = 1;
	int jax = 1;

	int ix=1;
	int jx=2;

	double loctau[1];

	INITIALIZE();

	SCALAR( "int", n);
	SCALAR("int", incx);

	COMMON( "double", alpha, 1);

#ifdef HAVE_ABS        
	square(1+(n-1)*abs(incx), &ROW_x, &COL_x);
#else
        square(1+(n-1)*(incx), &ROW_x, &COL_x);
#endif        
	ROW(x);
	COL(x);
	MAXLDD( maxldd, x);
	maxldx = maxldd;
	
	MATRIX( "double", x, ROW_x, COL_x);
	DISTRIBUTE( "double", x, ROW_x, COL_x);

	locx[(iax-1)+(jax-1)*n] = *alpha;	

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pdlarfg)( &n, alpha,
			       &iax, &jax,
			       locx, &ix, &jx, descx,
			       &incx,
			       loctau);

	GATHER( "double", x, ROW_x, COL_x);

	RETRIEVE("double", alpha, 1);
	RETRIEVE("double", loctau,1);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
	  *global_tau = loctau[0]; 
	} else {

	}
        
        FREE_COMMON(alpha);
	FREE_MATRIX(x);
}

