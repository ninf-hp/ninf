#define _WRAPPER_
/* $Id: psorg2l_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define FLOAT
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n
static	int worklen(int m, int n) {
	  int ret=1;
	  int IROFFA, ICOFFA, IAROW, IACOL, MpA0, NqA0;
	  ret = m + max(1,n);
	  if NEED_BUFF {
	    IROFFA = MOD( IA-1, MB_A );
	    ICOFFA = MOD( JA-1, NB_A );
	    IAROW = INDXG2P( IA, MB_A, MYROW, RSRC_A, NPROW );
	    IACOL = INDXG2P( JA, NB_A, MYCOL, CSRC_A, NPCOL );
	    MpA0 = NUMROC( M+IROFFA, MB_A, MYROW, IAROW, NPROW );
	    NqA0 = NUMROC( N+ICOFFA, NB_A, MYCOL, IACOL, NPCOL );
	    ret = MpA0 + MAX( 1, NqA0 );
	  }
	  return ret;
}

void  psorg2l_ninf(	 int m,
		 int n,
		 int k,
		 float global_a[],
		 int lda,
		 float global_tau[],
		 float work[],
		 int *info
)
/* "psorg2l generates an M-by-N real distributed matrix Q with orthonormal columns, which is defined as the last N columns of a product of K elementary reflectors of order M\\n  Q  =  H(k) ." */
/* OPTIONS */
{
	int maxldd;

	int maxlda;
	float *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
	int row_loca, col_loca;

	float *loctau=NULL;

	float *locwork=NULL;
	int llocwork;


	INITIALIZE();

	SCALAR( "int", m);
	SCALAR( "int", n);
	SCALAR( "int", k);
	SCALAR("int", lda);

	ROW(a);
	COL(a);
	MAXLDD( maxldd, a );
	maxlda = maxldd;

	MATRIX( "float", a, ROW_a, COL_a);
	DISTRIBUTE( "float", a, ROW_a  , COL_a);
	VECTOR( "c", "float", tau, n);
	vDISTRIBUTE("c", "float", tau, n);
	
	llocwork=worklen(m, n);
	WORK(locwork,llocwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(psorg2l)( &m, &n, &k,
                               loca, &one, &one, desca,
                               loctau,
                               locwork, &llocwork,
                               &linfo);

	GATHER( "float", a, ROW_a  , COL_a);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
		*info = linfo;
	} else {
		
	}
	FREE_MATRIX(a);
	FREE_VECTOR(tau);
        FREE(locwork);
	
}

