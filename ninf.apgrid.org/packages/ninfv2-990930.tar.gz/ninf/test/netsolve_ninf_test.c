/*
 * Test program for NetSolve.
 *
 *    This program is testing the C interface to NetSolve
 *
 */

#define NB_REQUESTS 5
#define SIZE 2
#include <stdio.h>
#include <sys/time.h>

char * malloc(int size);


#include "netsolve.h"

#include "ninf_stub.h"


struct timeval tp[2];

main(argc,argv)
int argc;
char **argv;
{
  int m;              /* Size of the matrix and right-hand side           */
  double *a1,*b1, *a2, *b2;
                      /* Matrix and right-hand side for the linear system */
  int info;           /* NetSolve error code                         */
  int request;        /* NetSolve request handler                    */

  int requests[NB_REQUESTS];
  int go_on;
  
  int A,B;
  int success = FALSE;
  int i;              /* Loop index                                  */
  int init=1325;      /* Seed of the random number generator         */

  argc = Ninf_parse_arg(argc, argv);

  /*
   * Generating the random mxm matrices, as well as the
   * random right hand sides.
   */

  fprintf(stdout,"** Test #1 : Blocking call to 'dgesv' **\n");

  if (argc > 1)
    m = atoi(argv[1]);
  else
    m = 50;
  printf("m = %d\n", m);
  a1 = (double *)malloc(m*sizeof(double));
  a2 = (double *)malloc(m*sizeof(double));

  for (i=0;i<m;i++) {
    init = 2315*init % 65536;
    a1[i] = (double)((double)init - 32768.0) / 16384.0;
    a2[i] = (double)((double)init - 32768.0) / 16384.0;
  }

  b1 = (double *)malloc(m*sizeof(double));
  b2 = (double *)malloc(m*sizeof(double));

  /***********/
  /* TEST #1 */
  /***********/
  /* Calling Netsolve for 'dgesv' in a blocking fashion */
  /* For 'dgesv', the right-hand side is overwritten    */
  /* with the solution                                  */

  gettimeofday(&tp[0], NULL);

  fprintf(stdout,"netsolve with adapter\n");
  info = netsl("test/double_test()",m ,a1, b1);
  if (info <0)
  {
    netslerr(info);
    fprintf(stdout,"** Failure **\n");
    exit(3);
  }
  gettimeofday(&tp[1], NULL);
  printf("NetSolve %d ", m);
  print_time(tp);

  gettimeofday(&tp[0], NULL);
  fprintf(stdout,"native ninf adapter\n");
  info = Ninf_call("test/double_test", m, a2, b2);
  if (info != 0)
  {
    Ninf_perror("double_test");
  }
  gettimeofday(&tp[1], NULL);
  printf("Ninf     %d ", m);
  print_time(tp);

  for (i = 0; i < m; i++){
    if (b1[i] != b2[i]){
      printf("b1[%d](%f) != b2[%d](%f)\n",i,b1[i],i,b2[i]);
      success = FALSE;
    }
  }
  if (success)
    fprintf(stdout,"** Success **\n");

}

print_time(struct timeval tp[]){
  unsigned long usec = (tp[1].tv_sec - tp[0].tv_sec) * 1000000L +
    (tp[1].tv_usec - tp[0].tv_usec);
  printf("usec = %ld\n\n", usec);
}
