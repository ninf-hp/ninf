package ninf.client;
import ninf.basic.NinfException;

public class NinfStoppedByUserException extends NinfException {
  public NinfStoppedByUserException(){
    super();
  }
}
