#include <stdio.h>
#include <errno.h>
#include <stdlib.h>
#include <strings.h>
#include <sys/time.h>
#include <unistd.h>

#include "ninf_group.h"
#include "session.h"

extern void   free_str(char *s);
extern char * save_str(char *s);

extern _Ninf_executable_t * ninf_get_executable(char * ninf_stub_entry);

extern any_t          * new_arg(int num);

#define MAX_BUFF_LEN 1000

static void free_group_hosts(nslib_list_t * host_list){
  int i;
  for (i = 0; i < nslib_list_size(host_list); i++){
    ninf_group_host_t * host = nslib_list_at(host_list, i);
    ninf_group_host_destruct(host);
  }
  nslib_list_destruct(host_list);
}


/********************* STATIC VARIABLES *********************/
static get_host_list_func    GET_HOST;
static char *                HOSTMAP_FILENAME = NULL;
static nslib_list_t *        HOST_LIST = NULL;
static double                LAST_UPDATE;
static double                INTERVAL = 5.0;  /** 20 sec minite **/

/** for host file load **/

static nslib_list_t * read_map_file(){
  FILE * fp;
  char buffer[MAX_BUFF_LEN];
  int counter = 0, i = 0;
  nslib_list_t * host_list;

  if ((fp = fopen(HOSTMAP_FILENAME, "r")) == NULL){
    fprintf(stderr, "cannot open file: %s\n", HOSTMAP_FILENAME);
    perror("fopen:");
    return NULL;
  }
  host_list = nslib_list_new(NULL);

  while (fgets(buffer, MAX_BUFF_LEN, fp) != NULL){
    if (buffer[0] != '#'){
      char * hostname;
      int    port;
      ninf_group_host_t * host;

      hostname = strtok(buffer, " \t\n");
      if (hostname == NULL) continue;
      port = atoi(strtok(NULL, " \t\n"));

      host = ninf_group_host_new(hostname, port);
      nslib_list_add(host_list, host);
    }
  }
  fclose(fp);
  return host_list;
}


static void set_map_filename(char * filename){
  HOSTMAP_FILENAME = filename;
  LAST_UPDATE      = 0.0;
}

static double convert_tv(struct timeval * tv){
  return ((double)(tv->tv_sec)) + tv->tv_usec / 1000000.0;
}

/********************** NINF_GROUP_HOST *******************/

ninf_group_host_t * ninf_group_host_new(char * hostname, int port){
  ninf_group_host_t * host = MY_MALLOC(ninf_group_host_t);
  if (host == NULL)
    return NULL;
  host->hostname = save_str(hostname);
  host->port     = port;
  return host;
}

void ninf_group_host_destruct(ninf_group_host_t * host){
  if (host->hostname != NULL)
    free_str(host->hostname);
  free(host);
}


boolean ninf_group_host_compare( 
  ninf_group_host_t * hostA, 
  ninf_group_host_t * hostB)
{
  if (((strcmp(hostA->hostname, hostB->hostname)) == 0 )
      && hostA->port == hostB->port) 
    return TRUE;
  return FALSE;
}

/*********************  NINF_HOST_MANAGER ********************************/
ninf_host_manager_t * ninf_host_manager_new(ninf_group_host_t * host,
					    char * entry){
  ninf_host_manager_t * manager = MY_MALLOC(ninf_host_manager_t);
  if (manager == NULL)
    return NULL;

  manager->host.hostname = save_str(host->hostname);
  manager->host.port     = host->port;  
  manager->entry         = save_str(entry);
  manager->exe           = NULL;
  manager->sessionID     = 0;
  manager->session       = NULL;
  manager->valid         = TRUE;
  return manager;
}

void ninf_host_manager_destruct(ninf_host_manager_t * manager){
  free_str(manager->host.hostname);
  free_str(manager->entry);
  if (manager->exe != NULL)
    ninf_executable_destruct(manager->exe);
  free(manager);
}

void ninf_host_manager_invalidate(ninf_host_manager_t * manager){
  manager->valid = FALSE;
}

void ninf_host_manager_session_done(ninf_host_manager_t * manager){
  manager->sessionID = 0;
  manager->session   = NULL;
}

boolean ninf_host_manager_connect(ninf_host_manager_t * manager){
  char buff[1000] ;
  sprintf(buff, "ninf://%s:%d/%s", 
	  manager->host.hostname, 
	  manager->host.port,
	  manager->entry);
  manager->exe = ninf_get_executable(buff);
  if (manager->exe == NULL)
    return FALSE;
  return TRUE;
}

static boolean 
ninf_host_manager_call_async(ninf_host_manager_t * manager, va_list *app){
  int ack;
  ninf_session * session;
  if ((session = new_ninf_session_executable(manager->exe)) 
	  == NULL)
	return FALSE;
  session->synchronous = FALSE;
  manager->session = session;
  manager->sessionID = session->id;
  ack = session_do(session, app);
  if (ack == NINF_ERROR){
    ninf_host_manager_session_done(manager);
    return FALSE;
  }
  return TRUE;
}

static boolean 
ninf_host_manager_recall(ninf_host_manager_t * manager, ninf_session * old_session){
  int ack;
  any_t * args;
  ninf_session * session;

  /*  fprintf(stderr, " manager_recall\n"); */

  if ((session = new_ninf_session_executable(manager->exe)) 
	  == NULL)
	return FALSE;
  session->synchronous = FALSE;

  /** remove the session from done list **/
  nslib_list_remove(done_sessions(), old_session);
  /* override sessionID by old id to maintain integrity */
  session->id    = old_session->id;
  args  = new_arg(old_session->stub_info->nparam);
  memcpy(args, old_session->args, 
	 old_session->stub_info->nparam*(sizeof(any_t)));
  /* free old session */
  destruct_ninf_session(old_session);

  manager->session = session;
  manager->sessionID = session->id;
  ack = session_do_v(session, args);
  if (ack == NINF_ERROR){
    ninf_host_manager_session_done(manager);
    return FALSE;
  }
  return TRUE;
}

void ninf_host_manager_print(ninf_host_manager_t * manager, FILE * fp){
  fprintf(fp, "[  %s:%d,", manager->host.hostname, 
	                       manager->host.port);
  fprintf(fp, " %d, %s ]\n", manager->sessionID,
	  manager->valid ? "Valid" : "Invalid");
}


/***********************************************************/

/** returns 
  1 : if updated
  0 : if not updated
 -1 : error
 */
static int update_host_list(){

  {
    nslib_list_t * old_list;
    old_list = HOST_LIST;
    if (GET_HOST == NULL) {
      ninf_error("function to get host map file has not been initialized\n");
      return -1;
    }      
    if ((HOST_LIST = (* GET_HOST)()) == NULL){
      ninf_error("function to get host map file failed. preserve the list\n");      
      HOST_LIST = old_list;
      return 0;
    }
    if (old_list != NULL)  /** release old list **/
      free_group_hosts(old_list);
    return 1;
  }
  return 0;
}

boolean update_managers(_ninf_group_t * gr, char * entry){
  int ack;
  struct timeval tv;
  double now;
  gettimeofday(&tv, NULL);

  now = convert_tv(&tv);
  if (now - LAST_UPDATE < INTERVAL)
    return TRUE;
  LAST_UPDATE = now;

  if ((ack = update_host_list()) < 0)
    return FALSE;

  /*  fprintf(stderr, "updating managers \n");     */

  /*  ninf_group_dump_managers(gr); */

  /** update managers **/
  /** when new hosts are added, add new managers */
  {  
    int i, j;
    nslib_list_t * added_hosts  = nslib_list_new(NULL);

    for (i = 0; i < nslib_list_size(HOST_LIST); i++){
      ninf_group_host_t * host = nslib_list_at(HOST_LIST, i);
      boolean flag = FALSE;

      for (j = 0; j < nslib_list_size(gr->managers); j++){
	ninf_host_manager_t * manager = nslib_list_at(gr->managers, j);
	ninf_group_host_t * mhost = &(manager->host);
	if (ninf_group_host_compare(host, mhost)){
	  flag = TRUE;
	  break;
	}
      }
      if (!flag)
	nslib_list_add(added_hosts, host);
    }

    /*    fprintf(stderr, "added managers size = %d\n", nslib_list_size(added_hosts)); */

    /** add managers **/
    for (i = 0; i < nslib_list_size(added_hosts); i++){
      ninf_group_host_t * host = nslib_list_at(added_hosts, i);      
      ninf_host_manager_t * manager = 
	ninf_host_manager_new(host, gr->entry);
      if (ninf_host_manager_connect(manager))
	nslib_list_add(gr->managers, manager);
      else 
	ninf_host_manager_destruct(manager);
    }
    
    /** clear added_hosts */
    nslib_list_destruct(added_hosts);
  }
  /** when hosts are removed, remove or invalidate the manager */
  {
    int i, j;
    nslib_list_t * tobe_removed = nslib_list_new(NULL);
    
    for (j = 0; j < nslib_list_size(gr->managers); j++){
      ninf_host_manager_t * manager = nslib_list_at(gr->managers, j);
      ninf_group_host_t * mhost = &(manager->host);
      boolean flag = FALSE;
      for (i = 0; i < nslib_list_size(HOST_LIST); i++){
	ninf_group_host_t * host = nslib_list_at(HOST_LIST, i);
	if (ninf_group_host_compare(host, mhost)){
	  flag = TRUE;
	  break;
	}
      }
      if (!flag)
	nslib_list_add(tobe_removed, manager);
    }

    /** remove or invalidate managers **/
    for (i = 0; i < nslib_list_size(tobe_removed); i++){
      ninf_host_manager_t * manager = nslib_list_at(tobe_removed, i);
      if (manager->sessionID == 0)  {/** currently not working */
	ninf_group_remove_manager(gr, manager);
      }
      else
	ninf_host_manager_invalidate(manager);
    }

    /** clear tobe_removed */
    nslib_list_destruct(tobe_removed);
  }
  return TRUE;
}
  
/**************** PUBLIC FUNCTIONS ********************/


/*** setup function to use hostmap file ***/
void ninf_group_setup(char * filename){
  set_map_filename(filename);
  GET_HOST = read_map_file;
}

/*** make a group structure ***/
_ninf_group_t * ninf_group_new(char * entry){
  _ninf_group_t * gr = MY_MALLOC(_ninf_group_t);
  if (gr == NULL)
    return gr;
  gr->managers = nslib_list_new(NULL);
  gr->entry    = save_str(entry);
  gr->session_manager_map 
               = nslib_map_new_default();

  /** initialize host_managers **/

  if (!update_managers(gr, entry))
    return NULL;

  return gr;
}


void ninf_group_remove_manager(
	       _ninf_group_t * gr, 
	       ninf_host_manager_t * manager){
  nslib_list_remove(gr->managers, manager);
  ninf_host_manager_destruct(manager);
}


static ninf_host_manager_t * ninf_group_get_free_manager(_ninf_group_t * gr){
  int i, ack; 
  ninf_host_manager_t * manager;

  update_managers(gr, gr->entry); 

  /* fprintf(stderr, " get free manager\n"); */

  for (i = 0; i < nslib_list_size(gr->managers); i++){
    manager = (ninf_host_manager_t *)nslib_list_at(gr->managers, i);
    if (manager->sessionID == 0 && manager->valid)
      return manager;
  }

  /** if not, wait until someone in the group finishes the call **/
  ack= ninf_group_wait_any(gr, &manager);
  if (ack == NINF_ERROR){
    ninf_error("failed to group_wait_any in call_async");
    return NULL;
  }
  if (ack == NINF_ALL_DONE){
    ninf_error("no session remains in call_async");
    return NULL;
  }
  return manager;
}

/**  call **/
int ninf_group_call_async(_ninf_group_t * gr,  va_list *app){
  /** get free manager **/
  ninf_host_manager_t * manager;

  manager = ninf_group_get_free_manager(gr);
  if (manager == NULL)
    return NINF_ERROR;

  /** if any, make a call using it **/
  if (ninf_host_manager_call_async(manager, app)){
    nslib_map_put(gr->session_manager_map, manager->session, manager);
    return manager->sessionID;
  } else {
    /** failed **/
    /* ninf_host_manager_invalidate(manager); */
    ninf_group_remove_manager(gr, manager);

    return NINF_ERROR;
  } 
}


/**  recall **/
int ninf_group_recall(_ninf_group_t * gr,  ninf_session * sess){
  /** get free manager **/
  ninf_host_manager_t * manager =
    ninf_group_get_free_manager(gr);
  if (manager == NULL)
    return NINF_ERROR;

  /** if any, make a call using it **/
  if (ninf_host_manager_recall(manager, sess)){
    nslib_map_put(gr->session_manager_map, manager->session, manager);
    return manager->sessionID;
  } else {
    /** failed **/
    ninf_group_remove_manager(gr, manager);
    return NINF_ERROR;
  } 
}


int ninf_group_wait_all(_ninf_group_t * gr){
  int flag = TRUE;
  nslib_list_t *sessions;
  ninf_session * sess;
  sessions = nslib_map_keys(gr->session_manager_map);

  while (!session_is_null(sessions)){
    ninf_host_manager_t * manager;

    if ((sess = select_session(sessions, TRUE)) == NULL){
      flag = FALSE;
      break;
    }
    manager = nslib_map_get(gr->session_manager_map, sess);
    nslib_map_remove(gr->session_manager_map, sess);
    nslib_list_remove(sessions, sess);
    if (manager == NULL){
      flag = FALSE;
      break;
    }
    
    /** ERROR CHECK  */
    if (sess->e_info.error_no != NINF_ERROR_NOERROR){
      
      ninf_group_remove_manager(gr, manager);
      ninf_group_recall(gr, sess);
      
      /* reconstruct sessions */
      nslib_list_destruct(sessions);
      sessions = nslib_map_keys(gr->session_manager_map);
      continue;
    } else {
      ninf_host_manager_session_done(manager);
    }
  }
  nslib_list_destruct(sessions);
  if (flag)
    return NINF_OK;
  else
    return NINF_ERROR;
}


/* returns 
   NINF_OK       : normal
   NINF_ALL_DONE : no more sessions 
   NINF_ERROR    : something happend
 */

int ninf_group_wait_any(_ninf_group_t * gr, ninf_host_manager_t ** manager_p){
  int flag = TRUE;
  nslib_list_t * sessions;
  ninf_session * sess;

  /*   fprintf(stderr, "ninf_group_wait_any\n"); */

  sessions = nslib_map_keys(gr->session_manager_map);
  if (session_is_null(sessions)){  /* all done */
    /* fprintf(stderr, "         all done\n"); */
    *manager_p = NULL;
    return NINF_ALL_DONE;
  }
  
  if ((sess = select_session(sessions, TRUE)) == NULL){
    *manager_p = NULL;
    /* fprintf(stderr, "         error1\n"); */
    return NINF_ERROR;
  }
  *manager_p = nslib_map_get(gr->session_manager_map, sess);
  if (*manager_p == NULL) {
    /*    fprintf(stderr, "         error2\n"); */
    return NINF_ERROR;
  }
  ninf_host_manager_session_done(*manager_p);
  nslib_map_remove(gr->session_manager_map, sess);    

  if (sess->e_info.error_no != NINF_ERROR_NOERROR){
    /*    fprintf(stderr, "         error detected. retry\n"); */

    ninf_group_remove_manager(gr, *manager_p);

    ninf_group_recall(gr, sess);
    return ninf_group_wait_any(gr, manager_p);
  }
  /*  fprintf(stderr, "         ok\n"); */
  return NINF_OK;
}

void ninf_group_dump_managers(_ninf_group_t * gr){
  int i;

  for (i = 0; i < nslib_list_size(gr->managers); i++){
    ninf_host_manager_t * manager = nslib_list_at(gr->managers, i);
    ninf_host_manager_print(manager, stderr);
  }
  fprintf(stderr, "----\n");
}

