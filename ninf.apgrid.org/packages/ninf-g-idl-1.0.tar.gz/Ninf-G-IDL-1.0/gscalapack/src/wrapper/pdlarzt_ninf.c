#define _WRAPPER_
/* $Id: pdlarzt_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define DOUBLE
#include <gscalapack.h>

#define ROW_v k
#define COL_v n
#define ROW_t ldt
#define COL_t k
static	int worklen(k) {
	  int ret=1;
	  k=max(1,(k*(k-1)/2));
	  return ret;
}

void  pdlarzt_ninf(	 char direct,
		 char storev,
		 int n,
		 int k,
		 double global_v[],
		 int ldv,
		 double global_tau[],
		 double global_t[],
		 int ldt
)
/* "pdlarzt forms the triangular factor T of a real block reflector H of order > n, which is defined as a product of k elementary reflectors as returned by PSTZRZF." */
/* OPTIONS */
{
	int maxldd;

	int maxldv;
	double *locv=NULL;
	int descv[DESCLEN];
	int desc_gv[DESCLEN];
	int row_locv, col_locv;

	int maxldt;
	double *loct=NULL;
	int desct[DESCLEN];
	int desc_gt[DESCLEN];
	int row_loct, col_loct;

	double *loctau=NULL;

	double *locwork=NULL;
	int llocwork;



	INITIALIZE();

	SCALAR( "char", direct);
	SCALAR( "char", storev);
	SCALAR( "int", n);
	SCALAR( "int", k);
	SCALAR("int", ldv);
	SCALAR("int", ldt);

	ROW(v);COL(v);
	ROW(t);COL(t);
	MAXLDD( maxldd, v );
	maxldv = maxldd;
	maxldt = maxldd;

	MATRIX("double", v, ROW_v, COL_v);
	DISTRIBUTE("double", v, ROW_v, COL_v);

	VECTOR( "r" , "double", tau, k);
	vDISTRIBUTE( "r" , "double", tau, k);
	MATRIX("double", t, ROW_t, COL_t);

	llocwork=worklen(k);
	WORK(locwork,llocwork);
        
	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pdlarzt)( &direct, &storev,
                               &n, &k,
                               locv, &one, &one, descv,
                               loctau,
                               loct,
                               locwork);

	GATHER("double", v, ROW_v, COL_v);
	GATHER("double", t, ROW_t, COL_t);

	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){

	} else {
	}

	FREE_MATRIX(v);
	FREE_MATRIX(t);
	FREE_VECTOR(tau);
        FREE(locwork);
	
}

