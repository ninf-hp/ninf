package ninf.cproxy;
import ninf.basic.*;
import ninf.client.*;
import ninf.cproxy.aggregate.*;
import java.io.*;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;

class CProxyServer extends NServer implements ScheduleProvider{
  boolean lookup = true;

  String myname;
  int myport;
  MetaServerReference metaServer;
  CProxy masterProxy;
  static NinfLog dbg = new NinfLog("CProxyServer");
  StubCache stubCache;
  ServerTable serverTable;
  ProxyScheduler proxyScheduler;
  static int callSerial = 0;
  boolean allowAll;
  IPHostList allowedHosts;
    
  CProxyServer(String myname, int myport, CProxy masterProxy)
  throws NinfException {
    this.myname = myname;
    this.myport = myport;
    this.masterProxy = masterProxy;
    this.metaServer = masterProxy.conf.metaServer;
    this.lookup = masterProxy.conf.lookup;
    NinfServerConnection.lookup = masterProxy.conf.lookup;
    MetaServerConnection.lookup = masterProxy.conf.lookup;
    allowedHosts = masterProxy.conf.allowedHosts;
    allowAll    = masterProxy.conf.allowAll;

    stubCache = new StubCache(this);
    serverTable = new ServerTable(this);
    proxyScheduler = new ProxyScheduler(serverTable, metaServer);
    initialize();
  }

  void initialize() throws NinfException {
    Vector initializers = masterProxy.conf.initializers;
    try {
      for (int i = 0; i < initializers.size(); i++){
        Class initClass = (Class)initializers.elementAt(i);
        ((CProxyInitializer)(initClass.newInstance())).init(masterProxy.conf);
      }
    } catch (IllegalAccessException e){
       throw new ConfigureException("Cannot instantiate Initializer");
    } catch (InstantiationException e){
       throw  new ConfigureException("Cannot instantiate Initializer");
    }
  }


  public ServerIndex schedule(NinfStub stub, CallContext callContext, int serial)
    throws NinfException{
      return proxyScheduler.schedule(stub, callContext, serial);
  }

  public AggregateScheduled aggregateSchedule(FuncNode funcNodes[], 
				       DataNode dataNodes[], int serial)
    throws NinfException{
      return proxyScheduler.aggregateSchedule(funcNodes, dataNodes, serial);
  }

  public void done(int serial) throws NinfException{
    proxyScheduler.done(serial);
  }

  public void addNewServer(NinfServerStructComm server){
    serverTable.addNewServer(server);
  }

  public Callable getCompound(NinfPacket p, XDRInputStream is) 
  throws NinfException {
    Callable func = new CompoundCallable(p, is, stubCache, this, 
					 masterProxy.conf.aggregateSchedule,
					 masterProxy.conf.myServerID);
    int index = stubCache.getIndex();
    func.index = index;
    stubCache.registerCallable(func.getStub().getName(), func, index);
    return func;
  }

  void sendBackStub(Callable callable, XDROutputStream os) throws NinfException {
    NinfPacketOutputStream nos = 
      new NinfPacketOutputStream(os, NinfPktHeader.NINF_PKT_RPY_STUB_INFO, callable.index, 0);
    nos.write(callable.getStub().toByteArray());
    nos.flush();
  }

  void processReqStubInfo(NinfPacket pkt, XDROutputStream os) throws NinfException {
    try {
      String entry = pkt.readString();
      Callable stubCallable = stubCache.getStubCallable(new FunctionName(entry));
      sendBackStub(stubCallable, os);
      return;
    } catch (NinfIOException e) {
      dbg.println("processReqStubInfo: " + e);
      e.printStackTrace();
      return;
    }
  }

  void processReqCompound(NinfPacket pkt,
			  XDRInputStream is, XDROutputStream os) 
  throws NinfException {
    dbg.println("packet: NINF_PKT_REQ_COMPOUND");
    try {
      Callable callable = getCompound(pkt, is);
      dbg.println("processReqCompund:got compound stub");
      sendBackStub(callable, os);
      return;
    } catch (NinfIOException e) {
      dbg.println("processReqCompound: " + e);
      e.printStackTrace();
      return;
    }
  }

  boolean processReqCall(NinfPacket pkt, XDRInputStream is, XDROutputStream os)  
  throws NinfException {
    dbg.println("processReqCall()");
    try {
      NinfPacketOutputStream pos = 
	new NinfPacketOutputStream(os, NinfPktHeader.NINF_PKT_RPY_CALL);
      int serial = getSerial();
      pos.writeInt(serial);
      pos.flush();

      Callable callable = stubCache.getCallable(pkt.hdr.arg1);
      callable.call(pkt, serial, is, os);
      if (!(callable instanceof CompoundCallable))
	done(serial);
      //      if (callable instanceof CompoundCallable)
      //return true;
      return false;
    } finally {
      //      os.flush();
    }
  }

  void processGetTime(NinfPacket pkt, XDRInputStream is, XDROutputStream os)  
  throws NinfException {
    dbg.println("processGetTime()");
    try {
      NinfPacketOutputStream pos = 
	new NinfPacketOutputStream(os, NinfPktHeader.NINF_PKT_RPY_GETTIME);
      pos.writeDouble(System.currentTimeMillis() / 1000.0);
      pos.flush();
    } finally {
      //      os.flush();
    }
  }

  void processKill(NinfPacket pkt, XDRInputStream is, XDROutputStream os)
  throws NinfException {
    dbg.println("packet: NINF_PKT_KILL");
    NinfPacketOutputStream pos = 
      new NinfPacketOutputStream(os, NinfPktHeader.NINF_PKT_RPY_KILL);
    pos.flush();
  }

  /** dispatch jobs according to packet code */
  public boolean dispatchNinfRequest(XDRInputStream is, XDROutputStream os) {
    boolean ret = true;
    NinfPacket pkt = null;
    try {
      pkt = new NinfPacket(is);
    } catch (NinfIOException e) {
      //      dbg.println("dispatchNinfRequst: " + e);
      //e.printStackTrace(dbg.os);
      return false;
    }
    try {
    if (lookup)
      dbg.log("["+myport+"] accept connection from " + clientSocket.getInetAddress());
    else
      dbg.log("["+myport+"] accept connection from " + clientSocket.getInetAddress().getHostAddress());      


      dbg.println("CProxy Read Pkt" + pkt.hdr);
      switch (pkt.hdr.code) {
      case NinfPktHeader.NINF_PKT_REQ_STUB_INFO:
	processReqStubInfo(pkt, os);
	break;

      case NinfPktHeader.NINF_PKT_REQ_COMP:
	processReqCompound(pkt, is, os);
	break;

      case NinfPktHeader.NINF_PKT_REQ_CALL:
	return processReqCall(pkt, is, os);
	
      case NinfPktHeader.NINF_PKT_GETTIME:
	processGetTime(pkt, is, os);
	break;
      case NinfPktHeader.NINF_PKT_KILL:
	processKill(pkt, is, os);
	return false;
      default:
	dbg.log("Unknown Coded Packet " + pkt.hdr.code);
	ret = false;
	break;
      }
    } catch (NinfException e) {
      dbg.println("exception occured in execution " + pkt.hdr.code);
      e.printStackTrace(dbg.os);
      int errorNo = 0;
      if (e instanceof NinfErrorException)
	errorNo = ((NinfErrorException)e).errorNo;
      NinfPacketOutputStream pos =
	new NinfPacketOutputStream(os, NinfPktHeader.NINF_PKT_ERROR, errorNo, 0);
      try {pos.flush();} catch(Exception ie){
	dbg.println("Can't return error pkt");
      }
      ret = false;
    }
    return ret;
  }

  public void serviceRequest() {
    XDRInputStream is = new XDRInputStream(clientInput);
    XDROutputStream os = new XDROutputStream(clientOutput);

    if (allowedHosts != null && !allowAll &&
      !allowedHosts.isAllowed(clientSocket)){
	dbg.log("["+myport+"] illegal access from "+ Util.peerName(clientSocket, lookup));
      close();
      return;
    }
    while (dispatchNinfRequest(is, os))
      ;
  }

  public synchronized int getSerial(){
    return callSerial++;
  }

  void start(){
    startServer(myport);
    dbg.log("[" +myport+"] start ..");
    if (allowAll || allowedHosts == null)
      dbg.log("["+myport+"] allows ALL" );
    else { 
      Enumeration elem = allowedHosts.elements();
      while (elem.hasMoreElements())
	dbg.log("["+myport+"] allows " + elem.nextElement());
    }
  }
}
