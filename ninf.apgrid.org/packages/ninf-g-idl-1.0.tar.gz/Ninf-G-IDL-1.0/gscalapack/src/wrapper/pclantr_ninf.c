#define _WRAPPER_
/* $Id: pclantr_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define SCOMPLEX
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n
static	int worklen(char norm, int m, int n) {
	  int ret=1;
	  int IROFFA, ICOFFA, IAROW, IACOL, Mp0, Nq0;
	  ret = max(m,n);
	  if NEED_BUFF {
	    IROFFA = MOD( IA-1, MB_A ); ICOFFA = MOD( JA-1, NB_A );
	    IAROW = INDXG2P( IA, MB_A, MYROW, RSRC_A, NPROW );
	    IACOL = INDXG2P( JA, NB_A, MYCOL, CSRC_A, NPCOL );
	    Mp0 = NUMROC( M+IROFFA, MB_A, MYROW, IAROW, NPROW );
	    Nq0 = NUMROC( N+ICOFFA, NB_A, MYCOL, IACOL, NPCOL );
	    if ((norm=='1') || (chrcmp(norm,'O')==0))
	      ret = Nq0;
	    if (chrcmp(norm,'I')==0)
	      ret = Mp0;
	  }
	  return ret;
}

void  pclantr_ninf(	 char norm,
		 char uplo,
		 char diag,
		 int m,
		 int n,
		 scomplex global_a[],
		 int lda,
		 float work[],
	 	 float *ret /* return value */
)
/* "pclantr returns the value of the one norm, or the Frobenius norm, or the infinity norm, or the element of largest absolute value of a trapezoidal or triangular distributed matrix sub( A ) denoting A." */
/* OPTIONS */
{

  extern float FortranCall(pclantr)(char*, char*, char*, int *, int *, scomplex *, int *,int *, int*,  float *);

	int maxldd;

	int maxlda;
	scomplex *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
	int row_loca, col_loca;

	float locpclantr[1];

	float *locwork=NULL;
	int llocwork;

	INITIALIZE();

	SCALAR( "char", norm);
	SCALAR( "char", uplo);
	SCALAR( "char", diag);
	SCALAR( "int", m);
	SCALAR( "int", n);
	SCALAR( "int", lda);

	ROW( a);
	COL( a);
	MAXLDD( maxldd, a );
	maxlda = maxldd;

	MATRIX( "scomplex", a, ROW_a, COL_a);
	DISTRIBUTE( "scomplex", a, ROW_a, COL_a);

	llocwork = worklen(norm, m, n);
	_work("float",&locwork, llocwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranReturnSimple( pclantr, locpclantr,
                        ( &norm, &uplo, &diag,
                        &m, &n,
                        loca, &one, &one, desca,
                        locwork) );

	RETRIEVE("float", locpclantr, 1);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
	  *ret = *locpclantr;
	} else {
	}

	FREE_MATRIX(a);
        FREE(locwork);
}

