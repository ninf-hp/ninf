package ninf.client;
import ninf.basic.*;

class ArrayShapeElem{
  int size;
  int start;
  int end;
  int step;
}
