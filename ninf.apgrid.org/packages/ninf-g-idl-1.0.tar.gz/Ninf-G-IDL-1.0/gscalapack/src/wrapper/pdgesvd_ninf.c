#define _WRAPPER_
/* $Id: pdgesvd_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define DOUBLE
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n
#define ROW_u ldu
#define COL_u col_u(jobu, m,n)
#define ROW_vt ldvt
#define COL_vt col_vt(jobvt, n)
static	int worklen(int m, int n, int col_locu, int col_locvt) {
	  int ret=1;
	  int SIZEB, WATOBD, WBDTOSVD,MP0,NQ0,MP,NQ;
	  int WPSLANGE, WPSLARED1D, WPSLARED2D, WPSGEBRD;
#define NUMROC Cnumroc
#define MYROW myprow
#define MYCOL mypcol
#define NPROW nprow
#define NPCOL npcol
#define MB rbloc
#define NB cbloc
          WBDTOSVD=max(m,n)*2*min(m,n)+max(4*max(m,n),max(n*max(n/2,m)+n*n,m*(m/2,n)+m*m));
          
          ret = 2+6*max(m,n)+max(max(m,n),WBDTOSVD);
	  if NEED_BUFF {
              int WPSORMBRQLN, WPSORMBRPRT;
	    SIZEB=max(m,n);
	    MP0 = NUMROC( m, rbloc, 0, 0, NPROW);
	    NQ0 = NUMROC( n, cbloc, 0, 0, NPCOL);
	    MP = NUMROC( m, rbloc, MYPROW, 0, NPROW);
	    NQ = NUMROC( n, cbloc, MYPCOL, 0, NPCOL);

	    WPSLANGE = MP;
	    WPSLARED1D = NQ0;
	    WPSLARED2D = MP0;
	    WPSGEBRD = NB*(MP + NQ + 1) + NQ;
	    WATOBD = max(max(WPSLANGE,WPSGEBRD),
			 max(WPSLARED2D,WPSLARED1D));

            WPSORMBRQLN = MAX( (NB*(NB-1))/2, (SIZEB+MP)*NB)+NB*NB;
            WPSORMBRPRT = MAX( (MB*(MB-1))/2, (SIZEB+NQ)*MB )+MB*MB;
            
            WBDTOSVD = SIZEB*(1*col_locu + 1*col_locvt) +
                     MAX(4*SIZEB,
                         MAX(1*WPSORMBRQLN, 1*WPSORMBRPRT));
	    ret =  2 + 6*SIZEB + max(WATOBD, WBDTOSVD);
	  }
          return ret;
}

static	int col_u(char jobu, int m, int n) {
	  return (jobu=='V' ? min(m,n) : 1);
}

static	int col_vt(char jobvt, int n) {
    return (jobvt=='V' ? n : 1);
}


void  pdgesvd_ninf(	 char jobu,
		 char jobvt,
		 int m,
		 int n,
		 double global_a[],
		 int lda,
		 double s[],
		 double global_u[],
		 int ldu,
		 double global_vt[],
		 int ldvt,
		 double work[],
		 int lwork,
		 int *info
)
/* "pdgesvd computes the singular value decomposition (SVD) of an M-by-N matrix A, optionally computing the left and/or right singular vectors." */
/* OPTIONS */
{
    extern void FortranCall(pdgesvd)( char*, char*, int*, int*,
                                double*, int*, int*, int*,
                                double*,
                                double*, int*, int*, int*,
                                double*, int*, int*, int*,
                                double*, int*, int*);
	int maxldd;

	int maxlda;
	double *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];

	int maxldu;
	double *locu=NULL;
	int descu[DESCLEN];
	int desc_gu[DESCLEN];

	int maxldvt;
	double *locvt=NULL;
	int descvt[DESCLEN];
	int desc_gvt[DESCLEN];

	int row_loca;
	int col_loca;
	int row_locu;
	int col_locu;
	int row_locvt;
	int col_locvt;

	double *locs=NULL;

	double *locwork=NULL;
	int llocwork;
	
	INITIALIZE();

	SCALAR( "char", jobu);
	SCALAR( "char", jobvt);
	SCALAR( "int", m);
	SCALAR( "int", n);
	SCALAR( "int", lda);
	SCALAR( "int", ldu);
	SCALAR( "int", ldvt);
        SCALAR( "int",lwork);
	
	ROW( a);
	COL( a);
	ROW( u);
	COL( u);
	ROW( vt);
	COL( vt);
	MAXLDD( maxldd, a );
	maxlda = maxldd;
	maxldu = maxldd;
	maxldvt = maxldd;

	MATRIX( "double", a, ROW_a, COL_a);
	MATRIX( "double", u, ROW_u, COL_u);
	MATRIX( "double", vt, ROW_vt, COL_vt);

	DISTRIBUTE( "double", a, ROW_a, COL_a);

	llocwork=worklen(m,n, col_locu, col_locvt);
        llocwork=max(lwork,llocwork);
	WORK(locwork,llocwork);

	locs=MALLOC(sizeof(double)*min(m,n)); assert(locs);

	if  (( mypnum != 0 ) ^ (serial==1) )
	  FortranCall(pdgesvd)( &jobu, &jobvt, &m, &n,
                                loca, &one, &one, desca,
                                locs,
                                locu, &one, &one, descu,
                                locvt, &one, &one, descvt,
                                locwork, &llocwork, &linfo);

	GATHER( "double", u, ROW_u  , COL_u);
	GATHER( "double", vt, ROW_vt  , COL_vt);
	RETRIEVE( "double", locs, min(m,n));
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
	  int i;
	  *info = linfo;
	  for(i=0;i<min(m,n);i++) s[i] = locs[i];
	} else {
		
	}

	FREE_MATRIX(a);
	FREE_MATRIX(u);
	FREE_MATRIX(vt);
	FREE(locwork);
        FREE(locs);
}

