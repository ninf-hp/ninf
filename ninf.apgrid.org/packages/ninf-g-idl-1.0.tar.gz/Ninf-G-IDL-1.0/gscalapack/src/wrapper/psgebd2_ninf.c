#define _WRAPPER_
/* $Id: psgebd2_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define _DISTRIBUTE_1D_
#define FLOAT
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n
static  int worklen(int m, int n) {
	  int ret=1;
	  int nb, IROFFA, IAROW, IACOL;
	  int MpA0, NqA0;
#define MYROW myprow
#define NPROW nprow
#define MYCOL mypcol
#define NPCOL npcol
	  ret = max(m,n);
	  if NEED_BUFF {
	    nb = blocsize;
	    IROFFA = 0;
	    IAROW = INDXG2P( 1, nb, MYROW, 0, NPROW );
	    IACOL = INDXG2P( 1, nb, MYCOL, 0, NPCOL );
	    MpA0 = Cnumroc( m+IROFFA, nb, MYROW, IAROW, NPROW );
	    NqA0 = Cnumroc( n+IROFFA, nb, MYCOL, IACOL, NPCOL );

	    ret = max( MpA0, NqA0 );
	  }
	  return ret;
}


void  psgebd2_ninf(	 int m,
		 int n,
		 float global_a[],
		 int lda,
		 float global_d[],
		 float global_e[],
		 float global_tauq[],
		 float global_taup[],
		 float work[],
		 int *info
)
/* "psgebd2 reduces a real general M-by-N distributed matrix A to upper or lower bidiagonal form B by an orthogonal transformation: Q' *  A * P = B." */
/* OPTIONS */
{
  int min_m_n;
  
	int maxldd;
	int maxlda;
	float *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
        
	float *locd=NULL;
	float *loce=NULL;
	int desctdd[DESCLEN], desc_gtdd[DESCLEN];

        float *loctauq=NULL;
	float *loctaup=NULL;
        
	int row_loca;
	int col_loca;

	float *locwork=NULL;
	int llocwork;

	INITIALIZE();

	SCALAR( "int", m);
	SCALAR( "int", n);
	SCALAR("int",lda);
	min_m_n = min(m,n);

	SIZE(min_m_n);

	ROW( a);
	COL( a);
	MAXLDD( maxldd, a );
	maxlda = maxldd;

	MATRIX( "float", a, ROW_a, COL_a);
	DISTRIBUTE( "float", a, ROW_a, COL_a);
	tdMATRIX("float", e, d, e, min_m_n);

	VECTOR("c","float", tauq, min_m_n);
	VECTOR("r", "float", taup, min_m_n);

	llocwork=worklen(m, n);
	WORK(locwork, llocwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(psgebd2)( &m, &n,
                               loca, &one, &one, desca,
                               locd, loce,
                               loctauq, loctaup,
                               locwork, &llocwork, &linfo);

	GATHER( "float", a, ROW_a, COL_a);
	tdGATHER( "float", e, d, e, min_m_n);
	vGATHER("c","float", tauq, min_m_n);
	vGATHER("r", "float", taup, min_m_n);

            /* d,e,taup,tauq -> bandmatrix descinit not distri*/
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
		*info = linfo;
	} else {
	}

	FREE_MATRIX(a);
	FREE_MATRIX(d);
	FREE_MATRIX(e);
	FREE_MATRIX(taup);
        FREE(locwork);
}

