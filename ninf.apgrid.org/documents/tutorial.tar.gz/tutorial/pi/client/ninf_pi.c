#include <stdio.h>
#include <stdlib.h>
#include "ninf.h"

int main(int argc, char ** argv){
  double pi;
  long times, count;
  argc = Ninf_parse_arg(argc, argv);

  if (argc < 2){
	fprintf(stderr, "USAGE: pi TIMES \n");
	exit(2);
  }
  times = atol(argv[1]);
  
  if (Ninf_call("pi/pi_trial", 10, times, &count) == NINF_ERROR){
	Ninf_perror("pi_trial");
	exit(2);
  }
	
  pi = 4.0 * ( count / (double) times);
  printf("PI = %f\n", pi);
  exit(0);
}
