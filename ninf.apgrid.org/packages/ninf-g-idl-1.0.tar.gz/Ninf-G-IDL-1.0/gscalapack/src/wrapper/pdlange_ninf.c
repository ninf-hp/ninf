#define _WRAPPER_
/* $Id: pdlange_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define DOUBLE
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n
static	int worklen(int m, int n) {
	  int ret=1;
	  int IROFFA, ICOFFA;
	  int IAROW, IACOL;
	  int Mp0, Nq0;
	  ret = max(m,max(n,m));
	  if NEED_BUFF {
	    IROFFA = MOD( IA-1, MB_A );
	    ICOFFA = MOD( JA-1, NB_A );
	    IAROW = INDXG2P( IA, MB_A, MYROW, RSRC_A, NPROW );
	    IACOL = INDXG2P( JA, NB_A, MYCOL, CSRC_A, NPCOL );
	    Mp0 = NUMROC( M+IROFFA, MB_A, MYROW, IAROW, NPROW );
	    Nq0 = NUMROC( N+ICOFFA, NB_A, MYCOL, IACOL, NPCOL );
	    ret = max(m,max(Nq0,Mp0));
	  }
	  return ret;
}


void  pdlange_ninf(	 char norm,
                         int m,
                         int n,
                         double global_a[],
                         int lda,
                         double work[],
                         double *ret /* return value */
)
/* "pdlange returns the value of the one norm, or the Frobenius norm, or the infinity norm, or the element of largest absolute value of a distributed matrix A." */
/* OPTIONS */
{
  extern double FortranCall(pdlange)( char*, int*, int*, double*, int*, int*, int*, double*);

	int maxldd;

	int maxlda;
	double *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
	int row_loca, col_loca;

	double *locwork=NULL;
	int llocwork;

	double locpdlange_[1];

	INITIALIZE();

	SCALAR( "char", norm);
	SCALAR( "int", m);
	SCALAR( "int", n);
	SCALAR( "int", lda);

	ROW( a);
	COL( a);
	MAXLDD( maxldd, a );
	maxlda = maxldd;
	MATRIX( "double", a, ROW_a, COL_a);
	DISTRIBUTE( "double", a, ROW_a  , COL_a);

	llocwork = worklen(m, n);
	WORK(locwork,llocwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	    FortranReturnSimple(pdlange, locpdlange_,
                       ( &norm, &m, &n,
                       loca, &one, &one, desca,
                       locwork )  );

	RETRIEVE("double", locpdlange_, 1);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
		*ret = *locpdlange_;
	} else {
	}

	FREE_MATRIX(a);
        FREE(locwork);
}

