void square ( int n, int *nrow, int *ncol )
{
  extern double sqrt( double );

   int i, row, col;

   col= (int)(sqrt(n));
   i = 0;
   while ( i == 0 ) {
      if( n % col == 0 ) {
         row = n/col;
         i = 1;
      } else
         col--;
   }
   *nrow = row;
   *ncol = col;
   return;
}
