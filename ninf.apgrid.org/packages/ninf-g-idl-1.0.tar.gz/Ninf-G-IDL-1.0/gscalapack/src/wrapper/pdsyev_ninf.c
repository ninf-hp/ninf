#define _WRAPPER_
/* $Id: pdsyev_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define DOUBLE
#include <gscalapack.h>

#define ROW_a lda
#define COL_a  n
#define ROW_z ROW_a
#define COL_z  COL_a
static	int worklen(char jobz, int n){
	  int ret=1;
	      int QRMEM,NRC,LDC;
	      int SIZEMQRLEFT;
              int NP,NQ,NN;
              int CONTEXTC;
              int MYPROWC, MYPCOLC, NPROWC,  NPCOLC;
#define mod(a,b) (a)%(b)
              
              SIZEMQRLEFT = MAX( n*n/2, n*n )+ n*n;
	      QRMEM = 2*n-2;
	      ret = 5*n + n*LDC + MAX( SIZEMQRLEFT, QRMEM ) +1;
              
	  if NEED_BUFF {

	    NN = max(n, max(NB, 2));
	    NP = NUMROC( NN, NB, MYROW, 0, NPROW );
	    NQ = NUMROC( NN, NB, MYCOL, 0, NPCOL );

	    ret = 5*n+ max( NB * ( NP +1 ), 3 * NB )+1;

	    if (chrcmp(jobz,'V')==0) {

	      NRC = NUMROC( n, NB, max(mypnum-1,0), 0, nprow*npcol);
	      LDC = MAX( 1, NRC );

	      SIZEMQRLEFT = MAX( (NB*(NB-1))/2, (NP + NQ)*NB )+ NB* NB;
	      QRMEM = 2*n-2;

	      ret = 5*n + n*LDC + MAX( SIZEMQRLEFT, QRMEM ) +1;
	    }
	  }
	  return ret;
          
}

void  pdsyev_ninf(	 char jobz,
		 char uplo,
		 int n,
		 double global_a[],
		 int lda,
		 double w[],
		 double work[],
		 int lwork,
		 int *info
)
/* "pdsyev computes all eigenvalues and, optionally, eigenvectors of a real symmetric matrix A." */
/* OPTIONS */
{
    extern void FortranCall(pdsyev)( char*, char*, int*,
			      double*, int*, int*, int*,
			      double*,
			      double*, int*, int*, int*,
			      double*, int*,
			      int*);

    extern void FortranCall(pdlacpy)( char*, int*, int*,
				double*, int*, int*, int*,
				double*, int*, int*, int*);

	int maxldd;

	int maxlda;
	double *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];

	double *global_z=NULL;
	double *locz=NULL;
	int maxldz;
	int descz[DESCLEN];
	int desc_gz[DESCLEN];

	int row_loca, col_loca;
	int row_locz, col_locz;

	double *locw=NULL;

	double *locwork=NULL;
	int llocwork;


	INITIALIZE();

	SCALAR( "char", jobz);
	SCALAR( "char", uplo);
	SCALAR( "int", n);
	SCALAR( "int", lda);
        SCALAR( "int", lwork);

	if (mypnum==0) {
            global_z = MALLOC( sizeof(double)*ROW_z*COL_z);
            assert(global_z);
        }

	ROW( a);
	COL( a);
	ROW( z);
	COL( z);
	MAXLDD( maxldd, a );
	maxlda = maxldd;
	maxldz = maxldd;

	MATRIX( "double", a, ROW_a, COL_a);
	MATRIX( "double", z, ROW_z, COL_z);
	DISTRIBUTE( "double", a, ROW_a  , COL_a);

	llocwork= worklen(jobz, n);
        llocwork = max(lwork,llocwork);
	WORK(locwork,llocwork);

	locw = MALLOC(sizeof(double)*n); assert(locw);

	if  (( mypnum != 0 ) ^ (serial==1) ) {
	 FortranCall(pdsyev)( &jobz, &uplo, &n,
			      loca, &one, &one, desca,
			      locw,
			      locz, &one, &one, descz,
			      locwork, &llocwork,
			      &linfo);
	  FortranCall(pdlacpy)( "All", &lda, &n,
				locz, &one, &one, descz,
				loca, &one, &one, desca);
	}

	GATHER("double", a, ROW_a, COL_a);
	
	RETRIEVE("double", locw, n);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
	  int i;
	  *info = linfo;
	  for(i=0;i<n;i++) w[i] = locw[i];
	} else {
	}

	FREE_MATRIX(a);
	FREE_MATRIX(z);
        FREE(locwork);
	FREE(locw);

}

