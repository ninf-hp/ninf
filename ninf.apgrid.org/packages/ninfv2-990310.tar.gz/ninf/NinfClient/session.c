#include <stdio.h>
#include <errno.h>
#include <stdlib.h>
#include <stdarg.h>

#include "ninf_stub_info.h"
#include "ninf_protocol.h"
#include "ninf_debug.h"
#include "ninf_error.h"
#include "session.h"
#include "ninf_comm_lib.h"
#include "ninf_client.h"
#include "callback.h"
#include "dataflow.h"



NINF_STUB_INFO * Ninf_get_compound(connection * );
NINF_STUB_INFO * Ninf_get_stub_raw(connection * con, ninf_entry * entry);
NINF_STUB_INFO * search_stub_cache(ninf_entry * entry);

connection     * ninf_connect(ninf_entry *);
any_t          * new_arg(int num);
extern int       IN_TRANSACTION;

/**  static variables **/
static int SESSION_COUNTER = 10;
static session_list * SESSIONS = NULL;         /* sessions under execution */
static session_list * DONE_SESSIONS = NULL;    /* sessions already done */
/**  static variables **/

/********************** INSTANCE CREATION ***********************/
static ninf_session * the_last_session;

ninf_session * get_last_session(){
  return the_last_session;
}

ninf_session * 
new_ninf_session(connection * server, any_t args[], NINF_STUB_INFO * stub_info, 
		 callback callbacks[], resource * c_resource){
  ninf_session * tmp;
  tmp = (ninf_session *)(malloc(sizeof(ninf_session)));
  if (tmp == NULL)
    return NULL;
#ifndef WIN32
  gettimeofday(&(tmp->e_info.start_time), 0);
#else
  _ftime(&(tmp->e_info.start_time));
#endif
  tmp->entry = stub_info->entry;
  tmp->server = server;
  tmp->args = args;
  tmp->stub_info = stub_info;
  tmp->callbacks = callbacks;
  tmp->c_resource = c_resource;
  tmp->synchronous = TRUE;
  tmp->isFortran = FALSE;
  tmp->e_info.error_no = NINF_ERROR_SESSION_ISNOT_DONE;
  tmp->id = SESSION_COUNTER++;
  the_last_session = tmp;
  return tmp;
}

ninf_session * 
new_ninf_session_stub(NINF_STUB_INFO * stub_info){
  return new_ninf_session_entry(stub_info->entry);
}

ninf_session * 
new_ninf_session_string(char * ninf_stub_entry){
  ninf_entry * entry;
  ninf_session * session;
  if ((entry = new_ninf_entry(ninf_stub_entry)) == NULL)
    return NULL;
  if ((session = new_ninf_session_entry(entry)) == NULL)
    return NULL;
  return session;
}

ninf_session * 
new_ninf_session_entry(ninf_entry * entry){
  ninf_session * tmp;
  tmp = (ninf_session *)(malloc(sizeof(ninf_session)));
  if (tmp == NULL)
    return NULL;
#ifndef WIN32
  gettimeofday(&(tmp->e_info.start_time), 0);
#else
  _ftime(&(tmp->e_info.start_time));
#endif
  if (IN_TRANSACTION){ /* in transaction, always use metaserver */
    entry->host = NULL;
    entry->port = NULL;
  }
  tmp->entry = entry;
  tmp->server = NULL;
  tmp->args = NULL;
  tmp->stub_info = NULL;
  tmp->callbacks = NULL;
  tmp->c_resource = NULL;
  tmp->synchronous = TRUE;
  tmp->isFortran = FALSE;
  if (entry->entry != NULL)
    if (session_stub_info(tmp) == NULL) 
      return NULL;
  tmp->e_info.error_no = NINF_ERROR_SESSION_ISNOT_DONE;
  tmp->id = SESSION_COUNTER++;
  the_last_session = tmp;
  return tmp;
}

ninf_session * 
new_ninf_session_transaction(){
  ninf_session * session;
  if ((session = new_ninf_session_string(NULL)) == NULL)
    return NULL;
  if (!session_connect(session))
    return NULL;
  session->stub_info = Ninf_get_compound(session->server);
  session->c_resource = new_resources(session->stub_info->nparam);
  return session;
}

void destruct_ninf_session(ninf_session * session){
  free(session);
}

/********************* SUBROUTINES ***********************/

NINF_STUB_INFO * session_stub_info(ninf_session * session){
  if (session->stub_info != NULL)
    return session->stub_info;

  session->stub_info = search_stub_cache(session->entry);
  if (session->stub_info == NULL){
    if (session->server == NULL)
      if ((session->server = ninf_connect(session->entry)) == NULL)
	return NULL;
    session->stub_info = Ninf_get_stub_raw(session->server, session->entry);
    if (session->stub_info == NULL)
      session_close(session);
  }
  return session->stub_info;
}


int session_connect(ninf_session * session){
  if (session->server == NULL)
    if ((session->server = ninf_connect(session->entry)) == NULL){
      ninf_error_code = NINF_ERROR_CANTCONNECTSERVER;
      return FALSE;
    }
  return TRUE;
}

void session_close(ninf_session * session){
  if (session->server != NULL)
    ninf_disconnect(session->server);
}


ninf_session * start_session(ninf_session * session){
  int ack;
  if (!session_connect(session))
    goto abort; 
  if (!start_stub_by_index(session)){
    if (ninf_error_code == NINF_ERROR_STUBREMOVED){
      session->stub_info = NULL;
      session_stub_info(session);
      if (session->stub_info == NULL){
	goto abort; 
      }
      return start_session(session);
    } else
      goto abort; 
  }
  set_trans_header(session->server->sDT, NINF_PKT_TO_STUB, 0, 0);

  /* do call */
  debug_log("NINF_REQ_CALL\n");

  if ((ack = ninf_send_args(session)) 
      != NINF_OK)
    goto abort;  /* send arg fail */
  return session;

abort:
  session_close(session);
  return NULL;
}

int session_do_v(ninf_session * session, any_t * args){

  session->c_resource = new_resources(session->stub_info->nparam);
  session->callbacks = new_callback(MAX_CALLBACK + 1);
  session->args = args;
  ninf_get_arg_v(session->stub_info, session->args, session->callbacks);
  return session_do_common(session);
}

int session_do(ninf_session * session, va_list *app){
  session->c_resource = new_resources(session->stub_info->nparam);
  session->callbacks = new_callback(MAX_CALLBACK + 1);
  session->args = new_arg(session->stub_info->nparam);
  /* set up args to work */
  
  ninf_get_arg2(app, session->stub_info, session->args, session->callbacks, 
		session->c_resource, session->isFortran);
  va_end(*app);
  return session_do_common(session);
}

int session_do_common(ninf_session * session){
  if (IN_TRANSACTION){
    if (session->server != NULL)
      ninf_remote_kill(session->server);
    return ninf_make_dataflow(session->args, session->stub_info);
  }
  if ((session = start_session(session)) == NULL){
    return NINF_ERROR;
  }
  if (!session->synchronous)
    return add_session(session);
  return finish_session(session);
}

int finish_session(ninf_session * session){
  int ack, ack_kill;
  ack = ninf_recv_or_callback(session);
  if (ack != NINF_OK)
    return ack;
  ack_kill = ninf_remote_kill(session->server);
  if (ack == NINF_OK && ack_kill != NINF_OK)
    return ack_kill;
  return(ack);
}

int do_session(int fd){
  int ack;
  ninf_session * session = find_session_by_fd(fd);

  if (session == NULL) 
    return NINF_ERROR;
  ack = ninf_recv_or_callback_org(session);
  if (ack == NINF_CALLBACK)
    return NINF_CALLBACK;
  else {
    /* fprintf(stderr, "fd %d done \n", fd); */

    session->e_info.error_no = ninf_error_code;
    ninf_remote_kill(session->server);
    session_done(session);
    return ack;
  }
}

/***************** SESSION LIST STUFF *******************/
void add_session_to(ninf_session * session, session_list ** s){
  *s = new_session_list(session, *s);
}

int add_session(ninf_session * session){
  add_session_to(session, &SESSIONS);
  return session->id;
}


session_list * new_session_list(ninf_session * session,
				session_list * next){
  session_list * tmp = (session_list *)(malloc(sizeof(session_list)));
  if (tmp == NULL)
    return NULL;
  tmp->session = session;
  tmp->next = next;
  return tmp;
}


ninf_session * find_session(int num, session_list * tmp){
  while (tmp != NULL){
    if (tmp->session->id == num)
      return tmp->session;
    tmp = tmp->next;
  }
  return NULL;
}

ninf_session * find_all_session(int num){
  ninf_session * tmp;
  if ((tmp = find_session(num, SESSIONS)) != NULL)
    return tmp;
  return find_session(num, DONE_SESSIONS);
}

int session_is_done(int id){
  ninf_session * session;
  if ((session = find_session(id, SESSIONS)) == NULL){
    if ((session = find_session(id, DONE_SESSIONS)) == NULL)
      return FALSE;  /* no such session */
    else 
      return TRUE;
  } 
  return FALSE;
}

int get_session_fd(ninf_session * s){
  if (s->e_info.error_no == NINF_ERROR_SESSION_ISNOT_DONE)
    return s->server->sDT->fd;
  return -1;
}

ninf_session * find_session_by_fd(int fd){
  session_list * tmp = SESSIONS;
  while (tmp != NULL){
    if (get_session_fd(tmp->session) == fd)
      return tmp->session;
    tmp = tmp->next;
  }
  return NULL;
}

session_list * rm_session_by_session_from(ninf_session * session, session_list * sl){
  session_list * tmp = sl;
  if (tmp == NULL) 
    return NULL;
  if (tmp->session == session){
    return tmp->next;
  }  
  while (tmp->next != NULL){
    if (tmp->next->session == session){
      ninf_session * ans = tmp->next->session;
      tmp->next = tmp->next->next;
      return sl;
    } 
    tmp = tmp->next;
  }
  return sl;
}

ninf_session * rm_session_by_session(ninf_session * session){
  SESSIONS = rm_session_by_session_from(session, SESSIONS);
  return session;
}


int session_kill(int id){
  ninf_session * ses;
  if ((ses = find_session(id, SESSIONS)) == NULL){
    if ((ses = find_session(id, DONE_SESSIONS)) == NULL){
      ninf_error_code = NINF_ERROR_CANTFINDSESSION;
      return NINF_ERROR;
    } else {
      ninf_error_code = NINF_ERROR_SESSION_FINISHED;
      ses->e_info.error_no = ninf_error_code;
      return NINF_ERROR;
    }
  }
  if (ses->e_info.error_no != NINF_ERROR_SESSION_ISNOT_DONE){
    ninf_error_code = NINF_ERROR_SESSION_FINISHED;
    ses->e_info.error_no = ninf_error_code;
    return NINF_ERROR;
  }
  /*  close(get_session_fd(ses)); */
  session_close(ses);
  ninf_error_code = NINF_ERROR_SESSION_CANCELED;  
  ses->e_info.error_no = ninf_error_code;
  session_done(ses);
  return NINF_OK;
}

void session_done(ninf_session * ses){   /* move from SESSIONS to DONE_SESSIONS */
  SESSIONS = rm_session_by_session_from(ses, SESSIONS);
  add_session_to(ses, &DONE_SESSIONS);
}

/*
ninf_session * rm_session(int num){
  ninf_session * tmp = find_session(num, SESSIONS);
  if (tmp == NULL)
    return NULL;
  else
    return rm_session_by_session(tmp);
}
*/

session_list * collect_session_list(int * id_list, int counts){
  int i;
  session_list * ans = NULL;
  ninf_session * ses;
  for (i = 0; i < counts; i++){
    if ((ses = find_session(id_list[i], SESSIONS)) != NULL)
      ans = new_session_list(ses, ans);
  }
  return ans;
}

session_list * root_sessions(){
  return SESSIONS;
}

/************ osoi ***********/
int session_is_null(session_list * sessions){
  session_list * tmp = sessions;
  while (tmp != NULL){
    int fd = get_session_fd(tmp->session);
    if (fd > 0) {
      return FALSE;
    }
    fprintf(stderr, "error: dead session in SESSIONS");
    tmp = tmp->next;
  }
  return TRUE;
}


ninf_session * select_session(session_list * sessions, int one_by_one){
  fd_set rfds;
  int max_nfd = 0;
  int nfd;
  int count = 0;
  ninf_session * ses = NULL;
  session_list * tmp = sessions;
  FD_ZERO(&rfds);
  while (tmp != NULL){
    int fd = get_session_fd(tmp->session);
    if (fd > 0) {
      FD_SET(fd, &rfds);
      if (max_nfd <= fd) 
	max_nfd = fd;
      count++;
    }
    tmp = tmp->next;
  }
  if (count == 0)
    return NULL;
  nfd = select(max_nfd+1,&rfds,NULL,NULL,NULL);
  if (nfd <= 0){
    if (errno != EINTR){
      perror("select");
    }
    return NULL;
  }
  tmp = sessions;
  while (tmp != NULL){
    int ack;
    int fd = get_session_fd(tmp->session);
    if (fd > 0) {
      if (FD_ISSET(fd, &rfds)){
	/*  fprintf(stderr, "fd %d is selected\n", fd); */
	ses = find_session_by_fd(fd);
	ack = do_session(fd);
	if (ack == NINF_ERROR)
	  return NULL;
	if (one_by_one)
	  return ses;
      }
    }
    tmp = tmp->next;
  }
  return ses;
}

int session_do_cim(ninf_session * session, obj_handler * hp){
  int i;
  session->c_resource = new_resources(session->stub_info->nparam);
  session->callbacks = new_callback(MAX_CALLBACK + 1);
  
  session->args = new_arg(session->stub_info->nparam);
  for (i = 0; i < session->stub_info->nparam; i++){
    session->args[i].isHandler = TRUE;
    session->args[i].handler = hp[i];
    session->args[i].u.p = (char *)hp[i];
  }
  return session_do_common(session);
}

