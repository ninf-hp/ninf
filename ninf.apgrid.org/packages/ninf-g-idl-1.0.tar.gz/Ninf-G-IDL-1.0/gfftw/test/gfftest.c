#include <stdio.h>
#include <math.h>
#define N 1234567
#include <string.h>
#include <stdlib.h>
#include <unistd.h>

#if defined(NINFG1)
#include "grpc.h"
#include "ns.h"
#include "ns_complex.h"
#include "nsapi.h"
#elif defined(NINFG2)
#include "grpc.h"
#include "ng.h"
#else
#error NINF Version is unknown.
#endif

#include "assert.h"
#include <gfftest.h>

char *host;

#if defined(NINFG1)
int port = 4000;
#elif defined(NINFG2)
int port=0;
#else
#error NINF Version is unknown.
#endif

#define COUNT 50

extern double second();

int main(int argc,char ** argv) {

  grpc_function_handle_t handle;
  dcomplex *in=NULL, *out=NULL, *rout=NULL;
  double resid;
  char plan[WISDOMLEN];

  double *dat=NULL;
  int n=N;
  double x;
  int i;

  double time0,timef;

  if (argc>1) {
    if (grpc_initialize(argv[1]) != GRPC_NO_ERROR) {
      fprintf(stderr, "grpc initialize\n");
      exit(2);
    }
  } else {
    fprintf(stderr, "You need to put config_file.\n");
    exit(0);
  }

  in = malloc(sizeof(dcomplex)*N); assert(in);
  out = malloc(sizeof(dcomplex)*N); assert(out);
  rout = malloc(sizeof(dcomplex)*N); assert(rout);
  dat = malloc(sizeof(double)*N); assert(dat);

  x=0.2;
  for(i=0;i<N;i++) {
    //            x=4.*x*(1.-x);
    dat[i]=sin((double)i/64);
  }

  for(i=0;i<N;i++) {
    in[i].r = dat[i];
    in[i].i = 1./(dat[i]+0.1);
    out[i].r = 0.;
    out[i].i = 0.;
    rout[i].r = 0.;
    rout[i].i = 0.;
  }

#if defined(NINFG1)
  host = strdup(nslib_conf_getserverhostname());
  port = nslib_conf_getserverport();
#else
  if ((host = getenv("NG_SERVER"))==NULL) {
      fprintf(stderr, "env 'NG_SERVER' is not defined and set my hostname instead.\n");
#define HOSTNAMELEN 512
      host = calloc(HOSTNAMELEN, sizeof(char));
      if (gethostname(host, HOSTNAMELEN) != 0) {
          strcpy(host,"localhost");
      }
  }
  {
      char *dummyc;
      if ((dummyc = getenv("NG_SERVER_PORT")) != NULL) {
          port = atoi(dummyc);
      }
  }
#endif

  printf("size=%d\n", n);

  printf("\nMEASURE MODE:\n");
  time0 = second();
  if (grpc_function_handle_init( &handle, host, "fftw/fftw_create_plan") 
      != GRPC_NO_ERROR ) {
    grpc_perror_np( "handle_init");
    exit(2);
  }

  if (grpc_call( &handle,
		 n, FFTW_FORWARD, FFTW_MEASURE,
		 plan)
      != GRPC_NO_ERROR) {
    fprintf(stderr,"Failed in grpc_call:create_plan\n");
    exit(2);
  }
  grpc_function_handle_destruct(&handle);
  timef = second();
  printf("create_plan(MEASURE): time= %f sec\n",timef-time0);

  if (grpc_function_handle_init( &handle, host, "fftw/fftw_one") 
       != GRPC_NO_ERROR ) {
    grpc_perror_np( "handle_init");
    exit(2);
  }
  time0 = second();
  printf("count= ");
  for(i=0;i<COUNT;i++) {
    if (grpc_call(&handle, plan, in, out, n, n) != GRPC_NO_ERROR) {
      fprintf(stderr,"Failed in grpc_call:one\n");
      exit(2);
    }
    if ((i<5)||((i+1)%5==0)) { printf("%d ",i+1); fflush(stdout);}
  }
  timef = second();
  printf("\ntime= %f sec (%dtimes)\n",timef-time0, COUNT);
  grpc_function_handle_destruct(&handle);


  for(i=0;i<WISDOMLEN;i++) plan[i]='\0';  
  printf("\n\nESTIMATE MODE:\n");
  if (grpc_function_handle_init( &handle, host, "fftw/fftw_one") 
      != GRPC_NO_ERROR ) {
      grpc_perror_np( "handle_init: ");
      exit(2);
  }

  time0 = second();
  printf("count= ");
  for(i=0;i<COUNT;i++) {
      if (grpc_call(&handle, plan, in, out, n, n) != GRPC_NO_ERROR) {
          fprintf(stderr,"Failed in grpc_call:one\n");
          exit(2);
      }
      if ((i<5)||((i+1)%5==0)) { printf("%d ",i+1); fflush(stdout); }
  }
  timef = second();
  printf("\ntime= %f sec (%dtimes)\n",timef-time0, COUNT);
  grpc_function_handle_destruct(&handle);


   printf("\nRESIDUE Check.\n");

   if (grpc_function_handle_init( &handle, host, "fftw/ifftw_one") 
       != GRPC_NO_ERROR ) {
     grpc_perror_np( "handle_init");
     exit(2);
   }
   
   if (grpc_call(&handle, plan, out, rout, n, n) != GRPC_NO_ERROR) {
     fprintf(stderr,"Failed in grpc_call:ione\n");
     exit(2);
   }
  grpc_function_handle_destruct(&handle);

   for(i=0;i<n;i++) {
     rout[i].r /= (double)n;
     rout[i].i /= (double)n;
   }
   printf("\norg inv^2\n");
   for(i=0;i<10;i++) printf("%3.16f %3.16f\n",rout[i].r,in[i].r);
   
   resid = 0.;
   for(i=0;i<n;i++) {
     resid += (rout[i].r-in[i].r)*(rout[i].r-in[i].r) + (rout[i].i-in[i].i)*(rout[i].i-in[i].i);
   }
   resid = sqrt(resid)/(double)n;
   printf("\nresid=%2.18f\n", resid);
   
   grpc_finalize();

   free(in);
   free(out);

   return 0;
}

double
second()
{
#include <sys/time.h>

  struct timeval tm;
  double t ;

  static int base_sec = 0,base_usec = 0;

  gettimeofday(&tm, NULL);
  
  if(base_sec == 0 && base_usec == 0)
    {
      base_sec = tm.tv_sec;
      base_usec = tm.tv_usec;
      t = 0.0;
    } else {
      t = (double) (tm.tv_sec-base_sec) + 
	((double) (tm.tv_usec-base_usec))/1.0e6 ;
    }

  return t ;
}
