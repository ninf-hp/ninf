#define _WRAPPER_
/* $Id: pcpbtrs_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define _DISTRIBUTE_1D_
#define SCOMPLEX
#define NO_PIVOT
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n
#define ROW_b ldb
#define COL_b nrhs
static	int worklen(int nrhs, int bw) {
	  int ret=1;
          ret = bw*nrhs;
	  return ret;
}

void  pcpbtrs_ninf(	 char uplo,
		 int n,
		 int bw,
		 int nrhs,
		 scomplex global_a[],
		 int lda,
		 scomplex global_b[],
		 int ldb,
		 int *info
)
/* "pcpbtrs solves a system of linear equations A * X = B where A is the matrix used to produce the factors stored in A and AF by PCPBTRF. A is an N-by-N complex */
/* banded symmetric positive definite distributed matrix with bandwidth BW." */
/* OPTIONS */
{
extern void FortranCall(pcpbtrs)( char*, int*, int*, int*,
                               scomplex*, int*, int*,
                               scomplex*, int*, int*,
                               scomplex*, int*,
                               scomplex*, int*, int*);

	int maxldd;

	int maxlda;
	scomplex *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];

	scomplex *locb=NULL;
	int maxldb;
	int descb[DESCLEN];
	int desc_gb[DESCLEN];
	int row_locb;
	int col_locb;

	scomplex *locaf=NULL;
	int laf;

	scomplex *locwork=NULL;
	int llocwork;

	INITIALIZE();

	SCALAR( "char", uplo);
	SCALAR( "int", n);
	SCALAR( "int", bw);
	SCALAR( "int", nrhs);
	SCALAR( "int", lda);
	SCALAR( "int", ldb);

	SIZE(n);

	ROW(b);
	COL(b);
	MAXLDD( maxldd, b );
	maxldb=maxldd;

	if (chrcmp(uplo,'u')==0) {
	  bandMATRIX(     "scomplex", a, 0, bw, n);
	  bandDISTRIBUTE( "scomplex", a, 0, bw, n);
	}else {
	  bandMATRIX(     "scomplex", a, bw, 0, n);
	  bandDISTRIBUTE( "scomplex", a, bw, 0, n);
	}	

	MATRIX("scomplex", b, ROW_b, COL_b);
	DISTRIBUTE("scomplex", b, ROW_b, COL_b);

	laf =   (cbloc+2*bw)*bw;
	locaf = MALLOC(sizeof(scomplex)*laf);
        assert(locaf);

	llocwork = worklen(nrhs, bw);
	WORK(locwork,llocwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pcpbtrs)( &uplo, &n, &bw, &nrhs,
                               loca, &one, desca,
                               locb, &one, descb,
                               locaf, &laf,
                               locwork, &llocwork, &linfo);

	GATHER("scomplex", b, ROW_b, COL_b);

	if (chrcmp(uplo,'u')==0) {
	  bandGATHER( "scomplex", a, 0, bw, n);
	}else {
	  bandGATHER( "scomplex", a, bw, 0, n);
	}	

	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
            *info = linfo;
	} else {
	}
	FREE_MATRIX(a);
	FREE_MATRIX(b);

        FREE(locwork);
        FREE(locaf);
	
}

