package ninf.monitor;
import java.awt.*;
import ninf.basic.*;
import ninf.metaserver.NinfServerHolder;
import ninf.common.*;


class ServerLoadMonitor implements Runnable {
  static final int LOADBUFFERSIZE = 1000;

  ServerMonitor monitor;
  NinfServerHolder holder;
  double loads[];
  int current = 0;
  int sleepTime = 3;

  ServerLoadMonitor(ServerMonitor monitor, NinfServerHolder holder){
    this.monitor = monitor;
    this.holder = holder;
    loads = new double[LOADBUFFERSIZE];
  }

  double getVal(int i){
    int index = (current % loads.length) -1 - i;
    while (index < 0)
      index += loads.length;
    return loads[index];

  }

  void tick(){
    if (holder.load == null) return;
    loads[current++ % loads.length] = holder.load.loadAverage;
    monitor.repaint();
  }

  public void run(){
    for (;;){
      try {
	tick();
	Thread.sleep(sleepTime * 1000);
      } catch (InterruptedException e){
	System.out.println(e);
      }
    }
  }
}
