package ninf.monitor;
import ninf.basic.*;
import ninf.common.*;
import ninf.client.*;
import ninf.metaserver.*;
import java.io.IOException;
import java.io.*;
import java.util.StringTokenizer;
import java.util.Hashtable;
import java.util.Enumeration;

public class Monitor{
  static NinfLog dbg = new NinfLog("Monitor");

  MetaServerReference server;
  MetaServerConnection command;
  MetaServerConnection inform;
  MetaServerConnection logConnection;

  MonitorPanel panel;
  MonitorReceive receive;
  
  Hashtable holders;   // struct -> holder
  Hashtable serverMonitors;   // struct -> serverMonitor
  Hashtable functionTable;  /* key = FunctionName, val = FunctionStruct */

  ServerPinger serverPinger;
  Thread serverPingerThread;
  FunctionPinger functionPinger;
  Thread functionPingerThread;
  Thread forwarder;

  public Monitor(MonitorPanel panel){
    this.panel = panel;
    holders = new Hashtable();
    serverMonitors = new Hashtable();
    functionTable = new Hashtable(); 
  }

  void disconnect(){
    if (command != null){
      command.close();
      command = null;
    }
    if (inform != null){
      inform.close();
      inform = null;
    }
    if (logConnection != null){
      logConnection.close();
      logConnection = null;
    }

    Enumeration enum = serverMonitors.elements();
    while (enum.hasMoreElements()){
      ServerMonitor smPanel = (ServerMonitor)(enum.nextElement());
      smPanel.dispose();
    }
    serverMonitors = new Hashtable();
    holders = new Hashtable();

    if  (functionPingerThread != null){
      functionPingerThread.stop();
      if (functionPinger != null)
	functionPinger.disconnect();
      functionPingerThread = null;
    }
    if  (serverPingerThread != null){
      serverPingerThread.stop();
      serverPingerThread = null;
    }

    if  (forwarder != null){
      forwarder.stop();
      forwarder = null;
    }
    updateFunctionTable(new Hashtable());
    updateServerList();
  }
  
  boolean connected(){
    return (command != null);
  }

  boolean connect(String host, String port){
    try {
      if (command != null){
	panel.print(" already connected.. ");
	return false;
      }
      server = new MetaServerReference(host, port);
      command = server.connect();
      inform = server.connect();
      inform.os.println("inform");
      receive = new MonitorReceive(inform.is, panel, this);
      (new Thread(receive)).start();

      logConnection = server.connect();
      logConnection.os.println("getLog");
      
      forwarder = new Thread(new ForwardLine(panel, logConnection.is));
      forwarder.start();

      functionPinger = new FunctionPinger(this);
      functionPingerThread = new Thread(functionPinger);
      functionPingerThread.start();

      serverPinger = new ServerPinger(server, 30, this);
      serverPingerThread = new Thread(serverPinger);
      serverPingerThread.start();

    } catch (NinfException e){
      //      panel.println(e);
      return false;
    }
    return true;
  }

  boolean confirm(){
    String tmp;
    try {
      tmp = command.is.readLine();
    } catch (IOException e){
      return false;
    }
    if (tmp == null)
      return false;
    panel.println(tmp);
    if (tmp.equals("+OK"))
      return true;
    else
      return false;
  }

  synchronized String getScheduler(){
    command.os.println("getScheduler");
    if (!confirm())
      return null;
    String tmp;
    try {
      tmp = command.is.readLine();
    } catch (IOException e){
      return null;
    }
    return trimPackage(tmp);
  }

  synchronized String getPredictors(){
    command.os.println("getPredictors");
    String tmp;
    if (!confirm())
      return null;
    try {
      tmp = command.is.readLine();
      System.out.println("Predictor " + tmp);
    } catch (IOException e){
      return null;
    }

    StringTokenizer st = new StringTokenizer(tmp);
    String predStr = "";
    st.nextToken();  // discard first predictor
    while (st.hasMoreTokens()){
      if (!(predStr.equals("")))
	predStr += " ";
      predStr += trimPackage(st.nextToken());
    }
    System.out.println("Predictor " + predStr);
    return predStr;
  }

  synchronized boolean selectScheduler(String str){
    if (command == null){
      panel.println("Connect, First.");
      return false;
    } else if (str.equals("")){
      return false;
    } else {
      command.os.println("scheduler "+ str);
      return confirm();
    }
  }

  synchronized boolean selectPredictor(String str){
    if (command == null){
      panel.println("Connect, First.");
      return false;
    } else if (str.equals("")){
      return false;
    } else {
      command.os.println("initPredictor");
      if (!confirm()) return false;

      StringTokenizer st = new StringTokenizer(str);
      while (st.hasMoreTokens()){
	command.os.println("pushPredictor "+ st.nextToken());
	if (!confirm()) return false;      
      }
      return true;
    }
  }

  synchronized ServerCharacter getServerCharacter(NinfServerStruct struct)
                throws NinfException {
    command.os.println("getServerCharacter");
    struct.toCommand().send(command.os);
    ServerCharacter sChar = new ServerCharacter(command.is);
    return sChar;
  }

  synchronized FunctionName[] getFuncs(NinfServerStruct struct){
    CommandRepresent acceptCommands[] = {
      new CommandRepresent("functionNames", 1),
      new CommandRepresent("stub", 0)
    }; 
    int count = 0;

    CommandParser parser = new CommandParser(acceptCommands);
    try {
      new NinfCommand("getServerStubs", struct.host, ""+struct.port)
	.send(command.os);
      NinfCommand com = parser.readCommand(command.is);
      count = (new Integer(com.args[0])).intValue();
    } catch (NinfException e){
      e.printStackTrace();
      return new FunctionName[0];
    }

    FunctionName names[] = new FunctionName[count];
    try {
      for (int i = 0; i < count; i++){
	names[i] = new FunctionName(command.is.readLine());
	System.out.println(names[i]);
      }
    } catch (IOException e){
      return new FunctionName[0];
    }
    return names;
  }

  void inform(NinfServerStruct struct, String str){
    ServerMonitor monitor = (ServerMonitor)serverMonitors.get(struct);
    monitor.println(str);
  }

  synchronized NinfServerHolder addNewServer(NinfServerStruct struct){
    NinfServerHolder holder = (NinfServerHolder)holders.get(struct);
    if (holder == null){
      holder = new NinfServerHolder(struct, null);
      try {
	holder.serverChar = getServerCharacter(struct);
      } catch (NinfException e){
      }
      ServerMonitor serverMonitor = new ServerMonitor(this, holder);
      serverMonitor.show();
      serverMonitors.put(struct, serverMonitor);
      holders.put(struct, holder);
      updateServerList();
    }
    return holder;
  }

  void serverLoad(NinfServerStruct struct, LoadInformation load) {
    NinfServerHolder holder = addNewServer(struct);
    holder.load = load;
  }

  void launch(NinfServerStruct struct){
    ServerMonitor monitor = (ServerMonitor)serverMonitors.get(struct);
    monitor.show();
  }

  void functionTablePing(){
    functionPinger.ping();
  }

  void updateFunctionTable(Hashtable newtable){
    functionTable = newtable;
    panel.stubPanel.makeList();
  }

  void updateServerList(){
    panel.serverListPanel.makeList();
  }

  void selectFuncs(FunctionName[] names){
    panel.stubPanel.selectFuncs(names);
  }

  void selectServers(FunctionName name){
    panel.serverListPanel.selectServers(name);
  }

  /******** other **********/

  String trimPackage(String str){
    StringTokenizer st = new StringTokenizer(str, ".");
    String tmp = "";
    while (st.hasMoreTokens())
      tmp = st.nextToken();
    return tmp;
  }

  /********    MAIN     ********/
  public static void main(String args[]){
    (new MonitorPanel("hpc", "3050")).show();
  }
  
}
