#define _WRAPPER_
/* $Id: pdlaed3_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define _DISTRIBUTE_1D_
#define DOUBLE
#include <gscalapack.h>

#define ROW_u ldu
#define COL_u n
void  pdlaed3_ninf(	
		 int *k,
		 int n,
		 double d[],
		 double *rho,
		 double dlamda[],
		 double w[],
		 double z[],
		 double global_u[],
		 int ldu,
		 int indx[],
		 int indxr[],
		 int indxc[],
		 int *info
)
/* "pdlaed3 finds the roots of the secular equation, as defined by the values in D, W, and RHO, between 1 and K." */
/* OPTIONS */
{
	int nb;
	int maxldd;
	int *buf, *indcol, *indrow, *ctot;

	int maxldu;
	double *locu=NULL;
        int desc_gu[DESCLEN];
        int descu[DESCLEN];
	int row_locu, col_locu;

        double *locw=NULL;

	INITIALIZE();

	SCALAR( "int", n);
	SCALAR( "int", ldu);

	SIZE(n);

	nb = cbloc;

	COMMON("double", d, n);
	COMMON("double", rho, 1);
	COMMON("double", z, n);
        COMMON("double",dlamda, n);

	ROW(u);
	COL(u);
	MAXLDD(maxldd, u);
	maxldu = maxldd;

	MATRIX("double", u, ROW_u, COL_u);

	locw = MALLOC(sizeof(double)*n);
        assert(locw);

	WORK(buf, 3*n);
	IWORK(indcol, n);
	IWORK(indrow, n);
	IWORK(ctot, npcol*4);

	if  (( mypnum != 0 ) ^ (serial==1) )
		FortranCall(pdlaed3)( &PARA_CTXT,
				      k, &n, &nb,
				      d, &zero, &zero,
				      &rho, dlamda, locw, z,
				      locu, &row_locu,
				      buf,
				      indx, indcol, indrow,
				      indxr, indxc, ctot, &npcol,
				      &linfo);

	GATHER( "double", u, ROW_u, COL_u);

	RETRIEVE("int", k, 1);
	RETRIEVE("double", d, n);

	RETRIEVE("double", rho, 1);
	RETRIEVE("double", dlamda, n);
	RETRIEVE("double", locw, n);

	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
		int i;
		*info = linfo;
		for(i=0;i<n;i++) w[i] = locw[i];
	} else {
	}
        
        FREE_COMMON(d);
        FREE_COMMON(rho);
        FREE_COMMON(z);
        FREE_COMMON(dlamda);

        FREE_MATRIX(u);
	FREE(locw);
}

