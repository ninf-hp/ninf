#define _WRAPPER_
/* $Id: pslaset_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define FLOAT
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n
void  pslaset_ninf(	 char uplo,
		 int m,
		 int n,
		 float alpha,
		 float beta,
		 float global_a[],
		 int lda
	)
/* "pslaset initializes an M-by-N distributed matrix A to BETA on the diagonal and ALPHA on the offdiagonals." */
/* OPTIONS */
{
	int maxldd;

	int maxlda;
	float *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
	int row_loca, col_loca;

	INITIALIZE();

	SCALAR( "char", uplo);
	SCALAR( "int", m);
	SCALAR( "int", n);
	SCALAR( "float", alpha);
	SCALAR( "float", beta);
	SCALAR("int", lda);

	ROW( a);
	COL( a);
	MAXLDD( maxldd, a );
	maxlda = maxldd;
	MATRIX( "float", a, ROW_a, COL_a);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pslaset)( &uplo,
                               &m, &n,
                               &alpha, &beta,
                               loca, &one, &one, desca);

	GATHER( "float", a, ROW_a, COL_a);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
	} else {
	}

	FREE_MATRIX(a);
	
}

