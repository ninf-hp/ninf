#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#include "ninf_data_trans.h"
#include "ninf_server_state.h"

server_state * new_server_state(int socket, int withHeader){
  server_state * tmp = (server_state *)malloc(sizeof(server_state));

  tmp->client   = new_connection(socket, TRUE);
  tmp->stub     = NULL;
  tmp->stub_out = NULL;
  tmp->stub_err = NULL;
  return tmp;
}

void destruct_server_state(server_state * state){
  if (state->client != NULL)
    ninf_disconnect(state->client);
  if (state->stub != NULL)
    ninf_disconnect(state->stub);
  if (state->stub_out != NULL)
    ninf_disconnect(state->stub_out);
  if (state->stub_err != NULL)
    ninf_disconnect(state->stub_err);
  free(state);
}

/***************************/

void fd_set_zero(ninf_fd_set * prfds){
      FD_ZERO(&(prfds->fds));
      prfds->max = 0;
}

void fd_set_set_fd(ninf_fd_set * prfds, int fd){
  FD_SET(fd, &(prfds->fds));
  if (prfds->max < fd)
    prfds->max = fd;
}

void fd_set_set_connection(ninf_fd_set *prfds, connection * con){
  if (con != NULL)
    fd_set_set_fd(prfds, connection_get_fd(con));
}

int fd_set_max(ninf_fd_set * prfds){
  return prfds->max;
}

int fd_set_is_set_fd(ninf_fd_set *prfds, int fd){
  return FD_ISSET(fd, &(prfds->fds));
}

int fd_set_is_set_connection(ninf_fd_set *prfds, connection * con){
  if (con == NULL)  
    return FALSE;
  return fd_set_is_set_fd(prfds, connection_get_fd(con));
}
