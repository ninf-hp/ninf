#ifndef _GSCAPACK_MISC_H_
#define _GSCAPACK_MISC_H_

#ifdef _LOCAL_
/* Other Routines            */
extern int Cnumroc ( int n, int nb, int iproc, int isrcproc, int nprocs );
extern int Cindxg2p(int,int, int, int,int);
extern int Cindxg2l(int,int, int, int,int);
extern int Cindxl2g(int,int, int, int,int);
extern int Ciceil(int , int );
extern int Cilcm( int m, int n);
#endif

#define LOCc(n) Cnumroc( (n), cbloc, mypcol, 0, npcol)
#define LOCr(m) Cnumroc( (m), rbloc, myprow, 0, nprow)
#define NUMROC(m,mb,myprow,src,nprow) Cnumroc((m),(mb),(myprow),(src),(nprow))

#define INDXG2P(ia,mb,myprow,src,nprocs) Cindxg2p((ia),(mb),(myprow),(src),(nprocs))

#define INDXG2L(ia,mb,myprow,src,nprocs) Cindxg2l((ia),(mb),(myprow),(src),(nprocs))

#define CEIL(a,b) Ciceil((a),(b))
#define ceil(a,b) Ciceil((a),(b))

#define LCM(m,n) Cilcm((m),(n))
#define lcm(m,n) Cilcm((m),(n))

#define MAX(x, y)   ((x) > (y) ? (x) : (y))
#define MIN(x, y)   ((x) < (y) ? (x) : (y))
#define MAX3(x, y, z)  MAX(MAX((x), (y)), (z))

#define M m
#define N n
#define NRHS nrhs

#define RSRC 0
#define CSRC 0
#define IA 1
#define JA 1
#define MB_A rbloc
#define NB_A cbloc
#define RSRC_A 0
#define CSRC_A 0
#define IB 1
#define JB 1
#define MB_B rbloc
#define NB_B cbloc
#define RSRC_B 0
#define CSRC_B 0
#define MYROW myprow
#define MYCOL mypcol
#define MYPROW myprow
#define MYPCOL mypcol
#define NPROW nprow
#define NPCOL npcol

#define MB_C rbloc
#define NB_C cbloc
#define RSRC_C 0
#define CSRC_C 0
#define IC 1
#define JC 1

#define _IAROW  INDXG2P( IA+1, MB_A, MYROW, RSRC_A, NPROW )
#define _IACOL  INDXG2P( JA+1, NB_A, MYCOL, CSRC_A, NPCOL )

#endif
