#define _WRAPPER_
/* $Id: pclaevswp_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define SCOMPLEX
#include <gscalapack.h>

#define ROW_zin ldzi /* length of an Eigenvector */
#define COL_zin n /* Total number of Eigenvectors */
#define ROW_z n
#define COL_z n
static	int worklen(int n) {
	  int ret=1;
	  int MINI, MAXI;
#define IZ 1
          ret = ROW_Z+n+10;
	  if (mypnum!=0) {
	    MINI = MAX( ROW_z, IZ );
	    MAXI = MIN( ROW_z+ rbloc-1, n+IZ-1 );
	    ret = MAXI-MINI+10;
	  }
	  return ret;
}

void  pclaevswp_ninf(	 int n,
			 float global_zin[],
			 int ldzi,
			 scomplex global_z[],
			 int nvs[],
			 int key[]

)
/* "pclaevswp moves the eigenvectors (potentially unsorted) from where they are computed, to a array, sorted so that the corresponding eigenvalues are sorted." */
/* OPTIONS */
{
	int maxldd;

	float *loczin=NULL;
	int maxldzin;
	int desczin[DESCLEN];
	int desc_gzin[DESCLEN];
	int row_loczin, col_loczin;

	scomplex *locz=NULL;
	int maxldz;
	int descz[DESCLEN];
	int desc_gz[DESCLEN];
	int row_locz, col_locz;

	int *nvs=NULL;
	float *locwork=NULL;
	int   llocwork;


	INITIALIZE();

	SCALAR( "int", n);
	SCALAR( "int", ldzi);

	COMMON( "int",key, n);
	COMMON( "int",nvs, nprocs+1);

	ROW(zin);
	COL(zin);
	MAXLDD( maxldd, zin );
	maxldzin=maxldd;
        
	ROW(z);
	COL(z);
	MAXLDD( maxldd, z );
	maxldz=maxldd;

	MATRIX( "float", zin, ROW_zin, COL_zin);
	MATRIX( "scomplex", z, ROW_z, COL_z);

	llocwork=worklen(n);
	_work("float",&locwork,llocwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pclaevswp)( &n,
                                 loczin, &ldzi,
                                 locz, &one, &one, descz,
                                 nvs,
                                 key,
                                 locwork, &llocwork);

	GATHER( "scomplex", z, ROW_z, COL_z);

	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){

	} else {
	}
        FREE_MATRIX(z);
        FREE_MATRIX(zin);
	FREE_COMMON(key);
	FREE_COMMON(nvs);
}

