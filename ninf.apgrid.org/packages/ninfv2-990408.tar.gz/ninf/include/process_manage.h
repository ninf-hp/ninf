
#ifndef __PROCESS_MANAGER__
#define __PROCESS_MANAGER__
#include "ninf_macros.h"

void process_manager_init();
void process_manager_forked(int pid, int socket);
void process_manager_died(int pid);
BOOLEAN process_manager_is_exceed_limit();

#endif 
