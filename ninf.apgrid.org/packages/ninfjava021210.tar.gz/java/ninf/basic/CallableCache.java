package ninf.basic;
import ninf.client.*;
import ninf.common.*;
import java.util.Vector;
import java.util.Hashtable;
import java.util.Enumeration;

public class CallableCache{
  static final int MATCH_PARTIAL = 0;
  static final int MATCH_EXACT   = 1;
  
  static NinfLog dbg = new NinfLog("CallableCache");
  public Hashtable stubCallables = new Hashtable();
  public Vector callables = new Vector();
  
  public CallableCache(){
  }

  int currentIndex = 0;

  public synchronized int getIndex(){
    return currentIndex++;
  }

  public Callable[] findCallables(String name, int option) {
    Vector tmp = new Vector();
    Enumeration enum = stubCallables.keys();
    while (enum.hasMoreElements()){
      FunctionName funcname = (FunctionName)enum.nextElement();
      if (option == MATCH_EXACT){
	if (funcname.equals(name))
	  tmp.addElement(stubCallables.get(funcname));
      } else {
	if (funcname.partialMatch(name))
	  tmp.addElement(stubCallables.get(funcname));
      }
    }
    Callable[] ans = new Callable[tmp.size()];
    for (int i = 0; i < tmp.size(); i++)
      ans[i] = (Callable)tmp.elementAt(i);
    return ans;
  }

  public Callable getCallable(int index) throws NinfException {
    try {
      Callable tmp = (Callable)callables.elementAt(index);
      if (tmp != null)
	return tmp;
      throw new NinfErrorException(NinfError.STUBREMOVED);
    } catch (ArrayIndexOutOfBoundsException e){
      throw new NinfErrorException(NinfError.STUBREMOVED);
    }
  }
  public Callable getStubCallable(FunctionName fullName) throws NinfException {
    Callable stub = (Callable)stubCallables.get(fullName);
    if (stub != null)
      return stub;
    throw new NinfErrorException(NinfError.CANTFINDSTUB);
  }

  public void registerCallable(FunctionName fullName, Callable callable, int index){
    if (callables.size() <= index)
      callables.setSize(index + 10);
    callables.setElementAt(callable, index);
    stubCallables.put(fullName, callable);
  }
}
