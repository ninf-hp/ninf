#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "ninf_macros.h"
#include "ninf_read_config.h"
#include "throughput_measure.h"
#include "metaserver.h"

#include "ninf_config.h"

char * save_str();

#define MAXCOMMANDLEN 256
static char * NWSNameServer = NULL;

static char * sensorExecutable = "network_sensor";
static char * memoryExecutable = "nws_memory";
static char * forecasterExecutable = "nws_forecast";


static void invokeMemory(char * NWSNameServer){
  char buffer[MAXCOMMANDLEN];
  sprintf(buffer, "%s/%s", NWSdir, memoryExecutable);
  if (fork() == 0) { /* I'm child */
    execl(buffer, memoryExecutable, "-d", NWSMemoryDir, "-N", NWSNameServer,
	  (NWSMemoryErr == NULL)? "":"-e", 
	  (NWSMemoryErr == NULL)? "": NWSMemoryErr,
	  (NWSMemoryLog == NULL)? "":"-l", 
	  (NWSMemoryLog == NULL)? "": NWSMemoryLog);
    perror("exec nws_memory:");
    exit(3);
  }
}

static void invokeSensor(char * NWSNameServer, char * Memory){
  char buffer[MAXCOMMANDLEN];
  sprintf(buffer, "%s/%s", NWSdir, sensorExecutable);
  if (fork() == 0) { /* I'm child */
    execl(buffer, sensorExecutable, "-M", Memory, "-N", NWSNameServer);
    perror("exec nws_sensor:");
    exit(3);
  }
}

static void invokeForecaster(char * NWSNameServer){
  char buffer[MAXCOMMANDLEN];
  sprintf(buffer, "%s/%s", NWSdir, forecasterExecutable);
  if (fork() == 0) { /* I'm child */
    execl(buffer, forecasterExecutable, "-N", NWSNameServer);
    perror("exec nws_forecaster:");
    exit(3);
  }
}

static char * getNWSNameServer(){
  char buffer[MAXCOMMANDLEN];
  char * answer;
  metaConnection * meta;

  struct metaserver_item * p = metaserver_item_root;
  if (p == NULL){
    ninf_log("couldn't get metaserver");
    return NULL;
  }
  if  ((meta = metaserver_connect(p->hostname, p->port)) == NULL){
    ninf_log("couldn't introduce to metaserver: can't connect to metaserver: %s, %s",
	     p->hostname, p->port);
    return;
  }
  metaserver_send(meta, "getNWSNameServer");
  metaserver_flush(meta);
  
  answer = metaserver_getLine(meta, buffer, MAXCOMMANDLEN);
  if (answer == NULL || answer[0] == '-'){
    ninf_log("couldn't get NWSNameServer from metaserver");
    return NULL;
  }
  answer = metaserver_getLine(meta, buffer, MAXCOMMANDLEN);
  metaserver_close(meta);
  return save_str(answer);
}

int nws_initialize(){
  if (!NWSuse)
    return TRUE;
  if (NWSdir = NULL){
    ninf_error("'NWSdir' is not specified in config file");
    return FALSE;	      
  }

  if (NWSinvokeSensor && NWSMemoryDir == NULL){
    ninf_log("'NWSMemoryDir' is not specified in config file");
    return FALSE;	      
  }      

  NWSNameServer = getNWSNameServer();
  if (NWSNameServer == NULL){
    ninf_log("cannot get NWSNameServer from Scheduler");
    return FALSE;	      
  }      

  if (NWSinvokeSensor){
    invokeMemory(NWSNameServer);
    invokeSensor(NWSNameServer, myname);
  }
  if (NWSinvokeForecaster){
    invokeForecaster(NWSNameServer);
  }
}
