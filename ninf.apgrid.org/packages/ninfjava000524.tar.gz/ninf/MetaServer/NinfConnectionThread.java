
package ninf.MetaServer;
import ninf.basic.*;
import ninf.client.*;

import java.io.IOException;
import java.util.Vector;

public class NinfConnectionThread extends NinfThread {
  int index;
  NinfNativeCallable func;
  Stoppable con;
  Vector args;
  NinfLog dbg = new NinfLog(this);
  int retryCount = 3;

  public NinfConnectionThread(int i, NinfNativeCallable f, Vector a){
    index = i;
    func = f;
    args = a;
  }
  public void runSub() {
    dbg.println("NinfConnectionThread No."+ index + " Starts");
    if (!succeeded){
      dbg.println("NinfConnectionThread No."+ index + " already failed");
      return;
    }
    try {
          Connected connected = func.connect();
            con = connected.stop;
	    con = func.callWith(connected, args); 
      //      con = func.callNative(args);
    } catch(NinfStoppedByUserException e) {
      dbg.println("NinfConnectionThread No."+ index + " stopped by user");
      succeeded = false;
    } catch(NinfException e) {
      dbg.println("NinfConnectionThread No."+ index + " failed");
      if (--retryCount >= 0)
	runSub();
      else
	succeeded = false;
    } finally {
      dbg.println("NinfConnectionThread No."+ index + " finished");
    }
  }
  public void kill(){
    dbg.println("NinfConnectionThread No."+ index + " killed. con = " + con);
    if (con != null) con.stop();
//    super.kill();
  }
}

// end of NinfConnectionThread.java
