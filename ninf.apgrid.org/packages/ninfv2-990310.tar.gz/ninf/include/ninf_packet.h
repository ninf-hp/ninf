#ifndef _NINF_PACKET_H_
#define _NINF_PACKET_H_

typedef struct ninf_packet_header
{
  char header[16];
/*    int size;  for packet size
      int code;  for task code 
      int arg1;	 for task args  
      int arg2;	 ???            */
} NINF_PKT_HEADER;

typedef struct decoded_header
{
    int size;  
    int code;  
    int arg1;	
    int arg2;	
} DECODED_HEADER;

#define NINF_PKT_HEADER_SIZE	sizeof(NINF_PKT_HEADER)
#define NINF_PKT_SIZE(p)	((p)->size)
#define NINF_PKT_CODE(p)	((p)->code)
#define NINF_PKT_ARG1(p)	((p)->arg1)
#define NINF_PKT_ARG2(p)	((p)->arg2)

#define MAX_PKT_LEN		0x1000	/* 4K */

/* packet code in packet level protocol */
#define NINF_PKT_ERROR		(-1)	/* error, negative code */
#define NINF_PKT_NONE		0	
#define NINF_PKT_KILL		1	/* kill */
#define NINF_PKT_TO_STUB	2	/* send client to stub */
#define NINF_PKT_TO_CLIENT	3	/* send stub to client */
#define NINF_PKT_REQ_STUB_INFO	4	/* request stub info */
#define NINF_PKT_RPY_STUB_INFO	5	/* reply ... */
#define NINF_PKT_REQ_CALL	6	/* request call */
#define NINF_PKT_RPY_CALL	7	/* reply ... */

#ifdef DUMP_TIME
#define NINF_PKT_SET_SKIP_TIME  8       /* set dump_skip_time */
#define NINF_PKT_ACK_SKIP_TIME  9       /* set dump_skip_time */
#endif
#define NINF_PKT_REQ_COMP   10      /* request compound stub */
#define NINF_PKT_RPY_KILL   11      /* reply kill pkt */

#define NINF_PKT_STDOUT         15      /* for forwarding stdout */
#define NINF_PKT_STDERR         16      /* for forwarding stderr */

#define NINF_PKT_GET_STORAGE_RESOURCE    17 /* get storage_resource */
#define NINF_PKT_PUT_STORAGE_RESOURCE    18 /* put storage_resource */
#define NINF_PKT_CLEAR_STORAGE_RESOURCE  19 /* clear storage_resource */
#define NINF_PKT_RPY_STORAGE_RESOURCE    20 /* put storage_resource */

#define NINF_PKT_TRANSFER                21 /* for transer */
#define NINF_PKT_TRANSFER_END            22 /* for terminate transer */
#define NINF_PKT_RPY_TRANSFER_END        23 /* for reply termination packet */

/* NINF_Q_Protocols */
#define NINF_PKT_REQ_STUB_INDEX_LIST 50  /* req stub index list */
#define NINF_PKT_RPY_STUB_INDEX_LIST 51  /* rpy stub index list */ 
#define NINF_PKT_REQ_STUB_BY_INDEX   52  /* req stub by index */


#define NINF_PKT_NEW_SERVER 100 /* register new server info to metaserver */
#define NINF_PKT_NEW_STUB 101   /* register new stub info to metaserver */

#define NINF_PKT_THROUGHPUT         102  /* to get throughtput    arg1 = size, arg2 = mode(0=both,1=fore,2=back) */
#define NINF_PKT_RPY_THROUGHPUT     103  /* RPRY */

#define NINF_PKT_LOAD               104  /* to get load information */
#define NINF_PKT_RPY_LOAD           105  /* RPRY */

#define NINF_PKT_CHARACTER          106  /* to get server character */
#define NINF_PKT_RPY_CHARACTER      107  /* reply */

#define NINF_PKT_GETTIME            108  /* request for time in double (sec. from 1970/1/1)*/
#define NINF_PKT_RPY_GETTIME        109  /* for time synchronization */


#define NINF_DUMP_MS_INFO 200   /* get info from metaserver */

#define NINF_PKT_REQ_EXEC	0xFE	/* exec stub program directly */
#define NINF_PKT_RPY_EXEC	0xFF	/* reply ... */

#define NINF_PKT_AUTH           110
#define NINF_PKT_AUTH_OK        111

#endif /* _NINF_PACKET_H_ */
