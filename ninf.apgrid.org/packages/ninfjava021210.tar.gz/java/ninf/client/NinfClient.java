package ninf.client;

import java.io.*;
import java.util.Vector;
import ninf.basic.*;

public class NinfClient {
 //  protected NinfServerStruct struct;
  protected NinfServerConnection con;
  OutputStream stdoutStream, stderrStream;

  protected static ClientConfig classConfig = new ClientConfig();
  protected ClientConfig config;

  public NinfClient(String h, int p) throws NinfIOException{
    String tmp = h;
    if (h == null){
      tmp = System.getProperty("HOST");
    }
    config = classConfig.copy();
    config.setServerPort(tmp, p);
    init();
  }

  public NinfClient() throws NinfIOException{
    init();
  }

  private void init(){
    stdoutStream = System.out;
    stderrStream = System.err;
  }

  private ClientConfig getConfig(){
    if (config != null) 
      return config;
    else
      return classConfig;
  }

  /** to enable debug output */
  public static void verbose(){
    NinfLog.verbose();
  }

  /** to suppress log output */
  public static void quiet(){
    NinfLog.quiet();
  }

  /** set redirect stream for stdout */
  public void setStdoutStream(OutputStream stdoutStream){
    this.stdoutStream = stdoutStream;
  }

  /** set redirect stream for stdout and stderr */
  public void setStderrStream(OutputStream stderrStream){
    this.stderrStream = stderrStream;
  }

  /** set default server and port */
  public static void setDefaultServer(String server, int port){
    classConfig.setServerPort(server, port);
  }
  /** set default server and port */
  public static void setDefaultServer(String server, String port){
    setDefaultServer(server, Integer.valueOf(port).intValue());
  }

  /** set instance server and port */
  public void setServer(String server, int port){
      if (config == null)
	  config = classConfig.copy();
      config.setServerPort(server, port);
  }

  /** set instance server and port */
  public void setServer(String server, String port){
      setServer(server, Integer.valueOf(port).intValue());
  }

  public void setShellMode(int mode){
    config.setShellMode(mode);
  }

  public static String[] parseArg(String arg[]){
    return classConfig.parseArg(arg);
  }

  public void connectServer()throws NinfException{
    con = new NinfServerConnection(getConfig(),
				   stdoutStream, stderrStream);
  }

  public void disconnect(){
    if (con != null) con.close();
    con = null;
  }

  public NinfExecInfo call(String func, Vector args) throws NinfException{
    this.connectServer();
    NinfExecInfo execInfo = con.call(func, args);
    this.disconnect();
    return execInfo;
  }

  public NinfExecInfo callWith(String name, Object a1) 
      throws NinfException{
      Vector arg = new Vector();
      arg.addElement(a1);
      return this.call(name, arg);
  }
  public NinfExecInfo callWith(String name, Object a1, Object a2) 
      throws NinfException{
      Vector arg = new Vector();
      arg.addElement(a1);       arg.addElement(a2);
      return this.call(name, arg);
  }
  public NinfExecInfo callWith(String name, Object a1, Object a2, Object a3) 
      throws NinfException{
      Vector arg = new Vector();
      arg.addElement(a1);  arg.addElement(a2); arg.addElement(a3);
      return this.call(name, arg);
  }

  public NinfExecInfo callWith(String name, Object a1, Object a2, Object a3, Object a4) 
    throws NinfException{
    Vector arg = new Vector();
    arg.addElement(a1); arg.addElement(a2); arg.addElement(a3); arg.addElement(a4);
    return this.call(name, arg);
  }

  public NinfExecInfo callWith(String name, Object a1, Object a2, Object a3, Object a4, 
		                    Object a5) 
    throws NinfException{
    Vector arg = new Vector();
    arg.addElement(a1); arg.addElement(a2); arg.addElement(a3); arg.addElement(a4);
    arg.addElement(a5);
    return this.call(name, arg);
  }
  public NinfExecInfo callWith(String name, Object a1, Object a2, Object a3, Object a4, 
		                    Object a5, Object a6) 
    throws NinfException{
    Vector arg = new Vector();
    arg.addElement(a1); arg.addElement(a2); arg.addElement(a3); arg.addElement(a4);
    arg.addElement(a5); arg.addElement(a6);
    return this.call(name, arg);
  }
  public NinfExecInfo callWith(String name, Object a1, Object a2, Object a3, Object a4, 
		                    Object a5, Object a6, Object a7) 
    throws NinfException{
    Vector arg = new Vector();
    arg.addElement(a1); arg.addElement(a2); arg.addElement(a3); arg.addElement(a4);
    arg.addElement(a5); arg.addElement(a6); arg.addElement(a7);
    return this.call(name, arg);
  }
  public NinfExecInfo callWith(String name, Object a1, Object a2, Object a3, Object a4, 
		                    Object a5, Object a6, Object a7, Object a8) 
    throws NinfException{
    Vector arg = new Vector();
    arg.addElement(a1); arg.addElement(a2); arg.addElement(a3); arg.addElement(a4);
    arg.addElement(a5); arg.addElement(a6); arg.addElement(a7); arg.addElement(a8);
    return this.call(name, arg);
  }
  public NinfExecInfo callWith(String name, Object a1, Object a2, Object a3, Object a4, 
		                    Object a5, Object a6, Object a7, Object a8,
		                    Object a9)
    throws NinfException{
    Vector arg = new Vector();
    arg.addElement(a1); arg.addElement(a2); arg.addElement(a3); arg.addElement(a4);
    arg.addElement(a5); arg.addElement(a6); arg.addElement(a7); arg.addElement(a8);
    arg.addElement(a9);
    return this.call(name, arg);
  }
  public NinfExecInfo callWith(String name, Object a1, Object a2, Object a3, Object a4, 
		                    Object a5, Object a6, Object a7, Object a8,
		                    Object a9, Object a10)
    throws NinfException{
    Vector arg = new Vector();
    arg.addElement(a1); arg.addElement(a2); arg.addElement(a3); arg.addElement(a4);
    arg.addElement(a5); arg.addElement(a6); arg.addElement(a7); arg.addElement(a8);
    arg.addElement(a9);arg.addElement(a10);
    return this.call(name, arg);
  }
  public NinfExecInfo callWith(String name, Object a1, Object a2, Object a3, Object a4, 
		                    Object a5, Object a6, Object a7, Object a8,
		                    Object a9, Object a10, Object a11)
    throws NinfException{
    Vector arg = new Vector();
    arg.addElement(a1); arg.addElement(a2); arg.addElement(a3); arg.addElement(a4);
    arg.addElement(a5); arg.addElement(a6); arg.addElement(a7); arg.addElement(a8);
    arg.addElement(a9);arg.addElement(a10);arg.addElement(a11);
    return this.call(name, arg);
  }

  public NinfExecInfo callWith(String name, Object a1, Object a2, Object a3, Object a4, 
		                    Object a5, Object a6, Object a7, Object a8,
		                    Object a9, Object a10, Object a11, Object a12) 
    throws NinfException{
    Vector arg = new Vector();
    arg.addElement(a1); arg.addElement(a2); arg.addElement(a3); arg.addElement(a4);
    arg.addElement(a5); arg.addElement(a6); arg.addElement(a7); arg.addElement(a8);
    arg.addElement(a9);arg.addElement(a10);arg.addElement(a11);arg.addElement(a12);
    return this.call(name, arg);
  }

  public NinfExecInfo callWith(String name, Object a1, Object a2, Object a3, Object a4, 
		                    Object a5, Object a6, Object a7, Object a8,
		                    Object a9, Object a10, Object a11, Object a12,
			            Object a13)
    throws NinfException{
    Vector arg = new Vector();
    arg.addElement(a1); arg.addElement(a2); arg.addElement(a3); arg.addElement(a4);
    arg.addElement(a5); arg.addElement(a6); arg.addElement(a7); arg.addElement(a8);
    arg.addElement(a9);arg.addElement(a10);arg.addElement(a11);arg.addElement(a12);
    arg.addElement(a13);
    return this.call(name, arg);
  }
  public NinfExecInfo callWith(String name, Object a1, Object a2, Object a3, Object a4, 
		                    Object a5, Object a6, Object a7, Object a8,
		                    Object a9, Object a10, Object a11, Object a12,
			            Object a13, Object a14)
    throws NinfException{
    Vector arg = new Vector();
    arg.addElement(a1); arg.addElement(a2); arg.addElement(a3); arg.addElement(a4);
    arg.addElement(a5); arg.addElement(a6); arg.addElement(a7); arg.addElement(a8);
    arg.addElement(a9);arg.addElement(a10);arg.addElement(a11);arg.addElement(a12);
    arg.addElement(a13);arg.addElement(a14);
    return this.call(name, arg);
  }

  public NinfExecInfo callWith(String name, Object a1, Object a2, Object a3, Object a4, 
		                    Object a5, Object a6, Object a7, Object a8,
		                    Object a9, Object a10, Object a11, Object a12,
			            Object a13, Object a14, Object a15)
    throws NinfException{
    Vector arg = new Vector();
    arg.addElement(a1); arg.addElement(a2); arg.addElement(a3); arg.addElement(a4);
    arg.addElement(a5); arg.addElement(a6); arg.addElement(a7); arg.addElement(a8);
    arg.addElement(a9);arg.addElement(a10);arg.addElement(a11);arg.addElement(a12);
    arg.addElement(a13);arg.addElement(a14);arg.addElement(a15);
    return this.call(name, arg);
  }

  public NinfExecInfo callWith(String name, Object a1, Object a2, Object a3, Object a4, 
		                    Object a5, Object a6, Object a7, Object a8,
		                    Object a9, Object a10, Object a11, Object a12,
			            Object a13, Object a14, Object a15, Object a16)
    throws NinfException{
    Vector arg = new Vector();
    arg.addElement(a1); arg.addElement(a2); arg.addElement(a3); arg.addElement(a4);
    arg.addElement(a5); arg.addElement(a6); arg.addElement(a7); arg.addElement(a8);
    arg.addElement(a9);arg.addElement(a10);arg.addElement(a11);arg.addElement(a12);
    arg.addElement(a13);arg.addElement(a14);arg.addElement(a15);arg.addElement(a16);
    return this.call(name, arg);
  }

  public NinfExecInfo callWith(String name, Object a1, Object a2, Object a3, Object a4, 
		                    Object a5, Object a6, Object a7, Object a8,
		                    Object a9, Object a10, Object a11, Object a12,
			            Object a13, Object a14, Object a15, Object a16,
			            Object a17)
    throws NinfException{
    Vector arg = new Vector();
    arg.addElement(a1); arg.addElement(a2); arg.addElement(a3); arg.addElement(a4);
    arg.addElement(a5); arg.addElement(a6); arg.addElement(a7); arg.addElement(a8);
    arg.addElement(a9);arg.addElement(a10);arg.addElement(a11);arg.addElement(a12);
    arg.addElement(a13);arg.addElement(a14);arg.addElement(a15);arg.addElement(a16);
    arg.addElement(a17);
    return this.call(name, arg);
  }
  public NinfExecInfo callWith(String name, Object a1, Object a2, Object a3, Object a4, 
		                    Object a5, Object a6, Object a7, Object a8,
		                    Object a9, Object a10, Object a11, Object a12,
			            Object a13, Object a14, Object a15, Object a16,
			            Object a17, Object a18)
    throws NinfException{
    Vector arg = new Vector();
    arg.addElement(a1); arg.addElement(a2); arg.addElement(a3); arg.addElement(a4);
    arg.addElement(a5); arg.addElement(a6); arg.addElement(a7); arg.addElement(a8);
    arg.addElement(a9);arg.addElement(a10);arg.addElement(a11);arg.addElement(a12);
    arg.addElement(a13);arg.addElement(a14);arg.addElement(a15);arg.addElement(a16);
    arg.addElement(a17);arg.addElement(a18);
    return this.call(name, arg);
  }
  public NinfExecInfo callWith(String name, Object a1, Object a2, Object a3, Object a4, 
		                    Object a5, Object a6, Object a7, Object a8,
		                    Object a9, Object a10, Object a11, Object a12,
			            Object a13, Object a14, Object a15, Object a16,
			            Object a17, Object a18, Object a19)
    throws NinfException{
    Vector arg = new Vector();
    arg.addElement(a1); arg.addElement(a2); arg.addElement(a3); arg.addElement(a4);
    arg.addElement(a5); arg.addElement(a6); arg.addElement(a7); arg.addElement(a8);
    arg.addElement(a9);arg.addElement(a10);arg.addElement(a11);arg.addElement(a12);
    arg.addElement(a13);arg.addElement(a14);arg.addElement(a15);arg.addElement(a16);
    arg.addElement(a17);arg.addElement(a18);arg.addElement(a19);
    return this.call(name, arg);
  }

  public NinfExecInfo callWith(String name, Object a1, Object a2, Object a3, Object a4, 
		                    Object a5, Object a6, Object a7, Object a8,
		                    Object a9, Object a10, Object a11, Object a12,
			            Object a13, Object a14, Object a15, Object a16,
			            Object a17, Object a18, Object a19, Object a20)
    throws NinfException{
    Vector arg = new Vector();
    arg.addElement(a1); arg.addElement(a2); arg.addElement(a3); arg.addElement(a4);
    arg.addElement(a5); arg.addElement(a6); arg.addElement(a7); arg.addElement(a8);
    arg.addElement(a9);arg.addElement(a10);arg.addElement(a11);arg.addElement(a12);
    arg.addElement(a13);arg.addElement(a14);arg.addElement(a15);arg.addElement(a16);
    arg.addElement(a17);arg.addElement(a18);arg.addElement(a19);arg.addElement(a20);
    return this.call(name, arg);
  }
  public NinfExecInfo callWith(String name, Object a1, Object a2, Object a3, Object a4, 
		                    Object a5, Object a6, Object a7, Object a8,
		                    Object a9, Object a10, Object a11, Object a12,
			            Object a13, Object a14, Object a15, Object a16,
			            Object a17, Object a18, Object a19, Object a20,
			            Object a21)
    throws NinfException{
    Vector arg = new Vector();
    arg.addElement(a1); arg.addElement(a2); arg.addElement(a3); arg.addElement(a4);
    arg.addElement(a5); arg.addElement(a6); arg.addElement(a7); arg.addElement(a8);
    arg.addElement(a9);arg.addElement(a10);arg.addElement(a11);arg.addElement(a12);
    arg.addElement(a13);arg.addElement(a14);arg.addElement(a15);arg.addElement(a16);
    arg.addElement(a17);arg.addElement(a18);arg.addElement(a19);arg.addElement(a20);
    arg.addElement(a21);
    return this.call(name, arg);
  }
  public NinfExecInfo callWith(String name, Object a1, Object a2, Object a3, Object a4, 
		                    Object a5, Object a6, Object a7, Object a8,
		                    Object a9, Object a10, Object a11, Object a12,
			            Object a13, Object a14, Object a15, Object a16,
			            Object a17, Object a18, Object a19, Object a20,
			            Object a21, Object a22)
    throws NinfException{
    Vector arg = new Vector();
    arg.addElement(a1); arg.addElement(a2); arg.addElement(a3); arg.addElement(a4);
    arg.addElement(a5); arg.addElement(a6); arg.addElement(a7); arg.addElement(a8);
    arg.addElement(a9);arg.addElement(a10);arg.addElement(a11);arg.addElement(a12);
    arg.addElement(a13);arg.addElement(a14);arg.addElement(a15);arg.addElement(a16);
    arg.addElement(a17);arg.addElement(a18);arg.addElement(a19);arg.addElement(a20);
    arg.addElement(a21);arg.addElement(a22);
    return this.call(name, arg);
  }
  public NinfExecInfo callWith(String name, Object a1, Object a2, Object a3, Object a4, 
		                    Object a5, Object a6, Object a7, Object a8,
		                    Object a9, Object a10, Object a11, Object a12,
			            Object a13, Object a14, Object a15, Object a16,
			            Object a17, Object a18, Object a19, Object a20,
			            Object a21, Object a22, Object a23)
    throws NinfException{
    Vector arg = new Vector();
    arg.addElement(a1); arg.addElement(a2); arg.addElement(a3); arg.addElement(a4);
    arg.addElement(a5); arg.addElement(a6); arg.addElement(a7); arg.addElement(a8);
    arg.addElement(a9);arg.addElement(a10);arg.addElement(a11);arg.addElement(a12);
    arg.addElement(a13);arg.addElement(a14);arg.addElement(a15);arg.addElement(a16);
    arg.addElement(a17);arg.addElement(a18);arg.addElement(a19);arg.addElement(a20);
    arg.addElement(a21);arg.addElement(a22);arg.addElement(a23);
    return this.call(name, arg);
  }

  public NinfExecInfo callWith(String name, Object a1, Object a2, Object a3, Object a4, 
		                    Object a5, Object a6, Object a7, Object a8,
		                    Object a9, Object a10, Object a11, Object a12,
			            Object a13, Object a14, Object a15, Object a16,
			            Object a17, Object a18, Object a19, Object a20,
			            Object a21, Object a22, Object a23, Object a24)
    throws NinfException{
    Vector arg = new Vector();
    arg.addElement(a1); arg.addElement(a2); arg.addElement(a3); arg.addElement(a4);
    arg.addElement(a5); arg.addElement(a6); arg.addElement(a7); arg.addElement(a8);
    arg.addElement(a9);arg.addElement(a10);arg.addElement(a11);arg.addElement(a12);
    arg.addElement(a13);arg.addElement(a14);arg.addElement(a15);arg.addElement(a16);
    arg.addElement(a17);arg.addElement(a18);arg.addElement(a19);arg.addElement(a20);
    arg.addElement(a21);arg.addElement(a22);arg.addElement(a23);arg.addElement(a24);
    return this.call(name, arg);
  }
  public NinfExecInfo callWith(String name, Object a1, Object a2, Object a3, Object a4, 
		                    Object a5, Object a6, Object a7, Object a8,
		                    Object a9, Object a10, Object a11, Object a12,
			            Object a13, Object a14, Object a15, Object a16,
			            Object a17, Object a18, Object a19, Object a20,
			            Object a21, Object a22, Object a23, Object a24,
			            Object a25)
    throws NinfException{
    Vector arg = new Vector();
    arg.addElement(a1); arg.addElement(a2); arg.addElement(a3); arg.addElement(a4);
    arg.addElement(a5); arg.addElement(a6); arg.addElement(a7); arg.addElement(a8);
    arg.addElement(a9);arg.addElement(a10);arg.addElement(a11);arg.addElement(a12);
    arg.addElement(a13);arg.addElement(a14);arg.addElement(a15);arg.addElement(a16);
    arg.addElement(a17);arg.addElement(a18);arg.addElement(a19);arg.addElement(a20);
    arg.addElement(a21);arg.addElement(a22);arg.addElement(a23);arg.addElement(a24);
    arg.addElement(a25);
    return this.call(name, arg);
  }
  public NinfExecInfo callWith(String name, Object a1, Object a2, Object a3, Object a4, 
		                    Object a5, Object a6, Object a7, Object a8,
		                    Object a9, Object a10, Object a11, Object a12,
			            Object a13, Object a14, Object a15, Object a16,
			            Object a17, Object a18, Object a19, Object a20,
			            Object a21, Object a22, Object a23, Object a24,
			            Object a25, Object a26)
    throws NinfException{
    Vector arg = new Vector();
    arg.addElement(a1); arg.addElement(a2); arg.addElement(a3); arg.addElement(a4);
    arg.addElement(a5); arg.addElement(a6); arg.addElement(a7); arg.addElement(a8);
    arg.addElement(a9);arg.addElement(a10);arg.addElement(a11);arg.addElement(a12);
    arg.addElement(a13);arg.addElement(a14);arg.addElement(a15);arg.addElement(a16);
    arg.addElement(a17);arg.addElement(a18);arg.addElement(a19);arg.addElement(a20);
    arg.addElement(a21);arg.addElement(a22);arg.addElement(a23);arg.addElement(a24);
    arg.addElement(a25);arg.addElement(a26);
    return this.call(name, arg);
  }
  public NinfExecInfo callWith(String name, Object a1, Object a2, Object a3, Object a4, 
		                    Object a5, Object a6, Object a7, Object a8,
		                    Object a9, Object a10, Object a11, Object a12,
			            Object a13, Object a14, Object a15, Object a16,
			            Object a17, Object a18, Object a19, Object a20,
			            Object a21, Object a22, Object a23, Object a24,
			            Object a25, Object a26, Object a27)
    throws NinfException{
    Vector arg = new Vector();
    arg.addElement(a1); arg.addElement(a2); arg.addElement(a3); arg.addElement(a4);
    arg.addElement(a5); arg.addElement(a6); arg.addElement(a7); arg.addElement(a8);
    arg.addElement(a9);arg.addElement(a10);arg.addElement(a11);arg.addElement(a12);
    arg.addElement(a13);arg.addElement(a14);arg.addElement(a15);arg.addElement(a16);
    arg.addElement(a17);arg.addElement(a18);arg.addElement(a19);arg.addElement(a20);
    arg.addElement(a21);arg.addElement(a22);arg.addElement(a23);arg.addElement(a24);
    arg.addElement(a25);arg.addElement(a26);arg.addElement(a27);
    return this.call(name, arg);
  }
  public NinfExecInfo callWith(String name, Object a1, Object a2, Object a3, Object a4, 
		                    Object a5, Object a6, Object a7, Object a8,
		                    Object a9, Object a10, Object a11, Object a12,
			            Object a13, Object a14, Object a15, Object a16,
			            Object a17, Object a18, Object a19, Object a20,
			            Object a21, Object a22, Object a23, Object a24,
			            Object a25, Object a26, Object a27, Object a28)
    throws NinfException{
    Vector arg = new Vector();
    arg.addElement(a1); arg.addElement(a2); arg.addElement(a3); arg.addElement(a4);
    arg.addElement(a5); arg.addElement(a6); arg.addElement(a7); arg.addElement(a8);
    arg.addElement(a9);arg.addElement(a10);arg.addElement(a11);arg.addElement(a12);
    arg.addElement(a13);arg.addElement(a14);arg.addElement(a15);arg.addElement(a16);
    arg.addElement(a17);arg.addElement(a18);arg.addElement(a19);arg.addElement(a20);
    arg.addElement(a21);arg.addElement(a22);arg.addElement(a23);arg.addElement(a24);
    arg.addElement(a25);arg.addElement(a26);arg.addElement(a27);arg.addElement(a28);
    return this.call(name, arg);
  }


// For ninf calc
//$B!T(BgetStubWithRdim()$B!U(B
// $B!V9TNs%5%$%:$r<($90z?t(B $B"+"*(B $B9TNs!W4V$NAPJ}8~$N8!:w2DG=$J(B 
//  $B%k!<%A%s$N%$%s%?!<%U%'!<%9>pJs$rF@$k(B

  public NinfStub getStubWithRdim(String func) throws NinfException{
    connectServer();
    NinfStub tmp = con.getStub(func);
    if(tmp == null) return null;
    tmp.inputRRetrieval();
    return tmp;
  }


}
