package org.gridforum.gridrpc;

public class GrpcException extends Exception{
  public String str;
  public Exception innerException;
  public GrpcException(){
    super();
  }
  public GrpcException(String str){
    super();
    this.str = str;
  }
  public GrpcException(Exception e){
    innerException = e;
  }
  public void printStackTrace(){
    if (innerException != null)
	innerException.printStackTrace();
    if (str != null)
      System.out.println(str);
    super.printStackTrace();
  }
  public String toString(){
    if (innerException != null)
      return "GrpcException: originalException is " +
	innerException.toString();
    if (str != null)
      return "GrpcException:" + str;
    return super.toString();
  }
}
