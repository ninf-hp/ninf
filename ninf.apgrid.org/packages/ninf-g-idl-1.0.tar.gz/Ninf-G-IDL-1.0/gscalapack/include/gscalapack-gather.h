#ifndef _GSCAPACK_GATHER_H_
#define _GSCAPACK_GATHER_H_

#ifdef _LOCAL_
extern void _gather( const char *type, int m, int n, 
			 void *a, int ia,  int ja,  int *desc_a, 
			 void *b, int ib,  int jb,  int *desc_b );
extern void _tdgather( const char*, const char*, const char*, int, void*, void*, void*, int, int, int*, void*, void*, void*, int, int, int*);
extern void _band_gather( const char*, int, int, int, void*, int*, void*, int*, int);
extern void _vgather( char *rowcol, const char* type, int size, void *v, void *locv);

#endif

#define GATHER(type, a, m, n)      \
                     _gather( type, \
                                   m, n, \
                                   loc##a,\
                                   1, 1, \
                                 desc##a, \
                               global_##a,\
                                   1, 1, \
                               desc_g##a \
)

#define DIAG "N"
#define trGATHER( uplo, type, a, m, n)      \
                     _tridistribute( &uplo, \
				     DIAG, \
				     type, \
                                   m, n, \
                                   loc##a,\
                                   1, 1, \
                                 desc##a, \
                               global_##a,\
                                   1, 1, \
                               desc_g##a \
)

#ifdef _DISTRIBUTE_1D_
#if defined(_REAL_DIAGONAL_) && defined(SCOMPLEX)
#define DIAG_TYPE "float"
#endif
#if defined(_REAL_DIAGONAL_) && defined(DCOMPLEX)
#define DIAG_TYPE "double"
#endif

#if defined(_REAL_DIAGONAL_)
#define tdGATHER( type, dl, d, du, n) \
           _tdgather( type,\
                 DIAG_TYPE,\
                      type,\
                         n,\
                global_##dl,\
                 global_##d,\
                global_##du,\
                        1,1,\
                desc_gtd##d,\
                    loc##dl,\
                     loc##d, \
                    loc##du, \
                        1,1, \
                  desctd##d \
)
#else
#define tdGATHER( type, dl, d, du, n) \
           _tdgather( type,\
                      type,\
                      type,\
                         n,\
                global_##dl,\
                 global_##d,\
                global_##du,\
                        1,1,\
                desc_gtd##d,\
                    loc##dl,\
                     loc##d, \
                    loc##du, \
                        1,1, \
                  desctd##d \
)
#endif
#endif

#ifdef _DISTRIBUTE_1D_

#define bandGATHER( type, a, bwl, bwu, n) \
           _band_gather( type, \
                         n, \
                        bwl, \
                        bwu, \
                 global_##a, \
                  desc_g##a, \
                     loc##a, \
                  desc##a, \
                  PIVOTING \
)
#endif


#define vGATHER( rowcol, type, v, size) _vgather( rowcol, type, size, global_##v, loc##v)

#endif
