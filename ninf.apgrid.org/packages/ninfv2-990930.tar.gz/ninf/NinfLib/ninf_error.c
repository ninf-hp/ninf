#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <time.h>
#include "ninf_error.h"
/*
#define initFp() if (logfp == NULL) logfp = fopen("/tmp/saru", "a");
*/
#define initFp() if (logfp == NULL) logfp = stderr;

extern FILE * logfp;

/*****  ERROR_ROUTINE  *****/

void (*finalizer)() = NULL;


void ninf_log_header()
{
  time_t clock;
  char * pc;

  initFp();
  clock = time(NULL);
  pc = ctime(&clock);
  *(pc+24) = '\0';
  fprintf(logfp, "%s ", pc);
}

void ninf_log(char * fmt, ...)
{
  va_list args;
  time_t clock;
  char * pc;

  va_start(args, fmt);
  initFp();
  clock = time(NULL);
  pc = ctime(&clock);
  *(pc+24) = '\0';
  fprintf(logfp, "%s ", pc);
  vfprintf(logfp, fmt, args);
  va_end(args);
  fprintf(logfp, "\n");
  fflush(logfp);
}

void ninf_error(char * fmt, ...)
{
  va_list args;
  
  va_start(args, fmt);
  initFp();
  fprintf(logfp,"Ninf Error in %s:", program_context);
  vfprintf(logfp, fmt, args);
  va_end(args);
  fprintf(logfp, "\n" );
  fflush(logfp);
}

void ninf_debug(char * fmt, ...)
{
  va_list args;
  va_start(args, fmt);
  initFp();
  if (ninf_debug_flag){
    fprintf(logfp,"[%s]:", program_context);
    vfprintf(logfp, fmt, args);
    fprintf(logfp, "\n" );
    fflush(logfp);
  }
  va_end(args);
}

void ninf_fatal(char * fmt, ...)
{
  va_list args;
  va_start(args, fmt);
  initFp();
  fprintf(logfp,"Ninf Fatal Error in %s:", program_context);
  vfprintf(logfp, fmt, args);
  va_end(args);
  fprintf(logfp, "\n" );
  fflush(logfp);
  if (finalizer != NULL)
    (*finalizer)();
  exit(3);
}

void Ninf_set_log_fp(FILE *fp){
  logfp = fp;
}

void Ninf_set_log_file(char * filename){
  FILE * fp;
  if (filename != NULL){
    /*      fprintf(stderr, "logfile = %s\n", filename); */
    if ((fp = fopen(filename, "a")) != NULL)
      Ninf_set_log_fp(fp);
    else
      fprintf(stderr, "Can't open logfile %s\n", filename);
  }
}
