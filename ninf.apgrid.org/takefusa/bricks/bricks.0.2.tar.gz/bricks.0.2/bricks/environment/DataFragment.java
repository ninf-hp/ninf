package bricks.environment;
import bricks.util.BricksNoDiskSpaceException;
import java.io.*;
import java.util.*;

/** 
 * DataFragment.java
 * <pre>
 * DataFragment represents a data fragment stored to disk systems.
 * </pre>
 */
public class DataFragment {

    public String id;
    public double size;
    public double generatedTime = 0.0;
    public double storedTime = 0.0;
    public double lastAccessedTime = 0.0;
    public int numAccesses = 0;

    public DataFragment(String id, double size) {
	this.id = id;
	this.size = size;
    }

    public String toString() {
	return "DataFragment-" + id + "(" + size + ")";
    }

    public boolean equals(Object object) {
	if (object instanceof DataFragment) {
	    DataFragment d = (DataFragment)object;
	    if (this.id == d.id)
		return true;
	}
	return false;
    }

    public void accessedAt(double currentTime) {
	lastAccessedTime = currentTime;
	numAccesses++;
    }

    public void stored(double currentTime, Disk disk)
	throws BricksNoDiskSpaceException {
	try {
	    this.storedTime = currentTime;
	    this.lastAccessedTime = currentTime;
	    disk.store(currentTime, this);

	} catch (BricksNoDiskSpaceException e) {
	    throw e;
	}
    }

    // for the HeapSort main function
    public void stored(double currentTime) {
	this.storedTime = currentTime;
	this.lastAccessedTime = currentTime;
    }
}
