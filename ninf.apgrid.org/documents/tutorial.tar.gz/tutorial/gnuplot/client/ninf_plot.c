#include <stdio.h>
#include "ninf.h"

int main(int argc, char ** argv){
  argc = Ninf_parse_arg(argc, argv);

  if (argc < 3) {
	fprintf(stderr, "USAGE: plot_main INPUT PSFILE\n");
	exit(2);
  }
  if (Ninf_call("plot/plot", argv[1], argv[2]) == NINF_ERROR)
	Ninf_perror("Ninf_call plot:");
  exit(0);
}
