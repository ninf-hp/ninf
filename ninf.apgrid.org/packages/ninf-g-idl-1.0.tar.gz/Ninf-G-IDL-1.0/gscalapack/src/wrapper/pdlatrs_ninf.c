#define _WRAPPER_
/* $Id: pdlatrs_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define DOUBLE
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n
static	int worklen() {
	  int ret=1;
	  ret =10;
	  return ret;
}

void  pdlatrs_ninf(	 char  uplo,
		 char  trans,
		 char  diag,
		 char normin,
		 int  n,
		 double global_a[],
		 int lda,
		 double global_x[],
		 double *scale,
		 double  cnorm[],
		 int *info
)
/* "pdlatrs solves a triangular system. This routine in unfinished at this time, but will be part of the next release." */
/* OPTIONS */
{
extern void  FortranCall(pdlatrs)( char*, char*, char*, char*, int*,
				   double*, int*, int*, int*,
				   double*, int*, int*, int*,
				   double*, double*,
				   double*);
	int maxldd;

	int maxlda;
	double *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
	int row_loca, col_loca;

	double *locx=NULL;
	int descx[DESCLEN];
	
	double *locwork=NULL;
	int llocwork;

	double locscale[1];


	INITIALIZE();

	SCALAR("char", uplo);
	SCALAR("char", trans);
	SCALAR("char", diag);
	SCALAR("char", normin);
	SCALAR("int", n);
	SCALAR("int",lda);

	COMMON("double",cnorm,n );

	ROW(a);
	COL(a);
	MAXLDD( maxldd, a );
	maxlda= maxldd;

	VECTOR("c", "double", x, n);
	vDISTRIBUTE("c", "double", x, n);
	Cdescinit( descx, 1, n, 1, cbloc, 0, 0,PARA_CTXT, 1, &linfo );

	trMATRIX( uplo, "double", a, ROW_a, COL_a);
	trDISTRIBUTE( uplo, "double", a, ROW_a, COL_a);

	llocwork=worklen();
	WORK(locwork,llocwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	  FortranCall(pdlatrs)( &uplo, &trans, &diag,
				&normin, &n,
				loca, &one, &one, desca,
				locx, &one, &one, descx,
				locscale, cnorm,
                                locwork);

	vGATHER( "c", "double", x, n);
	RETRIEVE("int", &linfo, 1);
	RETRIEVE("double", cnorm, n);
	RETRIEVE("double", locscale, 1);

	if( mypnum == 0 ){
	  *info = linfo;
	  *scale=*locscale;
	} else {

	}
        FREE_COMMON(cnorm);
	FREE_MATRIX(a);
	FREE_VECTOR(x);
        FREE(locwork);
}

