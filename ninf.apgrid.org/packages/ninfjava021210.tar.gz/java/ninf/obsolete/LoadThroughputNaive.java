package ninf.metaserver;

class LoadThroughputNaive extends LoadThroughputScheduler{
  void updateLoad(ServerInformation tmp){
    // nothing to do.
  }
}
