package bricks.scheduling;

public interface SchedulingUnit {
    public String getName();
}
