/*
 *  $Id: ninf_stream.c,v 1.9 1999/08/17 22:00:28 nakada Exp $
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/wait.h>
#include <unistd.h>

#include "ninf_error.h"
#include "ninf_data_trans.h"
#include "ninf_macros.h"
#include "ninf_serv_reg.h"
#include "ninf_stream.h"
#include "ninf_server_state.h"
#include "ninf_protocol.h"
#include "ninf_pipe.h"

#define UNIX_SOCK_NAME_FMT 	"/tmp/ninf.%d"
static char local_filename[100];
extern int ninf_debug_flag;
extern char * save_str(char *);

FILE *fdopen(int fildes, const char *type);

static void setup_argv_sub(char * str, char ** argv){
  char ** argp = argv;
  char * tmp = strtok(str, " \t");
  while (tmp != NULL){
    *(argp++) = save_str(tmp);
    tmp = strtok(NULL, " \t");
  }
  *argp = NULL;
}

static void setup_argv(char **program, char ** argv, char * stubname, char * desc){
  static char buffer[1000];
  sprintf(buffer, "%s %s", stubname, desc);
  setup_argv_sub(buffer, argv);
  *program = argv[0];
}

/* returns stub_pid */

int ninf_local_forkexec_outerr(char * stubname, int checkPid, server_state * state){
  long pid;
  ninf_pipe * pipe, * pipeout, * pipeerr;
  char * argv[30];
  char * program;
  char argbuf[1000];
  
#ifdef USE_PIPE
  pipe    = new_ninf_pipe(NINF_PIPE_SOCKETPAIR);
  pipeout = new_ninf_pipe(NINF_PIPE_SOCKETPAIR);
  pipeerr = new_ninf_pipe(NINF_PIPE_SOCKETPAIR);
#else
  pipe    = new_ninf_pipe(NINF_PIPE_UNIXDOMAIN);
  pipeout = new_ninf_pipe(NINF_PIPE_UNIXDOMAIN);
  pipeerr = new_ninf_pipe(NINF_PIPE_UNIXDOMAIN);
#endif

  if((state->stub_pid = fork()) == 0){
    if (ninf_debug_flag) fprintf(stderr, "child forked\n");
    ninf_pipe_child_clean(pipe);
    ninf_pipe_child_clean(pipeout);
    ninf_pipe_child_clean(pipeerr);    
    
    argbuf[0] = '\0';
    strcat(argbuf, ninf_pipe_description(pipe));
    strcat(argbuf, " ");
    strcat(argbuf, ninf_pipe_description(pipeout));
    strcat(argbuf, " ");
    strcat(argbuf, ninf_pipe_description(pipeerr));
    
    setup_argv(&program, argv, stubname, argbuf);
    if (ninf_debug_flag){
      int i = 0;
      fprintf(stderr, "execute: %s ", program);
      while (argv[i] != NULL)
	fprintf(stderr, "%s ", argv[i++]);
      fprintf(stderr, "\n");
    }
    if (execvp(program, argv) < 0){
      perror("ninf execvp failed:");
      ninf_log("server[%d]: failed to execstub %s", getppid(), program);
      exit(3);
    }
    /* NEVER READHED HERE */
  } 
  if (!ninf_pipe_parent_clean(pipe))   return -1;
  if (!ninf_pipe_parent_clean(pipeout))return -1;
  if (!ninf_pipe_parent_clean(pipeerr))return -1;

  if(state->stub_pid < 0){
    /*  fork error */
    ninf_error("can't execute stub");
    return -1;
  }

#ifdef SSL_USE  
  state->stub     = new_connection(ninf_pipe_get_fd(pipe),    FALSE, FALSE, NULL);
  state->stub_out = new_connection(ninf_pipe_get_fd(pipeout), FALSE, FALSE, NULL);
  state->stub_err = new_connection(ninf_pipe_get_fd(pipeerr), FALSE, FALSE, NULL);
#else
  state->stub     = new_connection(ninf_pipe_get_fd(pipe),    FALSE, FALSE);
  state->stub_out = new_connection(ninf_pipe_get_fd(pipeout), FALSE, FALSE);
  state->stub_err = new_connection(ninf_pipe_get_fd(pipeerr), FALSE, FALSE);
#endif

  if(!trans_long(state->stub->rDT, &pid)){
    ninf_error("first packet read failed");
    return -1;
  }
  /* make sure of the connection */
  if((checkPid) && state->stub_pid != pid){
    ninf_error("bad first packet, %d != %d",state->stub_pid,pid);
    return -1;
  }
  return state->stub_pid;
}

int ninf_local_forkexec(char * stubname, int checkPid, connection ** pcon){
  int stub_pid;
  long pid;
  int fd[2];
  char * argv[30];
  char * program;
  ninf_pipe * pipe;

#ifdef USE_PIPE
  pipe = new_ninf_pipe(NINF_PIPE_SOCKETPAIR);
#else
  pipe = new_ninf_pipe(NINF_PIPE_UNIXDOMAIN);
#endif

  if((stub_pid = fork()) == 0){
    if (ninf_debug_flag) fprintf(stderr, "child forked\n");
    ninf_pipe_child_clean(pipe);
    
    setup_argv(&program, argv, stubname, ninf_pipe_description(pipe));
    if (ninf_debug_flag){
      int i = 0;
      fprintf(stderr, "execute: %s ", program);
      while (argv[i] != NULL)
	fprintf(stderr, "%s ", argv[i++]);
      fprintf(stderr, "\n");
    }
    if (execvp(program, argv)<0){
      perror("ninf execvp failed:");
      exit(3);
    }
    /* NEVER READHED HERE */
  } 
  if (!ninf_pipe_parent_clean(pipe))
    return -1;
  
  if(stub_pid < 0){
    /*  fork error */
    ninf_error("can't execute stub");
    return -1;
  }

#ifdef SSL_USE  
  *pcon = new_connection(ninf_pipe_get_fd(pipe),    FALSE, FALSE, NULL);
#else
  *pcon = new_connection(ninf_pipe_get_fd(pipe),    FALSE, FALSE);
#endif
  if(!trans_long((*pcon)->rDT,&pid)){
    ninf_error("first packet read failed");
    return -1;
  }
  /* make sure of the connection */
  if((checkPid) && stub_pid != pid){
    ninf_error("bad first packet, %d != %d",stub_pid,pid);
    return -1;
  }
  return stub_pid;
}

int ninf_local_forkexec_state(char * stubname, int checkPid, server_state * state){
  state->stub_pid = 
    ninf_local_forkexec(stubname, checkPid, &(state->stub));
  return state->stub_pid;
}

int wait_for_killed(int stub_pid){
    int status,pid;

    /* wait for kill */
 again:
    if((pid = waitpid(stub_pid, &status, 0)) < 0) return(-1);
    if(WIFSTOPPED(status)) goto again;

    if(pid != stub_pid) {
      ninf_error("bad wait pid : waiting %d, returned %d", stub_pid, pid);
      return -1;
    }    
    if(WIFSIGNALED(status)) return(-1);
    else return(WEXITSTATUS(status));
}

int  ninf_local_kill_state(server_state *state){
  return ninf_local_kill(state->stub, state->stub_pid);
}

int  ninf_local_kill(connection * con, int stub_pid){
    /* send kill request */
    if (ninf_debug_flag) 
      fprintf(stderr, "killing stub(id: %d)", stub_pid);
    trans_request(con->sDT, NINF_REQ_KILL);
    write_flush(con->sDT);

    return wait_for_killed(stub_pid);
}

