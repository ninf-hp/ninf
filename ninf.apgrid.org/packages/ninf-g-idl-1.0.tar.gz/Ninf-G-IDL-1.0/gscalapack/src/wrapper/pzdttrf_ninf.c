#define _WRAPPER_
/* $Id: pzdttrf_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define DCOMPLEX
#define _DISTRIBUTE_1D_
#include <gscalapack.h>

#define ROW_af laf
#define COL_af n
#define ROW_af laf
#define COL_af n
static	int worklen() {
	  int ret=1;
	  ret = 8;
	  if NEED_BUFF
		  ret = 8*npcol;
	  return ret;
}


void  pzdttrf_ninf(	 int n,
		 dcomplex global_dl[],
		 dcomplex global_d[],
		 dcomplex global_du[],
		 dcomplex af[],
		 int dummy_laf,
		 dcomplex work[],
		 int lwork,
		 int *info
)
/* "pzdttrf computes a LU factorization of an N-by-N complex tridiagonal diagonally dominant-like distributed matrix A." */
/* OPTIONS */
{
    extern void FortranCall(pzdttrf)( int*,
                               dcomplex*, dcomplex*, dcomplex*, int*, int*,
                               dcomplex*, int*,
                               dcomplex*, int*, int*);

	int maxldd;

	dcomplex *locdl=NULL, *locd=NULL, *locdu=NULL;
	int desctdd[DESCLEN];
	int desc_gtdd[DESCLEN];

	int maxldaf;
	int laf,llocaf;
	dcomplex *locaf=NULL,*global_af=NULL;
	int descaf[DESCLEN];
	int desc_gaf[DESCLEN];
	int row_locaf, col_locaf;
	
	dcomplex *locwork=NULL;
	int llocwork;

	INITIALIZE();

	SCALAR( "int", n);
	SCALAR("int", dummy_laf);
	SCALAR( "int", lwork);

	SIZE(n);

	laf = 2*(blocsize+2)*nprocs/n;
	llocaf = laf*blocsize;
	if (mypnum==0) {
	  global_af=MALLOC(sizeof(double)*laf*n);
          assert(global_af);
	}

	ROW(af);
	COL(af);
	MAXLDD(maxldd, af);
	maxldaf=maxldd;

	tdMATRIX( "dcomplex", dl, d, du, n);
	tdDISTRIBUTE("dcomplex", dl, d, du, n);
	MATRIX("dcomplex", af, ROW_af, COL_af);

	llocwork = worklen();
	llocwork = max(lwork,llocwork);
	WORK(locwork,llocwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pzdttrf)( &n,
                               locdl, locd, locdu, &one, desctdd,
                               locaf, &llocaf,
                               locwork, &llocwork, &linfo);

	tdGATHER( "dcomplex", dl, d, du, n);
	GATHER( "dcomplex", af, ROW_af, COL_af);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
	  int i;
	  *info = linfo;
	  for(i=0;i<min(dummy_laf,laf*n);i++) af[i]=global_af[i];
          FREE(global_af);
	} else {
	}

        FREE_MATRIX(dl);
        FREE_MATRIX(d);
        FREE_MATRIX(du);
        FREE_MATRIX(af);

        FREE(locwork);
}

