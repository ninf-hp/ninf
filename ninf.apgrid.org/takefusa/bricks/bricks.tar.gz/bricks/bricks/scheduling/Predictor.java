package bricks.scheduling;

public interface Predictor {
    ;
}
