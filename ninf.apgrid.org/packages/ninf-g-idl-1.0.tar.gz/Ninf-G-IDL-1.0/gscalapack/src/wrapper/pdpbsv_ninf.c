#define _WRAPPER_
/* $Id: pdpbsv_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define _DISTRIBUTE_1D_
#define DOUBLE
#define NO_PIVOT
#include <gscalapack.h>
#define ROW_a lda
#define COL_a n
#define ROW_b ldb
#define COL_b nrhs
static    int worklen(int n, int nrhs, int bw) {
        int ret=1;
        ret = (n+2*bw)*bw+max(bw*nrhs, bw*bw);
        if NEED_BUFF ret = (blocsize+2*bw)*bw+max((bw*nrhs), bw*bw);
        return ret;
}


void  pdpbsv_ninf(	 char uplo,
		 int n,
		 int bw,
		 int nrhs,
		 double global_a[],
		 int lda,
		 double global_b[],
		 int ldb,
		 int *info
)
/* "pdpbsv solves a system of linear equations A * X = B where A is an N-by-N real banded symmetric positive definite distributed matrix with bandwidth BW." */
/* OPTIONS */
{
    extern void FortranCall(pdpbsv)( char*, int*, int*, int*,
                              double*, int*, int*,
                              double*, int*, int*,
                              double*, int*, int*);
    int maxldd;

    int maxlda;
    double *loca=NULL;
    int desca[DESCLEN];
    int desc_ga[DESCLEN];

    int maxldb;
    double *locb=NULL;
    int descb[DESCLEN];
    int desc_gb[DESCLEN];

    double *locwork=NULL;
    int llocwork;

    int row_locb;
    int col_locb;

    INITIALIZE();

	SCALAR( "char", uplo);
	SCALAR( "int", n);
	SCALAR( "int", bw);
	SCALAR( "int", nrhs);
	SCALAR("int",lda);
	SCALAR("int",ldb);

	SIZE(n);

        ROW(b);
        COL(b);
	MAXLDD( maxldd, b );
	maxldb=maxldd;

        MATRIX( "double", b, ROW_b, COL_b);
        DISTRIBUTE( "double", b, ROW_b, COL_b);

        if (chrcmp(uplo,'U')==0) {
            bandMATRIX( "double", a,  0, bw, n);
            bandDISTRIBUTE( "double", a,  0, bw, n);
        } else {
            bandMATRIX( "double", a, bw, 0, n);
            bandDISTRIBUTE( "double", a, bw, 0, n);
        }
        
        llocwork=worklen(n, nrhs, bw);
        WORK(locwork,llocwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pdpbsv)( &uplo, &n, &bw, &nrhs,
                              loca, &one, desca,
                              locb, &one, descb,
                              locwork, &llocwork, &linfo);

        if (chrcmp(uplo,'U')==0) {
            bandGATHER( "double", a,  0, bw, n);
        } else {
            bandGATHER( "double", a, bw, 0, n);
        }
        GATHER("double", b, ROW_b, COL_b);
        
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
		*info = linfo;
	} else {
		
	}
	FREE_MATRIX(a);
	FREE_MATRIX(b);
        FREE(locwork);
}

