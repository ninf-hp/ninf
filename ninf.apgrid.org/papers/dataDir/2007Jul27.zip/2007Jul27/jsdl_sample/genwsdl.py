#
# vi:set ts=3 sw=3:
# vim:set sts=0 noet:
import sys
import xml.dom.minidom

def main():
	f = file(sys.argv[1] + '/' + sys.argv[3], 'w')
	f.write('''<?xml version="1.0" encoding="UTF-8"?>
<wsdl:definitions targetNamespace="http://dummy.example.org/dummy" xmlns="http://dummy.example.org/dummy" xmlns:wsdl="http://schemas.xmlsoap.org/wsdl/">
 <wsdl:types>
  <xsd:schema xmlns:xsd="http://www.w3.org/2001/XMLSchema" targetNamespace="http://dummy.example.org/dummy">
''')
	for xsdfilename in sys.argv[2].split(','):
		doc = xml.dom.minidom.parse(sys.argv[1] + '/' + xsdfilename)
		tns = doc.documentElement.getAttribute('targetNamespace')
		f.write('   <xsd:import namespace="%s" schemaLocation="%s"/>\n' % (tns, xsdfilename))

	f.write('''  </xsd:schema>
 </wsdl:types>
</wsdl:definitions>
''')
	f.close()

main()
