#define _WRAPPER_
/* $Id: pspbtrf_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define _DISTRIBUTE_1D_
#define FLOAT
#define NO_PIVOT
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n
static	int worklen(int bw) {
	  int ret=1;
	  ret = bw*bw;
	  return ret;
}

void  pspbtrf_ninf(	 char uplo,
		 int n,
		 int bw,
		 float global_a[],
		 int lda,
		 int *info
)
/* "pspbtrf computes a Cholesky factorization of an N-by-N real banded symmetric positive definite distributed matrix with bandwidth BW: A." */
/* OPTIONS */
{
    extern void FortranCall(pspbtrf)( char*, int*, int*,
                               float*, int*, int*,
                               float*, int*,
                               float*, int*,
                               int*);

	int maxldd;

	int maxlda;
	float *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];

	float *locaf=NULL;
	int laf;

	float *locwork=NULL;
	int llocwork;


	INITIALIZE();

	SCALAR( "char", uplo);
	SCALAR( "int", n);
	SCALAR( "int", bw);
	SCALAR("int", lda);
	SIZE(n);

	if (chrcmp(uplo,'u')==0) {
	  bandMATRIX( "float", a, 0, bw, n);
	  bandDISTRIBUTE( "float", a, 0, bw, n);
	}else {
	  bandMATRIX( "float", a, bw, 0, n);
	  bandDISTRIBUTE( "float", a, bw, 0, n);
	}

	laf=(blocsize+2*bw)*bw;
	locaf=MALLOC(sizeof(float)*laf);
        assert(locaf);
        
	llocwork = worklen(bw);
	WORK(locwork, llocwork);
	
	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pspbtrf)( &uplo, &n, &bw,
                               loca, &one, desca,
                               locaf, &laf,
                               locwork, &llocwork,
                               &linfo);

	if (chrcmp(uplo,'u')==0) {
	  bandGATHER( "float", a, 0, bw, n);
	}else {
	  bandGATHER( "float", a, bw, 0, n);
	}

	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
	  *info = linfo;
	} else {
		
	}
	FREE_MATRIX(a);
        FREE(locaf);
        FREE(locwork);
	
}

