#define _WRAPPER_
/* $Id: pcgbsv_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define _DISTRIBUTE_1D_
#define SCOMPLEX
#define PIVOT
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n
#define ROW_b ldb
#define COL_b nrhs
static  int worklen(int n, int nrhs, int bwl, int bwu) {
    int ret=1;
    ret = (n+bwu)*(bwl+bwu)+6*(bwl+bwu)*(bwl+2*bwu)+max(nrhs*(n+2*bwl+4*bwu), 1);
    if NEED_BUFF {
    ret = (blocsize+bwu)*(bwl+bwu)+6*(bwl+bwu)*(bwl+2*bwu)+max(nrhs*(blocsize+2*bwl+4*bwu), 1);
    }
    return ret;
  }

void  pcgbsv_ninf(	 int n,
		 int bwl,
		 int bwu,
		 int nrhs,
		 scomplex global_a[],
		 int lda,
		 int global_ipiv[],
		 scomplex global_b[],
		 int ldb,
		 int *info
)
/* "pcgbsv solves a system of linear equations A * X = B where A is an N-by-N complex banded distributed matrix with bandwidth BWL, BWU." */
/* OPTIONS */
{
    extern void FortranCall(pcgbsv)( int*, int*, int*, int*,
				     scomplex*, int*, int*,
				     int*,
				     scomplex*, int*, int*,
				     scomplex*, int*,
				     int*);

  int maxldd;

  scomplex *loca = NULL;
  int desca[DESCLEN];
  int desc_ga[DESCLEN];
  
  int *locipiv = NULL;

  scomplex *locb=NULL;
  int maxldb;
  int descb[DESCLEN];
  int desc_gb[DESCLEN];

  scomplex *locwork = NULL;
  int lwork;

  int row_locb;
  int col_locb;
        
  INITIALIZE();

	SCALAR( "int", n);
	SCALAR( "int", bwl);
	SCALAR( "int", bwu);
	SCALAR( "int", nrhs);
	SCALAR("int",lda);
	SCALAR("int",ldb);

	SIZE(n);

        ROW(b);
        COL(b);
        
	MAXLDD( maxldd, b );
        maxldb = maxldd;
        
        bandMATRIX( "scomplex", a, bwl, bwu, n);
        MATRIX( "scomplex", b, ROW_b, COL_b);

        bandDISTRIBUTE("scomplex",a, bwl, bwu, n);
        DISTRIBUTE("scomplex",b, ROW_b, COL_b);

	VECTOR("c", "int", ipiv, n);

	lwork=worklen(n, nrhs, bwl, bwu);
        WORK( locwork, lwork);

	//	if ((serial==0) && (mypnum!=0)) /* pcgbsv don't work in serial */
	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pcgbsv)( &n, &bwl, &bwu, &nrhs,
                              loca, &one, desca,
                              locipiv,
                              locb, &one, descb,
                              locwork, &lwork, &linfo);

        bandGATHER("scomplex",a, bwl, bwu, n);
        GATHER("scomplex",b, ROW_b, COL_b);
	vGATHER( "c", "int", ipiv, n);

	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
	  *info = linfo;
	} else {
	}
        
        FREE_MATRIX(a);
        FREE_MATRIX(b);
	FREE_VECTOR(ipiv);
        FREE(locwork);

}

