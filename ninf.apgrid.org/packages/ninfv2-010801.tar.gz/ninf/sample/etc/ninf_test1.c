#include <stdio.h>
#include <math.h>

#define N 30

double A[N][N],B[N][N],C[N][N],C0[N][N];

main(int argc, char ** argv)
{
    int i,j,r;
    double a;
    double x,x0;

    argc = Ninf_parse_arg(argc, argv);

    for(i = 0; i < N; i++)
      for(j = 0; j < N; j++)
	{
	    A[i][j] = rand();
	    B[i][j] = rand();
	}

    for (i = 0; i < 1000; i++){
      r = Ninf_call("sample/mmul",N,A,B,C);
      printf("Ninf_call:mmul r = %d\n",r);
    }
    mmul(N,A,B,C0);

    for(i = 0; i < N; i++)
      for(j = 0; j < N; j++)
	if(C[i][j] != C0[i][j])
	  {
	      printf("C[%d][%d]= %e != %e\n",
		     i,j,C[i][j],C0[i][j]);
	      exit(1);
	  }

    exit(0);
}

/* test routine */
mmul(n,A,B,C)
     double *A,*B,*C;
{
    double t;
    int i,j,k;
    
    printf("n0=%d\n",n);
    printf("A0(10,5)=%e\n",A[10*n+5]);
    printf("B0(10,5)=%e\n",B[10*n+5]);
    for (i=0;i<n;i++) {
	for (j=0;j<n;j++) {
	    t = 0;
	    for (k=0;k<N;k++){
		t += A[i*n + k] * B[k*n+j];	/* inner product */
	    }
	    C[i*n+j] = t;
	}
    }
    printf("C0(10,5)=%e\n",C[10*n+5]);
}
