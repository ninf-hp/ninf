package ninf.cproxy.aggregate;

import ninf.basic.*;
import ninf.client.*;
import java.util.Vector;

class MergedInfo {
  Vector inputArgs;
  Vector outputArgs;

  MergedInfo(){
    inputArgs = new Vector();
    outputArgs = new Vector();
  }

  void addInputArg(ArgPosition arg){
    inputArgs.addElement(arg);
  }

  void addOutputArg(ArgPosition arg){
    outputArgs.addElement(arg);
  }

  ArgPosition getInputArg(int i ){
    return (ArgPosition)(inputArgs.elementAt(i));
  }
  ArgPosition getOutputArg(int i){
    return (ArgPosition)(outputArgs.elementAt(i));
  }

  void add(DependInfo info, boolean output, ArgPosition arg){
    if (output)
      addOutputArg(arg);
    else
      addInputArg(arg);

    System.out.println(this);
  }

  public String toString(){
    String tmp = "merged : in ";
    for (int i = 0; i < inputArgs.size(); i++)
      tmp += inputArgs.elementAt(i).toString() +" ";
    tmp += "out ";
    for (int i = 0; i < outputArgs.size(); i++)
      tmp += outputArgs.elementAt(i).toString();
    return tmp;
  }


}

