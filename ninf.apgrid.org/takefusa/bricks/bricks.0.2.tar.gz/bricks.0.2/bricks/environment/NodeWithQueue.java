package bricks.environment;
import bricks.util.*;
import java.util.*;

public abstract class NodeWithQueue extends Node {

    protected int precision = 6;
    public Queue queue;
    protected Sequence interarrivalTime;

    // for event flag
    protected static final int OTHERSDATA = 0;
    protected static final int QUEUE = 1;
    protected static final int SEND = 2;

/************************* needed method *************************/
    public void processEvent(double currentTime) {
	error("Bat method invocation!");
    }

    public void updateNextEvent(double currentTime) {
	error("Bat method invocation!");
    }

    public boolean isFull() {
	boolean b = false;
	try {
	    queue.isFull();
	} catch (NullPointerException e) {
	    e.printStackTrace();
	    BricksUtil.abort(this + " .isFull(): queue = " + queue);
	}
	return b;
    }

    public void schedule(double currentTime, Data data) {
	queue.enqueue(currentTime, data);
	outQueueLength(currentTime, queue.size());
	updateNextEvent(currentTime);
    }

    public String toOriginalString(double currnetTime) {
	String str = "  [" + getName() + " " + key + "]\n";
	str += "  nextData : " + nextData.toOriginalString();
	str += "  servedData : " + queue.top() + "\n";
	str += queue.toOriginalString();
	return str;
    }

    protected void outQueueLength(double currentTime, int size) {
	printLog(currentTime, " " + size);
    }

    protected void printLog(double currentTime, String log) {
	if (logWriter != null)
	    //logWriter.println(
	    //this + " " + Format.format(currentTime, 3) + " " + log
	    //);
	    logWriter.println(
		this + " " + Format.format(currentTime, 3) + " " + log
	    );
    }

    public void printLog(String log) {
	if (logWriter != null)
	    logWriter.println(this + " " + log);
    }
}

