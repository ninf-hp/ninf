/* ninf regiser program */
#define ERROR_MAIN

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <signal.h>
#include <sys/wait.h>
#include <sys/errno.h>
#include <rpc/rpc.h>
#include "ninf_serv_reg.h"

#include "ninf_error.h"

char * program_context = "Register";


void usage(){
  fprintf(stderr, "ninf_register [[[-register | -remove] filenames] \n           | -dump | -stop | -port PORT]\n");
}

char * get_arg_port(char *); 
int ninf_register_parse_arg(int argc, char ** argv);

main(int argc, char *argv[])
{
  int ac,n;
  char *program;
  char *pwd;
  int register_flag = TRUE;
  char reg_sockname[100];
  char *reg_pkt_buf;
  static int sock;
  
  reg_pkt_buf = (char *) malloc(NINF_REG_PKT_SIZE);  

  if((pwd = (char *)getenv("PWD")) == NULL)
    fprintf(stderr, "cannot get 'PWD', using relative path.\n");

  argc = ninf_register_parse_arg(argc, argv);
    
  make_reg_sockname(reg_sockname, atoi(get_arg_port(getenv("NINF_SERVER_PORT"))));
  sock = ninf_connect_local(reg_sockname);
  if (sock < 0){
    fprintf(stderr, "failed to connect the server\n");
    exit(3);
  }
  for (ac = 1; ac < argc; ac++){
    program = argv[ac];
    if (strncmp(program, "-register", 10) == 0){
      register_flag = TRUE;
    } else if (strncmp(program, "-remove", 8) == 0){
      register_flag = FALSE;      
    } else if (strncmp(program, "-dump", 6) == 0){
      dump(sock, reg_pkt_buf);
    } else if (strncmp(program, "-stop", 6) == 0){
      stop(sock, reg_pkt_buf);
    } else if (strncmp(program, "-h", 3) == 0){
      usage();
      break;
    } else{
      register_flag_program(program, pwd, register_flag, sock, reg_pkt_buf);
    }
  }
  close(sock);
  exit(0);
}

stop(int sock, char * reg_pkt_buf){
  struct ninf_reg_stub_packet *p;

  p = (struct ninf_reg_stub_packet *)reg_pkt_buf;
  p->code = NINF_REG_STOP;
  ninf_reg_send(sock, reg_pkt_buf);
}

dump(int sock, char * reg_pkt_buf){
  struct ninf_reg_stub_packet *p;

  p = (struct ninf_reg_stub_packet *)reg_pkt_buf;
  p->code = NINF_REG_DUMP;
  ninf_reg_send(sock, reg_pkt_buf);
  while (ninf_reg_recv(sock, reg_pkt_buf), p->code == NINF_REG_DUMP_ANS){
    printf("%d: '%s:%s' = '%s'\n",
	   p->stub_index,p->module_name,p->entry_name,p->program);
  }
}

register_flag_program(char * program, char * pwd, int register_flag,
		      int sock, char * reg_pkt_buf){
  struct ninf_reg_stub_packet *p;

  p = (struct ninf_reg_stub_packet *)reg_pkt_buf;
  printf("try to %s  '%s'...\n", register_flag?"register":"remove", program);
  if (register_flag)
    p->code = NINF_REG_ENTER_STUB;
  else
    p->code = NINF_REG_REMOVE_STUB;
  if (pwd && program[0] != '/'){
    strcpy(p->program,pwd);
    strcat(p->program,"/");
    strcat(p->program,program);
  } else 
    strcpy(p->program,program);
  
  ninf_reg_send(sock, reg_pkt_buf);
  ninf_reg_recv(sock, reg_pkt_buf);

  if(p->code != NINF_REG_OK) 
    printf("stub program '%s' %s failed.\n",p->program, 
	   register_flag?"register":"remove");
  else {
    if (register_flag)
      printf("stub program '%s', entry '%s:%s' is registered on %d\n",
	     p->program,p->module_name,p->entry_name,p->stub_index);
    else 
      printf("stub program '%s' was removed\n", p->program);
  }

}


/********* parse args ***********/

static char * arg_port = NINF_SERVER_PORT;
int parse_port_called = FALSE;
int privileged = FALSE;

char * get_arg_port(char * default_port){ 
  if (parse_port_called)
    return arg_port;
  if (default_port != NULL)
    return default_port;
  return NINF_SERVER_PORT;
}

int ninf_register_parse_arg(int argc, char ** argv){
  int i = 0;
  char ** index = argv;
  
  for (; *argv != NULL; argv++){
    if (strcasecmp(*argv, "-port") == 0){
      arg_port= *(++argv);
      parse_port_called = TRUE;
    } else if (strcasecmp(*argv, "-version") == 0){
      print_version();
    } else {
      i++;
      *(index++) = *(argv);
    }
  }
  *(index++) = *(argv);
  return i;
}

