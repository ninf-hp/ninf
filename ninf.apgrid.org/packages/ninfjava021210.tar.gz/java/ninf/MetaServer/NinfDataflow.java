// NinfDataflow.java

package ninf.cproxy;
import ninf.basic.*;
import ninf.client.*;


import java.io.IOException;

class NinfDataflow {
  // *********************** NON STATIC VARIABLES ***********************
  int index;
  int stubNum;
  public NinfStub stub;
  public DependInfo dinfo[];
  NinfLog dbg = new NinfLog(this);

  // ***********************  INSTANCE  CREATION  ***********************
  public NinfDataflow(NinfPacketInputStream is, StubCache stubCache)
    throws NinfException {
      read(is);
      getStub(stubCache);
    }
  
  // ***********************     I/O  METHODS     ***********************
  void read(NinfPacketInputStream is) throws NinfException {
    index = is.readInt();
    stubNum = is.readInt();
    int args = is.readInt();
    dinfo = new DependInfo[args];
    for (int i = 0; i < args; i++)
      dinfo[i] = new DependInfo(is);
    dbg.println("dataflow.read. No:" + index
		+", stubNum:"+ stubNum +", args:"+ args);
  }

  // ***********************  NON STATIC METHODS  ***********************
  void getStub(StubCache stubCache) {
    try {
      stub = fm.getFunction(stubNum).getStub();
    } catch (Exception e) {
      dbg.println("In getStub of NinfDataflow : " + e);
    }
  }

  int[] dependent() {
    int c = 0, d = 0;
    for (int i = 0; i < dinfo.length; i++)
      if (!dinfo[i].isNoLower())
	c++;
    int tmp[] = new int[c];
    for (int i = 0; i < dinfo.length; i++)
      if (!dinfo[i].isNoLower())
	tmp[d++] = dinfo[i].outputDepends[0].functionIndex;
    return tmp;
  }
}

// end of NinfDataflow.java
