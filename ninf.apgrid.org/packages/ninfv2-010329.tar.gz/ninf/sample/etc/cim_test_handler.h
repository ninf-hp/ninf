
typedef struct c_pointer_handler{
  void * pointer;
  int ndim;
  int dim_size[10];
  int current[10];
  DATA_TYPE data_type;
} c_pointer_handler;

c_pointer_handler * new_c_pointer_handler(void * pointer, int ndim, int * dim_size, 
					  DATA_TYPE data_type){
  int i;
  c_pointer_handler * tmp = (c_pointer_handler *)malloc(sizeof(c_pointer_handler));
  tmp->pointer = pointer;
  tmp->ndim = ndim;
  for (i = 0; i < ndim; i++){
    tmp->dim_size[i] = dim_size[i];
    tmp->current[i] = 0;
  }
  tmp->data_type = data_type;
  return tmp;
}

int ninf_cim_init_c(obj_handler h){
  c_pointer_handler * handler = (c_pointer_handler *)h;
  int i;
  for (i = 0; i < handler->ndim; i++){
    handler->current[i] = 0;
  }
  return CIM_OK; 
}
int ninf_cim_finalize_c(obj_handler  h){
  return CIM_OK; 
}
int ninf_cim_destruct_c(obj_handler  h){
  return CIM_OK; 
}

int ninf_cim_proceed_c(obj_handler h, int rank, int n){
  c_pointer_handler * handler = (c_pointer_handler *)h;
  int i;
  for (i = 0; i < rank; i++)
    handler->current[i] = 0;
  handler->current[rank] += n;
  return CIM_OK;
}

char * calc_pointer (c_pointer_handler * handler){
  char * tmp = (char *)(handler->pointer);
  int i, size;
  size = handler->current[handler->ndim];
  for (i = handler->ndim - 1; i >= 0; i--){
    size *= handler->dim_size[i];
    size += handler->current[i];
  }
  tmp += type_size[handler->data_type] * size;
  return tmp;
}

int ninf_cim_get_c(obj_handler h, void * p, DATA_TYPE d){
  c_pointer_handler * handler = (c_pointer_handler *)h;  
  char * tmp;
  int i;
  if (d != handler->data_type)
    return CIM_ERROR_TYPE_MISMATCH;
  for (i = 0; i < handler->ndim; i++)
    if (handler->current[i] >= handler->dim_size[i])
      return CIM_ERROR_ARRAY_BOUND;
  tmp = calc_pointer(handler);
  memcpy(p, tmp, type_size[d]);
  return CIM_OK;
}

int ninf_cim_put_c(obj_handler h, void * p, DATA_TYPE d){
  c_pointer_handler * handler = (c_pointer_handler *)h;  
  char * tmp;
  int i;
  if (d != handler->data_type)
    return CIM_ERROR_TYPE_MISMATCH;
  for (i = 0; i < handler->ndim; i++)
    if (handler->current[i] >= handler->dim_size[i])
      return CIM_ERROR_ARRAY_BOUND;
  tmp = calc_pointer(handler);
  memcpy(tmp, p, type_size[d]);
  return CIM_OK;
}

