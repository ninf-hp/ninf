#define _WRAPPER_
/* $Id: pdsyntrd_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define _DISTRIBUTE_1D_
#define DOUBLE
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n

static	int worklen(int n) {
	  int ret=1;
	  int ANB, SQNPC, NPS;
	  const int three=3;
	  ANB=max(n,100);
	  ret = 2*( ANB+1 )*( 4*n+2 ) + ( n + 4 ) * n;
	  if NEED_BUFF {
#if defined(FLOAT)
	    ANB = FortranCall(pjlaenv)( &PARA_CTXT, &three, "PSSYTTRD", "L", &zero, &zero, &zero, &zero );
#elif defined(DOUBLE)
	    ANB = FortranCall(pjlaenv)( &PARA_CTXT, &three, "PDSYTTRD", "L", &zero, &zero, &zero, &zero );
#endif
	    SQNPC = (int)( sqrt( (double)( NPROW * NPCOL ) ) );
	    NPS = MAX( NUMROC( N, 1, 0, 0, SQNPC ), 2*ANB );

	    ret = 2*( ANB+1 )*( 4*NPS+2 ) + ( NPS + 4 ) * NPS;
	  }
	  return ret;
}


void  pdsyntrd_ninf(	 char uplo,
			 int n,
			 double global_a[],
			 int lda,
			 double global_d[],
			 double global_e[], //uplo
			 double global_tau[],
			 int *info
)
/* "pdsyntrd is a prototype version of PSSYTRD which uses tailored codes (either the serial, SSYTRD, or the parallel code, PSSYTTRD) when the workspace provided by the user is adequate." */
/* OPTIONS */
{
	int maxldd;

	int maxlda;
	double *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
	int row_loca, col_loca;

	double *locd=NULL;
	double *loce=NULL;
	int desctdd[DESCLEN];
	int desc_gtdd[DESCLEN];

	double *loctau=NULL;

	double *locwork=NULL;
	int llocwork;

	INITIALIZE();

	SCALAR( "char", uplo);
	SCALAR( "int", n);
	SCALAR( "int", lda);
	SIZE(n);

	ROW( a);
	COL( a);
	MAXLDD( maxldd, a );
	maxlda = maxldd;

	trMATRIX( uplo, "double", a, ROW_a, COL_a);
	trDISTRIBUTE( uplo, "double", a, ROW_a  , COL_a);

	VECTOR("c", "double", tau, n);

	if (chrcmp(uplo,'U')==0) tdMATRIX( "double", 0, d, e, n);
	else tdMATRIX( "double", e, d, 0, n);

	llocwork = worklen(n);
	WORK(locwork,llocwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pdsyntrd)( &uplo, &n,
                                loca, &one, &one, desca,
                                locd, loce,
                                loctau,
                                locwork, &llocwork, &linfo);

	trGATHER( uplo, "double", a, ROW_a  , COL_a);
	if (chrcmp(uplo,'U')==0) tdGATHER("double", 0, d, e, n);
	else tdGATHER("double", e, d, 0, n);
	vGATHER("c","double", tau, n);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
		*info = linfo;
	} else {
	}

	FREE_MATRIX(a);
	FREE_MATRIX(d);
	FREE_MATRIX(e);
	FREE_VECTOR(tau);
        FREE(locwork);
	
}

