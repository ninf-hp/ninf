/* 
 * ninf_server of TCP/IP version. execute packet routines.
 */

#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/time.h>
#include <signal.h>
#include <sys/wait.h>
#include <errno.h>
#include "ninf_stub_info.h"
#include "ninf_serv_reg.h"
#include "ninf_data_trans.h"
#include "dump_time.h"
#include "ninf_read_config.h"
#include "ninf_error.h"
#include "get_load.h"
#include "ninf_server_state.h"
#include "ninf_config.h"

extern int ninf_debug_flag;

extern int call_serial;

#define max(x,y)	((x)>(y) ? (x) : (y))
extern int errno;
extern int redirect_outerr;

#define MAX_LISTEN	3

/* sever packet buffer */
char * getpeer(int ns);
	    
authenticate_rcmd(server_state * state){
    int size;
    char buffer[128], *pointer;
    char * peerhost;
    int    peerport;
    dataTrans * sDT = state->client->sDT;
    dataTrans * rDT = state->client->rDT; 

    read_onemore(rDT);

    size = NINF_PKT_SIZE(&(rDT->decoded)) - NINF_PKT_HEADER_SIZE;
    if(ninf_debug_flag)
      fprintf(stderr, "exec_packet_req(code=%d, size=%d(%d),arg1=%d,arg2=%d)\n",
	      NINF_PKT_CODE(&(rDT->decoded)),NINF_PKT_SIZE(&(rDT->decoded)),
	      size,
	      NINF_PKT_ARG1(&(rDT->decoded)),NINF_PKT_ARG2(&(rDT->decoded)));
    
    if (NINF_PKT_CODE(&(rDT->decoded)) != NINF_PKT_AUTH){
      ninf_serv_to_client(state, NINF_PKT_ERROR, NINF_AUTHENTICATION_FAILED,0);
      return FALSE;
    } 
    pointer = &(buffer[0]);
    if (!trans_string(rDT, &pointer, MAX_NAME_LEN)){
      if(ninf_debug_flag)
	fprintf(stderr, "failed to get auth string\n");
      ninf_serv_to_client(state, NINF_PKT_ERROR, NINF_AUTHENTICATION_FAILED,0);
      return FALSE;
    }
    peerhost = getpeer(rDT->fd);
    peerport = getpeerport(rDT->fd);

#ifndef _NO_RUSEROK_
    if (peerport > 512 && peerport < 1024){
      int ok = ruserok(peerhost, FALSE, buffer, buffer);
      if (ok == 0){
	ninf_log("Name = %s, port = %d: authentication OK", buffer, peerport);
	ninf_serv_to_client(state,NINF_PKT_AUTH_OK, 0,0);
	return TRUE;
      } else {
	ninf_log("ruserok failed, must be root, %d ", ok);
      }
    }
#endif
    ninf_log("Name = %s, port = %d: authentication FAILED", buffer, peerport);
    ninf_serv_to_client(state, NINF_PKT_ERROR, 0,0);
    return FALSE;
}

exec_packet_req(server_state * state){
  char *datap;
  int req;
  int error_code = 0;
  int code = NINF_PKT_CODE(&(state->client->rDT->decoded));
  
  if(ninf_debug_flag)
  fprintf(stderr, "exec_packet_req(code=%d, size=%d(%d),arg1=%d,arg2=%d)\n",
    NINF_PKT_CODE(&(state->client->rDT->decoded)),
    NINF_PKT_SIZE(&(state->client->rDT->decoded)),
    NINF_PKT_SIZE(&(state->client->rDT->decoded)) - NINF_PKT_HEADER_SIZE,
    NINF_PKT_ARG1(&(state->client->rDT->decoded)),
    NINF_PKT_ARG2(&(state->client->rDT->decoded)));

  switch(code){
  case NINF_PKT_THROUGHPUT:
    ninf_pkt_throughput(state);
    break;
  case NINF_PKT_LOAD:
    ninf_pkt_load(state);
    break;
  case NINF_PKT_CHARACTER:
    ninf_pkt_character(state);
    break;
  case NINF_PKT_GETTIME:
    ninf_pkt_gettime(state);
    break;
  case NINF_PKT_TO_STUB:
    if(ninf_debug_flag)
      fprintf(stderr, "NINF_PKT_TO_STUB\n");
    DUMP_TIME_TICK();
    ninf_pkt_to_stub(state);
    return;
  case NINF_PKT_REQ_STUB_INFO:	/* request stub info */
    if(ninf_debug_flag)
      fprintf(stderr, "NINF_PKT_REQ_STUB_INFO\n");
    DUMP_TIME_TICK();
    /* search entry */
    if ((error_code = ninf_pkt_req_stub_info(state)) != NINF_ERROR_NOERROR) 
      goto err_reply;
    break;
  case NINF_PKT_REQ_CALL:		/* request call */
    if(ninf_debug_flag)
      fprintf(stderr, "NINF_PKT_REQ_CALL\n");
    DUMP_TIME_TICK();
    if ((error_code = ninf_pkt_req_call(state)) != NINF_ERROR_NOERROR) 
      goto err_reply;
    break;
    
  case NINF_PKT_REQ_EXEC:	/* exec stub program directly, for debug */
    DUMP_TIME_TICK();
    if(ninf_debug_flag)
      fprintf(stderr, "NINF_PKT_REQ_EXEC\n");
    ninf_pkt_req_exec(state);
    /* return ack packet */
    break;
    
  case NINF_PKT_REQ_STUB_INDEX_LIST:  /* req stub index list */
    if(ninf_debug_flag)
      fprintf(stderr, "NINF_PKT_REQ_STUB_INDEX_LIST\n");
    DUMP_TIME_TICK();
    ninf_pkt_req_stub_index_list(state);
    return;

  case NINF_PKT_REQ_STUB_BY_INDEX:    /* req stub by index */
    if(ninf_debug_flag)
      fprintf(stderr, "NINF_PKT_REQ_STUB_BY_INDEX\n");
    DUMP_TIME_TICK();
    /* search entry */
    if ((error_code = ninf_pkt_req_stub_by_index(state)) != 
	NINF_ERROR_NOERROR) 
      goto err_reply;
    return;
    
  case NINF_PKT_GET_STORAGE_RESOURCE:
    if(ninf_debug_flag) fprintf(stderr, "NINF_PKT_GET_STORAGE_RESOURCE\n");
    if ((error_code = ninf_pkt_get_storage(state)) != NINF_ERROR_NOERROR)
      goto err_reply;
    return;
    
  case NINF_PKT_PUT_STORAGE_RESOURCE:
    if(ninf_debug_flag) fprintf(stderr, "NINF_PKT_PUT_STORAGE_RESOURCE\n");
    if ((error_code = ninf_pkt_put_storage(state)) != NINF_ERROR_NOERROR)
      goto err_reply;
    return;
    
  case NINF_PKT_CLEAR_STORAGE_RESOURCE:
    if(ninf_debug_flag) fprintf(stderr, "NINF_PKT_CLEAR_STORAGE_RESOURCE\n");
    if ((error_code = ninf_pkt_clear_storage(state)) != NINF_ERROR_NOERROR)
      goto err_reply;
    return;
    
  case NINF_PKT_KILL:
    DUMP_TIME_DUMP();
    kill_stub_program(state);
    {
      extern int dying;
      dying = TRUE;
    }
    break;
    
#ifdef DUMP_TIME
  case NINF_PKT_SET_SKIP_TIME:
    DUMP_TIME_SET_SKIP(NINF_PKT_ARG1(&decoded));
    ninf_serv_to_client(state, NINF_PKT_ACK_SKIP_TIME,0,0);
    break;
#endif
    
  default:
    ninf_log("unknown/unsupported packet %d",
	     NINF_PKT_CODE(&(state->client->rDT->decoded)));
  }
  return;
  
 err_reply:
  ninf_serv_to_client(state, NINF_PKT_ERROR,error_code,0);
}

ninf_pkt_req_exec(server_state * state){
  dataTrans * rDT = state->client->rDT;
  char buffer[MAX_NAME_LEN];
  char *tmp;
  int error_code;
  tmp = buffer;
  trans_string(rDT, &tmp, MAX_NAME_LEN);
  error_code= exec_stub_program(buffer, FALSE);  
  if (error_code != NINF_ERROR_NOERROR)
    ninf_serv_to_client(state, NINF_PKT_ERROR,error_code,0);
  else
    ninf_serv_to_client(state, NINF_PKT_RPY_EXEC,0,0);
}

ninf_pkt_to_stub(server_state * state){
  dataTrans * rDT = state->client->rDT;
  if(ninf_debug_flag)
    fprintf(stderr, "ninf_pkt_to_stub()\n");
  if(state->stub == NULL){
    ninf_log("no stub in ninf_pkt_to_stub");
    return;
  }
  if(trans_count(rDT) == 0) {
    /* zero size packet ??? 
    ninf_log("zero size packet to stub");
    return;*/
  }
  force_write(rDT, connection_get_fd(state->stub), FALSE);
}

ninf_pkt_load(server_state * state){
  dataTrans * sDT = state->client->sDT;

  struct load l;
  get_load(&l);
  
  trans_double(sDT, &(l.loadAverage));
  trans_double(sDT, &(l.user));
  trans_double(sDT, &(l.system));
  trans_double(sDT, &(l.idle));

  trans_flush(sDT, NINF_PKT_RPY_LOAD, 0, 0);
}

extern int CPUs;
extern int performance;
extern int mem_size;

ninf_pkt_gettime(server_state * state){
  dataTrans * sDT = state->client->sDT;
  double val;
  struct timeval tp;
  gettimeofday(&tp, NULL);
  val = tp.tv_sec + tp.tv_usec * 0.000001;
  trans_double(sDT, &val);
  trans_flush(sDT, NINF_PKT_RPY_GETTIME, 0, 0);
}

ninf_pkt_character(server_state * state){
  dataTrans * sDT = state->client->sDT;
  trans_int(sDT, &CPUs);
  trans_int(sDT, &performance);
  trans_int(sDT, &mem_size);

  trans_flush(sDT, NINF_PKT_RPY_CHARACTER, 0, 0);
}


ninf_pkt_throughput(server_state * state){
  DECODED_HEADER * header = &(state->client->rDT->decoded);
  
  int length = NINF_PKT_ARG1(header);
  int mode =   NINF_PKT_ARG2(header); /* (0=both,1=fore,2=back) */

  if (mode == 0 || mode == 1)
    trans_read_skip(state->client->rDT, length);

  ninf_serv_to_client(state, NINF_PKT_RPY_THROUGHPUT,0,0);

  if (mode == 0 || mode == 2)
    trans_write_skip(state->client->sDT, length);
  write_flush(state->client->sDT);
}

ninf_pkt_req_stub_index_list(server_state * state){
  dataTrans *rDT = state->client->rDT;
  dataTrans *sDT = state->client->sDT;
  NINF_REG_ENTRY *ep;
  int counter = 0;
  int from = 0, option;
  char entry_name[MAX_NAME_LEN], *cp;
  cp = entry_name;
  if(!trans_string(rDT,&cp,MAX_NAME_LEN)) return NINF_ERROR_CANTFINDSTUB;;
  option = NINF_PKT_ARG1(&(rDT->decoded));

  while((ep = find_reg_stub_entry_from(entry_name, from, option)) != NULL){
    counter++;
    trans_int(sDT, &(ep->index));
    from = ep->index + 1;
  }
  trans_flush(sDT, NINF_PKT_RPY_STUB_INDEX_LIST, counter, 0);  
  if (ninf_debug_flag) printf("counter = %d \n", counter);
  return NINF_ERROR_NOERROR;  
}

ninf_pkt_req_stub_by_index(server_state * state){
  dataTrans *rDT = state->client->rDT;
  dataTrans *sDT = state->client->sDT;

  NINF_REG_ENTRY *ep;
  int index;
  index = NINF_PKT_ARG1(&(rDT->decoded));
  if ((ep = find_reg_stub_index(index))== NULL)
    return NINF_ERROR_CANTFINDSTUB;
  trans_stub_info(sDT, ep->stub_info, TRUE);	

  trans_flush(sDT, NINF_PKT_RPY_STUB_INFO, ep->index,0);
  return NINF_ERROR_NOERROR;
}


ninf_pkt_req_stub_info(server_state * state){
  dataTrans *rDT = state->client->rDT;
  dataTrans *sDT = state->client->sDT;
  NINF_REG_ENTRY *ep;
  char entry_name[MAX_NAME_LEN], *cp;

  cp = entry_name;
  if(!trans_string(rDT,&cp,MAX_NAME_LEN)) return NINF_ERROR_CANTFINDSTUB;;

  if((ep = find_reg_stub_entry(entry_name)) == NULL) {
    return NINF_ERROR_CANTFINDSTUB;
  } else {
    if(ninf_debug_flag) 
      printf("send stub entry(%d) for '%s'..\n",ep->index,entry_name);
    
    if(ninf_debug_flag)
      fprintf(stderr, "sending %s, %s\n",
	    ep->stub_info->module_name,ep->stub_info->entry_name);

    set_trans_header(sDT, NINF_PKT_RPY_STUB_INFO, ep->index, 
		ep->stub_info->registered_time);  /* for big sized stub */

    trans_stub_info(sDT, ep->stub_info, TRUE);	

    trans_flush(sDT, NINF_PKT_RPY_STUB_INFO, ep->index, 
		ep->stub_info->registered_time);
  }
  return NINF_ERROR_NOERROR;
}

ninf_pkt_req_call(server_state * state){
  dataTrans *rDT = state->client->rDT;
  dataTrans *sDT = state->client->sDT;
  NINF_REG_ENTRY *ep;
  int error_code;

  if((ep = find_reg_stub_index(NINF_PKT_ARG1(&(rDT->decoded)))) == NULL) 
    return NINF_ERROR_STUBREMOVED;

  if (ep->stub_info->registered_time != NINF_PKT_ARG2(&(rDT->decoded)) &&
      NINF_PKT_ARG2(&(rDT->decoded)) != 0){ /* for backward compatibility */
    /* cache have to be expired */
    return NINF_ERROR_STUBREMOVED;
  }

  if(ninf_debug_flag)
    fprintf(stderr, "exec stub %d...\n", NINF_PKT_ARG1(&(rDT->decoded)));
  ninf_log("server[%d]: execstub %s", getpid(), ep->program);
  if ((error_code = exec_stub_program(state, ep->program, ep->stub_info->backend)) != NINF_ERROR_NOERROR) {
    if(ninf_debug_flag)
      fprintf(stderr, "exec_stub_program(%s) fail.\n", ep->program);
    return error_code;
  }
  trans_int(sDT, &call_serial);
  ninf_serv_to_client(state, NINF_PKT_RPY_CALL,0,0);

  return NINF_ERROR_NOERROR;  
}


int exec_stub_program(server_state *state, char * stubname, int backend){
  char buffer[1000];
  int checkPid = (backend == BACKEND_NORMAL)? TRUE: FALSE;

  if(state->stub != NULL){
    ninf_log("stub is already executed");
    return NINF_ERROR_STUBALREADY;
  }
  if (backend == BACKEND_NORMAL){
    sprintf(buffer, "%s", stubname);
  } else {                  /* MPI */
    sprintf(buffer, "%s -np %d %s", MPIRUN, MPI_PROCS, stubname);
  }

  if (redirect_outerr){
    if (ninf_local_forkexec_outerr(buffer, checkPid, state) < 0)
      return NINF_ERROR_CANTEXECUTESTUB;
  } else {
    if (ninf_local_forkexec_state(buffer, checkPid, state) < 0)
      return NINF_ERROR_CANTEXECUTESTUB;
  }
  return NINF_ERROR_NOERROR;
}

kill_stub_program(server_state *state){
    if(state->stub == NULL){
      ninf_log("no stub in kill_stub_program");
      return;
    }
    ninf_local_kill_state(state);
    state->stub = NULL;
}

force_kill_stub_program(server_state *state){
  if (state->stub_pid > 0){
    kill(state->stub_pid, SIGINT); 
    wait_for_killed(state->stub_pid); 
  }
}
