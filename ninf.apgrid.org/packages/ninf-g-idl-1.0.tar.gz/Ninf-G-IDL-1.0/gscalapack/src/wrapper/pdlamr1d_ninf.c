#define _WRAPPER_
/* $Id: pdlamr1d_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define DOUBLE
#include <gscalapack.h>
void  pdlamr1d_ninf(	 int n,
			 double global_a[],
			 double global_b[]
)
/* "pdlamr1d redistributes a one-dimensional row vector from one data decomposition to another. This is an auxiliary routine called by PSSYTRD to redistribute D, E  and TAU." */
/* OPTIONS */
{
	int maxldd;
	double *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
	int row_loca, col_loca;

	double *locb=NULL;
	int descb[DESCLEN];
	int desc_gb[DESCLEN];
	int row_locb, col_locb;


	INITIALIZE();

	SCALAR( "int", n);

	VECTOR("c","double", a,n);
	vDISTRIBUTE( "c", "double", a, n);
	Cdescinit( desca, 1, n, 1, n, 0, 0, PARA_CTXT, 1, &linfo);
        
	VECTOR("c","double", b,n);
	vDISTRIBUTE( "c", "double", b, n);
	Cdescinit( descb, 1, n, 1, n, 0, 0, PARA_CTXT, 1, &linfo);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pdlamr1d)( &n,
                                loca, &one, &one, desca,
                                locb, &one, &one, descb);

	vGATHER("c","double", a, n);
	vGATHER("c", "double", b, n);

	if( mypnum == 0 ){
	} else {
	}
        FREE_VECTOR(a);
        FREE_VECTOR(b);
	
}

