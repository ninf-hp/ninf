package bricks.util;
import java.io.*;

/**
 * InterpolationCpu returns current processing performance assuming 
 * machine load from [file].<BR>
 **/
public class InterpolationCpu extends InterpolationThroughput {

    private double throughput;

    public InterpolationCpu(double throughput) {
	this.throughput = throughput;
    }

    public String getName() {
	return interpolationType + "Cpu";
    }

    public double max() {
	return throughput;
    }

    public double nextDouble(double currentTime) {
	return throughput * interpolation.getPoint(currentTime);
    }

    public double nextDouble() {
	return throughput * interpolation.getPoint();
    }

    /******************** public method for Queue ********************/
    public double getCpuUtilization(double currentTime, double trackingTime) {
	//return 1.0 - interpolation.getPoint(currentTime);
	return 1.0 - interpolation.getIntegral(currentTime, trackingTime);
    }

    public double getLoad(double currentTime, double trackingTime) {
	//return 1.0 / interpolation.getPoint(currentTime) - 1;
	return 1.0 / interpolation.getIntegral(currentTime, trackingTime) - 1.0;
    }
}
