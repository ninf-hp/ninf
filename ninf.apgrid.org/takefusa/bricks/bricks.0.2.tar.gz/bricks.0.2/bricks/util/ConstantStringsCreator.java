package bricks.util;
import java.util.*;

public class ConstantStringsCreator extends SubComponentCreator {

    public String usage() {
	return "ConstantStrings(<String string>)";
    }

    public SubComponent create(StringTokenizer st) throws BricksParseException{
	try {
	    return new ConstantStrings(st.nextToken(" \t,()"));
	} catch (NoSuchElementException e) {
	    e.printStackTrace();
	    throw new BricksParseException(usage());
	}
    }
}

