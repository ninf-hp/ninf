#define _WRAPPER_
/* $Id: pspocon_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define FLOAT
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n

static	int worklen(int n) {
	  int ret=1;
	  ret =  2*n + 2*n +
	      MAX( 2, n + n );
	  if NEED_BUFF {
	    ret =  2*LOCr(N+MOD(IA-1,MB_A)) + 2*LOCc(N+MOD(JA-1,NB_A))+
 MAX( 2, MAX(NB_A*CEIL(NPROW-1,NPCOL),LOCc(N+MOD(JA-1,NB_A)) +
	     NB_A*CEIL(NPCOL-1,NPROW)) );
	  }
	  return ret;
}

static	int iworklen(int n) {
	  int ret=1;
	  ret = n;
	  if NEED_BUFF {
	    ret =  LOCr(N+MOD(IA-1,MB_A));
	  }
	  return ret;
}

void  pspocon_ninf(	 char uplo,
		 int n,
		 float global_a[],
		 int lda,
		 float anorm,
		 float *rcond,
		 float work[],
		 int iwork[],
		 int *info
)
/* "pspocon estimates the reciprocal of the condition number (in the 1-norm) of a real symmetric positive definite distributed matrix using the Cholesky factorization A = U**T*U or A = L*L**T computed by PSPOTRF." */
/* OPTIONS */
{
	int maxldd;

	int maxlda;
	float *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
	int row_loca, col_loca;

	float *locwork=NULL;
	int llocwork;
	float *lociwork=NULL;
	int llociwork;

	float locrcond[1];


	INITIALIZE();

	SCALAR( "char", uplo);
	SCALAR( "int", n);
        SCALAR( "int", lda);
	SCALAR( "float", anorm);

	ROW( a);
	COL( a);
	MAXLDD( maxldd, a );
	maxlda = maxldd;

	MATRIX( "float", a, ROW_a, COL_a);
	DISTRIBUTE( "float", a, ROW_a, COL_a);

	llocwork = worklen(n);
	WORK(locwork,llocwork);
	llociwork = iworklen(n);
	IWORK(lociwork,llociwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pspocon)( &uplo, &n,
                               loca, &one, &one, desca,
                               &anorm,
                               locrcond,
                               locwork, &llocwork,
                               lociwork, &llociwork,
                               &linfo);

	RETRIEVE("float",locrcond,1);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
		*info = linfo;
		*rcond = locrcond[0];
	} else {
		
	}

	FREE_MATRIX(a);
        FREE(locwork);
        FREE(lociwork);
	
}

