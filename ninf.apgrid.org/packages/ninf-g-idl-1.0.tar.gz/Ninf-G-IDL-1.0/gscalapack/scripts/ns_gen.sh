#! /bin/sh
# $Id: ns_gen.sh,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $

# Use this script when you can't get a gcc-like preprocessor.

TMPFILE=.tmp.idl
echo '#define NSGENSH_ST_INCLUDE #include' > $TMPFILE
gcc -E -xc $*|sed -e 's!#include!NSGENSH_ST_INCLUDE!g' >> $TMPFILE

ns_gen $TMPFILE

rm $TMPFILE