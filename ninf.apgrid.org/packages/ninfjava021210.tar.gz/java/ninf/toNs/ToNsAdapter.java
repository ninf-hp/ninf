package ninf.toNs;
import ninf.basic.*;

public class ToNsAdapter{
  static ToNsConfig conf;
  
  public static NinfLog dbg = new NinfLog("ToNsAdapter");
  ToNsRoot toNsRoot; 

  void usage(){
    dbg.println("USAGE: java ninf.toNs.ToNsAdapter [-port PORT] [-debug] CONFIGFILE");
  }  

  void start(String args[]){
    try {
      conf = new ToNsConfig(args);
      conf.configure();
      toNsRoot = new ToNsRoot(conf.myhostname, conf.port);
    } catch (NinfException e){
      usage();
      System.exit(3);
    }
    toNsRoot.start();
  }
  public static void main(String args[]){
    new ToNsAdapter().start(args);
  }
}
