/* gscalapack-scalapack.h */
#ifndef _GSCALAPACK_SCALAPACK_H_
#define _GSCALAPACK_SCALAPACK_H_

/* utilities */
#ifndef F77_procmap
#define F77_procmap    procmap_
extern void procmap_( int*, const int*, const int*, const int*, const int*, int*);
#endif

// /* vector distribution */
#define vdtype float
extern void svDistribute( char *, vdtype *, int , int , vdtype *, int,int , int, int, int, int, int ,  int ,   int);
#undef vdtype

#define vdtype double
extern void dvDistribute( char *, vdtype *, int , int , vdtype *, int,int , int, int, int, int, int ,  int ,   int);
#undef vdtype

#define vdtype scomplex
extern void cvDistribute( char *, vdtype *, int , int , vdtype *, int,int , int, int, int, int, int ,  int ,   int);
#undef vdtype

#define vdtype dcomplex
extern void zvDistribute( char *, vdtype *, int , int , vdtype *, int,int , int, int, int, int, int ,  int ,   int);
#undef vdtype

#define vdtype int
extern void ivDistribute( char *, vdtype *, int , int , vdtype *, int,int , int, int, int, int, int ,  int ,   int);
#undef vdtype

#define vdtype float
extern void svGather( char *, vdtype *,int,int, vdtype *, int, int, int, int,int,int, int,int, int);
#undef vdtype

#define vdtype double
extern void dvGather( char *, vdtype *,int,int, vdtype *, int, int, int, int,int,int, int,int, int);
#undef vdtype

#define vdtype scomplex
extern void cvGather( char *, vdtype *,int,int, vdtype *, int, int, int, int,int,int, int,int, int);
#undef vdtype

#define vdtype dcomplex
extern void zvGather( char *, vdtype *,int,int, vdtype *, int, int, int, int,int,int, int,int, int);
#undef vdtype

#define vdtype int
extern void ivGather( char *, vdtype *,int,int, vdtype *, int, int, int, int,int,int, int,int, int);
#undef vdtype


/* blacs */
extern void Cblacs_pinfo(int *, int *);
extern void Cblacs_get(int , int, int *);
extern int Cblacs_gridinit(int *ConTxt, char *order, int nprow, int npcol);
extern void Cblacs_gridinfo(int ConTxt, int *nprow, int *npcol, int *myrow, int *mycol);

extern void  Cigamx2d( int all_ctxt, char* scope, char* top, int m, int n,
		       int *A,int, int* ,int* , int, int, int);
extern void  Csgamx2d( int all_ctxt, char* scope, char* top, int m, int n,
		       float *A,int, int* ,int* , int, int, int);
extern void  Cdgamx2d( int all_ctxt, char* scope, char* top, int m, int n,
		       double *A,int, int* ,int* , int, int, int);
extern void  Ccgamx2d( int all_ctxt, char* scope, char* top, int m, int n,
		       scomplex *A,int, int* ,int* , int, int, int);
extern void  Czgamx2d( int all_ctxt, char* scope, char* top, int m, int n,
		       dcomplex *A,int, int* ,int* , int, int, int);


extern void Cigebs2d(int, char *, char *, int, int, int *, int);
extern void Cigebr2d(int, char *, char *, int, int, int *, int, int, int);

extern void Cdgebs2d(int, char *, char *, int, int, double *, int);
extern void Cdgebr2d(int, char *, char *, int, int, double *, int, int, int);

extern void Csgebs2d(int, char *, char *, int, int, float *, int);
extern void Csgebr2d(int, char *, char *, int, int, float *, int, int, int);

extern void Ccgebs2d(int, char *, char *, int, int, scomplex *, int);
extern void Ccgebr2d(int, char *, char *, int, int, scomplex *, int, int, int);

extern void Czgebs2d(int, char *, char *, int, int, dcomplex *, int);
extern void Czgebr2d(int, char *, char *, int, int, dcomplex *, int, int, int);


/* scalapack redist */

extern void Cpigemr2d( int, int, int*, int, int, int* , int*, int, int, int*, int);
extern void Cpdgemr2d( int, int, double*, int, int, int* , double*, int, int,int*, int);
extern void Cpsgemr2d( int, int, float*, int, int, int*, float*, int, int, int*, int);
extern void Cpcgemr2d( int, int, scomplex*, int, int, int*, scomplex*, int, int, int*, int);
extern void Cpzgemr2d( int, int, dcomplex*, int, int, int*, dcomplex*, int, int, int*, int);

/* scalapack tools */

/* triangle matrix redist */
extern void Cpitrmr2d( char*, char*, int, int, int*, int, int, int* , int*, int, int, int*, int);
extern void Cpdtrmr2d( char*, char*,int, int, double*, int, int, int* , double*, int, int, int*, int);
extern void Cpstrmr2d( char*, char*,int, int, float*, int, int, int*, float*, int, int, int*, int);
extern void Cpctrmr2d( char*, char*,int, int, scomplex*, int, int, int* , scomplex*, int, int, int*, int);
extern void Cpztrmr2d( char*, char*,int, int, dcomplex*, int, int, int*, dcomplex*, int, int, int*, int);

#endif
