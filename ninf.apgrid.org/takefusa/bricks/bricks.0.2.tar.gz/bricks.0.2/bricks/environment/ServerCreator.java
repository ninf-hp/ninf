package bricks.environment;
import bricks.util.*;
import java.util.*;

public class ServerCreator extends ComponentCreator {

    // for bricks.tools.ShowUsage
    public ServerCreator(){}

    public ServerCreator(
	SimulationSet owner, SubComponentFactory subComponentFactory
    ) {
	this.owner = owner;
	this.subComponentFactory = subComponentFactory;
    }

    public String usage() {
	return "Server(<String key> <Queue queue> " +
	    "OthersData(<Sequence numInstructions>, " +
	    "<Sqeuence interarrivalTime>) (<int traceBufferSize>))";
    }

    public Node createNode(String str) throws BricksParseException {
	SimulationDebug.println("create Server...");
	try {
	    StringTokenizer st = new StringTokenizer(str);
	    String tmp = st.nextToken(" \t(),"); // server
	    if (!st.hasMoreElements()) {
		return new NullServer();
	    }
	    String key = st.nextToken(" \t(),");
	    Queue queue = (Queue)subComponentFactory.create(st);

	    tmp = st.nextToken(" \t(),"); // OthersData
	    Sequence numInstructions = null;
	    Sequence interarrivalTime = null;
	    if (!tmp.equalsIgnoreCase("n/a")) {
		numInstructions = (Sequence)subComponentFactory.create(st);
		interarrivalTime = (Sequence)subComponentFactory.create(st);
	    }

	    if (st.hasMoreElements()) {
		int traceBufferSize = 
		    Integer.valueOf(st.nextToken(" \t,()")).intValue();
		return new Server(
		    owner, key, queue, numInstructions, 
		    interarrivalTime, traceBufferSize
	        );
		
	    } else {
		return new Server(
		    owner, key, queue, numInstructions, interarrivalTime
	        );
	    }

	} catch (NoSuchElementException e) {
	    e.printStackTrace();
	    throw new BricksParseException(usage());

	} catch (NumberFormatException e) {
	    e.printStackTrace();
	    throw new BricksParseException(usage());

	} catch (BricksParseException e) {
	    e.addMessage(usage());
	    throw e;
	}
    }
}
