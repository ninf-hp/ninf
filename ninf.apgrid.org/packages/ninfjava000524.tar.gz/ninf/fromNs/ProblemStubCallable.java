package ninf.fromNs;
import ninf.client.NinfServerStruct;
import ninf.client.*;
import ninf.basic.*;
import ninf.cproxy.*;
import ninf.netsolve.*;
import java.io.*;

class ProblemStubCallable extends Callable{
  public NinfStub stub;
  public Problem  problem;
  static NinfLog dbg = new NinfLog("ProblemStubCallable");
  NinfServerStruct cproxy = FromNsAdapter.conf.cproxy;

  public ProblemStubCallable(NinfStub stub, int index) throws NinfException{
    this.stub = stub;
    this.index = index;
    problem = Problem.makeUp(stub);
  }

  public NinfStub getStub(){
    return stub;
  }

  public Stoppable call(NinfPacket dum, int serial,
			XDRInputStream is, XDROutputStream os) 
    throws NinfException {
    NinfServerConnection con;
    CallContext context;

    dbg.println("call invoked");
    try {
      dbg.println("serverReceive ...");
      context = problem.serverReceive(stub, is);
      dbg.println("serverReceive done");
    } catch (Exception e){
      e.printStackTrace();
      throw new NinfIOException();
    }
    
    try {
      dbg.println("connecting server ...");
      con = cproxy.connect();
      dbg.println("connecting server done");
      dbg.println("getting stub ...");
      NinfStub dummy = con.getStub(stub.getName().toString());
      int index = con.currentIndex;
      dbg.println("got     stub ...");
      dbg.println("native calling ...");
      con.callNative(stub, index, context);
      dbg.println("native call done");
      
      os.writeChar(GlobalDefs.DATA_XDR);
      os.writeInt(GlobalDefs.SOLUTION);
      problem.writeBack(context, stub, os);
    } catch (IOException e) {
      throw new NinfIOException();
    }
    return con;
  }



}
