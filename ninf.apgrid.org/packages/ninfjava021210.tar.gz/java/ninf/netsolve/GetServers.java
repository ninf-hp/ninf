package ninf.netsolve;
import java.io.IOException;

public class GetServers extends GlobalDefs {
  private MyStream str;
  private final int DETAIL = 3;
  private ServerStatus servers[];
  private int longest_hostname = 0;
  private String blank_string = "                                        ";

  private int IP_ADDR_FIELD_WIDTH = 17;
  private int HOST_STATUS_FIELD_WIDTH = 13;
  private int SERVER_STATUS_FIELD_WIDTH = 15;
  private int PROBLEMS_FIELD_WIDTH = 10;

  private void read_servers(int num_serv) throws java.io.IOException{  
     int i;
     String temp;
     int temp2;
     
     servers = new ServerStatus[num_serv];

     for(i=0;i<num_serv;i++) {
       servers[i] = new ServerStatus();
       servers[i].desc = str.get_string();
       if(servers[i].desc.length() > longest_hostname)
         longest_hostname = servers[i].desc.length();
       servers[i].ip_addr = str.read_IPaddr();
       str.server_in.readInt();
       str.server_in.readInt();
       servers[i].host_status = str.server_in.readInt();
       servers[i].server_status = str.server_in.readInt();
       str.server_in.readInt();
       str.server_in.readInt();
       str.server_in.readInt();
       servers[i].number_problems = str.server_in.readInt();
     }
  }

  private String right_just(String str, int length) {
    if(str.length() > length)
      return(str);
    else
      return(blank_string.substring(0,length - str.length()) + str);
  }

  public String status_string() {
    StringBuffer temp = new StringBuffer(700);
    int i;

    temp.append(right_just("Machine Name",longest_hostname));
    temp.append(right_just("IP address",IP_ADDR_FIELD_WIDTH));
    temp.append(right_just("Host Status",HOST_STATUS_FIELD_WIDTH));
    temp.append(right_just("Server Status",SERVER_STATUS_FIELD_WIDTH));
    temp.append(right_just("Problems",PROBLEMS_FIELD_WIDTH) + "\n");

    temp.append(right_just("~~~~~~~~~~~~",longest_hostname));
    temp.append(right_just("~~~~~~~~~~",IP_ADDR_FIELD_WIDTH));
    temp.append(right_just("~~~~~~~~~~~",HOST_STATUS_FIELD_WIDTH));
    temp.append(right_just("~~~~~~~~~~~~~",SERVER_STATUS_FIELD_WIDTH));
    temp.append(right_just("~~~~~~~~",PROBLEMS_FIELD_WIDTH) + "\n");

    for(i=0;i<servers.length;i++) {
      temp.append(right_just(servers[i].desc,longest_hostname));
      temp.append(right_just(
            (long)  ((servers[i].ip_addr >> 24) & 0xFF) + "." +
                    ((servers[i].ip_addr >> 16) & 0xFF) + "." +
                    ((servers[i].ip_addr >>  8) & 0xFF) + "." +
                     (servers[i].ip_addr & 0xFF),IP_ADDR_FIELD_WIDTH));
      switch(servers[i].host_status) {
        case 0:
          temp.append(right_just("DOWN",HOST_STATUS_FIELD_WIDTH));
          break;
        case 1:
          temp.append(right_just("UP",HOST_STATUS_FIELD_WIDTH));
          break;
        default:
          temp.append(right_just("UNKNOWN",HOST_STATUS_FIELD_WIDTH));
      }
      switch(servers[i].server_status) {
        case 1:
          temp.append(right_just("RUNNING",SERVER_STATUS_FIELD_WIDTH));
          break;
        case 0:
          temp.append(right_just("STOPPED",SERVER_STATUS_FIELD_WIDTH));
          break;
        case -2:
          temp.append(right_just("FAILED",SERVER_STATUS_FIELD_WIDTH));
          break;
        default:
          temp.append(right_just("UNKNOWN",SERVER_STATUS_FIELD_WIDTH));
      }
      if(servers[i].number_problems == 0)
        temp.append(right_just("Agent",PROBLEMS_FIELD_WIDTH) + "\n");
      else
        temp.append( right_just(
           new Integer(servers[i].number_problems).toString(),PROBLEMS_FIELD_WIDTH) 
           + "\n");
    }
    return(temp.toString());
  }

  private void sort_servers() {
    int j, k, min_index, min_ip, cur_ip;
 
    for (k=0;k<servers.length;k++) {
      min_index=k;
      min_ip = servers[k].ip_addr;
  
      for(j = k+1;j<servers.length;j++) {
        cur_ip = servers[j].ip_addr;

        if(min_ip > cur_ip)
//        if((min_ip & 0xFF) > (cur_ip & 0xFF))
        {
          min_ip = cur_ip;
          min_index = j;
        }
      }
      swap(servers,k,min_index);
    }

  }

  private void swap(ServerStatus serv[], int x, int y) {
    ServerStatus temp = serv[x];
    serv[x] = serv[y];
    serv[y] = temp;
  }

  GetServers(String hostname) throws NetSolveException {
    short encoding;
    int num_servers;

    try {
      try {
        // always XDR
        str = new MyStream(hostname,AG_PORT,DATA_XDR);
      }
      catch(IOException e) {
        System.out.println("Could not connect to server: "+e);
        throw new NetSolveException(e.getMessage());
      }

     System.out.println("Sending some data to the server..");
     str.server_out.writeInt(POLL_LIST_SV); // send request
     str.server_out.writeInt(DETAIL);       // send detail
     System.out.println("...done.");

     System.out.println("Response from server:");
     encoding = str.server_in.readShort();
     str.init_recv(encoding);
     System.out.println("encoding = " + encoding);

     num_servers = str.server_in.readInt();
     System.out.println("num_servers = " + num_servers);

     read_servers(num_servers);

     System.out.println("Sorting...");
     sort_servers();

     System.out.println("done.");
    }
    catch(IOException e) {
      System.out.println("Data transfer error: "+e);
      throw new NetSolveException(e.getMessage());
    }
    finally {
      try { 
        if (str != null)  
          if (str.s != null) 
            str.shut_down(); 
      }
      catch (IOException e2) { ; }
    }
  }
}
