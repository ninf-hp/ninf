#define _WRAPPER_
/* $Id: pcgetrf_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define SCOMPLEX
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n
void  pcgetrf_ninf(	 int m,
		 int n,
		 scomplex global_a[],
		 int lda,
		 int global_ipiv[],
		 int *info
)
/* "pcgetrf computes an LU factorization of a general M-by-N distributed matrix A using partial pivoting with row interchanges. The factorization has the form A = P * L * U, where P is a permutation matrix, L is lower triangular with unit diagonal elements (lower trapezoidal if m > n), and U is upper triangular (upper trapezoidal if m < n). L and U are stored in A." */
/* OPTIONS */
{
    extern void FortranCall(pcgetrf)( int*, int*,
				      scomplex*, int*, int*, int*,
				      int*,
				      int*);
	int maxldd;

	int maxlda;
	scomplex *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
	int row_loca;
	int col_loca;

	int *locipiv=NULL;
	
	INITIALIZE();

	SCALAR( "int", m);
	SCALAR( "int", n);
	SCALAR( "int", lda);

	ROW( a);
	COL( a);
	MAXLDD( maxldd, a );
	maxlda = maxldd;
	MATRIX( "scomplex", a, ROW_a, COL_a);
	DISTRIBUTE( "scomplex", a, ROW_a  , COL_a);
	VECTOR("r", "int", ipiv, min(ROW_a,m));
	
	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pcgetrf)( &m, &n,
                               loca, &one, &one, desca,
                               locipiv,
                               &linfo);

	GATHER( "scomplex", a, ROW_a  , COL_a);
	vGATHER( "r", "int", ipiv, min(ROW_a,m));
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
		*info = linfo;
	} else {
	}

	FREE_MATRIX(a);
	FREE_VECTOR(ipiv);

	
}

