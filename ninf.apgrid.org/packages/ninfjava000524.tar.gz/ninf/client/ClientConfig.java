package ninf.client;
import ninf.basic.*;
import java.util.*;

public class ClientConfig implements Cloneable {
  static final int NINF_SHELL_STREAM   = 2;
  static final int NINF_SHELL_CALLBACK = 1;
  static final int NINF_SHELL_NO       = 0;

  static final int DEFAULT_PORT         = 3000;
  static final String DEFAULT_SHELL_COMMAND = "/usr/bin/ssh -x";

  String server = null;
  int    port = DEFAULT_PORT;
    
  String shell_command;
  String proxy_command = "ninf_ssh_proxy";
  int    shell_mode    = NINF_SHELL_NO;
  int    callback_port = 0;
  int    callback_try  = 4;

  public ClientConfig(){
    shell_command = System.getProperty("NINF_SHELL_COMMAND");
    if (shell_command == null) 
      shell_command = DEFAULT_SHELL_COMMAND;
  }

  public ClientConfig(String server, int port){
    this();
    this.server = server;
    this.port   = port;
  }

  public void setServerPort(String server, int port){
    this.server = server;
    this.port   = port;
  }

  public void setShellMode(int i){
    shell_mode = i;
  }

  NinfServerStruct getStruct(){
      return new NinfServerStruct(server, port);
  }

  ClientConfig copy(){
      try {
	 return (ClientConfig)(this.clone());
      } catch (CloneNotSupportedException e){
      }
      return null;
  }


  public String[] parseArg(String arg[]){
    Vector tmpV = new Vector();
    int index = 0;
    for (int i = 0; i < arg.length; i++){
      if (arg[i].equalsIgnoreCase("-server"))
	server = arg[++i];
      else if (arg[i].equalsIgnoreCase("-port"))
	port = Integer.valueOf(arg[++i]).intValue();
      else if (arg[i].equalsIgnoreCase("-debug"))
	NinfLog.verbose();
      else if (arg[i].equalsIgnoreCase("-quiet"))
	NinfLog.quiet();
      else if (arg[i].equalsIgnoreCase("-shell"))
	shell_mode = NINF_SHELL_STREAM;
      else if (arg[i].equalsIgnoreCase("-shell_stream"))
	shell_mode = NINF_SHELL_STREAM;
      else if (arg[i].equalsIgnoreCase("-shell_callback"))
	shell_mode = NINF_SHELL_CALLBACK;
      else if (arg[i].equalsIgnoreCase("-callback_port"))
	callback_port = Integer.valueOf(arg[++i]).intValue();
      else 
	tmpV.addElement(arg[i]);
    }
    String tmp[] = new String[tmpV.size()];
    for (int i = 0; i < tmpV.size(); i++)
      tmp[i] = (String)(tmpV.elementAt(i));
    return tmp;
  }
  


}
