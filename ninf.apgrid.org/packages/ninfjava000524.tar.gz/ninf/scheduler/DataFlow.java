package ninf.scheduler;
import ninf.basic.*;
import ninf.client.*;
import ninf.metaserver.*;
import ninf.cproxy.aggregate.*;
import java.util.Vector;

public class DataFlow{

  public ServerID cproxy;
  public FuncNode source, sink;
  public FuncNode funcNodes[];
  public DataNode dataNodes[];
  static NinfLog dbg = new NinfLog("DataFlow");
  public Vector pathes;

  public DataFlow(ServerID cproxy, FuncNode funcNodes[], DataNode dataNodes[],
		  DirectoryService service, NinfServerStruct[] servers)
  throws NinfException{
    this.cproxy    = cproxy;
    this.funcNodes = funcNodes;
    this.dataNodes = dataNodes;
    source = new FuncNode();
    sink = new FuncNode();
    for (int i = 0; i < dataNodes.length; i++)
      dataNodes[i].makeLink(funcNodes, source, sink);
    makePathes();
    setServerIndexes(service, servers);
    
    dbg.println(this);
  }

  private ServerIndex[] getServerIndex(FuncNode funcNode, 
				     DirectoryService service,
				     NinfServerStruct servers[])
  throws NinfException{
    Vector v = new Vector();
    for (int i = 0; i < servers.length; i++){
      ServerIndex serverIndex = 
	service.getServerIndex(funcNode.name, servers[i]);
      if (serverIndex != null)
	v.addElement(serverIndex);
    }
    ServerIndex[] tmp = new ServerIndex[v.size()];
    for (int i = 0; i < v.size(); i++)
      tmp[i] = (ServerIndex)v.elementAt(i);
    return tmp;
  }

  void setServerIndexes(DirectoryService service, NinfServerStruct[] servers)
    throws NinfException{
    for (int i = 0; i < funcNodes.length; i++)
      funcNodes[i].serverIndexes = getServerIndex(funcNodes[i], service, servers);

  }

  void makePathesData(FlowPath path, DataNode dataNode, Vector v){
    System.err.println(dataNode);
    path.addDataNode(dataNode);
    for (int i = 0; i < dataNode.lowerFuncs.length; i++){
      FlowPath local = (FlowPath)path.clone();
      makePathesFunc(local, dataNode.lowerFuncs[i], v);
    }
  }

  void makePathesFunc(FlowPath path, FuncNode funcNode, Vector v){
    System.err.println(funcNode);
    path.addFuncNode(funcNode);
    if (funcNode == sink){
      v.addElement(path);
      return;
    }      
    for (int i = 0; i < funcNode.lowerData.length; i++){
      FlowPath local = (FlowPath)path.clone();
      makePathesData(local, funcNode.lowerData[i], v);
    }
  }

  public Vector makePathes(){
    Vector tmp = new Vector();
    makePathesFunc(new FlowPath(), source, tmp);
    pathes = tmp;

    for (int i = 0; i < dataNodes.length; i++)
      if (dataNodes[i].noFrom() || dataNodes[i].noTo() )
	dataNodes[i].location = cproxy;

    source.serverIndex = new ServerIndex(cproxy, -1);
    sink.  serverIndex = new ServerIndex(cproxy, -1);

    return tmp;
  }

  public String toString(){
    String tmp = "DataFlow\n";
    for (int i = 0; i < pathes.size(); i++){
      tmp += pathes.elementAt(i) + "\n";
    }
    return tmp;
  }

}
