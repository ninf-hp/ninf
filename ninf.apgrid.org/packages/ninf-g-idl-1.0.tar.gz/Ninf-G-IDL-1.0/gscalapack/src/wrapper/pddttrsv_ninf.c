#define _WRAPPER_
/* $Id: pddttrsv_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define _DISTRIBUTE_1D_
#define DOUBLE
#include <gscalapack.h>

#define ROW_b n
#define COL_b nrhs
#define ROW_af laf
#define COL_af n
static	int worklen(int nrhs) {
	  int ret=1;
	  ret = 10+4*nrhs;
	  if NEED_BUFF ret = 10*npcol+4*nrhs;
          return ret;
}

void  pddttrsv_ninf(	 char uplo,
			 char trans,
			 int n,
			 int nrhs,
			 double global_dl[],
			 double global_d[],
			 double global_du[],
			 double global_b[],
			 double af[],
			 int dummy_laf,
			 double  work[],
			 int lwork,
			 int *info
)
/* "pddttrsv solves a tridiagonal triangular system of linear equations A * X = B or A^T * X = B where A is a tridiagonal triangular matrix factor produced by the Gaussian elimination code psttrf and is stored in A and AF." */
/* OPTIONS */
{
    extern void FortranCall(pddttrsv)( char*, char*, int*, int*,
                                double*, double*, double*, int*, int*,
                                double*, int*, int*,
                                double*, int*,
                                double*, int*, int*);

	int maxldd;

	double *locdl=NULL, *locd=NULL, *locdu=NULL;
	int desctdd[DESCLEN];
	int desc_gtdd[DESCLEN];

	int maxldb;
	double *locb=NULL;
	int descb[DESCLEN];
	int desc_gb[DESCLEN];
	int row_locb, col_locb;

	double *locaf=NULL, *global_af=NULL;
	int maxldaf;
	int descaf[DESCLEN];
	int desc_gaf[DESCLEN];
	int laf, llocaf;
	int row_locaf, col_locaf;

	double *locwork=NULL;
	int llocwork;

	INITIALIZE();

	SCALAR( "char", uplo);
	SCALAR( "char", trans);
	SCALAR( "int", n);
	SCALAR( "int", nrhs);
	SCALAR("int", dummy_laf);
	SCALAR( "int", lwork);

	SIZE(n);

	laf = 2*(blocsize+2)*nprocs/n;
	llocaf = laf*blocsize;
	if (mypnum==0) {
	  global_af=MALLOC(sizeof(double)*laf*n);
          assert(global_af);
	}

	ROW(b);
	COL(b);
	ROW(af);
	COL(af);
	MAXLDD( maxldd, b);
	maxldb = maxldd;
	maxldaf = maxldd;

	tdMATRIX( "double", dl, d, du, n);
	MATRIX(  "double", b, ROW_b, COL_b);
	MATRIX( "double",  af, ROW_af, COL_af);
	tdDISTRIBUTE( "double", dl, d, du, n);
	DISTRIBUTE( "double", af, ROW_af, COL_af);

	llocwork=worklen(nrhs);
	WORK(locwork,llocwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pddttrsv)( &uplo, &trans, &n, &nrhs,
                                locdl, locd, locdu, &one, desctdd,
                                locb, &one, descb,
                                locaf, &llocaf,
                                locwork, &llocwork, &linfo);

	tdGATHER( "double", dl, d, du, n);
	GATHER( "double", b, ROW_b, COL_b);
	GATHER( "double", af, ROW_af, COL_af);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
	  int i;
	  *info = linfo;
	  for(i=0;i<dummy_laf;i++) af[i]=global_af[i];
          FREE(global_af);
	} else {
	}
	FREE_MATRIX(dl);
	FREE_MATRIX(d);
	FREE_MATRIX(du);
	FREE_MATRIX(b);
	FREE_MATRIX(af);
        FREE(locwork);
	
}

