#define _WRAPPER_
/* $Id: pdsygvx_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define DOUBLE
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n
#define ROW_b ldb
#define COL_b n
#define ROW_z ldz
#define COL_z n
static	int worklen(int n) {
	  int ret=1;
	  int MNB, NN, NP0, MQ0, NEIG;
          ret = 5*n+max(5*n,n*n+2*n*n)+n*n;
	  if NEED_BUFF {
	    NEIG = n;
	    MNB = max(rbloc,cbloc);
	    NN = MAX( N, max(MNB, 2) );
	    NP0 = NUMROC( NN, MNB, 0, 0, NPROW );
	    MQ0 = NUMROC( MAX( NEIG, max(MNB, 2) ), MNB, 0, 0, NPCOL );
	    ret = 5 * N + MAX( 5*NN, NP0 * MQ0 + 2 * MNB * MNB ) +
	      CEIL( NEIG, NPROW*NPCOL)*NN;
	  }
	  ret += max((n-1)*n,1);
	  return ret;
}

static	int iworklen(int n) {
	  int ret=1;
	  int NNP;
          ret = 6*max(n,4);
	  if NEED_BUFF {
	    NNP = MAX( N, max(NPROW*NPCOL + 1, 4) );
	    ret = 6*NNP;
	  }
	  return ret;
}

void  pdsygvx_ninf(	 int ibtype,
		 char jobz,
		 char range,
		 char uplo,
		 int n,
		 double global_a[],
		 int lda,
		 double global_b[],
		 int ldb,
		 double vl,
		 double vu,
		 int il,
		 int iu,
		 double abstol,
		 int *m,
		 double w[],
		 double global_z[],
		 int ldz,
		 double work[],
		 int lwork,
		 int iwork[],
		 int liwork,
		 int ifail[],
		 double orfac,
		 int *info
)
/* "pdsygvx computes all the eigenvalues, and optionally, the eigenvectors of a real generalized SY-definite eigenproblem, of the form A * x=(lambda)* B * x,   A* B x=(lambda)*x,  or  B * A *x=(lambda)*x." */
/* OPTIONS */
{
    extern void	FortranCall(pdsygvx)( int*, char*, char*, char*, int*,
			       double*, int*, int*, int*,
			       double*, int*, int*, int*,
			       double*, double*, int*, int*,
			       double*, int*, int*, double*, double*,
			       double*, int*, int*, int*,
			       double*, int*,
				      int*, int*,
			       int*, int*, double*,
			       int*);

	int maxldd;

	int maxlda;
	double *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
	int row_loca, col_loca;

	int maxldb;
	double *locb=NULL;
	int descb[DESCLEN];
	int desc_gb[DESCLEN];
	int row_locb, col_locb;

	int maxldz;
	double *locz=NULL;
	int descz[DESCLEN];
	int desc_gz[DESCLEN];
	int row_locz, col_locz;

	int locnz[1],locm[1];

	int *iclustr=NULL;
	double *gap=NULL;

	double *locw=NULL;
	int *lifail=NULL;

	double *locwork=NULL;
	int llocwork;
	int *lociwork=NULL;
	int llociwork;


	INITIALIZE();

	SCALAR( "int", ibtype);
	SCALAR( "char", jobz);
	SCALAR( "char", range);
	SCALAR( "char", uplo);
	SCALAR( "int", n);
	SCALAR( "double", vl);
	SCALAR( "double" , vu);
	SCALAR( "int", il);
	SCALAR( "int" , iu);
	SCALAR("double", abstol);
	SCALAR( "double", orfac);
	SCALAR( "int", lda);
	SCALAR( "int", ldb);
	SCALAR( "int", ldz);
        SCALAR( "int", lwork);
        SCALAR( "int", liwork);

	ROW( a);
	COL( a);
	ROW( b);
	COL( b);
	ROW( z);
	COL( z);
	MAXLDD( maxldd, a );
	maxlda = maxldd;
	maxldb = maxldd;
	maxldz = maxldd;

	trMATRIX( uplo, "double", a, ROW_a, COL_a);
	trDISTRIBUTE( uplo, "double", a, ROW_a, COL_a);
	MATRIX( "double", b, ROW_b, COL_b);
	DISTRIBUTE( "double", b, ROW_b  , COL_b);
	MATRIX( "double", z, ROW_z, COL_z);

	llocwork=worklen(n);
	llocwork=max(llocwork,lwork);
	WORK(locwork,llocwork);
	llociwork=iworklen(n);
	llociwork = max( llociwork, liwork);
	IWORK(lociwork,llociwork);

	gap = MALLOC(sizeof(double)*nprow*npcol); assert(gap);
	iclustr = MALLOC(sizeof(int)*2*nprow*npcol); assert(iclustr);
	lifail = MALLOC(sizeof(int)*n); assert(lifail);
	locw = MALLOC(sizeof(double)*n); assert(locw);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pdsygvx)( &ibtype, &jobz, &range, &uplo, &n,
			       loca, &one, &one, desca,
			       locb, &one, &one, descb,
			       &vl, &vu, &il, &iu,
			       &abstol, locm, locnz, locw, &orfac,
			       locz, &one, &one, descz,
			       locwork, &llocwork, lociwork, &llociwork,
			       lifail, iclustr, gap,
			       &linfo);

	GATHER( "double", a, ROW_a, COL_a);
	GATHER( "double", b, ROW_b, COL_b);
	GATHER( "double", z, ROW_z, COL_z);

	RETRIEVE("double", locw, n);
	RETRIEVE("int", lifail, n);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
	  int i;
	  *info = linfo;
	  for(i=0;i<n;i++) ifail[i] = lifail[i];
	  for(i=0;i<n;i++) w[i] = locw[i];
	  *m = locm[1];
	} else {
		
	}

	FREE_MATRIX(a);
	FREE_MATRIX(b);
	FREE_MATRIX(z);
	FREE(locwork);
        FREE(lociwork);
        FREE(gap);
        FREE(iclustr);
        FREE(locw);
        FREE(lifail);
}

