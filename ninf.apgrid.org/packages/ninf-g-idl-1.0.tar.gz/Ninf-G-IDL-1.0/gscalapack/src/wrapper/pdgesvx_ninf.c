#define _WRAPPER_
/* $Id: pdgesvx_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define DOUBLE
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n
#define ROW_af ldaf
#define COL_af n
#define ROW_b ldb
#define COL_b nrhs
#define ROW_x ldx
#define COL_x nrhs
#define LOCc_a(n) Cnumroc( (n), cbloc, mypcol, 0, npcol)
#define LOCr_a(m) Cnumroc( (m), rbloc, myprow, 0, nprow)
static        int worklen(int n) {
	  int psgecon, psgerfs;
            int ret = 1;
            psgecon = 4*n+max(2,n);
            psgerfs = 3*n;
            ret = max(psgecon,psgerfs) + n;
            if NEED_BUFF {
	      psgecon =  2*LOCr(N+MOD(IA-1,MB_A)) + 2*LOCc(N+MOD(JA-1,NB_A))
		+ MAX( 2, MAX( NB_A*MAX( 1, CEIL(NPROW-1,NPCOL) ),
			       LOCc(N+MOD(JA-1,NB_A)) +
                NB_A*MAX( 1, CEIL(NPCOL-1,NPROW) ) ));
	      psgerfs = 3*LOCr( N + MOD(IA-1,MB_A) );
	      ret = max( psgecon, psgerfs ) + LOCr_a( COL_a );
	    }
            return ret;
}

static        int iworklen(int n) {
            int ret = 1;
            ret = COL_a;
            if NEED_BUFF ret = LOCr(COL_a);
            return ret;
}

void  pdgesvx_ninf(	 char fact,
		 char trans,
		 int n,
		 int nrhs,
		 double global_a[],
		 int lda,
		 double global_af[],
		 int ldaf,
		 int global_ipiv[],
		 char *equed,
		 double global_r[],
		 double global_c[],
		 double global_b[],
		 int ldb,
		 double global_x[],
		 int ldx,
		 double *rcond,
		 double global_ferr[],
		 double global_berr[],
		 double work[],
		 int iwork[],
		 int *info
)
/* "pdgesvx uses the LU factorization to compute the solution to a real system of linear equations A * X = B, where A is an N-by-N matrix and X and B are N-by-NRHS matrices." */
/* OPTIONS */
{
    extern void FortranCall(pdgesvx)( char*, char*, int*, int*,
			       double*, int*, int*, int*,
			       double*, int*, int*, int*,
			       int*,
			       char*,
			       double*, double*,
			       double*, int*, int*, int*,
			       double*, int*, int*, int*,
			       double*, double*, double*,
			       double*, int*,
			       int*, int*,
			       int*);

	int maxldd;

	int maxlda;
	double *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];

	int maxldaf;
	double *locaf=NULL;
	int descaf[DESCLEN];
	int desc_gaf[DESCLEN];

	int *locipiv=NULL;

	double locrcond[1];

	double *locr=NULL;
	double *locc=NULL;

	int maxldb;
	double *locb=NULL;
	int descb[DESCLEN];
	int desc_gb[DESCLEN];

	int maxldx;
	double *locx=NULL;
	int descx[DESCLEN];
	int desc_gx[DESCLEN];

	double *locferr=NULL;
	double *locberr=NULL;

        double *locwork=NULL;
        int llocwork;
        int *lociwork=NULL;
        int llociwork;

	int row_loca, col_loca;
	int row_locaf, col_locaf;
	int row_locb, col_locb;
	int row_locx, col_locx;

        
	INITIALIZE();

	SCALAR( "char", fact);
	SCALAR( "char", trans);
	SCALAR( "int", n);
	SCALAR( "int", nrhs);
	SCALAR( "int", lda);
	SCALAR( "int", ldb);
	SCALAR( "int", ldaf);
	SCALAR( "int", ldx);

	COMMON( "char", equed, 1);

	ROW( a);
	COL( a);
	ROW( af);
	COL( af);
	ROW( b);
	COL( b);
	ROW( x);
	COL( x);
	MAXLDD( maxldd, a );
	maxlda = maxldd;
	maxldaf = maxldd;
	maxldb = maxldd;
	maxldx = maxldd;

	MATRIX( "double", a, ROW_a, COL_a);
	MATRIX( "double", af, ROW_af, COL_af);
	MATRIX( "double", b, ROW_b, COL_b);
	MATRIX( "double", x, ROW_x, COL_x);
	VECTOR( "r", "int", ipiv, ROW_a);
        VECTOR( "r", "double", r, ROW_a);
        VECTOR( "c", "double", c, COL_a);
        VECTOR( "c", "double", ferr, COL_b);
        VECTOR( "c", "double", berr, COL_b);

	DISTRIBUTE( "double", a, ROW_a  , COL_a);
	DISTRIBUTE( "double", af, ROW_af  , COL_af);
	DISTRIBUTE( "double", b, ROW_b  , COL_b);
	vDISTRIBUTE( "r", "int", ipiv, ROW_a);
	vDISTRIBUTE( "r", "double", r, ROW_a);
	vDISTRIBUTE( "c", "double", c, COL_a);

        llocwork=worklen(n);
        WORK( locwork, llocwork);
        llociwork=iworklen(n);
        IWORK( lociwork, llociwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pdgesvx)( &fact, &trans, &n, &nrhs,
			       loca, &one, &one, desca,
			       locaf, &one, &one, descaf,
			       locipiv,
			       equed,
			       locr, locc,
			       locb, &one, &one, descb,
			       locx, &one, &one, descx,
			       locrcond, locferr, locberr,
			       locwork, &llocwork,
			       lociwork, &llociwork,
			       &linfo);

	GATHER( "double", a, ROW_a  , COL_a);
	GATHER( "double", af, ROW_af  , COL_af);
	GATHER( "double", b, ROW_b  , COL_b);
	GATHER( "double", x, ROW_x  , COL_x);

        vGATHER( "r", "double", r, ROW_a);
        vGATHER( "c", "double", c, COL_a);
	vGATHER( "c", "double", ferr, COL_b);
	vGATHER( "c", "double", berr, COL_b);
        
	RETRIEVE( "char", equed, 1);
	RETRIEVE( "double", locrcond, 1);

	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
	  *info = linfo;
	  *rcond = *locrcond;
	} else {
	}

	FREE_COMMON(equed);
	FREE_MATRIX(a);
	FREE_MATRIX(af);
	FREE_VECTOR(ipiv);
	FREE_VECTOR(r);
	FREE_VECTOR(c);
	FREE_VECTOR(ferr);
	FREE_VECTOR(berr);
	FREE_MATRIX(b);
	FREE_MATRIX(x);
	FREE(locwork);
        FREE(lociwork);
}

