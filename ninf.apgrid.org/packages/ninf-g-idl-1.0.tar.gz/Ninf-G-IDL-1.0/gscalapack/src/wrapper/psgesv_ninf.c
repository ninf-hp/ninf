#define _WRAPPER_
/* $Id: psgesv_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define FLOAT
#include <gscalapack.h>


#define ROW_a lda
#define COL_a n
#define ROW_b ldb
#define COL_b nrhs
void  psgesv_ninf(	 int n,
		 int nrhs,
		 float global_a[],
		 int lda,
		 int global_ipiv[],
		 float global_b[],
		 int ldb,
		 int *info
)
/* "psgesv computes the solution to a real system of linear equations  A * X =  B , where A is an N-by-N distributed matrix and X and  B are N-by-NRHS distributed matrices." */
/* OPTIONS */
{
    extern void FortranCall(psgesv)( int*, int*,
				     float*, int*, int*, int*,
				     int*,
				     float*, int*, int*, int*,
				     int*);

	int maxldd;

	int maxlda;
	float *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];

	int maxldb;
	float *locb=NULL;
	int descb[DESCLEN];
	int desc_gb[DESCLEN];

        int *locipiv;
	
	int row_loca;
	int col_loca;
	int row_locb;
	int col_locb;

	INITIALIZE();

	SCALAR( "int", n);
	SCALAR( "int", nrhs);
	SCALAR( "int", lda);
	SCALAR( "int", ldb);

	ROW( a);
	COL( a);
	ROW( b);
	COL( b);
	MAXLDD( maxldd, a );
	maxlda = maxldd;
	maxldb = maxldd;

	MATRIX( "float", a, ROW_a, COL_a);
	MATRIX( "float", b, ROW_b, COL_b);
	VECTOR( "r", "int", ipiv, ROW_a);

	DISTRIBUTE( "float", a, ROW_a  , COL_a);
	DISTRIBUTE( "float", b, ROW_b  , COL_b);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(psgesv)( &n, &nrhs,
                              loca, &one, &one, desca,
                              locipiv,
                              locb, &one, &one, descb,
                              &linfo);

	GATHER( "float", a, ROW_a  , COL_a);
	GATHER( "float", b, ROW_b  , COL_b);
	vGATHER( "r", "int", ipiv, ROW_a);

	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
		*info = linfo;
	} else {
	}
	
	FREE_MATRIX(a);
	FREE_MATRIX(b);
	FREE_VECTOR(ipiv);

}

