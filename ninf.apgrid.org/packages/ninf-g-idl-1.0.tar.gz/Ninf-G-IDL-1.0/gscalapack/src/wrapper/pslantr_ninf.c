#define _WRAPPER_
/* $Id: pslantr_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define FLOAT
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n
static	int worklen(char norm, int m, int n) {
	  int ret=1;
	  int IROFFA, ICOFFA, IAROW, IACOL, Mp0, Nq0;
	    if ((norm=='1') || (chrcmp(norm,'O')==0))
	      ret = n;
	    if (chrcmp(norm,'I')==0)
	      ret = m;
	  if NEED_BUFF {
	    IROFFA = MOD( IA-1, MB_A );
	    ICOFFA = MOD( JA-1, NB_A );
	    IAROW = INDXG2P( IA, MB_A, MYROW, RSRC_A, NPROW );
	    IACOL = INDXG2P( JA, NB_A, MYCOL, CSRC_A, NPCOL );
	    Mp0 = NUMROC( M+IROFFA, MB_A, MYROW, IAROW, NPROW );
	    Nq0 = NUMROC( N+ICOFFA, NB_A, MYCOL, IACOL, NPCOL );
	    if ((norm=='1') || (chrcmp(norm,'O')==0))
	      ret = Nq0;
	    if (chrcmp(norm,'I')==0)
	      ret = Mp0;
	  }
	  return ret;
}


void  pslantr_ninf(	 char norm,
		 char uplo,
		 char diag,
		 int m,
		 int n,
		 float global_a[],
		 int lda,
		 float work[],
                         float *ret /* return value */
)
/* "pslantr returns the value of the one norm, or the Frobenius norm, or the infinity norm, or the element of largest absolute value of a trapezoidal or triangular distributed matrix A." */
/* OPTIONS */
{

  extern float FortranCall(pslantr)(char*, char*, char*, int *, int *, float *, int *, int *, int *, float *);

	int maxldd;

	int maxlda;
	float *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
	int row_loca, col_loca;

	float *locwork=NULL;
	int llocwork;

	float locpslantr_[1];

	INITIALIZE();

	SCALAR( "char", norm);
	SCALAR( "char", uplo);
	SCALAR( "char", diag);
	SCALAR( "int", m);
	SCALAR( "int", n);
	SCALAR( "int", lda);

	ROW( a);
	COL( a);
	MAXLDD( maxldd, a );
	maxlda = maxldd;

	MATRIX( "float", a, ROW_a, COL_a);
	DISTRIBUTE( "float", a, ROW_a  , COL_a);

	llocwork = worklen(norm, m, n);
	WORK(locwork, llocwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranReturnSimple(pslantr,locpslantr_,
                      ( &norm, &uplo, &diag,
                       &m, &n,
                       loca, &one, &one, desca,
                       locwork ) );

	RETRIEVE("float", locpslantr_, 1);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
            *ret = *locpslantr_;
	} else {
	}

	FREE_MATRIX(a);
        FREE(locwork);
	
}

