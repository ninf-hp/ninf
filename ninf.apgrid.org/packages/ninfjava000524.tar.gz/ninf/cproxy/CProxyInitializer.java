package ninf.cproxy;
import ninf.basic.NinfException;

public interface CProxyInitializer{
  public void init(CProxyConfig conf) throws NinfException;
}
