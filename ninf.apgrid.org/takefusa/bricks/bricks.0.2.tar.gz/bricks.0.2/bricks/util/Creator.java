package bricks.util;

public interface Creator {
    public String usage();
}
