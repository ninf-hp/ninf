package ninf.netsolve;

import  java.io.*;
import  java.net.*;
import  java.util.Vector;
import  ninf.basic.*;
import  ninf.client.*;
import  ninf.MetaServer.*;

/**   Adapter for Ninf Server.
      Act as a Netsolve Server and gateway for the NinfServer */

public class NinfAdapter extends MetaServer {
  String agent;
  ServerInfo myself;



  void setMyself() {
    System.out.println("setting myself");
    try {
      //      myname = (new DataInputStream(Runtime.getRuntime().exec("hostname").getInputStream())).readLine();
      //      InetAddress localaddr = InetAddress.getByName(myname);

      InetAddress localaddr = InetAddress.getLocalHost();
      myname = localaddr.getHostName();
      System.out.println("myname is " + myname);

      byte tmpIp[] = localaddr.getAddress();
      
      myself = new ServerInfo();
      myself.name = myname;
      
      myself.ip_addr = tmpIp;
      myself.number_proc = 1;
    } catch (Exception e){
      e.printStackTrace();
    }
  }


  /* introduce myself to NetSolve Agent */
  void introduceMySelf(XDROutputStream os) throws IOException, NinfException{
    os.writeInt(GlobalDefs.I_AM_NEW);
    
    myself.writeTo(os);
    
    Problem probs[] = getProblems();

    System.out.println("sending problems");
    os.writeInt(probs.length);
    for (int j = 0; j<probs.length;j++){
      probs[j].write(os);
      System.out.println("send "+ j + " problem" );
    }
  }


  void introduceToAgent() throws IOException, ConfigurationException, NinfException{
    System.out.println("connecting to agent: "+ agent + "," + GlobalDefs.AG_PORT);

    Socket s = new Socket(agent, GlobalDefs.AG_PORT);
    XDRInputStream  is = new XDRInputStream(s.getInputStream());
    XDROutputStream os = new XDROutputStream(s.getOutputStream());

    System.out.println("introducing to agent");

    os.writeChar(GlobalDefs.DATA_XDR);
    
    introduceMySelf(os);

    System.out.println("waiting for agent reply");
    
    int mode = is.readChar();
    int response = is.readInt();
    System.out.println("got reply " + response);
    switch (response){
    case GlobalDefs.WRONG_PROBLEM:
      int nBadProblems = is.readInt();
      System.err.println("Following " + nBadProblems + " problem(s) have the same name in Agent, but has different arguments");
      for (int i = 0; i < nBadProblems; i++){
	//		Problem tmp = Problem.readProblem(is);
	System.err.println("----------------------");
	//	System.err.println(tmp);
	System.err.println("----------------------");
      }
      throw new ConfigurationException();
    case GlobalDefs.SV_FAILURE: /* The master has failed !!! */
      System.err.println("The master "+ agent + "failed");
      System.err.println("Sorry, impossible to check in");
      throw new ConfigurationException();
    case GlobalDefs.YOU_ARE_NEW:
      System.err.println("I successfully checked in");
      break;
    default:
      System.err.println("Unknown response from agent: " + response);
      throw new ConfigurationException();
    }
    getAllStruct(is); 


    /* Get the answer */
    /* BEGINNING OF A RECEIVE PHASE */

  }

  Problem[] getProblems(){
    Vector tmp = funcManager.getFunctions();
    Problem ans[] = new Problem[tmp.size()];
    for (int i = 0; i < tmp.size(); i++)
      ans[i] = ((AdapterFunctionStruct)(tmp.elementAt(i))).problem;
    return ans;
  }

  void getAllStruct(XDRInputStream is) throws NinfException{
    System.err.println("getting all struct");
    int nb_problem = 0;
    try {

      System.err.println("getting problems");
      nb_problem  = is.readInt();
      System.err.println("getting " + nb_problem + " problems");
      Problem problems[] = new Problem[nb_problem];
      for (int i = 0; i < nb_problem; i++)
	problems[i] = Problem.read(is);
      

      System.err.println("getting servers");
      int nb_server = is.readInt();
      System.err.println("getting " + nb_server + " servers");
      ServerInfo servers[] = new ServerInfo[nb_server];
      for (int i = 0; i < nb_server; i++)
	servers[i] = ServerInfo.readFull(is);
    } catch (IOException e){
      throw new NinfIOException();
    }
    System.err.println("got all struct");
  }


  public void setEnvironment(MetaServerConfig cnf) {
    if (cnf.logfile != null) {
      try {
	NinfLog.changeOutput(cnf.logfile);
      } catch(NinfIOException e) {
	System.err.println("Can't open logfile : " + cnf.logfile);
      }
    } else {
//      NinfLog.quiet();
    }
    try {
      for (int i = 0; i < cnf.servers.size(); i++)
	registerServer((String)cnf.servers.elementAt(i));
      agent = cnf.agent;
      introduceToAgent();      
    } catch (Exception e){e.printStackTrace();}
  }

  boolean processProblemSolve(XDRInputStream is, XDROutputStream os) throws IOException, NinfException{
    Problem tmpProb = Problem.readPartial(is);
    CallableStruct tmpFunction = funcManager.getFunction(tmpProb.name);
    dbg.println("tmpFunction = " + tmpFunction);
    Problem prob = ((AdapterFunctionStruct)tmpFunction).problem;

    dbg.println("client problem = \n" + tmpProb);
    
    if (!tmpProb.partialEqual(prob)){
      dbg.println("problem from agent differs from client ones: abort");
      dbg.println("server prob = " + prob);
      os.writeInt(GlobalDefs.PB_REFUSED);
      os.flush();
      return true;
    } 
    os.writeChar(GlobalDefs.DATA_XDR);
    os.writeInt(GlobalDefs.PB_ACCEPTED);
    os.flush();

    int dummy = is.readChar();
    ((AdapterFunctionStruct)tmpFunction).getCallable().call(null, is, os);
    return true;
  }

  boolean processPongBandWidth(XDRInputStream is, XDROutputStream os) throws IOException, NinfException{
    int size = 0;
    System.out.println("processing pong bandwidth");
    while ((size = is.readInt()) > 0){
      System.out.println("size = "+ size);
      System.out.println("reading");
      int tmp[] = new int[size];
      for (int i = 0; i < size; i++)
	tmp[i] = is.readInt();

      System.out.println("writing");
      os.writeChar(GlobalDefs.DATA_XDR);
      for (int i = 0; i < size; i++)
	os.writeInt(tmp[i]);
      int dummy = is.readChar();
    }
    return false;
  }

  /** dispatch jobs according to packet code */
  public boolean dispatchNinfRequest(XDRInputStream is, XDROutputStream os) {

    int code = 0;
    try {
      int mode = is.readChar();
      code = is.readInt();
    } catch (IOException e) {
      System.out.println("connection closed");
      //      e.printStackTrace(dbg.os);
      return false;
    }
    try {
      dbg.println("Adapter read code:" + code);
      switch (code) {
      case GlobalDefs.PROBLEM_SOLVE: 
	return processProblemSolve(is, os);
      case GlobalDefs.PONG_BANDWIDTH:
	return processPongBandWidth(is, os);
      case GlobalDefs.WHO_ARE_YOU:
      case GlobalDefs.PONG_LATENCY:
      case GlobalDefs.POLL_KILL:	
      case GlobalDefs.ARE_YOU_ALIVE:      
      case GlobalDefs.I_EXIST:
      case GlobalDefs.I_DIE:
      default:

	return false;
      }
    } catch (Exception e) {
      e.printStackTrace(dbg.os);
      return false;
    }
  }


  static public void main(String argv[]) {
    NinfAdapter instance = new NinfAdapter();
    instance.funcManager.setFunctionStructFactory(new AdapterStructFactory());

//    instance.dbg.quiet();

    // set myname
    try {
      InetAddress localaddr = InetAddress.getLocalHost();
      myname = localaddr.getHostName();
    } catch (UnknownHostException e) {
      instance.dbg.println("getLocalHost(): " + e);
      System.exit(1);
    }

    // set myport
    try {
      instance.setMyself();
      MetaServerConfig conf = new MetaServerConfig(argv[0]);
      instance.setEnvironment(conf);
      int myport = GlobalDefs.SV_PORT;
      System.err.println("Starting up ninfAdapter ...");
      instance.startServer(myport);
    } catch (Exception e){
      e.printStackTrace();
    }
  }

}
