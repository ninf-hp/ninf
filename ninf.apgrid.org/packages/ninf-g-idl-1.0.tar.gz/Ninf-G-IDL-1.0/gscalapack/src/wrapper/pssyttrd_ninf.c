#define _WRAPPER_
/* $Id: pssyttrd_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */

#define FLOAT
#define _DISTRIBUTE_1D_
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n

static	int worklen(int n) {
	  int ret=1;
	  int NPS, ANB;
	  int three=3;
	  ANB=max(n,100);
	  ret =  2*( ANB+1 )*( 4*n+2 ) + n;
	  if NEED_BUFF {
#if defined(FLOAT)
	    ANB = FortranCall(pjlaenv)( &PARA_CTXT, &three, "PSSYTTRD", "L", &zero, &zero, &zero, &zero );
#elif defined(DOUBLE)
	    ANB = FortranCall(pjlaenv)( &PARA_CTXT, &three, "PDSYTTRD", "L", &zero, &zero, &zero, &zero );
#endif
	    NPS = MAX( NUMROC( N, 1, 0, 0, NPROW ), 2*ANB );
	    ret =  2*( ANB+1 )*( 4*NPS+2 ) + NPS;
	  }
	  return ret;
}


void  pssyttrd_ninf(	 char uplo,
			 int n,
			 float global_a[],
			 int lda,
			 float global_d[],
			 float global_e[], //uplo
			 float global_tau[],
			 int *info
)
/* "pssyttrd reduces a complex Hermitian matrix  A to Hermitian tridiagonal form T by an unitary similarity transformation:     Q' *  A * Q = T." */
/* OPTIONS */
{
	int maxldd;

	int maxlda;
	float *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
	int row_loca, col_loca;

	float *locd=NULL, *loce=NULL;
	int desctdd[DESCLEN];
	int desc_gtdd[DESCLEN];

	float *loctau=NULL;

	float *locwork=NULL;
	int llocwork;
	INITIALIZE();

	SCALAR( "char", uplo);
	SCALAR( "int", n);
	SCALAR( "int", lda);
	SIZE(n);

	ROW( a);
	COL( a);
	MAXLDD( maxldd, a );
	maxlda = maxldd;

	trMATRIX( uplo, "float", a, ROW_a, COL_a);
	trDISTRIBUTE( uplo, "float", a, ROW_a, COL_a);
	if (chrcmp(uplo,'U')==0) tdMATRIX("float", 0, d, e, n);
	else tdMATRIX( "float", e, d, 0, n);
	VECTOR("c","float", tau, n);

	llocwork = worklen(n);
	WORK(locwork, llocwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pssyttrd)( &uplo, &n,
                                loca, &one, &one, desca,
                                locd, loce,
                                loctau,
                                locwork, &llocwork, &linfo);

	trGATHER( uplo, "float", a, ROW_a  , COL_a);
	if (chrcmp(uplo,'U')==0) tdGATHER( "float" , 0, d, e, n);
	else tdGATHER( "float", e, d, 0, n);
	vGATHER( "c", "float", tau, n);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
		*info = linfo;
	} else {
	}

	FREE_MATRIX(a);
	FREE_MATRIX(d);
	FREE_MATRIX(e);
        FREE_VECTOR(tau);
        FREE(locwork);
}

