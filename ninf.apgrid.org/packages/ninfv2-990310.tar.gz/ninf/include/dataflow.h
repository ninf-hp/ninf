
#ifndef _DATAFLOW_
#define _DATAFLOW_

struct FUNCNODE;
typedef struct FUNCNODE func_node;

typedef struct ARGPOS {
  func_node * func;
  int argnum;
  struct ARGPOS * next;
} arg_pos;

struct DATANODE {
  int serial;
  void * dataaddr;
  struct FUNCNODE * input;
  struct ARGPOS * outputs;
};

typedef struct DATANODE data_node;

typedef struct DATAWRAPPER {
  int  io_flag;
  data_node *data;
} data_wrapper;

struct FUNCNODE {
  int serial;
  NINF_STUB_INFO * info;
  data_wrapper ** args;
  int input_nums;
/*  data_node ** inputs; */
  int output_nums;
/*  data_node ** outputs; */
  any_t ninf_args[MAX_PARAMS];
};

typedef struct DATANODELIST {
  data_node * data;
  struct DATANODELIST * next;
} data_node_list;

typedef struct FUNCNODELIST {
  func_node * func;
  struct FUNCNODELIST * next;
} func_node_list;

void init_dataflow();
int ninf_make_dataflow(any_t ninf_args[], NINF_STUB_INFO * stub_info);
int trans_dataflows(dataTrans * dt);
int trans_common_data(dataTrans * dt);

#endif /* _DATAFLOW_ */
