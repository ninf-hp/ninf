#define _WRAPPER_
/* $Id: pcgeqrf_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define SCOMPLEX
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n
static	int worklen(int m, int n) {
	  int ret =1;
	  int IROFF, ICOFF, IAROW, IACOL, Mp0, Nq0;
	  ret = m + max( 1, n);
	  if NEED_BUFF {
#define IA 1
#define JA 1
#define MB_A MB
#define NB_A NB
#define MYROW myprow
#define MYCOL mypcol
#define NPROW nprow
#define NPCOL npcol
#define RSRC_A 0
#define CSRC_A 0
	    IROFF = MOD( IA-1, MB_A );
	    ICOFF = MOD( JA-1, NB_A );
	    IAROW = INDXG2P( IA, MB_A, MYROW, RSRC_A, NPROW );
	    IACOL = INDXG2P( JA, NB_A, MYCOL, CSRC_A, NPCOL );
	    Mp0   = NUMROC( M+IROFF, MB_A, MYROW, IAROW, NPROW );
	    Nq0   = NUMROC( N+ICOFF, NB_A, MYCOL, IACOL, NPCOL );
	    ret=Mp0 + MAX( 1, Nq0 );
	  }
	  return ret;
}

void  pcgeqrf_ninf(	 int m,
		 int n,
		 scomplex global_a[],
		 int lda,
		 scomplex global_tau[],
		 int ldtau,
		 scomplex work[],
		 int lwork,
		 int *info
)
/* "pcgeqrf computes a QR factorization of a complex distributed M-by-N matrix A = Q * R." */
/* OPTIONS */
{
    extern void FortranCall(pcgeqrf)( int*, int*,
				      scomplex*, int*, int*, int*,
				      scomplex*,
				      scomplex*, int*,
				      int*);

	int maxldd;

	int maxlda;
	scomplex *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
	int row_loca, col_loca;

	scomplex *loctau=NULL;

	scomplex *locwork=NULL;
	int llocwork;

	INITIALIZE();

	SCALAR( "int", m);
	SCALAR( "int", n);
	SCALAR( "int", lda);
	SCALAR( "int", lwork);

	ROW( a);
	COL( a);
	MAXLDD( maxldd, a );
	maxlda = maxldd;

	MATRIX( "scomplex", a, ROW_a, COL_a);
	DISTRIBUTE( "scomplex", a, ROW_a  , COL_a);
	VECTOR( "c", "scomplex", tau,  min(m,n));

        llocwork=worklen(m,n);
	llocwork=max(lwork,llocwork);
	WORK( locwork, llocwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pcgeqrf)( &m, &n,
                               loca, &one, &one, desca,
                               loctau,
                               locwork, &llocwork, &linfo);

	GATHER( "scomplex", a, ROW_a, COL_a);
	vGATHER( "c", "scomplex", tau, min(m,n));
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
		*info = linfo;
	} else {
		
	}

	FREE_MATRIX(a);
	FREE_VECTOR(tau);
        FREE(locwork);
}

