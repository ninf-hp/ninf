package bricks.scheduling;
import bricks.util.*;
import java.util.*;
import java.io.*;

public class NormalServerMonitor extends ServerMonitor implements SchedulingUnit {

    public NormalServerMonitor(
	String keyOfResourceDB,	Sequence interprobingTime,
	double trackingTime, double trackingTimeForAccess
    ) {
	this.keyOfResourceDB = keyOfResourceDB;
	this.interprobingTime = interprobingTime;
	this.trackingTime = trackingTime;
	this.trackingTimeForAccess = trackingTimeForAccess;
    }

/************************* needed method *************************/
    // override
    public String getName() {
	return "NormalServerMonitor";
    }
}
