package bricks.scheduling;
import bricks.util.*;
import bricks.environment.*;
import java.util.*;

public class OwnerComputesReplicationScheduler extends OwnerComputesScheduler implements SchedulingUnit {

    protected double maxLoad;

    public OwnerComputesReplicationScheduler(
	String keyOfMetaPredictor, String keyOfReplicaManager, 
	String keyOfServerMonitor, double maxLoad
    ) {
	super(keyOfMetaPredictor, keyOfReplicaManager, 
	      keyOfServerMonitor, maxLoad);
	this.maxLoad = maxLoad;
    }

/************************* needed method *************************/
    public String getName() {
	return "OwnerComputesReplicationScheduler";
    }

    protected Host select(
	double currentTime, RequestedData data, Enumeration e
    ) {
	Host selectedHost = null;
	double minElapsedTime = Double.POSITIVE_INFINITY;
	while (e.hasMoreElements()) {
	    Host h = (Host)e.nextElement();
	    if (data.scheduled(h))  //for fallback
		continue;
	    if (!hasAvailableDisk(currentTime, data, h))
		continue;
	    if (overMaxLoad(currentTime, h))
		continue;
	    double elapsedTime = Double.POSITIVE_INFINITY;
	    elapsedTime = getEstimate(
		currentTime, h, h, data.dataDestination, data
	    );
	    if (minElapsedTime > elapsedTime) {
		minElapsedTime = elapsedTime;
		selectedHost = h;
	    }
	}
	return selectedHost;
    }

    protected boolean overMaxLoad(double currentTime, Host host) {
	HostInfo info = getHostInfo(currentTime, host);
	if (info.loadAverage > maxLoad)
	    return true;
	else
	    return false;
    }
}

