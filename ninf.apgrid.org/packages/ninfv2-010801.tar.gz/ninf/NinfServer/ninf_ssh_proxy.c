#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/errno.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <pwd.h>

#include "ninf_serv_reg.h"
#include "ninf_macros.h"

#define ERROR_MAIN
#include "ninf_error.h"
char * program_context = "ninf_ssh_proxy";

#define LOG_TEMPLATE "/tmp/ninf_ssh_proxy_%s"

char * username(){
  struct passwd *pwd;
  
  pwd = getpwuid(geteuid());
  return pwd->pw_name;
}


initError(){
  char buffer[1000];
  FILE * fp;
  sprintf(buffer, LOG_TEMPLATE, username());
  Ninf_set_log_file(buffer);
}


#define max(x,y)	((x)>(y) ? (x) : (y))
#define MAX_BUFFER_SIZE 0x1000

static char buffer1[MAX_BUFFER_SIZE];
static char buffer2[MAX_BUFFER_SIZE];

void forward(int in1, int out1, int in2, int out2){
  fd_set rfds;
  int max_nfd, nfd;

  while (TRUE){
    FD_ZERO(&rfds);
    FD_SET(in1, &rfds);
    FD_SET(in2, &rfds);
    max_nfd = max(in1, in2);
    nfd = select(max_nfd+1, &rfds, NULL, NULL, NULL);
    if (nfd <= 0){
      if (errno != EINTR){
	perror("select");
	exit(3);
      }
      continue;
    }
    if (FD_ISSET(in1, &rfds)){
      int readed;
      if ((readed = read(in1, buffer1, MAX_BUFFER_SIZE - 1)) > 0)
	write(out2, buffer1, readed);
      else 
	break;
      if (ninf_debug_flag)
	ninf_log("forwarding from %d to %d", in1, out2);
    }	
    if (FD_ISSET(in2, &rfds)){
      int readed;
      if ((readed = read(in2, buffer1, MAX_BUFFER_SIZE - 1)) > 0)
	write(out1, buffer1, readed);
      else 
	break;
      if (ninf_debug_flag)
	ninf_log("forwarding from %d to %d", in2, out1);
    }	
  }
  close(in1); close(out1);
  close(in2); close(out2);
}

#ifndef SSLEAY_DEFAULT
#define SSLEAY_DEFAULT  "/usr/local/bin/ssleay"
#endif
#define SSLEAY          "ssleay"

#define SSLEAY_FMT      "%s x509 -subject -noout -in %s"

char * getCertSubject(char * filename){
  FILE * fp;
  static char subject[1000];

  char buffer1[1000];
  char buffer2[1000];

  sprintf(buffer1, SSLEAY_FMT, SSLEAY, filename);
  sprintf(buffer2, SSLEAY_FMT, SSLEAY_DEFAULT, filename);

  if (((fp = popen(buffer1, "r")) == NULL) &&   /* search using user path */
      ((fp = popen(buffer2, "r")) == NULL)){ /* try default */
    subject[0] = '\0';
    return ;
  } 
  fgets(subject, 1000, fp);
  pclose(fp);
  return subject;
}

char * stripSSHEnv(char * env){
    return strtok(env, " ");
}

#define SSH_ENV "SSH_CLIENT"
#define RSH_ENV "REMOTEHOST"
#define GSH_ENV "X509_USER_PROXY"

static void setupClientUser(struct ninf_reg_ssh_packet * packet){
  char * env;
  if ((env = getenv(SSH_ENV)) != NULL)
    strncpy(packet->client_env, stripSSHEnv(env), NINF_MAX_NAME_LEN * 2-1);
  else 
  if ((env = getenv(RSH_ENV)) != NULL)
    strncpy(packet->client_env, env, NINF_MAX_NAME_LEN -1);
  else
  if ((env = getenv(GSH_ENV)) != NULL){
    strncpy(packet->client_env, getCertSubject(env), NINF_MAX_NAME_LEN * 2-1);
  } else
    *(packet->client_env) = '\0';

  strncpy(packet->user_name, username(), NINF_MAX_NAME_LEN * 2 -1);
}

/** return TRUE if succeeded */
int signal_server(int port, char * client_host, char * client_port){
  static char reg_sockname[100];
  struct ninf_reg_callback_packet * packet; 
  int sock;
  char *reg_pkt_buf;

  if ((reg_pkt_buf = (char *) malloc(NINF_REG_PKT_SIZE)) == NULL){
    ninf_log("cannot alloc packet");
    close(0);
    exit(3);
  }  
  packet = (struct ninf_reg_callback_packet *)reg_pkt_buf;
  
  make_reg_sockname(reg_sockname, port);
  sock = ninf_connect_local(reg_sockname);
  if (sock < 0){
    ninf_log("failed to connect the server\n");
    return -1;
  }
  packet->code = NINF_REG_CALLBACK_CONNECTION;

  setupClientUser((struct ninf_reg_ssh_packet *) packet);

  strncpy(packet->client_host, client_host,  NINF_MAX_NAME_LEN -1);
  strncpy(packet->client_port, client_port,  10);
  
  if (!ninf_reg_send(sock, reg_pkt_buf))
    return FALSE;
  if (!ninf_reg_recv(sock, reg_pkt_buf))
    return FALSE;
  if (packet->code != NINF_REG_OK)
    return FALSE;
  return TRUE;
}


/** return socket, return  -1 if failed */
int get_server_connection(int port){
  static char reg_sockname[100];
  struct ninf_reg_ssh_packet * packet; 
  int sock;
  char *reg_pkt_buf;

  if ((reg_pkt_buf = (char *) malloc(NINF_REG_PKT_SIZE)) == NULL){
    ninf_log("cannot alloc packet");
    close(0);
    exit(3);
  }  
  packet = (struct ninf_reg_ssh_packet *)reg_pkt_buf;
  
  make_reg_sockname(reg_sockname, port);
  
  sock = ninf_connect_local(reg_sockname);
  if (sock < 0){
    ninf_log("failed to connect the server\n");
    return -1;
  }

  packet->code = NINF_REG_SSH_CONNECTION;

  setupClientUser((struct ninf_reg_ssh_packet *) packet);
  
  if (!ninf_reg_send(sock, reg_pkt_buf))
    return -1;
  if (!ninf_reg_recv(sock, reg_pkt_buf))
    return -1;
  if (packet->code != NINF_REG_OK)
    return -1;
  return sock;
    
}

/** it should be invoked by ssh remotely */
/** argv[1] = PORT;  or*/
/** argv[1] = PORT, argv[2] = clientname, argv[3] = clientport */

void stream_mode(int port){
  int clientIn, clientOut, server;

  /** stdin, out is considered to be connected to client */
  clientIn = 0;
  clientOut = 1;

  /** get server socket using register socket */
  server = get_server_connection(port);

  if (ninf_debug_flag)
    ninf_log("got connection to the server: fd=%d", server);
  if (server < 0){
    ninf_log("failed to open connection to the server port %d", port);
    close(0);
    exit(3);
  }
  if (ninf_debug_flag)
    ninf_log("startforwarding fd=%d, %d, %d", clientIn, clientOut, server);
  forward(clientIn, clientOut, server, server);
  ninf_log("ssh_proxy[%d] done.", getpid());
  exit(0);
}


void callback_mode(int port, char * hostname, char * portname){
  if (!signal_server(port, hostname, portname)){
    ninf_log("failed to signal callback");
  }
  ninf_log("ssh_proxy[%d] done.", getpid());
  exit(0);
}


main(int argc, char ** argv){
  int port;
  initError();

  if (argc == 2){
    ninf_log("ssh_proxy[%d] startup, stream mode", getpid());
    stream_mode(atoi(argv[1]));
  } else if (argc == 4){
    ninf_log("ssh_proxy[%d] startup, callback mode", getpid());
    callback_mode(atoi(argv[1]), argv[2], argv[3]);
  }else {
    ninf_log("cannot get port from args");
    close(0);
    exit(3);
  }  
}
