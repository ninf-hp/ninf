package jp.go.aist.gtrc.util;

import java.util.Vector;

import javassist.ClassPool;
import javassist.CtClass;
import javassist.CtField;
import javassist.CtMethod;
import javassist.NotFoundException;

public class ResourceInfo {
	public class ResourceInfoException extends Exception {
		ResourceInfoException(String message) {
			super(message);
		}

		ResourceInfoException(Throwable t) {
			super(t);
		}
	}

	String tnsFQDN;
	String implPackageName;
	String simpleName;
	public String serviceName;
	String location;
	String tnsPath;
	public String tns;
	OperationInfo factoryOperationInfo;
	public PropertyInfo[] propertyInfos;
	OperationInfo[] operationInfos;

	public ResourceInfo(CtClass cc, String tnsFQDN, TypeMapping typeMapping) throws ResourceInfoException, ClassNotFoundException, NotFoundException {
		this.tnsFQDN = tnsFQDN;
		implPackageName = cc.getPackageName();
		if (!implPackageName.endsWith(".impl")) {
			throw new ResourceInfoException("Name of resouce implementation package ('" + implPackageName + "') must end with '.impl'");
		}
		simpleName = cc.getSimpleName();
		if (!simpleName.endsWith("Resource")) {
			throw new ResourceInfoException("Name of resouce implementation class ('" + simpleName + "') must end with 'Resource'");
		}
		serviceName = simpleName.substring(0, simpleName.length() - "Resource".length());
		{
			String tmp = implPackageName.substring(0, implPackageName.length() - ".impl".length());
			if (!tmp.startsWith(reverseFQDN(tnsFQDN))) {
				throw new ResourceInfoException("Package name of resouce implementation class ('" + implPackageName + "') doesn't match with FQDN of given namespace ('" + tnsFQDN +"')\n");
			}
			location = tmp.replace(".", "/");
			tnsPath = tmp.substring(tnsFQDN.length() + 1, tmp.length()).replace(".", "/");
		}
		tns = "http://" + tnsFQDN + "/" + tnsPath;
		propertyInfos = getPropertyInfos(cc, tns, typeMapping);
		operationInfos = getOperationInfos(cc, tns, typeMapping);
	}

	static String reverseFQDN(String fqdn) {
		StringBuffer reversed = new StringBuffer("");
		for (String s : fqdn.split("\\.")) {
			reversed.insert(0, ".");
			reversed.insert(0, s);
		}
		reversed.deleteCharAt(reversed.length() - 1);
		return reversed.toString();
	}

	static PropertyInfo[] getPropertyInfos(CtClass cc, String tns, TypeMapping typeMapping) throws ClassNotFoundException, NotFoundException {
		Vector<PropertyInfo> tmp = new Vector<PropertyInfo>();
		for (CtField property : Utils.filterProps(cc.getDeclaredFields())) {
			tmp.add(new PropertyInfo(property, tns, typeMapping));
		}
		return tmp.toArray(new PropertyInfo[0]);
	}

	static OperationInfo[] getOperationInfos(CtClass cc, String tns, TypeMapping typeMapping) throws ClassNotFoundException, NotFoundException {
		Vector<OperationInfo> tmp = new Vector<OperationInfo>();
		for (CtMethod operation : Utils.filterOps(cc.getDeclaredMethods())) {
			tmp.add(new OperationInfo(cc, operation, tns, typeMapping));
		}
		return tmp.toArray(new OperationInfo[0]);
	}

	static boolean isTestOk() {
		try {
			ClassPool cp = ClassPool.getDefault();
			CtClass cc = cp.get("jp.go.aist.gtrc.util.impl.TestResource");
			ResourceInfo resourceInfo = new ResourceInfo(cc, "gtrc.aist.go.jp", getTypeMapping());
			if (!resourceInfo.implPackageName.equals("jp.go.aist.gtrc.util.impl")) {
				System.out.println("!resourceInfo.implPackageName.equals(\"jp.go.aist.gtrc.util.impl\")");
				return false;
			}
			if (!resourceInfo.simpleName.equals("TestResource")) {
				System.out.println("!resourceInfo.simpleName.equals(\"TestResource\")");
				return false;
			}
			if (!resourceInfo.serviceName.equals("Test")) {
				System.out.println("!resourceInfo.serviceName.equals(\"Test\")");
				return false;
			}
			if (!resourceInfo.tnsPath.equals("util")) {
				System.out.println("!resourceInfo.tnsPath.equals(\"util\")");
				return false;
			}
			if (!resourceInfo.tns.equals("http://gtrc.aist.go.jp/util")) {
				System.out.println("!resourceInfo.tns.equals(\"http://gtrc.aist.go.jp/util\")");
				return false;
			}
			if (!resourceInfo.tns.equals("http://gtrc.aist.go.jp/util")) {
				System.out.println("!resourceInfo.tns.equals(\"http://gtrc.aist.go.jp/util\")");
				return false;
			}
			if (!resourceInfo.location.equals("jp/go/aist/gtrc/util")) {
				System.out.println("!resourceInfo.tns.equals(\"jp/go/aist/gtrc/util\")");
				return false;
			}
			return true;
		} catch (Throwable e) {
			e.printStackTrace();
			return false;
		}
	}

	static TypeMapping getTypeMapping() {
		TypeMapping typeMapping = new TypeMapping();
		SchemaInfo schemaInfo = new SchemaInfo("xsd", "http://www.w3.org/2001/XMLSchema");
		typeMapping.put("int", new TypeInfo(schemaInfo, "int", "int"));  // XXX
		return typeMapping;
	}
}
