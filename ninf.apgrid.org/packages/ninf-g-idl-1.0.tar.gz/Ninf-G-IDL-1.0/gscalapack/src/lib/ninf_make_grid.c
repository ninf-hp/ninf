/*
 * $Id: ninf_make_grid.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $
 */

/*
 * original description
 *
 * ninf_make_grid
 *
 * The routine makes a process grid as close to as a squre. 
 *
 * Written by Keita Teranishi
 * University of Tennessee
 * Electrotenichical Laboratory
 * 6/14/2000
 */

#include <stdio.h>
#include <math.h>

void ninf_make_grid ( int nprocs, int *nprow, int *npcol )
{
   int i, row, col;

   col= (int)(sqrt(nprocs));
   i = 0;
   while ( i == 0 ) {
      if( nprocs % col == 0 ) {
         row = nprocs/col;
         i = 1;
      } else
         col--;
   }
   *nprow = row;
   *npcol = col;
   return;
}

void ninf_make_grid1d ( int nprocs, int *nprow, int *npcol )
{
   int row, col;

   row = 1;
   col = nprocs;
   *nprow = row;
   *npcol = col;
   return;
}
