package ninf.cproxy;
import java.io.PrintStream;

public interface TPinger extends Runnable{
  public TPinger setup(NinfServerStructComm target, int interval, int size);
  public TPinger setup(NinfServerStructComm target, int interval, 
	  int size, int minimumSize, int maximumSize, 
	  double measureTime, PrintStream throughputLogStream);
}
