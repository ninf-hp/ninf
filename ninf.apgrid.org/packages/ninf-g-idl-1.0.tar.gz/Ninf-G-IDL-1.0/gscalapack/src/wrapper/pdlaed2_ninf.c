#define _WRAPPER_
/* $Id: pdlaed2_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define DOUBLE
#define _DISTRIBUTE_1D_ 
/* this func doesn't treate matrices q and q2 as band,  however,  */
/* q and q2 are to be splitted in rows, so use utils which distribute */
/* a general matrix by splitting in rows. */

#include <gscalapack.h>

#define ROW_q ldq
#define COL_q n
#define ROW_q2 ldq
#define COL_q2 n
void  pdlaed2_ninf(	
		 int *k,
		 int n,
		 int n1,
		 double d[],
		 double global_q[],
		 int ldq,
		 int global_indxq[], /* dummy ?*/
		 double *rho,
		 double z[],
		 double dlamda[],
		 double w[],
		 double global_q2[],
		 int indx[],
		 int indxc[],
		 int indxp[],
		 int coltyp[],
		 int *info
)
/* "pdlaed2 sorts the two sets of eigenvalues together into a single sorted set." */
/* OPTIONS */
{
    int maxldd;

    int nn;
    int nn1;
    int nn2;
    int nb;
    
    int maxldq;
    double *locq=NULL;
    int desc_gq[DESCLEN];
    int descq[DESCLEN];
    int row_locq, col_locq;

    int maxldq2;
    double *locq2=NULL;
    int desc_gq2[DESCLEN];
    int descq2[DESCLEN];
    int row_locq2, col_locq2;

    double *locw=NULL;
    double *locdlamda=NULL;

    int *loccoltyp=NULL;
    int *ctor=NULL, *locpsm=NULL, *locqbuf=NULL;
    int *locindcol=NULL, *locctot=NULL;
    int ib1, ib2;

    INITIALIZE();
    SCALAR( "int", n);
    SCALAR( "int", n1);
    SCALAR( "int", ldq);
    SIZE(n);

    nb = cbloc;

    COMMON("int",k, 1);
    COMMON("double", rho, 1);
    COMMON("int", indx, n);
    COMMON("double", d, n);
    COMMON("double", z, n);


    ROW(q);
    COL(q);
    MAXLDD(maxldd, q);
    maxldq=maxldd;
    ROW(q2);
    COL(q2);
    MAXLDD(maxldd, q2);
    maxldq2=maxldd;

    MATRIX("double", q, ROW_q, COL_q);
    MATRIX("double", q2, ROW_q2, COL_q2);

    DISTRIBUTE("double", q, ROW_q, COL_q);

    locw =MALLOC(sizeof(double)*n); assert(locw);
    loccoltyp = MALLOC(sizeof(int)*n); assert(loccoltyp);
    locdlamda = MALLOC(sizeof(double)*n); assert(locdlamda);

    IWORK(locctot, npcol*4);
    IWORK(locpsm, npcol*4);
    WORK(locqbuf, 3*n);

    IWORK(locindcol,n);

    if  (( mypnum != 0 ) ^ (serial==1) )
	FortranCall(pdlaed2)( &PARA_CTXT,
			      &k, &n, &n1, &nb,
			      d, &zero, &zero,
			      locq, &row_locq,
			      rho, z, w, locdlamda,
			      locq2, &row_locq2,
			      locqbuf, locctot,
			      locpsm, &npcol,
			      indx, indxc, indxp, locindcol, loccoltyp,
			      &nn, &nn1, &nn2, &ib1, &ib2);

    RETRIEVE("double", d, n);
    RETRIEVE("double", w, n);
    GATHER("double", q, ROW_q, COL_q);
    GATHER("double", q2, ROW_q2, COL_q2);

    RETRIEVE("int", indx, n);

    RETRIEVE("int", locindcol, n);

    RETRIEVE("int", &nn, 1);
    RETRIEVE("int", &nn1, 1);
    RETRIEVE("int", &nn2, 1);
    RETRIEVE("int", &ib1, 1);
    RETRIEVE("int", &ib2, 1);

    RETRIEVE("double", rho, 1);
    RETRIEVE("int", k,1);
    RETRIEVE("double", locw,n);
    RETRIEVE("int", loccoltyp, n);
    RETRIEVE("double", locdlamda, n);
    RETRIEVE("int", &linfo, 1);

    if( mypnum == 0 ){
	int i;
	*info = linfo;
	for(i=0;i<n;i++) w[i] = locw[i];
	for(i=0;i<n;i++) coltyp[i] = loccoltyp[i];
	for(i=0;i<n;i++) dlamda[i] = locdlamda[i];
    } else {
    }

    FREE_COMMON(k);
    FREE_COMMON(rho);
    FREE_COMMON(indx);
    FREE_COMMON(d);
    FREE_COMMON(z);
    FREE_MATRIX( q);
    FREE_MATRIX( q2);
    FREE(locw);
    FREE(loccoltyp);
    FREE(locdlamda);
	
}

