#include <stdio.h>
#include <stdlib.h>

void* gfftw_malloc(size_t size)
{
    void *ret=NULL;

    if (size<3) {
        fprintf(stderr,
		"Error: STUB requires too little mem. Something strange.\n");
        exit(1);
    }

    ret = malloc(size);
    if (ret==NULL) {
        fprintf(stderr, "Error: Memory Allocation failed.\n");
        exit(1);
    }

    return ret;
}
