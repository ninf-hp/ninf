package ninf.client;

import java.io.IOException;
import java.io.*;
import java.net.*;
import java.util.Vector;
import ninf.basic.*;
import ninf.basic.NinfErrorException;
import ninf.common.*;

public class NinfLocalConnection extends NinfConnection 
implements NinfConstant{
  static NinfLog dbg = new NinfLog("NinfLocalConnection");
  Runtime runtime = Runtime.getRuntime();
  Process process;
  String [] com;

  NinfLocalConnection(String filename) throws NinfException{
    withHeader = false;
    connect(filename);
  }

  void connect(String filename) throws NinfException{
    try {
    //    SocketAddress sockAddr = 
    //      new InetSocketAddress(InetAddress.getByName("localhost"), 0);

    //    ServerSocket ss = new ServerSocket();
    //    ss.bind(sockAddr);
      ServerSocket ss = new ServerSocket(0);

      int port = ss.getLocalPort();
      com = new String[]{filename, ""+port, "callback"};

      process = runtime.exec(com);
      Thread t1 = 
	new Thread(new RedirectRunnable(process.getInputStream(),
					System.out));
      Thread t2 = 
	new Thread(new RedirectRunnable(process.getErrorStream(),
					System.err));
      t1.setDaemon(true);
      t2.setDaemon(true);
      t1.start();
      t2.start();

      //      dbg.print("accepting serversocket at " + port);
      Socket s = ss.accept();
      //      dbg.print("acceptted serversocket");

      is = new XDRInputStream(s.getInputStream());
      os = new XDROutputStream(s.getOutputStream());

      int pid = is.readInt();
      //      dbg.log("pid = " + pid);
    } catch (IOException e){
      throw new NinfIOException(e);
    }
    
  }

  /** the argument will be ignored */
  public NinfStub getStub(String stubname) throws NinfException {
    NinfStub stub;

    try {
      os.writeInt(NINF_REQ_STUB_INFO_LOCAL);
      os.flush();
      int ack = is.readInt();
    } catch (IOException e){throw new NinfIOException(e);}

    //pos.writeInt(NINF_REQ_STUB_INFO);
    //    pos.flush();

    stub =  new NinfStub(is);
    return stub;
  }

  public void close() throws NinfException{
    NinfPacketOutputStream pos = new NinfPacketOutputStream(os, false, false);
    pos.writeInt(NINF_REQ_KILL);
    pos.flush();
    try {
      os.close();
      is.close();
    } catch (IOException e){
      throw new NinfIOException(e);
    }
  }
}




