#define _WRAPPER_
/* $Id: pslatrs_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define FLOAT
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n
static	int worklen() {
	  int ret=1;
	  ret =10;
	  return ret;
}


void  pslatrs_ninf(	 char  uplo,
		 char  trans,
		 char  diag,
		 char normin,
		 int  n,
		 float global_a[],
		 int lda,
		 float global_x[],
		 float *scale,
		 float  cnorm[],
		 int *info
)
/* "pslatrs solves a triangular system. This routine in unfinished at this time, but will be part of the next release." */
/* OPTIONS */
{
extern void  FortranCall(pclatrs)( char*, char*, char*, char*, int*,
				   float*, int*, int*, int*,
				   float*, int*, int*, int*,
				   float*, float*,
				   float*);

	int maxldd;

	int maxlda;
	float *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
	int row_loca, col_loca;

	float *locx=NULL;
	int descx[DESCLEN];
	
	float *locwork=NULL;
	int llocwork;

	float locscale[1];

	INITIALIZE();

	SCALAR("char", uplo);
	SCALAR("char", trans);
	SCALAR("char", diag);
	SCALAR("char", normin);
	SCALAR("int", n);
	SCALAR("int",lda);

	COMMON("float",cnorm,n );

	ROW(a);
	COL(a);
	MAXLDD( maxldd, a );
	maxlda= maxldd;

	VECTOR("c", "float", x, n);
	vDISTRIBUTE("c", "float", x, n);
	Cdescinit( descx, 1, n, 1, cbloc, 0, 0,PARA_CTXT, 1, &linfo );

	trMATRIX( uplo, "float", a, ROW_a, COL_a);
	trDISTRIBUTE( uplo, "float", a, ROW_a, COL_a);

	llocwork=worklen();
	WORK(locwork,llocwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	  FortranCall(pslatrs)( &uplo, &trans, &diag,
				&normin, &n,
				loca, &one, &one, desca,
				locx, &one, &one, descx,
				locscale, cnorm,
                                locwork);

	vGATHER( "c", "float", x, n);
	RETRIEVE("int", &linfo, 1);
	RETRIEVE("float", cnorm, n);
	RETRIEVE("float", locscale, 1);

	if( mypnum == 0 ){
	  *info = linfo;
	  *scale=*locscale;
	} else {

	}
        FREE_COMMON(cnorm);
	FREE_MATRIX(a);
	FREE_VECTOR(x);
        FREE(locwork);
}

