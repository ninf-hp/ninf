package bricks.util;
import bricks.environment.*;
import java.util.*;

public abstract class Queue implements SubComponent {

    public boolean interpolationCpu = false;
    public NodeWithQueue owner;
    protected Vector  queue;
    public Sequence throughput;
    public double maxThroughput;

    protected int DEFAULT_QUEUE_LENGTH = 100;
    // for isFull of NodeWithQueue
    protected int bufferMax = Integer.MAX_VALUE;

    //public abstract String toOriginalString();
    public abstract String getName();

/************************* default method *************************/
    public String toOriginalString() {
	String str = "    " + getName() + "(" + throughput + ")[" + 
	    size() + "] : ";
	Enumeration e = queue.elements();
	while (e.hasMoreElements()) {
	    Data data = (Data)e.nextElement();
	    str += data + ", ";
	}
	return str + "\n";
    }


    public void setMaxThroughput() {
	if((maxThroughput = throughput.max()) < 0.0) {
	    error("Bad Sequence for Throughput");
	}
    }

    public int size() {
	return queue.size();
    }

    public boolean isFull() {
	return false;
    }

    public boolean isEmpty() {
	return queue.isEmpty();
    }	

    public boolean isInterpolationCpu() {
	return interpolationCpu;
    }

    public Data top() {
	return (Data)queue.firstElement();
    }

    public double getTimeQueueEventComes() {
	return top().timeEventComes;
    }

    /* callee: NetworkNode */
    public boolean processEvent(double currentTime) {
	top().updateDataSize();
	top().gotoNextNode(currentTime);
	// slide queueing jobs
	dequeue(currentTime);
	return true;
    }

    /* callee: ServerNode */
    public boolean processEventForPackets(double currentTime) {
	top().updateDataSize();
	// slide queueing jobs
	dequeue(currentTime);
	return true;
    }

    protected void updateNextTop(double currentTime) {
	if (!isEmpty()) {
	    top().updateProcessingDuration(
	        currentTime, throughput.nextDouble(currentTime)
	    );
	    top().updateTimeEventComes(currentTime);
	}
    }

    public void dequeue(double currentTime) {
	if (queue.isEmpty())
	    error("no dequeue data");

	queue.removeElementAt(0);
	updateNextTop(currentTime);
    }

    public void enqueue(double currentTime, Data data) {
	queue.addElement(data);
	if (queue.size() == 1) {
	    updateNextTop(currentTime);
	}	    
    }

    // if (interpolationCpu == true)
    public double getLoad(double currentTime, double trackingTime) {
	if (!interpolationCpu) {
	    error(this + " do not have the InterpolationCpu Queue.");
	}
	return ((InterpolationCpu)throughput).getLoad(
	    currentTime, trackingTime
	);
    }

    public double getCpuUtilization(double currentTime, double trackingTime) {
	if (!interpolationCpu) {
	    error(this + " do not have the InterpolationCpu Queue.");
	}
	return ((InterpolationCpu)throughput).getCpuUtilization(
	    currentTime, trackingTime
	);
    }

    // for fallback
    public double getEstimation(double currentTime, RequestedData data) {
	double total = 0.0;
	Enumeration e = queue.elements();
	while (e.hasMoreElements()) {
	    total += ((Data)e.nextElement()).getDataSize();
	}
	double diff = currentTime - 
	    (top().timeEventComes - top().processingDuration);
	return (total + data.getDataSize())/ throughput.nextDouble(currentTime) - diff;
    }

    /* callee: NetworkNode */
    public double getThroughputAt(double currentTime) {
	return throughput.nextDouble(currentTime);
    }

    protected void error(String message) throws RuntimeException {
	System.err.println("Queue Error:: " + message);
	throw new RuntimeException();
    }
}
