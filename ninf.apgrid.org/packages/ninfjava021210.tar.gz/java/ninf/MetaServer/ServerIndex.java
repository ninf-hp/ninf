package ninf.metaserver;

class ServerIndex {
  /** Ninf server */
  NinfServerStruct server;
  /** index No. on NinfServer */
  int index;  

  ServerIndex(NinfServerStruct server, int index){
    this.server = server;
    this.index = index;
  }

  boolean equals(Object o){
    if (!(o instanceof ServerIndex))
      return false;
    if (((ServerIndex)o).server.equals(server) &&
        ((ServerIndex)o).index == index)
      return true;
    return false;
  }
}

