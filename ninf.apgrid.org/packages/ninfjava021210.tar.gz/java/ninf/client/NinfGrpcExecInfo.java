package ninf.client;

public class NinfGrpcExecInfo implements org.gridforum.gridrpc.GrpcExecInfo {
  private NinfExecInfo execInfo;
  
  NinfGrpcExecInfo(NinfExecInfo execinfo){
    this.execInfo = execInfo;
  }

  public double getLookupTime(){
    return 0;
  }
  public double getInvokeTime(){
    return 0;
  }
  public double getForeTime(){
    return execInfo.fore_time;
  }
  public double getExecTime(){
    return execInfo.exec_time;
  }
  public double getBackTime(){
    return execInfo.back_time;
  }
}
