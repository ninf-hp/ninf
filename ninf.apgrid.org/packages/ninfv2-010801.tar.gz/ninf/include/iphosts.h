
#ifndef __NINF_IPHOSTS__
#define __NINF_IPHOSTS__

void initAllowList();
int addIPHostList(char * address, char * mask);
int isAllowed(int socket);

#endif
