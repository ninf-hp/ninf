package ninf.netsolve;
// import java.awt.*;
import java.awt.Panel;
// import java.awt.image.*;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;

public class ImagePanel extends Panel
{
  Image im=null;

  public ImagePanel(String filename)
  {
    super();
    resize(100,100);
//    im = getToolkit().getImage(filename);
    im = Toolkit.getDefaultToolkit().getImage(filename);
    repaint();
  }

  public void paint(Graphics g)
  {
    update(g);
  }

  public void update(Graphics g)
  {
    g.drawImage(im, 0, 0, this);
  }
}
