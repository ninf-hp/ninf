package ninf.metaserver;
import ninf.basic.*;
import ninf.client.*;
import ninf.common.*;
import java.io.*;
import java.util.Enumeration;
import java.util.Vector;

class MetaServerRoot extends NServer {
  String myname;
  int myport;
  MetaServer masterServer;
  boolean lookup = true;

  ProbeRoot probeRoot;
  DirectoryService directoryService;
  SchedulerRoot schedulerRoot;
  MetaServerConfig conf;

  static final CommandRepresent acceptCommands[] = {
    new CommandRepresent("register",           2), 
    new CommandRepresent("throughputInfo",     0), 
    new CommandRepresent("getStub",            1),
    new CommandRepresent("getNewServers",      1),
    new CommandRepresent("getServerCharacter", 0),
    new CommandRepresent("getServerStubs",     2),
    new CommandRepresent("schedule",           3),
    new CommandRepresent("aggregateSchedule",  3),
    new CommandRepresent("jobDone",            3),
    new CommandRepresent("time",               0),
    new CommandRepresent("inform",             0),
    new CommandRepresent("getLog",             0),
    new CommandRepresent("getScheduler",       0),
    new CommandRepresent("getAggregateScheduler",0),
    new CommandRepresent("getFunctionNames",   0),
    new CommandRepresent("scheduler",          1),
    new CommandRepresent("aggregateScheduler", 1),
    new CommandRepresent("initPredictor",      0),
    new CommandRepresent("pushPredictor",      1),
    new CommandRepresent("getPredictors",      0),    
    new CommandRepresent("getNWSNameServer",   0),    
  };
  static CommandParser parser = new CommandParser(acceptCommands);

  static NinfLog dbg = new NinfLog("MetaServerRoot");
  
  MetaServerRoot(String myname, int myport, MetaServer masterServer)
    throws NinfException {
    this.myname = myname;
    this.myport = myport;
    this.masterServer = masterServer;
    this.conf = masterServer.conf;
    this.lookup = this.conf.lookup;
    NinfServerConnection.lookup = this.conf.lookup;
    MetaServerConnection.lookup = this.conf.lookup;
    directoryService = new DirectoryService(this);
    probeRoot = new ProbeRoot(this);
    schedulerRoot = new SchedulerRoot(conf.schedulerString, directoryService);
    connectServers();
    initialize();
  }


  void initialize() throws NinfException {
    Vector initializers = masterServer.conf.initializers;
    try {
      for (int i = 0; i < initializers.size(); i++){
        Class initClass = (Class)initializers.elementAt(i);
        ((MetaServerInitializer)(initClass.newInstance())).init(masterServer.conf);
      }
    } catch (IllegalAccessException e){
	e.printStackTrace();
       throw new ConfigureException("Cannot instantiate Initializer");
    } catch (InstantiationException e){
	e.printStackTrace();
       throw  new ConfigureException("Cannot instantiate Initializer");
    }
  }

  boolean register(NinfCommand com, PrintStream os) throws NinfException{
    NinfServerHolder server = 
      new NinfServerHolder(com.args[0], 
			   (new Integer(com.args[1])).intValue());
    probeRoot.registerServer(server);
    return true;
  } 


  void connectServers(){
    if (conf.holders == null)
      return;
    for (int i = 0; i < conf.holders.length; i++) {
      try {
	probeRoot.registerServer(conf.holders[i]);
      } catch (NinfException e){
	dbg.log("Failed to register :" +  conf.holders[i]);
      }
    }
  }



  boolean getLog(PrintStream os) throws NinfException{
    ForkOutputStream fos = new ForkOutputStream();
    fos.addStream(NinfLog.os);
    fos.addStream(os);    
    PrintStream tmp = new PrintStream(fos);
    NinfLog.changeOutput(tmp);
    return true;
  }

  boolean getStub(NinfCommand com, PrintStream os) throws NinfException{
    NinfStub stub = directoryService.getStub(new FunctionName(com.args[0]));
    if (stub == null){
      os.println("nostub");
      return true;     
    }
    os.println("stub");
    stub.writeTo(new XDROutputStream(os));
    return false;   /* it means that this connection should be closed, because of binary transmission */
  }

  boolean getNewServers(NinfCommand com, PrintStream os) throws NinfException{
    long now = System.currentTimeMillis();
    long time = new Long(com.args[0]).longValue();
    Set servers = directoryService.getNewServers(time);
    int count = servers.size();
    Enumeration enum = servers.elements();

    new NinfCommand("newServers", ""+count , ""+ now ).send(os);
    while (enum.hasMoreElements()){
      NinfServerHolder o = (NinfServerHolder)enum.nextElement();
      o.toCommand().send(os);
    }
    return true;
  }

  boolean getServerCharacter(DataInputStream is, PrintStream os) 
                              throws NinfException{
    NinfServerHolder holder = new NinfServerHolder(is);
    ServerCharacter sChar = directoryService.getServerCharacter(holder.struct);
    if (sChar == null)
      os.println("-ERR");
    sChar.toCommand().send(os);
    return true;
  }

  boolean returnTime(PrintStream os) throws NinfException{
    os.println(FormatString.format("%.2lf", 
	new Double(System.currentTimeMillis() / 1000.0)));
    return false;
  }

  boolean getScheduler(PrintStream os) throws NinfException{
    String tmp = schedulerRoot.getCurrentScheduler();
    os.println("+OK");
    os.println(tmp);
    return true;
  }

  boolean returnNWSNameServer(PrintStream os) throws NinfException{
    if (!conf.NWSuse || conf.NWSNameServer == null){
      os.println("-NO");
    } else {
      os.println("+OK");
      os.println(conf.NWSNameServer);
    }
    return true;
  }

  boolean getAggregateScheduler(PrintStream os) throws NinfException{
    String tmp = schedulerRoot.getCurrentAggregateScheduler();
    os.println("+OK");
    os.println(tmp);
    return true;
  }

  boolean getFunctionNames(PrintStream os) throws NinfException{
    Enumeration tmp = directoryService.functionTable.keys();
    int n = directoryService.functionTable.size();
    os.println("functionNames " + n);
    for (int i = 0; i < n; i++){
      FunctionName name = (FunctionName)(tmp.nextElement());
      os.println(name);
    }
    return true;
  }

  boolean getServerStubs(NinfCommand com, PrintStream os) throws NinfException{
    NinfServerStruct server = 
      new NinfServerStruct(com.args[0], 
			   (new Integer(com.args[1])).intValue());
    FunctionName[] names = directoryService.getServerFuncs(server);
    os.println("functionNames " + names.length);
    for (int i = 0; i < names.length; i++){
      FunctionName name = names[i];
      os.println(name);
    }
    return true;
  }

  boolean setInform(PrintStream os) throws NinfException{
    ServerObserver obs = new ServerObserver(os);
    //    try {
      directoryService.addObserver(obs);
      //    }finally{
      //      directoryService.removeObserver(obs);
      //    }
    return true;
  }

  boolean processConnection(DataInputStream is, PrintStream os) 
             throws NinfException{
    NinfCommand com;
    try {
      com = parser.readCommand(is);
    } catch (NinfIOException e){
      return false;
    }
    dbg.println("readed " + com);
    if (com.command.equals("register")){
      return register(com, os);
    } else if (com.command.equals("throughputInfo")){
      return directoryService.throughputInfo(is, os);
    } else if (com.command.equals("getStub")){
      return getStub(com, os);
    } else if (com.command.equals("getNewServers")){
      return getNewServers(com, os);
    } else if (com.command.equals("schedule")){
      return schedulerRoot.doSchedule(is, os,
             new RequestID(com.args[0], com.args[1], com.args[2]));
    } else if (com.command.equals("aggregateSchedule")){
      return schedulerRoot.doAggregateSchedule(is, os,
             new RequestID(com.args[0], com.args[1], com.args[2]));
    } else if (com.command.equals("jobDone")){
      return schedulerRoot.jobDone(
             new RequestID(com.args[0], com.args[1], com.args[2]));
    } else if (com.command.equals("scheduler")){
      return schedulerRoot.newScheduler(com.args[0], os);
    } else if (com.command.equals("aggregateScheduler")){
      return schedulerRoot.newAggregateScheduler(com.args[0], os);
    } else if (com.command.equals("initPredictor")){
      return schedulerRoot.initPredictor(os);
    } else if (com.command.equals("pushPredictor")){
      return schedulerRoot.pushPredictor(com.args[0], os);
    } else if (com.command.equals("getPredictors")){
      return schedulerRoot.getPredictors(os);
    } else if (com.command.equals("getNWSNameServer")){
      return returnNWSNameServer(os);
    } else if (com.command.equals("time")){
      return returnTime(os);
    } else if (com.command.equals("inform")){
      return setInform(os);
    } else if (com.command.equals("getLog")){
      return getLog(os);
    } else if (com.command.equals("getScheduler")){
      return getScheduler(os);
    } else if (com.command.equals("getAggregateScheduler")){
      return getAggregateScheduler(os);
    } else if (com.command.equals("getFunctionNames")){
      return getFunctionNames(os);
    } else if (com.command.equals("getServerStubs")){
      return getServerStubs(com, os);
    } else if (com.command.equals("getServerCharacter")){
      return getServerCharacter(is, os);
    } else {
      dbg.log("Some error occurred: ");
      throw new NinfErrorException(NinfError.NINF_INTERNAL_ERROR);
    }
  }

  public void serviceRequest() {
    DataInputStream is = new DataInputStream(clientInput);
    PrintStream os = new PrintStream(clientOutput);
    if (lookup)
      dbg.println("["+myport+"] accept connection from " + clientSocket.getInetAddress());
    else
      dbg.println("["+myport+"] accept connection from " + clientSocket.getInetAddress().getHostAddress());      
    try {
      while (processConnection(is, os))
	;
    } catch (NinfException e){
      dbg.log("Some error occurred: " + e);
      e.printStackTrace();
      /* error condition and some string should be sent to the client */
    }
    try {
      is.close();
      os.flush();
      os.close();
    } catch (IOException e){}
  }

  void start(){
    startServer(myport);
    dbg.log("[" +myport+"] start ..");
  }
}
