package jp.go.aist.gtrc.impl;

import java.util.Vector;

import javassist.CannotCompileException;
import javassist.ClassClassPath;
import javassist.ClassPool;
import javassist.CtClass;
import javassist.CtConstructor;
import javassist.CtField;
import javassist.CtMethod;
import javassist.CtNewMethod;
import javassist.NotFoundException;

//import jp.go.aist.gtrc.util.PropertyInfo;
import jp.go.aist.gtrc.util.ResourceInfo;
import jp.go.aist.gtrc.util.SchemaInfo;
import jp.go.aist.gtrc.util.TypeInfo;
import jp.go.aist.gtrc.util.TypeMapping;
import jp.go.aist.gtrc.util.Utils;

public class ResourceHomeImpl extends org.globus.wsrf.impl.ResourceHomeImpl {
	static class PropertyInfo {
		String type_name;
		String name;

		PropertyInfo(String type_name, String name) {
			this.type_name = type_name;
			this.name = name;
		}
	}

	public void setResourceClass(String clazz) throws ClassNotFoundException {
		try {
			ClassPool cp = ClassPool.getDefault();
			cp.insertClassPath(new ClassClassPath(getClass()));
			CtClass resourceC = cp.get(clazz);
			{
				CtClass r = cp.get("org.globus.wsrf.Resource");
				resourceC.addInterface(r);
			}
			/*try*/{
				//ResourceInfo resourceInfo = new ResourceInfo(resourceC, "gtrc.aist.go.jp", getTypeMapping(cp));
				for (PropertyInfo prop : propertyInfos(resourceC)) {
					String getterString = makeGetterString(prop);
					CtMethod getter = CtNewMethod.make(getterString, resourceC);
					resourceC.addMethod(getter);

					String setterString = makeSetterString(prop);
					CtMethod setter = CtNewMethod.make(setterString, resourceC);
					resourceC.addMethod(setter);
				}
				String rpsFieldString = makeRPSFieldString();
				CtField rpsField = CtField.make(rpsFieldString, resourceC);
				resourceC.addField(rpsField);

				String initString = makeInitializeString(resourceC);
				CtConstructor cter = resourceC.getDeclaredConstructor(new CtClass[0]);
				cter.insertBeforeBody(initString);
			//} catch (ResourceInfo.ResourceInfoException e) {
				//e.printStackTrace();
			}

			String rpsGetterString = makeGetResourcePropertySetString();
			CtMethod rpsGetter = CtNewMethod.make(rpsGetterString, resourceC);
			resourceC.addMethod(rpsGetter);
			{
				CtClass rpsC = cp.get("org.globus.wsrf.ResourceProperties");
				resourceC.addInterface(rpsC);
			}
			resourceClass = resourceC.toClass();
		} catch (NotFoundException e) {
			e.printStackTrace();
		} catch (CannotCompileException e) {
			e.printStackTrace();
		}
	}
	/*
	static TypeMapping getTypeMapping(ClassPool cp) throws NotFoundException {
		TypeMapping typeMapping = new TypeMapping();
		SchemaInfo schemaInfo = new SchemaInfo("xsd", "http://www.w3.org/2001/XMLSchema");
		typeMapping.put("int", new TypeInfo(schemaInfo, "int", "int"));  // XXX
		return typeMapping;
	}
	*/
	static PropertyInfo[] propertyInfos(CtClass resourceC) throws ClassNotFoundException, NotFoundException {
		Vector<PropertyInfo> tmp = new Vector<PropertyInfo>();
		for (CtField property : Utils.filterProps(resourceC.getDeclaredFields())) {
			PropertyInfo propertyInfo = new PropertyInfo(property.getType().getName(), property.getName());
			tmp.add(propertyInfo);
		}
		return tmp.toArray(new PropertyInfo[0]);
	}

	static String makeGetterString(PropertyInfo prop) throws NotFoundException {
		String type = prop.type_name;
		String name = prop.name;
		String nameHC = name.substring(0, 1).toUpperCase() + name.substring(1, name.length());
		return
			"public " + type + " get" + nameHC + "() {\n" +
			"\treturn " + name +";\n" +
			"}\n";
	}

	static String makeSetterString(PropertyInfo prop) throws NotFoundException {
		String type = prop.type_name;
		String name = prop.name;
		String nameHC = name.substring(0, 1).toUpperCase() + name.substring(1, name.length());
		return
			"public void set" + nameHC + "(" + type + " " + name + ") {\n" +
			"\tthis." + name + " = " + name + ";\n" +
			"}\n";
	}

	static String makeRPSFieldString() {
		return
			"private org.globus.wsrf.ResourcePropertySet resourcePropertySet;\n";
	}

	static String makeInitializeString(CtClass resourceC) throws ClassNotFoundException, NotFoundException {
		String tns = "http://gtrc.aist.go.jp/test2";  // XXX resourceInfo.tns;
		String code1 = "try {\n" +
			"\tresourcePropertySet = new org.globus.wsrf.impl.SimpleResourcePropertySet(new javax.xml.namespace.QName(\"" + tns + "\", \"" + resourceC.getSimpleName() + "Properties\"));\n";
		StringBuffer code2 = new StringBuffer("");
		for (PropertyInfo prop : propertyInfos(resourceC)) {
			String name = prop.name;
			String varName = prop.name + "RP";
			code2.append("\torg.globus.wsrf.ResourceProperty " + varName + " = new org.globus.wsrf.impl.ReflectionResourceProperty(new javax.xml.namespace.QName(\"" + tns +"\", \"" + name + "\"), \"" + name + "\", this);\n");
			code2.append("\tresourcePropertySet.add(" + varName + ");\n");
		}
		String code3 = "} catch (Exception e) {e.printStackTrace();}\n";
		return code1 + code2.toString() + code3;
	}

	static String makeGetResourcePropertySetString() {
		return
			"public org.globus.wsrf.ResourcePropertySet getResourcePropertySet() {\n" +
			"\treturn resourcePropertySet;\n" +
			"}\n";
	}

	public static void main(String[] args) throws NotFoundException, ClassNotFoundException, CannotCompileException, ResourceInfo.ResourceInfoException {
		ClassPool cp = ClassPool.getDefault();
		cp.insertClassPath(new ClassClassPath(ResourceHomeImpl.class));
		CtClass resourceC = cp.get(args[0]);
		//ResourceInfo resourceInfo = new ResourceInfo(resourceC, "gtrc.aist.go.jp", getTypeMapping(cp));
		for (PropertyInfo prop : propertyInfos(resourceC)) {
			System.out.println("==== makeGetterString ====");
			System.out.print(makeGetterString(prop));
			System.out.println("====================");
			System.out.println("==== makeSetterString ====");
			System.out.print(makeSetterString(prop));
			System.out.println("====================");
		}
		System.out.println("==== makeRPSFieldString ====");
		System.out.print(makeRPSFieldString());
		System.out.println("====================");
		System.out.println("==== makeInitializeString ====");
		System.out.print(makeInitializeString(resourceC));
		System.out.println("====================");
		System.out.println("==== makeGetResourcePropertySetString ====");
		System.out.print(makeGetResourcePropertySetString());
		System.out.println("====================");
	}
}
