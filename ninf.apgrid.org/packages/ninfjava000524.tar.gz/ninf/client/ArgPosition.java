package ninf.client;

import ninf.basic.*;
import ninf.client.*;

import java.io.IOException;
public class ArgPosition{
  public int functionIndex;
  public int argNum;

  public ArgPosition(NinfPacketInputStream is) throws NinfException{
    read(is);
  }

  public ArgPosition(int functionIndex, int argNum){
    this.functionIndex = functionIndex;
    this.argNum = argNum;
  }

  public void read(NinfPacketInputStream is) throws NinfException {
    functionIndex = is.readInt();
    argNum = is.readInt();
  }

  public int serialize(int argNums[]) {
    return argNums[functionIndex] + argNum;
  }

  public String toString(){
    return "pos("+ functionIndex + "," + argNum +")";
  }

  public boolean equals(Object o){
    if (!(o instanceof ArgPosition))
      return false;
    ArgPosition s = (ArgPosition)o;
    if (functionIndex == s.functionIndex && argNum == s.argNum)
      return true;
    return false;
  }


}
