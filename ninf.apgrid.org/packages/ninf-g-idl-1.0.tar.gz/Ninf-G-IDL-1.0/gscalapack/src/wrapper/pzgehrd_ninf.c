#define _WRAPPER_
/* $Id: pzgehrd_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define DCOMPLEX
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n
static	int worklen(int n,int ilo, int ihi) {
	  int ret=1;
	  int IROFFA, ICOFFA, IAROW, IHIP, ILROW, IHLP, ILCOL;
	  int INLQ,IOFF;
	  IOFF = ilo-1;
	  IHIP = ihi;
	  ILROW = ilo;
	  IHLP =  ihi-ilo+1+ilo-1;
	  ILCOL = ilo;
	  INLQ =  n-ilo+IOFF+1;
	  ret = n*n+n*max(IHIP+1,IHLP+INLQ);
	  if NEED_BUFF {
#define NB cbloc
#define NUMROC Cnumroc
#define RSRC_A 0
	    IROFFA = 0;
	    ICOFFA = 0;
	    IOFF = MOD( ilo-1, NB );
	    IAROW = INDXG2P( 1, NB, myprow, RSRC_A, nprow );
	    IHIP = NUMROC( ihi, NB, myprow, IAROW, nprow );
	    ILROW = INDXG2P( ilo, NB, myprow, RSRC_A, nprow );
	    IHLP = NUMROC( ihi-ilo+IOFF+1, NB, myprow, ILROW, nprow );
	    ILCOL = INDXG2P( ilo, NB, mypcol, CSRC_A, npcol );
	    INLQ = NUMROC( n-ilo+IOFF+1, NB, mypcol, ILCOL, npcol );
	    ret = NB*NB + NB*MAX( IHIP+1, IHLP+INLQ );
	  }
	  return ret;
}

void  pzgehrd_ninf(	 int n,
		 int ilo,
		 int ihi,
		 dcomplex global_a[],
		 int lda,
		 dcomplex global_tau[],
		 dcomplex work[],
		 int lwork,
		 int *info
)
/* "pzgehrd reduces a complex general distributed matrix A to upper Hessenberg form H by an unitary similarity transformation Q' * A * Q = H." */
/* OPTIONS */
{
	int maxldd;

	int maxlda;
	dcomplex *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
	int row_loca, col_loca;

	dcomplex *loctau=NULL;

	dcomplex *locwork=NULL;
	int llocwork;


	INITIALIZE();

	SCALAR( "int", n);
	SCALAR( "int", ilo);
	SCALAR( "int", ihi);
	SCALAR( "int", lda);
	SCALAR( "int", lwork);

	ROW( a);
	COL( a);
	MAXLDD( maxldd, a );
	maxlda = maxldd;

	MATRIX( "dcomplex", a, ROW_a, COL_a);
	VECTOR( "c", "dcomplex", tau, n-1);
	DISTRIBUTE( "dcomplex", a, ROW_a  , COL_a);

        llocwork = worklen(n, ilo, ihi);
	llocwork=max(lwork,llocwork);
	WORK(locwork,llocwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pzgehrd)( &n, &ilo, &ihi,
                               loca, &one, &one, desca,
                               loctau,
                               locwork, &llocwork, &linfo);

	GATHER( "dcomplex", a, ROW_a  , COL_a);
	vGATHER( "c", "dcomplex", tau, n-1);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
	  *info = linfo;
	} else {
	}

	FREE_MATRIX(a);
	FREE_VECTOR(tau);
        FREE(locwork);
	
}

