#define _WRAPPER_
/* $Id: pslasmsub_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define FLOAT
#include <gscalapack.h>
/* ? ? */
#error

#define ROW_a lda
#define COL_a n
static	int worklen(int i,int l) {
	  int ret=1;
	  int HBL;
	  ret = max(2*(i-l),1);
	  if NEED_BUFF {
	    HBL = rbloc;
	    ret =  2*ceil( ceil( (I-L),HBL ) ,
			   LCM(NPROW,NPCOL) );
	    // Here LCM is least common multiple, and NPROWxNPCOL is the
	    // logical grid size.
	  }
	  return ret;
}


void  pslasmsub_ninf(
		  float global_a[]
		  int lda,
		  int n,
		 int i,
		 int l,
		 int *k,
		 float smlnum,
		  float work[],
		 int lwork

)
/* "pslasmsub looks for a small subdiagonal element from the bottom of the matrix that it can safely set to zero." */
/* OPTIONS */
{

	int maxldd;

	int maxlda;
	float *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
	int row_loca, col_loca;

	int lock;

	float *locwork=NULL;
	int llocwork;

	INITIALIZE();

	SCALAR( "int", i);
	SCALAR( "int", l);
	SCALAR( "float", smlnum);
	SCALAR("int", lda);
	SCALAR("int", n);
	SCALAR( "int", lwork);
	
	ROW(a);
	COL(a);
	MAXLDD( maxldd, a );

	MATRIX("float", a, ROW_a, COL_a);
	DISTRIBUTE("float", a, ROW_a, COL_a);

	llocwork=worklen(i, l);
	llocwork = max(lwork,llocwork);
	WORK(locwork,llocwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pslasmsub)( loca, desca,
                                 &i, &l, &lock, &smlnum,
                                 locwork, &llocwork);

	RETRIEVE("int", &lock, 1);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
	  *info = linfo;
	  *k = lock;
	} else {
	}
        FREE_MATRIX(a);
        FREE(locwork);
}

