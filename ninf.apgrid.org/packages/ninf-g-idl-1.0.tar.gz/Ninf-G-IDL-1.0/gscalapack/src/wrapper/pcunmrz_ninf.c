#define _WRAPPER_
/* $Id: pcunmrz_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define SCOMPLEX
#include <gscalapack.h>
#define ROW_a lda
#define COL_a col_a
#define ROW_c ldc
#define COL_c n
static int worklen(char side, int m, int n) {
	  int ret;
	  int LCMP, IROFFA, ICOFFA, IACOL, MqA0, IROFFC, ICROW, ICCOL;
	  int ICOFFC;
	  int MpC0, NqC0;
	  int max_m_n;
	  max_m_n = max( m, n);
	  ret = MAX( (max_m_n*(max_m_n-1))/2, (max_m_n + max_m_n)*max_m_n )
	      +  max_m_n * max_m_n;
	  if NEED_BUFF {
	    LCMP = LCM(nprow,npcol) / NPROW;
	    IROFFA = MOD( IA-1, MB_A );
	    ICOFFA = MOD( JA-1, NB_A );
	    IACOL = INDXG2P( JA, NB_A, MYCOL, CSRC_A, NPCOL );
	    MqA0 = NUMROC( M+ICOFFA, NB_A, MYCOL, IACOL, NPCOL );
	    IROFFC = MOD( IC-1, MB_C ), ICOFFC = MOD( JC-1, NB_C );
	    ICROW = INDXG2P( IC, MB_C, MYROW, RSRC_C, NPROW );
	    ICCOL = INDXG2P( JC, NB_C, MYCOL, CSRC_C, NPCOL );
	    MpC0 = NUMROC( M+IROFFC, MB_C, MYROW, ICROW, NPROW );
	    NqC0 = NUMROC( N+ICOFFC, NB_C, MYCOL, ICCOL, NPCOL );
	    
	    if (chrcmp(side , 'L')==0)
	      ret = MAX( (MB_A*(MB_A-1))/2, ( MpC0 + MAX( MqA0 + NUMROC( NUMROC( M+IROFFC, MB_A, 0, 0, NPROW ), MB_A, 0, 0, LCMP ), NqC0 ) )*MB_A ) +  MB_A * MB_A;
	    else
	      ret = MAX( (MB_A*(MB_A-1))/2, (MpC0 + NqC0)*MB_A ) +  MB_A * MB_A;
	  }
	  return ret;
}

void  pcunmrz_ninf(	 char side,
		 char trans,
		 int m,	/*  m >= 0 */
		 int n,	/*  n >= 0 */
		 int k,	/* n >= k >= 0 */
		 int l,	
		 scomplex global_a[],
		 int lda,
		 scomplex global_tau[], // column
		 scomplex global_c[],
		 int ldc,
		 scomplex work[],	/* n >= k >= 0 */
		 int lwork,
		 int *info
)
/* "pcunmrz overwrites the general complex M-by-N distributed matrix C with\\n */
/*                        SIDE = 'L'           SIDE = 'R'\\n */
/*   TRANS = 'N':         Q * C                C  * Q\\n */
/*   TRANS = 'C':      Q**H * C                C * Q**H\\n */
/* where Q is a complex unitary distributed matrix defined as the product of K elementary reflectors   Q = H(1)' H(2)' . . . H(k)'  as returned by PCTZRZF. Q is of order M if SIDE = 'L' and of order N  if SIDE = 'R'." */
/* OPTIONS */
{

	int maxldd;

	int col_a;
	int maxlda;
	scomplex *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
	int row_loca, col_loca;

	scomplex *loctau=NULL;

	int maxldc;
	scomplex *locc=NULL;
	int descc[DESCLEN];
	int desc_gc[DESCLEN];
	int row_locc, col_locc;

	scomplex *locwork=NULL;
	int llocwork;

	INITIALIZE();

	SCALAR("char",side);
	SCALAR("char",trans);
	SCALAR("int",m);
	SCALAR("int",n);
	SCALAR("int",k);
	SCALAR("int",l);
	SCALAR("int",lda);
	SCALAR("int",ldc);
	SCALAR("int",lwork);

	if (chrcmp(side,'l')==0) col_a = m;
	else col_a = n;

	ROW(a );
	COL(a );
	ROW(c);
	COL(c);
	MAXLDD(maxldd,a );
	maxlda=maxldd;
	maxldc=maxldd;

	MATRIX("scomplex",a,ROW_a  ,COL_a );
	DISTRIBUTE("scomplex", a, ROW_a ,COL_a  );

	MATRIX("scomplex",c, ROW_c ,COL_c );
	DISTRIBUTE("scomplex", c,ROW_c  , COL_c );

	VECTOR("c", "scomplex",tau,k);
	vDISTRIBUTE("c","scomplex", tau, k);

	llocwork=worklen(side, m, n);
	llocwork=max(llocwork,lwork);
	WORK(locwork,llocwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pcunmrz)( &side, &trans,
                               &m, &n, &k, &l,
                               loca, &one, &one, desca,
                               loctau,
                               locc, &one, &one, descc,
                               locwork, &llocwork, &linfo);

	GATHER("scomplex", c,ROW_c  ,COL_c  );
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
            *info = linfo;
	} else {
	}

	FREE_MATRIX(a);
	FREE_VECTOR(tau);
	FREE_MATRIX(c);
	FREE(locwork);
        
}

