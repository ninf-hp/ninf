#define _WRAPPER_
/* $Id: pcgesvx_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define SCOMPLEX
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n
#define ROW_af ldaf
#define COL_af n
#define ROW_b ldb
#define COL_b nrhs
#define ROW_x ldx
#define COL_x nrhs
#define LOCc_a(n) Cnumroc( (n), NB, mypcol, 0, npcol)
#define LOCr_a(m) Cnumroc( (m), MB, myprow, 0, nprow)
	//	int ipivlen() {
	//            int ret = n;
	//            if (mypnum!=0) ret = LOCR_a(ROW_a)+MB;
	//             return ret;
	//	}

static        int worklen(int n) {
            int ret = 1;
	    int psgecon;
	    int psgerfs;
            psgecon = 4*n+max(2,n);
            psgerfs = 3*n;
            ret = max(psgecon,psgerfs) + n;
            if NEED_BUFF {
	      psgecon = 2*LOCr(N+MOD(IA-1,MB_A)) + 2*LOCc(N+MOD(JA-1,NB_A))
		+ MAX( 2, MAX( NB_A*MAX( 1, CEIL(NPROW-1,NPCOL) ),
			       LOCc(N+MOD(JA-1,NB_A)) +
			       NB_A*MAX( 1, CEIL(NPCOL-1,NPROW) ) ));
	      psgerfs =  3*LOCr( N + MOD(IA-1,MB_A) );
	      ret = max( psgecon, psgerfs ) + LOCr( COL_a );
	    }
            return ret;
}

static        int rworklen(int n) {
            int ret = 1;
            ret = 2*COL_a;
            if NEED_BUFF
	      ret =  2*LOCc(COL_a);

            return ret;
}
        

void  pcgesvx_ninf(	 char fact,
		 char trans,
		 int n,
		 int nrhs,
		 scomplex global_a[],
		 int lda,
		 scomplex global_af[],
		 int ldaf,
		 int global_ipiv[],
		 char *equed,
		 float global_r[],
		 float global_c[],
		 scomplex global_b[],
		 int ldb,
		 scomplex global_x[],
		 int ldx,
		 float *rcond,
		 float global_ferr[],
		 float global_berr[],
		 scomplex work[],
		 float rwork[],
		 int *info
)
/* "pcgesvx uses the LU factorization to compute the solution to a complex system of linear equations A * X = B, where A is an N-by-N matrix and X and B are N-by-NRHS matrices." */
/* OPTIONS */
{
    extern void FortranCall(pcgesvx)( char*, char*, int*, int*,
				      scomplex*, int*, int*, int*,
				      scomplex*, int*, int*, int*,
				      int*,
				      char*,
				      float*, float*,
				      scomplex*, int*, int*, int*,
				      scomplex*, int*, int*, int*,
				      float*,
				      float*, float*,
				      scomplex*, int*,
				      float*, int*,
				      int*);

	int maxldd;

	int maxlda;
	scomplex *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];

	int maxldaf;
	scomplex *locaf=NULL;
	int descaf[DESCLEN];
	int desc_gaf[DESCLEN];

	float locrcond[1];

	int *locipiv=NULL;
	float *locr=NULL;
	float *locc=NULL;

	int maxldb;
	scomplex *locb=NULL;
	int descb[DESCLEN];
	int desc_gb[DESCLEN];

	int maxldx;
	scomplex *locx=NULL;
	int descx[DESCLEN];
	int desc_gx[DESCLEN];

	float *locferr=NULL;
	float *locberr=NULL;

        scomplex *locwork=NULL;
        int llocwork;
	float *locrwork=NULL;
	int llocrwork;

	int row_loca, col_loca;
	int row_locaf, col_locaf;
	int row_locipiv, col_locipiv;
	int row_locb, col_locb;
	int row_locx, col_locx;


	INITIALIZE();

	SCALAR( "char", fact);
	SCALAR( "char", trans);
	SCALAR( "int", n);
	SCALAR( "int", nrhs);
	SCALAR( "int", lda);
	SCALAR( "int", ldb);
	SCALAR( "int", ldaf);
	SCALAR( "int", ldx);

	COMMON( "char", equed, 1);

	ROW( a);
	COL( a);
	ROW( af);
	COL( af);
	ROW( b);
	COL( b);
	ROW( x);
	COL( x);
	MAXLDD( maxldd, a );
	maxlda = maxldd;
	maxldaf = maxldd;
	maxldb = maxldd;
	maxldx = maxldd;

	MATRIX( "scomplex", a, ROW_a, COL_a);
	MATRIX( "scomplex", af, ROW_af, COL_af);
	MATRIX( "scomplex", b, ROW_b, COL_b);
	MATRIX( "scomplex", x, ROW_x, COL_x);
	VECTOR( "r", "int", ipiv, ROW_a);
        VECTOR( "r", "float", r, ROW_a);
        VECTOR( "c", "float", c, COL_a);
        VECTOR( "c", "float", ferr, COL_b);
        VECTOR( "c", "float", berr, COL_b);

	DISTRIBUTE( "scomplex", a, ROW_a  , COL_a);
	DISTRIBUTE( "scomplex", af, ROW_af  , COL_af);
	DISTRIBUTE( "scomplex", b, ROW_b  , COL_b);
	vDISTRIBUTE( "r", "float", r, ROW_a);
	vDISTRIBUTE( "c", "float", c, COL_a);
	vDISTRIBUTE( "r", "int", ipiv, ROW_a);

        llocwork=worklen(n);
        WORK( locwork, llocwork);
        llocrwork=rworklen(n);
        _work("float", &locrwork, llocrwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pcgesvx)( &fact, &trans, &n, &nrhs,
			       loca, &one, &one, desca,
			       locaf, &one, &one, descaf,
			       locipiv,
			       equed,
			       locr, locc,
			       locb, &one, &one, descb,
			       locx, &one, &one, descx,
			       locrcond,
			       locferr, locberr,
			       locwork, &llocwork,
			       locrwork, &llocrwork,
			       &linfo);

	GATHER( "scomplex", a, ROW_a  , COL_a);
	GATHER( "scomplex", af, ROW_af  , COL_af);
	GATHER( "scomplex", b, ROW_b  , COL_b);
	GATHER( "scomplex", x, ROW_x  , COL_x);
	vGATHER("r", "int" ,ipiv, ROW_a);

        vGATHER( "r", "float", r, ROW_a);
        vGATHER( "c", "float", c, COL_a);
	vGATHER( "c", "float", ferr, COL_b);
	vGATHER( "c", "float", berr, COL_b);

	RETRIEVE("char", equed, 1);        
	RETRIEVE("float", locrcond, 1);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
		*info = linfo;
		*rcond = *locrcond;
	} else {
	}

	FREE_MATRIX(a);
	FREE_MATRIX(af);
        FREE_MATRIX(b);
	FREE_MATRIX(x);
        
	FREE_VECTOR(ipiv);
	FREE_VECTOR(r);
	FREE_VECTOR(c);
	FREE_VECTOR(ferr);
	FREE_VECTOR(berr);

        FREE(locwork);
        FREE(locrwork);

	FREE_COMMON(equed);
}

