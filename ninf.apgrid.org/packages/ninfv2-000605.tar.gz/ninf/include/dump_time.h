#ifndef DUMP_TIME

#define DUMP_TIME_TICK()
#define DUMP_TIME_DUMP()
#define DUMP_TIME_OPEN()
#define DUMP_TIME_CLOSE()
#define DUMP_TIME_GETENV()
#define DUMP_TIME_SET_SKIP(k)

#endif 
