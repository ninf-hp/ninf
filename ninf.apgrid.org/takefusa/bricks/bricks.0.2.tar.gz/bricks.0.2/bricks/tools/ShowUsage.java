package bricks.tools;
import bricks.util.*;
import java.io.*;
import java.lang.reflect.*;

/**
 * ShowUsage shows usage of a specified class.<BR>
 **/
public class ShowUsage {

    /**
     * USAGE string 
     **/
    public static String usage() {
	return "java bricks.tool.ShowUsage [class name]\n";
    }

    public static String showUsage(String[] args) {

	String str = "";
	for (int i = 0; i < args.length; i++) {
	    try {
		Creator creator = 
		    (Creator)Class.forName(args[i] + "Creator").newInstance();
		str += creator.usage() + "\n";

	    } catch (ClassNotFoundException e) {
		try {
		    str += showScriptUsage(args[i]);
		} catch (BricksException be) {
		    return "ClassNotFoundException: " + args[i] + "Creator";
		}

	    } catch (InstantiationException e) {
		return "InstantiationException: " + args[i] + "Creator";

	    } catch (IllegalAccessException e) {
		return "IllegalAccessException: " + args[i] + "Creator";
	    }
	}
	return str;
    }

    protected static String showScriptUsage(String arg) throws BricksException {

	String key = arg.toLowerCase();
	try {
	    if (key.equalsIgnoreCase("bricks")) {
		return "# Bricks configuration files consist of the following lines.\n" +
		    "Packet\n" + "ResourceDB(s)\n" + 
		    "NetworkMonitor(s)\n" + "ServerMonitor(s)\n" +
		    "Predictor(s)\n" + "Scheduler(s)\n" + 
		    "ReplicaManager(s)\n" +
		    "Host(s)\n" + "Node(s)\n" + "Network(s)\n" + "Link(s)\n" +
		    "# Details of each line are shown by the following command:" + 
		    "# java bricks.tools.ShowUsage [word]";

	    } else if (key.equalsIgnoreCase("packet")) {
		return "Packet <double logicalPacketSize>";

	    } else if (key.equalsIgnoreCase("predictor")) {
		return ((Creator)Class.forName("bricks.scheduling.MetaPredictorCreator").newInstance()).usage();

	    } else if (key.equalsIgnoreCase("scheduler")) {
		return ((Creator)Class.forName("bricks.scheduling.SchedulerCreator").newInstance()).usage();

	    } else if (key.equalsIgnoreCase("replicamanager")) {
		return ((Creator)Class.forName("bricks.scheduling.ReplicaManagerCreator").newInstance()).usage();

	    } else if (key.equalsIgnoreCase("resourcedb")) {
		return ((Creator)Class.forName("bricks.scheduling.ResourceDBCreator").newInstance()).usage();

	    } else if (key.equalsIgnoreCase("networkmonitor")) {
		return ((Creator)Class.forName("bricks.scheduling.NetworkMonitorCreator").newInstance()).usage();

	    } else if (key.equalsIgnoreCase("servermonitor")) {
		return ((Creator)Class.forName("bricks.scheduling.ServerMonitorCreator").newInstance()).usage();

	    } else if (key.equalsIgnoreCase("host")) {
		return ((Creator)Class.forName("bricks.environment.HostCreator").newInstance()).usage();

	    } else if (key.equalsIgnoreCase("network")) {
		return ((Creator)Class.forName("bricks.environment.ServerCreator").newInstance()).usage();

	    } else if (key.equalsIgnoreCase("node")) {
		return ((Creator)Class.forName("bricks.environment.ForwardNodeCreator").newInstance()).usage();

	    } else if (key.equalsIgnoreCase("link")) {
		return ((Creator)Class.forName("bricks.environment.LinkCreator").newInstance()).usage();

	    } else {
		throw new BricksException();
	    }

	} catch (ClassNotFoundException e) {
	    throw new BricksException();

	} catch (InstantiationException e) {
	    throw new BricksException();

	} catch (IllegalAccessException e) {
	    throw new BricksException();
	}
    }

    /**
     * The entry 
     */
    public static void main(String[] args) {
	if (args.length < 1)
	    BricksUtil.abort(ShowUsage.usage());
	System.out.println(ShowUsage.showUsage(args));
    }
}



