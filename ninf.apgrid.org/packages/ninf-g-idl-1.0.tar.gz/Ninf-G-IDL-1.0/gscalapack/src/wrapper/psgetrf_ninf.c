#define _WRAPPER_
/* $Id: psgetrf_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define FLOAT
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n
void  psgetrf_ninf(	 int m,
		 int n,
		 float global_a[],
		 int lda,
		 int global_ipiv[],
		 int *info
)
/* "psgetrf computes an LU factorization of a general M-by-N distributed matrix A using partial pivoting with row interchanges." */
/* OPTIONS */
{
    extern void FortranCall(psgetrf)( int*, int*,
				      float*, int*, int*, int*,
				      int*,
				      int*);

	int maxldd;

	int maxlda;
	float *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
	int row_loca, col_loca;

	int *locipiv=NULL;

	INITIALIZE();

	SCALAR( "int", m);
	SCALAR( "int", n);
	SCALAR( "int", lda);

	ROW( a);
	COL( a);
	MAXLDD( maxldd, a );
	maxlda = maxldd;

	MATRIX( "float", a, ROW_a, COL_a);
	DISTRIBUTE( "float", a, ROW_a  , COL_a);

	VECTOR( "r", "int", ipiv, m);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(psgetrf)( &m, &n,
                               loca, &one, &one, desca,
                               locipiv,
                               &linfo);

	GATHER( "float", a, ROW_a  , COL_a);
	vGATHER( "r", "int", ipiv, m);

	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
		*info = linfo;
	} else {
	}

	FREE_MATRIX(a);
	FREE_VECTOR(ipiv);
	
}

