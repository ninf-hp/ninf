#define _WRAPPER_
/* $Id: pclatra_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define SCOMPLEX
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n
void  pclatra_ninf(	 int n,
		 scomplex global_a[],
		 int lda,
		 scomplex *ret /* return value */
)
/* "pclatra computes the trace of an N-by-N distributed matrix A. " */
/* OPTIONS */
{
  extern  FortranCall(pclatra)(scomplex*, int*, scomplex* ,int *, int *, int *);

	int maxldd;

	int maxlda;
	scomplex *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
	int row_loca, col_loca;

	scomplex locret[1];

	INITIALIZE();

	SCALAR( "int", n);
	SCALAR("int",lda);

	ROW( a);
	COL( a);
	MAXLDD( maxldd, a );
	maxlda = maxldd;

	MATRIX( "scomplex", a, ROW_a, COL_a);
	DISTRIBUTE( "scomplex", a, ROW_a  , COL_a);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranReturnComplex(pclatra, ( locret,
                              &n,
                              loca, &one, &one, desca) );

	RETRIEVE("float", locret, 1);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
	  *ret = *locret;
	} else {
	}

	FREE_MATRIX(a);
}

