#define _WRAPPER_
/* $Id: pcposv_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define SCOPLEX
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n
#define ROW_b ldb
#define COL_b nrhs
void  pcposv_ninf(	 char uplo,
		 int n,
		 int nrhs,
		 scomplex global_a[],
		 int lda,
		 scomplex global_b[],
		 int ldb,
		 int *info
)
/* "pcposv computes the solution to a complex system of linear equations A * X = B, where A is an N-by-N hermitian distributed positive definite matrix and X and B are N-by-NRHS distributed matrices." */
/* OPTIONS */
{
    extern void FortranCall(pcposv)( char*, int*, int*,
				     scomplex*, int*, int*, int*,
				     scomplex*, int*, int*, int*,
				     int*);
	int maxldd;

	int maxlda;
	scomplex *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];

	int maxldb;
	scomplex *locb=NULL;
	int descb[DESCLEN];
	int desc_gb[DESCLEN];

	int row_loca, col_loca;
	int row_locb, col_locb;

	INITIALIZE();

	SCALAR( "char", uplo);
	SCALAR( "int", n);
	SCALAR( "int", nrhs);
	SCALAR( "int", lda);
	SCALAR( "int", ldb);

	ROW( a);
	COL( a);
	ROW( b);
	COL( b);
	MAXLDD( maxldd, a );
	maxlda = maxldd;
	maxldb = maxldd;

	trMATRIX( uplo, "scomplex", a, ROW_a, COL_a);
	MATRIX( "scomplex", b, ROW_b, COL_b);
	trDISTRIBUTE( uplo, "scomplex", a, ROW_a  , COL_a);
	DISTRIBUTE( "scomplex", b, ROW_b  , COL_b);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pcposv)( &uplo, &n, &nrhs,
                              loca, &one, &one, desca,
                              locb, &one, &one, descb,
                              &linfo);

	GATHER( "scomplex", a, ROW_a  , COL_a);
	GATHER( "scomplex", b, ROW_b  , COL_b);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
		*info = linfo;
	} else {
	}

	FREE_MATRIX(a);
	FREE_MATRIX(b);
	
}

