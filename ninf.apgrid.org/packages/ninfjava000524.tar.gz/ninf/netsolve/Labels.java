package ninf.netsolve;
public class Labels {
  public static final int NUM_LANGS = 3;

  public static final int ENGLISH = 0;
  public static final int ITALIAN = 1;
  public static final int FRENCH = 2;

  public static int language = ENGLISH;

  public static String lang[] = {
    "English",  
    "Italian",
    "French"
  };

  public static String no_agent[] = {
    "You must enter an agent.",   // English
    "Devi introdurre il nome di un agente."    ,// Italian
    "Vous devez taper le nom d'un agent."   // French
  };

  public static String no_problems[] = {
    "Agent has no problems.  Try again later.",   // English
    "L'agent non ha problemi. Prova piu' tardi."    ,// Italian
    "Aucun problemes disponibles. Essayez plus tard."   // French
  };

  public static String no_connection[] = {
    "Could not establish connection - ",   // English
    "Non e' stato possibile stabilire una connessione."    ,// Italian
    "Impossible d'etablir la connection - "   //French
  };

  public static String info_error[] = {
    "Error getting server information: ",   // English
    "Errore nel ricevere informazioni dal server."    ,// Italian
    "Erreur en recevant l'informtation sur le serveur."    // French
  };

  public static String help[] = {
    "Help",   // English
    "Aiuto"    ,// Italian
    "Aide"    // French
  };

  public static String no_selected[] = {
    "No problem selected.",   // English
    "Nessun problema selezionato."    ,// Italian
    "Aucun probleme n'est selectionne."    // French
  };

  public static String problems[] = {
    "Problems:",   // English
    "Problemi:"    ,// Italian
    "Problemes:"    // French
  };

  public static String desc[] = {
    "Description:",   // English
    "Descrizione:"    ,// Italian
    "Description:"    // French
  };

  public static String inputs[] = {
    "Inputs:",   // English
    "Inputs:"    ,// Italian
    "Entrees:"    // French
  };

  public static String outputs[] = {
    "Outputs:",   // English
    "Outputs:"    ,// Italian
    "Sorties:"    // French
  };

  public static String in_desc[] = {
    "Input Description:",   // English
    "Descrizione degli Input:"    ,// Italian
    "Description des Entrees:"    // French
  };

  public static String out_desc[] = {
    "Output Description:",   // English
    "Descrizione degli Output:"    ,// Italian
    "Description des Sorties :"    // French
  };

  public static String solve[] = {
    "Solve",   // English
    "Risolvere"    ,// Italian
    "Resoudre"    // French
  };

  public static String quit[] = {
    "Quit",   // English
    "Esci"    ,// Italian
    "Quitter"    // French
  };

  public static String close[] = {
    "Close",   // English
    "Chiudi"    ,// Italian
    "Fermer"    // French
  };

  public static String update[] = {
    "   Update    ",   // English
    "  Aggiorna   "    ,// Italian
    "Mise-a-jour"    // French
  };

  public static String serv_info[] = {
    "  Server Info  ",   // English
    "Info dal server"    ,// Italian
    "Info Serveur"    // French
  };

  public static String agent[] = {
    "NetSolve Agent",   // English
    "NetSolve Agent"    ,// Italian
    "Agent NetSolve"    // French
  };

  public static String contact[] = {
    "  Contact/Update  ",   // English
    "Contatta/Aggiorna"    ,// Italian
    "Contact/m-a-jour"    // French
  };

  public static String status[] = {
    "Status:",   // English
    "Status:"    ,// Italian
    "Statut:"    // French
  };

  public static String cancel[] = {
    "Cancel",   // English
    "Cancella"    ,// Italian
    "Annuler"    // French
  };

  public static String compute[] = {
    "Compute",   // English
    "Computa"    ,// Italian
    "Calculer"    // French
  };

  public static String browse[] = {
    "Browse",   // English
    "Cerca"    ,// Italian
    "Chercher"    // French
  };

  public static String sample_data[] = {
    "Sample Data",   // English
    "Dati di Esempio"    ,// Italian
    "Example"    // French
  };

  public static String file_input[] = {
    "File Input",   // English
    "File di Input"    ,// Italian
    "Fichier d'Entree"    // French
  };

  public static String data_input[] = {
    "Data Input",   // English
    "Dati di Input"    ,// Italian
    "Donnee d'Entree"    // French
  };

  public static String url_input[] = {
    "URL Input",   // English
    "URL Input"    ,// Italian
    "URL d'Entree"    // French
  };

  public static String ready[] = {
    "Ready...",   // English
    "Pronto..."    ,// Italian
    "Pret..."    // French
  };

  public static String data[] = {
    "Data:",   // English
    "Dati:"    ,// Italian
    "Donnees:"    // French
  };

  public static String dismiss[] = {
    "Dismiss",   // English
    "Abbandona"    ,// Italian
    "Interrompre"    // French
  };

  public static String save_data[] = {
    "Save this Data",   // English
    "Salva questi Dati"    ,// Italian
    "Sauver ces Donnees"    // French
  };

  public static String invalid_integer[] = {
    "Not a valid integer value",   // English
    "Valore intero non valido"    ,// Italian
    "Ceci n'est pas un entier"    // French
  };

  public static String invalid_char[] = {
    "Not a valid character value",   // English
    "Carattere non valido"    ,// Italian
    "Ceci n'est pas un caractere"    // French
  };

  public static String invalid_float[] = {
    "Not a valid single-precision floating point value: ",   // English
    "Floating point a singola-precisione non valido: "    ,// Italian
    "Ceci n'est pas un reel simple precision: "    // French
  };

  public static String invalid_double[] = {
    "Not a valid double-precision floating point value: ",   // English
    "Floating point a doppia-precisione non valido: "    ,// Italian
    "Ceci n'est pas un reel double precision: "    // French
  };

  public static String char_expected[] = {
    "Expecting a character, not a string: ",   // English
    "Si aspetta un carattere, non una stringa: "    ,// Italian
    "Ceci devrait etre un caractere, pas une chaine: "    // French
  };

  public static String invalid_complex[] = {
    "Badly formed complex number: ",   // English
    "Numero complesso mal formulato: "    ,// Italian
    "Nombre complexe invalide: "    // French
  };

  public static String incomplete_complex[] = {
    "Incomplete complex number: ",   // English
    "Numero complesso incompleto: "    ,// Italian
    "Nombre complexe incomple: "    // French
  };

  public static String uneven_matrix[] = {
    "Rows of Matrix not even.",   // English
    "Numero delle righe della matrice non dispari."    ,// Italian
    "Les lignes de la matrice ne sont pas regulieres."    // French
  };

  public static String no_imaginary[] = {
    "Badly formed complex number - no imaginary part: ",   // English
    "Numero complesso mal formato - mancanza di una parte immaginaria: "    ,// Italian
    "Nombre complexe invalide - pas de partie imaginaire: "    // French
  };

  public static String empty_input[] = {
    "Empty input.",   // English
    "Nessun input"    ,// Italian
    "Pas d'Entrees"    // French
  };

  public static String invalid_file[] = {
    "Filename must end in .c or .f",   // English
    "Il file deve finire in .c o .f"    ,// Italian
    "Les fichiers doivent avoir l'extension .c ou .f"    // French
  };

  public static String no_file[] = {
    "File not found: ",   // English
    "File non trovato"    ,// Italian
    "Fichier non trouve"   // French
  };

  public static String checking_data[] = {
    "Checking data for errors...",   // English
    "Controllo dati per errori..."    ,// Italian
    "Controle d'erreur..."    // French
  };

  public static String bad_url[] = {
    "Bad URL",   // English
    "URL sbagliato"    ,// Italian
    "URL malformee"    // French
  };

  public static String stream_err[] = {
    "Couldn't open stream to url: ",   // English
    "Non e' stato possibile aprire un flusso di dati con l'url: "    ,// Italian
    "Impossible d'ouvrir l'URL: " // French
  };

  public static String no_input[] = {
    "Error - you must enter a file or some data for input ",   // English
    "Errore - devi introdurre un file o dei dati per l'input "    ,// Italian
    "Erreur - vous devez entrer un fichier ou des donnees"    // French
  };

  public static String good_data[] = {
    "Data is OK...",   // English
    "I dati sono OK..."    ,// Italian
    "Les donnees sont OK..."    // French
  };

  public static String submitting[] = {
    "Submitting job...",   // English
    "Sto' sottoponendo il lavoro..."    ,// Italian
    "J'envoie la requete..."    // French
  };

  public static String no_submit[] = {
    "Not submitting your data because of the following errors: ",   // English
    "Non e' stato possibile sottoporre i dati a causa dei seguenti errori:"   ,// Italian
    "Impossible de soumettre la requete a cause des erreurs suivantes:"   // French
  };
 
  public static String input[] = {
    "Input ",   // English
    "Input"    ,// Italian
    "Entrees"    // French
  };
 
  public static String bad_data[] = {
    "Bad Data",   // English
    "Dati non corretti"    ,// Italian
    "Donees incorrectes"    // French
  };
 
  public static String upf[] = {
    "This is a user-provided function.\nCheck the problem description for the correct calling sequence.",   // English
    "Questa e' una funzione dara dall'utente.\nControlla la descrizione del problema per una corretta sequenza di chiamata."    ,// Italian
    "Ceci est une function fournie par l'utilisateur.\nAnalyse de la description du probleme pour la list d'arguments."    // French
  };
 
  public static String input_title[] = {
    "Data Input Screen - '",   // English
    "Schermo Dati di Input - '"    ,// Italian
    "Fenetre pour les Donnees d'Entree - '"    // French
  };
 
  public static String output_title[] = {
    "Data Output Screen - '",   // English
    "Schermo Dati di Output"    ,// Italian
    "Fenetre pour les Donnees de Sortie"    // French
  };
 
  public static String warning_title[] = {
    "NetSolve Warning",   // English
    "Segnale di Attenzione di Netsolve"    ,// Italian
    "Alerte Netsolve"   // French
  };
 
  public static String server_title[] = {
    "Server Information",   // English
    "Informazione del Server"    ,// Italian
    "Information sur les serveurs"    // French
  };

  public static String upf_failed[] = {
    "UPF Failed.",   // English
    "UPF Fallita."    ,// Italian
    "UPF invalide."    //French
  };

  public static String upf_unsafe[] = {
    "UPF Unsafe.",   // English
    "UPF non Salvata."    ,// Italian
    "UPF dangereuse."    // French
  };

  public static String no_solution[] = {
    "No Solution",   // English
    "Nessuna Soluzione"    ,// Italian
    "Pas de Solution"    // French
  };

  public static String linear_failed[] = {
    "Failure",   // English
    "Fallimento"    ,// Italian
    "Echec "    // French
  };

  public static String dm_mismatch[] = {
    "Dimension Mismatch",   // English
    "Errore Dimensionale"    ,// Italian
    "Erreur de Dimensions"    // French
  };

  public static String bad_values[] = {
    "Bad Values.",   // English
    "Valori non Corretti"    ,// Italian
    "Donnees incorrectes"    // French
  };

  public static String bad_upf[] = {
    "Bad UPF.",   // English
    "UPF Sbagliato"    ,// Italian
    "UPF incorrecte"    // French
  };

  public static String unknown_err[] = {
    "Unknown Error solving problem.",   // English
    "Errore Sconosciuto durante lo svolgimento del problema."    ,// Italian
    "Erreur inconnue en resolvant le probleme."    // French
  };

  public static String contacting[] = {
    "Contacting agent...",   // English
    "Sto contattando l'agent..."    ,// Italian
    "Je contacte l'agent..."    // French
  };

  public static String internal_err[] = {
    "Internal NetSolve Error.  Please Try Again.",   // English
    "Errore Interno di Netsolve. Perfavore prova piu' tardi."    ,// Italian
    "Erreur interne de Netsolve. Essayez plus tard."    // French
  };

  public static String contact_err[] = {
    "Can't contact agent: ",   // English
    "Non riesco a contattare l'agent: "    ,// Italian
    "Impossible de contacter l'agent: "    // French
  };

  public static String no_servers[] = {
    "No servers available!",   // English
    "Nessun server disponibile!"    ,// Italian
    "Aucun server disponible!"    // French
  };

  public static String trying[] = {
    "Trying to contact\nserver: ",   // English
    "Sto' cercando di contattare\nil server: "    ,// Italian
    "J'essaye de contacter\nun serveur: "    // French
  };

  public static String connected[] = {
    "Connected to: ",   // English
    "Collegato a: "    ,// Italian
    "Connecte a: "    // French
  };

  public static String sending[] = {
    "Sending data...",   // English
    "Sto' mandando i dati..."    ,// Italian
    "J'envoie les donnees ..."    // French
  };

  public static String waiting[] = {
    "Waiting for answer...",   // English
    "Attendo per una risposta..."    ,// Italian
    "J'attends une reponse..."    // French
  };

  public static String got_answer[] = {
    "Got answer...",   // English
    "Risposta presa..."    ,// Italian
    "J'ai recu une reponse ..."    // French
  };

  public static String solve_error[] = {
    "Error solving problem:  ",   // English
    "Errore nella soluzione del problema:"    ,// Italian
    "Erreur en resolvant le probleme:"    // French
  };

  public static void set_lang(int lang) {
    switch(lang) {
      case ENGLISH:
        System.out.println("setting lang to english");
        language = lang;
        break;
      case ITALIAN:
        System.out.println("setting lang to italian");
        language = lang;
        break;
      case FRENCH:
        System.out.println("setting lang to French");
        language = lang;
        break;
      default:
        System.err.println("set_lang() warning: " + 
           "Unsupported language: " + lang);
    }
  }
}
