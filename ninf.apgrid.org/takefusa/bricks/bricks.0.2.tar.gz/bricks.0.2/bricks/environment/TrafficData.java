package bricks.environment;
import java.util.*;
import bricks.util.*;

public abstract class TrafficData extends Data implements Cloneable {

    public double dataSize;
    public TrafficData originalData = this;

    public abstract String getName();

    protected Vector listOfRoute;
    protected Node currentNode;
    protected int indexOfCurrentNode = 0;

    // for RequestedData and ReplicaData
    public DataFragment dataFragment = null;
    public Disk dataSourceDisk = null;

/************************* public method *************************/
    public String toOriginalString() {
	return this + "(" + listOfRoute + ") : " + 
	    Format.format(timeEventComes, 3) + ", " + 
	    Format.format(dataSize, 3) + "\n";
    }

    /** 
     * generates a clone of the TrafficData.
     */
    public synchronized Object clone() {
        try {
            TrafficData d = (TrafficData)super.clone();
	    d.dataSize = this.dataSize;
	    d.timeEventComes = this.timeEventComes;
            return d;
        } catch (CloneNotSupportedException e) {
            // this shouldn't happen, since we are Cloneable
            throw new InternalError();
        }
    }

    // overriden by RequestedData and ReplicaData
    public void gotoNextNode(double currentTime) {
	if (indexOfCurrentNode < listOfRoute.size()) {
	    currentNode = (Node)listOfRoute.elementAt(++indexOfCurrentNode);
	} else {
	    error(getName() + " - No more nextNode Element [" + 
		  listOfRoute + "]");
	}
	currentNode.schedule(currentTime, this);
    }

    public Vector getSubList(double currentTime){
	//System.out.println(vectorToString(listOfRoute));
	return (Vector)listOfRoute.clone();
    }

    public void updateProcessingDuration(
	double currentTime, double throughput
    ) {
	processingDuration = dataSize / throughput;
    }

    // only TrafficData
    public void updateTimeEventComes(double currentTime, double interval) {
	timeEventComes = currentTime + interval;
    }

    public Node nextNode() {
	Node node = null;
	try {
	    node = (Node)listOfRoute.elementAt(indexOfCurrentNode + 1);
	} catch (ArrayIndexOutOfBoundsException e) {
	    e.printStackTrace();
	    BricksUtil.abort(this + ": listOfRoute = " + listOfRoute);
	}
	return node;
    }

    public Node getNodeAt(int index) {
	return (Node)listOfRoute.elementAt(index);
    }

    public Vector getListOfRoute() {
	return (Vector)listOfRoute.clone();
    }

    public int getIndexOfCurrentNode() {
	return indexOfCurrentNode;
    }

    protected String generateId() {
	return  getName() + serialNumber++;
    }

    /* for debug */
    public String showListOfRoute() {
	return listOfRoute.toString();
    }

    public double getDataSize() {
	return dataSize;
    }

/************************* protected method *************************/
    protected String vectorToString(Vector vec) {
	Enumeration e = vec.elements();
	String str = null;
	while (e.hasMoreElements()) {
	    str += e.nextElement() + ", ";
	}
	return str;
    }
}


