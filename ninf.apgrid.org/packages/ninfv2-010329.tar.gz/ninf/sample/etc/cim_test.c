#include <stdio.h>

#include "ninf_stub.h"
#include "ninf_cim.h"

#define N 10

typedef struct c_pointer_handler{
  void * pointer;
  int ndim;
  int dim_size[10];
  int current[10];
  DATA_TYPE data_type;
} c_pointer_handler;

c_pointer_handler * new_c_pointer_handler(void * pointer, int ndim, int * dim_size, 
					  DATA_TYPE data_type){
  int i;
  c_pointer_handler * tmp = (c_pointer_handler *)malloc(sizeof(c_pointer_handler));
  tmp->pointer = pointer;
  tmp->ndim = ndim;
  for (i = 0; i < ndim; i++){
    tmp->dim_size[i] = dim_size[i];
    tmp->current[i] = 0;
  }
  tmp->data_type = data_type;
  return tmp;
}

int ninf_cim_init_c(obj_handler h){
  c_pointer_handler * handler = (c_pointer_handler *)h;
  int i;
  for (i = 0; i < handler->ndim; i++){
    handler->current[i] = 0;
  }
  return CIM_OK; 
}
int ninf_cim_finalize_c(obj_handler  h){
  return CIM_OK; 
}
int ninf_cim_destruct_c(obj_handler  h){
  return CIM_OK; 
}

int ninf_cim_proceed_c(obj_handler h, int rank, int n){
  c_pointer_handler * handler = (c_pointer_handler *)h;
  int i;
  for (i = 0; i < rank; i++)
    handler->current[i] = 0;
  handler->current[rank] += n;
  return CIM_OK;
}

char * calc_pointer (c_pointer_handler * handler){
  char * tmp = (char *)(handler->pointer);
  int i, size;
  size = handler->current[handler->ndim];
  for (i = handler->ndim - 1; i >= 0; i--){
    size *= handler->dim_size[i];
    size += handler->current[i];
  }
  tmp += type_size[handler->data_type] * size;
  return tmp;
}

int ninf_cim_get_c(obj_handler h, void * p, DATA_TYPE d){
  c_pointer_handler * handler = (c_pointer_handler *)h;  
  char * tmp;
  int i;
  if (d != handler->data_type)
    return CIM_ERROR_TYPE_MISMATCH;
  for (i = 0; i < handler->ndim; i++)
    if (handler->current[i] >= handler->dim_size[i])
      return CIM_ERROR_ARRAY_BOUND;
  tmp = calc_pointer(handler);
  memcpy(p, tmp, type_size[d]);
  return CIM_OK;
}

int ninf_cim_put_c(obj_handler h, void * p, DATA_TYPE d){
  c_pointer_handler * handler = (c_pointer_handler *)h;  
  char * tmp;
  int i;
  if (d != handler->data_type)
    return CIM_ERROR_TYPE_MISMATCH;
  for (i = 0; i < handler->ndim; i++)
    if (handler->current[i] >= handler->dim_size[i])
      return CIM_ERROR_ARRAY_BOUND;
  tmp = calc_pointer(handler);
  memcpy(tmp, p, type_size[d]);
  return CIM_OK;
}

/******************** Test Main *********************/

main(int argc, char ** argv){
  double A[N][N], B[N][N], C[N][N], C0[N][N];
  int i, j;
  /*  ninf_debug_flag = 1;     */

  argc = Ninf_parse_arg(argc, argv);
  
  Ninf_set_cim_funcs(ninf_cim_init_c,
		ninf_cim_finalize_c, 
		ninf_cim_proceed_c,
		ninf_cim_get_c,
		ninf_cim_put_c,
		ninf_cim_destruct_c);
    for(i = 0; i < N; i++)
      for(j = 0; j < N; j++){
	  A[i][j] = i + 0.1 * j;
	  B[i][j] = 1 + i + 0.1 * j;
      }

  printf("mmul_testing: ");
  {
    c_pointer_handler * args[4];
    int result;
    long n = N;
    int dim[2];
    dim[0] = N;
    dim[1] = N;

    args[0] = new_c_pointer_handler(&n, 0, NULL, DT_LONG);
    args[1] = new_c_pointer_handler(A, 2, dim, DT_DOUBLE);
    args[2] = new_c_pointer_handler(B, 2, dim, DT_DOUBLE);
    args[3] = new_c_pointer_handler(C, 2, dim, DT_DOUBLE);

    if (Ninf_cim_main("test/matmul", args) != NINF_OK){
      printf("failed\n");
      Ninf_perror("cim:");
    }
    mmul(N,A,B,C0);
    for(i = 0; i < N; i++)
      for(j = 0; j < N; j++){
	if(C[i][j] != C0[i][j]){ 
	  printf("C[%d][%d]= %e != %e\n",
		 i,j,C[i][j],C0[i][j]);
	  exit(1);
	}
      }
    printf("\tOK\n");
    exit(0);
  }
}

/* test routine */
mmul(n,A,B,C)
     double *A,*B,*C;
{
    double t;
    int i,j,k;

    for (i=0;i<n;i++) {
	for (j=0;j<n;j++) {
	    t = 0;
	    for (k=0;k<N;k++){
		t += A[i*n + k] * B[k*n+j];	/* inner product */
	    }
	    C[i*n+j] = t;
	}
    }
}

