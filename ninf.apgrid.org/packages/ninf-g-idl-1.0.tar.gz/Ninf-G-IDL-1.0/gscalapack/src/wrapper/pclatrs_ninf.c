#define _WRAPPER_
/* $Id: pclatrs_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define SCOMPLEX
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n
static	int worklen() {
	  int ret=1;
	  ret=10;
	  return ret;
}


void  pclatrs_ninf(	 char  uplo,
		 char  trans,
		 char  diag,
		 char normin,
		 int  n,
		 scomplex global_a[],
		 int lda,
		 scomplex global_x[],
		 float *scale,
		 float  cnorm[],
		 int *info
)
/* "pclatrs solves a triangular system. This routine in UNFINISHED at this time, but will be part of the next release." */
/* OPTIONS */
{
extern void  FortranCall(pclatrs)( char*, char*, char*, char*, int*,
				   scomplex*, int*, int*, int*,
				   scomplex*, int*, int*, int*,
				   float*, float*,
				   scomplex*);

	int maxldd;

	int maxlda;
	scomplex *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
	int row_loca, col_loca;

	scomplex *locx=NULL;
	int descx[DESCLEN];

	float locscale[1];
	
	scomplex *locwork=NULL;
	int llocwork;


	INITIALIZE();

	SCALAR("char", uplo);
	SCALAR("char", trans);
	SCALAR("char", diag);
	SCALAR("char", normin);
	SCALAR("int", n);
	SCALAR("int",lda);

	COMMON("float", cnorm, n);
	
	ROW(a);
	COL(a);
	MAXLDD( maxldd, a );
	maxlda= maxldd;

	MATRIX("scomplex", a, ROW_a, COL_a);
	DISTRIBUTE( "scomplex", a, ROW_a, COL_a);

	VECTOR("c", "scomplex", x, n);
	vDISTRIBUTE("c", "scomplex", x, n);
	Cdescinit( descx, 1, n, 1, cbloc, 0, 0,PARA_CTXT, 1, &linfo);

	llocwork=worklen();
	WORK(locwork,llocwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	  FortranCall(pclatrs)( &uplo, &trans, &diag, &normin, &n,
				loca, &one, &one, desca,
				locx, &one, &one, descx,
				locscale, cnorm, locwork);

	vGATHER("c", "scomplex", x, n);

	RETRIEVE("float", locscale, 1);
	RETRIEVE("float", cnorm, n);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
	  *info = linfo;
	  *scale = locscale[0];
	} else {
	}
	FREE_COMMON(cnorm);
	FREE_MATRIX(a);
        FREE(locwork);
	
}

