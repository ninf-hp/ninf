#define _WRAPPER_
/* $Id: pslarf_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define FLOAT
#include <gscalapack.h>

#define ROW_c ldc
#define COL_c n
static	int worklen(char side, int m, int n, int incv) {
	  int ret=1;
	  int LCMP, LCMQ, IROFFC, ICOFFC, ICROC, ICCOL, MpC0, NqC0;
	  int IVROW, IVCOL;
          int ICROW;

	  if (incv == 1) {
		  if (chrcmp(side, 'L')==0)
			  ret = max(m,n);
		  else if (chrcmp(side , 'R')==0)
			  ret = n + MAX( MAX( 1, m ), n );
	  } else {
	      if (chrcmp(side , 'L')==0)
		      ret = m + MAX( MAX( 1, n), m );
	      else if ( chrcmp(side, 'R')==0)
		      ret = max(m,n);
	  }

	  if NEED_BUFF {

#define LCM Cilcm( nprow, npcol )
#define IV 1
#define JV 1
#define MB_C MB
#define NB_C NB
#define MB_V MB
#define NB_V NB
#define RSRC_C 0
#define CSRC_C 0              
#define RSRC_V 0
#define CSRC_V 0              
	    LCMP = LCM / NPROW;
	    LCMQ = LCM / NPCOL;

	    IROFFC = MOD( IC-1, MB_C ); ICOFFC = MOD( JC-1, NB_C );
	    ICROW = INDXG2P( IC, MB_C, MYROW, RSRC_C, NPROW );
	    ICCOL = INDXG2P( JC, NB_C, MYCOL, CSRC_C, NPCOL );
	    IVROW = INDXG2P( IV, MB_V, MYROW, RSRC_V, NPROW );
	    IVCOL = INDXG2P( JV, NB_V, MYCOL, CSRC_V, NPCOL );
	    MpC0 = NUMROC( M+IROFFC, MB_C, MYROW, ICROW, NPROW );
	    NqC0 = NUMROC( N+ICOFFC, NB_C, MYCOL, ICCOL, NPCOL );

	    if (incv == 1) {
	      if (chrcmp(side, 'L')==0)
		if (IVCOL = ICCOL)
		  ret = NqC0;
		else
		  ret = MpC0 + MAX( 1, NqC0 );
	      else if (chrcmp(side , 'R')==0)
		ret = NqC0 + MAX( MAX( 1, MpC0 ), NUMROC( NUMROC(N+ICOFFC,NB_V,0,0,NPCOL ),NB_V,0,0,LCMQ ) );
	    } else {
	      if (chrcmp(side , 'L')==0)
		ret = MpC0 + MAX( MAX( 1, NqC0 ), NUMROC( NUMROC( M+IROFFC,MB_V,0,0,NPROW ),MB_V,0,0,LCMP ) );
	      else if ( chrcmp(side, 'R')==0)
		if ( IVROW == ICROW )
		  ret = MpC0;
		else
		  ret = NqC0 + MAX( 1, MpC0 );
	    }
	  }
	  return ret;
}

static	int vlen(char side, int m, int n) {
	  int ret=1;
	  if (chrcmp(side,'L')==0)
		  ret = m;
	  else
		  ret = n;

	  return ret;
}


void  pslarf_ninf(	 char side,
		 int m,
		 int n,
		 float global_v[],
		 int incv,
		 float tau,
		 float global_c[],
		 int ldc,
		 float work[]
)
/* "pslarf applies a real elementary reflector Q (or Q**T) to a real M-by-N distributed matrix C, from either the left or the right." */
/* OPTIONS */
{
	int maxldd;

	float *locv=NULL;
	int descv[DESCLEN];

	int maxldc;
	float *locc=NULL;
	int descc[DESCLEN];
	int desc_gc[DESCLEN];
	int row_locc, col_locc;

	float *locwork=NULL;
	int llocwork;
	char condv;

	INITIALIZE();

	SCALAR( "char", side);
	SCALAR( "int", m);
	SCALAR( "int", n);
	SCALAR("float", tau);
	SCALAR( "int", incv);
	SCALAR( "int", ldc);

	ROW( c);
	COL( c);
	MAXLDD( maxldd, c );

	maxldc = maxldd;

	if (incv==1) {
	  VECTOR( "r", "scomplex", v, vlen(side, m, n));
	  vDISTRIBUTE("r","scomplex",v,vlen(side, m, n));
	  Cdescinit( descv, vlen(side, m, n), 1, rbloc, 1, 0, 0, PARA_CTXT, rbloc, &linfo);
	} else {
	  VECTOR( "c", "scomplex", v, vlen(side, m, n));
	  vDISTRIBUTE("c","scomplex",v,vlen(side, m, n));
	  Cdescinit( descv, 1, vlen(side, m, n), 1, cbloc, 0, 0, PARA_CTXT, 1, &linfo);
	}

	MATRIX( "float", c, ROW_c, COL_c);
	DISTRIBUTE( "float", c, ROW_c, COL_c);

	llocwork = worklen(side, m, n,incv);
	WORK(locwork,llocwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pslarf)( &side, &m, &n,
                              locv, &one, &one, descv,
                              &incv,
                              &tau,
                              locc, &one, &one, descc,
                              locwork);

	GATHER( "float", c, ROW_c  , COL_c);

	if( mypnum == 0 ){
	} else {
		
	}

	FREE_VECTOR(v);
	FREE_MATRIX(c);
        FREE(locwork);
	
}

