package ninf.netsolve;
import ninf.client.NinfVal;
import ninf.client.NinfParamDesc;
import ninf.client.NinfExpression;
import ninf.client.NinfStub;
import ninf.client.BufferObject;
import ninf.client.CallContext;
import ninf.client.StubConverter;
import ninf.basic.*;
import ninf.basic.XDRInputStream;
import ninf.basic.XDROutputStream;
import ninf.toNs.NinfNetSolveException;
import java.util.Vector;
import java.util.StringTokenizer;
import java.io.IOException;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;


public class Problem{
  static NinfLog dbg = new NinfLog("Problem");

  // NAME AND PATH SECTION
  public String name;
  public String path;

  public String description;

  // LANGUAGE SECTION
  public static final int FORTRAN_LANG = 0;
  public static final int C_LANG = 1;
  public int language;

  // Complexity section
  public int complexity_a;
  public int complexity_b;


  public MatlabInfo  matlab[];

  
  // INPUT SECTION
  public int nb_input;
  public NetSolveObject[] inputs;

  public void setinput(int nb){

    nb_input = nb;
    inputs = new NetSolveObject[nb]; 
  } // end setinput

  // OUTPUT SECTION
  public int nb_output;
  public NetSolveObject[] outputs;

  public NinfStub stub;
  public void setoutput(int nb){
    nb_output = nb;
    outputs = new NetSolveObject[nb];
  } // end setoutput

  // UPF SECTION
//  public boolean upf;
  public int upf;

  // CALLING SEQUENCE

  String mnemonics[][];
  Constant constants[];
  Formula formulae[];

  // for conversion from ninf stub;
  int in_number[];
  int out_number[];


  public Problem()
  {
    description = "";
    matlab = new MatlabInfo[0];    
    mnemonics = new String[0][];
    constants = new Constant[0];
    formulae  = new Formula[0];
    upf = 0;
  }

  public int[][] writeBackToBuffer(Vector output_vec, BufferObject[] buffers) throws IOException{
    int sizes[][] = new int[stub.nparam][];

    System.out.println("output_vec size = "+ output_vec.size());

    for (int i = 0; i < nb_output; i++){
      byte tmp[];

      int index = lookForMnemonic("O"+i);
      System.out.println("index = " + index + ", i = " + i);
      //      tmp = ((DataObject)output_vec.elementAt(i)).write(outputs[i].data_type);
      //sizes[index] = ((DataObject)output_vec.elementAt(i)).makeSize();
      //      buffers.setElementAt(new BufferObject(tmp, sizes[index]), index);
      buffers[index] = (BufferObject)output_vec.elementAt(i);
    }
    return sizes;
  }

  Vector transNinfOneBuffer(BufferObject bo, int data_type, int m, int n) throws IOException{
    byte buffer[] = bo.data;
    System.out.println("buffer size ="+ buffer.length);
    XDRInputStream is = new XDRInputStream(new ByteArrayInputStream(buffer));
    Vector ans = new Vector();
    for (int i = 0; i < n; i++){
      switch(data_type){
      case NetSolveObject.NETSOLVE_I:
	ans.addElement(new int[m]);
	break;
      case NetSolveObject.NETSOLVE_S:
	ans.addElement(new float[m]);
	break;
      case NetSolveObject.NETSOLVE_D:
	ans.addElement(new double[m]);
	break;
      case NetSolveObject.NETSOLVE_C:
	ans.addElement(new byte[m]);
	break;
      default :
	throw new IOException();
      }
    }
    for (int i = 0; i < n; i++){
      switch(data_type){
      case NetSolveObject.NETSOLVE_I:
	for (int j = 0; j < m; j++)
	  ((int [])(ans.elementAt(i)))[j] = is.readInt();
	break;
      case NetSolveObject.NETSOLVE_S:
	for (int j = 0; j < m; j++)
	  ((float [])(ans.elementAt(i)))[j] = is.readFloat();
	break;
      case NetSolveObject.NETSOLVE_D:
	for (int j = 0; j < m; j++)
	  ((double [])(ans.elementAt(i)))[j] = is.readDouble();
	break;
      case NetSolveObject.NETSOLVE_C:
	for (int j = 0; j < m; j++)
	  ((byte [])(ans.elementAt(i)))[j] = is.readByte();
	break;
      default :
	throw new IOException();
      }	
    }
    return ans;
  }

  public BufferObject [] transNinfBuffers(CallContext context, 
					  int m[], int n[]) throws IOException{
    BufferObject[] buffers = context.buffers;
    Vector nbuffer = new Vector();
    for (int i = 0; i < nb_input; i++){
      int index = lookForMnemonic("I"+i);
      System.out.println("index = " + index);
      BufferObject bo = buffers[index];

      switch (inputs[i].object_type){
      case NetSolveObject.NETSOLVE_MATRIX:
	m[i] = lookFor("mI"+i, context.iargs);
	n[i] = lookFor("nI"+i, context.iargs);
	System.out.println("m , n = " + m[i] + ", " + n[i]);
	System.out.println("bo.size , 0 = " + bo.sizes[0] + ", 1= " + bo.sizes[1]);
	//	nbuffer.addElement(transNinfOneBuffer(buffers[index], inputs[i].data_type, bo.sizes[0], bo.sizes[1]));
	nbuffer.addElement(buffers[index]);
	break;
      case NetSolveObject.NETSOLVE_VECTOR:
	m[i] = lookFor("mI"+i, context.iargs);
	System.out.println("bo.size , 0 = " + bo.sizes[0]);
	//nbuffer.addElement(transNinfOneBuffer(buffers[index], inputs[i].data_type, bo.sizes[0], 1));
	nbuffer.addElement(buffers[index]);
	break;
      case NetSolveObject.NETSOLVE_SCALAR:
	//nbuffer.addElement(transNinfOneBuffer(buffers[index], inputs[i].data_type, 1, 1));
	nbuffer.addElement(buffers[index]);
      	break;
      }
    }      
    BufferObject ans[] = new BufferObject[nbuffer.size()];
    for (int i = 0; i < nbuffer.size(); i++)
      ans[i] = (BufferObject)nbuffer.elementAt(i);
    return ans;
  }

  public int lookFor(String str, int[] iargs){
    int index = lookForMnemonic(str);
    if (index >= 0)
      return iargs[index];
    index = lookForConstant(str);
    if (index >= 0)
      return constants[index].value;
    return 0;
  }

  public int lookForMnemonic(String str){
    for (int i=0; i < mnemonics.length; i++)
      for (int j=0; j < mnemonics[i].length; j++){
	if (str.equals(mnemonics[i][j]))
	  return i;
      }
    return -1;
  } // End lookFor

  public int lookForConstant(String str){
    for (int i=0; i < constants.length; i++)
	if (str.equals(constants[i].mnemonic))
	  return i;
    return -1;
  } // End lookFor
  



  public boolean setpath(String string){
    // Check for "//"
    int test;

    if (string.length() == 0)
      return false;
    if (string.indexOf("//") != -1)
      return false;
    if (string.indexOf(" ") != -1)
      return false;

    if (string.charAt(0) != '/')  // Prepend with a '/' if necessary
      string = '/'+string;
    if (string.charAt(string.length()-1) != '/') // Add a '/' if necessary
      string = string+'/';

    path = string;
    return true;
  } // End setpath


  void parseFormulae(Formula formulae[], NetSolveObject inputs[], NetSolveObject outputs[])
  throws CannotConvertException{
    for (int i = 0; i < formulae.length; i++){
      ParsedMnemonic parsed = new ParsedMnemonic(formulae[i].mnemonic);
      NetSolveObject target;
      if (parsed.isInput)
	target = inputs[parsed.number];
      else
	target = outputs[parsed.number];
      if (target.property == null)
	  target.setProperty(new ObjectProperty());
      NinfExpression expr = formulae[i].getExpression(this);
      if (expr == null)
	throw new CannotConvertException();
      ObjectChar ochar = new ObjectChar(expr);

      switch (parsed.flag){
      case 0: /* none */
	System.out.println("error, in parsing constants.");
	throw new CannotConvertException();
      case 1:  /* n */
	target.property.n = ochar;
	break;
      case 2:  /* m */
	target.property.m = ochar;
	break;
      case 3:  /* l */
	target.property.l = ochar;
	break;
      } 
    }
  }

  void parseConstants(Constant constants[], NetSolveObject inputs[], NetSolveObject outputs[])
    throws CannotConvertException{
    for (int i = 0; i < constants.length; i++){
      ParsedMnemonic parsed = new ParsedMnemonic(constants[i].mnemonic);
      NetSolveObject target;
      if (parsed.isInput)
	target = inputs[parsed.number];
      else
	target = outputs[parsed.number];
      
      if (target.property == null)
	  target.setProperty(new ObjectProperty());
      switch (parsed.flag){
      case 0: /* none */
	System.out.println("error, in parsing constants.");
	throw new CannotConvertException();
      case 1:  /* n */
	target.property.n = new ObjectChar(NinfVal.VALUE_CONST, constants[i].value);
	break;
      case 2:  /* m */
	target.property.m = new ObjectChar(NinfVal.VALUE_CONST, constants[i].value);
	break;
      case 3:  /* l */
	target.property.l = new ObjectChar(NinfVal.VALUE_CONST, constants[i].value);
	break;
      } 
    }
  }

  ParsedMnemonic[][] parseMnemonics(String mnemonics[][], NetSolveObject inputs[], NetSolveObject outputs[]){
    ParsedMnemonic ans[][] = new ParsedMnemonic[mnemonics.length][];
    for (int i = 0; i < mnemonics.length; i++){
      ParsedMnemonic parsed[] = ParsedMnemonic.parseMnemonics(mnemonics[i]);
      ans[i] = parsed;
      NetSolveObject previous = null;
      for (int j = 0; j < parsed.length; j++){
	NetSolveObject target;
	if (parsed[j].isInput)
	  target = inputs[parsed[j].number];
	else
	  target = outputs[parsed[j].number];
	
	if (target.property == null)
	  target.setProperty(new ObjectProperty());
	switch (parsed[j].flag){
	case 0: /* none */
	  if (previous != null){
	    target.mergeProperty(previous.property);
	  }
	  previous = target;
	  break;
	case 1:  /* n */
	  target.property.n = new ObjectChar(NinfVal.VALUE_IN_ARG, i);
	  break;
	case 2:  /* m */
	  target.property.m = new ObjectChar(NinfVal.VALUE_IN_ARG, i);
	  break;
	case 3:  /* l */
	  target.property.l = new ObjectChar(NinfVal.VALUE_IN_ARG, i);
	  break;
	} 
      }
    }
    return ans;
  }


  NinfParamDesc makeNinfParamDesc(ParsedMnemonic parsed[], NetSolveObject inputs[], 
				  NetSolveObject outputs[]) throws NetSolveException, CannotConvertException{
    NinfParamDesc tmp = new NinfParamDesc();
    for (int i = 0; i < parsed.length; i++){
      if (parsed[i].isInput)
	tmp.param_inout |= NinfParamDesc.MODE_IN;
      else
	tmp.param_inout |= NinfParamDesc.MODE_OUT;
    }
    switch (parsed[0].flag){
    case 1:
    case 2:
    case 3:
      tmp.param_type = NinfVal.INT;
      tmp.ndim = 0;
      break;
    case 0:
      {
	NetSolveObject target;
	if (parsed[0].isInput)
	  target = inputs[parsed[0].number];
	else
	  target = outputs[parsed[0].number];
	target.setParamDesc(tmp);
	break;	
      }
    case 4:
      tmp.param_inout = NinfParamDesc.MODE_WORK;
    }
    if (tmp.ndim == 0 && tmp.IS_OUT_MODE())
      tmp.param_inout &= ~(NinfParamDesc.MODE_OUT);
    return tmp;

  }

  /*        to make stub from problem        */

  public static Problem makeUp(NinfStub stub) throws CannotConvertException{
    Problem prob = new Problem();
    StubConverter converter = new StubConverter(stub);

    prob.description = stub.description;
    prob.name = stub.module_name+"/"+stub.entry_name;
    prob.path = "Ninf/" + stub.module_name;
    prob.mnemonics = new String[stub.nparam][];

    int in_index = 0;
    int out_index = 0;

    prob.in_number = new int[stub.nparam];
    prob.out_number = new int[stub.nparam];

    for (int i = 0; i < stub.nparam; i++){
      prob.in_number[i] = -1;
      prob.out_number[i] = -1;
      dbg.println("index " + i +" is used as size = " +converter.isUsedAsSize(i) );
      if (!converter.isUsedAsSize(i)){
	if (stub.params[i].IS_IN_MODE())
	  prob.in_number[i] = in_index++;
	if (stub.params[i].IS_OUT_MODE())
	  prob.out_number[i] = out_index++;
      }
    }

    prob.setinput(in_index);
    prob.setoutput(out_index);
    dbg.println("in_index = " + in_index + ", out_index = " + out_index);
    for (int i = 0; i < stub.nparam; i++){
      if (prob.in_number[i] >= 0)
	prob.inputs[prob.in_number[i]] = new NetSolveObject(stub.params[i].param_type, 
					       stub.params[i].ndim);
      if (prob.out_number[i] >= 0)
	prob.outputs[prob.out_number[i]] = new NetSolveObject(stub.params[i].param_type,
					       stub.params[i].ndim);
    }

    Vector v_mnemonics[] = new Vector[stub.nparam];
    Vector v_constants = new Vector();
    for (int i = 0; i < stub.nparam; i++)
      v_mnemonics[i] = new Vector();
    for (int i = 0; i < stub.nparam; i++)
      converter.makeMnemonics(i, prob.in_number[i], prob.out_number[i], 
				   v_mnemonics, v_constants);
    prob.constants = new Constant[v_constants.size()];
    for (int i = 0; i < v_constants.size(); i++)
      prob.constants[i] = (Constant)(v_constants.elementAt(i));
    for (int i = 0; i < stub.nparam; i++){
      if (prob.in_number[i] >= 0)
	v_mnemonics[i].addElement("I"+prob.in_number[i]);
      if (prob.out_number[i] >= 0)
	v_mnemonics[i].addElement("O"+prob.out_number[i]);
      prob.mnemonics[i] = new String[v_mnemonics[i].size()];
      for (int j = 0; j < v_mnemonics[i].size(); j++)
	prob.mnemonics[i][j] = (String)(v_mnemonics[i].elementAt(j));
    }

    dbg.println("Problem configured = " + prob);
    return prob;
  }


  public NinfStub toNinfStub() throws NinfException{
    try {
      stub = NinfStub.getEmptyStub(mnemonics.length);
      stub.nparam = mnemonics.length;
      stub.description = description; 
      stub.module_name = "NetSolve";
      stub.entry_name = name;
      
      parseConstants(constants, inputs, outputs);
      parseFormulae(formulae, inputs, outputs);
      ParsedMnemonic parsed[][] = parseMnemonics(mnemonics, inputs, outputs);
      for (int i = 0; i < inputs.length; i++)
	dbg.println("input " + i + " : " +inputs[i]);
      for (int i = 0; i < outputs.length; i++)
	dbg.println("output " + i + " : " +outputs[i]);
      
      for (int i = 0; i < parsed.length; i++){
	dbg.println("Convert " + i + "th");
	NinfParamDesc tmp =  makeNinfParamDesc(parsed[i], inputs, outputs);
	stub.params[i] = tmp;
      }      
      
      return stub;
    } catch (NetSolveException e){
      dbg.log("Can't Convert to Stub :" + name);
      e.printStackTrace();
      throw new NinfNetSolveException(e);
    } 

  }


  /********************   TOSTRING ************************/
  public String toString(){
    StringBuffer buffer = new StringBuffer();
    buffer.append("Name:");
    buffer.append(name);
    buffer.append("\n");
    // path??  
    if (description != null){
      buffer.append("Description:");
      buffer.append(description);
      buffer.append("\n");
    }

    buffer.append("language = " + language + "\n");

    buffer.append("UPFs:");
    buffer.append(upf);
    buffer.append("\n");
    buffer.append("Number of Inputs:");
    buffer.append(nb_input);
    buffer.append("\n");
    for(int j=0;j<nb_input;j++) {
      buffer.append("Input "+j+" Data Type:");
      buffer.append(inputs[j].data_type + " - " +
	NetSolveObject.datatype2str(inputs[j].data_type));
      buffer.append("Input "+j+" Object Type:");
      buffer.append(inputs[j].object_type + " - " +
	NetSolveObject.objtype2str(inputs[j].object_type));
      if (inputs[j].description != null){
	buffer.append("Input "+j+" Description:");
	buffer.append(inputs[j].description);
      }
      buffer.append("\n");
    }
    
    buffer.append("Number of Outputs:");
    buffer.append(nb_output);
    buffer.append("\n");
    for(int j=0;j<nb_output;j++) {
      buffer.append("Output "+j+" Data Type:");
      buffer.append(outputs[j].data_type + " - " +
	NetSolveObject.datatype2str(outputs[j].data_type));
      buffer.append("Output "+j+" Object Type:");
      buffer.append(outputs[j].object_type + " - " +
	NetSolveObject.objtype2str(outputs[j].object_type));
      if (outputs[j].description != null){
	buffer.append("Output "+j+" Description:");
	buffer.append(outputs[j].description);
      }
      buffer.append("\n");
    }
    buffer.append("Complexity:");
    buffer.append(complexity_a + "," + complexity_b);
    buffer.append("\n");

    if (mnemonics != null)
      for (int i = 0; i < mnemonics.length; i++){
	buffer.append("(");
	for (int j = 0; j <mnemonics[i].length; j++)
	  buffer.append(mnemonics[i][j]+" ");
	buffer.append(") ");
      }
    buffer.append("\n");
    if (constants != null)
      for (int i = 0; i < constants.length; i++)
	buffer.append(constants[i]);
    buffer.append("\n");
    if (formulae != null)
      for (int i = 0; i < formulae.length; i++)
	buffer.append(formulae[i]);
    buffer.append("\n");
    return buffer.toString();
  }

  /****************** For Netsolve - Ninf Conversion*******************/
  
  int getBufferNumber(boolean isIn, int number){ 
    int tmp_number[];
    if (isIn)
      tmp_number = in_number;
    else 
      tmp_number = out_number;
    
    for (int i = 0; i < tmp_number.length; i++)
      if (tmp_number[i] == number)
	return i;
    return -1;
  }



  public void writeBack(CallContext context, NinfStub stub, XDROutputStream os) throws NinfException {
    for (int i = 0; i < outputs.length; i++){
      BufferObject bo = context.buffers[getBufferNumber(false, i)];
      outputs[i].writeOut(os, bo);
    }
  }

  public CallContext serverReceive(NinfStub stub, XDRInputStream is) 
  throws NinfException {
    CallContext context = new CallContext(stub.nparam);
    for (int i = 0; i < stub.nparam; i++)
      context.buffers[i] = new BufferObject();
    for (int i = 0; i < inputs.length; i++){
      BufferObject bo = context.buffers[getBufferNumber(true, i)];
      inputs[i].readInto(is, bo);
    }
    int iargs[] = setupScalar(context.buffers, stub);
    context.iargs = iargs;
    stub.setupArrayShapes(context);
    setupReturnBuffer(context, stub);
    return context;
  }

  void setupReturnBuffer(CallContext context, NinfStub stub) 
  throws NinfException {
    for (int i = 0; i < stub.nparam; i++)
      if (!stub.params[i].IS_IN_MODE()){
	context.buffers[i] = stub.params[i].setupBuffer(context.shapes[i]);
      }
  }


  int getMnemonicsValue(String mnemonic[], BufferObject[] buffers) 
    throws CannotConvertException {
    for (int i = 0; i < mnemonic.length; i++){
      ParsedMnemonic tmp = new ParsedMnemonic(mnemonic[i]);
      if (tmp.isInput) {
	int bufNum = getBufferNumber(true, tmp.number);
	switch (tmp.flag) {
	case 1: //  "n"
	  return buffers[bufNum].sizes[1];
	case 2: //  "m"
	  return buffers[bufNum].sizes[0];
	case 3: //  "l"
	  return 1;
	default:
	  continue;
	}
      }
    }
    throw new CannotConvertException();
  }

  int[] setupScalar(BufferObject[] buffers, NinfStub stub) throws NinfException {
    int ans[] = new int[stub.nparam];
    try {
      for (int i = 0; i < stub.nparam; i++){
	try {
	  if (stub.params[i].ndim == 0 && stub.params[i].IS_IN_MODE()){
	    int val = getMnemonicsValue(mnemonics[i], buffers);
	    ans[i] = val;
	    ByteArrayOutputStream bos = new ByteArrayOutputStream();
	    XDROutputStream os = new XDROutputStream(bos);
	    os.writeInt(val);
	    buffers[i].data = bos.toByteArray();
	    dbg.println("Scalar " + i + " is " + val);
	  }
	} catch (CannotConvertException e){
	  ByteArrayInputStream bis = new ByteArrayInputStream(buffers[i].data);
	  XDRInputStream is = new XDRInputStream(bis);
	  dbg.println("Buffer "+ i+ " is " + is.readInt());
	}
      }
    } catch (IOException e){
      throw new NinfIOException(e);
    }
    return ans;
  }



  public boolean partialEqual(Problem other){
    if (!name.equals(other.name))
      return false;
    //    if (language != other.language)
    //      return false;

    if (nb_input != other.nb_input || nb_output != other.nb_output)
      return false;
    for (int i = 0; i < nb_input; i++)
      if (!inputs[i].partialEqual(other.inputs[i]))
	return false;
    for (int i = 0; i < nb_output; i++)
      if (!outputs[i].partialEqual(other.outputs[i]))
	return false;
    return true;
  }


  public static Problem readPartial(XDRInputStream is) throws IOException{
    Problem tmp = new Problem();
    
    tmp.name = is.readString();
    tmp.language = is.readInt();

    tmp.nb_input = is.readInt();
    tmp.setinput(tmp.nb_input);
    for (int i = 0; i < tmp.nb_input; i++)
      tmp.inputs[i] = NetSolveObject.readPartial(is);

    tmp.nb_output = is.readInt();
    tmp.setoutput(tmp.nb_output);
    for (int i = 0; i < tmp.nb_output; i++)
      tmp.outputs[i] = NetSolveObject.readPartial(is);
    return tmp;
  }

  public static Problem read(XDRInputStream is) throws IOException{
    Problem tmp = new Problem();

    tmp.name = is.readString();
    tmp.path = is.readString();
    tmp.description = is.readString();

    tmp.nb_input = is.readInt();
    tmp.setinput(tmp.nb_input);
    for (int i = 0; i < tmp.nb_input; i++)
      tmp.inputs[i] = NetSolveObject.readFull(is);


    tmp.nb_output = is.readInt();
    tmp.setoutput(tmp.nb_output);
    for (int i = 0; i < tmp.nb_output; i++)
      tmp.outputs[i] = NetSolveObject.readFull(is);

    int nb_matlab = is.readInt();
    tmp.matlab = new MatlabInfo[nb_matlab];
    for (int i = 0; i < nb_matlab; i++)
      tmp.matlab[i] = new MatlabInfo(is.readInt(), is.readInt());
      
    tmp.parse_complexity(is.readString());

    int dummy = is.readInt();   /* */

    
    int temp1 = is.readInt();
    tmp.mnemonics = new String[temp1][];
    for(int k=0;k<temp1;k++) {
      String tmpStr = is.readString();
      Vector v = new Vector();
      StringTokenizer st = new StringTokenizer(tmpStr, ", ");
      while (st.hasMoreTokens())
	v.addElement(st.nextToken());
      String tmpArray[] = new String[v.size()];
      for (int l = 0; l < v.size(); l++)
	tmpArray[l] = (String)v.elementAt(l);
      tmp.mnemonics[k] = tmpArray;
    }
    temp1 = is.readInt();
    tmp.constants = new Constant[temp1];
    for(int k = 0; k < tmp.constants.length; k++) {
      String temp_str = is.readString();
      int temp2 = is.readInt();
      tmp.constants[k] = new Constant(temp_str, temp2);
    }
    tmp.formulae = new Formula[is.readInt()];
    for(int k = 0; k < tmp.formulae.length; k++) {
      String str1 = is.readString();
      String str2 = is.readString();
      tmp.formulae[k] = new Formula(str1, str2);
    }
    



    return tmp;
  }

  public void write(XDROutputStream os) throws IOException{
    os.writeString(name);
    os.writeString(path);
    os.writeString(description);

    os.writeInt(nb_input);
    for (int i = 0; i < nb_input; i++)
      inputs[i].writeFull(os);

    os.writeInt(nb_output);
    for (int i = 0; i < nb_output; i++)
      outputs[i].writeFull(os);

    os.writeInt(matlab.length);
    for (int i = 0; i < matlab.length; i++){
      os.writeInt(matlab[i].output1);
      os.writeInt(matlab[i].output2);
    }
      
    writeComplexity(os);

    os.writeInt(1);
    
    os.writeInt(mnemonics.length);
    for(int k=0;k<mnemonics.length;k++) {
      String tmp = "";
      for (int l = 0; l < mnemonics[k].length; l++)
	tmp += mnemonics[k][l] + " ";
      os.writeString(tmp);
    }

    os.writeInt(constants.length);
    for(int k=0;k< constants.length;k++) 
      constants[k].write(os);

    os.writeInt(formulae.length);
    for(int k = 0; k < formulae.length; k++) 
      formulae[k].write(os);
  }

  void writeComplexity(XDROutputStream os) throws IOException{
    os.writeString(""+ complexity_a +","+ complexity_b);
  }

  private void parse_complexity(String cstr) {
    int start=0, mid=0;
    if(cstr.length() < 3) mid = 0;
    else {
      while((mid < cstr.length()) && (cstr.charAt(mid) != ',')) 
	mid++;
      if((mid == cstr.length()) || (start==mid)) mid = -1;
    }
    if(mid == -1) {
      complexity_a = 0;
      complexity_b = 0;
      System.out.println("Trouble parsing complexity string");
    } else {
      complexity_a = 
	new Integer(cstr.substring(0,mid)).intValue();
      complexity_b = 
	new Integer(cstr.substring(mid+1)).intValue();
    }
  }




} // End class Problem
