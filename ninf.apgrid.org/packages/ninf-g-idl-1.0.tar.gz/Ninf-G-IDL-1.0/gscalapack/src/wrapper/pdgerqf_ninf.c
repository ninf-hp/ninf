#define _WRAPPER_
/* $Id: pdgerqf_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define DOUBLE
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n

static	int worklen(int m, int n) {
	  int ret;
	  int IROFF, ICOFF, IAROW, IACOL, Mp0, Nq0;
	  ret = m * (m+n+m);
	  if NEED_BUFF {
#define IA 1
#define JA 1
#define MB_A MB
#define NB_A NB
#define MYROW myprow
#define MYCOL mypcol
#define NPROW nprow
#define NPCOL npcol

	    IROFF = MOD( IA-1, MB_A );
	    ICOFF = MOD( JA-1, NB_A );
	    IAROW = INDXG2P( IA, MB_A, MYROW, RSRC_A, NPROW );
	    IACOL = INDXG2P( JA, NB_A, MYCOL, CSRC_A, NPCOL );
	    Mp0   = NUMROC( M+IROFF, MB_A, MYROW, IAROW, NPROW );
	    Nq0   = NUMROC( N+ICOFF, NB_A, MYCOL, IACOL, NPCOL );
	    ret =  MB_A * ( Mp0 + Nq0 + MB_A );
	  }
	  return ret;
}


void  pdgerqf_ninf(	 int m,
		 int n,
		 double global_a[],
		 int lda,
		 double global_tau[],
		 double work[],
		 int lwork,
		 int *info
)
/* "pdgerqf computes a RQ factorization of a real distributed M-by-N matrix A = R * Q." */
/* OPTIONS */
{
	int maxldd;

	int maxlda;
	double *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
	int row_loca, col_loca;

	double *loctau=NULL;

	double *locwork=NULL;
	int llocwork;

	INITIALIZE();

	SCALAR( "int", m);
	SCALAR( "int", n);
	SCALAR( "int", lda);
	SCALAR( "int", lwork);

	ROW( a);
	COL( a);
	MAXLDD( maxldd, a );
	maxlda = maxldd;

	MATRIX( "double", a, ROW_a, COL_a);
	DISTRIBUTE( "double", a, ROW_a  , COL_a);

	VECTOR( "r", "double", tau, m);

        llocwork = worklen(m, n);
	llocwork = max(lwork,llocwork);
	WORK(locwork,llocwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pdgerqf)( &m, &n,
                               loca, &one, &one, desca,
                               loctau,
                               locwork, &llocwork, &linfo);

	GATHER( "double", a, ROW_a  , COL_a);
	vGATHER( "r", "double", tau, m);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
		*info = linfo;
	} else {
	}

	FREE_MATRIX(a);
	FREE_VECTOR(tau);
        FREE(locwork);
}

