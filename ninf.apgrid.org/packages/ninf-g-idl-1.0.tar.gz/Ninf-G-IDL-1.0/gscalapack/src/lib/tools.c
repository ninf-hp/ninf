#include <stdio.h>
#include <stdlib.h>
#include <mpi.h>
#include <assert.h>
#include <string.h>

#define _LOCAL_
#include "gscalapack.h"
#include "gscalapack-scalapack.h"

extern void parse_type( const char *type, char *utype);

int _sizeof( const char *type) {
  char utype[TYPESTRLEN];
  int ret = 1;
  parse_type(type,utype);
  switch(*utype) {
  case 'd':
      ret = sizeof(double);
    break;
  case 'f':
      ret = sizeof(float);
    break;
  case 'c':
      ret = sizeof(scomplex);
    break;
  case 'z':
      ret = sizeof(dcomplex);
    break;
  case 'i':
      ret = sizeof(int);
    break;
  case 'l':
      ret = sizeof(long);
    break;
  default:
    assert(0);
    break;
  }
  return ret;
}

void _make_bloc(int n) {
  if (serial==1) {
    blocsize=n;
    return;
  }
  if (n%(nprocs-1)==0) cbloc = n/(nprocs-1);
  else cbloc = n/(nprocs-1)+1;
  blocsize=cbloc;
  rbloc=n;
} /* end of _make_bloc */

void _size_init( int *mroc, int m, int mb, int myprow, int nprow) 
{
  if (serial==1) return;
  if( mypnum != 0 ) {
    /* Allocate memory to local arrays */
    assert(mb!=0);
    assert(m!=0);
    *mroc = Cnumroc( m, mb, myprow, 0, nprow );
  } else {
    *mroc = 1;
  }
} /* end of _size_init */

void parse_type( const char *type, char *utype)
{

  strncpy( utype, type, TYPESTRLEN);
  if (strncmp(type,"scomplex",sizeof("scomplex")-1)==0) 
    strncpy(utype,"complex",sizeof("complex"));

  if (strncmp(type,"char",sizeof("char")-1)==0) 
    strncpy(utype,"string",sizeof("string"));

  if (strncmp(type,"dcomplex",sizeof("dcomplex")-1)==0) 
    strncpy(utype,"zcomplex",sizeof("zcomplex"));

} /* end of parse_type */

void _maxldd(int *maxvalue, int *value){
  int dummy;
  if (serial==1) return;

  if (mypnum!=0) Cigamx2d( para_ctxt, "ALL", " ", 1, 1, value, 1, &dummy,
			   &dummy, -1, -1, -1 ); 
  if (*value<0) *value=-*value;
  *maxvalue = *value;
}  /* end of _maxldd */

void gamx2d( char *type, void *max)
{
  char utype[TYPESTRLEN];
  int dummy;
    parse_type(type,utype);
    switch(*type) {
        case 'i':
            Cigamx2d( all_ctxt, "ALL", " ", 1, 1, max, 1, &dummy,
                      &dummy, -1, -1, -1 );
            break;
        case 'f':
            Csgamx2d( all_ctxt, "ALL", " ", 1, 1, max, 1, &dummy,
                      &dummy, -1, -1, -1 );
            break;
        case 'd':
            Cdgamx2d( all_ctxt, "ALL", " ", 1, 1, max, 1, &dummy,
                      &dummy, -1, -1, -1 );
            break;
        case 'c':
            Ccgamx2d( all_ctxt, "ALL", " ", 1, 1, max, 1, &dummy,
                      &dummy, -1, -1, -1 );
            break;
        case 'z':
            Czgamx2d( all_ctxt, "ALL", " ", 1, 1, max, 1, &dummy,
                      &dummy, -1, -1, -1 );
            break;
        default:
            assert(0);
            break;
    }
    return ;
} /* end of gamx2d */



