#define _WRAPPER_
/* $Id: pdormlq_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define DOUBLE
#include <gscalapack.h>

#define ROW_a lda
#define COL_a col_a
#define ROW_c ldc
#define COL_c n

static	int worklen(char side, int m, int n) {
	  int ret=1;
	  int LCMP, IROFFA, ICOFFA, IACOL, MqA0;
	  int IROFFC, ICOFFC, ICROW, ICCOL, MpC0, NqC0;
	  int max_m_n;
	  max_m_n = max( m, n);
	  ret = MAX( (max_m_n*(max_m_n-1))/2, ( max_m_n + MAX( max_m_n + max_m_n , max_m_n ) )*max_m_n ) + max_m_n* max_m_n;
	  if NEED_BUFF {
	    LCMP = LCM(NPROW, NPCOL) / NPROW ;

	    IROFFA = MOD( IA-1, MB_A ); ICOFFA = MOD( JA-1, NB_A );
	    IACOL = INDXG2P( JA, NB_A, MYCOL, CSRC_A, NPCOL );
	    MqA0 = NUMROC( M+ICOFFA, NB_A, MYCOL, IACOL, NPCOL );

	    IROFFC = MOD( IC-1, MB_C ); ICOFFC = MOD( JC-1, NB_C );
	    ICROW = INDXG2P( IC, MB_C, MYROW, RSRC_C, NPROW );
	    ICCOL = INDXG2P( JC, NB_C, MYCOL, CSRC_C, NPCOL );
	    MpC0 = NUMROC( M+IROFFC, MB_C, MYROW, ICROW, NPROW );
	    NqC0 = NUMROC( N+ICOFFC, NB_C, MYCOL, ICCOL, NPCOL );

	    if (chrcmp(side, 'L')==0)
	      ret = MAX( (MB_A*(MB_A-1))/2, ( MpC0 + MAX( MqA0 + NUMROC( NUMROC( M+IROFFC, MB_A, 0, 0, NPROW ), MB_A, 0, 0, LCMP ), NqC0 ) )*MB_A ) + MB_A * MB_A;
	    else 
	      ret = MAX( (MB_A*(MB_A-1))/2, (MpC0 + NqC0)*MB_A ) +  MB_A * MB_A;
	  }
	  return ret;
}

void  pdormlq_ninf(	 char side,
		 char trans,
		 int m,
		 int n,
		 int k,
		 double global_a[],
		 int lda,
		 double global_tau[],
		 double global_c[],
		 int ldc,
		 double work[],
		 int lwork,
		 int *info
)
/* "pdormlq overwrites the general real M-by-N distributed matrix C with\\n\\n                       SIDE = 'L'          SIDE = 'R'\\n  TRANS = 'N':      Q *  C           C * Q\\n  TRANS = 'T':      Q**T *  C       C * Q**T\\n\\n  where Q is a real orthogonal distributed matrix defined as the product of K elementary reflectors\\n\\n        Q = H(k) ." */
/* OPTIONS */
{
	int maxldd;

	int maxlda;
	double *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
	int row_loca, col_loca;
	int col_a;

	double *loctau=NULL;

	int maxldc;
	double *locc=NULL;
	int descc[DESCLEN];
	int desc_gc[DESCLEN];
	int row_locc, col_locc;

	double *locwork=NULL;
	int llocwork;

	INITIALIZE();

	SCALAR( "char", side);
	SCALAR( "char", trans);
	SCALAR( "int", m);
	SCALAR( "int", n);
	SCALAR( "int", k);
	SCALAR( "int", lda);
	SCALAR( "int", ldc);
	SCALAR( "int", lwork);

	if (chrcmp(side,'L')==0) col_a = m;
	else col_a = n;

	ROW( a);
	COL( a);
	ROW( c);
	COL( c);
	MAXLDD( maxldd, c );
	maxlda = maxldd;
	maxldc = maxldd;

	MATRIX( "double", a, ROW_a, COL_a);
	MATRIX( "double", c, ROW_c, COL_c);
	VECTOR( "c","double", tau, k);
	DISTRIBUTE( "double", a, ROW_a, COL_a);
	DISTRIBUTE( "double", c, ROW_c, COL_c);
	vDISTRIBUTE("c","double", tau, k);

	llocwork=worklen(side, m, n);
	llocwork = max(lwork,llocwork);
	WORK(locwork,llocwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pdormlq)( &side, &trans,
                               &m, &n, &k,
                               loca, &one, &one, desca,
                               loctau,
                               locc, &one, &one, descc,
                               locwork, &llocwork,
                               &linfo);

	GATHER( "double", c, ROW_c, COL_c);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
		*info = linfo;
		//		cp  locwork to work[lwork]
	} else {
		
	}

	FREE_MATRIX(a);
	FREE_MATRIX(c);
	FREE_VECTOR(tau);
        FREE(locwork);
	
}

