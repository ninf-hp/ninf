package ninf.MetaServer;
import ninf.basic.*;
import ninf.client.*;


import java.io.IOException;
import java.util.Vector;

public class NinfCompound implements NinfCallable, CallableStruct, Stoppable {
  // *********************** NON STATIC VARIABLES ***********************
  Vector buffers;

  /**  Vector of indexlist correspond to funcs */
  NinfDataflow dataflows[];
  NinfCommonData commonData[];
  NinfNativeCallable funcs[];
  int argNums[];
  NinfStub stub;
  FunctionManager funcManager;
  NinfLog dbg = new NinfLog(this);
  Vector threads = new Vector();
  boolean finished = false;

  /** Construct from packet, stream, and manager */
  public NinfCompound(NinfPacket p, XDRInputStream is, FunctionManager fm) {
    buffers = new Vector();
    funcManager = fm;
    NinfPacketInputStream pis = new NinfPacketInputStream(p, is);
    try {
      read(pis);
    } catch (NinfException e) {
      e.printStackTrace(dbg.os);
    }
    stub = makeCompoundStub();
//    dbg.println(stub);
  }
  
  /** read stub body from stream */
  void read(NinfPacketInputStream is) throws NinfException {
    dbg.print("----reading ninfcompound:" );

    int inputNum = is.readInt();
    dbg.println(" numbers:" + inputNum);
    dataflows = new NinfDataflow[inputNum];

    for (int i = 0; i < inputNum; i++) {
      dbg.println("------read one dataflow" );
      dataflows[i] = new NinfDataflow(is, funcManager);
    }
    dbg.println("   rest of packet ->" + is.rest());
    //is.dumpRest(dbg.os());
    inputNum = is.readInt();
    commonData = new NinfCommonData[inputNum];
    for (int i = 0; i < inputNum; i++) {
      dbg.println("------read one commonData" );
      commonData[i] = new NinfCommonData(is);
    }
  }

  // ***********************  NON STATIC METHODS  ***********************
  public NinfStub stub() {
    return stub;
  }

  public NinfThread forkWriteBack(XDROutputStream os) {
    return new NinfWriteBackThread(os, stub, buffers, this);
  }

  public NinfThread forkStub(int index, NinfNativeCallable func, int offset) {
    Vector args = new Vector();
    for (int i = 0; i < func.getStub().nparam; i++) {
      args.addElement(buffers.elementAt(i + offset));
    }
    return new NinfConnectionThread(index, func, args);
  }

  public void mergeBufferSub(int serial[]) {
    byte[] tmp = (byte[]) buffers.elementAt(serial[0]);
    for (int i = 1; i < serial.length; i++) {
      byte[] tmp2 = (byte[]) buffers.elementAt(serial[i]);
      buffers.setElementAt(tmp, serial[i]);
      if (tmp.length != tmp2.length)
	dbg.println("Buffer size conflict: " + serial[0] +
		    " is " + tmp.length+ " ,while " + serial[i] +
		    " is " + tmp2.length);
    }
  }

  public void mergeBuffer() {
    argNums = new int[dataflows.length];
    int index = 0;
    for (int i = 0; i < dataflows.length; i++) {
      argNums[i] = index;
      index += dataflows[i].stub.nparam;
    }
    dbg.println("Merging Buffer");
    for (int i = 0; i < commonData.length; i++) {
      int se[] = commonData[i].serialize(argNums);
      dbg.println(" Merging Buffer" + se);
      mergeBufferSub(se);
    }
  }

  public void recieveNinfCode(NinfPacketInputStream is) throws NinfException {
    int i;
    if ((i = is.readInt()) != 1)
      dbg.println("Invalid code:"  + i);
    else
      dbg.println("get Ninf Call Code: " + i);
  }

  public void setupBuffers(XDRInputStream is) throws NinfException {
    NinfPacketInputStream pis = new NinfPacketInputStream(is);
    recieveNinfCode(pis);
    stub.setupBuffers(buffers, pis);
    mergeBuffer();
    stub.serverReceive(buffers, pis);
  }

  public void forkThreads(XDROutputStream os) {
    dbg.println("Fork Threads ");
    getfuncs();
    for (int i = 0; i < dataflows.length; i++) {
      threads.addElement(forkStub(i, funcs[i], argNums[i]));
    }
    NinfThread writeBack = forkWriteBack(os);

    int dependentList[][] = getDependentList();

    for (int i = 0; i < dependentList.length; i++) {
      int tmp[] = dependentList[i];
//      dbg.print(i + " dependent: ");
      for (int j = 0; j < tmp.length; j++) {
//	dbg.print(tmp[j] + " ");
      }
//      dbg.println("");
      if (tmp.length == 0) {
	((NinfThread)threads.elementAt(i)).addLower(writeBack);
      } else {
	for (int j = 0; j < tmp.length; j++)
	  ((NinfThread)threads.elementAt(i)).
	    addLower(((NinfThread)threads.elementAt(tmp[j])));
      }
    }
    writeBack.start();
    for (int i = 0; i < threads.size(); i++) {
      ((NinfThread) threads.elementAt(i)).start();
    }
    threads.addElement(writeBack);
//    try {
//      writeBack.current.join(); /* wait for the end of write back */
//    } catch (Exception e) {
//      dbg.println("exception occured while waiting write back:" + e);
//    }
  }

  public NinfStub modify(NinfStub stub, NinfDataflow dataflow) {
    for (int i = 0; i < stub.nparam; i++) {
      stub.params[i].modify(dataflow.dinfo[i]); // dinfo = DependInfo
    }
    return stub;
  }
  
  public NinfStub makeCompoundStub() {
    int size = 0;
    for (int i = 0; i < dataflows.length; i++) 
      size += dataflows[i].stub.nparam;
    NinfStub tmp = NinfStub.getEmptyStub(size);
    for (int i = 0; i < dataflows.length; i++) {
      tmp.add(modify(dataflows[i].stub.copy(), dataflows[i]));
//      dbg.println("dataflow : " + i + " done.");
    }
    return tmp;
  }

  //NinfCompounData <- here
  //  NinfDataFlow dataflows[]
  //    int index
  //    int stubNum
  //    NinfStub stub
  //    DependInfo dinfo[]
  //      ArgPosition inputDepend
  //        int functionIndex
  //        int argNum
  //      ArgPosition outputDepends[]
  //        int functionIndex
  //        int argNum
  
  /** must rewrite this method to calculate min{CPM} */
  public void getfuncs () {

    // current state, dataflows -> funcs[]
    // make [map1] w/dataflow -> CPM1
    // modify [map1] and derive [map2] -> CPM2
    //                :
    // modify [map n-1] and derive [map n] -> CPM n
    // make funcs[] from [map n]

    funcs = new NinfNativeCallable[dataflows.length];
    try {
//      System.err.println("DataFlow Follows: ");

      int count = 0;
      for (int i = 0; i < dataflows.length; i++) {
//	String entry = funcManager.getFunctionName(dataflows[i].stubNum);

	//---- for debug
	//System.err.print("  " + i + ":" + dataflows[i].stubNum + ":"
	//+ entry + "(");
	//DependInfo di[] = dataflows[i].dinfo;
	//boolean first = true;
	//for (int j = 0; j < di.length; j++) {
	//if (!first) System.err.print(", ");
	//first = false;
	//System.err.print(di[j]);
	//}
	//System.err.println(")");
	//---- for debug

	funcs[i] = ((NinfFunctionStruct)(funcManager.getFunction(dataflows[i].stubNum))).getNativeCallable();

      }
    } catch (Exception e) {
      dbg.println("getStub() : " + e);
    }
  }
  public void addManager(FunctionManager f){
    funcManager = f;
  }
  
  int[][] getDependentList() {
    int tmp[][] = new int[dataflows.length][];
    for (int i = 0; i < dataflows.length; i++)
      tmp[i] = dataflows[i].dependent();
    return tmp;
  }

  public Stoppable call(NinfPacket pkt, XDRInputStream is, XDROutputStream os) 
  throws NinfException {
    NinfPacket.getRpyCallPacket().write(os);
    setupBuffers(is);
    forkThreads(os);
    return this;
  }

  public NinfCallable getCallable(){
    return this;
  }
  public NinfStub getStub(){
    return stub;
  }

  public void stop() {
System.out.println("Compound: stop called: finished = " + finished +", threads.size = " + threads.size());
    if (!finished)
      for (int i = 0; i < threads.size(); i++)
	((NinfThread)threads.elementAt(i)).kill();
  }
  public void finished(){
    finished = true;
    buffers = null;
    dataflows = null;
    commonData = null;
    funcs = null;
    stub = null;
    threads = null;
  }

  public boolean succeeded (){
    for (int i = 0; i < threads.size(); i++){
      Object tmp = threads.elementAt(i);
      if (tmp instanceof NinfConnectionThread)
	if (!((NinfConnectionThread)tmp).succeeded)
	  return false;
    }
    return true;
  }
}

// end of NinfCompound.java
