import java.io.*;
import java.util.Vector;
import org.gridforum.gridrpc.*;
import ninf.basic.*;

public class GrpcTest{
  static boolean verbose = false;
  static int N = 1;
  static int SKIP = 3;
  static int TIMES = 10;


 /****************************************************************/
  static boolean intTest(GrpcClient client){
    int a[], b[];
    int i, result;
    
    a = new int[N];
    b = new int[N];
    for (i = 0; i < N; i++){
      a[i] = (int)i;
      b[i] = 0;
    }
    
    try {
      System.out.print("IntTest ");
      GrpcHandle handle = client.getHandle("test/int_test");
      handle.callWith(new Integer(N), a, b);
      handle.callWith(new Integer(N), a, b);
      handle.callWith(new Integer(N), a, b);
      handle.callWith(new Integer(N), a, b);
      handle.dispose();
    } catch (GrpcException e){
      if (verbose){e.printStackTrace();}
      return false;
    }
    for (i = 0; i < N; i++){
      if (a[i] != b[i]){
	if (verbose) System.out.println(
		FormatString.format("file_test: a[%d](%d) != b[%d](%d)",
				    new Integer(i), new Integer(a[i]),
				    new Integer(i), new Integer(b[i])));
	return false;
      }
    }
    return true;
  }


 /****************************************************************/
  static String[] parseMyArg(String arg[]){
    Vector tmpV = new Vector();
    int index = 0;
    for (int i = 0; i < arg.length; i++){
      if (arg[i].equalsIgnoreCase("-verbose"))
	verbose = true;
      else 
	tmpV.addElement(arg[i]);
    }
    String tmp[] = new String[tmpV.size()];
    for (int i = 0; i < tmpV.size(); i++)
      tmp[i] = (String)(tmpV.elementAt(i));
    return tmp;
  }

  public static void main(String args[])throws GrpcException{
    args = parseMyArg(args);
    GrpcClient remoteClient = 
      GrpcClientFactory.getClient("ninf.client.NinfGrpcClient");
    remoteClient.activate(args[0]);

    GrpcClient localClient = 
      GrpcClientFactory.getClient("ninf.client.LocalGrpcClient");
    localClient.activate(args[0]);

    if (intTest(remoteClient)) System.out.println(" OK"); else System.out.println(" failed");
    if (intTest(localClient)) System.out.println(" OK"); else System.out.println(" failed");
  }
}
