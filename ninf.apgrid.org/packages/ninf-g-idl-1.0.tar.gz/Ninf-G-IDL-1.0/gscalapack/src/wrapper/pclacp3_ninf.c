#define _WRAPPER_
/* $Id: pclacp3_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define SCOMPLEX
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n
#define ROW_b ldb
#define COL_b m
void  pclacp3_ninf(	 int m,
		 int i,
		 scomplex a[],
		 int lda,
		 int n,
		 scomplex global_b[],
		 int ldb,
		 int node_ii,
		 int node_jj,
		  int rev
)
/* "pclacp3 is an auxiliary routine that copies from a global parallel array into a local replicated array or vise versa.  Notice that the entire submatrix that is copied gets placed on one node or more.  The receiving node can be specified precisely, or all nodes can receive, or just one row or column of nodes." */
/* OPTIONS */
{

	int maxldd;

	int desca[DESCLEN];

	int maxldb;
	scomplex *locb=NULL;
	int descb[DESCLEN];
	int desc_gb[DESCLEN];
	int row_locb, col_locb;


	INITIALIZE();

	SCALAR( "int", m);
	SCALAR( "int", i);
	SCALAR("int", lda);
	SCALAR("int", n);
	SCALAR("int", ldb);
	SCALAR("int", node_ii);
	SCALAR("int",node_jj);
	SCALAR("int", rev);

	ROW(b);
	COL(b);
	MAXLDD( maxldd, b );
	maxldb=maxldd;

	MATRIX("scomplex", b, ROW_b, COL_b);
	DISTRIBUTE( "scomplex", b, ROW_b, COL_b);

	COMMON_MATRIX( "scomplex", a, ROW_a, COL_a);
	Cdescinit( desca, ROW_a, COL_a, ROW_a, COL_a, 0, 0, PARA_CTXT, ROW_a, &linfo);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pclacp3)( &m, &i,
			       a, &desca,
			       locb, &ldb,
			       &node_ii, &node_jj, &rev);

	RETRIEVE("scomplex", a, ROW_a* COL_a);
	GATHER( "scomplex", b, ROW_b, COL_b);
	
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
	} else {
	}

	FREE_MATRIX(b);
	FREE_COMMON(a);
}

