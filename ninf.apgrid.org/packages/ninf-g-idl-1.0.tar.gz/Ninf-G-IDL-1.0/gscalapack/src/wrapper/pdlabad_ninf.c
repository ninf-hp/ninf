#define _WRAPPER_
/* $Id: pdlabad_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define DOUBLE
#include <gscalapack.h>

void  pdlabad_ninf(	 double *small,
		 double *large
)
/* "pdlabad takes as input the values computed by PSLAMCH for underflow and overflow, and returns the square root of each of these values if the log of LARGE is sufficiently large." */
/* OPTIONS */
{
	int maxldd;
	
	int locsmall[1], loclarge[1];

	INITIALIZE();

	SCALAR( "double", small);
	SCALAR( "double", large);

	*locsmall = *small;
	*loclarge = *large;

	if  (( mypnum != 0 ) ^ (serial==1) )
	  FortranCall(pdlabad)( &PARA_CTXT, locsmall, loclarge);

	RETRIEVE("double", locsmall, 1);
	RETRIEVE("double", loclarge, 1);

	if( mypnum == 0 ){
	  *small = *locsmall;
	  *large = *loclarge;
	} else {
	}

	
}

