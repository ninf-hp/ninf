package ninf.cproxy;
import ninf.basic.*;
import ninf.client.*;
import ninf.common.*;
import java.io.PrintStream;

public class NinfServerStructComm extends NinfServerStruct{
  public CommunicationInformation throughput;
  public  CommunicationInformation latency;

  NinfServerStructComm(String str) {
    super(str);
  }

  public NinfServerStructComm(String h, int p) {
    super(h,p);
  }

  NinfServerStructComm(NinfServerStruct struct) {
    super(struct.host, struct.port);
  }

  public NinfServerStructComm(String h, String port) {
    super(h,port);
  }

  NinfServerStructComm(XDRInputStream is) throws NinfException {
    super(is);
  }
  public NinfServerStructComm(NinfPacketInputStream is) throws NinfException {
    super(is);
  }

  void writeOut(PrintStream ps){
    System.out.println(this);
    System.out.println(this.throughput);
    System.out.println(this.latency);
    System.out.println(ps);

    ps.println(this.toCommand());
    ps.println(this.throughput.toCommand());
    ps.println(this.latency.toCommand());
  }
  
}
