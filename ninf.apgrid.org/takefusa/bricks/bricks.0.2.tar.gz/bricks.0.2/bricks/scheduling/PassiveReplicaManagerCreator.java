package bricks.scheduling;
import bricks.util.*;
import java.util.*;

public class PassiveReplicaManagerCreator extends SchedulingUnitCreator {

    // for bricks.tools.ShowUsage
    public PassiveReplicaManagerCreator(){}

    public PassiveReplicaManagerCreator(SubComponentFactory subComponentFactory) {
	this.subComponentFactory = subComponentFactory;
    }

    public String usage() {
	return "PassiveReplicaManager(<String keyOfRresourceDB>, <String keyOfServerMonitor>, <double compactness>, <double overstoredDiskRate>, <int numOfReplications>)";
    }

    public SchedulingUnit create(StringTokenizer st) 
	throws BricksParseException 
    {
	try {
	    String keyOfResourceDB = st.nextToken(" \t,()");
	    String keyOfServerMonitor = st.nextToken(" \t,()");
	    double compactness = 
		Double.valueOf(st.nextToken(" \t,()")).doubleValue();
	    double rate = Double.valueOf(st.nextToken(" \t,()")).doubleValue();
	    int num = Integer.valueOf(st.nextToken(" \t,()")).intValue();

	    return new PassiveReplicaManager(
		keyOfResourceDB, keyOfServerMonitor, compactness, rate, num
	    );

	} catch (NoSuchElementException e) {
	    e.printStackTrace();
	    throw new BricksParseException(usage());

	} catch (NumberFormatException e) {
	    e.printStackTrace();
	    throw new BricksParseException(usage());
	}
    }
}

