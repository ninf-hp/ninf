#define _WRAPPER_
/* $Id: pzgelqf_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define DCOMPLEX
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n
static	int worklen(int m, int n) {
	  int ret=1;
	  int IROFF,IAROW,IACOL,Mp0,Nq0,ICOFF;
	  ret = m * (m +n +m );
	  if NEED_BUFF {
#define IA 1
#define JA 1
#define MB_A rbloc
#define NB_A cbloc
#define MYROW myprow
#define MYCOL mypcol
#define NPROW nprow
#define NPCOL npcol
	    IROFF = MOD( IA-1, MB_A );
	    ICOFF = MOD( JA-1, NB_A );
	    IAROW = INDXG2P( IA, MB_A, MYROW, RSRC_A, NPROW );
	    IACOL = INDXG2P( JA, NB_A, MYCOL, CSRC_A, NPCOL );
	    Mp0   = NUMROC( M+IROFF, MB_A, MYROW, IAROW, NPROW );
	    Nq0   = NUMROC( N+ICOFF, NB_A, MYCOL, IACOL, NPCOL );

	    ret = MB_A * ( Mp0 + Nq0 + MB_A );
	  }
	  return ret;
}


void  pzgelqf_ninf(	 int m,
		 int n,
		 dcomplex global_a[],
		 int lda,
		 dcomplex global_tau[],
		 dcomplex work[],
		 int lwork,
		 int *info
)
/* "pzgelqf computes a LQ factorization of a complex distributed M-by-N matrix A = L * Q." */
/* OPTIONS */
{

	int maxldd;

	int maxlda;
	dcomplex *loca;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
	int row_loca, col_loca;

	dcomplex *loctau;

	dcomplex *locwork;
	int llocwork;

	INITIALIZE();

	SCALAR( "int", m);
	SCALAR( "int", n);
	SCALAR( "int", lda);
	SCALAR( "int", lwork);

	ROW( a);
	COL( a);
	MAXLDD( maxldd, a );
	maxlda = maxldd;

	MATRIX( "dcomplex", a, ROW_a, COL_a);
	VECTOR( "r", "dcomplex", tau,  min(m,n));
	DISTRIBUTE( "dcomplex", a, ROW_a  , COL_a);

	llocwork = worklen(m , n);
	llocwork = max(lwork,llocwork);
	WORK(locwork,llocwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pzgelqf)( &m, &n, loca, &one, &one, desca, loctau, locwork, &llocwork, &linfo);

	GATHER( "dcomplex", a, ROW_a  , COL_a);
	vGATHER( "r", "dcomplex", tau, min(m,n));
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
		*info = linfo;
	} else {
	}

	FREE_MATRIX(a);
	FREE_VECTOR(tau);

	
}

