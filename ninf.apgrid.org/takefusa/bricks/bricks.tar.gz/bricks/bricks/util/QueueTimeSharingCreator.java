package bricks.util;
import java.util.*;

public class QueueTimeSharingCreator extends SubComponentCreator {

    private SubComponentFactory subComponentFactory;

    // for bricks.tools.ShowUsage
    public QueueTimeSharingCreator(){}

    public QueueTimeSharingCreator(SubComponentFactory subComponentFactory) {
	this.subComponentFactory = subComponentFactory;
    }

    public String usage() {
	return "QueueTimeSharing(<Sequence throughput>, <double timeSlice>)";
    }

    public SubComponent create(StringTokenizer st) 
	throws BricksParseException 
    {
	try {
	    Sequence throughput = (Sequence)subComponentFactory.create(st);
	    double slice = 
		Double.valueOf(st.nextToken(" \t,()")).doubleValue();
	    QueueTimeSharing queue = new QueueTimeSharing(throughput, slice);
	    queue.setMaxThroughput();
	    return queue;

	} catch (NoSuchElementException e) {
	    e.printStackTrace();
	    throw new BricksParseException(usage());

	} catch (BricksParseException e) {
	    e.addMessage(usage());
	    throw e;
	}
    }
}

