#define _WRAPPER_
/* $Id: pslaed0_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define FLOAT
#include <gscalapack.h>

#define ROW_q ldq
#define COL_q n
#define ROW_qs ldqs
#define COL_qs n
static	int worklen(int n) {
	  int ret=1;
	  int NP, NQ, IQROW, IQCOL;
#define NPROW nprow
#define NPCOL npcol
#define MYROW myprow
#define MYCOL mypcol
#define N n
#define MB_Q rbloc
#define NB_Q cbloc
#define RSRC_Q 0
#define CSRC_Q 0
#define IQ 1
#define JQ 1
	  ret = 6*n + n*n;
	  if NEED_BUFF {
	    NP = NUMROC( N, MB_Q, MYROW, IQROW, NPROW );
	    NQ = NUMROC( N, NB_Q, MYCOL, IQCOL, NPCOL );
	    IQROW = INDXG2P( IQ, NB_Q, MYROW, RSRC_Q, NPROW );
	    IQCOL = INDXG2P( JQ, MB_Q, MYCOL, CSRC_Q, NPCOL );
	    ret =  6*N + 2*NP*NQ;
	  }
	  return ret;
}

static	int iworklen(int n) {
	  int ret=1;
	  ret = 2+7*n+8;
	  if NEED_BUFF {
	    ret = 2 + 7*N + 8*NPCOL;
	  }
	return ret;
}


void  pslaed0_ninf(	 int n,
		 float d[],
		 float e[],
		 float global_q[],
		 int ldq,
		 float qstore[],
		 int ldqs,
		 float work[],
		 int iwork[],
		 int *info
)
/* "pslaed0 computes all eigenvalues and corresponding eigenvectors of a symmetric tridiagonal matrix using the divide and conquer method." */
/* OPTIONS */
{
	int maxldd;

	int maxldq;
	float *locq=NULL;
	int descq[DESCLEN];
	int desc_gq[DESCLEN];
	int row_locq, col_locq;

	float *locwork=NULL;
	int llocwork;
	float *lociwork=NULL;
	int llociwork;

	INITIALIZE();

	SCALAR( "int", n);

	COMMON("float", d, n);
	COMMON("float", e, n-1);

	ROW( q);
	COL( q);
	MAXLDD(maxldd, q);
	maxldq=maxldd;

	MATRIX( "float", q, ROW_q, COL_q);
	DISTRIBUTE( "float", q, ROW_q, COL_q);

	llocwork = worklen(n);
	WORK(locwork,llocwork);
	llociwork = iworklen(n);
	WORK(lociwork,llociwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pslaed0)( &n, d, e,
			       locq, &one, &one, descq,
			       locwork, lociwork, &linfo);

	RETRIEVE("float", d, n);
	RETRIEVE("float", e, n-1);
	GATHER( "float", q, ROW_q  , COL_q);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
		*info = linfo;
	} else {

	}
	FREE_COMMON(d);
	FREE_COMMON(e);
	FREE_MATRIX(q);
        FREE(locwork);
        FREE(lociwork);
}

