/*
 *  $Id: ninf_pipe.c,v 1.5 2000/12/03 09:28:43 tatebe Exp $
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ninf_pipe.h"
#include "ninf_stream.h"

#define TMP_FILE_TEMPLATE "/tmp/ninf_tmp%d.XXXXXX"
static int tmp_ser_num = 0;

static void setup_filename (char * filename){
    sprintf(filename, TMP_FILE_TEMPLATE, tmp_ser_num);
    while (strcmp(mktemp(filename), "") == 0) {
	++tmp_ser_num;
	sprintf(filename, TMP_FILE_TEMPLATE, tmp_ser_num);
    }
}

ninf_pipe *    new_ninf_pipe(int flag){
  ninf_pipe * pipe = (ninf_pipe *)malloc(sizeof(ninf_pipe));
  if (pipe == NULL)
    return NULL;
  pipe->flag = flag;
  if (pipe->flag == NINF_PIPE_SOCKETPAIR){
    pipe->filename = NULL;
    if (socketpair(AF_UNIX, SOCK_STREAM, 0, pipe->fd) < 0){
      perror("socketpair");
      return NULL;
    }
  } else {
    pipe->filename = (char *)malloc(NINF_PIPE_FILENAME_LEN);
    setup_filename(pipe->filename);
    if ((pipe->l_sock = ninf_sock_local(pipe->filename)) < 0){
      return NULL;
    }
    register_unlink(pipe->filename);
    
    if (listen(pipe->l_sock, 1) < 0){	/* ready to accept */
      perror("listen: ");
      return NULL;
    }
  }
  return pipe;
}

void        delete_ninf_pipe(ninf_pipe * pipe){
  if (pipe->flag == NINF_PIPE_SOCKETPAIR){
    /* nothing to do */
  } else {
    free(pipe->filename);
  }
  free(pipe);
}

char *             ninf_pipe_description(ninf_pipe * pipe){
  static char buffer[NINF_PIPE_FILENAME_LEN];
  if (pipe->flag == NINF_PIPE_SOCKETPAIR){
    sprintf(buffer, "%d", pipe->fd[0]);
  } else {
    sprintf(buffer, "%s", pipe->filename);
  }
  return buffer;
}

int               ninf_pipe_parent_clean(ninf_pipe * pipe){
  if (pipe->flag == NINF_PIPE_SOCKETPAIR){
    close(pipe->fd[0]);
  } else {
    int size;
    struct sockaddr_in stub_addr; 
    size = sizeof(stub_addr);

    if((pipe->fd[1] = accept(pipe->l_sock,(struct sockaddr *)&stub_addr,&size)) < 0){
      extern int errno;
      perror("accept:");
      ninf_error("accept failed(%d)",errno);
      return FALSE;
    }
    close(pipe->l_sock);
  }
  return TRUE;
}

int               ninf_pipe_child_clean(ninf_pipe * pipe){
  if (pipe->flag == NINF_PIPE_SOCKETPAIR){
    close(pipe->fd[1]);
  } else {
    /* nothing to do */
  }
}
int                ninf_pipe_get_fd(ninf_pipe * pipe){
  return pipe->fd[1];
}

int get_fd_from_description(char * description, int flag){
  if (flag == NINF_PIPE_SOCKETPAIR){
    return atoi(description);
  } else {
    return ninf_connect_local(description);
  }
}

