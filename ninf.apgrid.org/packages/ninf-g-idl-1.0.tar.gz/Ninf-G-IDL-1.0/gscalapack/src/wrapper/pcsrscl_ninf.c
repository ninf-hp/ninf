#define _WRAPPER_
/* $Id: pcsrscl_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define SCOMPLEX
#include <gscalapack.h>

void  pcsrscl_ninf(	 int  n,
		 float sa,
#ifdef HAVE_ABS
		 scomplex global_x[],
#else
                 scomplex global_x[],
#endif
		 int incx
)
/* "pcsrscl multiplies an N-element complex distributed vector X by the real scalar 1/a. This is done without overflow or underflow as long as the final X/a does not overflow or underflow." */
/* OPTIONS */
{

  int ROW_x;
  int COL_x;
  scomplex *locx=NULL;
  int maxldx;
  int descx[DESCLEN];
  int desc_gx[DESCLEN];
  int row_locx, col_locx;

  int maxldd;


  INITIALIZE();

	SCALAR("int",n);
	SCALAR("int", incx);
	SCALAR( "float", sa);
	square( 1+(n-1)*abs(incx), &ROW_x, &COL_x);

	ROW(x);
	COL(x);
	MAXLDD(maxldd, x );
	maxldx=maxldd;

	MATRIX("scomplex", x, ROW_x, COL_x);
	DISTRIBUTE("scomplex", x, ROW_x, COL_x);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pcsrscl)( &n, &sa,
                               locx, &one, &one, descx,
                               &incx);

	GATHER( "scomplex", x, ROW_x, COL_x);

	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
	} else {
	}

	FREE_MATRIX(x);
	
}

