#define _WRAPPER_
/* $Id: pdgeequ_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define DOUBLE
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n
void  pdgeequ_ninf(	 int m,
		 int n,
		 double global_a[],
		 int lda,
		 double global_r[],
		 double global_c[],
		 double *rowcnd,
		 double *colcnd,
		 double *amax,
		 int *info
)
/* "pdgeequ computes row and column scalings intended to equilibrate an M-by-N distributed matrix A and reduce its condition number." */
/* OPTIONS */
{
	int maxldd;

	int maxlda;
	double *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
	int row_loca, col_loca;
        
	double *locr=NULL;
	double *locc=NULL;

	double locrowcond[1], loccolcond[1], locamax[1];

	INITIALIZE();

	SCALAR( "int", m);
	SCALAR( "int", n);
	SCALAR( "int", lda);

	ROW( a);
	COL( a);
	MAXLDD( maxldd, a );
	maxlda = maxldd;

	MATRIX( "double", a, ROW_a, COL_a);
	DISTRIBUTE( "double", a, ROW_a  , COL_a);
	VECTOR("r", "double", r, m);
	VECTOR("c", "double", c, n);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pdgeequ)( &m, &n,
                               loca, &one, &one, desca,
                               locr, locc,
                               locrowcond, loccolcond, locamax,
                               &linfo);

	vGATHER("r", "double", r, m);
	vGATHER("c", "double", c, n);
        RETRIEVE("double",locrowcond,1);
        RETRIEVE("double",loccolcond,1);
        RETRIEVE("double",locamax,1);

	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
	  *rowcnd = *locrowcond;
	  *colcnd = *loccolcond;
	  *amax = *locamax;
	  *info = linfo;
	} else {
	}

	FREE_MATRIX(a);
        FREE_VECTOR(r);
        FREE_VECTOR(c);
	
}

