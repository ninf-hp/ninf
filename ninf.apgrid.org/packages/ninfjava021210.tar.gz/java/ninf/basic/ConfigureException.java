package ninf.basic;

public class ConfigureException extends NinfException {
  public ConfigureException() {
    super();
  }
  public ConfigureException(String s) {
    super(s);
  }
}

// end of ConfigureException.java
