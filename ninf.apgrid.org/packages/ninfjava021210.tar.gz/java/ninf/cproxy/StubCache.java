package ninf.cproxy;
import ninf.basic.*;
import ninf.client.*;
import ninf.common.*;
import java.util.Vector;
import java.util.Hashtable;
import java.util.Enumeration;

public class StubCache extends CallableCache{
  CProxyServer master;
  CallableFactory factory = new StubCallableFactory();

  static final CommandRepresent acceptCommands[] = {
    new CommandRepresent("stub",   0), 
    new CommandRepresent("nostub", 0)
  };

  static CommandParser parser = new CommandParser(acceptCommands);
  static NinfLog dbg = new NinfLog("StubCache");
  
  StubCache(CProxyServer master){
    super();
    this.master = master;
  }

  public Callable getStubCallable(FunctionName fullName) throws NinfException {
    try {
      return super.getStubCallable(fullName);
    } catch (NinfErrorException e){
      Callable stub = retrieveStubInfo(master.metaServer, fullName);
      if (stub != null)
	return stub;
      throw new NinfErrorException(NinfError.CANTFINDSTUB);
    }
  }
  
  Callable retrieveStubInfo(MetaServerReference metaServer, 
				FunctionName fullName) 
  throws NinfException{
    MetaServerConnection con = metaServer.connect();
    con.send(new NinfCommand("getStub", fullName.toString()));
    String line = con.readLine();
    NinfCommand ack = parser.readCommand(line);
    //    if (ack.argc() != 2)
    //      throw new CommandParseException(line);
    if (ack.command.equals("stub")){
      NinfStub stub = new NinfStub(new XDRInputStream(con.is));
      con.close();
      return registerStub(fullName, stub);
    } else {
      throw new NinfErrorException(NinfError.CANTFINDSTUB);
    }
  }

  Callable registerStub(FunctionName fullName, NinfStub stub){
    int index = getIndex();
    Callable tmp = factory.generate(stub, index, master);
    registerCallable(fullName, tmp, index);
    return tmp;
  }
}
