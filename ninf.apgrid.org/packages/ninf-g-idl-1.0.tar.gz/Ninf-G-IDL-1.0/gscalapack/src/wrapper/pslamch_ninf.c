#define _WRAPPER_
/* $Id: pslamch_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define FLOAT
#include <gscalapack.h>

void  pslamch_ninf(	
		 char cmach,
		 float *ret /* return value */
)
/* "pslamch determines single precision machine parameters." */
/* OPTIONS */
{
  extern float FortranCall(pslamch)( int*, char*);

  float locpslamch_[1];
	
	INITIALIZE();

	SCALAR( "char", cmach);

	if  (( mypnum != 0 ) ^ (serial==1) )
            FortranReturnSimple( pslamch, locpslamch_,
                           ( &PARA_CTXT, &cmach) );

	RETRIEVE("float", locpslamch_, 1);

	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
	  *ret = *locpslamch_;
	} else {
	}

	
}

