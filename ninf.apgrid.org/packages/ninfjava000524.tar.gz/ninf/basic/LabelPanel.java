package ninf.basic;
import java.awt.*;

public class LabelPanel extends Panel {
  public LabelPanel(String str, Component comp){
    setLayout(new BorderLayout());
    Label label = new Label(str, Label.CENTER);
    label.setBackground(Color.darkGray);
    label.setForeground(Color.white);
    add("Center", comp);
    add("North", label);
  }
}
