package bricks.scheduling;
import bricks.util.*;
import bricks.environment.*;
import java.util.*;

public class LoadBoundRecvTimeReplicationScheduler extends LoadBoundSendTimeReplicationScheduler implements SchedulingUnit {

    public LoadBoundRecvTimeReplicationScheduler(
	String keyOfMetaPredictor, String keyOfReplicaManager, 
	String keyOfServerMonitor, double minLoadScore
    ) {
	super(keyOfMetaPredictor, keyOfReplicaManager, 
	      keyOfServerMonitor, minLoadScore);
    }

/************************* needed method *************************/
    public String getName() {
	return "LoadBoundRecvTimeReplicationScheduler";
    }

    // override
    protected Host select(
	double currentTime, RequestedData data, Enumeration e
    ) {
	return selectBySendAndComputeDuration(currentTime, data, e);
    }

    protected Host selectDataDestination(
	double currentTime, RequestedData data, Host computeHost
    ) {
	Host destinationHost = null;
	double loadScore = 0.0;
	
	Vector v = shuffle(resourceDB.hosts(data));
	Enumeration e = v.elements();

	while (e.hasMoreElements()) {
	    Host h = (Host)e.nextElement();
	    if (h.equals(computeHost))
		continue;
	    if (!hasAvailableDisk(currentTime, h, data.dataSizeForReceive))
		continue;

	    StaticHostInfo staticInfo = resourceDB.getStaticHostInfo(h);
	    HostInfo info = getHostInfo(currentTime, h);
	    double score = staticInfo.performance / (info.loadAverage + 1.0);
	    if (loadScore < score) {
		destinationHost = h;
		loadScore = score;
	    }
	}
	return destinationHost;
    }
}

