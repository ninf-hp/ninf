package jp.go.aist.gtrc.util;

import java.util.Vector;

import javassist.CtField;
import javassist.CtMethod;

public class Utils {
	public static CtField[] filterProps(CtField[] fields) throws ClassNotFoundException {
		Vector<CtField> props = new Vector<CtField>();
		for (CtField field : fields) {
			for (Object an : field.getAnnotations()) {
				if (an instanceof OperationAN) {
					System.err.println("WARN: @OperationAN annotation for field \"" +
						field.getName() + "\" is ignored.");
				}
				if (an instanceof PropertyAN) {
					props.add(field);
					break;
				}
			}
		}
		return props.toArray(new CtField[0]);
	}

	public static CtMethod[] filterOps(CtMethod[] methods) throws ClassNotFoundException {
		Vector<CtMethod> ops = new Vector<CtMethod>();
		for (CtMethod method : methods) {
			for (Object an : method.getAnnotations()) {
				if (an instanceof PropertyAN) {
					System.err.println("WARN: @PropertyAN annotation for method \"" +
						method.getName() + "\" is ignored.");
				}
				if (an instanceof OperationAN) {
					ops.add(method);
					break;
				}
			}

		}
		return ops.toArray(new CtMethod[0]);
	}
}
