#define _WRAPPER_
/* $Id: pclacon_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define SCOMPLEX
#include <gscalapack.h>

#define ROW_v mv
#define COL_v nv
#define ROW_x mx
#define COL_x nx

void  pclacon_ninf(	 int n,
		 scomplex global_v[],
		 scomplex global_x[],
		 float *est,
		 int *kase
)
/* "pclacon estimates the 1-norm of a square, complex distributed matrix A. Reverse communication is used for evaluating matrix-vector products." */
/* OPTIONS */
{
	int maxldd;

	scomplex *locv=NULL;
	int maxldv;
	int descv[DESCLEN];
	int desc_gv[DESCLEN];
	int mv, nv;
	int row_locv, col_locv;

	int maxldx;
	scomplex *locx=NULL;
	int descx[DESCLEN];
	int desc_gx[DESCLEN];
	int mx, nx;
	int row_locx, col_locx;

	float locest[1];

	INITIALIZE();

	SCALAR( "int", n);

	COMMON("int", kase, 1);

	square( n, &mv, &nv);
	square( n, &mx, &nx);

	ROW(v);
	COL(v);
	ROW(x);
	COL(x);
	MAXLDD( maxldd, x );
	maxldv = maxldd;
	maxldx = maxldd;

	MATRIX( "scomplex", v, ROW_v, COL_v);
	MATRIX( "scomplex", x, ROW_x, COL_x);

	DISTRIBUTE( "scomplex", x, ROW_x, COL_x);

	if  (( mypnum != 0 ) ^ (serial==1) )
		FortranCall(pclacon)( &n,
				      locv, &one, &one, descv,
				      locx, &one, &one, descx,
				      locest, kase);

	GATHER( "scomplex", x, ROW_x, COL_x);

	RETRIEVE("int", locest, 1);
	RETRIEVE("float", kase, 1);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
		*est = *locest;
	} else {
	}

	FREE_MATRIX(x);
	FREE_MATRIX(v);
	FREE_COMMON(kase);
}

