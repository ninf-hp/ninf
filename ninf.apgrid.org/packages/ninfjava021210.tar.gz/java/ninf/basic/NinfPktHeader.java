package ninf.basic;

import java.io.*;

public class NinfPktHeader {
  /** error, negative code */
  public static final int NINF_PKT_ERROR = -1;
  /** none */
  public static final int NINF_PKT_NONE = 0;	
  /** kill */
  public static final int NINF_PKT_KILL = 1;
  /** client -> stub */
  public static final int NINF_PKT_TO_STUB = 2;
  /** stub -> client */
  public static final int NINF_PKT_TO_CLIENT =	3;
  /** request stub info */
  public static final int NINF_PKT_REQ_STUB_INFO = 4;
  /** reply stub info */
  public static final int NINF_PKT_RPY_STUB_INFO = 5;
  /** request call */
  public static final int NINF_PKT_REQ_CALL = 6;
  /** reply call */
  public static final int NINF_PKT_RPY_CALL = 7;
  /** request compound stub */
  public static final int NINF_PKT_REQ_COMP = 10;
  /** reply kill pkt */
  public static final int NINF_PKT_RPY_KILL = 11;


  public static final int NINF_PKT_STDOUT = 15;      /* for forwarding stdout */
  public static final int NINF_PKT_STDERR = 16;      /* for forwarding stderr */

  /* get storage_resource */
  public static final int NINF_PKT_GET_STORAGE_RESOURCE   = 17;
  /* put storage_resource */  
  public static final int NINF_PKT_PUT_STORAGE_RESOURCE   = 18;
  /* clear storage_resource */
  public static final int NINF_PKT_CLEAR_STORAGE_RESOURCE = 19;
  /* put storage_resource */
  public static final int NINF_PKT_RPY_STORAGE_RESOURCE   = 20; 
  /* for transer */
  public static final int NINF_PKT_TRANSFER               = 21; 
  /* for terminate transer */
  public static final int NINF_PKT_TRANSFER_END           = 22; 
  /* for reply termination packet */
  public static final int NINF_PKT_RPY_TRANSFER_END       = 23; 



  /** NINF_Q_Protocols 
    req stub index list */
  public static final int NINF_PKT_REQ_STUB_INDEX_LIST = 50;
  /** rpy stub index list */
  public static final int    NINF_PKT_RPY_STUB_INDEX_LIST = 51;       
  /** req stub by index */
  public static final int  NINF_PKT_REQ_STUB_BY_INDEX = 52;       
  /** rpy stub by index (is not used) */
  public static final int  NINF_PKT_RPY_STUB_BY_INDEX = 53;

  /** add new server info to MetaServer */
  public static final int NINF_PKT_NEW_SERVER = 100;

  /** add new stub info to MetaServer */
  public static final int NINF_PKT_NEW_STUB = 101;

  /** throughput  */
  public static final int NINF_PKT_THROUGHPUT = 102;     /* arg1 = size, arg2 = mode(0=both,1=fore,2=back) */
  public static final int NINF_PKT_RPY_THROUGHPUT = 103;

  /** load */
  public static final int NINF_PKT_LOAD = 104;  
  public static final int NINF_PKT_RPY_LOAD = 105;

  public static final int NINF_PKT_CHARACTER = 106;
  public static final int NINF_PKT_RPY_CHARACTER = 107;

  public static final int NINF_PKT_GETTIME = 108;
  public static final int NINF_PKT_RPY_GETTIME = 109;
  /** 
    consult stub info from MetaServer to MetaServer
    parameter:
      arg1, arg2 : 0 (dummy)
      String: entry name
      String: uniq id (localy-uniq-id@initiator'sFQDN)
      Int   : count
      String: initiator's FQDN
      Int   : initiator's port
    */
  public static final int NINF_PKT_CONSULT_STUB = 105;

  /** Dump info holded by MetaServer */
  public static final int NINF_DUMP_MS_INFO = 200;
  public static final int NINF_RPY_MS_INFO  = 201;

  /** exec stub program directly */
  public static final int NINF_PKT_REQ_EXEC = 0xfe;
  /** reply stub program directly */
  public static final int NINF_PKT_RPY_EXEC = 0xff;

  /** options for req_stub_index_list */
  public static final int PARTIAL = 0;
  public static final int EXACT = 1;

  public static NinfPktHeader StubReq =
    new NinfPktHeader(NINF_PKT_REQ_STUB_INFO, 0);

  public boolean isRpyStubInfo(){
    return (code == NINF_PKT_RPY_STUB_INFO);
  }

  public boolean isRpyCall(){
    return (code == NINF_PKT_RPY_CALL);
  }

  NinfLog dbg = new NinfLog(this);

  public int size;
  public int code;
  public int arg1;
  public int arg2;
  public static final int PktHeaderSize = 16;

  public NinfPktHeader(int code, int size){
    this.size = size;
    this.code = code;
    arg1 = 0;
    arg2 = 0;
  }

  public NinfPktHeader(int code, int size, int a, int b){
    this.size = size;
    this.code = code;
    arg1 = a;
    arg2 = b;
  }

  public String toString(){
    String tmp =
      "NinfPktHeader(size: " +size+
	", code: " +code+", arg1: " +arg1+", arg2: " +arg2+")";
    return tmp;
  }

  public NinfPktHeader(XDRInputStream is) throws IOException{
    size = is.readInt() - PktHeaderSize;
    code = is.readInt();
    arg1 = is.readInt();
    arg2 = is.readInt();
  }
  public void writeTo(XDROutputStream os) throws IOException{
    //    dbg.println(toString());
    os.writeInt(size + PktHeaderSize);
    os.writeInt(code);
    os.writeInt(arg1);
    os.writeInt(arg2);
  }
}

// end of NinfPktHeader.java
