package ninf.MetaServer;
import ninf.netsolve.NetSolveException;
import java.io.PrintStream;
import ninf.basic.NinfException;

public class NinfNetSolveException extends NinfException {
  NetSolveException e;
  public NinfNetSolveException() {
    super();
  }
  public NinfNetSolveException(NetSolveException e) {
    super();
    this.e = e;
  }
  public void printStackTrace(PrintStream ps){
    if (e != null){
      ps.println("NinfNetSolveException: original exception follows");
      e.printStackTrace(ps);
    } else 
      super.printStackTrace(ps);
  }
}

// end of NinfNetSolveException.java
