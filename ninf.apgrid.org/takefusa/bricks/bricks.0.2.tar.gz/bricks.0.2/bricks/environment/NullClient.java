package bricks.environment;
import bricks.util.*;
import bricks.scheduling.*;
import java.io.*;
import java.util.*;

/** 
 * NullClient.java
 */
public class NullClient extends Client {

    /**
     * Constructs NullClient.
     */
    public NullClient() {
	nextEventTime = Double.POSITIVE_INFINITY;
    }

    /** 
     * returns a type of the Client.
     */
    public String getName() {
	return "NullClient";
    }

    public void setHost(Host host) {;}
    public void processEvent(double currentTime) {;}
    public void updateNextEvent(double currentTime) {;}
    public void fallback(double currentTime, RequestedData data) {;}
    public void initSession(double currentTime) {;}

    public String toOriginalString(double currentTime) {
	return "  [" + getName() + "]\n";
    }

    public String toInitString() {
	return "  [" + getName() + "]\n";
    }
}


