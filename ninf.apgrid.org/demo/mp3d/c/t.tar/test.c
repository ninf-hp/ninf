#include "framebuffer.h"
#define BLACK (-1)

main(){
    int i,t;

    fb_init(0);
    fb_line(0,0,100,100,0xFF00);
    for(i = 0; i < 100; i++){
	fb_drawpoint(i+100,i+100,0xFF);
    }
    fb_circle(100,100,50,BLACK);
    fb_flush();
    getchar();
    for(t = 0; t < 100; t += 2){
	/* fb_clear(100,100,500,500,0); */
	fb_circle(200+t,300,50,BLACK);
	fb_flush();
	printf("t = %d\n",t);
    }
    getchar();
}

fb_clear(x1,y1,x2,y2,color)
{
    int x,y;

    for(x = x1; x < x2; x++)
      for(y = y1; y < y2; y++)
	fb_drawpoint(x,y,color);
}

