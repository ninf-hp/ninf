package ninf.toNs;
import ninf.basic.*;
import ninf.client.*;
import ninf.cproxy.*;
import ninf.netsolve.*;

import java.io.IOException;
import java.util.Vector;

public class NetSolveLatch extends StubCallable implements Stoppable{
  Problem problem;
  static NinfLog dbg = new NinfLog("NetSolveLatch");
  NetSolveBuffer nsBuffer;
  CallContext callContext;
  String agent;


  public NetSolveLatch(Problem problem, int index, String agent) throws NinfException{
    super(problem.toNinfStub(), index);
    this.problem = problem;
    this.agent = agent;
  }

  void setupNetSolveVector(CallContext context, Problem problem) throws NinfIOException{
    try {
      nsBuffer = new NetSolveBuffer(problem.nb_input);
      nsBuffer.buffers = problem.transNinfBuffers(context, nsBuffer.m, nsBuffer.n);

      nsBuffer.dump();

    } catch (IOException e){
      throw new NinfIOException(e);
    }
  }

  int[][] writeBackToBuffer(Problem problem, Vector output, BufferObject[] buffers) throws NinfIOException{
    try {
      return problem.writeBackToBuffer(output, buffers);
    } catch (IOException e){
      throw new NinfIOException(e);
    }
  }

  void sendDummyInformation(NinfPacketOutputStream pos) throws NinfException{
    pos.writeDouble(-1.0);
    pos.writeDouble(-1.0);
    pos.writeDouble(-1.0);
    pos.writeString("NetSolveAdapter on "+ ToNsAdapter.conf.myhostname);
    pos.writeInt(ToNsAdapter.conf.port);
  }

  public Stoppable call(NinfPacket pkt, int serial,
			XDRInputStream is, XDROutputStream os) 
    throws NinfException {
    NinfServerConnection con;
    StubCallableContext context;

    NinfPacketInputStream pis = new NinfPacketInputStream(pkt, is);    
    XDRInputStream dis = new XDRInputStream(pis);
    context = receiveNinfCode(pis);

    callContext= stub.setupBuffers(dis);
    context.modifyBuffers(callContext.buffers);
    stub.serverReceive(callContext, dis);

    setupNetSolveVector(callContext, problem);
    try {
      SubmitJob job = new SubmitJob(agent, problem, nsBuffer.buffers, null, 
				    nsBuffer.m, nsBuffer.n);
      Vector output = job.start();
      writeBackToBuffer(problem, output, callContext.buffers);
    } catch (NetSolveException e){
      throw new NinfNetSolveException(e);
    }

    NinfPacketOutputStream pos = new NinfPacketOutputStream(os, false);
    stub.serverSend(callContext, pos);
    sendDummyInformation(pos);
    pos.flush();
    return this;
  }

  public void stop() {
  }
}


