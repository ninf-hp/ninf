#define _WRAPPER_
/* $Id: pclarzt_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define SCOMPLEX
#include <gscalapack.h>

#define ROW_v k
#define COL_v n
#define ROW_t ldt
#define COL_t k
static	int worklen(int k) {
	  int ret=1;
	  ret=max(1,(k*(k-1)/2));
	  return ret;
}

void  pclarzt_ninf(	 char direct,
		 char storev,
		 int n,
		 int k,
		 scomplex global_v[],
		 int ldv,
		 float global_tau[],
		 scomplex global_t[],
		 int ldt
)
/* "pclarzt forms the triangular factor T of a complex block reflector H of order > n, which is defined as a product of k elementary reflectors as returned by PCTZRZF." */
/* OPTIONS */
{
	int maxldd;

	int maxldv;
	scomplex *locv=NULL;
	int descv[DESCLEN];
	int desc_gv[DESCLEN];
	int row_locv, col_locv;

	int maxldt;
	scomplex *loct=NULL;
	int desct[DESCLEN];
	int desc_gt[DESCLEN];
	int row_loct, col_loct;

	scomplex *loctau=NULL;

	scomplex *locwork=NULL;
	int llocwork;

	INITIALIZE();

	SCALAR( "char", direct);
	SCALAR( "char", storev);
	SCALAR( "int", n);
	SCALAR( "int", k);
	SCALAR("int",ldv);
	SCALAR("int", ldt);

	ROW(v);COL(v);
	MAXLDD(maxldd, v);
	maxldv=maxldd;

	ROW(t);COL(t);
	MAXLDD( maxldd, t);
	maxldt = maxldd;

	MATRIX("scomplex", v, ROW_v, COL_v);
	DISTRIBUTE("scomplex", v, ROW_v, COL_v);
	MATRIX("scomplex", t, ROW_t, COL_t);

	VECTOR(  "r","scomplex", tau, k);
	vDISTRIBUTE( "r" , "scomplex", tau, k);

	MATRIX("float", t, ROW_t, COL_t);

	llocwork=worklen(k);
	WORK(locwork,llocwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pclarzt)( &direct, &storev,
                               &n, &k,
                               locv, &one, &one, descv,
                               loctau,
                               loct,
                               locwork);

	GATHER("scomplex", v, ROW_v, COL_v);
	GATHER("scomplex", t, ROW_t, COL_t);

	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
	} else {
	}
        FREE_MATRIX(v);
        FREE_MATRIX(t);
        FREE_VECTOR(tau);
        FREE(locwork);
	
}

