#define _WRAPPER_
/* $Id: pcrot_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define SCOMPLEX
#include <gscalapack.h>
#define ROW_x xm
#define COL_x xn
#define ROW_y ym
#define COL_y yn
void  pcrot_ninf(   int n,
#ifdef HAVE_ABS               
	       scomplex global_x[],
	       int incx,    
	       scomplex global_y[],
#else
                scomplex global_x[],
	       int incx,    
	       scomplex global_y[],
#endif
	       int incy,    
	       float c,
	       scomplex s
)
/* "pcrot applies a plane rotation, where the cos (C) is real and the sin (S) is complex, and the vectors CX and CY are complex, i.e.,\\n */
/*     [  X  ] := [  C          S  ] [ X ]\\n */
/*     [  Y  ] := [ -conjg(S)   C  ] [ Y ]" */
/* OPTION */
{
  int maxldd;

  int maxldx;
  float *locx=NULL;
  int descx[DESCLEN];
  int desc_gx[DESCLEN];
  int row_locx, col_locx;
  int xm, xn;

  int maxldy;
  float *locy=NULL;
  int descy[DESCLEN];
  int desc_gy[DESCLEN];
  int row_locy, col_locy;
  int ym, yn;

  SCALAR("int", n);
  SCALAR("int",incx);
  SCALAR("int",incy);
  SCALAR( "float", c);
  SCALAR( "scomplex", s);

  if (incx!=1) incx=ROW_x;
  if (incy!=1) incy=ROW_y;

  square( 1+(n-1)*abs(incx), &xm, &xn);
  square( 1+(n-1)*abs(incy), &ym, &yn);

  ROW(x);
  COL(x);
  MAXLDD(maxldd, x);
  maxldx=maxldd;
  ROW(y);
  COL(y);
  MAXLDD(maxldd, y);
  maxldy=maxldd;

  MATRIX("scomplex", x, ROW_x, COL_x);
  MATRIX("scomplex", y, ROW_y, COL_y);

  DISTRIBUTE("scomplex", x, ROW_x, COL_x);
  DISTRIBUTE("scomplex", y, ROW_y, COL_y);

  if ( (mypnum!=0) || (serial==1))
    FortranCall(pcrot)( &n,
                        locx, &one, &one,  descx,
                        &incx,
                        locy, &one, &one, descy,
                        &incy,
                        &c, &s);

  GATHER("scomplex", x, ROW_x, COL_x);
  GATHER("scomplex", y, ROW_y, COL_y);

  FREE_MATRIX(x);
  FREE_MATRIX(y);

}
