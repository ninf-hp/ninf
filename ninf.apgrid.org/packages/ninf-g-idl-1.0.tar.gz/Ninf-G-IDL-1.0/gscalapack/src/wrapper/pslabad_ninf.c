#define _WRAPPER_
/* $Id: pslabad_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define FLOAT
#include <gscalapack.h>

void  pslabad_ninf(	 float *small,
		 float *large
)
/* "pslabad takes as input the values computed by PSLAMCH for underflow and overflow, and returns the square root of each of these values if the log of LARGE is sufficiently large." */
/* OPTIONS */
{
	int maxldd;
	
	int locsmall[1], loclarge[1];

	INITIALIZE();

	SCALAR( "float", small);
	SCALAR( "float", large);

	*locsmall = *small;
	*loclarge = *large;

	if  (( mypnum != 0 ) ^ (serial==1) )
	  FortranCall(pslabad)( &PARA_CTXT, locsmall, loclarge);

	RETRIEVE("float", locsmall, 1);
	RETRIEVE("float", loclarge, 1);

	if( mypnum == 0 ){
	  *small = *locsmall;
	  *large = *loclarge;
	} else {
	}

	
}

