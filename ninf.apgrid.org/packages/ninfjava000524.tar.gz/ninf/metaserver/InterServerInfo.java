package ninf.metaserver;
import ninf.basic.*;
import ninf.common.*;
import ninf.client.*;

class InterServerInfo {
  CommunicationInformation throughput, latency;

  InterServerInfo(CommunicationInformation throughput, 
		  CommunicationInformation latency){
    this.throughput = throughput;
    this.latency    = latency;
  }

  public String toString(){
    return throughput.toString();
  }
}
