#include "ninf_Q.h"
#include "html.h"

#define ETL 

#define MAX_REG_ENTRY_STUB 0x100  /* 256 entryis */
#ifdef OCHA
#define NINFDIR "/home02/nii/public_html/Ninf/"
#define STUBDIR "/home02/nii/public_html/Stub/"
#endif
#ifdef TK
#define NINFDIR "/home/ynii/public_html/Test/"
#define STUBDIR "/home/ynii/public_html/Stub/"
#endif
#ifdef ETL
#define NINFDIR "/ynii/public_html/Ninf/"
#define STUBDIR "/tmp/"
#endif

#define NODEDIR "./"

void check_info_number(/* xdrp, options, ret */);
int get_stub_info_init(/*i,ninf_stub_entry,stub_index,pre_stub_index,flag */);

void name_list(/* curp,fp */);
void calling_style(/* curp,fp */);
void func_style(/* curp,fp */);
void args_style(/* curp,fp */);

int get_stub_entry_list(/*name,index*/);

void node_file_writing(/*curp,fp*/);
void stub_info(/*curp,fp*/);
void calling_info(/*curp,fp*/);
#ifdef ROOT
void root_file_writing(/*curp,fp,name,n*/);
#endif
#ifdef PREHTML
void prehtml_file_writing(/*curp,fp*/);
#endif
#ifdef RFP
void stub_detail_writing(/*curp,fp*/);
#endif

char* EXdata_type(/* type */);
char* EXmode_spec(/* type */);
char* EXVALUE_TYPE(/* type */);
char EXi(/*num,type*/);
