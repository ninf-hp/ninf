#define _WRAPPER_
/* $Id: pslaed3_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define _DISTRIBUTE_1D_
#define FLOAT
#include <stdlib.h>
#include <gscalapack.h>

#define ROW_u ldu
#define COL_u n
void  pslaed3_ninf(	
		 int *k,
		 int n,
		 float d[],
		 float *rho,
		 float dlamda[],
		 float w[],
		 float z[],
		 float global_u[],
		 int ldu,
		 int indx[],
		 int indxr[],
		 int indxc[],
		 int *info
)
/* "pslaed3 finds the roots of the secular equation, as defined by the values in D, W, and RHO, between 1 and K." */
/* OPTIONS */
{
	int nb;
	int maxldd;
	int *buf=NULL, *indcol=NULL, *indrow=NULL, *ctot=NULL;

	int maxldu;
	float *locu=NULL;
        int descu[DESCLEN], desc_gu[DESCLEN];
	int row_locu, col_locu;

        float *locw=NULL;

	INITIALIZE();

	SCALAR( "int", n);
	SCALAR( "int", ldu);

	SIZE(n);

	nb = cbloc;

	COMMON("float", d, n);
	COMMON("float", rho, 1);
	COMMON("float", z, n);
        COMMON("float",dlamda, n);

	ROW(u);
	COL(u);
	MAXLDD(maxldd, u);
	maxldu = maxldd;

	MATRIX("float", u, ROW_u, COL_u);

	locw = MALLOC(sizeof(float)*n);
        assert(locw);

	WORK(buf, 3*n);
	IWORK(indcol, n);
	IWORK(indrow, n);
	IWORK(ctot, npcol*4);

	if  (( mypnum != 0 ) ^ (serial==1) )
		FortranCall(pslaed3)( &PARA_CTXT,
				      k, &n, &nb,
				      d, &zero, &zero,
				      &rho, dlamda, locw, z,
				      locu, &row_locu,
				      buf,
				      indx, indcol, indrow,
				      indxr, indxc, ctot, &npcol,
				      &linfo);

	GATHER( "float", u, ROW_u, COL_u);

	RETRIEVE("int", k, 1);
	RETRIEVE("float", d, n);

	RETRIEVE("float", rho, 1);
	RETRIEVE("float", dlamda, n);
	RETRIEVE("float", locw, n);

	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
		int i;
		*info = linfo;
		for(i=0;i<n;i++) w[i] = locw[i];
	} else {
	}
        
        FREE_COMMON(d);
        FREE_COMMON(rho);
        FREE_COMMON(z);
        FREE_COMMON(dlamda);

        FREE_MATRIX(u);
	FREE(locw);
}

