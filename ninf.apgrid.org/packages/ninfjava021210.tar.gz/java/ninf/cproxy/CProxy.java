package ninf.cproxy;
import ninf.basic.*;
import ninf.client.*;
import java.util.Vector;
import java.util.Hashtable;
import java.io.IOException;
import java.net.*;

public class CProxy{
  public static CProxyConfig conf;

  public static NinfLog dbg = new NinfLog("CProxy");
  CProxyServer cProxyServer;

  void usage(){
    dbg.println("USAGE: java ninf.cproxy.CProxy [-port PORT] [-debug] CONFIGFILE");
  }

  void start(String args[]){
    try {
      conf = new CProxyConfig(args);
      conf.configure();
      cProxyServer = new CProxyServer(conf.myhostname, conf.port, this);
    } catch (NinfException e){
      e.printStackTrace();
      usage();
      System.exit(3);
    }
    cProxyServer.start();
  }

  public static void main(String args[]){
    new CProxy().start(args);
  }
}
