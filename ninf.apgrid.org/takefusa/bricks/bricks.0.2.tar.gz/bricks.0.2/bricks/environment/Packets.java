package bricks.environment;
import bricks.util.*;
import java.util.*;

public class Packets {
    protected Node owner;
    protected Vector sendBufferList = new Vector(100);
    protected double packetSize;
    protected int currentIndex = 0;
    protected Hashtable interarrivalTimeList = new Hashtable();
    //protected Sequence interarrivalTime;

    // need to modify!
    protected static double EPS = 0.000001;

    public Packets(Node owner, double packetSize) {
	this.owner = owner;
	this.packetSize = packetSize;
    }

    public String toString() {
	return sendBufferList.toString();
    }

    public void putInterarrivalTimeOfPackets(Sequence ng, Node toNode) {
	interarrivalTimeList.put(toNode, ng);
    }

    public boolean isEmpty() {
    //public boolean isEmpty() {
	return sendBufferList.isEmpty();
    }

    public boolean canOnePacketSend() {
	if (sendBufferList.size() > 1) {
	    return false;
	} else {
	    return true;
	}
    }

    public void sendFirstPacket(double currentTime) {
	TrafficData td = firstPacket();
	if (!td.nextNode().isFull()) {
	    popFirstPacket(currentTime);
	    td.gotoNextNode(currentTime);
	} else {
	    incrementCurrentIndex();
	    TrafficData nextPacket = firstPacket();
	    Sequence interarrivalTime = (Sequence)interarrivalTimeList.get(
	        nextPacket.nextNode()
	    );
	    nextPacket.updateTimeEventComes(
		currentTime, interarrivalTime.nextDouble(currentTime)
	    );
	}
    }

    public TrafficData firstPacket() {
	//System.out.println("sendBufferList = " + sendBufferList.size() + 
	//		   ", currentIndex = " + currentIndex);
	SendBuffer buffer = (SendBuffer)sendBufferList.elementAt(currentIndex);
	return buffer.firstPacket();
    }

    public void divideTrafficData(double currentTime, TrafficData data) {

	double db = data.dataSize / packetSize;
	int numPackets = (int)db;
	data.dataSize = data.dataSize - packetSize * numPackets;
	if ((numPackets > 1) && (data.dataSize < EPS)) {
	    data.dataSize = data.dataSize + packetSize;
	    numPackets--;
	}
	Vector list = data.getSubList(currentTime);
	//System.out.println(
	SimulationDebug.println(
	    "Packets: " + data + "'s route = " + data.getListOfRoute());
	//System.out.println(
	SimulationDebug.println(
	    "Packets: owner = " + owner + 
	    "indexOfCurrentNode = " + data.getIndexOfCurrentNode() + 
	    "data.dataSize = " + data.dataSize);
	SendBuffer buffer;
	if ((buffer = getSendBuffer(data)) == null) {
	    buffer = new SendBuffer(numPackets);
	    sendBufferList.addElement(buffer);
	}
	buffer.put(data);
	for (int i = 1 ; i <= numPackets ; i++ ) {
	    try {
		buffer.put(new PacketData(packetSize, list, data));
	    } catch (NullPointerException e) {
		e.printStackTrace();
		System.out.println("data.nextNode = " + data.nextNode() + ", indexOfCurrentNode = " + data.getIndexOfCurrentNode());
		System.out.println("route: " + data.getListOfRoute());
		BricksUtil.abort("packets.divideTrafficData: " +
				 data + ": " + i + "/" + numPackets);

	    }
	}
    }

    // put one packet
    public void putOnePacket(double currentTime, TrafficData data) {
	Vector list = data.getSubList(currentTime);
	SendBuffer buffer;
	if ((buffer = getSendBuffer(data)) == null) {
	    buffer = new SendBuffer();
	    sendBufferList.addElement(buffer);
	}
	buffer.put(new PacketData(packetSize, list, data));
    }

    private SendBuffer getSendBuffer(TrafficData data) {
	Enumeration e = sendBufferList.elements();
	while(e.hasMoreElements()) {
	    SendBuffer buffer = (SendBuffer)e.nextElement();
	    TrafficData d = buffer.firstPacket();
	    if (d instanceof PacketData) {
		if (data.equals(d.originalData))
		    return buffer;
	    }
	}
	return null;
    }

    protected void popFirstPacket(double currentTime) {
	SendBuffer buffer = (SendBuffer)sendBufferList.elementAt(currentIndex);
	SimulationDebug.println(
	    currentTime + " : sendBufferListSize = " + sendBufferList.size() +
	    " : buffer size = " + buffer.size()
	);
	if(buffer.popFirstPacket()) {
	    incrementCurrentIndex();
	} else {
	    sendBufferList.removeElementAt(currentIndex);
	    /* if last element was removed */
	    if (sendBufferList.size() > 0 &&
		sendBufferList.size() == currentIndex) {
		currentIndex = 0;
	    }
	}
	if (!sendBufferList.isEmpty()) {
	    TrafficData nextPacket = firstPacket();
	    if (nextPacket.nextNode() instanceof Network) {
		Sequence interarrivalTime = (Sequence)interarrivalTimeList.get(
		    nextPacket.nextNode()
		);
		nextPacket.updateTimeEventComes(
		    currentTime, interarrivalTime.nextDouble(currentTime)
		);
	    } else {
		nextPacket.updateTimeEventComes(currentTime, 0.0);
	    }
	}
    }

    protected void incrementCurrentIndex() {
	currentIndex++;
	if (currentIndex == sendBufferList.size()) {
	    currentIndex = 0;
	}
    }
}
