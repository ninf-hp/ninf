#ifndef __CALLBACK__
#define __CALLBACK__

#include "ninf_any_t.h"

typedef struct callback {
  void (*func)();
  int start_index;
  int nparam;
  int allocated_size[MAX_PARAMS];
} callback;

#define MAX_CALLBACK 5

void       init_callback (struct callback * call, void (*f)(), int start, int np);
void       ninf_exec_callback_call(void (* func)(), int start, int params, any_t ninf_args[]);
callback * find_callback(struct callback[], int);
callback * new_callback(int num);

#endif
