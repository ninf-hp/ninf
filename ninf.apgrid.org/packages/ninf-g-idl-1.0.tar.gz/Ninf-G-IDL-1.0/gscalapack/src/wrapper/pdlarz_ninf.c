#define _WRAPPER_
/* $Id: pdlarz_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define DOUBLE
#include <gscalapack.h>

#define ROW_v ldv
#define COL_v l
#define ROW_c ldc
#define COL_c n
static	int worklen(char side, int m, int n, int incv) {
		int ret=1;
#define MB_V rbloc
#define NB_V cbloc		
		int LCM, LCMP,LCMQ,IROFFC, ICOFFC,ICROW,ICCOL;
		int MpC0, NqC0;
		ret = m+n;
		if NEED_BUFF {
		  LCM = LCM( NPROW, NPCOL ); LCMP = LCM / NPROW;
		  LCMQ = LCM / NPCOL;
		  IROFFC = MOD( IC-1, MB_C );
		  ICOFFC = MOD( JC-1, NB_C );
		  ICROW = INDXG2P( IC, MB_C, MYROW, RSRC_C, NPROW );
		  ICCOL = INDXG2P( JC, NB_C, MYCOL, CSRC_C, NPCOL );
		  MpC0 = NUMROC( M+IROFFC, MB_C, MYROW, ICROW, NPROW );
		  NqC0 = NUMROC( N+ICOFFC, NB_C, MYCOL, ICCOL, NPCOL );
		  if (incv == 1) {
		    if (chrcmp(side, 'L')==0)
#define IVCOL 0
#define ICCOL 0
		      if (IVCOL == ICCOL)
			ret = NqC0;
		      else
			ret = MpC0 + MAX( 1, NqC0 );
		    else 
		      ret = NqC0 + MAX( MAX( 1, MpC0 ), NUMROC( NUMROC( N+ICOFFC,NB_V,0,0,NPCOL ),NB_V,0,0,LCMQ ) );

		  } else {
		    if (chrcmp( side , 'L')==0)
		      ret = MpC0 + MAX( MAX( 1, NqC0 ), NUMROC( NUMROC( M+IROFFC,MB_V,0,0,NPROW ),MB_V,0,0,LCMP ) );
		    else 
#define IVROW 0
#define ICROW 0
		      if (IVROW == ICROW)
			ret = MpC0;
		      else
			ret = NqC0 + MAX( 1, MpC0 );
		  }
		}
		return ret;
}


void  pdlarz_ninf(	 char side,
		 int m,
		 int n,
		 int l,
		 double global_v[],
		 int ldv,
		 int incv,
		 double tau,
		 double global_c[],
		 int ldc,
		 double work[]
)
/* "pdlarz applies a real elementary reflector Q (or Q**T) to a real M-by-N distributed matrix C, from either the left or the right." */
/* OPTIONS */
{
	int maxldd;

	int maxldv;
	double *locv=NULL;
	int descv[DESCLEN];
	int desc_gv[DESCLEN];
	int row_locv, col_locv;

	int maxldc;
	double *locc=NULL;
	int descc[DESCLEN];
	int desc_gc[DESCLEN];
	int row_locc, col_locc;

	double *locwork=NULL;
	int llocwork;

	INITIALIZE();

	SCALAR( "char", side);
	SCALAR( "int", m);
	SCALAR( "int", n);
	SCALAR( "int", l);

	SCALAR("int", ldv);
	SCALAR( "int",ldc);
	SCALAR("double", tau);
	SCALAR( "int", incv);
	if (incv != 1) incv=COL_v;

	ROW(v);
	COL(v);
	ROW( c);
	COL( c);
	MAXLDD( maxldd, c );
	maxldv = maxldd;
	maxldc = maxldd;

	MATRIX( "double", v, ROW_v, COL_v);
	MATRIX( "double", c, ROW_c, COL_c);
	DISTRIBUTE( "double", v, ROW_v, COL_v);
	DISTRIBUTE( "double", c, ROW_c, COL_c);

	llocwork = worklen(side, m, n, incv);
	WORK(locwork,llocwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pdlarz)( &side,
                              &m, &n, &l,
                              locv, &one, &one, descv,
                              &incv,
                              &tau,
                              locc, &one, &one, descc,
                              locwork);

	GATHER( "double", c, ROW_c, COL_c);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){

	} else {
		
	}

	FREE_MATRIX(v);
	FREE_MATRIX(c);
        FREE(locwork);
	
}

