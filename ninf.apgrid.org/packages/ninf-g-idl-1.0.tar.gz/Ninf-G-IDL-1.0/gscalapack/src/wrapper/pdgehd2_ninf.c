#define _WRAPPER_
/* $Id: pdgehd2_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define DOUBLE
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n
static	int worklen(int n, int ihi) {
	  int ret;
	  int iroffa, iarow;
	  int NpA0;
	  ret = 2*n;
	  if NEED_BUFF {
#define NB cbloc
#define RSRS_a 0
            iroffa = 0;
            iarow = Cindxg2p( 1, NB, myprow, RSRS_a, npcol );
            NpA0 = Cnumroc( ihi+iroffa, NB, myprow, iarow, nprow );
            ret =  NB + max( NpA0, NB );
	  }
	  return ret;
}


void  pdgehd2_ninf(	 int n,
		 int ilo,
		 int ihi,
		 double global_a[],
		 int lda,
		 double global_tau[],
		 double work[],
		 int *info
)
/* "pdgehd2 reduces a real general distributed matrix  A to upper Hessenberg form H by an orthogonal similarity transformation:  Q' * A * Q = H." */
/* OPTIONS */
{
	int maxldd;

	int maxlda;
	double *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
	int row_loca, col_loca;

	double *loctau=NULL;

        double *locwork=NULL;
        int llocwork;

	INITIALIZE();

	SCALAR( "int", n);
	SCALAR( "int", ilo);
	SCALAR( "int", ihi);
	SCALAR( "int", lda);

	ROW( a);
	COL( a);
	MAXLDD( maxldd, a );
	maxlda = maxldd;

	MATRIX( "double", a, ROW_a, COL_a);
	DISTRIBUTE( "double", a, ROW_a  , COL_a);

	VECTOR( "c", "double", tau, n-1);

	llocwork = worklen(n, ihi);
	WORK(locwork, llocwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pdgehd2)( &n, &ilo, &ihi,
                               loca, &one, &one, desca,
                               loctau,
                               locwork, &llocwork,
                               &linfo);

	GATHER( "double", a, ROW_a, COL_a);
        vGATHER( "c", "double", tau, n-1);
        
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
	  *info = linfo;
	} else {
	}

	FREE_MATRIX(a);
	FREE_VECTOR(tau);
        FREE(locwork);
}

