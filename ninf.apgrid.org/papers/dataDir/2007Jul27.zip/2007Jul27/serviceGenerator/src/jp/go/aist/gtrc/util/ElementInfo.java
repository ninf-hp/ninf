package jp.go.aist.gtrc.util;

class ElementInfo {
	SchemaInfo schemaInfo;
	String name;
	TypeInfo type;

	ElementInfo(SchemaInfo schemaInfo, String name, TypeInfo type) {
		this.schemaInfo = schemaInfo;
		this.name = name;
		this.type = type;
	}
}
