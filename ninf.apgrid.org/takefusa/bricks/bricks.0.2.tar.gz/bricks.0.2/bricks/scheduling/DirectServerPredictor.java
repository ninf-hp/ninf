package bricks.scheduling;
import bricks.util.*;
import bricks.environment.*;
import java.util.*;

public class DirectServerPredictor extends ServerPredictor implements Predictor {
    protected ServerMonitor serverMonitor; 

    public DirectServerPredictor(
	MetaPredictor owner, String keyOfServerMonitor
    ) {
	init(owner);
	serverMonitor = owner.getServerMonitor(keyOfServerMonitor);
    }

/************************* needed method *************************/
    public String getName() {
	return "DirectServerPredictor";
    }

    public ServerPrediction getServerPrediction(
	double currentTime, Host host, HostInfo hostInfo
    ) {
	HostInfo info = serverMonitor.getHostInfo(currentTime, host);
	return new ServerPrediction(info, info);
    }
}
