
package ninf.client;

public interface ServerNotifiable{
  public void notifyFree(NinfServerStruct srv);
}
