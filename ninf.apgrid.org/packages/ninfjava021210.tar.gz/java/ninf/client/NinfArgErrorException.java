package ninf.client;
import ninf.basic.NinfException;

public
class NinfArgErrorException extends NinfException {
  int argNum;
  boolean isSize;
  

  public NinfArgErrorException(String str, int argNum) {
    super(str);
    this.argNum = argNum;
  }
  public String toString(){
    return "Arg no." + argNum + " caused error";
  }
}
