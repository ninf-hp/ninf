package jp.go.aist.gtrc.util;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Vector;

public class TypeMapping {
	Map<String, TypeInfo> map;
	List<TypeInfo> usingList;

	public TypeMapping() {
		map = new HashMap<String, TypeInfo>();
		usingList = new Vector<TypeInfo>();
	}

	public void put(String type, TypeInfo info) {
		map.put(type, info);
	}

	TypeInfo get(String typeStr) {
		TypeInfo typeInfo = map.get(typeStr);
		if (!usingList.contains(typeInfo)) {
			usingList.add(typeInfo);
		}
		return typeInfo;
	}

	TypeInfo[] using() {
		return usingList.toArray(new TypeInfo[0]);
	}
}
