package ninf.netsolve;
import java.awt.Frame;
// import java.net.Socket;
import java.io.IOException;
// import java.io.DataInputStream;
// import java.io.DataOutputStream;
// import java.io.PrintStream;
import java.util.Vector;
import ninf.client.BufferObject;

public class SubmitJob {
  private MyStream str;
  private ServerInfo [] servers;
  private int f;
  private String hostname;
  private Problem prob;
  private Vector [] v;
  private BufferObject [] bo;
  private String [] files;
  private int [] m;
  private int [] n;
  private int current_data_format, 
              my_data_format = 11;
  public int cur_lang = Labels.language;

  private int get_servers(String server,Problem prob) 
   throws java.io.IOException {
     int prob_size, data_size, result_size, status,
         num_servers, i, temp[], encoding;
     temp = new int[4];
   
     
// always XDR
     str = new MyStream(server,GlobalDefs.AG_PORT,GlobalDefs.DATA_XDR);

     System.out.println("Sending some data to the server..");

//     str.server_out.writeChar(GlobalDefs.DATA_RAW);       // send encoding
     str.server_out.writeInt(GlobalDefs.PROBLEM_REQUEST);
     str.server_out.writeInt(GlobalDefs.JAVA_PROG);        // send client type
     str.write_string(prob.name);                          // send problem name

// some junk values (for now)
     prob_size = 1;
     data_size = 1;
     result_size = 1;

     str.server_out.writeInt(prob_size);   // send problem size
     str.server_out.writeInt(data_size);   // send data size
     str.server_out.writeInt(result_size); // send result size

/*
     if(prob.upf)
       num = prob.nb_input - 1;  // leave out the pseudo input for UPF
     else
       num = prob.nb_input;

     str.server_out.writeInt(num);         // send number of inputs
*/
     str.server_out.writeInt(prob.nb_input);

     for(i=0;i<prob.nb_input;i++) {
       str.server_out.writeInt(prob.inputs[i].data_type);
       str.server_out.writeInt(prob.inputs[i].object_type);
     }
       
     str.server_out.writeInt(prob.nb_output); // send number of outputs
     for(i=0;i<prob.nb_output;i++) {
       str.server_out.writeInt(prob.outputs[i].data_type);
       str.server_out.writeInt(prob.outputs[i].object_type);
     }
     System.out.println("...done.");

     System.out.println("Response from server:");
     encoding = str.server_in.readShort();
     str.init_recv(encoding);
     System.out.println("encoding = " + encoding);

     status = str.server_in.readInt();
     System.out.println("status = " + status);
     
     if((status == GlobalDefs.NO_SUCH_PB) || (status == GlobalDefs.BAD_INPUT) || 
        (status == GlobalDefs.BAD_OUTPUT) || (status == GlobalDefs.SV_FAILURE)) {
           str.shut_down();
           return status;
     }

     num_servers = str.server_in.readInt();
     servers = new ServerInfo[num_servers];

     for(i=0;i<num_servers;i++) {
       servers[i] = new ServerInfo();
       servers[i].name = str.get_string();
       System.out.println("Server: "+servers[i].name);
       servers[i].ip_addr = str.read_IPaddr();
       servers[i].data_format = str.server_in.readInt();
       servers[i].expected = str.server_in.readInt();
     }
     str.shut_down();
     return status;
  }

  private int send_prob(Problem prob) throws java.io.IOException {
    int i, encoding, status;

// assume connection to server has been made before calling send_prob

//    str.server_out.writeChar(GlobalDefs.DATA_RAW);      // send encoding

    str.server_out.writeInt(GlobalDefs.PROBLEM_SOLVE);  // send PROBLEM_SOLVE
    str.write_string(prob.name);                        // send problem name
    str.server_out.writeInt(GlobalDefs.C_PROG);   // send client type (java)

/*
    if(prob.upf)
      num = prob.nb_input - 1;  // leave out the pseudo input for UPF
    else
      num = prob.nb_input;

    str.server_out.writeInt(num);         // send number of inputs
*/
    str.server_out.writeInt(prob.nb_input);
    
    for(i=0;i<prob.nb_input;i++) {
      str.server_out.writeInt(prob.inputs[i].data_type);
      str.server_out.writeInt(prob.inputs[i].object_type);
    }

    str.server_out.writeInt(prob.nb_output);
    for(i=0;i<prob.nb_output;i++) {
      str.server_out.writeInt(prob.outputs[i].data_type);
      str.server_out.writeInt(prob.outputs[i].object_type);
    }

    System.out.println("Response from server:");
    encoding = str.server_in.readShort();
    str.init_recv(encoding);
    System.out.println("encoding = " + encoding);

    status = str.server_in.readInt();
    System.out.println("status = " + status);

    return status;
  }

/*********** get_info not really necessary for this interface *******

  private ProblemDesc get_info(String server,String name) {
    int encoding, status, i, dummy, dummy2;
    ProblemDesc pb_desc;
    Constant current_constant;
    Formula current_form;

    try 
      str = new MyStream(server,GlobalDefs.AG_PORT,GlobalDefs.DATA_RAW);
    }
    catch (IOException e) {
      return null;
    }

    try {
      pb_desc = new ProblemDesc();

//      str.server_out.writeChar(GlobalDefs.DATA_RAW);    // send encoding

      str.server_out.writeInt(GlobalDefs.INFO_REQUEST); // send INFO_REQUEST
      str.write_string(name);                           // send problem name
    
      System.out.println("info_request sent...response from server:");

      encoding = str.server_in.readShort();
      System.out.println("encoding = " + encoding);
      status = str.server_in.readInt();
      System.out.println("status = " + status);

      if(status == GlobalDefs.NO_SUCH_PB) {
        System.out.println("No Such Problem");
        return null;
      }

      pb_desc.path = str.get_string();
      pb_desc.desc = str.get_string();
      pb_desc.num_upf = str.server_in.readInt();
      pb_desc.nb_obj_input = str.server_in.readInt();

      pb_desc.input_obj = new NetSolveObject[pb_desc.nb_obj_input];
      for(i=0;i<pb_desc.nb_obj_input;i++) {
        pb_desc.input_obj[i] = new NetSolveObject();
        pb_desc.input_obj[i].data_type = str.server_in.readInt();      
        pb_desc.input_obj[i].object_type = str.server_in.readInt();
        pb_desc.input_obj[i].description = str.get_string();
      }

      pb_desc.nb_obj_output = str.server_in.readInt();
      pb_desc.output_obj = new NetSolveObject[pb_desc.nb_obj_output];

      for(i=0;i<pb_desc.nb_obj_output;i++) {
        pb_desc.output_obj[i] = new NetSolveObject();
        pb_desc.output_obj[i].data_type = str.server_in.readInt();      
        pb_desc.output_obj[i].object_type = str.server_in.readInt();
        pb_desc.output_obj[i].description = str.get_string();
      }

      // only allocate one format, as in the C version
      pb_desc.formats = new FormatSpec[1];
      pb_desc.formats[0] = new FormatSpec();
      pb_desc.formats[0].nb_args = str.server_in.readInt();
      pb_desc.formats[0].args_desc = 
          new String[pb_desc.formats[0].nb_args];
      for(i=0;i<pb_desc.formats[0].nb_args;i++) {
        pb_desc.formats[0].args_desc[i] = str.get_string();
      }

      pb_desc.formats[0].nb_constants = str.server_in.readInt();
      pb_desc.formats[0].consts = null;

      for(i=0;i<pb_desc.formats[0].nb_constants;i++) {
        current_constant = new Constant();
        current_constant.next = pb_desc.formats[0].consts;
        current_constant.mnemonic = str.get_string();
        current_constant.value = str.server_in.readInt();
        pb_desc.formats[0].consts = current_constant;
      }

      pb_desc.formats[0].nb_formulae = str.server_in.readInt();
      pb_desc.formats[0].forms = null;

      for(i=0;i<pb_desc.formats[0].nb_formulae;i++) {
        current_form = new Formula();
        current_form.next = pb_desc.formats[0].forms;
        current_form.mnemonic = str.get_string();
        current_form.expression = str.get_string();
        pb_desc.formats[0].forms = current_form;
      }

      // ignore matlab information
      dummy = str.server_in.readInt();
      for(i=0;i<dummy;i++) {
        dummy2 = str.server_in.readInt();
        dummy2 = str.server_in.readInt();
      }
      pb_desc.name = new String(name);
    } 
    catch (IOException e) {
      return null;
    }
    finally {
      try {
        if (str != null)  
          if (str.s != null) 
            str.shut_down(); 
      }
      catch (IOException e2) { ; }
    }

    System.out.println("That's it for get_info...");
    return pb_desc;
  }

**********************************************************/

  private void send_data(Problem prob, String [] files) throws java.io.IOException, NetSolveException,
    UpfUnsafeException 
  {
    int upf_type, unsafe_index, encoding, status, i, j, k, count=0;
    double answer;
    String upf_code, upf_name;
    String unsafe_calls;
    
    if(prob.upf > 0) {
      System.out.println("There are " + prob.upf + "UPFs to send...");

      if(current_data_format == my_data_format) {
        System.out.println("Sending UPF using DATA_RAW");
        str.server_out.writeChar(GlobalDefs.DATA_RAW);         // send encoding
      }
      else {
        System.out.println("Sending UPF using DATA_XDR");
        str.server_out.writeChar(GlobalDefs.DATA_XDR);         // send encoding
      }

      for(j = 0;j < prob.nb_input; j++) {
        if(prob.inputs[j].data_type == NetSolveObject.NETSOLVE_EXTERNAL) {
          System.out.println("Sending UPF number " + count);

          upf_type = ((Integer) v[j].elementAt(0)).intValue();
          upf_code = new String();
          for(i=1;i< v[j].size(); i++)
            upf_code = upf_code.concat( (String) v[j].elementAt(i) );

          // upf_name = new String("upf" + (new Integer(j).toString()));
          upf_name = new String("upf" + (new Integer(count).toString()));

          System.out.println("UPF type = "+upf_type);
          System.out.println("UPF name = "+upf_name);
          System.out.println("UPF code: ");
          System.out.println(upf_code);

          /****** send the UPF *********/

          str.server_out.writeInt(upf_type);            // type = c or fortran
          str.write_string(upf_name);                   // send function name
          str.server_out.writeInt(upf_code.length());   // send size of code
          str.server_out.writeBytes(upf_code);          // send code

          System.out.println("UPF sent");
          count++;
        }
      }

      System.out.println("Response from server:");
      encoding = str.server_in.readShort();
      str.init_recv(encoding);
      System.out.println("encoding = " + encoding);
  
      status = str.server_in.readInt();
      System.out.println("status = " + status);
      if(status == GlobalDefs.UPF_FAILED)
        throw new NetSolveException(Labels.upf_failed[cur_lang]);
      else if(status == GlobalDefs.UPF_UNSAFE) {
        unsafe_index = str.server_in.readInt();
        unsafe_calls = str.get_string();
        throw new UpfUnsafeException("UPF"+unsafe_index+": "+unsafe_calls);
      }
    }

//  if UPF, are we resending encoding here?  seems to work.
    if(current_data_format == my_data_format) {
      System.out.println("Sending data using DATA_RAW");
      str.server_out.writeChar(GlobalDefs.DATA_RAW);         // send encoding
    }
    else {
      System.out.println("Sending data using DATA_XDR");
      str.server_out.writeChar(GlobalDefs.DATA_XDR);         // send encoding
    }

    System.out.println("sending "+ (prob.nb_input - prob.upf) +
       " input objs, not counting upf");
    for(i=0;i<prob.nb_input;i++) {
      switch(prob.inputs[i].object_type) {
        case NetSolveObject.NETSOLVE_SCALAR:
          if (v != null) str.write_scalar(v, i, prob.inputs[i].data_type);
          else str.write_scalar(bo[i]);
          break;
        case NetSolveObject.NETSOLVE_VECTOR:
          if (v != null) str.write_vector(v, i, prob.inputs[i].data_type, m[i]);
          else str.write_vector(bo[i], m[i]);
          break;
        case NetSolveObject.NETSOLVE_MATRIX:
          if (v != null) str.write_matrix(v, i, prob.inputs[i].data_type, m[i], n[i]);
          else str.write_matrix(bo[i], m[i], n[i]);
          break;
        case NetSolveObject.NETSOLVE_UPF:
          // already sent UPF above
          break;
        default:
          System.err.println("SubmitJob.send_data(): unknown object type!");
      }
    }
  }

  private Vector get_answer(Problem prob) throws java.io.IOException, 
   NetSolveException {
    int i, j, k, m, n, encoding, status;
    Vector vec;
    
    System.out.println("done.  response from server:");

    encoding = str.server_in.readShort();
    str.init_recv(encoding);
    System.out.println("encoding = " + encoding);

    status = str.server_in.readInt();
    System.out.println("status = " + status);

    switch(status) {
      case GlobalDefs.SOLUTION:
        // this is good, we got a solution, just continue
        break;
      case GlobalDefs.NO_SOLUTION:
        throw new NetSolveException(Labels.no_solution[cur_lang]);
      case GlobalDefs.LINEAR_FAILED:
        throw new NetSolveException(Labels.linear_failed[cur_lang]);
      case GlobalDefs.DM_MISMATCH:
        throw new NetSolveException(Labels.dm_mismatch[cur_lang]);
      case GlobalDefs.BAD_VALUES:
        throw new NetSolveException(Labels.bad_values[cur_lang]);
      case GlobalDefs.NO_SUCH_PB:
        return(null);
      case GlobalDefs.BAD_UPF:
        throw new NetSolveException(Labels.bad_upf[cur_lang]);
      case GlobalDefs.UPF_UNSAFE:
        throw new NetSolveException(Labels.upf_unsafe[cur_lang]);
      default:
        throw new NetSolveException(Labels.unknown_err[cur_lang]);
    }

    System.out.println("trying to get answer...");

    vec = new Vector(prob.nb_output);
    for(i=0;i < prob.nb_output;i++) {
      switch(prob.outputs[i].object_type) {
        case NetSolveObject.NETSOLVE_SCALAR:
	  System.out.println(""+ i + ": get scalar");
          str.read_scalar_bo(vec, prob.outputs[i].data_type);
          break;
        case NetSolveObject.NETSOLVE_VECTOR:
	  System.out.println(""+ i + ": get vector");
          str.read_vector_bo(vec, prob.outputs[i].data_type);
          break;
        case NetSolveObject.NETSOLVE_MATRIX:
	  System.out.println(""+ i + ": get matrix");
          str.read_matrix_bo(vec, prob.outputs[i].data_type);
          break;
        default:
          System.err.println("SubmitJob.get_answer(): unknown object type!");
      }
    }
    return(vec);
  }

  private void report_failure(String host, byte[] addr, int type) {
    System.out.println("Sending failure report for host: " + host);
    try {
      // always XDR
      str = new MyStream(host,GlobalDefs.AG_PORT,GlobalDefs.DATA_XDR);

//      str.server_out.writeChar(GlobalDefs.DATA_RAW);       // send encoding

      str.server_out.writeInt(GlobalDefs.CLIENT_F_REPORT); // send fail report
      str.server_out.writeInt(type);            // send type
      str.write_IPaddr(addr);            // send IP addr

      str.shut_down();    
      System.out.println("*** It WORKED ***");
    } catch (IOException e) {
      System.out.println("*** HERE ***");
      System.out.println(e.getMessage());
      return;
    }
  }

  private void job_done(String host, byte[] addr) {
    try {
      // always XDR
      str = new MyStream(host,GlobalDefs.AG_PORT,GlobalDefs.DATA_XDR);

//      str.server_out.writeChar(GlobalDefs.DATA_RAW);      // send encoding

      str.server_out.writeInt(GlobalDefs.JOB_COMPLETED);  // send JOB_COMPLETED
      str.write_IPaddr(addr);                             // send IP address
      str.shut_down();    
    } catch (IOException e) {
      return;
    }
  }

  public SubmitJob(String hostname, Problem prob, Vector v[], String files[],
      int m[], int n[])
    throws NetSolveException {
    this.hostname = hostname;
    this.prob = prob;
    this.v = v;
    this.files = files;
    this.m = m;
    this.n = n;
  }

  public SubmitJob(String hostname, Problem prob, BufferObject bo[], String files[],
      int m[], int n[])
    throws NetSolveException {
    this.hostname = hostname;
    this.prob = prob;
    this.bo = bo;
    this.files = files;
    this.m = m;
    this.n = n;
  }

 public Vector start() {
    int i,resp=0, status;
    boolean made_connection = false;
    ProblemDesc pd = null;
    Vector output_vec = null;
    NetSolveWarning warn;

    while(!made_connection) {
      System.out.println(Labels.contacting[cur_lang]);
      try {
        status = get_servers(hostname,prob);

        if((status == GlobalDefs.NO_SUCH_PB) || 
           (status == GlobalDefs.BAD_INPUT)  || 
           (status == GlobalDefs.BAD_OUTPUT) ||  
           (status == GlobalDefs.SV_FAILURE))
        {
          warn = new NetSolveWarning(f, Labels.internal_err[cur_lang]);
	  return null;
        }
      }
      catch(IOException e) {
        System.out.println("Cant contact agent: "+hostname);
        warn = new NetSolveWarning(f,Labels.contact_err[cur_lang] + 
           "'" + hostname + "'" + " -- (" + e + ")");
        return null;
      }

      if(servers.length == 0) {
        System.out.println("No servers available......");
        warn = new NetSolveWarning(f,Labels.no_servers[cur_lang]);
        return null;
      }

      System.out.println("got a list of "+servers.length+" servers: ");
      for(i=0;i<servers.length;i++) {
        System.out.println(i+": "+ servers[i].name);
        System.out.println( 
			   (((int)servers[i].ip_addr[0]) & 0xFF) + "." +
			   (((int)servers[i].ip_addr[1]) & 0xFF) + "." +
			   (((int)servers[i].ip_addr[2]) & 0xFF) + "." +
			   (((int)servers[i].ip_addr[3]) & 0xFF));
        System.out.println("data format: "+servers[i].data_format);
        System.out.println("expected: "+servers[i].expected);
      }

      System.out.println("Going to contact a server.");
      for(i=0;i<servers.length;i++) {
        System.out.println("Setting current_data_format to: "+servers[i].data_format);
        current_data_format = servers[i].data_format;
        System.out.println(Labels.trying[cur_lang] + servers[i].name);
        System.out.println("Trying "+servers[i].name+"...");
        try {
          if(current_data_format == my_data_format) {
            System.out.println("...in DATA_RAW mode.");
            str = new MyStream(servers[i].name,GlobalDefs.SV_PORT,GlobalDefs.DATA_RAW);
          } else {
            System.out.println("...in DATA_XDR mode.");
            str = new MyStream(servers[i].name,GlobalDefs.SV_PORT,GlobalDefs.DATA_XDR);
          }
        }
        catch (IOException e) {
	  e.printStackTrace();
          report_failure(hostname, servers[i].ip_addr, GlobalDefs.STOPPED);
          continue;
        }
//        made_connection = true;
        System.out.println("Made a connection to: "+servers[i].name);
        System.out.println(Labels.connected[cur_lang] + servers[i].name);

        try {
          resp = send_prob(prob);
          if((resp == GlobalDefs.PB_REFUSED) || (resp == GlobalDefs.SV_FAILURE)) {
            report_failure(hostname, servers[i].ip_addr, GlobalDefs.FAILED);
            continue;
          }
        }
        catch (IOException e) {
          report_failure(hostname, servers[i].ip_addr, GlobalDefs.FAILED);
          continue;
        }
        System.out.println(Labels.sending[cur_lang]);
        try {
	  send_data(prob,files);

          System.out.println(Labels.waiting[cur_lang]);
          output_vec = get_answer(prob);
          if(output_vec == null)
            continue;
          System.out.println(Labels.got_answer[cur_lang]);

	  //          OutputData od = new OutputData(f,prob,output_vec,idString);
        }catch (IOException e) {
	  e.printStackTrace();
          System.out.println("IO exception on get_answer");
          report_failure(hostname, servers[i].ip_addr, GlobalDefs.FAILED);
          System.out.println("reported failure of " + servers[i].ip_addr);
          continue;
        }catch(NetSolveException e) {
          // what to do here?
          System.out.println(e.getMessage());
          NetSolveWarning cant_solve = new NetSolveWarning(f,
            Labels.solve_error[cur_lang]+e.getMessage());
        }catch(UpfUnsafeException e) {
          TextScreen unsafe = new TextScreen(Labels.upf_unsafe[cur_lang],
            "One or more of your User Provided Functions cannot be\n" +
            "compiled because of unsafe function calls.  The following\n" +
            "is a list of the unsafe calls in your code:\n\n" + 
            e.getMessage());
        }

        job_done(hostname,servers[i].ip_addr);

        made_connection = true;

        try {
          str.shut_down();
        }
        catch(IOException e) { ; }
        break; // break out of for loop
      }
      System.out.println("after for loop");
    }
    System.out.println("after while loop");
    return output_vec;
  }
}
