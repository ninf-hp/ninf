package ninf.netsolve;
/*  
    RadioMenu.java
 
    from "Graphic Java: Mastering the AWT" 
          by David M. Geary and Alan McClellan
          page 112
*/

import java.awt.Menu;
import java.awt.MenuItem;
import java.awt.CheckboxMenuItem;

public class RadioMenu extends Menu {

  public RadioMenu(String s, boolean tearoff) {
    super(s,tearoff);
  }

  public void add(String s) {
    add(new CheckboxMenuItem(s));
  }

  public MenuItem add(MenuItem item) {
    return super.add(item);
  }

  public void selectItem(MenuItem item) {
    CheckboxMenuItem nextItem;
    int numItems = countItems();

    for(int i=0; i < numItems; ++i) {
      if(item != getItem(i)) {
        nextItem = (CheckboxMenuItem)getItem(i);
        nextItem.setState(false);
      }
    }
  }
}
