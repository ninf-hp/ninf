package ninf.client;
import java.util.StringTokenizer;
import java.net.URL;
import java.net.MalformedURLException;
import ninf.basic.*;


public class URLResource{
  public static int HTTP_RESOURCE = 1;
  public static int FILE_RESOURCE = 2;
  public static int NINF_STORAGE_RESOURCE = 3;

  public static String protocolStrings[] = {
    "", "http", "file", "storage"
  };

  public int    protocol;
  public String host;
  public String port;
  public String path;

  public URLResource(String str) throws NinfErrorException{
    try {
      URL url = new URL(str);
      if (url.getProtocol().equals("http")){
	protocol = HTTP_RESOURCE;
	host = url.getHost();
	int tmpPort = url.getPort();
	if (tmpPort < 0)
	  port = "80";
	else
	  port = ""+tmpPort;
	path = url.getFile();
      } else if (url.getProtocol().equals("storage")){
	protocol = NINF_STORAGE_RESOURCE;
	host = url.getHost();
	int tmpPort = url.getPort();
	if (tmpPort < 0)
	  port = "3000";
	else
	  port = ""+tmpPort;
	path = url.getFile();
      } else if (url.getProtocol().equals("file")){
	protocol = FILE_RESOURCE;
	host = "";
	port = "";
	path = url.getFile();
      } else {
	throw new NinfErrorException(NinfError.MALFORMED_URL);
      }
    } catch (MalformedURLException e){
      throw new NinfErrorException(NinfError.MALFORMED_URL);
    }
  }

  public URLResource(int protocol, String host, String port, String path){
       this.protocol = protocol;
       this.host     = host;
       this.port     = port;
       this.path     = path;
  }

  public void writeTo(NinfPacketOutputStream ostream) throws NinfIOException{
    ostream.writeInt(protocol);
    ostream.writeString(host);
    ostream.writeString(port);
    ostream.writeString(path);
  }

  public URLResource(NinfPacketInputStream istream) throws NinfException{
    protocol = istream.readInt();
    host = istream.readString();
    port = istream.readString();
    path = istream.readString();
  }

  public String toString(){
    return ""+ protocolStrings[protocol] + "://"+ 
      (protocol == FILE_RESOURCE ? "" : (host + ":" + port)) + "/" +
      path;
  }

}
