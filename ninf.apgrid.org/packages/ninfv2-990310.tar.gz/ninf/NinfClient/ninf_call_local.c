#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>
#include <stdarg.h>
#include <signal.h>
#include <sys/wait.h>
#include "ninf_stub_info.h"
#include "ninf_protocol.h"
#include "ninf_debug.h"
#include "ninf_data_trans.h"
#include "ninf_stream.h"
#include "callback.h"
#include "ninf_comm_lib.h"
#include "session.h"
#include "ninf_client.h"

extern int errno;

static NINF_STUB_INFO  * stub_info;

/* argument work place */
static any_t ninf_args[MAX_PARAMS];


#define USE_STUB_PKT

/* 
 * Ninf_call, a local version:
 * 	Ninf_local_exec("stub_program",arg1,arg2,...) 
 */
Ninf_local_exec(char * ninf_stub_program, ...)
{
  va_list ap;
  
  ninf_session * session;
  connection * server;
  resource * c_resource;

  int nparam,i,j,cc,ack;
  struct ninf_param_desc *dp;    
  struct callback callbacks[MAX_CALLBACK + 1];
  int stub_pid;

  int size;
  char tmpbuffer[1024];

  stub_info = new_ninf_stub_info();

  stub_pid = 
    ninf_local_forkexec(ninf_stub_program, FALSE, &server);

  if (server->sDT == NULL){
    fprintf(stderr, "cant' find stub %s\n", ninf_stub_program);
    return -1;
  }
  
  /* send request */
  
  if(!trans_request(server->sDT,NINF_REQ_STUB_INFO_LOCAL)) return(NINF_ERROR);
  write_flush(server->sDT);


  /* get result */

  if(!trans_int(server->rDT,&ack)) return(NINF_ERROR);
  else if(ack != NINF_ACK_OK) return(ack);

  if(!trans_stub_info(server->rDT, stub_info, TRUE))
    return(NINF_ERROR);

  c_resource = new_resources(stub_info->nparam);

    nparam = stub_info->nparam;
  /* set args to work */
  va_start(ap, ninf_stub_program);

  ninf_get_arg(&ap, stub_info, ninf_args, callbacks, c_resource);
  va_end(ap);
  /* do call */

  session = new_ninf_session(server, ninf_args, stub_info, callbacks, c_resource);

  if ((ack = ninf_send_args(session)) != NINF_OK)
    return(ack);  /* send arg */
  ack = ninf_recv_or_callback(session);

  /* kill */
  ninf_local_kill(server, stub_pid);
    return(NINF_OK);
}
