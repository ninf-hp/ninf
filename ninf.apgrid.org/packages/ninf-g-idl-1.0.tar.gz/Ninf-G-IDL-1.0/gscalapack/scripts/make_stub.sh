#! /bin/sh
# $Id: make_stub.sh,v 1.2 2005/06/07 08:08:45 naotaka Exp $

for arg in "$@"
do
    case "$arg" in
	[^=]*=*) 
	    TARGETENV=`expr "${arg}" : '\([^=]*\)='`
	    VAL="`expr "${arg}" : '[^=]*=\(.*\)'`"
	    eval ${TARGETENV}=\"${VAL}\"
        ;;
        *)
        ;;
    esac
done

[ x"${THISDIR}" = x"" ] && exit 3
[ x"${TARGET}" = x"" ] && exit 3
[ x"${TOPDIR}" = x"" ] && exit 3
[ x"${BINDIR}" = x"" ] && exit 3
[ x"${SRCDIR}" = x"" ] && exit 3
[ x"${INCLUDEDIR}" = x"" ] && exit 3
[ x"${NINF_GEN}" = x"" ] && exit 3
[ x"${MPIDIR}" = x"" ] && exit 3
[ x"${CC}" = x"" ] && exit 3
[ x"${MAKE}" = x"" ] && exit 3

if [ -f ${TOPDIR}/make.inc ] ; then
    TMP="`cat ${TOPDIR}/make.inc | sed -e '/^#/d' | grep 'CFLAGS.*='`"
    CFLAGS=`expr "${TMP}" : 'CFLAGS *=\(.*\)'`
    CFLAGS="${CFLAGS} -D_LOCAL_ -I./"
fi

tgt="`echo ${TARGET}| sed -e s'!^.!!' `"

if [ -d ${BINDIR} ] ; then
    cd ${BINDIR}

    for h in ${INCLUDEDIR}/*.h ; do
	header=`basename ${h}`
	if [ ! -L $header -a ! -e $header  ] ; then
	    ln -s $h $header
	fi
    done

    if [ ! -L "${tgt}_ninf.c" ] ; then
	ln -s ${SRCDIR}/wrapper/${tgt}_ninf.c ${BINDIR}/ || exit 2
    fi

    ${CC} ${CFLAGS} -c ${tgt}_ninf.c
    ${NINF_GEN} ${NINF_GEN_FLAG} -I./ ${SRCDIR}/${tgt}.idl  || exit 2

    ${MAKE} -f scalapack.mak || exit 2
    ${MAKE} -f scalapack.mak clean
    for def in nsdef ngdef ; do
	if [ -f scalapack."`globus-hostname`".${def} ] ; then
	    cat scalapack."`globus-hostname`".${def} | sed -e 's#^\(GridRPC-MpirunCommand: \)/bin/mpirun#\1'"${MPIDIR}"'/bin/mpirun#;s#^\(GridRPC-MpirunNoOfCPUs: \)1#\15#' > scalapack."`globus-hostname`".${def}${TARGET}
	fi
    done

    rm ${tgt}_ninf.[co]
    cd ${THISDIR}
    touch ${TARGET}
fi


