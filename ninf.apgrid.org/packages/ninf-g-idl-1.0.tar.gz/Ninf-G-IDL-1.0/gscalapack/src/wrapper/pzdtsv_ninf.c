#define _WRAPPER_
/* $Id: pzdtsv_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define _DISTRIBUTE_1D_
#define DCOMPLEX
#include <gscalapack.h>

#define ROW_b ldb
#define COL_b nrhs
static	int worklen(int n, int nrhs) {
	  int ret=1;
	  ret = (12+3*n) +max(10+4*nrhs, 8);
	  if NEED_BUFF 
              ret =  (12*npcol+3*blocsize) +max(10*npcol+4*nrhs, 8*npcol);
	  return ret;
}


void  pzdtsv_ninf(	 int n,
		 int nrhs,
		 dcomplex global_dl[],
		 dcomplex global_d[],
		 dcomplex global_du[],
		 dcomplex global_b[],
		 int ldb,
		 dcomplex work[],
		 int lwork,
		 int *info
)
/* "pzdtsv solves a system of linear equations A * X = B where A is an N-by-N complex tridiagonal diagonally dominant-like distributed matrix." */
/* OPTIONS */
{
    extern void FortranCall(pzdtsv)( int*, int*,
                              dcomplex*, dcomplex*, dcomplex*, int*, int*,
                              dcomplex*, int*, int*,
                              dcomplex*, int*, int*);

	int maxldd;

	dcomplex *locdl=NULL, *locd=NULL, *locdu=NULL;
	int desctdd[DESCLEN];
	int desc_gtdd[DESCLEN];

	int maxldb;
	dcomplex *locb=NULL;
	int descb[DESCLEN];
	int desc_gb[DESCLEN];
	int row_locb, col_locb;

	dcomplex *locwork=NULL;
	int llocwork;

	INITIALIZE();

	SCALAR( "int", n);
	SCALAR( "int", nrhs);
	SCALAR( "int", lwork);
	SCALAR("int", ldb);
	SCALAR( "int", lwork);

	SIZE(n);

	ROW(b);
	COL(b);
	MAXLDD( maxldd, b);
	maxldb = maxldd;

	tdMATRIX( "dcomplex", dl, d, du, n);
	MATRIX( "dcomplex", b, ROW_b, COL_b);
	tdDISTRIBUTE( "dcomplex", dl, d, du, n);
	DISTRIBUTE( "dcomplex", b, ROW_b, COL_b);

	llocwork = worklen(n ,nrhs);
        llocwork = max( llocwork, lwork);
	WORK(locwork, llocwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pzdtsv)( &n, &nrhs,
                              locdl, locd, locdu, &one, desctdd,
                              locb, &one, descb,
                              locwork, &llocwork, &linfo);

	tdGATHER( "dcomplex", dl, d, du, n);
	GATHER( "dcomplex", b, ROW_b, COL_b);

	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
	  *info = linfo;
	} else {
	}
        
	FREE_MATRIX(dl);
	FREE_MATRIX(d);
	FREE_MATRIX(du);
	FREE_MATRIX(b);

        FREE(locwork);
}

