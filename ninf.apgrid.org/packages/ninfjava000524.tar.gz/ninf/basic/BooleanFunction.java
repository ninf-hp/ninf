package ninf.basic;

public interface BooleanFunction{
  public boolean eval(Object o);
}
