package bricks.scheduling;
import bricks.util.*;
import bricks.environment.*;
import java.util.*;
import java.io.*;

public class LazyReplicaManager extends ReplicaManager implements SchedulingUnit {
    public LazyReplicaManager(
	String keyOfResourceDB,	String keyOfServerMonitor, double compactness
    ) {
	super(keyOfResourceDB, keyOfServerMonitor, compactness);
    }

/************************* needed method *************************/
    public String getName() {
	return "LazyReplicaManager";
    }

    // implement replication strategies
    public void processEvent(double currentTime) {;}
}
