#define _WRAPPER_
/* $Id: psdbtrsv_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define _DISTRIBUTE_1D_
#define FLOAT
#define NO_PIVOT
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n
#define ROW_b ldb
#define COL_b nrhs
#define ROW_af laf
#define COL_af n
static	int worklen(int nrhs, int bwl, int bwu) {
	  int ret=1;
	  ret =  (max(bwl,bwu)*nrhs);
          return ret;
}

void  psdbtrsv_ninf(  char uplo,
		 char trans,
		 int n,
		 int bwl,
		 int bwu,
		 int nrhs,
		 float global_a[],
		  int lda,
		 float global_b[],
		  int ldb,
		  float af[],
		 int dummy_laf,
		 float work[],
		 int lwork,
		 int *info
)
/* "psdbtrsv solves a banded triangular system of linear equations A * X = B or A^T * X = B where A is a banded triangular matrix factor produced by the Gaussian elimination code pdbtrf and is stored in A and AF." */
/* OPTIONS */
{
    extern void  FortranCall(psdbtrsv)( char*, char*, int*, int*, int*, int*,
                                 float*, int*, int*,
                                 float*, int*, int*,
                                 float*, int*,
                                 float*, int*, int*);

	int maxldd;

	float *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];

	int maxldb;
	float *locb=NULL;
	int descb[DESCLEN];
	int desc_gb[DESCLEN];
	int row_locb, col_locb;

	float *locwork=NULL;
	int llocwork;

	float *locaf=NULL,*global_af=NULL;
	int descaf[DESCLEN];
	int desc_gaf[DESCLEN];
	int maxldaf;
	int laf, llocaf;
	int row_locaf, col_locaf;

	INITIALIZE();

	SCALAR( "char", uplo);
	SCALAR( "char", trans);
	SCALAR( "int", n);
	SCALAR( "int", bwl);
	SCALAR( "int", bwu);
	SCALAR( "int", nrhs);
	SCALAR( "int", dummy_laf);
	SCALAR("int", lda);
	SCALAR( "int", lwork);

	SIZE(n);

	laf=max(dummy_laf, bwl+bwu+6*max(bwl,bwu)*max(bwl,bwu)/n);
	llocaf=laf*blocsize;
	if(mypnum==0){
            global_af=MALLOC(sizeof(float)*laf*n);
            assert(global_af);
	}

	ROW(af);
	COL(af);
	ROW(b);
	COL(b);
	MAXLDD( maxldd, b);
	maxldb =  maxldd;
	maxldaf = maxldd;

	bandMATRIX( "float", a, bwl ,bwu, n);
	MATRIX( "float", b, ROW_b, COL_b);
	MATRIX( "float", af, ROW_af, COL_af);
	bandDISTRIBUTE( "float", a, bwl, bwu, n);
	DISTRIBUTE( "float", b, ROW_b, COL_b);

	llocwork = worklen(nrhs, bwl, bwu);
        llocwork = max(lwork,llocwork);
	WORK(locwork,llocwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	  FortranCall(psdbtrsv)( &uplo, &trans, &n, &bwl, &bwu, &nrhs,
                                 loca, &one, desca,
                                 locb, &one, descb,
                                 locaf, &llocaf,
                                 locwork, &llocwork, &linfo);

	bandGATHER( "float", a, bwl, bwu, n);
	GATHER("float", b, ROW_b, COL_b);
	GATHER("float",  af, ROW_af, COL_af);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
	  int i;
	  *info = linfo;
	  for(i=0;i<min(dummy_laf,laf*n); i++) af[i] = global_af[i];
          FREE(global_af);
	} else {
	}
	FREE_MATRIX(a);
	FREE_MATRIX(b);
	FREE_MATRIX(af);
        FREE(locwork);
}

