package ninf.client;

import ninf.basic.*;
import java.io.*;

public class ServerIndex {
  /** Ninf server */
  public NinfServerStruct server;
  /** index No. on NinfServer */
  public int index;  

  static CommandParser parser = 
    new CommandParser(new CommandRepresent("serverIndex",    3));


  public ServerIndex(NinfServerStruct server, int index){
    this.server = server;
    this.index = index;
  }

  public ServerIndex(ServerID server, int index){
    this.server = new NinfServerStruct(server.host, server.port);
    this.index = index;
  }

  public ServerIndex(DataInputStream is) throws NinfException{
    NinfCommand com = parser.readCommand(is);
    this.server = new NinfServerStruct(com.args[0], com.args[1]);
    this.index = new Integer(com.args[2]).intValue();
  }

  public boolean equals(Object o){
    if (!(o instanceof ServerIndex))
      return false;
    if (((ServerIndex)o).server.equals(server) &&
        ((ServerIndex)o).index == index)
      return true;
    return false;
  }

  public String toString(){
    return server.toString() + ": " + index;
  }

  public NinfCommand toCommand(){
    return new NinfCommand("serverIndex", server.host, ""+server.port, ""+index);
  }
}

