package bricks.environment;
import bricks.util.*;
import java.util.*;

public class NetworkCreator extends ComponentCreator {

    // for bricks.tools.ShowUsage
    public NetworkCreator(){}

    public NetworkCreator(
	SimulationSet owner, SubComponentFactory subComponentFactory
    ) {
	this.owner = owner;
	this.subComponentFactory = subComponentFactory;
    }

    public String usage() {
	return "Network <String key> <Queue queue> " +
	    "OthersData(<Sequence dataSize>, <Sqeuence interarrivalTime>)";
    }

    public void create(String str) throws BricksParseException {
	//System.out.println("create Network...");
	try {
	    StringTokenizer st = new StringTokenizer(str);
	    String tmp = st.nextToken(" \t(),"); // network
	    String key = st.nextToken(" \t(),");
	    Queue queue = (Queue)subComponentFactory.create(st);

	    tmp = st.nextToken(" \t(),"); // OthersData
	    Sequence dataSize = null;
	    Sequence interarrivalTime = null;
	    if (!tmp.equalsIgnoreCase("n/a")) {
		dataSize = 
		    (Sequence)subComponentFactory.create(
			st, (owner.logicalPacket).packetSize
		    );
		interarrivalTime = (Sequence)subComponentFactory.create(st);
	    }
	    owner.register(key, new Network(
		owner, key, queue, dataSize, interarrivalTime
	    ));

	} catch (NoSuchElementException e) {
	    e.printStackTrace();
	    throw new BricksParseException(usage());

	} catch (BricksParseException e) {
	    e.addMessage(usage());
	    throw e;
	}
    }
}
