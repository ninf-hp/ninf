#include <stdio.h>
#include <sys/types.h>
#include <sys/time.h>
#include "ninf_macros.h"


#ifdef DUMP_TIME

#define DUMP_TIME_MAX 10000
#define DUMP_FILE_NAME "ninf_serv.log.%d"
FILE * dump_time_file;
long dump_time[DUMP_TIME_MAX][2];
int dump_index, dump_skip_index, dump_skip;
int dump_initialized = FALSE;

struct timeval t0, t;
struct timezone tz0, tz;


DUMP_TIME_TICK()
{
  if (!dump_initialized){
    dump_index = 0; dump_skip_index = 0; dump_skip = 0;
    gettimeofday(&t0, &tz0);
    dump_initialized = TRUE;
  }
  if (dump_skip_index++ >= dump_skip){
    gettimeofday(&t, &tz);
    t.tv_sec -= t0.tv_sec;
    t.tv_usec -= t0.tv_usec;
    if (t.tv_usec < 0) {t.tv_usec += 1000000; t.tv_sec -= 1;}
    if (dump_index < DUMP_TIME_MAX){
      dump_time[dump_index][0] = t.tv_sec;
      dump_time[dump_index++][1] = t.tv_usec;
    }
    dump_skip_index = 0;
  }
}
DUMP_TIME_DUMP()
{
  int i;
  
  gettimeofday(&t, &tz);
  t.tv_sec -= t0.tv_sec;
  t.tv_usec -= t0.tv_usec;
  if (t.tv_usec < 0) {t.tv_usec += 1000000; t.tv_sec -= 1;}
  
  fprintf(dump_time_file, "dump_skip = %d, last skip_index = %d\n", dump_skip, dump_skip_index);
  for (i = 0; i < dump_index; i++){
    fprintf(dump_time_file, "%ld\t%ld\n", dump_time[i][0], dump_time[i][1]);
  }
  fprintf(dump_time_file, "\n%ld\t%ld\n\n", t.tv_sec, t.tv_usec);      

  dump_initialized = FALSE;
}
DUMP_TIME_OPEN()
{
  char dump_file_name[100];
  sprintf(dump_file_name, DUMP_FILE_NAME, getpid());
  if ((dump_time_file = fopen(dump_file_name, "w")) == NULL){
    ninf_error("can't open log file\n");
    exit(3);
  }
  dump_initialized = FALSE;
}
DUMP_TIME_CLOSE()
{
    fclose (dump_time_file);
}
DUMP_TIME_GETENV()
{
  if (getenv("NINF_DUMP_SKIP") != NULL){
    fprintf(stderr, "NINF_DUMP_SKIP = %s\n", getenv("NINF_DUMP_SKIP"));
    dump_skip = atoi(getenv("NINF_DUMP_SKIP"));
  }
}

DUMP_TIME_SET_SKIP(int skip)
{
  dump_skip = skip;
  fprintf(stderr, "skip_time = %d\n", dump_skip);
}
#endif 
