# test bricks.tools.BricksConfiguration

#java bricks.tools.BricksConfiguration -sl 0.1 -nd 3 -nn 2:3 -lt 50:100 -wt 200:400 -r 1:1 -sp 500:5000 -cr u:100:200:u:100:200:u:1000:10000:u:10:60 -bricks -scheduler loth -comment -prefix tmp1 -seed 10 -npsize 50 -itnp 30 -itsp 30 

java bricks.tools.BricksConfiguration -sl 0.1 -nd 3 -nn 2:3 -lt 50:100 -wt 200:400 -r 1:1 -sp 500:5000 -cr u:100:200:u:100:200:u:1000:10000:u:10:60 -bricks -scheduler loth -comment -prefix tmp1 -seed 10 -npsize 50 -itnp 30 -itsp 30 -sodsize 10.0

