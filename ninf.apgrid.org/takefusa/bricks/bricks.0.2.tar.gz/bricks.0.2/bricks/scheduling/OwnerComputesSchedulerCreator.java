package bricks.scheduling;
import bricks.util.*;
import java.util.*;

public class OwnerComputesSchedulerCreator extends SchedulingUnitCreator {

    public String usage() {
	return "OwnerComputesScheduler(<String keyOfPredictor>, <String keyOfReplicaManager>, <String keyOfServerMonitor>)";
    }

    public SchedulingUnit create(StringTokenizer st) 
	throws BricksParseException 
    {
	try {
	    String keyOfMetaPredictor = st.nextToken(" \t,()");
	    String keyOfReplicaManager = st.nextToken(" \t,()");
	    String keyOfServerMonitor = st.nextToken(" \t,()");
	    return new OwnerComputesScheduler(
		keyOfMetaPredictor, keyOfReplicaManager, keyOfServerMonitor
	    );

	} catch (NoSuchElementException e) {
	    e.printStackTrace();
	    throw new BricksParseException(usage());
	}
    }
}

