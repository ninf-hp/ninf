package ninf.netsolve;

import ninf.client.NinfExpression;
import ninf.client.NinfVal;
import ninf.basic.XDROutputStream;
import java.io.IOException;


public class Formula{

  public String mnemonic;
  public String value;

  public Formula(String mnemonic, String value){
    this.mnemonic = mnemonic;
    this.value = value;
  }
  public String toString(){
    return "Form:( " + mnemonic + " " + value + ")";
  }

  public NinfExpression getExpression(Problem prob) throws CannotConvertException{
    FormulaParser fp = new FormulaParser(value);
    ParsedFormula pf = fp.parse();
    NinfExpression exp = new NinfExpression();
    int index = pf.setExpression(prob, exp, 0);
    exp.type[index] = NinfVal.VALUE_END_OF_OP;
    exp.val [index] = 0;
    return exp;
  }


  public void write(XDROutputStream os) throws IOException{
    os.writeString(mnemonic);
    os.writeString(value);
  }



} // End class Formula
