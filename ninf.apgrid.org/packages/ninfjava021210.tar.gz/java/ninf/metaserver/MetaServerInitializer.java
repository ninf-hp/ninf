package ninf.metaserver;
import ninf.basic.NinfException;

public interface MetaServerInitializer{
  public void init(MetaServerConfig conf) throws NinfException;
}
