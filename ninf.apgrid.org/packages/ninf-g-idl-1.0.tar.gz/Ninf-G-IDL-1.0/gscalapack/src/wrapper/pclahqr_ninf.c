#define _WRAPPER_
/* $Id: pclahqr_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define SCOMPLEX
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n
#define ROW_z ldz
#define COL_z n
static	int worklen(int n, int lda, int ldz) {
	  int ret=1;
	  int HBL;
	  ret = 3*n + max( 2*max(ROW_z,ROW_a) + 2*n, 7*n);
	  if NEED_BUFF {
	    HBL=max(rbloc,cbloc);
	    ret = 3*n + max( 2*max(ROW_z,ROW_a) + 2*LOCc(N), 7*ceil(N,HBL)/lcm(NPROW,NPCOL));
	  }
	  return ret;
}

static	int iworklen() {
	  int ret=1;
	  ret = 10;
	  return ret;
}

void  pclahqr_ninf(	 long wantt,
		 long wantz,
		 int n,
		 int ilo,
		 int ihi,
		 scomplex a[],
		 int lda,
		 scomplex w[],
		 int iloz,
		 int ihiz,
		 scomplex z[],
		 int ldz,
		 int *info
)
/* "pclahqr is an auxiliary routine used to find the Schur decomposition and or eigenvalues of a matrix already in Hessenberg form from cols ILO to IHI. If Z = I, and WANTT=WANTZ=.TRUE., H gets replaced with Z'HZ, with Z'Z=I, and H in Schur form." */
/* OPTIONS */
{
extern void FortranCall(pclahqr)( long*, long*,
				  int*, int*, int*,
				  scomplex*, int*,
				  scomplex*,
				  int*, int*,
				  scomplex*, int*,
				  scomplex*, int*,
				  int*, int*,
				  int*);

	int maxldd;

	int desca[DESCLEN];
	int descz[DESCLEN];

	scomplex *locw=NULL;

	scomplex *locwork=NULL;
	int llocwork;
	int *lociwork=NULL;
	int llociwork;



	INITIALIZE();

	SCALAR( "long", wantt);
	SCALAR( "long", wantz);
	SCALAR( "int", n);
        SCALAR( "int", ilo);
	SCALAR( "int", ihi);
	SCALAR( "int", iloz);
	SCALAR( "int", ihiz);
	SCALAR( "int", lda);
	SCALAR( "int", ldz);

	COMMON_MATRIX("scomplex", a, ROW_a, COL_a);
	Cdescinit(desca, ROW_a, COL_a, ROW_a, COL_a, 0, 0, PARA_CTXT,  ROW_a, &linfo);
	COMMON_MATRIX("scomplex", z, ROW_z, COL_z);
	Cdescinit(descz, ROW_z, COL_z, ROW_z, COL_z, 0,0, PARA_CTXT, ROW_z, &linfo);

	locw = MALLOC(sizeof(scomplex)*n);
        assert(locw);

	llocwork = worklen(n, lda, ldz);
	WORK(locwork,llocwork);
	llociwork = iworklen();
	IWORK(lociwork,llociwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pclahqr)( &wantt, &wantz,
			       &n, &ilo, &ihi,
			       a, desca,
			       locw,
			       &iloz, &ihiz,
			       z, &descz,
			       locwork, &llocwork,
			       lociwork, &llociwork,
			       &linfo);

	RETRIEVE("scomplex", locw, n);
	RETRIEVE("scomplex", a, ROW_a*COL_a);
	RETRIEVE("scomplex", z, ROW_z*COL_z);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
		int i;
		*info = linfo;
		for(i=0;i<n;i++) w[i] = locw[i];
	} else {
	}

	FREE_COMMON(a);
	FREE_COMMON(z);
	FREE(locw);
	
}

