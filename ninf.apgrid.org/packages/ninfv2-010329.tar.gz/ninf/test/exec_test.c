#include <stdio.h>
#include <math.h>
#include "ninf_stub.h"

#define N    5
#define W    3
#define T    10
#define M    W * T

extern int ninf_debug_flag;
int verbose = FALSE;

void init_data(double a[][N], double b[][N]){
  int i, j;
  for (j = 0; j < M; j++){
    for (i = 0; i < N; i++){
      a[j][i] = i + 100 * j;
      b[j][i] = 0;
    }
  }
}


int check_data(double a[][N], double b[][N]){
  int i, j;
  for (j = 0; j < M; j++){
    for (i = 0; i < N; i++){
      if (a[j][i] != b[j][i]){
	if (verbose) 
	  printf ("a[%d][%d](%lf) != b[%d][%d](%lf)\n",j,i,a[j][i],j,i,b[j][i]);
	return FALSE;
      }
    }
  }
  return TRUE;
}

int exec_test(){
  double a[M][N], b[M][N];
  int j;
  Ninf_executable_t * exec;
  init_data(a, b);
  printf("exec testing: ");
  if ((exec = Ninf_get_executable("test/double_test")) == NULL)
	return FALSE;
  for (j = 0; j < M; j++){
    if (Ninf_call_executable(exec, N, a[j], b[j]) == NINF_ERROR){
	  if (verbose) Ninf_perror("call_executable failed: ");
	  return FALSE;
	}
  }
  Ninf_executable_finalize(exec);
  return check_data(a,b);
}


int get_job(){
  static int i = 0;
  if (i >= M)
	return -1;
  return i++;
}

int exec_async_test(){
  double a[M][N], b[M][N];
  int i, j, id;
  Ninf_executable_t * execs[W];
  Ninf_executable_t * exec;
  int counter = 0;

  init_data(a, b);
  printf("exec_async testing: ");

  for (j = 0; j < W; j++){
	int job;
	if ((execs[j] = Ninf_get_executable("test/double_test")) == NULL){
	  if (verbose) Ninf_perror("get_executable");
	  return FALSE;
	}
	job = get_job();
	if (Ninf_call_executable_async(execs[j], N, a[job], b[job]) == NINF_ERROR){
	  if (verbose) Ninf_perror("Ninf_call_executable_async");
	  return FALSE;
	}
  }

  while (TRUE){
	int id = Ninf_wait_any();
	if (id == NINF_OK){
	  if (counter == M)
		break;
	  else {
		printf("Something go wrong with Ninf_wait_any()\n");
		printf("it should be called %d times, but actually called %d times\n", 
			   M, counter);
		break;
	  }
	} else if (id == NINF_ERROR){
	  Ninf_perror("Something go wrong with Ninf_wait_any():");
	  break;
	} else {
	  int job;
	  counter++;
	  if ((job = get_job()) < 0)
		continue;
	  if ((exec = Ninf_get_executable_from_session(id)) == NULL){
		Ninf_perror("Ninf_get_executable_from_session");
		return FALSE;
	  }
	  if (Ninf_call_executable_async(exec, N, a[job], b[job]) == NINF_ERROR){
		if (verbose) Ninf_perror("Ninf_call_executable_async");
		return FALSE;
	  }
	}
  }
  for (j = 0; j < W; j++)
	Ninf_executable_finalize(execs[j]);

  return check_data(a,b);
}

main(int argc, char ** argv)
{
  argc = Ninf_parse_arg(argc, argv);
  while (argc > 1){
    argv++;
    if (strcasecmp(*(argv), "-verbose") == 0)
      verbose = TRUE;
    if (strcasecmp(*(argv), "-debug") == 0)
      ninf_debug_flag = TRUE;
    argc--;
  }
  
  if (exec_test())  {printf("\tOK\n");} else { printf("\tfailed\n");} 
  if (exec_async_test())  {printf("\tOK\n");} else { printf("\tfailed\n");} 
}


