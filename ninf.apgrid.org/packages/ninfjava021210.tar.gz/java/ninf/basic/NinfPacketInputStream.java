package ninf.basic;

import java.io.IOException;
import java.io.*;
import java.io.PrintStream;

public class NinfPacketInputStream extends InputStream{
  XDRInputStream is;
  OutputStream stdoutStream, stderrStream;
  NinfPacket cpacket;
  int cp, max;
  private static int XDRLIMIT = 4;
  NinfLog dbg = new NinfLog(this);
  boolean withHeader = true;

  static final int buflen = NinfPacket.MAX_PKT_LEN - NinfPktHeader.PktHeaderSize;
  
  public NinfPacketInputStream(XDRInputStream s, OutputStream stdoutStream, 
			       OutputStream stderrStream){
    this(s);
    this.stdoutStream = stdoutStream;
    this.stderrStream = stderrStream;
  }

  public NinfPacketInputStream(XDRInputStream s, OutputStream stdoutStream, 
			       OutputStream stderrStream, boolean withHeader){
    this(s);
    this.stdoutStream = stdoutStream;
    this.stderrStream = stderrStream;
    this.withHeader = withHeader;
  }

  public NinfPacketInputStream(XDRInputStream s){
    is = s;
    cp = 0;
    max = 0;
  }
  public NinfPacketInputStream(NinfPacket p, XDRInputStream s){
    cpacket = p;
    is = s;
    cp = 0;
    max = p.hdr.size;
  }

  public NinfPacketInputStream(XDRInputStream s, boolean withHeader){
    this(s);
    this.withHeader = withHeader;
  }
  
  void readPacket() throws NinfException {
    cpacket = new NinfPacket(is, withHeader);
    cp = 0;
    max = cpacket.hdr.size;

    if (cpacket.hdr.code == NinfPktHeader.NINF_PKT_ERROR)
      throw new NinfErrorException(cpacket.hdr.arg1);

    if (!(cpacket.hdr.code == NinfPktHeader.NINF_PKT_STDOUT ||
	  cpacket.hdr.code == NinfPktHeader.NINF_PKT_STDERR))
      return;

    if (cpacket.hdr.code == NinfPktHeader.NINF_PKT_STDOUT &&
	stdoutStream != null){
      try{
	stdoutStream.write(cpacket.buf);
      }catch (IOException e){}
    } else if (cpacket.hdr.code == NinfPktHeader.NINF_PKT_STDERR &&
	stderrStream != null){
      try{
	stderrStream.write(cpacket.buf);
      }catch (IOException e){}
    }
    readPacket();
  }	

  public int rest(){
    return (max - cp);
  }

  public void dumpRest(PrintStream os){
    for (int i = 0; i < 20; i++){
      for (int j = 0; j < 20 && (i * 20 + j) < (max - cp); j++){
	os.print(cpacket.buf[(i * 20 + j) + cp] + " ");
      }
      os.println("");
    }
  }
  public NinfPacket getRestPacket() throws NinfException{
    int restsize = rest();
    byte rest[] = new byte[restsize];
    try {
      read(rest);
    } catch (IOException e){
      throw new NinfIOException(e);
    }
    return new NinfPacket(cpacket.hdr.code, restsize, 
			  cpacket.hdr.arg1, cpacket.hdr.arg2, rest);
  }

  public int getCode() throws NinfException{
    if (cpacket == null) readPacket();
    return cpacket.hdr.code;
  }
  public int getArg1() throws NinfException{
    if (cpacket == null) readPacket();
    return cpacket.hdr.arg1;
  }


  /******************* for short cut ********************/

  public int readInt() throws NinfException {
    try {
      return (new XDRInputStream(this)).readInt();
    } catch (IOException e){
      throw new NinfIOException(e);
    }
  }

  public double readDouble() throws NinfException {
    try {
      return (new XDRInputStream(this)).readDouble();
    } catch (IOException e){
      throw new NinfIOException(e);
    }
  }
  public long readLong() throws NinfException {
    try {
      return (new XDRInputStream(this)).readLong();
    } catch (IOException e){
      throw new NinfIOException(e);
    }
  }

  public String readString() throws NinfException {
    try {
      return (new XDRInputStream(this)).readString();
    } catch (IOException e){
      throw new NinfIOException(e);
    }
  }

  public void readThrough(int length) throws NinfException {
    try {
      skip(length);
    } catch (IOException e){
      throw new NinfIOException(e);
    }
  }

  /******************* to extend InputStream ********************/

  public int read() throws IOException {
    byte tmp[] = new byte[1];
    read(tmp);
    //    System.out.print((((int) tmp[0]) & 0xff) + " ");

    return ((int) tmp[0]) & 0xff;
  }

  public int read(byte buf[], int off, int length) throws IOException {
    try {
      //    System.out.println(" reading " + length + " bytes, from " + cp);
      int pointer = 0;
      //System.out.println("Reading from Packet "+
      //(max - cp) + " ," + (length - pointer));
      
      if (cpacket == null) readPacket();
      while ((max - cp) < length - pointer){
	System.arraycopy(cpacket.buf, cp, buf, pointer+off, max - cp);
	pointer += max - cp;
	readPacket();
      }
      System.arraycopy(cpacket.buf, cp, buf, pointer+off, length - pointer);
      cp += length - pointer;
      return length;
    } catch (NinfException e){
      return -1;
    }
  }

  public int read(byte buf[], int length) throws IOException {
    return read(buf, 0, length);
  }

  public int read(byte buf[]) throws IOException {
    return read(buf, 0, buf.length);
  }

  public long skip(long length) throws IOException {
    try {
      int pointer = 0;     /* just read through input. to measure throughput */
      
      if (cpacket == null) readPacket();
      while ((max - cp) < length - pointer){
	//      System.arraycopy(cpacket.buf, cp, buf, pointer, max - cp);
	pointer += max - cp;
	readPacket();
      }
      //  System.arraycopy(cpacket.buf, cp, buf, pointer, length - pointer);
      cp += length - pointer;
      return length;
    } catch (NinfException e){
      return -1;
    }
  }
}
