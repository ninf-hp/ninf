#define _WRAPPER_
/* $Id: pdgerfs_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define DOUBLE
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n
#define ROW_af ldaf
#define COL_af n
#define ROW_b ldb
#define COL_b nrhs
#define ROW_x ldx
#define COL_x nrhs
#define LOCc_a(n) Cnumroc( (n), cbloc, mypcol, 0, npcol)
#define LOCr_a(m) Cnumroc( (m), rbloc, myprow, 0, nprow)
#define IA 1
static        int worklen(int n)        {
            int ret;
            ret = 3*n;
            if NEED_BUFF
                ret = 3*LOCr_a(n+(IA-1)%MB);
            return ret;
        }
static        int iworklen(int n)         {
            int ret;
            ret = 2*3*n;
            if NEED_BUFF
                ret = 2*3*LOCr_a(n+(IA-1)%MB);
            return ret;
}

void  pdgerfs_ninf(	 char trans,
		 int n,
		 int nrhs,
		 double global_a[],
		 int lda,
		 double global_af[],
		 int ldaf,
		 int global_ipiv[],
		 double global_b[],
		 int ldb,
		 double global_x[],
		 int ldx,
		 double global_ferr[],
		 double global_berr[],
		 double work[],
		 int iwork[],
		 int *info
)
/* "pdgerfs improves the computed solution to a system of linear equations and provides error bounds and backward error estimates for  the solutions." */
/* OPTIONS */
{
	int maxldd;

	int maxlda;
	double *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];

	int maxldaf;
	double *locaf=NULL;
	int descaf[DESCLEN];
	int desc_gaf[DESCLEN];

	int maxldb;
	double *locb=NULL;
	int descb[DESCLEN];
	int desc_gb[DESCLEN];

	int maxldx;
	double *locx=NULL;
	int descx[DESCLEN];
	int desc_gx[DESCLEN];

	int *locipiv=NULL;
        double *locferr=NULL;
	double *locberr=NULL;

        double *locwork=NULL;
        int llocwork;
        int *lociwork=NULL;
        int llociwork;

	int row_loca, col_loca;
	int row_locaf, col_locaf;
	int row_locb, col_locb;
	int row_locx, col_locx;

	INITIALIZE();

	SCALAR( "char", trans);
	SCALAR( "int", n);
	SCALAR( "int", nrhs);
	SCALAR( "int", lda);
	SCALAR( "int", ldb);
	SCALAR( "int", ldx);

	ROW( a);
	COL( a);
	ROW( af);
	COL( af);
	ROW( b);
	COL( b);
	ROW( x);
	COL( x);
	MAXLDD( maxldd, a );
	maxlda = maxldd;
	maxldaf = maxldd;
	maxldb = maxldd;
	maxldx = maxldd;

	MATRIX( "double", a, ROW_a, COL_a);
	MATRIX( "double", af, ROW_af, COL_af);
	MATRIX( "double", b, ROW_b, COL_b);
	MATRIX( "double", x, ROW_x, COL_x);
	VECTOR( "r", "int", ipiv, ROW_af);
	VECTOR( "c", "double", ferr, nrhs);
	VECTOR( "c", "double", berr, nrhs);
	DISTRIBUTE( "double", a, ROW_a  , COL_a);
	DISTRIBUTE( "double", af, ROW_af  , COL_af);
	DISTRIBUTE( "double", b, ROW_b  , COL_b);
	DISTRIBUTE( "double", x, ROW_x  , COL_x);
	vDISTRIBUTE( "r", "int", ipiv, ROW_af);

	llocwork=worklen(n);
        WORK( locwork,  llocwork);
	llociwork=iworklen(n);
        WORK( lociwork, llociwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pdgerfs)( &trans, &n, &nrhs,
                               loca, &one, &one, desca,
                               locaf, &one, &one, descaf,
                               locipiv,
                               locb, &one, &one, descb,
                               locx, &one, &one, descx,
                               locferr, locberr,
                               locwork, &llocwork,
                               lociwork, &llociwork,
                               &linfo);

	GATHER( "double", x, ROW_x  , COL_x);
	vGATHER( "c", "double", ferr, nrhs);
	vGATHER( "c", "double", berr, nrhs);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
		*info = linfo;
	} else {
	}

	FREE_MATRIX(a);
	FREE_MATRIX(af);
	FREE_MATRIX(b);
	FREE_MATRIX(x);
	FREE_VECTOR(ipiv);
	FREE_VECTOR(ferr);
	FREE_VECTOR(berr);
	FREE(locwork);
        FREE(lociwork);
}

