package ninf.netsolve;

import ninf.client.NinfExpression;
import ninf.client.NinfVal;

public interface ParsedFormula{
  int setExpression(Problem prob, NinfExpression exp, int index) throws CannotConvertException;
}

class FormulaConstant implements ParsedFormula{
  public int i;
  public FormulaConstant(int i){
    this.i = i;
  }
  public String toString(){
    return ""+ i;
  }
  public int setExpression(Problem prob, NinfExpression exp, int index) throws CannotConvertException{
    exp.type[index] = NinfVal.VALUE_CONST;
    exp.val [index] = i;
    return index+1;
  }
}

class FormulaMnemonic implements ParsedFormula{
  public String mnemonic;

  public FormulaMnemonic(String mnemonic){
    this.mnemonic = mnemonic;
  }

  public String toString(){
    return mnemonic;
  }
  public   int setExpression(Problem prob, NinfExpression exp, int index) throws CannotConvertException{
    int i = prob.lookForMnemonic(mnemonic);

    if (i < 0){
      System.err.println("cannot fined mnemonic :" + this);
      throw new CannotConvertException();
    }
    exp.type[index] = NinfVal.VALUE_IN_ARG;
    exp.val [index] = i;
    return index+1;
  }
  int getOpVal() throws CannotConvertException{
    if (mnemonic.equals("+")){
      return NinfExpression.OP_VALUE_PLUS;
    } else if (mnemonic.equals("-")){
      return NinfExpression.OP_VALUE_MINUS;
    } else if (mnemonic.equals("*")){
      return NinfExpression.OP_VALUE_MUL;
    } else if (mnemonic.equals("/")){
      return NinfExpression.OP_VALUE_DIV;
    } else if (mnemonic.equals("%")){
      return NinfExpression.OP_VALUE_MOD;
    } else if (mnemonic.equals("^")){
      return NinfExpression.OP_VALUE_BEKI;
    } else {
      System.err.println("unknown opecode:" + this);
      throw new CannotConvertException();
    }
  }
}

class FormulaExpression implements ParsedFormula{
  String code;       /* codes = "op", "if", "array" */
  ParsedFormula parts[];   /* each must be ParsedFormula or String */

  public FormulaExpression(String code, ParsedFormula parts[]){
    this.code = code;
    this.parts = parts;
  }

  public String toString(){
    String tmp = code + "("; 
    int i;
    for (i = 0; i < parts.length - 1; i++)
      tmp += parts[i] + ", ";
    tmp += parts[i] + ")";
    return tmp;
  }

  public   int setExpression(Problem prob, NinfExpression exp, int index) throws CannotConvertException{
    if (code.equals("array")){
      throw new CannotConvertException();
    } else if (code.equals("=")){
      index = parts[0].setExpression(prob, exp, index);
      index = parts[1].setExpression(prob, exp, index);
      exp.type[index] = NinfVal.VALUE_OP;
      exp.val [index] = NinfExpression.OP_VALUE_EQ;
      return ++index;
    } else if (code.equals("if")){
      index = parts[0].setExpression(prob, exp, index);
      index = parts[1].setExpression(prob, exp, index);
      index = parts[2].setExpression(prob, exp, index);
      exp.type[index] = NinfVal.VALUE_OP;
      exp.val [index] = NinfExpression.OP_VALUE_TRY;
      return ++index;      
    } else if (code.equals("op")){
      index = parts[1].setExpression(prob, exp, index);
      index = parts[2].setExpression(prob, exp, index);
      exp.type[index] = NinfVal.VALUE_OP;
      exp.val [index] = ((FormulaMnemonic)parts[0]).getOpVal();
      return ++index;
    } else {
      System.err.println("unknown formula:" + this);
      throw new CannotConvertException();
    }
  }
}
