/* ninf regiser program */
#define ERROR_MAIN

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <signal.h>
#include <sys/wait.h>
#include <sys/errno.h>
#include <rpc/rpc.h>
#include "ninf_serv_reg.h"

#include "ninf_error.h"

char * program_context = "Register";

char *reg_pkt_buf;

int myread(int sock, char * reg_pkt_buf, int size){
  int n, readed = 0;

  while (readed < size){
    if ((n = read(sock, reg_pkt_buf + readed, size - readed)) < 0)
      return n;
    readed += n;
  }
  return size;
}

void usage(){
  fprintf(stderr, "ninf_register [[[-register | -remove] filenames] \n           | -dump | -stop | -port PORT]\n");
}


static int sock;
char * get_arg_host(char *);
char * get_arg_port(char *); 

main(int argc, char *argv[])
{
  int ac,n;
  char *program;
  char *pwd;
  int register_flag = TRUE;
  char reg_sockname[100];
  
  reg_pkt_buf = (char *) malloc(NINF_REG_PKT_SIZE);  

  if((pwd = (char *)getenv("PWD")) == NULL)
    fprintf(stderr, "cannot get 'PWD', using relative path.\n");

  argc = Ninf_parse_arg(argc, argv);
    
  make_reg_sockname(reg_sockname, atoi(get_arg_port(getenv("NINF_SERVER_PORT"))));
  sock = ninf_connect_local(reg_sockname);
  if (sock < 0){
    fprintf(stderr, "failed to connect the server\n");
    exit(3);
  }
  for (ac = 1; ac < argc; ac++){
    program = argv[ac];
    if (strncmp(program, "-register", 10) == 0){
      register_flag = TRUE;
    } else if (strncmp(program, "-remove", 8) == 0){
      register_flag = FALSE;      
    } else if (strncmp(program, "-dump", 6) == 0){
      dump();
    } else if (strncmp(program, "-stop", 6) == 0){
      stop();
    } else if (strncmp(program, "-h", 3) == 0){
      usage();
      break;
    } else{
      register_flag_program(program, pwd, register_flag);
    }
  }
  close(sock);
  exit(0);
}

stop(){
  struct ninf_reg_stub_packet *p;

  p = (struct ninf_reg_stub_packet *)reg_pkt_buf;
  p->code = NINF_REG_STOP;
  ninf_reg_send();
}

dump()
{
  struct ninf_reg_stub_packet *p;

  p = (struct ninf_reg_stub_packet *)reg_pkt_buf;
  p->code = NINF_REG_DUMP;
  ninf_reg_send();
  while (ninf_reg_recv(), p->code == NINF_REG_DUMP_ANS){
    printf("%d: '%s:%s' = '%s'\n",
	   p->stub_index,p->module_name,p->entry_name,p->program);
  }
}

ninf_reg_recv(){
  int n;
  if((n = myread(sock,reg_pkt_buf,NINF_REG_PKT_SIZE)) 
     != NINF_REG_PKT_SIZE){
    fprintf(stderr, "Failed to receive reply from server. n=%d\n",n);
    exit(1);
  }
}

ninf_reg_send()
{
  int n;

  if((n = write(sock,reg_pkt_buf,NINF_REG_PKT_SIZE)) 
     != NINF_REG_PKT_SIZE){
    fprintf(stderr, "Failed to send command to the server. n=%d\n",n);
    exit(1);
  }
}

register_flag_program(char * program, char * pwd, int register_flag)
{
  struct ninf_reg_stub_packet *p;

  p = (struct ninf_reg_stub_packet *)reg_pkt_buf;
  printf("try to %s  '%s'...\n", register_flag?"register":"remove", program);
  if (register_flag)
    p->code = NINF_REG_ENTER_STUB;
  else
    p->code = NINF_REG_REMOVE_STUB;
  if (pwd && program[0] != '/'){
    strcpy(p->program,pwd);
    strcat(p->program,"/");
    strcat(p->program,program);
  } else 
    strcpy(p->program,program);
  
  ninf_reg_send();
  ninf_reg_recv();

  if(p->code != NINF_REG_OK) 
    printf("stub program '%s' %s failed.\n",p->program, 
	   register_flag?"register":"remove");
  else {
    if (register_flag)
      printf("stub program '%s', entry '%s:%s' is registered on %d\n",
	     p->program,p->module_name,p->entry_name,p->stub_index);
    else 
      printf("stub program '%s' was removed\n", p->program);
  }

}
