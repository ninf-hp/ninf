package ninf.MetaServer;
import ninf.basic.*;
import ninf.client.*;
import ninf.netsolve.*;

import java.io.IOException;
import java.util.Vector;

public class NetSolveLatch implements NinfCallable, Stoppable{
  NinfPacket pkt;
  XDRInputStream is;
  XDROutputStream os;
  Vector buffers = new Vector();
  ProblemStruct pStruct;
  NinfStub stub;
  NinfLog dbg = new NinfLog(this);

  BufferObject nbuffers[];
  int m[];
  int n[];


  public NetSolveLatch(ProblemStruct pStruct){
    this.pStruct = pStruct;
    this.stub = pStruct.getStub();
  }


  void setupNetSolveVector(Vector buffers, Problem problem) throws NinfIOException{
    try {
      m = new int[problem.nb_input];
      n = new int[problem.nb_input];
      nbuffers = problem.transNinfBuffers(buffers, m, n);
      /*      for (int i = 0; i < nbuffers.length; i++){
	for (int j = 0; j <nbuffers[i].size(); j++)
	  System.out.println(nbuffers[i].elementAt(j));
	System.out.println("");
      }*/
    } catch (IOException e){
      throw new NinfIOException(e);
    }
  }

  int[][] writeBackToBuffer(Problem problem, Vector output, Vector buffers) throws NinfIOException{
    try {
      return problem.writeBackToBuffer(output, buffers);
    } catch (IOException e){
      throw new NinfIOException(e);
    }
  }

  public void recieveNinfCode(NinfPacketInputStream is) throws NinfException {
    int i;
    if ((i = is.readInt()) != 1)
      dbg.println("Invalid code:"  + i);
    else
      dbg.println("get Ninf Call Code: " + i);
  }

  public Stoppable call(NinfPacket pkt, XDRInputStream is, XDROutputStream os) 
    throws NinfException {
    int sizes[][] = null;
      
    this.pkt = pkt;
    this.is = is;
    this.os = os;

    NinfPacket.getRpyCallPacket().write(os);
    NinfPacketInputStream pis = new NinfPacketInputStream(pkt, is);    
    try {
      recieveNinfCode(pis);
      stub.setupBuffers(buffers, pis);
      stub.serverReceive(buffers, pis);
    } catch (Exception e){
      e.printStackTrace();
      throw new NinfIOException();
    }

    for (int i = 0; i < buffers.size(); i++)
      System.out.println("buffer size = " + ((BufferObject)buffers.elementAt(i)).data.length);
    setupNetSolveVector(buffers, pStruct.problem);
    try {
      SubmitJob job = new SubmitJob(pStruct.server, pStruct.problem, nbuffers, null, m, n);
      Vector output = job.start();
      sizes = writeBackToBuffer(pStruct.problem, output, buffers);
    } catch (NetSolveException e){
      throw new NinfNetSolveException(e);
    }

    
    stub.serverSend(buffers, new NinfPacketOutputStream(os, false));
    return this;
  }

  public void stop() {
  }
}


