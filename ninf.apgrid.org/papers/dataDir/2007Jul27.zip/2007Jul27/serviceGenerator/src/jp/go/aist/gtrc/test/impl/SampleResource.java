package jp.go.aist.gtrc.test.impl;

import jp.go.aist.gtrc.util.OperationAN;
import jp.go.aist.gtrc.util.PropertyAN;

public class SampleResource {
	@PropertyAN
	private int count;

	@OperationAN
	public int add(int addValue) {
		return count += addValue;
	}

	@OperationAN
	public int sub(int subValue) {
		return count -= subValue;
	}
}
