package bricks.scheduling;
import java.util.*;

public class HeapSortForReplicaManager {
    
    private static final String Usage = 
	"java bricks.util.HeapSortForReplicaManager [int numData]";

    private static Vector v = new Vector();

    public static void sortByScore(Vector list) {
	int bottom = list.size() / 2;
	int top = list.size() - 1;
	while (bottom > 0) {
	    bottom--;
	    shiftDownByScore(list, top, bottom);
	}
	while (top > 0) {
	    swap(list, 0, top);
	    top--;
	    shiftDownByScore(list, top, bottom);
	}
    }

    protected static void shiftDownByScore(Vector list, int top, int bottom) {
	int i = 2 * bottom;
	while (i <= top) {
	    if (i < top) {
		Score score1 = (Score)list.elementAt(i+1);
		Score score0 = (Score)list.elementAt(i);
		if (score1.score > score0.score)
		    i++;
	    }
	    if (((Score)list.elementAt(bottom)).score
		>= ((Score)list.elementAt(i)).score)
		break;
	    swap(list, bottom, i);
	    bottom = i;
	    i = 2 * bottom;
	}
    }

    public static void swap(Vector list, int indexA, int indexB) {
	Object tmp = list.elementAt(indexA);
	list.insertElementAt(list.elementAt(indexB), indexA);
	list.removeElementAt(indexA + 1);
	list.insertElementAt(tmp, indexB);
	list.removeElementAt(indexB + 1);
    }
}


