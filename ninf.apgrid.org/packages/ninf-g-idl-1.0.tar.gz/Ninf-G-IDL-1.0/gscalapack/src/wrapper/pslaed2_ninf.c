#define _WRAPPER_
/* $Id: pslaed2_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define FLOAT
#define _DISTRIBUTE_1D_ 
/* this func doesn't treate matrices q and q2 as band,  however,  */
/* q and q2 are to be splitted in rows, so use utils which distribute */
/* a general matrix by splitting in rows. */

#include <gscalapack.h>

#define ROW_q ldq
#define COL_q n
#define ROW_q2 ldq
#define COL_q2 n
void  pslaed2_ninf(	
		 int *k,
		 int n,
		 int n1,
		 float d[],
		 float global_q[],
		 int ldq,
		 int global_indxq[], /* dummy ?*/
		 float *rho,
		 float z[],
		 float dlamda[],
		 float w[],
		 float global_q2[],
		 int indx[],
		 int indxc[],
		 int indxp[],
		 int coltyp[],
		 int *info
)
{
    int maxldd;

    int nn;
    int nn1;
    int nn2;
    int nb;

    int maxldq;
    float *locq=NULL;
    int desc_gq[DESCLEN];
    int descq[DESCLEN];
    int row_locq, col_locq;

    int maxldq2;
    float *locq2=NULL;
    int desc_gq2[DESCLEN];
    int descq2[DESCLEN];
    int row_locq2, col_locq2;

    float *locw=NULL;
    float *locdlamda=NULL;

    int *loccoltyp=NULL;
    int *ctor=NULL, *locpsm=NULL, *locqbuf=NULL;
    int *locindcol=NULL, *locctot=NULL;
    int ib1, ib2;

    INITIALIZE();
    SCALAR( "int", n);
    SCALAR( "int", n1);
    SCALAR( "int", ldq);
    SIZE(n);

    nb = cbloc;

    COMMON("int",k, 1);
    COMMON("float", rho, 1);
    COMMON("int", indx, n);
    COMMON("float", d, n);
    COMMON("float", z, n);


    ROW(q);
    COL(q);
    MAXLDD(maxldd, q);
    maxldq=maxldd;
    ROW(q2);
    COL(q2);
    MAXLDD(maxldd, q2);
    maxldq2=maxldd;

    MATRIX("float", q, ROW_q, COL_q);
    MATRIX("float", q2, ROW_q2, COL_q2);

    DISTRIBUTE("float", q, ROW_q, COL_q);

    locw =MALLOC(sizeof(float)*n); assert(locw);
    loccoltyp = MALLOC(sizeof(int)*n); assert(loccoltyp);
    locdlamda = MALLOC(sizeof(float)*n); assert(locdlamda);

    IWORK(locctot, npcol*4);
    IWORK(locpsm, npcol*4);
    WORK(locqbuf, 3*n);

    IWORK(locindcol,n);

    if  (( mypnum != 0 ) ^ (serial==1) )
	FortranCall(pslaed2)( &PARA_CTXT,
			      &k, &n, &n1, &nb,
			      d, &zero, &zero,
			      locq, &row_locq,
			      rho, z, w, locdlamda,
			      locq2, &row_locq2,
			      locqbuf, locctot,
			      locpsm, &npcol,
			      indx, indxc, indxp, locindcol, loccoltyp,
			      &nn, &nn1, &nn2, &ib1, &ib2);

    RETRIEVE("float", d, n);
    RETRIEVE("float", w, n);
    GATHER("float", q, ROW_q, COL_q);
    GATHER("float", q2, ROW_q2, COL_q2);

    RETRIEVE("int", indx, n);

    RETRIEVE("int", locindcol, n);

    RETRIEVE("int", &nn, 1);
    RETRIEVE("int", &nn1, 1);
    RETRIEVE("int", &nn2, 1);
    RETRIEVE("int", &ib1, 1);
    RETRIEVE("int", &ib2, 1);

    RETRIEVE("float", rho, 1);
    RETRIEVE("int", k,1);
    RETRIEVE("float", locw,n);
    RETRIEVE("int", loccoltyp, n);
    RETRIEVE("float", locdlamda, n);
    RETRIEVE("int", &linfo, 1);

    if( mypnum == 0 ){
	int i;
	*info = linfo;
	for(i=0;i<n;i++) w[i] = locw[i];
	for(i=0;i<n;i++) coltyp[i] = loccoltyp[i];
	for(i=0;i<n;i++) dlamda[i] = locdlamda[i];
    } else {
    }

    FREE_COMMON(k);
    FREE_COMMON(rho);
    FREE_COMMON(indx);
    FREE_COMMON(d);
    FREE_COMMON(z);
    FREE_MATRIX( q);
    FREE_MATRIX( q2);
    FREE(locw);
    FREE(loccoltyp);
    FREE(locdlamda);
	
}

