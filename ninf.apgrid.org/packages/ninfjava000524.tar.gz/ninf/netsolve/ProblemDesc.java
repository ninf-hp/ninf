package ninf.netsolve;
public class ProblemDesc {
  public String name;
  public String path;
  public String desc;

  public int num_upf;
  public UpfStruct [] upfs;

  public int nb_obj_input;
  public int nb_obj_output;
  public NetSolveObject [] input_obj;
  public NetSolveObject [] output_obj;

  public int nb_matlab;
  public MatlabMerge [] matlab;

  public String complexity;

  public int nb_formats;
  public FormatSpec [] formats;
}
