#define _WRAPPER_
/* $Id: pclapv2_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define SCOMPLEX
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n
void  pclapv2_ninf(	 char direc,
		 char rowcol,
		 int m,
		 int n,
		 scomplex global_a[],
		 int lda,
		 int global_ipiv[]
)
/* "pclapv2 applies either P (permutation matrix indicated by IPIV) or inv( P ) to a M-by-N distributed matrix sub( A ) denoting A, resulting in row or column pivoting." */
/* OPTIONS */
{
	int maxldd;

	int maxlda;
	scomplex *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
	int row_loca, col_loca;

	int *locipiv=NULL;
	int descipiv[DESCLEN];

	INITIALIZE();

	SCALAR( "char", direc);
	SCALAR( "char", rowcol);
	SCALAR( "int", m);
	SCALAR( "int", n);

	ROW( a);
	COL( a);
	MAXLDD( maxldd, a);
	maxlda = maxldd;

	MATRIX( "scomplex", a, ROW_a, COL_a);
	DISTRIBUTE( "scomplex", a, ROW_a  , COL_a);

	if (chrcmp(rowcol,'R')==0) {
	  VECTOR( "r", "int", ipiv, ROW_a);
	  Cdescinit( descipiv,  ROW_a, 1, rbloc, 1, 0, 0,PARA_CTXT, rbloc, &linfo);
	  vDISTRIBUTE( "r", "int", ipiv, ROW_a);
	} else {
	  VECTOR( "c", "int", ipiv, COL_a);
	  Cdescinit( descipiv, 1, COL_a, 1, cbloc,  0, 0,PARA_CTXT, 1, &linfo);
	  vDISTRIBUTE( "c", "int", ipiv, COL_a);
	}

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pclapv2)( &direc, &rowcol,
                               &m, &n,
                               loca, &one, &one, desca,
                               locipiv, &one, &one, descipiv);

	GATHER( "scomplex", a, ROW_a, COL_a);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
	} else {
	}

	FREE_MATRIX(a);
	
}

