package ninf.client;

import ninf.basic.*;
import ninf.client.*;


import java.io.IOException;

public class DependInfo {
  static NinfLog dbg = new NinfLog("DependInfo");
  
  // *********************** NON STATIC VARIABLES ***********************
  public ArgPosition inputDepend;
  public ArgPosition outputDepends[];   

  // ***********************  INSTANCE  CREATION  ***********************
  public DependInfo(NinfPacketInputStream is) throws NinfException{
    read(is);
  }

  DependInfo(){
  }

  // ***********************     I/O  METHODS     ***********************
  public void read(NinfPacketInputStream is) throws NinfException {
    int inputNum = is.readInt();
    if (inputNum != 0)
      inputDepend = new ArgPosition(is);
    int outputNum = is.readInt();
    outputDepends = new ArgPosition[outputNum];
    for (int i = 0; i < outputNum; i++)
      outputDepends[i] = new ArgPosition(is);
  }

  public String toString() {
//    String tmp = "dependInfo input:" + ((inputDepend == null)? 0 : 1) 
//               + " output: " + outputDepends.length;
    String tmp =
      (inputDepend == null) ? "{:" : ("{(" + inputDepend.functionIndex + "," +
				      inputDepend.argNum + "):");

    boolean first = true;
    for (int i = 0; i < outputDepends.length; i++) {
      if (!first) tmp += ",";
      first = false;
      tmp = tmp + "(" +
	outputDepends[i].functionIndex + "," + outputDepends[i].argNum + ")";
    }
    tmp += "}";
    return tmp;
  }

  public DependInfo copy(){
    DependInfo tmp = new DependInfo();
    tmp.inputDepend = inputDepend;
    tmp.outputDepends = new ArgPosition[outputSize()];
    for (int i = 0; i < outputSize(); i++)
      tmp.outputDepends[i] = outputDepends[i];
    return tmp;
  }
  
  int outputSize(){
    if (outputDepends == null)
      return 0;
    return outputDepends.length;
  }
      
  public DependInfo add(DependInfo info){
    DependInfo tmp = new DependInfo();
    if (inputDepend != null && info.inputDepend != null){
      dbg.println("duplicated input depend. Error.");
      tmp.inputDepend = inputDepend;
    } else if (inputDepend != null){
      tmp.inputDepend = inputDepend;
    } else {
      tmp.inputDepend = info.inputDepend;
    }    
    tmp.outputDepends = new ArgPosition[outputSize()+info.outputSize()];
    for (int i = 0; i < this.outputSize(); i++)
      tmp.outputDepends[i] = this.outputDepends[i];
    for (int i = 0; i < info.outputSize(); i++)
      tmp.outputDepends[i + this.outputSize()] = info.outputDepends[i];
    return tmp;
  }

  // ***********************  NON STATIC METHODS  ***********************

  public boolean isNoLower() {
    if (outputDepends.length == 0)
      return true;
    return false;
  }

  public boolean isNoUpper() {
    if (inputDepend == null)
      return true;
    return false;
  }
}


// end of DependInfo.java
