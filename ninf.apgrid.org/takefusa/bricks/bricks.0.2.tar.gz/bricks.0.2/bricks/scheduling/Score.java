package bricks.scheduling;
import java.util.*;
import java.io.*;
import bricks.environment.Host;

public class Score {
    Host host;
    double score;
    
    public Score(Host host, double score) {
	this.host = host;
	this.score = score;
    }

    public String toString() {
	return "<" + host + ", " + score + ">";
    }
}


