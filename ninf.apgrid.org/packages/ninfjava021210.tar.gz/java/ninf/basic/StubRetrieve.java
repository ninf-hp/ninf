package ninf.basic;
import java.io.*;
import ninf.client.*;

public class StubRetrieve{
  MetaServerReference  metaServer;
  MetaServerConnection con;
  static NinfLog dbg = new NinfLog("StubRetrieve");
  
  static final CommandRepresent acceptCommands[] = {
    new CommandRepresent("functionNames", 1),
    new CommandRepresent("stub", 0)
  }; 
  static CommandParser parser = new CommandParser(acceptCommands);

  public StubRetrieve(MetaServerReference metaServer){
    this.metaServer = metaServer;
  }

  public FunctionName[] getStubNames() throws NinfException{
    if (con == null)
      con = metaServer.connect();
    new NinfCommand("getFunctionNames").send(con.os);
    NinfCommand com;
    try {
      com = parser.readCommand(con.is);
    } catch (NinfException e){
      dbg.log("cannot get stubnames");
      return new FunctionName[0];
    }
    int count = (new Integer(com.args[0])).intValue();
    FunctionName names[] = new FunctionName[count];
    try {
      for (int i = 0; i < count; i++){
	names[i] = new FunctionName(con.is.readLine());
	dbg.println(names[i]);
      }
    } catch (IOException e){
      throw new NinfIOException(e);
    }
    return names;
  }    

  public NinfStub[] getAllStubs() throws NinfException{
    return getStubs(getStubNames());
  }

  public NinfStub[] getStubs(FunctionName[] names) throws NinfException{
    NinfStub[] ans = new NinfStub[names.length];
    for (int i = 0; i < names.length; i++)
      ans[i] = getStub(names[i]);
    return ans;
  }

  public NinfStub getStub(FunctionName fullName) throws NinfException{
    try {
      MetaServerConnection con = metaServer.connect();
      con.send(new NinfCommand("getStub", fullName.toString()));
      String line = con.is.readLine();
      
      NinfCommand ack = parser.readCommand(line);
      if (ack.command.equals("stub")){
	NinfStub stub = new NinfStub(new XDRInputStream(con.is));
	con.close();
	return stub;
      } else {
	dbg.println("failed to read stub");
	throw new NinfIOException();
      }
    } catch (IOException e){
      throw new NinfIOException(e);
    }
  }

}
