#define _WRAPPER_
/* $Id: pclarft_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define SCOMPLEX
#include <gscalapack.h>

#define ROW_v ldv
#define COL_v col_v
#define ROW_t ldt
#define COL_t k
static	int worklen(int k) {
	  int ret=1;
	  ret = max(1,(k*(k-1)/2));
	  return ret;
}

void  pclarft_ninf(	 char direct,
		 char storev,
		 int n,
		 int k,
		 scomplex global_v[],
		 int ldv,
		 scomplex global_tau[],
		 scomplex global_t[],
		 int ldt
)
/* "pclarft forms the triangular factor T of a complex block reflector H of order n, which is defined as a product of k elementary reflectors." */
/* OPTIONS */
{
	int maxldd;

	int maxldv;
	scomplex *locv=NULL;
	int descv[DESCLEN];
	int desc_gv[DESCLEN];
	int row_locv, col_locv;

	scomplex *loctau=NULL;

	int maxldt;
	scomplex *loct=NULL;
	int desct[DESCLEN], desc_gt[DESCLEN];
	int row_loct, col_loct;

	scomplex *locwork=NULL;
	int llocwork;

	INITIALIZE();

	SCALAR( "char", direct);
	SCALAR( "char", storev);
	SCALAR( "int", n);
	SCALAR( "int", k);
	SCALAR( "int", ldv);
	SCALAR( "int", ldt);

	if (chrcmp(storev,'c')==0) {
	  MATRIX("scomplex", v, ldv, k );
	  DISTRIBUTE( "scomplex", v, ldv, k );
	} else {
	  MATRIX("scomplex", v, ldv, n);
	  DISTRIBUTE( "scomplex", v, ldv, n);
	}
	MATRIX("scomplex", t, ROW_t, COL_t);

	if (chrcmp(storev,'c')==0) {
	  VECTOR( "c", "scomplex", tau, k);
	  vDISTRIBUTE( "c", "scomplex", tau, k);
	} else {
	  VECTOR( "r", "scomplex", tau, k);
	  vDISTRIBUTE( "r", "scomplex", tau, k);
	}

	llocwork = worklen(k);
	WORK(locwork,llocwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pclarft)( &direct, &storev, &n, &k,
                               locv, &one, &one, descv,
                               loctau,
                               loct,
                               locwork);

	if (chrcmp(storev,'c')==0) 
	  vGATHER( "c", "scomplex", tau, k);
	else
	  vGATHER( "r", "scomplex", tau, k);
	GATHER( "scomplex", t, ROW_t, COL_t);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
	} else {
	}

        FREE(locwork);
}

