#define _WRAPPER_
/* $Id: pzgebd2_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define _DISTRIBUTE_1D_
#define DCOMPLEX
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n
static        int worklen(int m, int n) {
	  int ret=1;
	  int NNB, IROFFA, IAROW, IACOL;
	  int MpA0, NqA0;
#define MYROW myprow
#define NPROW nprow
#define MYCOL mypcol
#define NPCOL npcol
	  ret = max( m, n);
	  if NEED_BUFF {
	    NNB = max(rbloc, cbloc);
	    IROFFA = 0;
	    IAROW = INDXG2P( 1, NNB, MYROW, 0, NPROW );
	    IACOL = INDXG2P( 1, NNB, MYCOL, 0, NPCOL );
	    MpA0 = Cnumroc( m+IROFFA, NNB, MYROW, IAROW, NPROW );
	    NqA0 = Cnumroc( n+IROFFA, NNB, MYCOL, IACOL, NPCOL );

	    ret = max( MpA0, NqA0 );
	  }
	  return ret;
}


void  pzgebd2_ninf(	 int m,
		 int n,
		 dcomplex global_a[],
		 int lda,
		 double global_d[],
		 double global_e[],
		 dcomplex global_tauq[],
		 dcomplex global_taup[],
		 dcomplex work[],
		 int *info
)
/* "pzgebd2 reduces a complex general M-by-N distributed matrix A to upper or lower bidiagonal form B by an unitary transformation: Q' * A * P = B. If M >= N, B is upper bidiagonal; if M < N, B is lower bidiagonal." */
/* OPTIONS */
{
  int min_m_n;
    
	int maxldd;
	int maxlda;
	dcomplex *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
	int row_loca, col_loca;

	double *locd=NULL;
	double *loce;
	int desctdd[DESCLEN],desc_gtdd[DESCLEN];

        dcomplex *loctauq=NULL;
	dcomplex *loctaup=NULL;

	dcomplex *locwork=NULL;
	int llocwork;

	INITIALIZE();

	SCALAR( "int", m);
	SCALAR( "int", n);
	SCALAR("int", lda);
        
	min_m_n = min(m,n);
	SIZE(min_m_n);

	ROW( a);
	COL( a);
	MAXLDD( maxldd, a );
	maxlda = maxldd;

	MATRIX( "dcomplex", a, ROW_a, COL_a);
	DISTRIBUTE( "dcomplex", a, ROW_a  , COL_a);

	tdMATRIX("double", e, d, e, min_m_n);

	VECTOR("c","dcomplex", tauq, min_m_n);
	VECTOR("r", "dcomplex", taup, min_m_n);

	llocwork=worklen(m,n);
	WORK(locwork, llocwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pzgebd2)( &m, &n,
                               loca, &one, &one, desca,
                               locd, loce,
                               loctauq, loctaup,
                               locwork, &llocwork, &linfo);

	GATHER( "dcomplex", a, ROW_a  , COL_a);
	tdGATHER( "dcomplex", e, d, e, min_m_n);
	vGATHER("c","dcomplex", tauq, min_m_n);
	vGATHER("r", "dcomplex", taup, min_m_n);

	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
	  *info = linfo;
	} else {
	}

	FREE_MATRIX(a);
	FREE_MATRIX(d);
	FREE_MATRIX(e);
        
	FREE_VECTOR(taup);
	FREE_VECTOR(tauq);

	FREE(locwork);
}

