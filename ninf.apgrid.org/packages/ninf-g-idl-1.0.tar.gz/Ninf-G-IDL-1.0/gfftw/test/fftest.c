#include <stdio.h>
#include <math.h>
#define N 1234567
#include <string.h>
#include <stdlib.h>
#include <unistd.h>

#include "assert.h"
#include <fftw.h>

#define COUNT 50
#define dcomplex fftw_complex

extern double second();

int main(int argc,char ** argv) {

  dcomplex *in=NULL, *out=NULL, *rout=NULL;
  double resid;
  fftw_plan plan;

  double *dat=NULL;
  int n=N;
  double x;
  int i;

  double time0,timef;

  in = malloc(sizeof(dcomplex)*N); assert(in);
  out = malloc(sizeof(dcomplex)*N); assert(out);
  rout = malloc(sizeof(dcomplex)*N); assert(rout);
  dat = malloc(sizeof(double)*N); assert(dat);

  x=0.2;
  for(i=0;i<N;i++) {
    //            x=4.*x*(1.-x);
    dat[i]=sin((double)i/64);
  }

  for(i=0;i<N;i++) {
    in[i].re = dat[i];
    in[i].im = 1./(dat[i]+0.1);
    out[i].re = 0.;
    out[i].im = 0.;
    rout[i].re = 0.;
    rout[i].im = 0.;
  }

  printf("size=%d\n",n);

  printf("\nMEASURE MODE:\n");
  plan = fftw_create_plan( n, FFTW_FORWARD, FFTW_MEASURE);
  fftw_print_plan(plan);
  time0 = second();
  printf("\ncount= ");
  for(i=0;i<COUNT;i++) {
    fftw_one( plan, in, out);
    if ((i<5)||((i+1)%5==0)) { printf("%d ",i+1); fflush(stdout);}
  }
  timef = second();
  printf("\ntime= %f sec (%dtimes)\n",timef-time0, COUNT);
  fftw_destroy_plan(plan);  


  printf("\n\nESTIMATE MODE:\n");
  plan = fftw_create_plan( n, FFTW_FORWARD, FFTW_ESTIMATE);
  fftw_print_plan(plan);
  time0 = second();
  printf("\ncount= ");
  for(i=0;i<COUNT;i++) {
    fftw_one( plan, in, out);
    if ((i<5)||((i+1)%5==0)) { printf("%d ",i+1); fflush(stdout); }
  }
  timef = second();
  printf("\ntime= %f sec (%dtimes)\n",timef-time0, COUNT);


   printf("\nRESIDUE Check.\n");
   fftw_destroy_plan(plan);
   plan = fftw_create_plan( n, FFTW_BACKWARD, FFTW_ESTIMATE);
   fftw_one( plan, out, rout);

   for(i=0;i<n;i++) {
     rout[i].re /= (double)n;
     rout[i].im /= (double)n;
   }
   printf("\norg inv^2\n");
   for(i=0;i<10;i++) printf("%3.16f %3.16f\n",rout[i].re,in[i].re);
   
   resid = 0.;
   for(i=0;i<n;i++) {
     resid += (rout[i].re-in[i].re)*(rout[i].re-in[i].re) + (rout[i].im-in[i].im)*(rout[i].im-in[i].im);
   }
   resid = sqrt(resid)/(double)n;
   printf("\nresid=%2.18f\n", resid);
   
   free(in);
   free(out);

   return 0;
}

double
second()
{
#include <sys/time.h>

  struct timeval tm;
  double t ;

  static int base_sec = 0,base_usec = 0;

  gettimeofday(&tm, NULL);
  
  if(base_sec == 0 && base_usec == 0)
    {
      base_sec = tm.tv_sec;
      base_usec = tm.tv_usec;
      t = 0.0;
    } else {
      t = (double) (tm.tv_sec-base_sec) + 
	((double) (tm.tv_usec-base_usec))/1.0e6 ;
    }

  return t ;
}
