/**
   ninf_serv_lib.c           
*/
#include <stdio.h>
#include "ninf_macros.h"

static char * arg_port = NINF_SERVER_PORT;
int parse_port_called = FALSE;
int privileged = FALSE;

char * get_arg_port(char * default_port){ 
  if (parse_port_called)
    return arg_port;
  if (default_port != NULL)
    return default_port;
  return NINF_SERVER_PORT;
}


int ninf_server_parse_arg(int argc, char ** argv){
  int i = 0;
  char ** index = argv;
  
  for (; *argv != NULL; argv++){
    if (strcasecmp(*argv, "-port") == 0){
      arg_port= *(++argv);
      parse_port_called = TRUE;
    } else if (strcasecmp(*argv, "-privileged") == 0){
      privileged = TRUE;
    } else if (strcasecmp(*argv, "-version") == 0){
      print_version();
    } else {
      i++;
      *(index++) = *(argv);
    }
  }
  *(index++) = *(argv);
  return i;
}

/********* usage *********/

void usage(){
  fprintf(stderr, "ninf_serv_tcp [-daemon] [-port PORT] [configfile]\n");
  exit(0);
}
