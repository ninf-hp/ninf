//
// Problem.java
//

package ninf.MetaServer;
import ninf.basic.*;
import ninf.client.*;
import ninf.netsolve.*;

import java.util.Vector;
import java.io.IOException;

public class ProblemStruct implements CallableStruct{
  public String server;
  public Problem problem;
  public FunctionManager manager;
  
  public NinfStub stub;

  public ProblemStruct(String server, Problem problem){
    this.server = server;
    this.problem = problem;
    stub = problem.toNinfStub();
    System.out.println(stub);
  }

  public NinfCallable getCallable(){
    return new NetSolveLatch(this);
  }

  public NinfStub getStub(){
    return stub;
  }

  public void addManager(FunctionManager f){
    manager = f;
  }


}
