#define _WRAPPER_
/* $Id: pcdttrf_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define SCOMPLEX
#define _DISTRIBUTE_1D_
#include <gscalapack.h>

#define ROW_af laf
#define COL_af n
#define ROW_af laf
#define COL_af n
static	int worklen() {
	  int ret=1;
	  ret = 8;
	  if NEED_BUFF
		  ret = 8*npcol;
	  return ret;
}

void  pcdttrf_ninf(	 int n,
		 scomplex global_dl[],
		 scomplex global_d[],
		 scomplex global_du[],
		 scomplex af[],
		 int dummy_laf,
		 scomplex work[],
		 int lwork,
		 int *info
)
/* "pcdttrf computes a LU factorization of an N-by-N complex tridiagonal diagonally dominant-like distributed matrix A." */
/* OPTIONS */
{
    extern void FortranCall(pcdttrf)( int*,
                               scomplex*, scomplex*, scomplex*, int*, int*,
                               scomplex*, int*,
                               scomplex*, int*, int*);

	int maxldd;

	scomplex *locdl=NULL, *locd=NULL, *locdu=NULL;
	int desctdd[DESCLEN];
	int desc_gtdd[DESCLEN];

	int maxldaf;
	int laf,llocaf;
	scomplex *locaf=NULL,*global_af=NULL;
	int descaf[DESCLEN];
	int desc_gaf[DESCLEN];
	int row_locaf, col_locaf;
	
	scomplex *locwork=NULL;
	int llocwork;

	INITIALIZE();

	SCALAR( "int", n);
	SCALAR("int", dummy_laf);
	SCALAR( "int", lwork);

	SIZE(n);

	laf = 2*(blocsize+2)*nprocs/n;
	llocaf = laf*blocsize;
	if (mypnum==0) {
	  global_af=MALLOC(sizeof(float)*laf*n);
          assert(global_af);
	}

	ROW(af);
	COL(af);
	MAXLDD(maxldd, af);
	maxldaf=maxldd;

	tdMATRIX( "scomplex", dl, d, du, n);
	tdDISTRIBUTE("scomplex", dl, d, du, n);
	MATRIX("scomplex", af, ROW_af, COL_af);

	llocwork = worklen();
	llocwork = max( lwork, llocwork);
	WORK(locwork,llocwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pcdttrf)( &n,
                               locdl, locd, locdu, &one, desctdd,
                               locaf, &llocaf,
                               locwork, &llocwork, &linfo);

	tdGATHER( "scomplex", dl, d, du, n);
	GATHER( "scomplex", af, ROW_af, COL_af);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
	  int i;
	  *info = linfo;
	  for(i=0;i<min(dummy_laf,laf*n);i++) af[i]=global_af[i];
          FREE(global_af);
	} else {
	}

        FREE_MATRIX(dl);
        FREE_MATRIX(d);
        FREE_MATRIX(du);
        FREE_MATRIX(af);

        FREE(locwork);
}

