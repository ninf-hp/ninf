#define _WRAPPER_
/* $Id: pslawil_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define FLOAT
#include <gscalapack.h>

#define ROW_a lda
#define COL_a m
void  pslawil_ninf(	 int ii,
		 int jj,
		 int m,
		 float a[],
		 int lda,
		 float h44,
		 float h33,
		 float h43,
		 float global_v[]
)
/* "pslawil gets the transform given by H44,H33, & H43H34 into V starting at row M." */
/* OPTIONS */
{
	int maxldd;

	int desca[DESCLEN];

	float locv[3];

	INITIALIZE();

	SCALAR( "int", ii);
	SCALAR( "int", jj);
	SCALAR( "int", m);
	SCALAR("int",lda);
	SCALAR( "float", h44);
	SCALAR( "float", h33);
	SCALAR( "float", h43);

	COMMON_MATRIX("float", a, ROW_a, COL_a);
	Cdescinit( desca, ROW_a, COL_a, ROW_a, COL_a, 0, 0, PARA_CTXT, ROW_a, &linfo);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pslawil)( &ii, &jj, &m, a, desca, &h44, &h33, &h43, locv);

	RETRIEVE("float", locv, 3);

	if( mypnum == 0 ){
	  int i;
	  for(i=0;i<3;i++) global_v[i]=locv[i];
	} else {
	}
        FREE_COMMON(a);
}
