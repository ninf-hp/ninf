#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>


#include "ninf_macros.h"
#include "ninf_read_config.h"
#include "throughput_measure.h"
#include "iphosts.h"

#define CONFIG_MAIN
#include "ninf_config.h"

#define MAX_LINE_LEN 1000
void set_lookup_flag(int i);

char * save_str();
char * xmalloc();


static int getBoolean(char * command, char * str, int init){
  if (str == NULL)
      return init;
  if (strcasecmp(str, "yes") == 0 || strcasecmp(str, "on") == 0||
      strcasecmp(str, "true") == 0)
      return TRUE;
  if (strcasecmp(str, "no") == 0 || strcasecmp(str, "off") == 0||
      strcasecmp(str, "false") == 0)
      return FALSE;
  ninf_log("unrecognized option argument for %s: '%s'\n", 
	   command, str);
  return -1;
}


static add_last_read_stub_item(struct read_stub_item * tmp2)
 {
   struct read_stub_item * tmp = read_stub_item_root;

   if (read_stub_item_root == NULL){
     read_stub_item_root = tmp2;
     return;
   }
   while (tmp->next != NULL)
     tmp = tmp->next;
   tmp->next = tmp2;
 }

 add_last_metaserver_item(struct metaserver_item * tmp2)
 {
   struct metaserver_item * tmp = metaserver_item_root;

   if (metaserver_item_root == NULL){
     metaserver_item_root = tmp2;
     return;
   }
   while (tmp->next != NULL)
     tmp = tmp->next;
   tmp->next = tmp2;
 }

int read_configure_file(char * filename){
   char buffer[MAX_LINE_LEN];
   FILE * fp;
   if ((fp = fopen(filename, "r")) == NULL){
     fprintf(stderr, "Can't read configuration file: %s\n", filename);
     fprintf(stderr, "      Using default configuration ...\n");
     return FALSE;
   }

   while (fgets(buffer, MAX_LINE_LEN - 2, fp) != NULL){
     char * command, * arg;
     if (buffer[0] == '#')
       continue;
     command = strtok(buffer, " \t\n:");
     if (command == NULL)
       continue;
     if (strncmp(command, "port", 5) == 0){
       config_port = save_str(strtok(NULL, " \t\n:"));
       if (atoi(config_port) == 0){
	 ninf_log("argument for 'port' is invalid");
	 return FALSE;
       }
       continue;
     }
     if (strncmp(command, "performance", 12) == 0){
       performance = atoi(strtok(NULL, " \t\n:"));
       continue;
     }
     if (strncmp(command, "linpack_size", 13) == 0){
       linpack_size = atoi(strtok(NULL, " \t\n:"));
       continue;
     }
     if (strncmp(command, "CPUs", 5) == 0){
       CPUs = atoi(strtok(NULL, " \t\n:"));
       continue;
     }
     if (strncmp(command, "MPICPUs", 8) == 0){
       MPI_PROCS = atoi(strtok(NULL, " \t\n:"));
       continue;
     }
     if (strncmp(command, "mpirun", 7) == 0){
       MPIRUN = save_str(strtok(NULL, "#\n"));
       continue;
     }
     if (strncmp(command, "stubs", 6) == 0){
       struct read_stub_item * tmp = (struct read_stub_item *) xmalloc(sizeof(struct read_stub_item));
       arg = save_str(strtok(NULL, " \t\n:"));
       tmp->stub_file_name = arg;
       tmp->next = NULL;
       add_last_read_stub_item(tmp);
       continue;
     }
     if (strncmp(command, "measure", 8) == 0){
       measure_servers = new_measure_server(measure_servers);
       arg = save_str(strtok(NULL, " \t\n:"));
       measure_servers->host = arg;
       arg = save_str(strtok(NULL, " \t\n:"));
       measure_servers->port = arg;
       continue;
     }
     if (strncmp(command, "interval", 9) == 0){
       measure_interval = atoi(strtok(NULL, " \t\n:"));
       continue;
     }
     if (strncmp(command, "throughputSize", 15) == 0){
       measure_size = atoi(strtok(NULL, " \t\n:"));
       continue;
     }
     if (strncmp(command, "metaserver", 11) == 0) {
       struct metaserver_item * tmp =
	 (struct metaserver_item *) xmalloc(sizeof(struct metaserver_item));

       tmp->hostname = save_str(strtok(NULL, " \t\n:"));
       tmp->port = save_str(strtok(NULL, " \t\n:"));

       /*      fprintf(stderr, "hostname = >%s< port = >%s<\n",
	       tmp->hostname, tmp->port); */
       add_last_metaserver_item(tmp);
       continue;
     }
     if (strncmp(command, "myname", 7) == 0) {
       myname = save_str(strtok(NULL, " \t\n:"));
       continue;
     }
     if (strncmp(command, "myhostname", 11) == 0) {
       myname = save_str(strtok(NULL, " \t\n:"));
       continue;
     }
     if (strncmp(command, "lookup", 7) == 0) {
       set_lookup_flag(strcasecmp("on", strtok(NULL, " \t\n:")) == 0);
       continue;
     }
     if (strncmp(command, "log", 4) == 0) {
       logfile = save_str(strtok(NULL, " \t\n:"));
       Ninf_set_log_file(logfile);
       continue;
     }
     if (strncmp(command, "tmpFileRoot", 12) == 0) {
       TMP_FILE_ROOT = save_str(strtok(NULL, " \t\n:"));
       continue;
     }
     if (strncmp(command, "NWSuse", 7) == 0) {
       if ((NWSuse = getBoolean(command, strtok(NULL, " \t\n:"), NWSuse)) < 0)
	 return FALSE;
       continue;
     }
     if (strncmp(command, "NWSinvokeSensor", 16) == 0) {
       if ((NWSinvokeSensor = getBoolean(command, strtok(NULL, " \t\n:"), NWSinvokeSensor)) < 0)
	 return FALSE;
       continue;
     }
     if (strncmp(command, "NWSinvokeForecaster", 20) == 0) {
       if ((NWSinvokeForecaster = getBoolean(command, strtok(NULL, " \t\n:"), 
					     NWSinvokeForecaster)) < 0)
	 return FALSE;
       continue;
     }
     if (strncmp(command, "NWSdir", 7) == 0) {
       NWSdir = save_str(strtok(NULL, " \t\n:"));
       continue;
     }
     if (strncmp(command, "NWSMemoryDir", 13) == 0) {
       NWSMemoryDir = save_str(strtok(NULL, " \t\n:"));
       continue;
     }
     if (strncmp(command, "NWSMemoryLog", 13) == 0) {
       NWSMemoryLog = save_str(strtok(NULL, " \t\n:"));
       continue;
     }
     if (strncmp(command, "NWSMemoryErr", 13) == 0) {
       NWSMemoryErr = save_str(strtok(NULL, " \t\n:"));
       continue;
     }

    /******* HTTPD RELATED ********/
    if (strncmp(command, "httpdStart", 9) == 0){
      if ((httpdStart = getBoolean(command, strtok(NULL, " \t\n:"), 
			    httpdStart)) < 0)
	return FALSE;
      continue;
    }
    if (strncmp(command, "httpdClassName", 15) == 0) {
      httpdClassName = save_str(strtok(NULL, " \t\n:"));
      continue;
    }
    if (strncmp(command, "httpdJarPath", 15) == 0) {
      httpdJarPath = save_str(strtok(NULL, " \t\n:"));
      continue;
    }
    if (strncmp(command, "httpdPort", 10) == 0){
      httpdPort = atoi(strtok(NULL, " \t\n:"));
      continue;
    }
    /******* SERVER RESTRICTION ********/

    if (strncmp(command, "allowHost", 13) == 0){
      char * address, * mask = NULL;

      address = strtok(NULL, " \t\n:");
      mask = strtok(NULL, " \t\n:");
      if (!addIPHostList(address, mask)){
	ninf_log("cannot setup 'allowHost %s %s '", 
		   address == NULL ? "": address,
		   mask == NULL ? "": mask);
	return FALSE;
      }
      continue;
    }

    if (strncmp(command, "allowUnixDomain", 16) == 0) {
      if ((allowUnixDomain = getBoolean(command, strtok(NULL, " \t\n:"), 
					allowUnixDomain)) < 0)
	return FALSE;
      continue;
    }

    /******* Process restriction ********/

    if (strncmp(command, "maxInvocation", 14) == 0){
      char * tmp;
      if ((tmp = strtok(NULL, " \t\n:")) == NULL){
	ninf_log("argument required for 'maxInvocation'");
	return FALSE;
      }
      maxInvocation = atoi(tmp);
      continue;
    }

#ifdef SSL_USE
    /******* SSL RELATED ********/

    if (strncmp(command, "ssl_use", 8) == 0){
      if ((ssl_use = getBoolean(command, strtok(NULL, " \t\n:"), 
				ssl_use)) < 0)
	return FALSE;
      continue;
    }

    if (strncmp(command, "ssl_cert", 9) == 0){
      char * tmp;
      if ((tmp = strtok(NULL, " \t\n:")) == NULL){
	ninf_log("argument required for 'ssl_cert'");
	return FALSE;
      }
      ssl_cert = save_str(tmp);
      continue;
    }
    if (strncmp(command, "ssl_key", 8) == 0){
      char * tmp;
      if ((tmp = strtok(NULL, " \t\n:")) == NULL){
	ninf_log("argument required for 'ssl_key'");
	return FALSE;
      }
      ssl_key = save_str(tmp);
      continue;
    }
    if (strncmp(command, "ssl_ca_cert", 12) == 0){
      char * tmp;
      if ((tmp = strtok(NULL, " \t\n:")) == NULL){
	ninf_log("argument required for 'ssl_ca_cert'");
	return FALSE;
      }
      ssl_ca_cert = save_str(tmp);
      continue;
    }
#endif


    /******* REDIRECT ********/

    if (strncmp(command, "redirect", 9) == 0) {
      if ((redirect_outerr = getBoolean(command, strtok(NULL, " \t\n:"), 
					redirect_outerr)) < 0)
	return FALSE;
      continue;
    }
    fprintf(stderr, "CONFIGERR: unknown command %s\n", command);
    return FALSE;
  }
  return TRUE;
}
