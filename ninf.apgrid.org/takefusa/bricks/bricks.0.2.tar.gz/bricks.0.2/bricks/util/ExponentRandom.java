package bricks.util;
import java.util.Random;

/** 
 * ExponentRandom(double mean, long seed)
 **/
public class ExponentRandom extends Sequence implements SubComponent {
    protected Random random;

    public ExponentRandom(long seed, double mean) {
	random = new Random(seed);
	this.mean = mean;
    }

    public String getName() {
	return "ExponentRandom";
    }

    public double nextDouble(double currentTime) {
	return nextDouble();
    }

    public double nextDouble() {
	return - mean * Math.log(1 - random.nextDouble());
	//return - mean * Math.log(random.nextDouble());
    }

    // for debug
    public static void main(String[] argv) {
	if (argv.length < 3) {
	    System.out.println(
		"Usage: java ExponetRandom [mean] [seed] [num]"
	    );
	    return;
	}
	double mean = Double.valueOf(argv[0]).doubleValue();
	long seed = Long.valueOf(argv[1]).longValue();
	int num = Integer.valueOf(argv[2]).intValue();

	ExponentRandom e = new ExponentRandom(seed, mean);
	for (int i = 0 ; i < num ; i++) {
	    System.out.println(e.nextDouble());
	}
    }
}
