package bricks.util;

public class SerialNumberStrings extends Strings implements SubComponent {

    protected int number;

    public SerialNumberStrings(int firstNumber) {
	this.number = firstNumber - 1;
    }

    public String getName() {
	return "SerialNumberStrings";
    }

    public String nextString() {
	number++;
	return Integer.toString(number);
    }
}
