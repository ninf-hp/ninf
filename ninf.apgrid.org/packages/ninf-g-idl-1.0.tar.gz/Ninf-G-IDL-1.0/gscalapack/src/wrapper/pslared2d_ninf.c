#define _WRAPPER_
/* $Id: pslared2d_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define FLOAT
#include <gscalapack.h>
/* ?? */

static	int worklen(int n) {
	  int ret=1;
	  ret = n;
	  if NEED_BUFF {
	    ret= NUMROC(N, NB , 0, 0, NPCOL);
	  }
	  return ret;
}


void  pslared2d_ninf(	 int n,
		 float global_byrow[],
		 float byall[],
		 float work[],
		 int lwork
)
/* "pslared2d redistributes a 1D array. It assumes that the input array, BYROW, is distributed across columns and that all process rows contain the same copy of  BYROW." */
/* OPTIONS */
{
	int maxldd;

	int desc[DESCLEN];
	int desc_g[DESCLEN];

	float *locbyrow=NULL;

	float *locwork=NULL;
	int llocwork;


	INITIALIZE();

	SCALAR( "int", n);
	if (mypnum!=0) {
            byall = MALLOC(sizeof(float)*n);
            assert(byall);
        }
        

	VECTOR("c","float", byrow, n);
	vDISTRIBUTE("c","float", byrow, n);
	Cdescinit(desc, 1, n, 1, cbloc, 0, 0,PARA_CTXT, 1, &linfo);

	llocwork=worklen(n);
	WORK(locwork,llocwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pslared2d)( &n, &one, &one, desc, locbyrow, byall, locwork, &llocwork);

	RETRIEVE("float", byall, n);

	if( mypnum == 0 ){
	} else {
            FREE(byall);
	}
        FREE(locwork);
	
}

