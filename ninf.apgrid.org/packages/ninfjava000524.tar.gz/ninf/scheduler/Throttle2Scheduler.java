package ninf.scheduler;
import ninf.metaserver.*;

public class Throttle2Scheduler extends ThrottleScheduler {
  static int THRESHOLD = 2;
}
