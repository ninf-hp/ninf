package ninf.cproxy;
import ninf.basic.*;
import ninf.common.*;
import ninf.client.*;
import java.util.Vector;
import java.util.Hashtable;
import java.io.IOException;
import java.net.*;

abstract public class ServerTablePingerRoot implements Runnable{
  static CommandParser newserversParser = new CommandParser(new CommandRepresent("newServers", 2));
  static CommandParser serverInfoParser = new CommandParser(new CommandRepresent("serverInfo", 2));

  public int interval;               /* interval in second */
  public MetaServerReference target;
  public MetaServerConnection con;
  public static NinfLog dbg = new NinfLog("ServerTablePinger");
  public long time = 0;

  public ServerTablePingerRoot(MetaServerReference target, int interval){
    this.target = target;
    this.interval = interval;
  }

  void receiveReply(MetaServerConnection con) throws NinfException {
    NinfCommand com = newserversParser.readCommand(con.is);
    int count = new Integer(com.args[0]).intValue();
    time = new Long(com.args[1]).longValue();
    for (int i = 0; i < count; i++){
      com = serverInfoParser.readCommand(con.is);
      NinfServerStruct serverStruct = new NinfServerStruct(com.args[0], com.args[1]);
      addNewServer(serverStruct);
    }
  }

  public abstract void addNewServer(NinfServerStruct serverStruct);

  void sendRequest(MetaServerConnection con) throws NinfException {
    new NinfCommand("getNewServers", ""+ time).send(con.os);
  }

  void ping(){
    try {
      con = target.connect();
      sendRequest(con);
      receiveReply(con);
      con.close();
    } catch (NinfException e){
      System.err.println(e);
    }
  }

  public void start(){
    new Thread(this).start();
  }

  public void run(){
    while (true){
      ping();
      try {
	Thread.sleep(interval * 1000);
      } catch (InterruptedException e){
      }
    }
  }
}
