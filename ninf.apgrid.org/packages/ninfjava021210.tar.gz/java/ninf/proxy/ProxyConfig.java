package ninf.proxy;
import ninf.basic.*;
import java.net.*;
import java.util.Vector;
import java.util.Hashtable;
import java.io.IOException;

class ProxyConfig extends Configure{
  static final int DEFAULT_PORT = 3001;

  static CommandRepresent initAcceptedCommands[] = {
    new CommandRepresent("metaserver", 2), 
    new CommandRepresent("server",     2),
    new CommandRepresent("server",     3), 
    new CommandRepresent("myhostname", 1),
    new CommandRepresent("log",        1), 
    new CommandRepresent("lookup",     1), 
    new CommandRepresent("port",       1),
    new CommandRepresent("allowHost",  1),
    new CommandRepresent("allowHost",  2)};

  static CommandRepresent initAcceptedOptions[] = {
    new CommandRepresent("-port",      1), 
    new CommandRepresent("-debug",     0),
    new CommandRepresent("-quiet",     0),
    new CommandRepresent("-version",   0)};
    
  MetaServerReference metaServer;

  boolean    allowAll = true;
  IPHostList allowedHosts = new IPHostList();

  ProxyConfig(String args[]) throws NinfException{
    super(args, initAcceptedCommands, initAcceptedOptions);
  }

  public void configure() throws NinfException{
    port = DEFAULT_PORT;
    super.configure();
    configureMetaServer();
    configureAllowHost();
  }

  void configureAllowHost() throws NinfException{
    allowedHosts.addHost("localhost", null);
    Vector v = getContent("allowHost");
    if (v == null)
	return;
    allowAll = false;
    for (int i = 0; i < v.size(); i++){
      String strs[] = (String [])v.elementAt(i);
      if (strs.length == 2)
	  allowedHosts.addHost(strs[0], strs[1]);
      else if (strs.length == 1)
	  allowedHosts.addHost(strs[0], null);      
    }
  }

  void configureMetaServer(){
    String strs[] = getOneContent("metaserver");
    if (strs == null || strs.length == 0)
      return;
    metaServer = new MetaServerReference(strs[0], (new Integer(strs[1]).intValue()));
  }

}
