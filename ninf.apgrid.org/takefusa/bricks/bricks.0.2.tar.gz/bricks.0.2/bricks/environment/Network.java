package bricks.environment;
import bricks.util.*;
import java.io.*;
import java.util.*;

/** 
 * Network.java
 * <pre>
 * Network represents the (wide-area) network interconnecting 
 * a client and a server, and is parameterized by e.g., bandwidth, 
 * congestion, and their variance over time.
 * </pre>
 */
public class Network extends NodeWithQueue {

    /** The size of extraneous arribal data invoked from other nodes. */
    protected Sequence dataSize;

    protected Packets probePackets;
    protected static final int PROBE = 3;

    /**
     * Constructs a Network with
     *     owner : a SimulationSet of your configuration,
     *     key : a key of the Network,
     *     queue : a queue which represents bandwidth, congestion, and
     *             their variance of the Network,
     *     dataSize : dataSize of the Network,
     *     interarrivalTime : The interval that the Network invokes 
     *                        extraneous data.
     */
    public Network(
	SimulationSet owner, String key, Queue queue, 
	Sequence dataSize, Sequence interarrivalTime
    ) {
	this.owner = owner;
	this.key = key;
	this.queue = queue;
	queue.owner = this;
	this.dataSize = dataSize;
	this.interarrivalTime = interarrivalTime;
	this.logWriter = owner.networkLogWriter;
	nextLink = new Vector();
	probePackets = new Packets(this, (owner.logicalPacket).packetSize);
	init();
   }

/************************* needed method *************************/
    /** 
     * returns a type of the Network.
     */
    public String getName() {
	return "Network";
    }

    /** 
     * initializes the Network, 
     * if it uses InterpolationInterarrivalTime.
     */
    public void init() {
	super.init();
	if (interarrivalTime instanceof InterpolationInterarrivalTime) {
	    ((InterpolationInterarrivalTime)interarrivalTime).init(
		queue.maxThroughput, dataSize.mean
	    );
	}
    }

    public String toInitString() {
	String str = "  [" + getName() + " " + key + "] : ";
	str += queue.getName() + ", " + dataSize.mean + ", " + 
	    interarrivalTime.mean + "\n";
	str += queue.toOriginalString();
	return str;
    }

    /** 
     * processEvent
     *     QUEUE : processes queue event.
     *     OTHERSDATA : puts extraneous data into queue of the Network.
     *     PROBE : puts a packet to probe the Network.
     */
    public void processEvent(double currentTime) {
	if (event == QUEUE) {
	    //System.out.println(currentTime + " : " + this + ": QUEUE");
	    if (queue.processEvent(currentTime))
		outQueueLength(currentTime, queue.size());
	} else if (event == OTHERSDATA) { 
	    if (!queue.isFull()) {
		schedule(currentTime, nextData);
	    }
	    nextData = getNextData(currentTime);
	} else { // PROBE
	    //SimulationDebug.println(
	    //"##Network: " + Format.format(currentTime, precision)+ " : PROBE"
	    //);
	    probePackets.sendFirstPacket(currentTime);
	    updateNextEvent(currentTime);
	}
    }

    /** 
     * updates the event.
     */
    public void updateNextEvent(double currentTime) {
	event = OTHERSDATA;
	double earliestTime = nextData.timeEventComes;
	if (!queue.isEmpty()) {
	    if (queue.getTimeQueueEventComes() < earliestTime) {
		earliestTime = queue.getTimeQueueEventComes();
		event = QUEUE;
	    }
	}
	if (!probePackets.isEmpty()) {
	    TrafficData td = probePackets.firstPacket();
	    if (td.timeEventComes < earliestTime) {
		earliestTime = td.timeEventComes;
		event = PROBE;
		SimulationDebug.println(
		    "Network(" + this + "): nextEvent = PROBE (" +
		    Format.format(earliestTime, precision)
		);
	    }
	}
	nextEventTime = earliestTime;
    }

    public double getThroughputAt(double currentTime) {
	return queue.getThroughputAt(currentTime);
    }

    protected Data getNextData(double currentTime) {
	if (this.interarrivalTime != null) {
	    double timeEventComes = 
		currentTime + interarrivalTime.nextDouble(currentTime);
	    return new OthersData(
		this, timeEventComes, dataSize.nextDouble(currentTime)
	    );
	} else {
	    return new OthersData(this, Double.POSITIVE_INFINITY, 0);
	}
    }

    /** 
     * handles to probe.
     * caller: NodePair
     */
    public void probe(double currentTime, ProbeData pd) {
	SimulationDebug.println("Network(" + currentTime + "): probe - divideTrafficData");
	probePackets.divideTrafficData(currentTime, pd);

	SimulationDebug.println("Network(" + currentTime + "): probe - sendFirstPacket");
	if (probePackets.canOnePacketSend())
	    probePackets.sendFirstPacket(currentTime);
    }

    public void putInterarrivalTimeOfPackets(Sequence ng, Node toNode) {
	probePackets.putInterarrivalTimeOfPackets(ng, toNode);
    }
}
