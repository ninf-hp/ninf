package ninf.basic;

public interface Informable{
  public void inform();
}
