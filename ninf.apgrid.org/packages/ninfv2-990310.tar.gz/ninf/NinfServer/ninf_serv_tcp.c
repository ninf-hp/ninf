/* 
 * ninf_server of TCP/IP version.
 */

#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>
#include <sys/resource.h>
#include <sys/ioctl.h>
#include <signal.h>
#include <sys/wait.h>
#include <errno.h>
#include <string.h>
#include <sys/stat.h>
#include <fcntl.h>

#define ERROR_MAIN

#include "ninf_stub_info.h"
#include "ninf_serv_reg.h"
#include "dump_time.h"
#include "ninf_read_config.h"
#include "ninf_data_trans.h"
#include "ninf_error.h"
#include "metaserver.h"
#include "ninf_server_state.h"
#include "throughput_measure.h"
#include "ninf_config.h"

void unlink_all();

static char local_filename[100];

#define DEFAULT_LOGFILE "/tmp/ninflog"
static char HOSTNAMEBUF[100];
static char PORTBUF[100];
static char FILEROOTBUF[100];
static char * NINFDEBUGBUF = "NINF_DEBUG=TRUE";
static char * NINFFORKBUF = "NINF_FORK_GDB=TRUE";

char * ninf_server_service = NULL;


extern int ninf_debug_flag;
int ninf_stub_debug = FALSE;
int ninf_fork_gdb = FALSE;
extern int privileged;
int noinetd = FALSE; /* command line flag to disable inetd mode: default FALSE */


#define max(x,y)	((x)>(y) ? (x) : (y))
#define max4(x,y,z,w)   (max(max(x,y),max(z,w)))
extern int errno;


int mem_size = -1;   /* memory size in Kbytes */
int get_memsize();

#define MAX_LISTEN	3

extern char * save_str(char *);

int reg_sock;
char * program_context = "NINF_SERVER";
int call_serial = 0;


void reapchild();
void hookint();
void ignore();
char * read_configure_file();

int inetd_flag = FALSE;

void server_finalizer(){
    unlink_all();
}

void introduce_myself_to_metaserver()
{
  struct metaserver_item * p = metaserver_item_root;
  char* HostName;
  int myportno;
  dataTrans *sDT;
  int setup_ninf_socket(int s); /* ninf_call_remote.c */
  metaConnection  * meta;

  if (ninf_server_service == NULL){
    ninf_log("couldn't introduce to metaserver: can't specify port");
  }
  myportno = atoi(ninf_server_service);
  if (myname != NULL)
    HostName = myname;
  else 
    HostName = getenv("HOST");
  myname = HostName;
  if (HostName == NULL){
    ninf_log("couldn't introduce to metaserver: can't specify my hostname");
    return;
  }

  /** inform stub via environment variable */
  sprintf(HOSTNAMEBUF, "MYHOSTNAME=%s", HostName);
  putenv(HOSTNAMEBUF);
  sprintf(PORTBUF, "MYPORT=%d",myportno);
  putenv(PORTBUF);
  sprintf(FILEROOTBUF, "TMP_FILE_ROOT=%s", TMP_FILE_ROOT);
  putenv(FILEROOTBUF);
  if (ninf_stub_debug)
    putenv(NINFDEBUGBUF);
  if (ninf_fork_gdb)
    putenv(NINFFORKBUF);

  if (p == NULL){
    ninf_log("couldn't introduce to metaserver: metaserver is not specified in the configfile");
    return;
  }
  if  ((meta = metaserver_connect(p->hostname, p->port)) == NULL){
    ninf_log("couldn't introduce to metaserver: can't connect to metaserver: %s, %s",
	     p->hostname, p->port);
    return;
  }
  metaserver_send(meta, "register %s %d", HostName, myportno);
  metaserver_flush(meta);
  metaserver_close(meta);


}


#if 0   
void send_new_stub_info_to_metaserver(stub_entry_name)
     char* stub_entry_name;
{
  struct metaserver_item * p = metaserver_item_root;
  dataTrans *sDT;
  int s;
  int myportno;
  char * HostName;

  if (p == NULL) {
/*    fprintf(stderr, "Warning: you must specify MetaServer in config.\n"); */
    return;
  }
  if (ninf_server_service == NULL){
    ninf_error("couldn't send new stub to metaserver\n");
    return;
  }
  myportno = atoi(ninf_server_service);
  HostName =getenv("HOST");
  if (HostName == NULL){
    ninf_error("couldn't send new stub to metaserver\n");
    return;
  }
  if (p == NULL){
    ninf_error("couldn't send new stub to metaserver\n");
    return;
  }
  if ((s = ninf_connect_remote(p->hostname, p->port)) < 0){
    ninf_error("couldn't send new stub to metaserver\n");
    return;
  }
  sDT = new_dataTrans(s, XDR_ENCODE, TRUE);  
  trans_string(sDT, &stub_entry_name, MAX_NAME_LEN);
  trans_string(sDT, &HostName, MAX_NAME_LEN);
  trans_int(sDT, &myportno);
  trans_flush(sDT, NINF_PKT_NEW_STUB, myportno, 0);
  shutdown(s, 2);
  close(s);
}
#endif

become_daemon(){
  int i;
  int fd;
  int tablesize;

#if defined(__j90__) || defined(_AIX) || defined(hppa) || defined(HIUX)
  tablesize = getdtablesize();
#elif defined (_NO_RLIMIT_)
  tablesize = 10; /* just a hack for cygnus */
#else
  {
    struct rlimit rl;
    getrlimit(RLIMIT_NOFILE, &rl);
    tablesize = rl.rlim_cur;
  }
#endif 
  for (i = tablesize-1; i >=2; i--)
    close(i);
  freopen("/dev/null", "r", stdin);
  freopen("/dev/null", "w", stdout);
  freopen("/dev/null", "w", stderr);

    
/*    if (close(i) >= 0)
      fprintf(stderr, "%d\n", i);  */

  
  if ((i = fork()) < 0)
    ninf_fatal("Can not become daemon.");
  if (i != 0)
    exit(0);
  setsid();
/*  fd = open("/dev/tty", O_RDWR);
  ioctl(fd, TIOCNOTTY, 0); 
  close(fd);*/
}

void usage(){
  fprintf(stderr, "ninf_serv_tcp [-daemon] [-port PORT] [configfile]\n");
  exit(0);
}
  
char * get_arg_port(char *);

int initialize(argc, argv)
     int argc;
     char *argv[];
{
  int s, size;
  struct sockaddr_in myaddr;
  char *service = NULL;
  char *stubstr;
  char * arg;
  int ac;
  int daemon_flag = FALSE;

  ninf_debug_flag = FALSE;

  argc = Ninf_parse_arg(argc, argv);

  for (ac = 1; ac < argc; ac++){
    arg = argv[ac];
    if (strncmp(arg, "-daemon", 8) == 0){
      daemon_flag = TRUE;
    } else if (strncmp(arg, "-debug", 7) == 0){
      ninf_debug_flag = TRUE;
    } else if (strncmp(arg, "-stubdebug", 12) == 0){
      ninf_stub_debug = TRUE;
    } else if (strncmp(arg, "-forkgdb", 10) == 0){
      ninf_fork_gdb = TRUE;
    } else if (strncmp(arg, "-h", 3) == 0){
      usage();
      break;
    } else if (strcasecmp(arg, "-noinetd") == 0){
      noinetd  = TRUE;
    } else{
      service = read_configure_file(arg);
    }
  }
  inetd_flag = isSocket(0) && !noinetd;

  {
    FILE * fp;
    if (logfile != NULL){
      /*      fprintf(stderr, "logfile = %s\n", logfile); */
      if ((fp = fopen(logfile, "a")) != NULL)
	Ninf_set_log_fp(fp);
      else
	fprintf(stderr, "Can't open logfile %s\n", logfile);
    }
  }
  service = get_arg_port((service != NULL)? service: getenv("NINF_SERVER_PORT"));
  ninf_server_service = save_str(service);

  if (inetd_flag){  /*  for inetd  */
    s = 0;
    dup2(fileno(logfp),2); 
  } else {
    if (daemon_flag)
      become_daemon();
    
    DUMP_TIME_GETENV();
    myaddr.sin_port = atoi(service);
    myaddr.sin_port = htons(myaddr.sin_port);
    
    myaddr.sin_family = AF_INET;
    myaddr.sin_addr.s_addr = INADDR_ANY;
    size = sizeof(myaddr);
    s = socket(PF_INET,SOCK_STREAM,0);
    if (s < 0){
      perror("socket");
      exit(1);
    }
    if (bind(s,(struct sockaddr *)&myaddr,size) < 0){
      perror("bind");
      exit(1);
    }
  }

  reg_sock = setup_ninf_register(); 

  if ((stubstr = getenv("NINF_STUBS")) != NULL)
    setup_ninf_by_stubstr(stubstr);
  setup_ninf_by_read_stub();
  
  ninf_log("measuring performance ...");

  performance = measure_performance(linpack_size, 1); /* measure performance by linpack sized 300 */
  ninf_log("measured: %d kflops", performance);

  mem_size = get_memsize();
  ninf_log("mem_size: %d Kbytes", mem_size);

  signal(SIGCHLD,reapchild);
  signal(SIGINT, hookint);
  signal(SIGPIPE, ignore); 

  putenv("LANG=C");
  introduce_myself_to_metaserver();

  return s;
}


void start_throughput_measurement();

main(argc,argv)
     int argc;
     char *argv[];
{
  int s;
  fd_set rfds;
  int nfd, max_nfd;
  struct sockaddr_in client_addr;
  int ns;
  
  s = initialize(argc, argv);
  finalizer = server_finalizer;
  start_throughput_measurement();

  /*    ninf_log("server[%d]: listening ...", getpid()); */
  if ((errno = listen(s, MAX_LISTEN)) < 0){
    perror("listen failed");
    ninf_log("master listen failed: socket %d, Aborting", s);
    exit(2);
  }

  ninf_log("server[%d]: Ninf Server Start Up ...", getpid());
  for (;;){	/* server master loop */
    FD_ZERO(&rfds);
    FD_SET(s,&rfds);
    if (!inetd_flag) 
      FD_SET(reg_sock,&rfds); /* inetd mode */
    max_nfd = max(s,reg_sock);
    nfd = select(max_nfd+1,&rfds,NULL,NULL,NULL);
    if (nfd <= 0){
      if (errno != EINTR){
	perror("select");
	ninf_log("master select failed");
      }
	continue;
    }
    if (FD_ISSET(s,&rfds)){
      int size = sizeof(client_addr);
      ns = accept(s,(struct sockaddr *)&client_addr,&size);
      if (ns < 0){
	perror("accept client");
	ninf_log("master accept failed: socket %d", s);
	break;
      }
#ifdef NO_FORK_SESSION
      {
	server_state * state = new_server_state(ns, TRUE);
	ninf_serv_session(state);
      }
#else
      if (fork() == 0){
	server_state * state = new_server_state(ns, TRUE);
	/* child */
	close(s);
	clear_unlink(); /* clear unlink list */
	ninf_serv_session(state);
	exit(0);
      }
      else close(ns);	/* parent */
#endif
      call_serial++;
    }
    if (FD_ISSET(reg_sock,&rfds) && !inetd_flag){
      if (!register_from_socket(reg_sock))
	ninf_log("some error occured for register socket");
    }
  }
  ninf_log("server[%d]: Stopped by Ninf Server Protocol:", getpid());
  unlink_all();
  exit(0);    
}

void reapchild(int sig)
{
    int pid;
    int status;
    for (;;)
      {
/*	  pid = wait3(&status,WNOHANG,(struct rusage *)NULL); */
	  pid = waitpid(0, &status,  WNOHANG);
	  if (pid <= 0) break;	/* if no child, break */
      }

#ifdef __svr4__    
  signal(SIGCHLD,reapchild);
#endif /* __svr4__ */
}


void ignore(int sig)
{
#ifdef __svr4__    
  signal(SIGPIPE, ignore);
#endif /* __svr4__ */
}

void hookint()
{
  ninf_log("server[%d]: Interruptted by Console User", getpid());
  unlink_all();
  exit(3);
}


/* 
 * ninf_server loop for one sesssion 
 */

#define UNIX_SOCK_NAME_FMT 	"/tmp/ninf.%d"



char * getpeer(int ns);
int isSocket(int s);
int dying = FALSE;

#define TIMEOUTSEC 0
#define TIMEOUTMUSEC 0
ninf_serv_session(server_state * state)
{
  int mypid,max_nfd,n;
  int fd = connection_get_fd(state->client);
  struct timeval timeoutval;
  
  timeoutval.tv_sec = TIMEOUTSEC;
  timeoutval.tv_usec = TIMEOUTMUSEC;
  
  DUMP_TIME_OPEN();
  if (ninf_debug_flag) printf("session start ...\n");
  
  ninf_log("forked[%d]: parent[%d]: From %s : %d", getpid(), 
	   getppid(), getpeer(fd), getpeerport(fd));
  
  /* reset SIGCHILD. */
  signal(SIGCHLD,SIG_DFL);
  
  /* make server to stub socket */
  if (privileged)
    if (!authenticate_rcmd(state))
      goto end;
  
  for (;;){
    ninf_fd_set rfds;
    int max_nfd;
    fd_set_zero(&rfds);
    fd_set_set_connection(&rfds, state->client);
    fd_set_set_connection(&rfds, state->stub);
    fd_set_set_connection(&rfds, state->stub_out);
    fd_set_set_connection(&rfds, state->stub_err);
    
    max_nfd = fd_set_max(&rfds);
    /* if stub is active, add stub socket */
    if (!dying)
      n = select(max_nfd+1,&(rfds.fds),NULL,NULL,NULL);
    else
      n = select(max_nfd+1,&(rfds.fds),NULL,NULL,&timeoutval);
    if (n < 0){	/* some error*/
      if (errno != EINTR){
	perror("select");
	ninf_log("select failed");
      }
      continue;
    }
    if (ninf_debug_flag)
      ninf_error("select: %d, stub_stdout = %d,stub_stderr = %d \n", n,
		 connection_get_fd(state->stub_out), 
		 connection_get_fd(state->stub_err));
    if (n == 0){
      if (ninf_debug_flag)
	ninf_error("TIMEOUT \n");
      break;
    }
    
    if (fd_set_is_set_connection(&rfds, state->stub_out))
      state_forward_stub_out(state);
    
    if (fd_set_is_set_connection(&rfds, state->stub_err))
      state_forward_stub_err(state);
    
    if (fd_set_is_set_connection(&rfds, state->client))
      if (!state_exec_server(state)){
	break;
      }

    if (fd_set_is_set_connection(&rfds, state->stub))
      if (!state_forward_stub(state))
	break;

    if (ninf_debug_flag)
      ninf_error("LOOPEND \n");
    
  }
  ninf_serv_to_client(state, NINF_PKT_RPY_KILL,0,0);
  
 end:

    DUMP_TIME_CLOSE();
    if (ninf_debug_flag) printf("session end\n");
    ninf_log("server[%d]: session end", getpid());
    /* exit(0); */
}

int state_forward_stub(server_state * state){
  if (ninf_debug_flag)
    ninf_error("FROM STUB\n");
  if (!forward_packet_from_stub(state->client->sDT, 
				state->stub->rDT, NINF_PKT_TO_CLIENT)){
    ninf_log("server:[%d] Read From Stub Error. Stub died\n", getpid());
    ninf_serv_to_client(state, NINF_PKT_ERROR, NINF_ERROR_STUBREADFAIL, 0);
    ninf_disconnect(state->stub);
    state->stub = NULL;
    return FALSE;
  }
  return TRUE;
}
int state_exec_server(server_state * state){
  if (ninf_debug_flag)
    ninf_error("FROM CLIENT\n");
  
  /* input one complete packet from client. */
  if (!read_onemore(state->client->rDT)){
    /* ninf_error("read from client failed\n");  */
    if (state->stub != NULL) {
      force_kill_stub_program(state);
      state->stub = NULL;
    }
    return FALSE;
  }
  exec_packet_req(state);
  return TRUE;
}

int state_forward_stub_err(server_state * state){
  if (ninf_debug_flag)
    ninf_error("STDERR \n");
  if (!forward_packet_from_stub(state->client->sDT, 
				state->stub_err->rDT, 
				NINF_PKT_STDERR)){
    state->stub_err = NULL;
    return FALSE;
  }
  return TRUE;
}

int state_forward_stub_out(server_state * state){
  if (ninf_debug_flag)
    ninf_error("STDOUT \n");
  if (!forward_packet_from_stub(state->client->sDT, 
				state->stub_out->rDT, 
				NINF_PKT_STDOUT)){
    state->stub_out = NULL;
    return FALSE;
  }
  return TRUE;
}

ninf_serv_to_client(server_state * state, int code, int arg1, int arg2)
{
    if (ninf_debug_flag)
      printf("ninf_serv_to_client(code=%d,size=%d,arg1=%d,arg2=%d)\n",
	     code,trans_count(state->client->sDT),arg1,arg2);
    trans_flush(state->client->sDT, code, arg1, arg2);
}

#ifdef linux
#define READ_FAIL 0
#else
#define READ_FAIL 0
#endif  

int forward_packet_from_stub(dataTrans * sDT, dataTrans *stubDT, int pkt_flag)
{
  int n;
  /* make packet and forward to client. */
  if (!read_onemore(stubDT)){
    return FALSE;
  }
/*  n = read(stub_sock,ninf_pkt_buf+NINF_PKT_HEADER_SIZE,
    MAX_PKT_LEN-NINF_PKT_HEADER_SIZE);
*/
  n = trans_count(stubDT);
  if (ninf_debug_flag) printf("from stub, n = %d\n",n);

  if (n <= READ_FAIL){
    if (errno != EINTR){
      if (ninf_debug_flag) {
	perror("read");
      }
    }
    return FALSE;
  }

  force_write_with(stubDT, sDT->fd, pkt_flag,0,0);
  return TRUE;
}

#if 0
#include <stdarg.h>
ninf_serv_error(va_alist)
     va_dcl
{
    va_list args;
    char *fmt;

    va_start(args);
    fprintf(stderr,"Ninf Server Error:");
    fmt = va_arg(args,char *);
    vfprintf(stderr, fmt, args);
    va_end(args);
    fprintf(stderr, "\n" );
    fflush(stderr);
    exit(1);
}
#endif

/***************** get memory size ******************/

int get_memsize(){
#ifdef __j90__
  return sysconf(_SC_CRAY_USRMEM)/1024 * 8;
#elif defined(_SC_PHYS_PAGES) &&  defined(_SC_PAGESIZE)
  return sysconf(_SC_PHYS_PAGES) * (sysconf(_SC_PAGESIZE)/1024) ;
#else 
  return -1;
#endif

}
