#define _WRAPPER_
/* $Id: pslaed1_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define FLOAT
#include <gscalapack.h>

#define ROW_q ldq
#define COL_q n
#define N n
#define NPCOL npcol
#define NUMROC Cnumroc
#define MYROW myprow
#define MYCOL mypcol
#define IQROW 0
#define IQCOL 0
#define MB rbloc
#define NB cbloc
static	int worklen(int n) {
	  int ret=1;
	  int NP, NQ;
	  ret = 6*n + 2*n+n;
	  if NEED_BUFF {
	    NP = NUMROC( N,  MB, MYROW, IQROW, NPROW );
	    NQ = NUMROC( N,  NB, MYCOL, IQCOL, NPCOL );
	    ret =  6*N + 2*NP*NQ;
	  }
	  return ret;
}

static	int iworklen(int n) {
	  int ret=1;
	  ret = 7*n + 8+2;
	  if NEED_BUFF {
	    ret =  7*N + 8*NPCOL + 2;
	  }
	  return ret;
}


void  pslaed1_ninf(	 int n,
		 int n1,
		 float d[],
		 float global_q[],
		 int ldq,
		 int dummy[],
		 float rho,
		 float work[],
		 int iwork[],
		 int *info
)
/* "pslaed1 computes the updated eigensystem of a diagonal matrix after modification by a rank-one symmetric matrix, in parallel." */
/* OPTIONS */
{
	int maxldd;

	int maxldq;
	float *locq=NULL;
	int descq[DESCLEN];
	int desc_gq[DESCLEN];
	int row_locq, col_locq;

	float *locwork=NULL;
	int llocwork;
	int *lociwork=NULL;
	int llociwork;

	INITIALIZE();

	SCALAR( "int", n);
	SCALAR( "int", n1);
	SCALAR("int", ldq);
	SCALAR( "float", rho);

	COMMON("float", d, n);

	ROW( q);
	COL( q);
	MAXLDD(maxldd, q);
	maxldq = maxldd;

	MATRIX( "float", q, ROW_q, COL_q);
	DISTRIBUTE("float", q, ROW_q, COL_q);
	
	llocwork = worklen(n);
	WORK(locwork, llocwork);
	llociwork = iworklen(n);
	WORK(lociwork, llociwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pslaed1)( &n, &n1, d, &one,
			       locq, &one, &one, descq,
			       &rho,
			       locwork, lociwork,
			       &linfo);

	RETRIEVE("float", d, n);
	GATHER( "float", q, ROW_q  , COL_q);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
	  *info = linfo;
	} else {
	}
	FREE_COMMON(d);
	FREE_MATRIX(q);
        FREE(locwork);
        FREE(lociwork);
}

