#include <stdio.h>
#include <sys/types.h>
#include <time.h>

#include "ninf_macros.h"
#include "process_manage.h"
#include "ninf_config.h"
#define MAX_PROC_NUMBER 1024

static int process_count;

typedef struct running_process{
  int  p_id;
  char client_host_identity[NINF_MAX_NAME_LEN];
  char client_user_identity[NINF_MAX_NAME_LEN];
  time_t time;  
} running_process;


static running_process processes[MAX_PROC_NUMBER];

static void processes_init(){
  int i;
  /* initialize */
  for (i = 0; i < MAX_PROC_NUMBER; i++)
    processes[i].p_id = 0;
}

static BOOLEAN processes_add(int p_id, char *client_host_identity,
			             char *client_user_identity){
  int i, j;
  for (i = 0; i < MAX_PROC_NUMBER; i++)
    if (processes[i].p_id == 0)
      break;
  if (i == MAX_PROC_NUMBER) /* run out of list */
    return FALSE;
  processes[i].p_id = p_id;
  strncpy(processes[i].client_host_identity,client_host_identity,NINF_MAX_NAME_LEN-1);
  strncpy(processes[i].client_user_identity,client_user_identity,NINF_MAX_NAME_LEN-1);
  processes[i].time = time(NULL);
  return TRUE;
}

/* return TRUE if the p_id included */
static BOOLEAN processes_remove(int p_id){
  int i;
  for (i = 0; i < MAX_PROC_NUMBER; i++)
    if (processes[i].p_id == p_id){
      processes[i].p_id = 0;
      return TRUE;
    }
  return FALSE;
}  

/* return process which has the p_id*/
static running_process * processes_find(int p_id){
  int i;
  for (i = 0; i < MAX_PROC_NUMBER; i++)
    if (processes[i].p_id == p_id)
      return &(processes[i]);
  return NULL;
}

/********* PUBLIC FUNCTIONS ***********/
void process_manager_init(){
  process_count = 0;
  processes_init();
  ninf_log("Allowed invocation: %d", maxInvocation);
}

void process_manager_forked(int p_id, char *client_host_identity,
			    char *client_user_identity){
  processes_add(p_id, client_host_identity, client_user_identity);
  if (ninf_debug_flag) 
    ninf_log("%d processes: %d forked", process_count, p_id);

  ninf_log("forked[%d]: parent[%d]: From %s : %s", p_id, 
	   getpid(), client_host_identity, client_user_identity);
}

void process_manager_died(int p_id){
  running_process * tmp = processes_find(p_id);
  char buffer[100];

  if (processes_remove(p_id)){
    process_count--;
    if (ninf_debug_flag){ 
      ninf_log("%d processes: %d died (from %s, by %s)", process_count, p_id, 
	       tmp->client_host_identity, tmp->client_user_identity);
    } 
  }
}

BOOLEAN process_manager_is_exceed_limit(){
  return process_count + 1 > maxInvocation;
}
