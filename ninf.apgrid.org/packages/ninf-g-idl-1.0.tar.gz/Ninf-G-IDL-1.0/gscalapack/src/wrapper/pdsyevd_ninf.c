#define _WRAPPER_
/* $Id: pdsyevd_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define DOUBLE
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n
#define ROW_z lda
#define COL_z n
static	int worklen(int n) {
	  int ret=1;
	  int NP, NQ, TRILWMIN;
	  int IAROW,IACOL;
	  TRILWMIN = 3*n + MAX( n*( n+1 ), 3*n );
	  ret = MAX( 1+6*n+2*n*n, TRILWMIN ) + 2*n;
	  if NEED_BUFF {
	    IAROW = INDXG2P( IA, MB_A, MYROW, RSRC_A, NPROW );
	    IACOL = INDXG2P( JA, NB_A, MYCOL, CSRC_A, NPCOL );
	    TRILWMIN = 3*N + MAX( NB*( NP+1 ), 3*NB );
	    NP = NUMROC( N, NB, MYROW, IAROW, NPROW );
	    NQ = NUMROC( N, NB, MYCOL, IACOL, NPCOL );
	    ret = MAX( 1+6*N+2*NP*NQ, TRILWMIN ) + 2*N;
	  }
	  return ret;
}

static	int iworklen(int n) {
	  int ret=1;
	  ret = 7*n + 8+2;
	  if NEED_BUFF {
	    ret =  7*N + 8*NPCOL + 2;
	  }
	  return ret;
}

void  pdsyevd_ninf(	 char jobz,
		 char uplo,
		 int n,
		 double global_a[],
		 int lda,
		 double w[],
		 double work[],
		 int lwork,
		 int iwork[],
		 int liwork,
		 int *info
)
/* "pdsyevd computes all the eigenvalues and eigenvectors of a real symmetric matrix A by calling the recommended sequence of ScaLAPACK routines." */
/* OPTIONS */
{

extern void  FortranCall(pdsyevd)( char*, char*, int*,
                                double*, int*, int*, int*,
                                double*,
                                double*, int*, int*, int*,
                                double*, int*,
                                int*, int*,
                                int*);
extern void  FortranCall(pdlacpy)( char*, int*, int*,
				double*, int*, int*, int*,
				double*, int*, int*, int*);

	int maxldd;

	int maxlda;
	double *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
	int row_loca, col_loca;

	int maxldz;
	double *global_z=NULL;
	double *locz=NULL;
	int descz[DESCLEN];
	int desc_gz[DESCLEN];
	int row_locz, col_locz;

	double *locwork=NULL;
	int llocwork;
	int *lociwork=NULL;
	int llociwork;

	double *locw=NULL;


	INITIALIZE();

	SCALAR( "char", jobz);
	SCALAR( "char", uplo);
	SCALAR( "int", lda);
	SCALAR( "int", n);
	SCALAR("int",lwork);
	SCALAR("int",liwork);

	if (mypnum=0) {
            global_z = MALLOC(sizeof(double)*ROW_a*COL_a);
            assert(global_z);
        }

	ROW( a);
	COL( a);
	ROW( z);
	COL( z);
	MAXLDD( maxldd, a );
	maxlda = maxldd;
	maxldz = maxldd;

	trMATRIX( uplo, "double", a, ROW_a, COL_a);
	MATRIX( "double", z, ROW_z, COL_z);
	trDISTRIBUTE( uplo, "double", a, ROW_a  , COL_a);

	llocwork = worklen(n);
	llocwork = max(lwork,llocwork);
	WORK(locwork,llocwork);
	llociwork = iworklen(n);
	llociwork = max(liwork,llociwork);
	IWORK(lociwork,llociwork);

	locw=MALLOC(sizeof(double)*n);
        assert(locw);

	if  (( mypnum != 0 ) ^ (serial==1) ) {
	  FortranCall(pdsyevd)( &jobz, &uplo, &n,
                                loca, &one, &one, desca,
                                locw,
                                locz, &one, &one, descz,
                                locwork, &llocwork,
                                lociwork, &llociwork,
                                &linfo);
	  FortranCall(pdlacpy)( &uplo, &ROW_a, &COL_a,
				locz, &one, &one, descz,
				loca, &one, &one, desca);
	}

	GATHER( "double", a, ROW_a, COL_a);
	RETRIEVE( "double", locw, n);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
	  int i;
	  *info = linfo;
	  for(i=0;i<n;i++) w[i]=locw[i];
          FREE(global_z);
	} else {
	}

	FREE_MATRIX(a);
	FREE_MATRIX(z);
        FREE(locw);
	FREE(locwork);
        FREE(lociwork);
}

