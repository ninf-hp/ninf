#define _WRAPPER_
/* $Id: pctrcon_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define SCOMPLEX
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n
static	int worklen(int n) {
	  int ret=1;
	  ret = 2*n + max(2, max(n,n+n));
	  if NEED_BUFF {
	    ret = 2*LOCr(N+MOD(IA-1,MB_A)) +
	      MAX( 2, MAX(NB_A*CEIL(nprow-1,npcol),LOCc(N+MOD(JA-1,NB_A)) +
			  NB_A*CEIL(npcol-1,nprow)) );
	  }
	  return ret;
}

static	int rworklen(int n) {
	  int ret=1;
	  ret = n;
	  if NEED_BUFF {
	    ret = LOCc(N+MOD(JA-1,NB_A));
	  }
	  return ret;
}

void  pctrcon_ninf(	 char norm,
		 char uplo,
		 char diag,
		 int n,
		 scomplex global_a[],
		 int lda,
		 float *rcond,
		 scomplex work[],
		 float rwork[],
		 int *info
)
/* "pctrcon estimates the reciprocal of the condition number of a triangular distributed matrix A, in either the 1-norm or the infinity-norm." */
/* OPTIONS */
{
	int maxldd;

	int maxlda;
	scomplex *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
	int row_loca, col_loca;

	float lrcond[1];

	scomplex *locwork=NULL;
	int llocwork;
	float *locrwork=NULL;
	int llocrwork;

	INITIALIZE();

	SCALAR( "char", norm);
	SCALAR( "char", uplo);
	SCALAR( "char", diag);
	SCALAR( "int", n);
	SCALAR( "int", lda);

	ROW( a);
	COL( a);
	MAXLDD( maxldd, a );
	maxlda = maxldd;
        
	trMATRIX( uplo, "float", a, ROW_a, COL_a);
	trDISTRIBUTE( uplo, "float", a, ROW_a, COL_a);

	llocwork=worklen(n);
	WORK(locwork,llocwork);
	llocrwork=rworklen(n);
	_work("float", &locrwork, llocrwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pctrcon)( &norm, &uplo, &diag, &n,
                               loca, &one, &one, desca,
                               lrcond,
                               locwork, &llocwork,
                               locrwork, &locrwork,
                               &linfo);

	RETRIEVE("int", &linfo, 1);
	RETRIEVE("float", lrcond, 1);

	if( mypnum == 0 ){
	  *rcond=lrcond[0];
	  *info = linfo;
	} else {
	}

	FREE_MATRIX(a);
        FREE(locwork);
        FREE(locrwork);
	
}

