package bricks.util;
import bricks.environment.*;
import bricks.scheduling.*;
import java.util.*;

public class RouteService {

    Hashtable routes = new Hashtable();

    public int size() {
	return routes.size();
    }

    public void initRoutes(Enumeration hosts) {

	while (hosts.hasMoreElements()) {

	    Host host = (Host)hosts.nextElement();
	    Hashtable table = host.getRoutes();
	    Enumeration keys = table.keys();

	    while (keys.hasMoreElements()) {
		Node node = (Node)keys.nextElement();
		Vector route = (Vector)table.get(node);
		NodePair pair = new NodePair(host, node);
		routes.put(pair, route);
	    }
	}
    }


    /******************** public method ********************/
    public Vector get(NodePair pair) {
	return (Vector)((Vector)routes.get(pair)).clone();
    }

    public Enumeration keys() {
	return routes.keys();
    }

    public String toString() {
	String str = "RouteService: ";
	Enumeration e = keys();
	while (e.hasMoreElements()) {
	    NodePair pair = (NodePair)e.nextElement();
	    str += pair + "{" + routes.get(pair) + "}, ";
	}
	return str;
    }

    /*
    protected void putIntoRoutes(NodePair pair, Vector v) {
	if (routes.containsKey(pair)) {
	    Vector data = (Vector)routes.get(pair);
	    data.addElement(v);
	} else {
	    Vector data = new Vector();
	    data.addElement(v);
	    routes.put(pair, data);
	}
    }
    */
}
