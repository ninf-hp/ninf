#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include "ninf_Q.h"

#define MAX_NAME_LEN 50
#define MAX_LINE_LEN 1024

main(int argc, char *argv[])
{
    int i,j;
    static int point = 0;
    static int options = 0;
    int entry_num = 0;
    char *keyword;
    char top[MAX_NAME_LEN];
    char bottom[MAX_NAME_LEN];
    char *uuu;
    char *c;

    argc = Ninf_parse_arg(argc, argv);

    if(argc < 2){
      fprintf(stderr,"Please input entry names which you want.\n");
      exit(1);
    }

    for(i = 0; (i+1) < argc; i++){
/* ============================== */
/*      �ؿ��ꥹ���Ѥ� option     */
/* ------------------------------ */
      if(strncmp(argv[i+1],"-",1)==0 && strcmp(&argv[i+1][1],"k")==0){
           options |= KOPTION;
           keyword = argv[(++i)+1];
/*           if((argv[i+1] == NULL) || (strncmp(argv[i+1],"-",1)==0) || 
                (!isalpha(*keyword))) */
           if((argv[i+1] == NULL) || (strncmp(argv[i+1],"-",1)==0))
             ninf_Q_err("-k is used with string argument!!");
           continue;
      }
/* ============================== */
/*       �ؿ��ܺ��Ѥ� option      */
/* ------------------------------ */
      else if(strncmp(argv[i+1],"-",1)==0 && strcmp(&argv[i+1][1],"e")==0){
           options |= EOPTION;
           c = argv[i+2];
           if((argv[i+2] == NULL) || (strncmp(argv[i+2],"-",1)==0) || 
                (!isalpha(*c)))
                ninf_Q_err("-e is used with string argument!!");
           for(j = 0,i++,point=i+1; (i+1) < argc ; j++,i++)
              if(strncmp(argv[i+1],"-",1)==0){
                  --i;
                  break;
              }
           entry_num = j;
           continue;
      }
    }       

    if (!options)
      ninf_Q_err("Ninf_Q must be called with some option");

/* ================= */
/*  Ninf_Q �ƤӽФ�  */
/* ----------------- */
    if(Ninf_Q(options,keyword,top,bottom,entry_num,argv+point)== NINF_ERROR){
        fprintf(stderr,"ERROR:failed getting stub infomation!\n");
        exit(1);
    }

    exit(0);
}

/* ============ */
/*  error ����  */
/* ------------ */
ninf_Q_err(char *err_str)
{
   FILE *fp;
   char *header = "ninf_Q.h";
   char opt[1],*p;
   char line_buf[MAX_LINE_LEN];
   int i,j;
 
   fprintf(stderr,"ERROR: %s\n",err_str);
   fprintf(stderr,"ninf_Q [-options] (arguments)\n");

   if((fp = fopen(header,"r")) == NULL){
      fprintf(stderr,"Cannot open %s file. \n",header);
      exit(1);
   }
   for(;fgets(line_buf,MAX_LINE_LEN,fp) != NULL; ){
      printf("line(0):%s\n",line_buf);
      if(strncmp(line_buf,"/* options */",13))
                break;
   }
   if(fgets(line_buf,MAX_LINE_LEN,fp) == NULL){
      fprintf(stderr,"Cannot open %s file. \n",header);
      exit(1);
   }  
   for(i = 0;fgets(line_buf,MAX_LINE_LEN,fp) != NULL && i < 19 && 
            (strncmp(line_buf,"/*",2) != 0); i++){
      for(j = 0,p = line_buf; j < MAX_LINE_LEN; j++,p++){
         if(strncmp(line_buf,"#define ",8) ==0){
            p += 8;
            strncpy(opt,p,1);
            strcpy(&opt[1],"\0");
            printf("\t-%s\t",opt);
            for( ;p != NULL && j < MAX_LINE_LEN; j++,p++)
               if(strncmp(p,"/* ",3) ==0){
                   printf(" %s\n",p);
                   break;
               }
            break;
         }
      }
   }
   exit(0);
      
}


