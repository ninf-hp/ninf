package bricks.util;

/** An Exception class for Bricks */
public class BricksNoDiskSpaceException extends BricksException{

    public BricksNoDiskSpaceException() {
	super();
    }

    public BricksNoDiskSpaceException(String str) {
	super();
	this.str = str;
    }

    public BricksNoDiskSpaceException(String str, Object o){
	super();
	this.str = FormatString.format(str, o);
    }

    public BricksNoDiskSpaceException(String str, Object o, Object o2){
	super();
	this.str = FormatString.format(str, o, o2);
    }

    public String toString(){
	if (str != null)
	    return "\nBricksNoDiskSpaceException: " + str;
	return super.toString();
    }
}
