#ifndef _GPLAN_H_
#define _GPLAN_H_

extern int loadplan_opts( char const *plan, int *prank, int *pn, int *pdir, int *pflags, int *pis, int *pos, MEASURE measure );

 extern void* loadplan( char const *plan, MEASURE measure);

 extern void* loadplannd( char const *plan, MEASURE measure);

 extern void saveplannd(char *plan, int rank, int *pn, int dir,int flags, int istide, int ostride );

 extern void saveplan(char *plan, int n, int dir, int flags, int istride, int ostride );

 extern void pushs_opts( char *s, int rank, int *pn, int dir, int flags, int is, int os);

 extern int pops_opts( char const *s, int *prank, int *pn, int *pdir, int *pflags, int *pis, int *pos);

#endif
