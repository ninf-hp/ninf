package bricks.util;
import java.util.*;

public class QueueFCFS extends Queue implements SubComponent {

    public QueueFCFS (Sequence throughput) {
	this.queue = new Vector(DEFAULT_QUEUE_LENGTH);
	this.throughput = throughput;
	if (throughput instanceof InterpolationCpu) {
	    interpolationCpu = true;
	}
    }

/************************* needed method *************************/
    public String getName() {
	return "QueueFCFS";
    }
}
