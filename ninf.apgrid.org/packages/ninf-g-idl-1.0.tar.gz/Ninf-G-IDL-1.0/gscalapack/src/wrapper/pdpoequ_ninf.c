#define _WRAPPER_
/* $Id: pdpoequ_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define DOUBLE
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n
void  pdpoequ_ninf(	 int n,
		 double global_a[],
		 int lda,
		 double global_sr[],
		 double global_sc[],
		 int ldsc,
		 double *scond,
		 double *amax,
		 int *info
)
/* "pdpoequ computes row and column scalings intended to equilibrate a distributed symmetric positive definite matrix A and reduce its condition number (with respect to the two-norm)." */
/* OPTIONS */
{
    	int maxldd;

	int maxlda;
	double *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
	int row_loca, col_loca;

	double *locsr=NULL;
	double *locsc=NULL;

	double lscond[1];
	double lamax[1];

	INITIALIZE();

	SCALAR( "int", n);
        SCALAR( "int", lda);
	SCALAR( "int", ldsc);

	ROW( a);
	COL( a);
	MAXLDD( maxldd, a );
	maxlda = maxldd;

	MATRIX( "double", a, ROW_a, COL_a);
        DISTRIBUTE( "double", a, ROW_a, COL_a);
	VECTOR( "r", "double", sr, ROW_a);
	VECTOR( "c", "double", sc, COL_a);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pdpoequ)( &n,
                               loca, &one, &one, desca,
                               locsr, locsc,
                               lscond,
                               lamax,
                               &linfo);

	vGATHER( "r", "double", sr, ROW_a);
	vGATHER( "c", "double", sc, COL_a);

	RETRIEVE("int", lscond, 1);
	RETRIEVE("int", lamax, 1);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
	  *scond = lscond[0];
	  *amax = lamax[0];
	  *info = linfo;
	} else {
	}

	FREE_MATRIX(a);
}

