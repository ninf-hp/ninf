#define _WRAPPER_
/* $Id: pscsum1_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define FLOAT
#include <gscalapack.h>

#define ROW_x ldx
#define COL_x nx
void  pscsum1_ninf(	
		 int n,
		 scomplex global_x[],
		 int incx,
		 float *global_asum
)
/* "pscsum1 returns the sum of absolute values of a complex vector X, and returns a single precision result." */
/* OPTIONS */
{
  int maxldd;

  int maxldx;
  scomplex *locx=NULL;
  int descx[DESCLEN];
  int desc_gx[DESCLEN];
  int ldx, nx;
  int row_locx, col_locx;

  float locasum[1];

  INITIALIZE();

  SCALAR("int", n);
  SCALAR("int", incx);

  square( n, &ldx, &nx);
  
  ROW(x);
  COL(x);
  MAXLDD(maxldd, x);
  maxldx=maxldd;
  
  MATRIX( "scomplex", x, ROW_x, COL_x);
  DISTRIBUTE( "scomplex", x, ROW_x, COL_x);
  
  if  (( mypnum != 0 ) ^ (serial==1) ) {
     FortranCall(pscsum1)( &n, locasum, locx, &one, &one, descx, &incx);
    Csgsum2d( PARA_CTXT, "A", MPI_TOP, 1, 1, &locasum,     1, 0, 0);
  }

  RETRIEVE( "float", locasum, 1);

  if( mypnum == 0 ){
    *global_asum = locasum[0];
  } else {
  }

  
}

