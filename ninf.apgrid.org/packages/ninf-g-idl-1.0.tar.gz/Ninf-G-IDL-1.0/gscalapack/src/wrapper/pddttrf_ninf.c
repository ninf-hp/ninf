#define _WRAPPER_
/* $Id: pddttrf_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define _DISTRIBUTE_1D_
#define NO_PIVOT
#define DOUBLE
#include <gscalapack.h>

#define ROW_af laf
#define COL_af n
static	int worklen() {
	  int ret=1;
	  ret = 8;
	  if NEED_BUFF ret = 8*npcol;
	  return ret;
}

void  pddttrf_ninf(	 int n,
		 double global_dl[],
		 double global_d[],
		 double global_du[],
		 double af[],
		 int dummy_laf,
		 double work[],
		 int lwork,
		 int *info
)
/* "pddttrf computes a LU factorization of an N-by-N real tridiagonal diagonally dominant-like distributed matrix A." */
/* OPTIONS */
{
    extern void FortranCall(pddttrf)( int*,
                               double*, double*, double*, int*, int*,
                               double*, int*,
                               double*, int*, int*);

	int maxldd;

	double *locdl=NULL, *locd=NULL, *locdu=NULL;
	int desctdd[DESCLEN];
	int desc_gtdd[DESCLEN];

	double *locaf=NULL;
	double *global_af=NULL;
	int maxldaf;
	int descaf[DESCLEN];
	int desc_gaf[DESCLEN];
	int laf,llocaf;
	int row_locaf, col_locaf;
	
	double *locwork=NULL;
	int llocwork;


	INITIALIZE();

	SCALAR( "int", n);
	SCALAR( "int", lwork);
	SCALAR("int", dummy_laf);

	SIZE(n);

	laf = 2*(blocsize+2)*nprocs/n;
	llocaf = laf*blocsize;
	if (mypnum==0) {
	  global_af=MALLOC(sizeof(double)*laf*n);
          assert(global_af);
	}

	ROW(af);
	COL(af);
	MAXLDD( maxldd, af);
	maxldaf=maxldd;

	tdMATRIX( "double", dl, d, du, n);
	tdDISTRIBUTE( "double",  dl, d, du, n);
	MATRIX("double",  af, ROW_af, COL_af);

	llocwork = worklen();
        llocwork = max(lwork,llocwork);
	WORK(locwork,llocwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pddttrf)( &n,
                               locdl, locd, locdu, &one, desctdd,
                               locaf, &llocaf,
                               locwork, &llocwork, &linfo);

	tdGATHER( "double", dl, d, du, n);
	GATHER("double",  af, ROW_af, COL_af);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
	  int i;
	  *info = linfo;
	  for(i=0;i<dummy_laf;i++) af[i] = global_af[i];
          FREE(global_af);
	} else {
	}
	FREE_MATRIX(dl);
	FREE_MATRIX(d);
	FREE_MATRIX(du);
	FREE_MATRIX(af);
        FREE(locwork);
	
}

