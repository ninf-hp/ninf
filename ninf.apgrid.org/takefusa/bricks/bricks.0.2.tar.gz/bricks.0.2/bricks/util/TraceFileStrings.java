package bricks.util;
import java.io.*;
import java.util.*;

public class TraceFileStrings extends Strings implements SubComponent {

    protected String fileName;
    protected Vector strings = new Vector();
    protected int numString;

    public TraceFileStrings(String fileName) {
	this.fileName = fileName;
    }

    public void initialize() throws BricksParseException {
	try {
	    InputStream is = new FileInputStream(fileName);
	    BufferedReader br = new BufferedReader(new InputStreamReader(is));
	    String line;
	    while ((line = br.readLine()) != null) {
		StringTokenizer st = new StringTokenizer(line);
		while (st.hasMoreElements()) {
		    strings.add(0, st.nextToken());
		}
	    }

	} catch (IOException e) {
	    e.printStackTrace();
	    throw new BricksParseException();
	}
    }

    public String getName() {
	return "TraceFileStrings";
    }

    public String nextString() {
	String str = (String)strings.lastElement();
	strings.removeElementAt(strings.size() - 1);
	return str;
    }
}
