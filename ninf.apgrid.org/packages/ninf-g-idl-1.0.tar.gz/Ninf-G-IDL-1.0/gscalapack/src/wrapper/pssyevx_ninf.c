#define _WRAPPER_
/* $Id: pssyevx_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define FLOAT
#include <gscalapack.h>

#define ROW_a lda
#define COL_a  n
#define ROW_z ldz
#define COL_z  n

static	int worklen(char jobz, int n) {
	  int ret=1;
	  int NN, NP0, MQ0;
	  int NEIG;
          int dummy1, dummy2;

              /* */
          dummy1 = n*n +2*n*n;
          dummy2 = 5*n;
          ret = 5*n + max(dummy1,dummy2) + n*n;
	  if NEED_BUFF {
	    NEIG=n;
	    NN = MAX( N,max( NB, 2) );
	    NP0 = NUMROC( NN, NB, 0, 0, NPROW );
	    MQ0 = NUMROC( MAX( NEIG, max(NB, 2) ), NB, 0, 0, NPCOL );
	    ret = 5 * n + MAX( 5 * NN, NB * ( NP0 + 1 ) );
	    if (chrcmp(jobz,'V')==0)
	      ret = 5*n + MAX( 5*NN, NP0 * MQ0 + 2 * NB * NB ) +
		ceil( NEIG, NPROW*NPCOL)*NN;
	  }
          return ret;
}

static	int iworklen(int n) {
	  int ret=1;
	  int NNP;
          ret = 6*max(n,4);
	  if NEED_BUFF {
	    NNP = MAX( N, max(NPROW*NPCOL + 1, 4) );
	    ret = 6*NNP;
	  }
	  return ret;
}

void  pssyevx_ninf(	 char jobz,
		 char range,
		 char uplo,
		 int n,
		 float global_a[],
		 int lda,
		 float vl,
		 float vu,
		 int il,
		 int iu,
		 float abstol,
		 int *m,
		 float w[],
		 float orfac,
		 float global_z[],
		 int ldz,
		 float work[],
		 int lwork,
		 int iwork[],
		 int  ifail[],
		 int *info
)
/* "pssyevx computes selected eigenvalues and, optionally, eigenvectors of a real symmetric matrix A." */
/* OPTIONS */
{
    extern void FortranCall(pssyevx)( char*, char*, char*,
                                int*,
                                float*, int*, int*, int*,
                                float*, float*,
                                int*, int*,
                                float*,
                                int*, int*, float*, float*,
                                float*, int*, int*, int*,
                                float*, int*,
                                int*, int*,
                                int*,
                                int*, float*, int*);

	int maxldd;

	int maxlda;
	float *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];

	int maxldz;
	float *locz=NULL;
	int descz[DESCLEN];
	int desc_gz[DESCLEN];

	int row_loca, col_loca;
	int row_locz, col_locz;

	int *iclustr=NULL;
	float *gap=NULL;
	int locm[1];
	float *locw=NULL;
	int *locifail=NULL;
	int nz;

	float *locwork=NULL;
	int llocwork;
	int *lociwork=NULL;
	int llociwork;

	INITIALIZE();

	SCALAR( "char", jobz);
	SCALAR( "char", range);
	SCALAR( "char", uplo);
	SCALAR( "int", n);
	SCALAR( "float", vl);
	SCALAR( "float", vu);
	SCALAR( "int", il);
	SCALAR( "int", iu);
	SCALAR( "float", abstol);
	SCALAR( "float", orfac);
	SCALAR("int",lda);
	SCALAR("int",ldz);
        SCALAR("int",lwork);

	iclustr = MALLOC( sizeof(int)*2*nprow*npcol); assert(iclustr);
	gap = MALLOC( sizeof(float)*nprow*npcol); assert(gap);
	locw = MALLOC(sizeof(float)*n); assert(locw);
	locifail = MALLOC(sizeof(int)*n); assert(locifail);

	ROW( a);
	COL( a);
	ROW( z);
	COL( z);
	MAXLDD( maxldd, a );
	maxlda = maxldd;
	maxldz = maxldd;
	MATRIX( "float", a, ROW_a, COL_a);
	MATRIX( "float", z, ROW_z, COL_z);
	DISTRIBUTE( "float", a, ROW_a  , COL_a);

	llocwork=worklen(jobz, n);
        llocwork=max(lwork,llocwork);
	WORK(locwork,llocwork);
	llociwork=iworklen(n);
	IWORK(lociwork,llociwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	  FortranCall(pssyevx)( &jobz, &range, &uplo,
                                &n,
                                loca, &one, &one, desca,
                                &vl, &vu,
                                &il, &iu,
                                &abstol,
                                locm, &nz, locw, &orfac,
                                locz, &one, &one, descz,
                                locwork, &llocwork,
                                lociwork, &llociwork,
                                locifail,
                                iclustr, gap, &linfo);

	GATHER( "float", z, ROW_z  , COL_z);
	RETRIEVE( "int", locm, 1);
	RETRIEVE("float", locw, n);
	RETRIEVE( "int", locifail, n);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
		int i;
		*info = linfo;
		for(i=0;i<n;i++) w[i] = locw[i];
		for(i=0;i<n;i++) ifail[i] = locifail[i];
		*m = *locm;
	} else {
	}

	FREE_MATRIX(a);
	FREE_MATRIX(z);
        FREE(gap);
        FREE(iclustr);
	FREE(locw);
	FREE(locifail);
	FREE(locwork);
        FREE(lociwork);
}

