package ninf.netsolve;
import ninf.MetaServer.*;
import ninf.client.*;
import ninf.basic.*;


import java.io.IOException;
import java.util.Vector;

public class AdapterLatch implements NinfCallable{
  AdapterFunctionStruct func;
  NinfStub stub;
  FunctionManager manager;
  NinfPacket pkt;
  XDRInputStream is;
  XDROutputStream os;
  Vector buffers = new Vector();
  NinfServerConnection con;
  NinfLog dbg = new NinfLog(this);


  public AdapterLatch(AdapterFunctionStruct func,  FunctionManager manager){
    this.func = func;
    this.stub = func.stub;
    this.manager = manager;
  }

  public Stoppable call(NinfPacket dum, XDRInputStream is, XDROutputStream os) 
    throws NinfException {
    this.pkt = pkt;
    this.is = is;
    this.os = os;

    dbg.println("call invoked");
    try {
      dbg.println("serverReceive ...");
      func.problem.serverReceive(buffers, stub, is);
      dbg.println("serverReceive done");
    } catch (Exception e){
      e.printStackTrace();
      throw new NinfIOException();
    }
    ServerIndex server = null;
    NinfServerConnection con = null;
    dbg.println("getting server ...");
    if (NinfFunction.locking)
      server = manager.getQue().getServerLock(func, 1);
    else
      server = manager.getQue().getProperServer(func, 1);
    dbg.println("getting server done");
    if (server != null){
      try {
	dbg.println("connecting server ...");
	con = server.server.connect();
	dbg.println("connecting server done");
	dbg.println("native calling ...");
	con.callNative(stub, server.index, buffers);
	dbg.println("native call done");

	os.writeChar(GlobalDefs.DATA_XDR);
	os.writeInt(GlobalDefs.SOLUTION);
	func.problem.writeBack(buffers, stub, os);
      } catch (IOException e) {
	manager.removeNinfServer(server.server);
	throw new NinfIOException();
      } finally {
	server.server.loadDecrement();
      }
    }
    return con;
  }
}
