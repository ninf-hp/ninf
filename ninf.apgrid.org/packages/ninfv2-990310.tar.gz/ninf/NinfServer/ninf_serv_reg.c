/*
 * ninf server register process 
 */
#include <stdio.h>
#include <sys/stat.h>

#include <signal.h>
#include <sys/wait.h>
#include <errno.h>
#include <string.h>
#include <dirent.h>

#include "ninf_stub_info.h"
#include "ninf_serv_reg.h"
#include "ninf_read_config.h"
#include "ninf_data_trans.h"
#include "ninf_stream.h"
#include "ninf_protocol.h"

#include "ninf_q_protocol.h"

#define USE_STUB_PKT

NINF_STUB_INFO * new_ninf_stub_info();
extern struct read_stub_item * read_stub_item_root;

static char reg_sockname[100];

FILE *sock_ostream, *sock_istream;

/* table for stub entrys */
static NINF_REG_ENTRY *reg_stubs[MAX_REG_ENTRY_STUB];
static int current_entry_index = 0;


setup_ninf_by_read_stub()
{
  struct read_stub_item * tmp = read_stub_item_root;
   
  while (tmp != NULL){
    setup_ninf_directory(tmp->stub_file_name);
    tmp = tmp->next;
  }
}

char * xmalloc();

setup_ninf_directory(char * name)
{
  DIR * dir;
  char buffer[1000];
  struct dirent * tdirent;
  struct stat * tstat = (struct stat *)xmalloc(sizeof(struct stat));
  if (stat(name, tstat) != 0){
    perror("setup_ninf_directory");
    ninf_log("server[%d]: can't setup using dir: %s\n", getpid(), name);
    return;
  }
  if ((tstat->st_mode & S_IFDIR) == 0){
    enter_stub_info(name);
    return;
  }   

  if ((dir = opendir(name)) == NULL){
    ninf_log("server[%d]: can't open dir: %s\n", getpid(), name);
    return;
  } 
  while ((tdirent = readdir(dir)) != NULL){

    if (strncmp(tdirent->d_name, "_stub_", 6) == 0) {
      strcpy(buffer, name);
      strncat(buffer, "/", 1000);
      strncat(buffer, tdirent->d_name, 1000);
      stat(buffer, tstat);
      if ((tstat->st_mode & S_IXUSR) != 0){
	enter_stub_info(buffer);
      }
    }
  }
  closedir(dir);
}

extern char * ninf_server_service;
setup_ninf_register()
{
    int s,size,i;
    char reg_addr[30];

    /* initalize table */
    for(i = 0; i < MAX_REG_ENTRY_STUB; i++)
      reg_stubs[i] = NULL;


    make_reg_sockname(reg_sockname, ninf_server_service);
    s = ninf_sock_local(reg_sockname);
    register_unlink(reg_sockname);
    listen(s,1);	/* ready to accept */
    return(s);
}

/* int reg_sock;	register socket */
static char reg_pkt_buf[NINF_REG_PKT_SIZE];

do_ninf_register(int reg_sock)
{
  int code,n;
  struct ninf_reg_stub_packet *rp;
  
  for(;;){	/* command loop */
    if((n = read(reg_sock,reg_pkt_buf,NINF_REG_PKT_SIZE)) 
       != NINF_REG_PKT_SIZE){
      
      if(n == 0) goto ret;	/* EOF */
    ninf_log("server[%d]: segmented reg packet? n=%d\n", getpid(), n);
      goto ret;
    }
    switch(code = NINF_REG_PKT_CODE(reg_pkt_buf)){
    case NINF_REG_END: 
      goto ret;
    case NINF_REG_STOP:
      unlink(reg_sockname);	/* remove socket */
      return(FALSE);			/* stop server */
    case NINF_REG_ENTER_STUB:
      rp = (struct ninf_reg_stub_packet *)reg_pkt_buf;
      if((n = enter_stub_info(rp->program)) < 0) 
	goto nack;
      rp->stub_index = n;
      strcpy(rp->entry_name,reg_stubs[n]->entry_name);
      strcpy(rp->module_name,reg_stubs[n]->module_name); 
      break;
    case NINF_REG_REMOVE_STUB:
      rp = (struct ninf_reg_stub_packet *)reg_pkt_buf;
      if(!remove_stub_info(rp->program)) 
	goto nack;
      break;
    case NINF_REG_DUMP:
      rp = (struct ninf_reg_stub_packet *)reg_pkt_buf;
      dump_stub_info(rp, reg_sock);
      goto ret;
    default:
      ninf_log("unknow reg packet code=%d",code);
      goto ret;
    }
    /* return ack */
    NINF_REG_PKT_CODE(reg_pkt_buf) = NINF_REG_OK;
    goto reply;
 nack:
    NINF_REG_PKT_CODE(reg_pkt_buf) = NINF_REG_ERROR;
 reply:	  
    if (!send_packet(reg_sock))
      return(TRUE);
  }
 ret:
  /* exit from register process, but continue server */
  return(TRUE);
}

send_packet(int reg_sock)
{
  int n;

  if ((n = write(reg_sock,reg_pkt_buf,NINF_REG_PKT_SIZE)) 
      != NINF_REG_PKT_SIZE) {
    ninf_log("reply reg failed, n=%d\n",n);
    return FALSE;
  }
  return TRUE;
}

void setup_ninf_by_stubstr(char * stubstr)
{
  char * tmp;
  tmp = strtok(stubstr, ":, \t");
  while (tmp != NULL && *tmp != '\0'){
    enter_stub_info(tmp);
    tmp = strtok(NULL, ":");
  }
}

int find_index_module_name(char * mname, char *ename)
{
  int i;
  NINF_REG_ENTRY *ep;
  for(i = 0; i < MAX_REG_ENTRY_STUB; i++){
    ep = reg_stubs[i];
    if(ep != NULL && strcmp(ep->module_name, mname) == 0 
                  && strcmp(ep->entry_name,  ename) == 0 ) 
      return(i);
  }
  return -1;
}


int find_index_by_name(char * program)
{
  int i;
  NINF_REG_ENTRY *ep;
  for(i = 0; i < MAX_REG_ENTRY_STUB; i++){
    ep = reg_stubs[i];
    if(ep != NULL && strcmp(ep->program,program) == 0) 
      return(i);
  }
  return -1;
}

remove_stub_info(char * index_str)
{
  int index;
  char * tmp;
  if (strcmp(index_str, "0") == 0){
    index = 0;
  } else {
    index = atoi(index_str);
    if (index == 0){
      index = find_index_by_name(index_str);
      if (index < 0){
	return FALSE;
      }
    }
  }
  tmp = (char *)(reg_stubs[index]);
  reg_stubs[index] = NULL;
  free(tmp);
  return TRUE;
}

one_dump_stub(struct ninf_reg_stub_packet * rp, int n, int reg_sock)
{
  if (reg_stubs[n] == NULL)
    return;
  rp->code = NINF_REG_DUMP_ANS;
  rp->stub_index = n;
  strcpy(rp->program,reg_stubs[n]->program);
  strcpy(rp->entry_name,reg_stubs[n]->entry_name);
  strcpy(rp->module_name,reg_stubs[n]->module_name);
  send_packet(reg_sock);
}

dump_stub_info(struct ninf_reg_stub_packet * rp, int reg_sock)
{
  int i; 
  for (i = 0; i < current_entry_index; i++){
    one_dump_stub(rp, i, reg_sock);
  }
  rp->code = NINF_REG_DUMP_ANS_END;
  send_packet(reg_sock);
}


void register_time(NINF_STUB_INFO * reg_stub_info){
  struct timeval tm;

  gettimeofday(&tm, 0);
  reg_stub_info->registered_time = tm.tv_sec;
}

enter_stub_info(char * program)
{
    int i,ack,size;
    NINF_REG_ENTRY *ep;
    static char work_buffer[MAX_PKT_LEN];
    NINF_STUB_INFO * reg_stub_info = new_ninf_stub_info();
    connection * con;

    char *cp;
    void send_new_stub_info_to_metaserver(char* ); /* ninf_serv_tcp.c */
    int s;
    int stub_pid;

    stub_pid = ninf_local_forkexec(program, FALSE, &con);
    if (stub_pid < 0)
      goto err;
    /* send request */

    if(!trans_request(con->sDT,NINF_REQ_STUB_INFO)) 
      goto err;
    write_flush(con->sDT);
		
    /* get result */

    if(!trans_int(con->rDT,&ack)) goto err;
    else if(ack != NINF_ACK_OK) goto err;
    if(!trans_stub_info_all(con->rDT, reg_stub_info, TRUE))
      goto err;

    ninf_local_kill(con, stub_pid);	/* kill it */
    close(con->sDT->fd);

    register_time(reg_stub_info);

    if((ep = (NINF_REG_ENTRY *)malloc(sizeof(*ep)))== NULL){
      ninf_log("enter_stub_info: no memory");
      return(-1);
    }

    strcpy(ep->program,program);
    strcpy(ep->module_name,reg_stub_info->module_name);
    strcpy(ep->entry_name,reg_stub_info->entry_name);
    sprintf(ep->full_name,"%s/%s", reg_stub_info->module_name, reg_stub_info->entry_name);
    ep->stub_info = reg_stub_info;

    if (find_index_module_name(ep->module_name, ep->entry_name) >= 0){
      free(ep);
      return -1;
    }

    i = current_entry_index++;
    if (i == MAX_REG_ENTRY_STUB) return(-1);
    ep->index = i;
    reg_stubs[i] = ep;

    ninf_log("Register[%d] %s/%s:%s",
	    i, ep->module_name,ep->entry_name,ep->program);

    /*    send_new_stub_info_to_metaserver(ep->entry_name); */
    return(i);
 err:
    ninf_local_kill(con, stub_pid);	/* kill it */
    return(-1);
}

NINF_REG_ENTRY *find_reg_stub_entry(char * entry_name)
{
    return find_reg_stub_entry_from(entry_name, 0, MATCH_EXACT);
}

NINF_REG_ENTRY *find_reg_stub_entry_from(char * entry_name, int start, int flag)
{
    int i;
    NINF_REG_ENTRY *ep;
    
    /* find free entry */
    for(i = start; i < MAX_REG_ENTRY_STUB; i++){
      ep = reg_stubs[i];
      if(ep != NULL){
	if (flag == MATCH_EXACT) {
	  if (strcmp(ep->full_name,entry_name) == 0)
	    return ep;
	} else {
	  if (strstr(ep->full_name,entry_name) != NULL)
	    return ep;
	}
      }
    }
    return NULL;
}

NINF_REG_ENTRY *find_reg_stub_index(int index)
{
    NINF_REG_ENTRY *ep;

    if(index < 0 || index >= MAX_REG_ENTRY_STUB) return(NULL);
    return(reg_stubs[index]);
}

int register_from_socket(int reg_sock){
  char reg_client_addr[30];

  int size = sizeof(reg_client_addr);
  int ns = accept(reg_sock,
		  (struct sockaddr *)reg_client_addr,&size);
  if (ns < 0){
    perror("accept reg client");
    ninf_error("master reg accept failed");
    return FALSE;
  }  

  if (!do_ninf_register(ns)) 
    return FALSE;
  close(ns);
  return TRUE;
}
