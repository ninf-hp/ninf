#define _WRAPPER_
/* $Id: pcpbsv_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define _DISTRIBUTE_1D_
#define SCOMPLEX
#define NO_PIVOT
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n
#define ROW_b ldb
#define COL_b nrhs
static    int worklen(int n, int nrhs, int bw) {
        int ret=1;
        ret = (n+2*bw)*bw+max((bw*nrhs), bw*bw);
        if NEED_BUFF ret = (blocsize+2*bw)*bw+max((bw*nrhs), bw*bw);
        return ret;
}

void  pcpbsv_ninf(	 char uplo,
		 int n,
		 int bw,
		 int nrhs,
		 scomplex global_a[],
		 int lda,
		 scomplex global_b[],
		 int ldb,
		 int *info
)
/* "pcpbsv solves a system of linear equations A * X = B where A is an N-by-N complex banded symmetric positive definite distributed matrix with bandwidth BW." */
/* OPTIONS */
{
    extern void FortranCall(pcpbsv)( char*, int*, int*, int*,
                              scomplex*, int*, int*,
                              scomplex*, int*, int*,
                              scomplex*, int*, int*);

    int maxldd;

    int maxlda;
    scomplex *loca=NULL;
    int desca[DESCLEN];
    int desc_ga[DESCLEN];

    int maxldb;
    scomplex *locb=NULL;
    int descb[DESCLEN];
    int desc_gb[DESCLEN];

    int row_locb;
    int col_locb;

    scomplex *locwork=NULL;
    int llocwork;

    INITIALIZE();

	SCALAR( "char", uplo);
	SCALAR( "int", n);
	SCALAR( "int", bw);
	SCALAR( "int", nrhs);
	SCALAR("int", lda);
	SCALAR("int", ldb);

	SIZE(n);

        ROW(b);
        COL(b);
	MAXLDD( maxldd, b );
	maxldb=maxldd;
	
        if (chrcmp(uplo,'U')==0) {
            bandMATRIX( "scomplex", a, 0, bw, n);
            bandDISTRIBUTE( "scomplex", a, 0, bw, n);
        } else {
            bandMATRIX( "scomplex", a, bw, 0, n);
            bandDISTRIBUTE( "scomplex", a, bw, 0, n);
        }
        
        MATRIX( "scomplex", b, ROW_b, COL_b);
        DISTRIBUTE( "scomplex", b, ROW_b, COL_b);
        
        llocwork=worklen(n, nrhs, bw);
        WORK(locwork,llocwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pcpbsv)( &uplo, &n, &bw, &nrhs,
                              loca, &one, desca,
                              locb, &one, descb,
                              locwork, &llocwork, &linfo);

        if (chrcmp(uplo,'U')==0) {
            bandGATHER( "scomplex", a, 0, bw, n);
        } else {
            bandGATHER( "scomplex", a, bw, 0, n);
        }
        GATHER("scomplex", b, ROW_b, COL_b);
        
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
            *info = linfo;
	} else {
		
	}
	FREE_MATRIX(a);
	FREE_MATRIX(b);

        FREE(locwork);
}

