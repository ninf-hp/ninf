package bricks.scheduling;
import bricks.util.*;
import bricks.environment.*;
import java.util.*;

public class NaiveServerPredictor extends ServerPredictor implements Predictor {

    protected Hashtable predictInfos = new Hashtable();

    public NaiveServerPredictor(MetaPredictor owner) {
	init(owner);
    }

/************************* inner class *************************/
    protected class PredictInfo {
	HostInfo hostInfo;
	int numConflict;

	protected PredictInfo(HostInfo hostInfo) {
	    this.hostInfo = hostInfo;
	    this.numConflict = 0;
	}

	protected void add() {
	    numConflict++;
	}
	
	protected int getNumOfConflict() {
	    return numConflict;
	}
    }

/************************* needed method *************************/
    public String getName() {
	return "NaiveServerPredictor";
    }

    public ServerPrediction getServerPrediction(
	double currentTime, Host host, HostInfo hostInfo
    ) {
	PredictInfo predictInfo = (PredictInfo)predictInfos.get(host);
	if ((predictInfo != null) &&
	    (predictInfo.hostInfo.probeTime == hostInfo.probeTime)) {
	    // Current PredictInfo is there.
	    HostInfo info = (HostInfo)hostInfo.clone();
	    info.loadAverage = 
		info.loadAverage + predictInfo.getNumOfConflict();
	    return new ServerPrediction(hostInfo, info);

	} else {
	    // PredictInfo is old or nothing.
	    predictInfos.put(host, new PredictInfo(hostInfo));
	    return null;
	}
    }

    public void addServerLoad(
        double currentTime, Host host, RequestedData data
    ) {
	addServerLoad(host, data.numInstructions);
    }

    public void addServerLoad(double currentTime, EPTask task) {
	addServerLoad((Host)task.destination, task.numInstructions);
    }

    public void addServerLoad(Host host, double numInstructions) {

	PredictInfo predictInfo = (PredictInfo)predictInfos.get(host);
	if (predictInfo == null) {
	    HostInfo hostInfo = resourceDB.getHostInfo(host);
	    predictInfo = new PredictInfo(hostInfo);
	    predictInfos.put(host, predictInfo);
	}
	predictInfo.add();
    }
}
