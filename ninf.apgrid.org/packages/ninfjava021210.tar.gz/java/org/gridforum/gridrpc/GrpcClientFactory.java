package org.gridforum.gridrpc;

public class GrpcClientFactory{
  static public GrpcClient getClient(String classname) throws GrpcException{
    try {
      Class clientClass = Class.forName(classname);
      Object client = clientClass.newInstance();
      if (client instanceof GrpcClient)
	return (GrpcClient)client;
      throw new GrpcException("The specified class " + classname +
			      " was not subclass of GrpcClient ");
    } catch (Exception e){
      throw new GrpcException(e);
    }
  }
}
