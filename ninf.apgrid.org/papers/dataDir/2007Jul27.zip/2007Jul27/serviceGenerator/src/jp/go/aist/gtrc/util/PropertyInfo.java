package jp.go.aist.gtrc.util;

import javassist.ClassPool;
import javassist.CtClass;
import javassist.CtField;
import javassist.NotFoundException;

import javax.xml.namespace.QName;

public class PropertyInfo {
	public String name;
	QName qName;
	public TypeInfo type;

	PropertyInfo(CtField property, String tns, TypeMapping typeMapping) throws NotFoundException {
		name = property.getName();
		qName = new QName(tns, name);
		type = typeMapping.get(property.getType().getName());
	}

	static boolean isTestOk() {
		try {
			ClassPool cp = ClassPool.getDefault();
			CtClass cc = cp.get("jp.go.aist.gtrc.util.impl.TestResource");
			CtField property = cc.getDeclaredField("count");
			PropertyInfo propertyInfo = new PropertyInfo(property, "http://gtrc.aist.go.jp/util", getTypeMapping());
			if (!propertyInfo.name.equals("count")) {
				System.out.println("!propertyInfo.name.equals(\"count\")");
				return false;
			}
			if (!propertyInfo.qName.equals(new QName("http://gtrc.aist.go.jp/util", "count"))) {
				System.out.println("!propertyInfo.qName.equals(new QName(\"http://gtrc.aist.go.jp/util\", \"count\"))");
				return false;
			}
			return true;
		} catch (Throwable t) {
			t.printStackTrace();
			return false;
		}
	}

	static TypeMapping getTypeMapping() {
		TypeMapping typeMapping = new TypeMapping();
		SchemaInfo schemaInfo = new SchemaInfo("xsd", "http://www.w3.org/2001/XMLSchema");
		typeMapping.put("int", new TypeInfo(schemaInfo, "int", "int"));
		return typeMapping;
	}
}
