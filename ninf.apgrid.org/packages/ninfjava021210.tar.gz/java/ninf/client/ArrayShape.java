package ninf.client;
import ninf.basic.*;

class ArrayShape{
  ArrayShapeElem dim[];
  ArrayShape(int n){
    dim = new ArrayShapeElem[n];
  }
}
