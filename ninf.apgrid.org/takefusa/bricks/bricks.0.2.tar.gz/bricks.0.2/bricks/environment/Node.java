package bricks.environment;
import bricks.util.*;
import java.io.*;
import java.util.*;

public abstract class Node extends Obj {

    protected int event;
    protected Vector nextLink;
    protected Data nextData;
    protected PrintWriter logWriter;
    public abstract void schedule(double currentTime, Data data);
    public abstract String getName();

/************************* public method *************************/

    public void printLog(String log) {;}

    public String toOriginalString(double currentTime) {
	return "  [" + getName() + "]\n";
    }

    public String toInitString() {
	return "  [" + getName() + "]\n";
    }


    /* caller:  SimulationSet.initLinks() */
    /* overriden by Host */
    public void tracePath(Vector list) {

	/* Check return path */
	if (list.contains(this))
	    return;
	
	/* trace next node */
	list.addElement(this);
	Enumeration e = nextLink.elements();
	while (e.hasMoreElements()) {
	    Vector subList = (Vector)list.clone();
	    Node node = (Node)e.nextElement();
	    node.tracePath(subList);
	}
	return;
    }

    // overriden by Network and Host.
    public void putInterarrivalTimeOfPackets(Sequence ng, Node toNode) {;}

    public void initSession(double currentTime) {
	nextData = getNextData(currentTime);
	updateNextEvent(currentTime);
    }

    public boolean isFull() {
	return false;
    }

    public boolean equals(Object object) {
	if (object instanceof Node) {
	    Node node = (Node)object;
	    if (this.key == node.key)
		return true;
	}
	return false;
    }


/************************* protected method *************************/
    protected Data getNextData(double currentTime) {
	System.err.println(this);
	error("Bad method invocation!");
	return null;
    }

    protected void putLinkedNode(Node node) {
	nextLink.addElement(node);
    }

    protected void error(String message) throws RuntimeException {
	System.err.println(getName() + " Error:: " + message);
	throw new RuntimeException();
    }
}

