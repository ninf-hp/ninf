#include <stdio.h>
#include <signal.h>
/* sample library */


throw_sigfpe(){
  kill(getpid(), SIGFPE);
}

mmul(N,A,B,C)
     double *A,*B,*C;
{
    double t;
    int i,j,k;

    for (i=0;i<N;i++) {
	for (j=0;j<N;j++) {
	    t = 0;
	    for (k=0;k<N;k++){
		t += A[i*N + k] * B[k*N+j];	/* inner product */
	    }
	    C[i*N+j] = t;
	}
    }
}

