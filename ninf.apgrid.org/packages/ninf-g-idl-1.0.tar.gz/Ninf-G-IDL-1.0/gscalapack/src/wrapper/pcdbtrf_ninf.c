#define _WRAPPER_
/* $Id: pcdbtrf_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define _DISTRIBUTE_1D_
#define SCOMPLEX
#define NO_PIVOT
#include <gscalapack.h>

#define ROW_a  lda
#define COL_a n
#define ROW_af ldaf
#define COL_af n
static	int worklen(int bwl, int bwu) {
	  int ret=1;
	    ret = max(bwl,bwu)*max(bwl,bwu);
            return ret;
}


void  pcdbtrf_ninf(	 int n,
		 int bwl,
		 int bwu,
		 scomplex global_a[],
		 int lda,
		 scomplex af[],
		  int dummy_ldaf,
		 scomplex work[],
		 int lwork,
		 int *info
)
/* "pcdbtrf computes a LU factorization of an N-by-N complex banded diagonally dominant-like distributed matrix with bandwidth BWL, BWU: A." */
/* OPTIONS */
{
    extern void FortranCall(pcdbtrf)( int*, int*, int*,
                               scomplex*, int*, int*,
                               scomplex*, int*,
                               scomplex*, int*, int*);

	int maxldd;

	float *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];

	int maxldaf;
	int ldaf,llocaf;	
	scomplex *locaf=NULL,*global_af=NULL;
	int descaf[DESCLEN];
	int desc_gaf[DESCLEN];

	int row_locaf;
	int col_locaf;
	
	float *locwork=NULL;
	int llocwork;

	INITIALIZE();
        
	SCALAR( "int", n);
	SCALAR( "int", bwl);
	SCALAR( "int", bwu);
	SCALAR( "int", lda);
	SCALAR( "int", lwork);
	SCALAR( "int", dummy_ldaf);

	SIZE(n);

	ldaf = max( dummy_ldaf, bwl+bwu+6*max(bwl,bwu)*max(bwl,bwu)/n);
	llocaf = ldaf*blocsize;
	if(mypnum==0){
            global_af = MALLOC(sizeof(scomplex)*ldaf*n); assert(global_af);
	}

	ROW(af);
	COL(af);
	MAXLDD(maxldd, af);
	maxldaf=maxldd;

	bandMATRIX("scomplex", a, bwl, bwu, n);
	MATRIX( "scomplex", af, ROW_af, COL_af);
	bandDISTRIBUTE("scomplex", a, bwl, bwu, n);

	llocwork = worklen(bwl,bwu);
        llocwork = max(llocwork,lwork);
	WORK(locwork,llocwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pcdbtrf)( &n, &bwl, &bwu,
                               loca, &one, desca,
                               locaf, &llocaf,
                               locwork, &llocwork, &linfo);
	
	bandGATHER("scomplex", a, bwl, bwu, n);
	GATHER( "scomplex", af, ROW_af, COL_af);

	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
	  int i;
	  *info = linfo;
	  for(i=0;i<min(dummy_ldaf,ldaf*n);i++) af[i]=global_af[i];
          FREE(global_af);
	} else {
	}
        
	FREE_MATRIX(a);
	FREE_MATRIX(af);

        FREE(locwork);
}

