

#define ptr(input, size, i, j) \
   (((i) < 0 || (i) >= size || (j) < 0 || (j) >= size)? 0.0 : *((input) + (size) * (i) + (j)))


void jacobi(int size, double * input, int iter_times){
  int i, j, k;
  for (k = 0; k < iter_times; k++){

    for (i = 0; i < size; i++){
      for (j = 0; j < size; j++){
	*((input) + (size) * (i) + (j)) =
	  (ptr(input, size, i+1, j) +
	   ptr(input, size, i, j+1) +
	   ptr(input, size, i-1, j) +
	   ptr(input, size, i, j-1)) / 4;
      }
    }
  }
}

#if 0
#define N 10
double base[N][N];

print(int size, double * base){
  int i, j;
  for (i = 0; i < size; i++){
    for (j = 0; j < size; j++){
      printf("%3.2f ", 	*((base) + (size) * (i) + (j)));      
    }
    printf("\n");
  }
  printf("\n");
}

init(int size, double * base){
  int i, j;
  for (i = 0; i < size; i++){
    for (j = 0; j < size; j++){
      *((base) + (size) * (i) + (j)) = (i==j)? 3: 0;
    }
  }
}

main(){
  char tmp[10];
  init(N, base);
  
  while(1){
    print(N, base);
    gets(tmp);
    jacobi(N, base, 1);
  }
}

#endif 
