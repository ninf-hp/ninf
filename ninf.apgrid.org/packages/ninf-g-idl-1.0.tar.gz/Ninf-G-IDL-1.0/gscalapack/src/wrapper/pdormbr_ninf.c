#define _WRAPPER_
/* $Id: pdormbr_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define DOUBLE
#include <gscalapack.h>

#define ROW_a lda
#define COL_a nq
#define ROW_c ldc
#define COL_c n

static	int worklen(char vect, char side,int m, int n, int nq, int k) {
	  int ret=1;
#define NQ nq
	  int LCM, LCMP, LCMQ, IROFFA, ICOFFA, IAROW, IACOL;
	  int MqA0, NpA0, IROFFC, ICOFFC, ICROW, ICCOL;
	  int MpC0, NqC0;
	  int IAA, JAA;
	  int ICC, JCC;
	  int MI, NI;
	  int max_m_n;

	  max_m_n = max(m,n);
	  ret = MAX( (max_m_n*(max_m_n-1))/2, (max_m_n + max_m_n)*max_m_n ) +
	      max_m_n * max_m_n;
	  if NEED_BUFF {

	    if (chrcmp(side, 'L')==0) {
	      NQ = M;
	      if( ((chrcmp(vect, 'Q')==0) && NQ >= k) 
		  || ( (chrcmp(vect,'Q') !=0 ) && NQ > k) )
		{IAA=IA; JAA=JA; MI=M; NI=N; ICC=IC; JCC=JC;}
	      else
		{IAA=IA+1; JAA=JA; MI=M-1; NI=N; ICC=IC+1; JCC=JC;}
	    } else {
	      NQ = N;
	      if( ((chrcmp(vect,'Q') == 0) && NQ >= k)
		  || ((chrcmp(vect,'Q')!=0) && NQ > k) )
		{IAA=IA; JAA=JA; MI=M; NI=N; ICC=IC; JCC=JC;}
	      else
		{IAA=IA; JAA=JA+1; MI=M; NI=N-1; ICC=IC; JCC=JC+1;}
	    }

	    LCM = LCM( NPROW, NPCOL );
	    LCMP = LCM / NPROW; LCMQ = LCM / NPCOL;

	    IROFFA = MOD( IAA-1, MB_A ); ICOFFA = MOD( JAA-1, NB_A );
	    IAROW = INDXG2P( IAA, MB_A, MYROW, RSRC_A, NPROW );
	    IACOL = INDXG2P( JAA, NB_A, MYCOL, CSRC_A, NPCOL );
	    MqA0 = NUMROC( MI+ICOFFA, NB_A, MYCOL, IACOL, NPCOL );
	    NpA0 = NUMROC( NI+IROFFA, MB_A, MYROW, IAROW, NPROW );

	    IROFFC = MOD( ICC-1, MB_C ); ICOFFC = MOD( JCC-1, NB_C );
	    ICROW = INDXG2P( ICC, MB_C, MYROW, RSRC_C, NPROW );
	    ICCOL = INDXG2P( JCC, NB_C, MYCOL, CSRC_C, NPCOL );
	    MpC0 = NUMROC( MI+IROFFC, MB_C, MYROW, ICROW, NPROW );
	    NqC0 = NUMROC( NI+ICOFFC, NB_C, MYCOL, ICCOL, NPCOL );

	    if (chrcmp(vect, 'Q')==0) {
	      if (chrcmp(side ,'L')==0)
		ret = MAX( (NB_A*(NB_A-1))/2, (NqC0 + MpC0)*NB_A ) +
		  NB_A * NB_A;
	      else 
		ret = MAX( (NB_A*(NB_A-1))/2, ( NqC0 + MAX( NpA0 + NUMROC( NUMROC( NI+ICOFFC, NB_A, 0, 0, NPCOL ),  NB_A, 0, 0, LCMQ ), MpC0 ) )*NB_A ) + NB_A * NB_A;
	    } else {
	      if (chrcmp( side , 'L') ==0)
		ret = MAX( (MB_A*(MB_A-1))/2, ( MpC0 + MAX( MqA0 + NUMROC( NUMROC( MI+IROFFC, MB_A, 0, 0, NPROW ), MB_A, 0, 0, LCMP ), NqC0 ) )*MB_A ) + MB_A * MB_A;
	      else if (chrcmp(side , 'R')==0)
		ret = MAX( (MB_A*(MB_A-1))/2, (MpC0 + NqC0)*MB_A ) +
		  MB_A * MB_A;
	    }

	  }
	  return ret;
}

void  pdormbr_ninf(	 char vect,
		 char side,
		 char trans,
		 int m,
		 int n,
		 int k,
		 double global_a[],
		 int lda,
		 double global_tau[],
		 double global_c[],
		 int ldc,
		 double work[],
		 int lwork,
		 int *info
)
/* "If VECT = 'Q', pdormbr overwrites the general real distributed M-by-N matrix C with\\n\\n                       SIDE = 'L'           SIDE = 'R'\\n  TRANS = 'N':      Q * C           C * Q\\n  TRANS = 'T':      Q**T *  C        C * Q**T\\n\\n  If VECT = 'P', pdormbr overwrites C with\\n\\n                       SIDE = 'L'           SIDE = 'R'\\n  TRANS = 'N':      P * C           C * P\\n  TRANS = 'T':      P**T * C        C * P**T\\n\\n  Here Q and P**T are the orthogonal distributed matrices determined by PSGEBRD when reducing a real distributed A to bidiagonal form: A(IA:*,JA:*) = Q * B * P**T." */
/* OPTIONS */
{
	int maxldd;
	int nq;

	int maxlda;
	double *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
	int row_loca, col_loca;

	double *loctau=NULL;

	int maxldc;
	double *locc=NULL;
	int descc[DESCLEN];
	int desc_gc[DESCLEN];
	int row_locc, col_locc;

	double *locwork=NULL;
	int llocwork;


	INITIALIZE();

	SCALAR( "char", vect);
	SCALAR( "char", side);
	SCALAR( "char", trans);
	SCALAR( "int", m);
	SCALAR( "int", n);
	SCALAR( "int", k);
	SCALAR( "int", lda);
	SCALAR( "int", ldc);
	SCALAR( "int", lwork);

	if (chrcmp(side,'L')==0) nq=m;
	else nq=n;

	ROW( a);
	COL( a);
	ROW( c);
	COL( c);
	MAXLDD( maxldd, c );
	maxlda = maxldd;
	maxldc = maxldd;

	MATRIX( "double", a, ROW_a, COL_a);
	MATRIX( "double", c, ROW_c, COL_c);
	DISTRIBUTE( "double", a, ROW_a  , COL_a);
	DISTRIBUTE( "double", c, ROW_c  , COL_c);
        
	if (chrcmp(vect,'q')==0) {
	  VECTOR("c", "double",tau, min(nq,k));
	  vDISTRIBUTE("c","double",tau, min(nq,k));
	}else{
	  VECTOR("r", "double",tau, min(nq,k));
	  vDISTRIBUTE("r","double",tau, min(nq,k));
	}

	llocwork=worklen(vect, side, m, n, nq, k);
	llocwork = max( llocwork, lwork);
	WORK(locwork,llocwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pdormbr)( &vect, &side, &trans,
                               &m, &n, &k,
                               loca, &one, &one, desca,
                               loctau,
                               locc, &one, &one, descc,
                               locwork, &llocwork,
                               &linfo);

	GATHER( "double", c, ROW_c, COL_c);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
		*info = linfo;
		// cp locwork to work[lwork]
	} else {
		
	}

	FREE_MATRIX(a);
	FREE_MATRIX(c);
	FREE_VECTOR(tau);
        FREE(locwork);
	
}

