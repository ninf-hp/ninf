#define _WRAPPER_
/* $Id: pdsygs2_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define DOUBLE
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n
#define ROW_b ldb
#define COL_b n
void  pdsygs2_ninf(	 int ibtype,
		 char uplo,
		 int n,
		 double global_a[],
		 int lda,
		 double global_b[],
		 int ldb,
		 int *info
)
/* "pdsygs2 reduces a real symmetric-definite generalized eigenproblem to standard form." */
/* OPTIONS */
{
	int maxldd;

	int maxlda;
	double *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
	int row_loca, col_loca;

	int maxldb;
	double *locb=NULL;
	int descb[DESCLEN];
	int desc_gb[DESCLEN];
	int row_locb, col_locb;

	INITIALIZE();

	SCALAR( "int", ibtype);
	SCALAR( "char", uplo);
	SCALAR( "int", n);
	SCALAR( "int", lda);
	SCALAR( "int", ldb);

	ROW( a);
	COL( a);
	ROW( b);
	COL( b);
	MAXLDD( maxldd, a );
	maxlda = maxldd;
	maxldb = maxldd;

	trMATRIX(uplo, "double", a, ROW_a, COL_a);
	trDISTRIBUTE(uplo, "double", a, ROW_a, COL_a);
	MATRIX( "double", b, ROW_b, COL_b);
	DISTRIBUTE( "double", b, ROW_b  , COL_b);

	if  (( mypnum != 0 ) ^ (serial==1) )
	  FortranCall(pdsygs2)( &ibtype, &uplo, &n,
                                loca, &one, &one, desca,
                                locb, &one, &one, descb,
                                &linfo);

	GATHER( "double", a, ROW_a  , COL_a);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
		*info = linfo;
	} else {
	}

	FREE_MATRIX(a);
	FREE_MATRIX(b);
	
}

