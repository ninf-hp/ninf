package ninf.nws;
import ninf.basic.*;
import ninf.metaserver.*;
import java.io.*;


public class MetaServerInitializerNWS implements MetaServerInitializer{
  static NinfLog dbg = new NinfLog("MetaServerInitializerNWS");

  static final String nameServerExecutable = "nws_memory";
    
  public void init(MetaServerConfig conf) throws NinfException {
    dbg.println("initializing nws related modules.");
    try {
      if (conf.NWSuse)
	conf.LPingerClass = Class.forName("ninf.nws.LPingerNWS");
    } catch (ClassNotFoundException e){
	e.printStackTrace();
      throw new ConfigureException("cannot get LPinger class for NWS");
    }

    // invoke nameserver (ifneeded)

    try {
	if (conf.NWSinvokeNameServer)
	    invokeNameServer(conf);
    } catch (IOException e){
	e.printStackTrace();
	throw new NinfIOException(e);
    }
  }

  void invokeNameServer(MetaServerConfig conf) throws IOException{
    String nameServer = conf.myhostname;
    Runtime runtime = Runtime.getRuntime();
    String NameServerArgs[] = new String[9];
    NameServerArgs[0] = conf.NWSdir + "/" + nameServerExecutable;
    NameServerArgs[1] = "-d";
    NameServerArgs[2] = conf.NWSMemoryDir;
    NameServerArgs[3] = "-N";
    NameServerArgs[4] = conf.NWSNameServer;
    NameServerArgs[5] = (conf.NWSMemoryErr == null)? "":"-e";
    NameServerArgs[6] = (conf.NWSMemoryErr == null)? "":conf.NWSMemoryErr;
    NameServerArgs[7] = (conf.NWSMemoryLog == null)? "":"-e";
    NameServerArgs[8] = (conf.NWSMemoryLog == null)? "":conf.NWSMemoryLog;
    for (int i = 0; i < NameServerArgs.length; i++)
	System.out.println(NameServerArgs[i]);

    Process NWSNameserver = runtime.exec(NameServerArgs);
  }
}
