#define _WRAPPER_
/* $Id: pcstein_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define _DISTRIBUTE_1D_
#define SCOMPLEX
#include <gscalapack.h>

#define ROW_z ldz
#define COL_z  m
static int worklen(int m, int n){
    int ret=1;
    int np00,mq00;
    ret = max(5*n,n*m) + m*n;
    if NEED_BUFF {
        np00 = Cnumroc( n, rbloc, 0, 0, nprow );
        mq00 = Cnumroc( m, cbloc, 0, 0, npcol );              
        ret = max(5*n,np00*mq00) + ceil(m,nprocs)*n;
    }
    return ret;
}

static	int iworklen(int n) {
    int ret=1;
    ret = 3*n+2;
    if NEED_BUFF ret = 3*n + nprocs + 1;
    return ret;
}

void  pcstein_ninf(	 int n,
		 float d[],
		 float e[],
		 int m,
		 float w[],
		 int iblock[],
		 int isplit[],
		 float orfac,
		 scomplex global_z[],
		 int ldz,
		 float global_work[],
		 int global_iwork[],
		 int ifail[],
		 int *info
)
/* "pcstein computes the eigenvectors of a symmetric tridiagonal matrix in parallel, using inverse iteration." */
/* OPTIONS */
{
	int maxldd;

	int maxldz;
	scomplex *locz=NULL;
	int descz[DESCLEN];
	int desc_gz[DESCLEN];
	int row_locz;
	int col_locz;

	int *locifail=NULL;
	int *iclustr=NULL;
	int *gap=NULL;

	float *locwork=NULL;
	int llocwork;
	int *lociwork=NULL;
	int llociwork;

	INITIALIZE();

	SCALAR( "int", n);
	SCALAR( "int", m);
	SCALAR("float",orfac);
	SCALAR("int",ldz);
	SIZE(n);

	iclustr=MALLOC(sizeof(int)*nprocs*2);  assert(iclustr);
	locifail=MALLOC(sizeof(int)*min(m,n)); assert(locifail);
	gap=MALLOC(sizeof(int)*nprocs);        assert(gap);

	ROW( z);
	COL( z);
	MAXLDD( maxldd, z );
	maxldz = maxldd;

	COMMON("float",w, min(m,n));
	COMMON("int", iblock, n);
	COMMON("int", isplit, n);
	COMMON( "float", d, n);
	COMMON( "float", e, n-1);

	MATRIX( "scomplex", z, ROW_z, COL_z);

	llocwork=worklen(m,n);
	_work("float",&locwork,llocwork);
	llociwork=iworklen(n);
	WORK(lociwork,llociwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pcstein)( &n, d, e, &m,
			       w,
			       iblock, isplit, &orfac,
			       locz, &one, &one, descz,
			       locwork, &llocwork,
			       lociwork, &llociwork,
			       ifail, iclustr, gap,
			       &linfo);

	GATHER( "scomplex", z, ROW_z  , COL_z);

	RETRIEVE("float", w, min(m,n));
	RETRIEVE("int", &linfo, 1);

	RETRIEVE("int", iclustr, nprocs*2);
	RETRIEVE("int", locifail, m);
	RETRIEVE("float", gap, nprocs);

	if( mypnum == 0 ){
		int i;
		*info = linfo;
		for(i=0;i<min(m,n);i++) ifail[i] = locifail[i];
	} else {

	}
        
	FREE_MATRIX(z);

        FREE(locwork);
        FREE(lociwork);
        
	FREE(iclustr);
        
        FREE(locifail);
	FREE(gap);

	FREE_COMMON(w);
	FREE_COMMON(isplit);
	FREE_COMMON(iblock);
	FREE_COMMON(d);
	FREE_COMMON(e);
}

