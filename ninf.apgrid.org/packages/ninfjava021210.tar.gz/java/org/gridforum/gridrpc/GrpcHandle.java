package org.gridforum.gridrpc;
import java.util.*;

public abstract class GrpcHandle{
    /**
     * call a remote library 
     * 
     * @param args paramters to be passed to the remote library 
     * @throws if activate method is not called first 
     */ 
    public abstract GrpcExecInfo call(List args) throws GrpcException;
    

    /**
     * cancel execution 
     */
    public abstract void cancel() throws GrpcException;


    /**
     * dispose handel 
     */
    public abstract void dispose() throws GrpcException;

    /**
     * call a remote library 
     * 
     * @param a1 one parameter 
     * @throws if activate method is not called first 
     */ 
    public GrpcExecInfo callWith(Object a1) 
	throws GrpcException{
	Vector arg = new Vector();
	arg.addElement(a1);
	return call(arg);
    }

    /**
     * call a remote library 
     * 
     * @param a1 first parameter 
     * @param a2 second parameter
     * @throws if activate method is not called first 
     */ 
    public GrpcExecInfo callWith(Object a1, Object a2) 
	throws GrpcException{
	Vector arg = new Vector();
	arg.addElement(a1);       arg.addElement(a2);
	return call(arg);
    }

    public GrpcExecInfo callWith(Object a1, Object a2, Object a3) 
	throws GrpcException{
	Vector arg = new Vector();
	arg.addElement(a1);  arg.addElement(a2); arg.addElement(a3);
	return call(arg);
    }

    public GrpcExecInfo callWith(Object a1, Object a2, Object a3, Object a4) 
	throws GrpcException{
	Vector arg = new Vector();
	arg.addElement(a1); arg.addElement(a2); arg.addElement(a3); arg.addElement(a4);
	return call(arg);
    }

    public GrpcExecInfo callWith(Object a1, Object a2, Object a3, Object a4, 
				 Object a5) 
	throws GrpcException{
	Vector arg = new Vector();
	arg.addElement(a1); arg.addElement(a2); arg.addElement(a3); arg.addElement(a4);
	arg.addElement(a5);
	return call(arg);
    }
    public GrpcExecInfo callWith(Object a1, Object a2, Object a3, Object a4, 
				 Object a5, Object a6) 
	throws GrpcException{
	Vector arg = new Vector();
	arg.addElement(a1); arg.addElement(a2); arg.addElement(a3); arg.addElement(a4);
	arg.addElement(a5); arg.addElement(a6);
	return call(arg);
    }
    public GrpcExecInfo callWith(Object a1, Object a2, Object a3, Object a4, 
				 Object a5, Object a6, Object a7) 
	throws GrpcException{
	Vector arg = new Vector();
	arg.addElement(a1); arg.addElement(a2); arg.addElement(a3); arg.addElement(a4);
	arg.addElement(a5); arg.addElement(a6); arg.addElement(a7);
	return call(arg);
    }
    public GrpcExecInfo callWith(Object a1, Object a2, Object a3, Object a4, 
				 Object a5, Object a6, Object a7, Object a8) 
	throws GrpcException{
	Vector arg = new Vector();
	arg.addElement(a1); arg.addElement(a2); arg.addElement(a3); arg.addElement(a4);
	arg.addElement(a5); arg.addElement(a6); arg.addElement(a7); arg.addElement(a8);
	return call(arg);
    }
    public GrpcExecInfo callWith(Object a1, Object a2, Object a3, Object a4, 
				 Object a5, Object a6, Object a7, Object a8,
				 Object a9)
	throws GrpcException{
	Vector arg = new Vector();
	arg.addElement(a1); arg.addElement(a2); arg.addElement(a3); arg.addElement(a4);
	arg.addElement(a5); arg.addElement(a6); arg.addElement(a7); arg.addElement(a8);
	arg.addElement(a9);
	return call(arg);
    }
    public GrpcExecInfo callWith(Object a1, Object a2, Object a3, Object a4, 
				 Object a5, Object a6, Object a7, Object a8,
				 Object a9, Object a10)
	throws GrpcException{
	Vector arg = new Vector();
	arg.addElement(a1); arg.addElement(a2); arg.addElement(a3); arg.addElement(a4);
	arg.addElement(a5); arg.addElement(a6); arg.addElement(a7); arg.addElement(a8);
	arg.addElement(a9);arg.addElement(a10);
	return call(arg);
    }
    public GrpcExecInfo callWith(Object a1, Object a2, Object a3, Object a4, 
				 Object a5, Object a6, Object a7, Object a8,
				 Object a9, Object a10, Object a11)
	throws GrpcException{
	Vector arg = new Vector();
	arg.addElement(a1); arg.addElement(a2); arg.addElement(a3); arg.addElement(a4);
	arg.addElement(a5); arg.addElement(a6); arg.addElement(a7); arg.addElement(a8);
	arg.addElement(a9);arg.addElement(a10);arg.addElement(a11);
	return call(arg);
    }

    public GrpcExecInfo callWith(Object a1, Object a2, Object a3, Object a4, 
				 Object a5, Object a6, Object a7, Object a8,
				 Object a9, Object a10, Object a11, Object a12) 
	throws GrpcException{
	Vector arg = new Vector();
	arg.addElement(a1); arg.addElement(a2); arg.addElement(a3); arg.addElement(a4);
	arg.addElement(a5); arg.addElement(a6); arg.addElement(a7); arg.addElement(a8);
	arg.addElement(a9);arg.addElement(a10);arg.addElement(a11);arg.addElement(a12);
	return call(arg);
    }

    public GrpcExecInfo callWith(Object a1, Object a2, Object a3, Object a4, 
				 Object a5, Object a6, Object a7, Object a8,
				 Object a9, Object a10, Object a11, Object a12,
				 Object a13)
	throws GrpcException{
	Vector arg = new Vector();
	arg.addElement(a1); arg.addElement(a2); arg.addElement(a3); arg.addElement(a4);
	arg.addElement(a5); arg.addElement(a6); arg.addElement(a7); arg.addElement(a8);
	arg.addElement(a9);arg.addElement(a10);arg.addElement(a11);arg.addElement(a12);
	arg.addElement(a13);
	return call(arg);
    }
    public GrpcExecInfo callWith(Object a1, Object a2, Object a3, Object a4, 
				 Object a5, Object a6, Object a7, Object a8,
				 Object a9, Object a10, Object a11, Object a12,
				 Object a13, Object a14)
	throws GrpcException{
	Vector arg = new Vector();
	arg.addElement(a1); arg.addElement(a2); arg.addElement(a3); arg.addElement(a4);
	arg.addElement(a5); arg.addElement(a6); arg.addElement(a7); arg.addElement(a8);
	arg.addElement(a9);arg.addElement(a10);arg.addElement(a11);arg.addElement(a12);
	arg.addElement(a13);arg.addElement(a14);
	return call(arg);
    }

    public GrpcExecInfo callWith(Object a1, Object a2, Object a3, Object a4, 
				 Object a5, Object a6, Object a7, Object a8,
				 Object a9, Object a10, Object a11, Object a12,
				 Object a13, Object a14, Object a15)
	throws GrpcException{
	Vector arg = new Vector();
	arg.addElement(a1); arg.addElement(a2); arg.addElement(a3); arg.addElement(a4);
	arg.addElement(a5); arg.addElement(a6); arg.addElement(a7); arg.addElement(a8);
	arg.addElement(a9);arg.addElement(a10);arg.addElement(a11);arg.addElement(a12);
	arg.addElement(a13);arg.addElement(a14);arg.addElement(a15);
	return call(arg);
    }

    public GrpcExecInfo callWith(Object a1, Object a2, Object a3, Object a4, 
				 Object a5, Object a6, Object a7, Object a8,
				 Object a9, Object a10, Object a11, Object a12,
				 Object a13, Object a14, Object a15, Object a16)
	throws GrpcException{
	Vector arg = new Vector();
	arg.addElement(a1); arg.addElement(a2); arg.addElement(a3); arg.addElement(a4);
	arg.addElement(a5); arg.addElement(a6); arg.addElement(a7); arg.addElement(a8);
	arg.addElement(a9);arg.addElement(a10);arg.addElement(a11);arg.addElement(a12);
	arg.addElement(a13);arg.addElement(a14);arg.addElement(a15);arg.addElement(a16);
	return call(arg);
    }

    public GrpcExecInfo callWith(Object a1, Object a2, Object a3, Object a4, 
				 Object a5, Object a6, Object a7, Object a8,
				 Object a9, Object a10, Object a11, Object a12,
				 Object a13, Object a14, Object a15, Object a16,
				 Object a17)
	throws GrpcException{
	Vector arg = new Vector();
	arg.addElement(a1); arg.addElement(a2); arg.addElement(a3); arg.addElement(a4);
	arg.addElement(a5); arg.addElement(a6); arg.addElement(a7); arg.addElement(a8);
	arg.addElement(a9);arg.addElement(a10);arg.addElement(a11);arg.addElement(a12);
	arg.addElement(a13);arg.addElement(a14);arg.addElement(a15);arg.addElement(a16);
	arg.addElement(a17);
	return call(arg);
    }
    public GrpcExecInfo callWith(Object a1, Object a2, Object a3, Object a4, 
				 Object a5, Object a6, Object a7, Object a8,
				 Object a9, Object a10, Object a11, Object a12,
				 Object a13, Object a14, Object a15, Object a16,
				 Object a17, Object a18)
	throws GrpcException{
	Vector arg = new Vector();
	arg.addElement(a1); arg.addElement(a2); arg.addElement(a3); arg.addElement(a4);
	arg.addElement(a5); arg.addElement(a6); arg.addElement(a7); arg.addElement(a8);
	arg.addElement(a9);arg.addElement(a10);arg.addElement(a11);arg.addElement(a12);
	arg.addElement(a13);arg.addElement(a14);arg.addElement(a15);arg.addElement(a16);
	arg.addElement(a17);arg.addElement(a18);
	return call(arg);
    }
    public GrpcExecInfo callWith(Object a1, Object a2, Object a3, Object a4, 
				 Object a5, Object a6, Object a7, Object a8,
				 Object a9, Object a10, Object a11, Object a12,
				 Object a13, Object a14, Object a15, Object a16,
				 Object a17, Object a18, Object a19)
	throws GrpcException{
	Vector arg = new Vector();
	arg.addElement(a1); arg.addElement(a2); arg.addElement(a3); arg.addElement(a4);
	arg.addElement(a5); arg.addElement(a6); arg.addElement(a7); arg.addElement(a8);
	arg.addElement(a9);arg.addElement(a10);arg.addElement(a11);arg.addElement(a12);
	arg.addElement(a13);arg.addElement(a14);arg.addElement(a15);arg.addElement(a16);
	arg.addElement(a17);arg.addElement(a18);arg.addElement(a19);
	return call(arg);
    }

    public GrpcExecInfo callWith(Object a1, Object a2, Object a3, Object a4, 
				 Object a5, Object a6, Object a7, Object a8,
				 Object a9, Object a10, Object a11, Object a12,
				 Object a13, Object a14, Object a15, Object a16,
				 Object a17, Object a18, Object a19, Object a20)
	throws GrpcException{
	Vector arg = new Vector();
	arg.addElement(a1); arg.addElement(a2); arg.addElement(a3); arg.addElement(a4);
	arg.addElement(a5); arg.addElement(a6); arg.addElement(a7); arg.addElement(a8);
	arg.addElement(a9);arg.addElement(a10);arg.addElement(a11);arg.addElement(a12);
	arg.addElement(a13);arg.addElement(a14);arg.addElement(a15);arg.addElement(a16);
	arg.addElement(a17);arg.addElement(a18);arg.addElement(a19);arg.addElement(a20);
	return call(arg);
    }
    public GrpcExecInfo callWith(Object a1, Object a2, Object a3, Object a4, 
				 Object a5, Object a6, Object a7, Object a8,
				 Object a9, Object a10, Object a11, Object a12,
				 Object a13, Object a14, Object a15, Object a16,
				 Object a17, Object a18, Object a19, Object a20,
				 Object a21)
	throws GrpcException{
	Vector arg = new Vector();
	arg.addElement(a1); arg.addElement(a2); arg.addElement(a3); arg.addElement(a4);
	arg.addElement(a5); arg.addElement(a6); arg.addElement(a7); arg.addElement(a8);
	arg.addElement(a9);arg.addElement(a10);arg.addElement(a11);arg.addElement(a12);
	arg.addElement(a13);arg.addElement(a14);arg.addElement(a15);arg.addElement(a16);
	arg.addElement(a17);arg.addElement(a18);arg.addElement(a19);arg.addElement(a20);
	arg.addElement(a21);
	return call(arg);
    }
    public GrpcExecInfo callWith(Object a1, Object a2, Object a3, Object a4, 
				 Object a5, Object a6, Object a7, Object a8,
				 Object a9, Object a10, Object a11, Object a12,
				 Object a13, Object a14, Object a15, Object a16,
				 Object a17, Object a18, Object a19, Object a20,
				 Object a21, Object a22)
	throws GrpcException{
	Vector arg = new Vector();
	arg.addElement(a1); arg.addElement(a2); arg.addElement(a3); arg.addElement(a4);
	arg.addElement(a5); arg.addElement(a6); arg.addElement(a7); arg.addElement(a8);
	arg.addElement(a9);arg.addElement(a10);arg.addElement(a11);arg.addElement(a12);
	arg.addElement(a13);arg.addElement(a14);arg.addElement(a15);arg.addElement(a16);
	arg.addElement(a17);arg.addElement(a18);arg.addElement(a19);arg.addElement(a20);
	arg.addElement(a21);arg.addElement(a22);
	return call(arg);
    }
    public GrpcExecInfo callWith(Object a1, Object a2, Object a3, Object a4, 
				 Object a5, Object a6, Object a7, Object a8,
				 Object a9, Object a10, Object a11, Object a12,
				 Object a13, Object a14, Object a15, Object a16,
				 Object a17, Object a18, Object a19, Object a20,
				 Object a21, Object a22, Object a23)
	throws GrpcException{
	Vector arg = new Vector();
	arg.addElement(a1); arg.addElement(a2); arg.addElement(a3); arg.addElement(a4);
	arg.addElement(a5); arg.addElement(a6); arg.addElement(a7); arg.addElement(a8);
	arg.addElement(a9);arg.addElement(a10);arg.addElement(a11);arg.addElement(a12);
	arg.addElement(a13);arg.addElement(a14);arg.addElement(a15);arg.addElement(a16);
	arg.addElement(a17);arg.addElement(a18);arg.addElement(a19);arg.addElement(a20);
	arg.addElement(a21);arg.addElement(a22);arg.addElement(a23);
	return call(arg);
    }

    public GrpcExecInfo callWith(Object a1, Object a2, Object a3, Object a4, 
				 Object a5, Object a6, Object a7, Object a8,
				 Object a9, Object a10, Object a11, Object a12,
				 Object a13, Object a14, Object a15, Object a16,
				 Object a17, Object a18, Object a19, Object a20,
				 Object a21, Object a22, Object a23, Object a24)
	throws GrpcException{
	Vector arg = new Vector();
	arg.addElement(a1); arg.addElement(a2); arg.addElement(a3); arg.addElement(a4);
	arg.addElement(a5); arg.addElement(a6); arg.addElement(a7); arg.addElement(a8);
	arg.addElement(a9);arg.addElement(a10);arg.addElement(a11);arg.addElement(a12);
	arg.addElement(a13);arg.addElement(a14);arg.addElement(a15);arg.addElement(a16);
	arg.addElement(a17);arg.addElement(a18);arg.addElement(a19);arg.addElement(a20);
	arg.addElement(a21);arg.addElement(a22);arg.addElement(a23);arg.addElement(a24);
	return call(arg);
    }
    public GrpcExecInfo callWith(Object a1, Object a2, Object a3, Object a4, 
				 Object a5, Object a6, Object a7, Object a8,
				 Object a9, Object a10, Object a11, Object a12,
				 Object a13, Object a14, Object a15, Object a16,
				 Object a17, Object a18, Object a19, Object a20,
				 Object a21, Object a22, Object a23, Object a24,
				 Object a25)
	throws GrpcException{
	Vector arg = new Vector();
	arg.addElement(a1); arg.addElement(a2); arg.addElement(a3); arg.addElement(a4);
	arg.addElement(a5); arg.addElement(a6); arg.addElement(a7); arg.addElement(a8);
	arg.addElement(a9);arg.addElement(a10);arg.addElement(a11);arg.addElement(a12);
	arg.addElement(a13);arg.addElement(a14);arg.addElement(a15);arg.addElement(a16);
	arg.addElement(a17);arg.addElement(a18);arg.addElement(a19);arg.addElement(a20);
	arg.addElement(a21);arg.addElement(a22);arg.addElement(a23);arg.addElement(a24);
	arg.addElement(a25);
	return call(arg);
    }
    public GrpcExecInfo callWith(Object a1, Object a2, Object a3, Object a4, 
				 Object a5, Object a6, Object a7, Object a8,
				 Object a9, Object a10, Object a11, Object a12,
				 Object a13, Object a14, Object a15, Object a16,
				 Object a17, Object a18, Object a19, Object a20,
				 Object a21, Object a22, Object a23, Object a24,
				 Object a25, Object a26)
	throws GrpcException{
	Vector arg = new Vector();
	arg.addElement(a1); arg.addElement(a2); arg.addElement(a3); arg.addElement(a4);
	arg.addElement(a5); arg.addElement(a6); arg.addElement(a7); arg.addElement(a8);
	arg.addElement(a9);arg.addElement(a10);arg.addElement(a11);arg.addElement(a12);
	arg.addElement(a13);arg.addElement(a14);arg.addElement(a15);arg.addElement(a16);
	arg.addElement(a17);arg.addElement(a18);arg.addElement(a19);arg.addElement(a20);
	arg.addElement(a21);arg.addElement(a22);arg.addElement(a23);arg.addElement(a24);
	arg.addElement(a25);arg.addElement(a26);
	return call(arg);
    }
    public GrpcExecInfo callWith(Object a1, Object a2, Object a3, Object a4, 
				 Object a5, Object a6, Object a7, Object a8,
				 Object a9, Object a10, Object a11, Object a12,
				 Object a13, Object a14, Object a15, Object a16,
				 Object a17, Object a18, Object a19, Object a20,
				 Object a21, Object a22, Object a23, Object a24,
				 Object a25, Object a26, Object a27)
	throws GrpcException{
	Vector arg = new Vector();
	arg.addElement(a1); arg.addElement(a2); arg.addElement(a3); arg.addElement(a4);
	arg.addElement(a5); arg.addElement(a6); arg.addElement(a7); arg.addElement(a8);
	arg.addElement(a9);arg.addElement(a10);arg.addElement(a11);arg.addElement(a12);
	arg.addElement(a13);arg.addElement(a14);arg.addElement(a15);arg.addElement(a16);
	arg.addElement(a17);arg.addElement(a18);arg.addElement(a19);arg.addElement(a20);
	arg.addElement(a21);arg.addElement(a22);arg.addElement(a23);arg.addElement(a24);
	arg.addElement(a25);arg.addElement(a26);arg.addElement(a27);
	return call(arg);
    }
    public GrpcExecInfo callWith(Object a1, Object a2, Object a3, Object a4, 
				 Object a5, Object a6, Object a7, Object a8,
				 Object a9, Object a10, Object a11, Object a12,
				 Object a13, Object a14, Object a15, Object a16,
				 Object a17, Object a18, Object a19, Object a20,
				 Object a21, Object a22, Object a23, Object a24,
				 Object a25, Object a26, Object a27, Object a28)
	throws GrpcException{
	Vector arg = new Vector();
	arg.addElement(a1); arg.addElement(a2); arg.addElement(a3); arg.addElement(a4);
	arg.addElement(a5); arg.addElement(a6); arg.addElement(a7); arg.addElement(a8);
	arg.addElement(a9);arg.addElement(a10);arg.addElement(a11);arg.addElement(a12);
	arg.addElement(a13);arg.addElement(a14);arg.addElement(a15);arg.addElement(a16);
	arg.addElement(a17);arg.addElement(a18);arg.addElement(a19);arg.addElement(a20);
	arg.addElement(a21);arg.addElement(a22);arg.addElement(a23);arg.addElement(a24);
	arg.addElement(a25);arg.addElement(a26);arg.addElement(a27);arg.addElement(a28);
	return call(arg);
    }
}
