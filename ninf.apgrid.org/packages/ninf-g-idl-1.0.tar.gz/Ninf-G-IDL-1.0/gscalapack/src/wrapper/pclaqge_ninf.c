#define _WRAPPER_
/* $Id: pclaqge_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define SCOMPLEX
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n
void  pclaqge_ninf(	 int m,
		 int n,
		 scomplex global_a[],
		 int lda,
		 float global_r[],
		 float global_c[],
		 float rowcnd,
		 float colcnd,
		 float amax,
		 char *equed
)
/* "pclaqge equilibrates a general M-by-N distributed matrix A using the row and scaling factors in the vectors R and C." */
/* OPTIONS */
{
	int maxldd;

	int maxlda;
	scomplex *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
	int row_loca, col_loca;

	float *locr=NULL;
	float *locc=NULL;
	char locequed[1];

	INITIALIZE();

	SCALAR( "int", m);
	SCALAR( "int", n);
	SCALAR( "float", rowcnd);
	SCALAR( "float", colcnd);
	SCALAR( "float", amax);
	SCALAR("int", lda);

	ROW( a);
	COL( a);
	MAXLDD( maxldd, a );
	maxlda = maxldd;

	MATRIX( "scomplex", a, ROW_a, COL_a);
	DISTRIBUTE( "scomplex", a, ROW_a  , COL_a);

	VECTOR( "r","float", r, ROW_a);
	vDISTRIBUTE( "r", "float", r, ROW_a);
	VECTOR( "c","float", c, COL_a);
	vDISTRIBUTE( "c", "float", c, COL_a);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pclaqge)( &m, &n,
                               loca, &one, &one, desca,
                               locr,
                               locc,
                               &rowcnd, &colcnd,
                               &amax,
                               locequed);

	GATHER( "scomplex", a, ROW_a, COL_a);
	RETRIEVE("int", &linfo, 1);
	RETRIEVE("char", locequed, 1);

	if( mypnum == 0 ){
	  *equed = locequed[0];
	} else {
	}

	FREE_MATRIX(a);

	
}

