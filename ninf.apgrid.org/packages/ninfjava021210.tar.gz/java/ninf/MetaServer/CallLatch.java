package ninf.MetaServer;
import ninf.basic.*;
import ninf.client.*;

import java.io.IOException;
import java.util.Vector;

public class CallLatch implements NinfCallable{
  NinfFunctionStruct func;
  NinfStub stub;
  FunctionManager manager;
  NinfPacket pkt;
  XDRInputStream is;
  XDROutputStream os;
  Vector buffers = new Vector();
  NinfServerConnection con;
  NinfLog dbg = new NinfLog(this);


  public CallLatch(NinfFunctionStruct func,  FunctionManager manager){
    this.func = func;
    this.stub = func.stub;
    this.manager = manager;
  }

  public void recieveNinfCode(NinfPacketInputStream is) throws NinfException {
    int i;
    if ((i = is.readInt()) != 1)
      dbg.println("Invalid code:"  + i);
    else
      dbg.println("get Ninf Call Code: " + i);
  }

  public Stoppable call(NinfPacket pkt, XDRInputStream is, XDROutputStream os) 
    throws NinfException {
    this.pkt = pkt;
    this.is = is;
    this.os = os;

    NinfPacket.getRpyCallPacket().write(os);
    NinfPacketInputStream pis = new NinfPacketInputStream(pkt, is);    
    recieveNinfCode(pis);

    stub.setupBuffers(buffers, pis);
    stub.serverReceive(buffers, pis);

    ServerIndex server = null;
    NinfServerConnection con = null;
    if (NinfFunction.locking)
      server = manager.getQue().getServerLock(func, 1);
    else
      server = manager.getQue().getProperServer(func, 1);
    System.err.println ("CallLatch call");
    if (server != null){
      try {
	con = server.server.connect();
	con.startForward(stub, server.index, buffers, is, os);
      } catch (NinfException e) {
	manager.removeNinfServer(server.server);
	throw e;
      } finally {
	server.server.loadDecrement();
      }
    }
    System.err.println ("CallLatch call");
    return con;
  }
}
