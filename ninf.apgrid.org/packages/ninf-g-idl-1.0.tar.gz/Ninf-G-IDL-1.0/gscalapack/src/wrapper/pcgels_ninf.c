#define _WRAPPER_
/* $Id: pcgels_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define SCOMPLEX
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n
#define ROW_b ldb
#define COL_b nrhs
static	int worklen(int m, int n, int nrhs) {
	  int ret=1;
	  int IROFFA, ICOFFA,  IAROW, IACOL, MpA0, NqA0;
	  int IROFFB, ICOFFB,  IBROW, IBCOL, MpB0, NpB0, NRHSqB0;
	  int LTAU, LWF, LWS, LCMP; 
#define MB_A rbloc
#define NB_A cbloc
#define MB_B rbloc
#define NB_B cbloc
#define RSRC_A 0
#define CSRC_A 0
#define RSRC_B 0
#define CSRC_B 0
#define NUMROC Cnumroc
#define MYROW myprow
#define MYCOL mypcol
          LWF= min(m,n)*(m+n+1);
          if (m>=n) LWS=max( n*n/2,(nrhs+m)*n)+n*n;
          else LWS=max(m*m/2,(n+max(n+n,m)+m*m));
          ret = min(m,n)+max(LWF,LWS);
	  if NEED_BUFF {
	    LCMP=lcm(nprow,npcol)/nprow;
	    IROFFA = MOD( IA-1, MB_A ); ICOFFA = MOD( JA-1, NB_A );
	    IAROW = INDXG2P( IA, MB_A, MYROW, RSRC_A, NPROW );
	    IACOL = INDXG2P( JA, NB_A, MYCOL, CSRC_A, NPCOL );
	    MpA0 = NUMROC( M+IROFFA, MB_A, MYROW, IAROW, NPROW );
	    NqA0 = NUMROC( N+ICOFFA, NB_A, MYCOL, IACOL, NPCOL );

	    IROFFB = MOD( IB-1, MB_B ); ICOFFB = MOD( JB-1, NB_B );
	    IBROW = INDXG2P( IB, MB_B, MYROW, RSRC_B, NPROW );
	    IBCOL = INDXG2P( JB, NB_B, MYCOL, CSRC_B, NPCOL );
	    MpB0 = NUMROC( M+IROFFB, MB_B, MYROW, IBROW, NPROW );
	    NpB0 = NUMROC( N+IROFFB, MB_B, MYROW, IBROW, NPROW );
	    NRHSqB0 = NUMROC( NRHS+ICOFFB, NB_B, MYCOL, IBCOL, NPCOL );

	    if (m >= n) {
	      LTAU = NUMROC( JA+MIN(M,N)-1, NB_A, MYCOL, CSRC_A, NPCOL );
	      LWF  = NB_A * ( MpA0 + NqA0 + NB_A );
	      LWS  = MAX( (NB_A*(NB_A-1))/2, (NRHSqB0 + MpB0)*NB_A ) +
		NB_A * NB_A;
		} else {
		  LTAU = NUMROC( IA+MIN(M,N)-1, MB_A, MYROW, RSRC_A, NPROW );
		  LWF  = MB_A * ( MpA0 + NqA0 + MB_A );
		  LWS  = MAX( (MB_A*(MB_A-1))/2, ( NpB0 + MAX( NqA0 +
							       NUMROC( NUMROC( N+IROFFB, MB_A, 0, 0, NPROW ), MB_A, 0, 0, LCMP ), NRHSqB0 ) )*MB_A ) +        MB_A * MB_A;
		}
	    ret = LTAU + MAX( LWF, LWS );
	  }
	  return ret;
}

void  pcgels_ninf(	 char trans,
		 int m,
		 int n,
		 int nrhs,
		 scomplex global_a[],
		 int lda,
		 scomplex global_b[],
		 int ldb,
		 scomplex work[],
		 int lwork,
		 int *info
)
/* "pcgels solves overdetermined or underdetermined complex linear systems involving an M-by-N matrix  A, or its transpose, using a QR or LQ factorization." */
/* OPTIONS */
{
extern void FortranCall(pcgels)( char*, int*, int*, int*,
                              scomplex*, int*, int*, int*,
                              scomplex*, int*, int*, int*,
                              scomplex*, int*, int*);
	int maxldd;

	int maxlda;
	scomplex *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];

	int maxldb;
	scomplex *locb=NULL;
	int descb[DESCLEN];
	int desc_gb[DESCLEN];

	int row_loca, col_loca;
	int row_locb, col_locb;

	scomplex *locwork=NULL;
	int llocwork;

	INITIALIZE();

	SCALAR( "char", trans);
	SCALAR( "int", m);
	SCALAR( "int", n);
	SCALAR( "int", nrhs);
	SCALAR("int",lda);
	SCALAR("int",ldb);
        SCALAR( "int", lwork);

	ROW( a);
	COL( a);
	ROW( b);
	COL( b);

	MAXLDD( maxldd, a );
	maxlda = maxldd;
	maxldb = maxldd;

	MATRIX( "scomplex", a, ROW_a, COL_a);
	MATRIX( "scomplex", b, ROW_b, COL_b);
	DISTRIBUTE( "scomplex", a, ROW_a  , COL_a);
	DISTRIBUTE( "scomplex", b, ROW_b  , COL_b);

	llocwork=worklen(m,n,nrhs);
	llocwork = max(llocwork, lwork);
	WORK( locwork, llocwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pcgels)( &trans, &m, &n, &nrhs,
                              loca, &one, &one, desca,
                              locb, &one, &one, descb,
                              locwork, &llocwork, &linfo);

	GATHER( "scomplex", a, ROW_a  , COL_a);
	GATHER( "scomplex", b, ROW_b  , COL_b);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
		*info = linfo;
	} else {
	}

	FREE_MATRIX(a);
	FREE_MATRIX(b);
        FREE(locwork);
	
}

