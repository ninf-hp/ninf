#define _WRAPPER_
/* $Id: pcposvx_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define SCOMPLEX
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n
#define ROW_af ldaf
#define COL_af n
#define ROW_b ldb
#define COL_b nrhs
#define ROW_x ldx
#define COL_x nrhs
#define NB cbloc
#define MB rbloc
#define LOCc_a(n) Cnumroc( (n), NB, mypcol, 0, npcol)
#define LOCr_a(m) Cnumroc( (m), MB, myprow, 0, nprow)
#define LOCc_b(n) Cnumroc( (n), NB, mypcol, 0, npcol)
#define LOCr_b(m) Cnumroc( (m), MB, myprow, 0, nprow)
static	int worklen(int n, int maxldd) {
	  int ret=1;
	  int pcpocon, pcporfs;
          pcpocon = 2*n+max(2,2*n);
          pcporfs = 2*n;
          ret = max(3*maxldd,
                    max( pcpocon, pcporfs )+  COL_a);
          
	  if NEED_BUFF {
	    pcpocon =  2*LOCr(N+MOD(IA-1,MB_A)) +
	      MAX( 2, MAX(NB_A*MAX(1,CEIL(NPROW-1,NPCOL)),LOCc(N+MOD(JA-1,NB_A)) +
			  NB_A*MAX(1,CEIL(NPCOL-1,NPROW))) );
	    pcporfs = 2*LOCr( N + MOD( IA-1, MB_A ) );
	    ret = max(3*maxldd,
		      max( pcpocon, pcporfs )+ LOCr_a( COL_a ));
	  }
	  return ret;
}

static	int rworklen(int n) {
	  int ret=1;
          ret = 2*COL_a;
          if NEED_BUFF 
	    ret = 2*LOCc_a(COL_a);
          
	  return ret;
}


void  pcposvx_ninf(	 char fact,
		 char uplo,
		 int n,
		 int nrhs,
		 scomplex global_a[],
		 int lda,
		 scomplex global_af[],
		 int ldaf,
		 char *equed,
		 scomplex global_sr[],
		 scomplex global_sc[],
		 scomplex global_b[],
		 int ldb,
		 scomplex global_x[],
		 int ldx,
		 float *rcond,
		 float global_ferr[],
		 float global_berr[],
		 scomplex global_work[],
		 float global_rwork[],
		 int *info
)
/* "pcposvx uses the Cholesky factorization A = U**H*U or A = L*L**H to compute the solution to a complex system of linear equations A * X = B, where A is an N-by-N matrix and X and B are N-by-NRHS matrices." */
/* OPTIONS */
{
    extern void FortranCall(pcposvx)( char*, char*, int*, int*,
				      scomplex*, int*, int*, int*,
				      scomplex*, int*, int*, int*,
				      char*,
				      scomplex*, scomplex*,
				      scomplex*, int*, int*, int*,
				      scomplex*, int*, int*, int*,
				      float*,
				      float*, float*,
				      scomplex*, int*,
				      float*, int*,
				      int*);

	int maxldd;

	int maxlda;
	scomplex *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];

	int maxldaf;
	scomplex *locaf=NULL;
	int descaf[DESCLEN];
	int desc_gaf[DESCLEN];

	int maxldb;
	scomplex *locb=NULL;
	int descb[DESCLEN];
	int desc_gb[DESCLEN];

	float locrcond[1];

        scomplex *locsr=NULL, *locsc=NULL;

	int maxldx;
	scomplex *locx=NULL;
	int descx[DESCLEN];
	int desc_gx[DESCLEN];

	float *locferr=NULL;
	float *locberr=NULL;

        scomplex *locwork=NULL;
	int llocwork;
        float *locrwork=NULL;
	int llocrwork;

	int row_loca, col_loca;
	int row_locaf, col_locaf;
	int row_locb, col_locb;
	int row_locx, col_locx;

	INITIALIZE();

	SCALAR( "char", fact);
	SCALAR( "char", uplo);
	SCALAR( "int", n);
	SCALAR( "int", nrhs);
	SCALAR("int", lda);
	SCALAR( "int", ldaf);
	SCALAR( "int", ldb);
	SCALAR( "int", ldx);

	COMMON( "char", equed, 1);

	ROW( a);
	COL( a);
	ROW( af);
	COL( af);
	ROW( b);
	COL( b);
	ROW( x);
	COL( x);
	MAXLDD( maxldd, a);
	maxlda = maxldd;
	maxldaf = maxldd;
	maxldb = maxldd;
	maxldx = maxldd;

	MATRIX( "scomplex", a, ROW_a, COL_a);
	MATRIX( "scomplex", af, ROW_af, COL_af);
	MATRIX( "scomplex", b, ROW_b, COL_b);
	MATRIX( "scomplex", x, ROW_x, COL_x);
        VECTOR("r", "scomplex", sr, ROW_a);
        VECTOR("c", "scomplex", sc, COL_a);
	VECTOR( "c", "float", ferr, COL_b);
	VECTOR( "c", "float", berr, COL_b);

	DISTRIBUTE( "scomplex", a, ROW_a  , COL_a);
	DISTRIBUTE( "scomplex", b, ROW_b  , COL_b);
	vDISTRIBUTE( "r", "scomplex", sr, ROW_a);
	vDISTRIBUTE( "c", "scomplex", sc, COL_a);

        llocwork = worklen(n, maxldd);
        WORK(locwork, llocwork);
        llocrwork = rworklen(n);
        _work("float",&locrwork,llocrwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pcposvx)( &fact, &uplo, &n, &nrhs,
			       loca, &one, &one, desca,
			       locaf, &one, &one, descaf,
			       equed,
			       locsr, locsc,
			       locb, &one, &one, descb,
			       locx, &one, &one, descx,
			       locrcond,
			       locferr, locberr,
			       locwork, &llocwork,
			       locrwork, &llocrwork,
			       &linfo);

	GATHER( "scomplex", a, ROW_a  , COL_a);
	GATHER( "scomplex", af, ROW_af  , COL_af);
	GATHER( "scomplex", b, ROW_b  , COL_b);
	GATHER( "scomplex", x, ROW_x  , COL_x);
	vGATHER("r","scomplex", sr, ROW_a);
	vGATHER("c","scomplex", sc, ROW_a);
	vGATHER("c", "float", ferr, COL_b);
	vGATHER("c", "float", berr, COL_b);
	RETRIEVE( "char", equed, 1);
	RETRIEVE("float", locrcond, 1);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
		*info = linfo;
		*rcond = *locrcond;
	} else {
	}

	FREE_MATRIX(a);
	FREE_MATRIX(af);
	FREE_MATRIX(b);
	FREE_MATRIX(x);
        
	FREE_VECTOR(sr);
	FREE_VECTOR(sc);
	FREE_VECTOR(ferr);
	FREE_VECTOR(berr);

        FREE(locwork);
        FREE(locrwork);

	FREE_COMMON(equed);
}

