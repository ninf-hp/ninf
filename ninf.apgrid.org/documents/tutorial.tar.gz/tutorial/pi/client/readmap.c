#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ninf.h"
#define MAX_LEN 1000

/** returns number of hosts */
int read_map_file(char * filename, char *** hosts, int ** ports, char * entry){
  FILE * fp;
  char buffer[MAX_LEN];
  int counter = 0, i = 0;

  if ((fp = fopen(filename, "r")) == NULL){
    fprintf(stderr, "cannot open file: %s\n", filename);
    perror("fopen:");
    exit(2);
  }
  while (fgets(buffer, MAX_LEN, fp) != NULL){
    if (buffer[0] != '#') {
      if (strtok(buffer, " \t\n") != NULL) 
	counter++;
    }
  }
  rewind(fp);
  *hosts = (char **)malloc(sizeof(char *) * counter);
  *ports = (int *)malloc(sizeof(int) * counter);
  while (fgets(buffer, MAX_LEN, fp) != NULL){
    if (buffer[0] != '#'){
      char * host;
      int    port;
      int types[30];
      char entry_buffer[MAX_LEN];
      struct ninf_stub_information * p;

      host = strtok(buffer, " \t\n");
      if (host == NULL) continue;
      port = atoi(strtok(NULL, " \t\n"));
      
      sprintf(entry_buffer, "ninf://%s:%d/%s", host, port, entry); 
      if (Ninf_get_stub(entry_buffer, types, &p) == NINF_OK) {
	*((*hosts) + i) = strdup(host);
	*((*ports) + i) = port;
	i++;
      }
    }
  }
  return i;
}
