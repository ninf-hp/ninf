#include <stdio.h>
#include <math.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/timeb.h>

#define N 3

double A[N][N],B[N][N],C[N][N],D[N][N],E[N][N],F[N][N],G[N][N],G0[N][N];

main(int argc, char* argv[])
{
  int i,j,k,r;
  struct timeb s, e;
  int m;
  {
    extern int ninf_debug_flag;
    ninf_debug_flag = 1;
  }

  
  m = (argc > 1);
  for(i = 0; i < N; i++) {
    for(j = 0; j < N; j++) {
      A[i][j] = rand(); 
/*      A[i][j] = (i == j)? 1.0 : 0.0; */
      B[i][j] = (i == j)? 1.0 : 0.0;
      C[i][j] = (i == j)? 1.0 : 0.0;
      D[i][j] = (i == j)? 1.0 : 0.0;
      E[i][j] = 0;
      F[i][j] = 0;
      G[i][j] = 0;
    }
  }

  if (m) {
    Ninf_check_in();
  }
  ftime(&s);

  if (!m) {
    ftime(&e);
    if (e.millitm > s.millitm) {
      printf("time: %ld.%hu\n", e.time - s.time, e.millitm - s.millitm);
    } else {
      printf("time: %ld.%hu\n", e.time - s.time - 1, 1000 + e.millitm - s.millitm);
    }
  }


  if ((r = Ninf_call("mmul",N,A,B,E)) != 1) printf("error\n");
  if ((r = Ninf_call("mmul",N,C,D,F)) != 1) printf("error\n");
  if ((r = Ninf_call("mmul",N,E,F,G)) != 1) printf("error\n");


/*  if ((r = Ninf_call("mmul",N,A,B,G)) != 1) printf("error\n"); */
  if (m) {
    Ninf_check_out();
    ftime(&e);
    if (e.millitm > s.millitm) {
      printf("time: %ld.%hu\n", e.time - s.time, e.millitm - s.millitm);
    } else {
      printf("time: %ld.%hu\n", e.time - s.time - 1, 1000 + e.millitm - s.millitm);
    }
  }
  
  printf("Ninf_call:mmul r = %d\n",r);
/*  mmul(N,A,B,E);
  mmul(N,C,D,F);
  mmul(N,E,F,G0);
*/
  mmul(N,A,B,G0);

  for(i = 0; i < N; i++) {
    for(j = 0; j < N; j++) {
/*      if(G[i][j] - G0[i][j] < 0.00001) { */
      for (k = 7; k >= 0; k--)
	printf("%02x ", *((unsigned char *)(&(G[i][j])) + k));
      printf("\n");
      for (k = 7; k >= 0; k--)
	printf("%02x ", *((unsigned char *)(&(G0[i][j])) + k));
      printf("\n");

	printf("G[%d][%d]= %e != %e\n",
	       i,j,G[i][j],G0[i][j]);
/*      } */
    }
  }
  exit(0);
}


/* test routine */
mmul(int n,double * A,double * B,double * C)
{
  double t;
  int i,j,k;
  
  printf("n0=%d\n",n);
  printf("A0(10,5)=%e\n",A[10*n+5]);
  printf("B0(10,5)=%e\n",B[10*n+5]);
  for (i=0;i<n;i++) {
    for (j=0;j<n;j++) {
      t = 0;
      for (k=0;k<N;k++){
	t += A[i*n + k] * B[k*n+j];	/* inner product */
      }
      C[i*n+j] = t;
    }
  }
  printf("C0(10,5)=%e\n",C[10*n+5]);
}

