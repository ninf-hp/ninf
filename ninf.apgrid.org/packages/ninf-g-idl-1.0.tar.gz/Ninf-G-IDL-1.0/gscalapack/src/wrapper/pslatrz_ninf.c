#define _WRAPPER_
/* $Id: pslatrz_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define FLOAT
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n
static	int worklen(int m, int n) {
	  int ret=1;
	  int IROFF, ICOFF, IAROW, IACOL, Mp0, Nq0;
	  ret = n+max(1,m);
	  if NEED_BUFF {
	    IROFF = MOD( IA-1, MB_A );
	    ICOFF = MOD( JA-1, NB_A );
	    IAROW = INDXG2P( IA, MB_A, MYROW, RSRC_A, NPROW );
	    IACOL = INDXG2P( JA, NB_A, MYCOL, CSRC_A, NPCOL );
	    Mp0   = NUMROC( M+IROFF, MB_A, MYROW, IAROW, NPROW );
	    Nq0   = NUMROC( N+ICOFF, NB_A, MYCOL, IACOL, NPCOL );
	    ret = Nq0 + MAX( 1, Mp0 );
	  }
	  return ret;
}


void  pslatrz_ninf(	 int m,
		 int n,
		 int l,
		 float global_a[],
		 int lda,
		 float global_tau[],
		 float work[]
)
/* "pslatrz reduces the M-by-N ( M<=N ) real upper trapezoidal matrix A to upper triangular form by means of orthogonal transformations." */
/* OPTIONS */
{
	int maxldd;

	int maxlda;
	float *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
	int row_loca, col_loca;

	float *loctau=NULL;

	float *locwork=NULL;
	int llocwork;

	INITIALIZE();

	SCALAR( "int", m);
	SCALAR( "int", n);
	SCALAR( "int", l);
	SCALAR("int", lda);

	ROW( a);
	COL( a);
	MAXLDD( maxldd, a );
	maxlda = maxldd;

	MATRIX( "float", a, ROW_a, COL_a);
	VECTOR( "r","float",  tau, m);
	DISTRIBUTE( "float", a, ROW_a  , COL_a);

	llocwork = worklen(m,n);
	WORK(locwork,llocwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pslatrz)( &m, &n, &l,
                               loca, &one, &one, desca,
                               loctau,
                               locwork);

	GATHER( "float", a, ROW_a, COL_a);
	vGATHER("r","float", tau, m);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
	} else {
	}

	FREE_MATRIX(a);
        FREE(locwork);
}

