package ninf.netsolve;
public class GlobalDefs {
  public final static int DATA_RAW        = 0;
  public final static int DATA_XDR        = 1;

  public final static int LANG_C          = 0;
  public final static int LANG_FORTRAN    = 1;

  public final static int NOT_CHECKED = 0;
  public final static int FILE_INPUT  = 1;
  public final static int DATA_INPUT  = 2;
  public final static int URL_INPUT   = 3;

  public final static int LINEAR_FAILED = -1;
  public final static int BAD_DIMENSION = -2;
  public final static int NO_SOLUTION   = -3;
  public final static int BAD_VALUES    = -4;

  public final static int SV_PORT         = 2222;
  public final static int AG_PORT         = 2223;

  public final static int MATLAB_PROG     = 1;
  public final static int C_PROG          = 2;
  public final static int FORTRAN_PROG    = 3;
  public final static int JAVA_PROG       = 4;

  public final static int STOPPED         = 0;
  public final static int FAILED          = -1;
  public final static int INVALID_CODE    = -1;
  public final static int NO_SUCH_PB      = -2;
  public final static int BAD_INPUT       = -3;
  public final static int BAD_OUTPUT      = -4;
  public final static int BAD_UPF         = -5;
  public final static int DM_MISMATCH     = -6;
  public final static int BAD_COMPLEXITY  = -7;
  public final static int NO_SUCH_FORMAT  = -8;
  public final static int CORRECT_PB      = 0;
  public final static int PROBLEM_REQUEST = 1;
  public final static int PROBLEM_SOLVE   = 2;
  public final static int FAILURE_REPORT  = 3;
  public final static int I_AM_NEW        = 4;
  public final static int I_EXIST         = 5;
  public final static int I_DIE           = 6;
  public final static int YOU_ARE_NEW     = 7;
  public final static int WRONG_PROBLEM   = 8;
  public final static int PB_REFUSED      = 9;
  public final static int SV_FAILURE      = 10;
  public final static int PB_ACCEPTED     = 11;
  public final static int PB_NO_SOL       = 12;
  public final static int SOLUTION        = 13;
  public final static int WORKLOAD        = 14;
  public final static int DISTANCE_REPORT = 15;
  public final static int DISTANCE_REQUEST= 16;
  public final static int CLIENT_F_REPORT = 17;
  public final static int INFO_REQUEST    = 18;
  public final static int END_COMP        = 19;
  public final static int JOB_COMPLETED   = 20;
  public final static int ALIVE           = 21;
  public final static int ARE_YOU_ALIVE   = 22;
  public final static int DESC_REQUEST    = 23;
  public final static int IS_ALIVE        = 24;
  public final static int WHO_ARE_YOU     = 25;
  public final static int UPF_OK          = 26;
  public final static int UPF_FAILED      = 27;
  public final static int UPF_UNSAFE      = 28;
  public final static int PONG_LATENCY    = 29;
  public final static int PONG_BANDWIDTH  = 30;
  public final static int POLL_CONTACT    = 100;
  public final static int POLL_LIST_PB    = 110;
  public final static int POLL_LIST_SV    = 120;
  public final static int POLL_GET_PB     = 130;
  public final static int POLL_GET_SV     = 140;
  public final static int POLL_STAT       = 150;
  public final static int POLL_KILL       = 160;
}
