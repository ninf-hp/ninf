package ninf.toNs;
import ninf.basic.*;
import ninf.client.*;
import ninf.cproxy.*;
import ninf.netsolve.*;
import java.io.*;

class ProblemCache extends CallableCache {
  static NinfLog dbg = new NinfLog("ProblemCache");
  String agent;

  ProblemCache(String agent) throws NinfException{
    super();
    this.agent = agent;
    getProblems(agent);
  }

  void getProblems(String agent) throws NinfException {
    try {
      GetProblems getter = new GetProblems(agent);
      Problem problems[] = getter.getAllProblems();
      //            Problem problems[] = new Problem[1];
      //            problems[0] = getter.getOneProblem("totaltest");
      //      problems[1] = getter.getOneProblem("dgtsv");
      //      problems[2] = getter.getOneProblem("dmatmul");

      for (int i = 0; i < problems.length; i++){
	dbg.println("try to register "+ problems[i].name);
	int index = getIndex();
	Callable callable;
	try {
	  callable = new NetSolveLatch(problems[i], index, agent);
	} catch (NinfException e){
	  dbg.log(problems[i].name + " is not registered");
	  continue;
	}
	FunctionName name = new FunctionName("NetSolve", problems[i].name);
	registerCallable(name, callable, index);
	
	dbg.log(name + " is registered");
      }
    } catch (NetSolveException e){
      throw new NinfNetSolveException(e);
    }
  } 
}
