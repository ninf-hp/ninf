#include <stdio.h>
#define CONV_USE_XDR

#include <stdlib.h>
#include <string.h>
#include "ninf_macros.h"
#include "ninf_data_trans.h"
#include "ninf_error.h"

struct ninf_param_desc * new_ninf_param_desc(int num);

int xdr_data_length[] = 
{
    0, /* UNDEF */
    0, /* VOID, */
    1, /* CHAR,*/
    2, /* SHORT,*/
    4, /* INT,*/
    4, /* LONG,*/
    8, /* LONGLONG,*/
    4, /* UNSIGNED_CHAR,*/
    4, /* UNSIGNED_SHORT,*/
    4, /* UNSIGNED,*/
    4, /* UNSIGNED_LONG,*/
    8, /* UNSIGNED_LONGLONG,*/
    4, /* FLOAT,*/
    8, /* DOUBLE,*/
    16, /* LONG_DOUBLE,*/
    0, /* STRING_TYPE,*/
    0, /* FUNC_TYPE,*/
    8, /* SCOMPLEX */
    16, /* DCOMPLEX */
    0, /* BASIC_TYPE_END*/
};

int do_onemore(dataTrans * dt){
  if (dt->flag == XDR_ENCODE) 
    return write_flush(dt);
  else 
    return read_onemore(dt);
}

void print_dt(dataTrans * dt){
  printf("%x: %x-%d-%x-%d-%x-%d-%x\n", dt, dt->start, dt->position - dt->start, dt->position, dt->valid_end - dt->position, dt->valid_end, dt->end - dt->valid_end, dt->end);
}

int isSend(dataTrans *dt){
  return (dt->flag == XDR_ENCODE);
}
int isReceive(dataTrans *dt){
  return (dt->flag == XDR_DECODE);
}

int trans_count(dataTrans *dt){
  if (dt->flag == XDR_ENCODE)
    return(dt->position - dt->start);
  return(dt->valid_end - dt->position);
}

#define SOCK_BUF_SIZE 0x10000

connection * new_connection(int fd, int withHeader){
  connection * tmp;
  int size = SOCK_BUF_SIZE;

  if ((tmp = (connection *)malloc(sizeof(connection))) == NULL)
    return NULL;
  tmp->sDT = new_dataTrans(fd, XDR_ENCODE, withHeader);
  tmp->rDT = new_dataTrans(fd, XDR_DECODE, withHeader);

  setsockopt(fd, SOL_SOCKET, SO_SNDBUF, (char *)&size, sizeof(int));
  setsockopt(fd, SOL_SOCKET, SO_RCVBUF, (char *)&size, sizeof(int));

  if (tmp->rDT == NULL || tmp->sDT == NULL)
    return NULL;
  return tmp;
}

int ninf_disconnect(connection * con){
  if (close(con->rDT->fd) < 0)
    perror("close in ninf_disconnect: ");
  return 0;
}

int connection_get_fd(connection * con){
  if (con == NULL)
    return -1;
  return con->rDT->fd;
}

/***************************************/
dataTrans * new_dataTrans(int fd, int flag, int withHeader){
  dataTrans * tmp;
  if ((tmp = (dataTrans *)malloc(sizeof(dataTrans))) == NULL)
    return NULL;
  tmp->start = tmp->buffer;
  tmp->position = tmp->start;
  tmp->valid_end = tmp->start;
  tmp->end = tmp->start + STUB_BUF_SIZE;
  tmp->fd = fd;
  tmp->flag = flag;
  tmp->withHeader = withHeader;
  tmp->dying = FALSE;
/*
  {
    long flag;
    flag = fcntl(fd, F_GETFL);
    
    ninf_error("fd %d: no-blocking flag is %s", fd, ((flag & O_NONBLOCK) == 0)? "FALSE":"TRUE");

  }
*/
  return tmp;
}

void force_write_with(dataTrans *dt, int sock, int code, int arg1, int arg2){
  dt->decoded.code = code;
  dt->decoded.arg1 = arg1;
  dt->decoded.arg2 = arg2;
  force_write(dt, sock, TRUE);
}

void force_write(dataTrans *dt, int sock, int headerFlag){
  int RWFlagBack = dt->flag;
  int headerFlagBack = dt->withHeader;
  int fdBack = dt->fd;
  dt->flag = XDR_ENCODE;
  dt->withHeader = headerFlag;
  dt->fd = sock;
  dt->position = dt->valid_end;
  write_flush(dt);
  dt->fd = fdBack;
  dt->valid_end = dt->start;
  dt->flag = RWFlagBack;
  dt->withHeader = headerFlagBack;
}

void trans_flush(dataTrans * dt, int code, int arg1, int arg2){
  dt->decoded.code = code;
  dt->decoded.arg1 = arg1;
  dt->decoded.arg2 = arg2;
  write_flush(dt);
}

void set_trans_header(dataTrans * dt, int code, int arg1, int arg2){
  dt->decoded.code = code;
  dt->decoded.arg1 = arg1;
  dt->decoded.arg2 = arg2;
}

void trans_destroy(dataTrans * dt){
  if (dt->flag == XDR_ENCODE)
    write_flush(dt);
}

#ifdef linux
#define READ_FAIL 0
#else
#define READ_FAIL 0
#endif  

int timeout(int fd, int sec, int usec){
    fd_set rfds;
    int n;
    struct timeval timeoutval;
    timeoutval.tv_sec = sec;
    timeoutval.tv_usec = usec;

    FD_ZERO(&rfds);
    FD_SET(fd, &rfds);
    n = select(fd + 1, &rfds, NULL, NULL, &timeoutval);
    if (n == 0)
      return TRUE;
    return FALSE;
}

int read_stick(int fd, char * buffer, int bytes, int dying){
  int count = 0, tmp;
  while (count < bytes){
#ifndef WIN32
    if (dying)
      if (timeout(fd, 1, 0))
	return 0;
    if ((tmp = read(fd, buffer, bytes - count)) <= READ_FAIL)
      return count;
#else
    if ((tmp = recv(fd, buffer, bytes - count, NO_FLAGS_SET)) < 0)
      return count;
#endif
    count += tmp;
    buffer += tmp;
  }
  return count;
}

/*
FILE * stub_out = stdout;
FILE * stub_err = stderr;
*/
FILE * stub_out = NULL;
FILE * stub_err = NULL;

char outerr_buffer[MAX_PKT_LEN];
handle_outerr(dataTrans * dt){
  int len, readed, i;
  FILE * fp;
  if (stub_out == NULL)
    stub_out = stdout;
  if (stub_err == NULL)
    stub_out = stderr;

  len = dt->decoded.size - NINF_PKT_HEADER_SIZE;

  if ((readed = read_stick(dt->fd, outerr_buffer, len, dt->dying)) < len){
    if (ninf_debug_flag)
      fprintf(stderr, "readed = %d, len = %d\n", readed, len);

    return FALSE;   /* what to do */
  }
  if (NINF_PKT_CODE(&(dt->decoded)) == NINF_PKT_STDOUT)
    fp = stub_out;
  else
    fp = stub_err;
  for (i = 0; i < readed; i++)
    putc(outerr_buffer[i], fp);
  fflush(fp);
}

int read_onemore(dataTrans * dt){
  int offset = 0;
  int len, readed;
  if (dt->withHeader){
    char tbuf[NINF_PKT_HEADER_SIZE];
    if (read_stick(dt->fd, tbuf, NINF_PKT_HEADER_SIZE, dt->dying) < NINF_PKT_HEADER_SIZE)
      return FALSE;
    reorder_header_inner(tbuf, &(dt->decoded));
    ninf_error_code = NINF_PKT_ARG1(&(dt->decoded));
    len = dt->decoded.size - NINF_PKT_HEADER_SIZE;
    if ((NINF_PKT_CODE(&(dt->decoded)) == NINF_PKT_STDOUT) ||
	(NINF_PKT_CODE(&(dt->decoded)) == NINF_PKT_STDERR)){
      if (ninf_debug_flag)
	fprintf(stderr, "stdout forwarded\n");
      handle_outerr(dt);
      return read_onemore(dt);
    } else if (NINF_PKT_CODE(&(dt->decoded)) == NINF_PKT_ERROR){
      return FALSE;
    }
  }
  if (dt->valid_end > dt->position){
    offset = dt->valid_end - dt->position;
    memcpy(dt->start, dt->position, offset);
  }
  dt->position = dt->start + offset;
  if (dt->withHeader){
    if ((readed = read_stick(dt->fd, dt->position, len, dt->dying)) < len)
      return FALSE;
  } else {
    if ((readed = read(dt->fd, dt->position, STUB_BUF_SIZE - offset)) <= READ_FAIL){
      dt->valid_end = dt->position;
      dt->position = dt->start;
      return FALSE;
    }
  }

  dt->valid_end = dt->position + readed;
  dt->position = dt->start;
  if (ninf_debug_flag)
    ninf_error("READ : %d\n", readed);
  return TRUE;
}

int write_flush(dataTrans * dt){
  int tmp, size;
  int i;
  char * startPoint;
  if (dt->withHeader){
    dt->decoded.size = dt->position - dt->start + NINF_PKT_HEADER_SIZE;
    reorder_header_network(&(dt->decoded), dt->header);
    startPoint = dt->header;
    if(ninf_debug_flag) printf("write size = %d, code = %d, arg1 = %d, arg2 = %d\n", dt->decoded.size, dt->decoded.code, dt->decoded.arg1, dt->decoded.arg2);
  }else
    startPoint = dt->start;
  size = dt->position - startPoint;

#ifndef WIN32

  tmp = write(dt->fd, startPoint, dt->position - startPoint);

#else
  {
    tmp = send(dt->fd, startPoint, dt->position - startPoint, NO_FLAGS_SET);
  }
#endif

  if(ninf_debug_flag) ninf_error("write result: %d\n", tmp);
  dt->position = dt->start;
  if (tmp < 0)
    return FALSE;
  return TRUE;
}

/* returns a pointer points VOLATILE string.
   User must copy the string before calling the next dataTrans 
   functions. */
char * read_line_dataTrans(dataTrans * dt){
  char * ans = NULL;
  char * tmp;
  int proceed = 0;
  for (;;){
    for (tmp = dt->position; tmp < dt->valid_end - 1; tmp++){
      if (*tmp == 0x0d) {
	if (*(tmp+1) == 0x0a)
	  proceed = 2;
	else
	  proceed = 1;
	*tmp = 0x0;
	ans = dt->position;
	dt->position = tmp + proceed;
	return ans;
      } else if (*tmp == 0x0a) {
	proceed = 1;
	*tmp = 0x0;
	ans = dt->position;
	dt->position = tmp + proceed;
	return ans;
      }
    }
    if (!read_onemore(dt)){
      if (dt->position != dt->valid_end){
	*(dt->valid_end) = 0x0;
	return dt->position;
      } else
	return NULL;
    }
  }
}

int trans_read_skip(dataTrans * dt, int count){
  int rest_items;
  rest_items = (dt->valid_end - dt->position);
  while (TRUE){
    if (rest_items < count){
      dt->position += rest_items;
      if (!read_onemore(dt))
	return FALSE;
      count -= rest_items;
      rest_items = (dt->valid_end - dt->position);
    }else{
      dt->position += count;
      break;
    }
  }
  return TRUE;
}

int trans_write_skip(dataTrans * dt, int count){
  int rest_items;

  rest_items = (dt->end - dt->position);
  while (TRUE){
    if (rest_items < count){
      dt->position += rest_items;
      write_flush(dt);
      count -= rest_items;
      rest_items = (dt->end - dt->position);
    }else{
      dt->position += count;
      break;
    }
  }
  return TRUE;
}

int read_dataTrans(dataTrans * dt, char * buffer, DATA_TYPE type, int count){
  int rest_items;
  if (type == DT_STRING_TYPE)
    return write_dataTrans_string(dt, buffer, count);
  rest_items = (dt->valid_end - dt->position) / xdr_data_length[type];
  if (ninf_debug_flag)
    printf("read_dataTrans count: %d, rest_items: %d\n", count, rest_items);
  while (TRUE){
    if (rest_items < count){
      trans_dataTrans_sub(dt, buffer, type, rest_items);
      if (!read_onemore(dt))
	return FALSE;
      count -= rest_items;
      buffer += rest_items * ninf_data_type_size[type];
      rest_items = (dt->valid_end - dt->position) / xdr_data_length[type];
    }else{
      trans_dataTrans_sub(dt, buffer, type, count);
      break;
    }
  }
  return TRUE;
}

int write_dataTrans_string(dataTrans * dt, char * buffer, int count){
  int i;
  char ** tmp = (char**)buffer;
  for (i = 0; i < count; i++)
    if (!trans_string(dt, tmp++, MAX_STRING_LEN))
      return FALSE;
  return TRUE;
}


int write_dataTrans(dataTrans * dt, char * buffer, DATA_TYPE type, int count){
  int rest_items;

  if (type == DT_STRING_TYPE)
    return write_dataTrans_string(dt, buffer, count);
  rest_items = (dt->end - dt->position) / xdr_data_length[type];
  while (TRUE){
    if (rest_items < count){
      trans_dataTrans_sub(dt, buffer, type, rest_items);
      write_flush(dt);
      count -= rest_items;
      buffer += rest_items * ninf_data_type_size[type];
      rest_items = (dt->end - dt->position) / xdr_data_length[type];
    }else{
      trans_dataTrans_sub(dt, buffer, type, count);
      break;
    }
  }
  return TRUE;
}


int trans_any(dataTrans *dt, DATA_TYPE t, int ncount, char * p){
  if (dt->flag == XDR_DECODE)
    return read_dataTrans(dt, p, t, ncount);
  return write_dataTrans(dt, p, t, ncount);
}


int  getArg1(dataTrans * dt){
  return dt->decoded.arg1;
}
int  getArg2(dataTrans * dt){
  return dt->decoded.arg2;
}

int trans_getPacket(dataTrans * dt){
  if (!read_onemore(dt))
    return -1;
  return dt->decoded.code;
}

void trans_mark_align(dataTrans * dt){
  dt->align_base = dt->position;
}

void trans_align(dataTrans * dt){
  int diff = ((dt->position - dt->start) - (dt->align_base - dt->start)) % 4;
  if (diff != 0)
    dt->position += 4 - diff;
  if (ninf_debug_flag) printf("add %d for alignment\n", (4 - diff) % 4);
}
