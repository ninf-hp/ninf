package ninf.netsolve;

class ObjectProperty {
  ObjectChar m;
  ObjectChar n;
  ObjectChar l;

  boolean isEmpty(){
    System.out.println(m == null && n == null && l == null);
    return (m == null && n == null && l == null);
  }

  void merge(ObjectProperty prop){
    if (m != null && prop.m != null)    
      System.out.println("Conflict occured: ignore.");
    if (m == null && prop.m != null)
      m = prop.m;
    if (n != null && prop.n != null)    
      System.out.println("Conflict occured: ignore.");
    if (n == null && prop.n != null)
      n = prop.n;
    if (l != null && prop.l != null)    
      System.out.println("Conflict occured: ignore.");
    if (l == null && prop.l != null)
      l = prop.l;
  }
  public String toString(){
    return "m = " + m + ", n = " + n + ", l = " + l;
  }
}
