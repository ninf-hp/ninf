#define _WRAPPER_
/* $Id: pcungl2_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define SCOMPLEX
#include <gscalapack.h>
#define ROW_a lda
#define COL_a n
static	int worklen(int m, int n) {
	  int ret=1;
	  int IROFFA, ICOFFA, IAROW, IACOL, MpA0, NqA0;
	  ret = n + max(1, m);
	  if NEED_BUFF {
	    IROFFA = MOD( IA-1, MB_A ); ICOFFA = MOD( JA-1, NB_A );
	    IAROW = INDXG2P( IA, MB_A, MYROW, RSRC_A, NPROW );
	    IACOL = INDXG2P( JA, NB_A, MYCOL, CSRC_A, NPCOL );
	    MpA0 = NUMROC( M+IROFFA, MB_A, MYROW, IAROW, NPROW );
	    NqA0 = NUMROC( N+ICOFFA, NB_A, MYCOL, IACOL, NPCOL );
	    ret = NqA0 + MAX( 1, MpA0 );
	  }
	  return ret;
}


void  pcungl2_ninf(	 int m,	/*  m >= 0 */
		 int n,	/*  n >= m >= 0 */
		 int k,	/*  m >= k >= 0 */
		 scomplex global_a[],
		 int lda,
		 scomplex global_tau[],
		 scomplex work[],
		 int *info
)
/* "pcungl2 generates an M-by-N complex distributed matrix Q  with orthonormal rows, which is defined as the first M rows of a product of K elementary reflectors of order N\\n  Q  =  H(k)' . . . H(2)' H(1)' as returned by PCGELQF." */
/* OPTIONS */
{
	int maxldd;

	int maxlda;
	scomplex *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
	int row_loca, col_loca;

	scomplex *loctau=NULL;

	scomplex *locwork=NULL;
	int llocwork;

	INITIALIZE();

	SCALAR("int",m);
	SCALAR("int",n);
	SCALAR("int",k);
	SCALAR( "int", lda);

	ROW(a );
	COL(a );
	MAXLDD(maxldd,a );
	maxlda=maxldd;

	MATRIX("scomplex",a,ROW_a,COL_a );
	VECTOR("r","scomplex",tau,k );
	DISTRIBUTE("scomplex", a,ROW_a,COL_a  );
	vDISTRIBUTE("r","scomplex", tau, k  );

        llocwork = worklen(m, n);
        WORK(locwork,llocwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pcungl2)( &m, &n, &k,
			       loca, &one, &one, desca,
			       loctau,
			       locwork, &llocwork,
			       &linfo);

	GATHER("scomplex", a,ROW_a,COL_a  );
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
		*info = linfo;
	} else {
	}

	FREE_MATRIX(a);
	FREE_VECTOR(tau);
	FREE(locwork);
}

