#define _WRAPPER_
/* $Id: pclassq_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define SCOMPLEX
#include <gscalapack.h>

void  pclassq_ninf(	 int n,
		 scomplex global_x[],
		 int incx,
		 float *scale,
		 float *sumsq
)
/* "pclassq returns the values  scl  and  smsq  such that ( scl**2 )*smsq = x( 1 )**2 +...+ x( n )**2 + ( scale**2 )*sumsq. The value of sumsq is assumed to be at least unity and the value of ssq will then satisfy  1.0 .le. ssq .le. ( sumsq + 2*n ). scale is assumed to be non-negative and scl returns the value\\n */
/*     scl = max( scale, abs( real( x( i ) ) ), abs( aimag( x( i ) ) ) ),\\n */
/*            i\\n */
/*  scale and sumsq must be supplied in SCALE and SUMSQ respectively." */
/* OPTIONS */
{
	int maxldd;

	int maxldx;
	scomplex *locx=NULL;
	int descx[DESCLEN];
	int desc_gx[DESCLEN];
	int ROW_x, COL_x;
	int row_locx, col_locx;

	float lscale[1];
	float lsumsq[1];

	INITIALIZE();

	SCALAR( "int", n);
	SCALAR( "int", incx);
        square(n, ROW_x, COL_x);
	if (incx!=1) incx=ROW_x;
        
	COMMON( "float", scale,1);
	COMMON( "float", sumsq,1);

	*lscale=*scale;
	*lsumsq=*sumsq;


	ROW(x);
	COL(x);
	MAXLDD( maxldd, x );
	maxldx=maxldd;

	MATRIX("scomplex", x, ROW_x, COL_x);
	DISTRIBUTE("scomplex", x, ROW_x, COL_x);

	if  (( mypnum != 0 ) ^ (serial==1) ) {
		FortranCall(pclassq)( &n,
                                      locx, &one, &one, descx,
                                      &incx,
                                      &lscale, &lsumsq);
		Csgsum2d( PARA_CTXT, "A", MPI_TOP, 1, 1, lscale, 1, 0, 1);
		Csgsum2d( PARA_CTXT, "A", MPI_TOP, 1, 1, lsumsq, 1, 0, 1);
	}

	RETRIEVE("float", &lscale, 1);
	RETRIEVE("float", &lsumsq, 1);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
		*scale=*lscale;
		*sumsq=*lsumsq;
	} else {
	}

	FREE_COMMON(scale);
	FREE_COMMON(sumsq);
	FREE_MATRIX(x);
}

