#define _WRAPPER_
/* $Id: psstedc_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define _DISTRIBUTE_1D_
#define FLOAT
#include <gscalapack.h>

#define ROW_q ldq
#define COL_q n
static	int worklen(int n) {
	  int ret=1;
	  int NP, NQ;
	  ret = 6*n+2*n*n;
	  if NEED_BUFF {
	    NP = NUMROC( N, NB, MYROW, RSRC, NPROW );
	    NQ = NUMROC( N, NB, MYCOL, CSRC, NPCOL );
	    ret =  6*N + 2*NP*NQ;
	  }
	  return ret;
}

static	int iworklen(int n) {
	  int ret=1;
	  ret = 2+7*n+8;
	  if NEED_BUFF {
	    ret =  2 + 7*N + 8*NPCOL;
	  }
	  return ret;
}

void  psstedc_ninf(	 char compz,
		 int n,
		 float global_d[],
		 float global_e[],
		 float global_q[],
		 int ldq,
		 float work[],
		 int lwork,
		 int iwork[],
		 int liwork,
		 int *info
)
/* "psstedc computes all eigenvalues and eigenvectors of a symmetric tridiagonal matrix in parallel, using the divide and conquer algorithm." */
/* OPTIONS */
{
	int maxldd;

	int maxldq;
	float *locq=NULL;
	int descq[DESCLEN];
	int desc_gq[DESCLEN];
	int row_locq;
	int col_locq;

	float *locd=NULL, *loce=NULL;
	int desctdd[DESCLEN];
	int desc_gtdd[DESCLEN];

	float *locwork=NULL;
	int llocwork;
	int *lociwork=NULL;
	int llociwork;


	INITIALIZE();

	SCALAR( "char", compz);
	SCALAR( "int", n);
	SCALAR( "int", ldq);
	SCALAR("int",lwork);
	SCALAR("int",liwork);
	SIZE(n);

	ROW( q);
	COL( q);
	MAXLDD( maxldd, q );
	maxldq=maxldd;

	tdMATRIX( "float", e, d, e, n);
	MATRIX( "float", q, ROW_q, COL_q);
	tdDISTRIBUTE( "float", e, d, e, n);

	llocwork = worklen(n);
	llocwork = max(lwork,llocwork);
	WORK(locwork, llocwork);

	llociwork = iworklen(n);
	llociwork = max(liwork,llociwork);
	IWORK(lociwork, llociwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(psstedc)( &compz,
                               &n,
                               locd, loce,
                               locq, &one, &one, descq,
                               locwork, &llocwork,
                               lociwork, &llociwork,
                               linfo);

	tdGATHER("float", e, d, e, n);
	GATHER( "float", q, ROW_q, COL_q);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
		*info = linfo;
	} else {
	}
	FREE_MATRIX(d);
	FREE_MATRIX(e);
	FREE_MATRIX(q);
        FREE(locwork);
        FREE(lociwork);
}

