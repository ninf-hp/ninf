#define _WRAPPER_
/* $Id: pzdbtrf_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define _DISTRIBUTE_1D_
#define DCOMPLEX
#define NO_PIVOT
#include <gscalapack.h>

#define ROW_a  lda
#define COL_a n
#define ROW_af ldaf
#define COL_af n
static	int worklen(int bwl, int bwu) {
	  int ret=1;
	    ret = max(bwl,bwu)*max(bwl,bwu);
            return ret;
}

void  pzdbtrf_ninf(	 int n,
		 int bwl,
		 int bwu,
		 dcomplex global_a[],
		 int lda,
		 dcomplex af[],
		  int dummy_ldaf,
		 dcomplex work[],
		 int lwork,
		 int *info
)
/* "pzdbtrf computes a LU factorization of an N-by-N complex banded diagonally dominant-like distributed matrix with bandwidth BWL, BWU: A." */
/* OPTIONS */
{
    extern void FortranCall(pzdbtrf)( int*, int*, int*,
                               dcomplex*, int*, int*,
                               dcomplex*, int*,
                               dcomplex*, int*, int*);

	int maxldd;

	double *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];

	int maxldaf;
	int ldaf,llocaf;	
	dcomplex *locaf=NULL,*global_af=NULL;
	int descaf[DESCLEN];
	int desc_gaf[DESCLEN];

	int row_locaf;
	int col_locaf;
	
	double *locwork=NULL;
	int llocwork;

	INITIALIZE();
        
	SCALAR( "int", n);
	SCALAR( "int", bwl);
	SCALAR( "int", bwu);
	SCALAR( "int", lda);
	SCALAR( "int", lwork);
	SCALAR( "int", dummy_ldaf);

	SIZE(n);

	ldaf = max( dummy_ldaf, bwl+bwu+6*max(bwl,bwu)*max(bwl,bwu)/n);
	llocaf = ldaf*blocsize;
	if(mypnum==0){
            global_af = MALLOC(sizeof(dcomplex)*ldaf*n); assert(global_af);
	}

	ROW(af);
	COL(af);
	MAXLDD(maxldd, af);
	maxldaf=maxldd;

	bandMATRIX("dcomplex", a, bwl, bwu, n);
	MATRIX( "dcomplex", af, ROW_af, COL_af);
	bandDISTRIBUTE("dcomplex", a, bwl, bwu, n);

	llocwork = worklen(bwl, bwu);
        llocwork = max(llocwork,lwork);
	WORK(locwork,llocwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pzdbtrf)( &n, &bwl, &bwu,
                               loca, &one, desca,
                               locaf, &llocaf,
                               locwork, &llocwork, &linfo);
	
	bandGATHER("dcomplex", a, bwl, bwu, n);
	GATHER( "dcomplex", af, ROW_af, COL_af);

	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
	  int i;
	  *info = linfo;
	  for(i=0;i<min(dummy_ldaf,ldaf*n);i++) af[i]=global_af[i];
          FREE(global_af);
	} else {
	}
        
	FREE_MATRIX(a);
	FREE_MATRIX(af);

        FREE(locwork);
}

