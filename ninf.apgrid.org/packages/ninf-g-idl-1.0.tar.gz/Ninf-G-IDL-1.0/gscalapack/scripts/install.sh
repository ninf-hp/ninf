#! /bin/sh
# $Id: install.sh,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $

for arg in "$@"
do
    case $arg in
	*=*) eval `expr ${arg} : '\(.*\)='`=`expr ${arg} : '.*=\(.*\)'`
        ;;
        *)
        ;;
    esac
done

[ x"${TOPDIR}" = x"" ] && exit 3
[ x"${THISDIR}" = x"" ] && exit 3
[ x"${BINDIR}" = x"" ] && exit 3
[ x"${LDIF_INSTALL_DIR}" = x"" ] && exit 3


if [ -d ${BINDIR} ] ; then

    cd ${BINDIR}

    for idl in ${THISDIR}/*idl ; do
	endmark=`basename ${idl} | sed -e 's!\(.*\)\.idl!.\1!'`
	if [ -f ${THISDIR}/${endmark} ] ; then
	    funclist="`grep Define ${idl} | sed -e 's!^.*Define !!;s!(.*$!!' `"
	    for funcname in $funclist ; do
		if [ -f "scalapack::${funcname}.ldif" ] ; then
		    echo "Registering scalapack/${funcname}"
		    cp -f scalapack::${funcname}.ldif ${LDIF_INSTALL_DIR}
		fi
	    done
	fi
    done

    if	[ -f scalapack.mak ] ; then
	rm scalapack.mak
    fi

    cd ${THISDIR}
fi
