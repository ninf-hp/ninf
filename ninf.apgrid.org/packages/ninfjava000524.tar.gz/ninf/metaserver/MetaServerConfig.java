package ninf.metaserver;
import ninf.basic.*;
import java.util.Vector;
import java.util.Hashtable;
import java.io.*;

public class MetaServerConfig extends Configure{
  static CommandRepresent initAcceptedCommands[] = {
    new CommandRepresent("myhostname",  1),
    new CommandRepresent("port",        1),
    new CommandRepresent("lookup",      1),

    new CommandRepresent("scheduler",   1),
    new CommandRepresent("aggregateScheduler",   1),
    new CommandRepresent("predictor",   1),
    new CommandRepresent("loadInterval",1),
    new CommandRepresent("log",         1), 
    new CommandRepresent("loadlog",     1),
    new CommandRepresent("server",      2),
    new CommandRepresent("schedulelog", 1),

    new CommandRepresent("NWSuse",      1),
    new CommandRepresent("NWSdir",      1),
    new CommandRepresent("NWSMemoryDir",      1),
    new CommandRepresent("NWSinvokeNameServer", 1),
    new CommandRepresent("NWSNameServer", 1),

    new CommandRepresent("NWSMemoryLog",      1),
    new CommandRepresent("NWSMemoryErr",      1),
  };
  static CommandRepresent initAcceptedOptions[] = {
    new CommandRepresent("-port",      1), 
    new CommandRepresent("-debug",     0),
    new CommandRepresent("-version",   0),
    new CommandRepresent("-quiet",     0)
  };

  MetaServerConfig(String args[]) throws NinfException{
    super(args, initAcceptedCommands, initAcceptedOptions);
  }

  static final int DEFAULT_PORT = 3001;
  String schedulerString = "RoundRobinScheduler";
  String aggregateSchedulerString = "SimpleAggregateScheduler";
  NinfServerHolder holders[];

  String predictors[];
  int loadInterval = 100;
  PrintStream scheduleLogStream = null;
  public PrintStream loadLogStream = null;
  public Vector  initializers = new Vector();

  public boolean NWSuse = false;
  public String  NWSdir = null;
  public boolean NWSinvokeNameServer = false;
  public String  NWSNameServer = null;
  public String  NWSMemoryDir = null;
  public Class   LPingerClass = LPingerNative.getPingerClass();

  public String  NWSMemoryLog = null;
  public String  NWSMemoryErr = null;

  public void configure() throws NinfException{
    port = DEFAULT_PORT;
    super.configure();
    configureLoadInterval();
    configureScheduler();
    configureAggregateScheduler();
    configureSchedulerLog();
    configureLoadLog();
    configurePredictor();
    configureServer();
    configureNWS();
  }

  void configureNWS() throws NinfException{
    NWSuse              = getBoolean("NWSuse", NWSuse);
    NWSinvokeNameServer = getBoolean("NWSinvokeNameServer", 
				      NWSinvokeNameServer);
    NWSdir              = getOneArg("NWSdir");
    NWSMemoryDir        = getOneArg("NWSMemoryDir");
    NWSNameServer       = getOneArg("NWSNameServer");
    try {
      if (NWSuse)
        initializers.addElement(Class.forName("ninf.nws.MetaServerInitializerNWS"));
    } catch (ClassNotFoundException e){
	throw new ConfigureException("Cannot get intializer for NWS");
    }

    if (NWSuse && (!NWSinvokeNameServer) && NWSNameServer == null)
       throw new ConfigureException("have to specify NWSNameServer");

    if (NWSuse && NWSinvokeNameServer && NWSMemoryDir == null)
       throw new ConfigureException("have to specify directory for NWSMemoryDir");

    if (NWSuse && NWSNameServer == null)
	NWSNameServer = myhostname;

    NWSMemoryLog        = getOneArg("NWSMemoryLog");
    NWSMemoryErr        = getOneArg("NWSMemoryErr");

  }

  void configureLoadInterval(){
    int tmp = getPositiveNumber("loadInterval");
    if (tmp >= 0)
      loadInterval = tmp;
  }

  void configureScheduler(){
    String tmp = getOneArg("scheduler");
    if (tmp != null)
      schedulerString = tmp;
  }
  void configureAggregateScheduler(){
    String tmp = getOneArg("aggregateScheduler");
    if (tmp != null)
      aggregateSchedulerString = tmp;
  }

  void configurePredictor(){
    Vector tmpV = getContent("predictor");
    if (tmpV == null)
      return;
    predictors = new String[tmpV.size()];
    for (int i = 0; i < tmpV.size(); i++)
      predictors[i] = ((String[])tmpV.elementAt(i))[0];
  }

  void configureSchedulerLog() throws NinfException{
    PrintStream tmp = openLogStream("scheduleLog");
    if (tmp != null)
      scheduleLogStream = tmp;
  }

  void configureLoadLog() throws NinfException{
    PrintStream tmp = openLogStream("loadLog");
    if (tmp != null)
      loadLogStream = tmp;
  }

  void configureServer(){
    Vector tmpV = getContent("server");
    if (tmpV == null)
      return;
    holders = new NinfServerHolder[tmpV.size()];
    for (int i = 0; i < tmpV.size(); i++){
      holders[i] = 
	(new NinfServerHolder(((String[])tmpV.elementAt(i))[0],
			      ((String[])tmpV.elementAt(i))[1]));
    }
  }
}

