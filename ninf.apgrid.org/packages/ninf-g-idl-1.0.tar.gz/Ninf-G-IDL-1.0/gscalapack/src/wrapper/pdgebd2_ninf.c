#define _WRAPPER_
/* $Id: pdgebd2_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define _DISTRIBUTE_1D_
#define DOUBLE
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n

static   int worklen(int m, int n) {
	  int ret=1;
	  int nb, IROFFA, IAROW, IACOL;
	  int MpA0, NqA0;
#define MYROW myprow
#define NPROW nprow
#define MYCOL mypcol
#define NPCOL npcol
	  ret = max(m,n);
	  if NEED_BUFF {
	    nb = blocsize;
	    IROFFA = 0;
	    IAROW = INDXG2P( 1, nb, MYROW, 0, NPROW );
	    IACOL = INDXG2P( 1, nb, MYCOL, 0, NPCOL );
	    MpA0 = Cnumroc( m+IROFFA, nb, MYROW, IAROW, NPROW );
	    NqA0 = Cnumroc( n+IROFFA, nb, MYCOL, IACOL, NPCOL );

	    ret = max( MpA0, NqA0 );
	  }
	  return ret;
}

void  pdgebd2_ninf(	 int m,
		 int n,
		 double global_a[],
		 int lda,
		 double global_d[],
		 double global_e[],
		 double global_tauq[],
		 double global_taup[],
		 double work[],
		 int *info
)
/* "pdgebd2 reduces a real general M-by-N distributed matrix A to upper or lower bidiagonal form B by an orthogonal transformation: Q' *  A * P = B." */
/* OPTIONS */
{
  int min_m_n;
  
	int maxldd;
	int maxlda;
	double *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
        
	double *locd=NULL;
	double *loce=NULL;
	int desctdd[DESCLEN], desc_gtdd[DESCLEN];

        double *loctauq=NULL;
	double *loctaup=NULL;
        
	int row_loca;
	int col_loca;

	double *locwork=NULL;
	int llocwork;

	INITIALIZE();

	SCALAR( "int", m);
	SCALAR( "int", n);
	SCALAR("int",lda);
	min_m_n = min(m,n);

	SIZE(min_m_n);

	ROW( a);
	COL( a);
	MAXLDD( maxldd, a );
	maxlda = maxldd;

	MATRIX( "double", a, ROW_a, COL_a);
	DISTRIBUTE( "double", a, ROW_a, COL_a);
	tdMATRIX("double", e, d, e, min_m_n);

	VECTOR("c","double", tauq, min_m_n);
	VECTOR("r", "double", taup, min_m_n);

	llocwork=worklen(m, n);
	WORK(locwork, llocwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pdgebd2)( &m, &n,
                               loca, &one, &one, desca,
                               locd, loce,
                               loctauq, loctaup,
                               locwork, &llocwork, &linfo);

	GATHER( "double", a, ROW_a, COL_a);
	tdGATHER( "double", e, d, e, min_m_n);
	vGATHER("c","double", tauq, min_m_n);
	vGATHER("r", "double", taup, min_m_n);

            /* d,e,taup,tauq -> bandmatrix descinit not distri*/
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
		*info = linfo;
	} else {
	}

	FREE_MATRIX(a);
	FREE_MATRIX(d);
	FREE_MATRIX(e);
	FREE_MATRIX(taup);
        FREE(locwork);
}

