#define _WRAPPER_
/* $Id: pdtrrfs_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define DOUBLE
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n
#define ROW_b ldb
#define COL_b nrhs
#define ROW_x ldx
#define COL_x nrhs

static	int worklen(int n) {
	  int ret=1;
	  ret = 3*n;
	  if NEED_BUFF {
	    ret = 3*LOCr( N + MOD( IA-1, MB_A ) );
	  }
	  return ret;
}

static	int iworklen(int n) {
	  int ret=1;
	  ret = n;
	  if NEED_BUFF {
	    ret = LOCr( N + MOD( IB-1, MB_B ));
	  }
	  return ret;
}

void  pdtrrfs_ninf(	 char uplo,
		 char trans,
		 char diag,
		 int n,
		 int nrhs,
		 double global_a[],
		 int lda,
		 double global_b[],
		 int ldb,
		 double global_x[],
		 int ldx,
		 double global_ferr[],
		 double global_berr[],
		 double work[],
		 int iwork[],
		 int *info
)
/* "pdtrrfs provides error bounds and backward error estimates for the solution to a system of linear equations with a triangular coefficient matrix." */
/* OPTIONS */
{
	int maxldd;

	int maxlda;
	double *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
	int row_loca, col_loca;

	int maxldb;
	double *locb=NULL;
	int descb[DESCLEN];
	int desc_gb[DESCLEN];
	int row_locb, col_locb;

	int maxldx;
	double *locx=NULL;
	int descx[DESCLEN];
	int desc_gx[DESCLEN];
	int row_locx, col_locx;

	double *locferr=NULL;
	double *locberr=NULL;

	double *locwork=NULL;
	int llocwork;
	int *lociwork=NULL;
	int llociwork;


	INITIALIZE();

	SCALAR( "char", uplo);
	SCALAR( "char", trans);
	SCALAR( "char", diag);
	SCALAR( "int", n);
	SCALAR( "int", nrhs);
	SCALAR( "int", lda);
	SCALAR( "int", ldb);
	SCALAR( "int", ldx);

	ROW( a);
	COL( a);
	ROW( b);
	COL( b);
	ROW( x);
	COL( x);
	MAXLDD( maxldd, a );
	maxlda = maxldd;
	maxldb = maxldd;
	maxldx = maxldd;

	trMATRIX( uplo, "double", a, ROW_a, COL_a);
	MATRIX( "double", b, ROW_b, COL_b);
	MATRIX( "double", x, ROW_x, COL_x);
	VECTOR( "c", "double", ferr, nrhs);
	VECTOR( "c", "double", berr, nrhs);

	trDISTRIBUTE( uplo, "double", a, ROW_a, COL_a);
	DISTRIBUTE( "double", b, ROW_b, COL_b);
	DISTRIBUTE( "double", x, ROW_x, COL_x);

	llocwork = worklen();
	WORK( locwork, llocwork);
	llociwork = iworklen();
	WORK( lociwork, llociwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pdtrrfs)( &uplo, &trans, &diag, &n, &nrhs,
                               loca, &one, &one, desca,
                               locb, &one, &one, descb,
                               locx, &one, &one, descx,
                               locferr, locberr,
                               locwork, &llocwork,
                               lociwork, &llociwork,
                               &linfo);

	vGATHER( "c", "double", ferr, nrhs);
	vGATHER( "c", "double", berr, nrhs);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
		*info = linfo;
	} else {
	}

	FREE_MATRIX(a);
	FREE_MATRIX(b);
	FREE_MATRIX(x);
        FREE_VECTOR(ferr);
        FREE_VECTOR(berr);
        FREE(locwork);
        FREE(lociwork);
	
}

