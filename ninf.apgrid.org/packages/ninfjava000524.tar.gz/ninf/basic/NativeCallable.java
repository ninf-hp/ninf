package ninf.basic;
import ninf.client.*;

abstract public class NativeCallable extends Callable{
  abstract public NinfExecInfo callNative(CallContext context, int serial, 
				       ServerIndex index) 
    throws NinfException;
}
