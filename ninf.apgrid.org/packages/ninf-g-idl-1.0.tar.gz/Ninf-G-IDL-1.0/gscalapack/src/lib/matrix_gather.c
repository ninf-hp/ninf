#include <stdio.h>
#include <stdlib.h>
#include <mpi.h>
#include <assert.h>
#include <string.h>

#define _LOCAL_
#include "gscalapack.h"
#include "gscalapack-scalapack.h"

extern void parse_type(const char*,char *);
extern void gamx2d( char*, void*);

void _gather(
	    const char *type,
	    int m,
	    int n,
	    void *a,
	    int ia,
	    int ja,
	    int *desc_a,
	    void *b,
	    int ib,
	    int jb,
	    int *desc_b
	    )
{
extern void _distribute( const char *type, int m, int n,
			 void *a, int ia,  int ja,  int *desc_a,
			 void *b, int ib,  int jb,  int *desc_b );
 if (serial==1) return;
 _distribute( type, m, n, a, ia, ja, desc_a, b, ib, jb, desc_b );
}

void _tdgather(
	      const char *type1,
	      const char *type2,
	      const char *type3,
	      int n,
	      void *gdl,
	      void *gd,
	      void *gdu,
	      int igd, int jgd, /* not used */
	      int *desc_gd,
	      void *ldl,
	      void *ld,
	      void *ldu,
	      int ild, int jld, /* not used */
	      int *desc_ld
)
{
  char utype[TYPESTRLEN];

if (serial==1) return;

 parse_type(type1,utype);
 if (gdl!=gdu) {
 switch(*utype) {
 case 'f':
   svGather( "c", gdl, n-1, 1, ldl, blocsize, nprow, npcol, myprow, mypcol, seq_ctxt, para_ctxt, all_ctxt, mypnum);
   break;
 case 'd':
   dvGather( "c", gdl, n-1, 1, ldl, blocsize, nprow, npcol, myprow, mypcol, seq_ctxt, para_ctxt, all_ctxt, mypnum);
   break;
 case 'c':
   cvGather( "c", gdl, n-1, 1, ldl, blocsize, nprow, npcol, myprow, mypcol, seq_ctxt, para_ctxt, all_ctxt, mypnum);
   break;
 case 'z':
   zvGather( "c", gdl, n-1, 1, ldl, blocsize, nprow, npcol, myprow, mypcol, seq_ctxt, para_ctxt, all_ctxt, mypnum);
   break;
 default:
   assert(0);
   break;
 }
 }

 parse_type(type2,utype);
 switch(*utype) {
 case 'f':
   svGather( "c", gd, n, 0, ld, blocsize, nprow, npcol, myprow, mypcol, seq_ctxt, para_ctxt, all_ctxt, mypnum);
   break;
 case 'd':
   dvGather( "c", gd, n, 0, ld, blocsize, nprow, npcol, myprow, mypcol, seq_ctxt, para_ctxt, all_ctxt, mypnum);
   break;
 case 'c':
   cvGather( "c", gd, n, 0, ld, blocsize, nprow, npcol, myprow, mypcol, seq_ctxt, para_ctxt, all_ctxt, mypnum);
   break;
 case 'z':
   zvGather( "c", gd, n, 0, ld, blocsize, nprow, npcol, myprow, mypcol, seq_ctxt, para_ctxt, all_ctxt, mypnum);
   break;
 default:
   assert(0);
   break;
 }

 parse_type(type3,utype);
 switch(*utype) {
 case 'f':
   svGather( "c", gdu, n-1, 0, ldu, blocsize, nprow, npcol, myprow, mypcol, seq_ctxt, para_ctxt, all_ctxt, mypnum);
   break;
 case 'd':
   dvGather( "c", gdu, n-1, 0, ldu, blocsize, nprow, npcol, myprow, mypcol, seq_ctxt, para_ctxt, all_ctxt, mypnum);
   break;
 case 'c':
   cvGather( "c", gdu, n-1, 0, ldu, blocsize, nprow, npcol, myprow, mypcol, seq_ctxt, para_ctxt, all_ctxt, mypnum);
   break;
 case 'z':
   zvGather( "c", gdu, n-1, 0, ldu, blocsize, nprow, npcol, myprow, mypcol, seq_ctxt, para_ctxt, all_ctxt, mypnum);
   break;
 default:
   assert(0);
   break;
 }

} /* end of _tdgather */

void _band_gather(
	      const char *type,
	      int n,
	      int bwl,
	      int bwu,
	      void *global,
	      int *desc_gd,
	      void *local,
	      int *desc_ld,
	      int pivot
)
{
  char utype[TYPESTRLEN];
  int ld;

  if (serial==1) return;

  if (pivot!=0) {
    ld=2*bwl+2*bwu+1;
  } else {
    ld=bwl+bwu+1;
  }

  parse_type(type,utype);
  switch(*utype) {
  case 'f':
    svGather( "c", global, ld*n, 0, local, ld*blocsize, nprow, npcol, myprow, mypcol, seq_ctxt, para_ctxt, all_ctxt, mypnum);
    break;
  case 'd':
    dvGather( "c", global, ld*n, 0, local, ld*blocsize, nprow, npcol, myprow, mypcol, seq_ctxt, para_ctxt, all_ctxt, mypnum);
    break;
  case 'c':
    cvGather( "c", global, ld*n, 0, local, ld*blocsize, nprow, npcol, myprow, mypcol, seq_ctxt, para_ctxt, all_ctxt, mypnum);
    break;
  case 'z':
    zvGather( "c", global, ld*n, 0, local, ld*blocsize, nprow, npcol, myprow, mypcol, seq_ctxt, para_ctxt, all_ctxt, mypnum);
    break;
  case 'i':
    ivGather( "c", global, ld*n, 0, local, ld*blocsize, nprow, npcol, myprow, mypcol, seq_ctxt, para_ctxt, all_ctxt, mypnum);
    break;
  default:
    assert(0);
    break;
    
  }
}

void _band_gather_old(
		  const char *type,
	      int n,
	      int bwl,
	      int bwu,
	      void *global,
	      int *desc_gd,
	      void *local,
	      int *desc_ld,
	      int pivot
)
{
  char utype[TYPESTRLEN];
  int ld;
  if (serial==1) return;

  if (pivot!=0) {
    ld=2*bwl+2*bwu+1;
    local+=blocsize*(bwl+bwu);
  } else 
    ld=bwl+bwu+1;

  parse_type(type,utype);
  switch(*utype) {
    int i,offset,len;
      case 'f':
	for(i=0;i<ld;i++) {
	  if (i<bwu) {
	    offset = bwu-i;
	    len = n-offset;
	  } else {
	    offset=0;
	    len = n-(i-bwu);
	  }
	  svGather( "c", global,  len, offset, local,  blocsize, nprow, npcol, myprow, mypcol, seq_ctxt, para_ctxt, all_ctxt, mypnum);
	  global += len;
	  local +=  blocsize;
	}
	break;
      case 'd':
	for(i=0;i<ld;i++) {
	  if (i<bwu) {
	    offset = bwu-i;
	    len = n-offset;
	  } else {
	    offset=0;
	    len = n-(i-bwu);
	  }
	  dvGather( "c", global,  len, offset, local,  blocsize, nprow, npcol, myprow, mypcol, seq_ctxt, para_ctxt, all_ctxt, mypnum);
	  global += len;
	  local +=  blocsize;
	}
	break;
      case 'c':
	for(i=0;i<ld;i++) {
	  if (i<bwu) {
	    offset = bwu-i;
	    len = n-offset;
	  } else {
	    offset=0;
	    len = n-(i-bwu);
	  }
	  cvGather( "c", global,  len, offset, local,  blocsize, nprow, npcol, myprow, mypcol, seq_ctxt, para_ctxt, all_ctxt, mypnum);
	  global += len;
	  local +=  blocsize;
	}
	break;
      case 'z':
	for(i=0;i<ld;i++) {
	  if (i<bwu) {
	    offset = bwu-i;
	    len = n-offset;
	  } else {
	    offset=0;
	    len = n-(i-bwu);
	  }
	  zvGather( "c", global,  len, offset, local,  blocsize, nprow, npcol, myprow, mypcol, seq_ctxt, para_ctxt, all_ctxt, mypnum);
	  global += len;
	  local +=  blocsize;
	}
	break;
      case 'i':
	for(i=0;i<ld;i++) {
	  if (i<bwu) {
	    offset = bwu-i;
	    len = n-offset;
	  } else {
	    offset=0;
	    len = n-(i-bwu);
	  }
	  ivGather( "c", global,  len, offset, local,  blocsize, nprow, npcol, myprow, mypcol, seq_ctxt, para_ctxt, all_ctxt, mypnum);
	  global += len;
	  local +=  blocsize;
	}
	break;
  default:
    assert(0);
    break;
  } // end of switch

} /* end of _band_gather */

void _vgather( char *rowcol,
               const char *type,
               int size,
               void *gv,
               void *lv
)
{
  char utype[TYPESTRLEN];
  int blocsize=1;

  if (serial==1) return;

  if (*rowcol=='r') blocsize=rbloc;
  else blocsize=cbloc;

  parse_type(type,utype);
  switch(*utype) {
      case 'i':
	ivGather( rowcol, gv,   size, 0, lv,  blocsize, nprow, npcol, myprow, mypcol, seq_ctxt, para_ctxt, all_ctxt, mypnum);
          break;
      case 'f':
          svGather( rowcol, gv,   size, 0, lv,  blocsize, nprow, npcol, myprow, mypcol, seq_ctxt, para_ctxt, all_ctxt, mypnum);
          break;
      case 'd':
          dvGather( rowcol, gv,   size, 0, lv,  blocsize, nprow, npcol, myprow, mypcol, seq_ctxt, para_ctxt, all_ctxt, mypnum);
          break;
      case 'c':
          cvGather( rowcol, gv,   size, 0, lv,  blocsize, nprow, npcol, myprow, mypcol, seq_ctxt, para_ctxt, all_ctxt, mypnum);
          break;
      case 'z':
          zvGather( rowcol, gv,   size, 0, lv,  blocsize, nprow, npcol, myprow, mypcol, seq_ctxt, para_ctxt, all_ctxt, mypnum);
          break;
  default:
    assert(0);
    break;
  } // end of switch

} /* end of _vgather */

