#ifndef _NINF_ANY_T_H_
#define _NINF_ANY_T_H_

typedef struct _any_t_struct {
  int isHandler;
  void * handler;
  union {
    char c;
    unsigned char uc;
    short s;
    unsigned short us;
    int i;
    unsigned int ui;
    long l;
    unsigned long ul;
    float f;
    double d;
    void * p;
    void * (*func)();
  } u;
} any_t;

#endif 
