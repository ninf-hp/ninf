#define _WRAPPER_
/* $Id: pzgbtrs_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define _DISTRIBUTE_1D_
#define DCOMPLEX
#define PIVOT
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n
#define ROW_b ldb
#define COL_b nrhs
static	int worklen(int n, int nrhs, int bwl, int bwu) {
	  int ret=1;
	  ret =  nrhs*(n+2*bwl+4*bwu);
	  if NEED_BUFF {
	    ret =  nrhs*(blocsize+2*bwl+4*bwu);
	  }
	  return ret;
}


void  pzgbtrs_ninf(	 char trans,
		 int n,
		 int bwl,
		 int bwu,
		 int nrhs,
		 dcomplex global_a[],
		 int lda,
		 int global_ipiv[],
		 dcomplex global_b[],
		 int ldb,
		 int *info
)
/* "pzgbtrs solves a system of linear equations A * X = B or A' * X = B where A is the matrix used to produce the factors stored in A and AF by PCGBTRF. A is an N-by-N complex banded distributed matrix with bandwidth BWL, BWU." */
/* OPTIONS */
{
extern void FortranCall(pzgbtrs)( char*,
                               int*, int*, int*, int*,
                               dcomplex*, int*, int*,
                               int*,
                               dcomplex*, int*, int*,
                               dcomplex*, int*,
                               dcomplex*, int*, int*);

	int maxldd;

	dcomplex *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];

	dcomplex *locb=NULL;
	int descb[DESCLEN];
	int desc_gb[DESCLEN];
	int maxldb;
	int row_locb;
	int col_locb;

	dcomplex *locaf=NULL;
	int laf;

	dcomplex *locwork=NULL;
	int llocwork;

	int *locipiv=NULL;

	INITIALIZE();

	SCALAR( "char", trans);
	SCALAR( "int", n);
	SCALAR( "int", bwl);
	SCALAR( "int", bwu);
	SCALAR( "int", nrhs);
	SCALAR("int", lda);
	SCALAR("int", ldb);

	SIZE(n);

	ROW(b);
	COL(b);
	MAXLDD( maxldd, b);
	maxldb=maxldd;

	bandMATRIX("dcomplex", a, bwl, bwu, n);
	bandDISTRIBUTE("dcomplex", a, bwl, bwu, n);
        
	MATRIX("dcomplex", b, ROW_b, COL_b);
	DISTRIBUTE("dcomplex", b, ROW_b, COL_b);

	VECTOR( "c", "int", ipiv, n);

	laf=(blocsize+bwu)*(bwl+bwu)+6*(bwl+bwu)*(bwl+2*bwu);
	locaf=MALLOC(sizeof(dcomplex)*laf);
        assert(locaf);

	llocwork = worklen(n, nrhs, bwl, bwu);
	WORK(locwork, llocwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pzgbtrs)( &trans,
                               &n, &bwl, &bwu, &nrhs,
                               loca, &one, desca,
                               locipiv,
                               locb, &one, descb,
                               locaf, &laf,
                               locwork, &llocwork, &linfo);

	bandGATHER("dcomplex", a, bwl, bwu, n);
	GATHER("dcomplex", b, ROW_b, COL_b);
	vGATHER("c", "int", ipiv, n);
	
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
	  *info = linfo;
	} else {
	}
	FREE_MATRIX(a);
	FREE_MATRIX(b);
	FREE_MATRIX(ipiv);

	FREE(locaf);
        FREE(locwork);
}

