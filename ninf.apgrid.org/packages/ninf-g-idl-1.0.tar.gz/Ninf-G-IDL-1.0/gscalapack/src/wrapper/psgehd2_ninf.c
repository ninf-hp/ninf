#define _WRAPPER_
/* $Id: psgehd2_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define FLOAT
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n
static	int worklen(int n, int ihi) {
	  int ret;
	  int iroffa, iarow;
	  int NpA0;
	  ret = 2*n;
	  if NEED_BUFF {
#define NB cbloc
#define RSRS_a 0
            iroffa = 0;
            iarow = Cindxg2p( 1, NB, myprow, RSRS_a, npcol );
            NpA0 = Cnumroc( ihi+iroffa, NB, myprow, iarow, nprow );
            ret =  NB + max( NpA0, NB );
	  }
	  return ret;
}


void  psgehd2_ninf(	 int n,
		 int ilo,
		 int ihi,
		 float global_a[],
		 int lda,
		 float global_tau[],
		 float work[],
		 int *info
)
/* "psgehd2 reduces a real general distributed matrix  A to upper Hessenberg form H by an orthogonal similarity transformation:  Q' * A * Q = H." */
/* OPTIONS */
{
	int maxldd;

	int maxlda;
	float *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
	int row_loca, col_loca;

	float *loctau=NULL;

        float *locwork=NULL;
        int llocwork;

	INITIALIZE();

	SCALAR( "int", n);
	SCALAR( "int", ilo);
	SCALAR( "int", ihi);
	SCALAR( "int", lda);

	ROW( a);
	COL( a);
	MAXLDD( maxldd, a );
	maxlda = maxldd;

	MATRIX( "float", a, ROW_a, COL_a);
	DISTRIBUTE( "float", a, ROW_a  , COL_a);

	VECTOR( "c", "float", tau, n-1);

	llocwork = worklen(n, ihi);
	WORK(locwork, llocwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(psgehd2)( &n, &ilo, &ihi,
                               loca, &one, &one, desca,
                               loctau,
                               locwork, &llocwork,
                               &linfo);

	GATHER( "float", a, ROW_a, COL_a);
        vGATHER( "c", "float", tau, n-1);
        
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
	  *info = linfo;
	} else {
	}

	FREE_MATRIX(a);
	FREE_VECTOR(tau);
        FREE(locwork);
}

