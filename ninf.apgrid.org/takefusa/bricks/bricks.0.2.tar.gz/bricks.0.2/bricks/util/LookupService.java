package bricks.util;
import bricks.environment.*;
import bricks.scheduling.*;
import java.util.*;

public class LookupService {

    Hashtable lookupService = new Hashtable();
    Hashtable originalDataFragments = new Hashtable();

    public int size() {
	return lookupService.size();
    }

    public void init(Host host) {
	SimulationDebug.println("LookupService.init(): host = " + host);
	Enumeration e = host.dataFragments();
	if (e == null)
	    return;
	while (e.hasMoreElements()) {
	    DataFragment fragment = (DataFragment)e.nextElement();
	    Vector v = (Vector)lookupService.get(fragment.id);
	    if (v == null) {
		v = new Vector();
		lookupService.put(fragment.id, v);
		originalDataFragments.put(fragment.id, fragment);
	    }
	    v.add(host);
	}
	SimulationDebug.println(originalDataFragments);
    }

    /******************** public method ********************/
    public Vector get(String id) {
	if (id == null)
	    return null;
	else
	    return (Vector)lookupService.get(id);
    }

    //***********************************//
    public Vector getFragments(double size) {
	Enumeration e = originalDataFragments.elements();
	Vector v = new Vector();
	while(e.hasMoreElements()) {
	    DataFragment fragment = (DataFragment)e.nextElement();
	    if (fragment.size == size) {
		v.add(fragment);
	    }
	}
	return v;
    }

    public void addFragmentInto(Host host, DataFragment fragment) {
	Vector v = (Vector)lookupService.get(fragment.id);
	if (v == null) {
	    v = new Vector();
	    lookupService.put(fragment.id, v);
	    if ((DataFragment)originalDataFragments.get(fragment.id) == null)
		originalDataFragments.put(fragment.id, fragment);
	}
	v.add(host);
    }

    public void removeFragmentFrom(Host host, String id) {
	Vector v = (Vector)lookupService.get(id);
	v.removeElement(id);
	if (v.size() == 0) {
	    lookupService.remove(id);
	    //originalDataFragments.remove(id);
	}
    }

    public boolean hasData(Host host, String id) {
	Vector v = get(id);
	return v.contains(host);
    }

    public int howManyReplicas(DataFragment fragment) {
	Vector v = get(fragment.id);
	if (v == null)
	    return 0;
	return v.size();
    }

    public String toString() {
	String str = "LookupService: ";
	Enumeration e = lookupService.keys();
	while (e.hasMoreElements()) {
	    String id = (String)e.nextElement();
	    str += id + "{" + get(id) + "}, ";
	}
	return str;
    }
}
