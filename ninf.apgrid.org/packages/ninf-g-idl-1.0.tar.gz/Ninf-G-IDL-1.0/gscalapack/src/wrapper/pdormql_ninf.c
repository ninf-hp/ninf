#define _WRAPPER_
/* $Id: pdormql_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define DOUBLE
#include <gscalapack.h>

#define ROW_a lda
#define COL_a k
#define ROW_c ldc
#define COL_c n

static	int worklen(char side, int m, int n) {
	  int ret=1;
	  int LCMQ, IROFFA, ICOFFA, IAROW, NpA0;
	  int IROFFC, ICOFFC, ICROW, ICCOL;
	  int MpC0, NqC0;
	  int max_m_n;
	  max_m_n = max( m, n);
	  ret = MAX( (max_m_n*(max_m_n-1))/2, (max_m_n + max_m_n)*max_m_n ) +
		max_m_n * max_m_n;
	  if NEED_BUFF {
	    LCMQ = LCM(NPROW, NPCOL) / NPCOL;

	    IROFFA = MOD( IA-1, MB_A ); ICOFFA = MOD( JA-1, NB_A );
	    IAROW = INDXG2P( IA, MB_A, MYROW, RSRC_A, NPROW );
	    NpA0 = NUMROC( N+IROFFA, MB_A, MYROW, IAROW, NPROW );

	    IROFFC = MOD( IC-1, MB_C ); ICOFFC = MOD( JC-1, NB_C );
	    ICROW = INDXG2P( IC, MB_C, MYROW, RSRC_C, NPROW );
	    ICCOL = INDXG2P( JC, NB_C, MYCOL, CSRC_C, NPCOL );
	    MpC0 = NUMROC( M+IROFFC, MB_C, MYROW, ICROW, NPROW );
	    NqC0 = NUMROC( N+ICOFFC, NB_C, MYCOL, ICCOL, NPCOL );

	    if ( chrcmp(side, 'L')==0)
	      ret = MAX( (NB_A*(NB_A-1))/2, (NqC0 + MpC0)*NB_A ) +
		NB_A * NB_A;
	    else 
	      ret = MAX( (NB_A*(NB_A-1))/2, ( NqC0 + MAX( NpA0 + NUMROC( NUMROC( N+ICOFFC, NB_A, 0, 0, NPCOL ), NB_A, 0, 0, LCMQ ), MpC0 ) )*NB_A ) +
		NB_A * NB_A;
	  }
	  return ret;
}


void  pdormql_ninf(	 char side,
		 char trans,
		 int m,
		 int n,
		 int k,
		 double global_a[],
		 int lda,
		 double global_tau[],
		 double global_c[],
		 int ldc,
		 double work[],
		 int lwork,
		 int *info
)
/* "pdormql overwrites the general real M-by-N distributed matrix C with\\n\\n                      SIDE = 'L'            SIDE = 'R'\\n  TRANS = 'N':      Q * C          C * Q\\n  TRANS = 'T':      Q**T * C       C * Q**T\\n\\n  where Q is a real orthogonal distributed matrix defined as the product of K elementary reflectors\\n\\n        Q = H(k) ." */
/* OPTIONS */
{
	int maxldd;

	int maxlda;
	double *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
	int row_loca, col_loca;

	int maxldc;
	double *locc=NULL;
	int descc[DESCLEN];
	int desc_gc[DESCLEN];
	int row_locc, col_locc;

	double *loctau=NULL;

	double *locwork=NULL;
	int llocwork;
	INITIALIZE();

	SCALAR( "char", side);
	SCALAR( "char", trans);
	SCALAR( "int", m);
	SCALAR( "int", n);
	SCALAR( "int", k);
	SCALAR( "int", lda);
	SCALAR( "int", ldc);
	SCALAR( "int", lwork);

	ROW( a);
	COL( a);
	ROW( c);
	COL( c);
	MAXLDD( maxldd, c );
	maxlda = maxldd;
	maxldc = maxldd;
	MATRIX( "double", a, ROW_a, COL_a);
	MATRIX( "double", c, ROW_c, COL_c);
	VECTOR("c","double",tau,n);
	DISTRIBUTE( "double", a, ROW_a  , COL_a);
	DISTRIBUTE( "double", c, ROW_c  , COL_c);
	vDISTRIBUTE("c","double",tau, n);

	llocwork=worklen(side, m, n);
	llocwork = max(lwork,llocwork);
	WORK(locwork,llocwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pdormql)( &side, &trans,
                               &m, &n, &k,
                               loca, &one, &one, desca,
                               loctau,
                               locc, &one, &one, descc,
                               locwork, &llocwork,
                               &linfo);

	GATHER( "double", c, ROW_c, COL_c);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
		*info = linfo;
		// cp locwork to work[lwork]
	} else {
	}

	FREE_MATRIX(a);
	FREE_MATRIX(c);
	FREE_VECTOR(tau);
        FREE(locwork);
	
}

