#define _WRAPPER_
/* $Id: pcgetrs_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define SCOMPLEX
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n
#define ROW_b ldb
#define COL_b nrhs
void  pcgetrs_ninf(	 char trans,
		 int n,
		 int nrhs,
		 scomplex global_a[],
		 int lda,
		 int global_ipiv[],
		 scomplex global_b[],
		 int ldb,
		 int *info
)
/* "pcgetrs solves a system of distributed linear equations op( A ) * X = B with a general N-by-N distributed matrix A using the LU factorization computed by PCGETRF." */
/* OPTIONS */
{
extern void FortranCall(pcgetrs)( char*, int*, int*,
                               scomplex*, int*, int*, int*,
                               int*,
                               scomplex*, int*, int*, int*,
                               int*);

	int maxldd;

	int maxlda;
	scomplex *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
	int row_loca, col_loca;

	int maxldb;
	scomplex *locb=NULL;
	int descb[DESCLEN];
	int desc_gb[DESCLEN];
	int row_locb, col_locb;

	int *locipiv=NULL;

	INITIALIZE();

	SCALAR( "char", trans);
	SCALAR( "int", n);
	SCALAR( "int", nrhs);
	SCALAR( "int", lda);
	SCALAR( "int", ldb);

	ROW( a);
	COL( a);
	ROW( b);
	COL( b);
	MAXLDD( maxldd, a );
	maxlda = maxldd;
	maxldb = maxldd;
	MATRIX( "scomplex", a, ROW_a, COL_a);
	MATRIX( "scomplex", b, ROW_b, COL_b);
	VECTOR( "r", "int", ipiv, min(ROW_a, n));
	DISTRIBUTE( "scomplex", a, ROW_a  , COL_a);
	DISTRIBUTE( "scomplex", b, ROW_b  , COL_b);
	vDISTRIBUTE( "r", "int", ipiv, min(ROW_a,n));

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pcgetrs)( &trans, &n, &nrhs,
                               loca, &one, &one, desca,
                               locipiv,
                               locb, &one, &one, descb,
                               &linfo);

	GATHER( "scomplex", b, ROW_b  , COL_b);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
	  *info = linfo;
	} else {
	}

	FREE_MATRIX(a);
	FREE_MATRIX(b);
	FREE_VECTOR(ipiv);
	
}

