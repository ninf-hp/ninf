package ninf.netsolve;
import  ninf.MetaServer.FunctionStructFactory;
import  ninf.client.*;
import  ninf.MetaServer.*;

public class AdapterStructFactory extends FunctionStructFactory{
  public NinfFunctionStruct make(NinfServerStruct srv, NinfStub stub, int index) throws CannotConvertException{
    System.out.println("making AdapterFunctionStruct");
    return new AdapterFunctionStruct(srv, stub, index);
  }





}
