package ninf.scheduler;
import ninf.metaserver.*;

public class Throttle4Scheduler extends ThrottleScheduler {
  static int THRESHOLD = 4;
}
