package bricks.scheduling;
import bricks.util.*;
import bricks.environment.*;
import java.util.*;

public class RoundRobinScheduler extends Scheduler implements SchedulingUnit {

    protected Vector hosts;
    protected int index;

    public RoundRobinScheduler(String keyOfMetaPredictor, int index) {
	this.keyOfMetaPredictor = keyOfMetaPredictor;
	this.index = index - 1;
	schedulingOverhead = 0.0;
    }

    public RoundRobinScheduler(String keyOfMetaPredictor) {
	this.keyOfMetaPredictor = keyOfMetaPredictor;
	this.index = -1;
	schedulingOverhead = 0.0;
    }

/************************* needed method *************************/
    public String getName() {
	return "RoundRobinScheduler";
    }

    public void selectHosts (
	double currentTime, Host source, RequestedData data
    ) throws BricksNotScheduledException {
	hosts = resourceDB.getHostList();
	if (hosts.size() == 0)
	    throw new BricksNotScheduledException(this.toString());

	addIndex();
	Host host = (Host)hosts.elementAt(index);

	SimulationDebug.println(
	    "index/hosts.size() = " + index + "/" + 
	    hosts.size() + ", Host = " + host
	);

	updateStatus(currentTime, source, host, data);
    }

    private void addIndex() {
	index = ++index % hosts.size();
    }
}

