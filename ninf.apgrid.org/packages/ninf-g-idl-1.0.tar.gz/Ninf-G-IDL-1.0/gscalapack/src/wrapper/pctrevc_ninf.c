#define _WRAPPER_
/* $Id: pctrevc_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define SCOMPLEX
#include <gscalapack.h>

#define ROW_t ldt
#define COL_t n
#define ROW_vl ldvl
#define COL_vl mm
#define ROW_vr ldvr
#define COL_vr mm

static	int worklen(int ldt,int n, int row_loct, int col_loct ) {
	  int ret=1;
	  ret = 2*max(ROW_t, COL_t);
	  if NEED_BUFF {
	    ret= 2*max(row_loct,col_loct);
	  }
	  return ret;
}

static	int rworklen(int ldt, int n, int row_loct, int col_loct) {
	  int ret=1;
	  ret = max(ROW_t, COL_t);
	  if NEED_BUFF {
	    ret = max(row_loct, col_loct);
	  }
	  return ret;
}

void  pctrevc_ninf(
	 char side,
	 char howmany,
	 long select[],	
	 int n,	
	 scomplex global_t[],
	 int ldt,
	 scomplex global_vl[],
	 int ldvl,
	 scomplex global_vr[],
	 int ldvr,
	 int mm,
	 int *m,
	 scomplex work[],
	 float rwork[],
	 int *info
)
/* "pctrevc computes some or all of the right and/or left eigenvectors of a complex upper triangular matrix T in parallel. The right eigenvector x and the left eigenvector y of T corresponding to an eigenvalue w are defined by:\\n               T*x = w*x,     y'*T = w*y'\\n  where y' denotes the conjugate transpose of the vector y." */
/* OPTIONS */
{
	int maxldd;

	scomplex *loct=NULL;
	int maxldt;
	int desct[DESCLEN];
	int desc_gt[DESCLEN];
	int row_loct, col_loct;

	scomplex *locvl=NULL;
	int maxldvl;
	int descvl[DESCLEN];
	int desc_gvl[DESCLEN];
	int row_locvl, col_locvl;

	scomplex *locvr=NULL;
	int maxldvr;
	int descvr[DESCLEN];
	int desc_gvr[DESCLEN];
	int row_locvr, col_locvr;

	scomplex *locwork=NULL;
	int llocwork;
	float *locrwork=NULL;
	int llocrwork;

	int locm[1];


	INITIALIZE();

	SCALAR("char",side);
	SCALAR( "char", howmany);

	COMMON( "long", select, n);
	SCALAR("int",n);
	SCALAR( "int", ldvl);
	SCALAR( "int", ldvr);
	SCALAR( "int", mm);

	ROW(t );
	COL(t );
	MAXLDD(maxldd,t );
	maxldt=maxldd;

	ROW(vl);
	COL(vl);
	MAXLDD(maxldd, vl);
	maxldvl=maxldd;
	
	ROW(vr);
	COL(vr);
	MAXLDD(maxldd, vr);
	maxldvr=maxldd;

	MATRIX("scomplex",t, ROW_t ,COL_t );
	DISTRIBUTE("scomplex", t,ROW_t  , COL_t );
	MATRIX("scomplex",vl,ROW_vl, COL_vl );
	DISTRIBUTE("scomplex", vl,ROW_vl  , COL_vl );
	MATRIX("scomplex",vr, ROW_vr, COL_vr );
	DISTRIBUTE("scomplex", vr,ROW_vr  , COL_vr);

	llocwork=worklen(ldt, n, row_loct, col_loct);
	WORK(locwork,llocwork);
	llocrwork=rworklen(ldt, n, row_loct, col_loct);
	_work("float", &locrwork, llocrwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pctrevc)( &side, &howmany, select, &n,
                               loct, desct,
                               locvl, descvl,
                               locvr, descvr,
                               &mm,
                               locm,
                               locwork,
                               locrwork,
                               &linfo);

	GATHER("scomplex", t, ROW_t, COL_t);
	GATHER("scomplex", vl, ROW_vl, COL_vl);
	GATHER("scomplex", vr, ROW_vr, COL_vr);

	RETRIEVE("int", locm, 1);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
		*info = linfo;
		*m = *locm;
	} else {
	}
	FREE_COMMON(select);
	FREE_MATRIX(t);
	FREE_MATRIX(vl);
	FREE_MATRIX(vr);
	FREE(locwork);
        FREE(locrwork);

}

