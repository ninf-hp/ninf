#define _WRAPPER_
/* $Id: pdlasrt_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define DOUBLE
#include <gscalapack.h>

#define ROW_q ldq
#define COL_q n
static	int worklen(int n) {
		int ret=1;
		int NP, NQ;
		int IAROW;
		ret = max(n,n*(n+n));
		if NEED_BUFF {
			IAROW = _IAROW;
			NP = NUMROC( N, NB, MYROW, IAROW, NPROW );
			NQ = NUMROC( N, NB, MYCOL, 0, NPCOL );
			ret = MAX( N, NP * ( NB + NQ ));
		}
		return ret;
}
	
static int iworklen(int n) {
		int ret=1;
		ret = n+ 2*n+2;
		if NEED_BUFF {
			ret =  N + 2*NB + 2*NPCOL;
		}
		return ret;
}

void  pdlasrt_ninf(	 char id,
		 int n,
		 double d[],
		 double global_q[],
		 int ldq,
		 int *info
)
/* "pdlasrt Sort the numbers in D in increasing order and the corresponding vectors in Q." */
/* OPTIONS */
{
	int maxldd;

	int maxldq;
	double *locq=NULL;
	int descq[DESCLEN];
	int desc_gq[DESCLEN];
	int row_locq, col_locq;

	double *locwork=NULL;
	int llocwork;
	int *lociwork=NULL;
	int llociwork;


	INITIALIZE();

	SCALAR( "char", id);
	SCALAR( "int", n);
	SCALAR("int",ldq);

	ROW( q);
	COL( q);
	MAXLDD( maxldd, q );
	maxldq = maxldd;

	COMMON("double", d, n);

	MATRIX( "double", q, ROW_q, COL_q);
	DISTRIBUTE( "double", q, ROW_q  , COL_q);

	llocwork = worklen(n);
	WORK(locwork, llocwork);
	llociwork = iworklen(n);
	IWORK(lociwork, llociwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
		FortranCall(pdlasrt)( &id, &n, d,
				      locq, &one, &one, descq,
				      locwork, &llocwork,
				      lociwork, &llociwork,
				      &linfo);

	RETRIEVE("double", d, n);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
		*info = linfo;
	} else {
	}
        
        FREE_COMMON(d);
	FREE_MATRIX(q);
        FREE(locwork);
        FREE(lociwork);
	
}

