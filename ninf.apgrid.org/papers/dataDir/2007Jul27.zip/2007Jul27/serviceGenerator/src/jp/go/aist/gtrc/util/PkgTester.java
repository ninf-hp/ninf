package jp.go.aist.gtrc.util;

public class PkgTester {
	public static void main(String[] args) {
		System.out.println("Testing ResourceInfo...");
		if (ResourceInfo.isTestOk()) {
			System.out.println("ResourceInfo Test Ok");
		} else {
			System.out.println("ResourceInfo Test NG");
			System.exit(1);
		}

		System.out.println("Testing PropertyInfo...");
		if (PropertyInfo.isTestOk()) {
			System.out.println("PropertyInfo Test Ok");
		} else {
			System.out.println("PropertyInfo Test NG");
			System.exit(1);
		}
		System.out.println("Testing ServiceGenerator...");
		if (ServiceGenerator.isTestOk()) {
			System.out.println("ServiceGenerator Test Ok");
		} else {
			System.out.println("ServiceGenerator Test NG");
			System.exit(1);
		}
	}
}
