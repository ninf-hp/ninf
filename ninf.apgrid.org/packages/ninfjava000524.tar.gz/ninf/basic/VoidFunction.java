package ninf.basic;

public interface VoidFunction{
  public void eval(Object o);
}
