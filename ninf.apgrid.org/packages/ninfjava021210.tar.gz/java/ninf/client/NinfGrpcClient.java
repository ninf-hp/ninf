package ninf.client;

import org.gridforum.gridrpc.*;
import java.util.*;
import java.io.*;

public class NinfGrpcClient implements org.gridforum.gridrpc.GrpcClient{
  static final String defaultHost = "localhost";
  static final int    defaultPort = 3000;

  String instanceHost = defaultHost;
  int    instancePort = defaultPort;

  /** initializes a Grpc Client */
  public void activate(String propertiesFilename) throws GrpcException{
    try {
      Properties prop = new Properties();
      prop.load(new FileInputStream(propertiesFilename));
      activate(prop);
    } catch (IOException e) {
      throw new GrpcException(e);
    }
  }

  /** initializes a Grpc Client */
  public void activate(Properties prop){
    String tmp = prop.getProperty("host");
    if (tmp != null)
      instanceHost = tmp;
    tmp = prop.getProperty("port");
    if (tmp != null)
      instancePort = Integer.parseInt(tmp);
  }

  /** Create a GrpcHandler instance using specified properties
    and returns it. */
  public GrpcHandle getHandle(String functionName, Properties prop)
  throws GrpcException {
    String host = instanceHost;
    int port = instancePort;
    String tmp = prop.getProperty("host");
    if (tmp != null)
      host = tmp;
    tmp = prop.getProperty("port");
    if (tmp != null)
      port = Integer.parseInt(tmp);
    return getHandle(functionName, host, port);
  }

  /** Create a default GrpcHandler and returns */
  public GrpcHandle getHandle(String functionName)
  throws GrpcException {
    return getHandle(functionName, instanceHost, instancePort);
  }

  /** Create a GrpcHandler and returns */
  protected GrpcHandle getHandle(String functionName, String host, int port)
  throws GrpcException {
    return new NinfGrpcHandle(host, port, functionName,
			      System.out, System.err);
  }


  public void deactivate(){
    // nothing to do
  }

}
