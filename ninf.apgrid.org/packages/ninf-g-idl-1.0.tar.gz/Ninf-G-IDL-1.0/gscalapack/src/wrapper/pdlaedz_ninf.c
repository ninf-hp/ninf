#define _WRAPPER_
/* $Id: pdlaedz_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define DOUBLE
#include <gscalapack.h>

#define ROW_q ldq
#define COL_q n
static	int worklen(int n) {
	  int ret=1;
	  ret=2*n;
	  return ret;
}

void  pdlaedz_ninf(	 int  n,
		 int  n1,
		 double global_q[],
		 int ldq,
		 double z[]
)
/* "pdlaedz Form the z-vector which consists of the last row of Q_1 and the first row of Q_2." */
/* OPTIONS */
{
	int maxldd;

	int maxldq;
	double *locq=NULL;
	int descq[DESCLEN];
	int desc_gq[DESCLEN];
	int row_locq, col_locq;

	double *locwork=NULL;
	int llocwork;

	int id=1;


	INITIALIZE();

	SCALAR("int", n);
	SCALAR("int", n1);
	SCALAR("int", ldq);

	COMMON( "double", z, n);

	ROW(q);
	COL(q);
	MAXLDD( maxldd, q );
	maxldq=maxldd;

	MATRIX("double", q, ROW_q, COL_q);
	DISTRIBUTE( "double", q, ROW_q, COL_q);

	llocwork=worklen(n);
	WORK(locwork, llocwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pdlaedz)( &n, &n1, &id,
			       locq, &one, &one, &row_locq, descq,
			       z,
			       locwork);

	GATHER( "double", q, ROW_q, COL_q);
	RETRIEVE("double", z, n);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
	} else {
	}
        FREE_MATRIX(q);
        FREE_COMMON(z);
        FREE(locwork);
}

