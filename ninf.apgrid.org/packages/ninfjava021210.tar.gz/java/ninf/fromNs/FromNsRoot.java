package ninf.fromNs;
import  ninf.basic.*;
import  ninf.client.*;
import  ninf.netsolve.*;
import  java.io.*;
import  java.net.*;
import  java.util.Vector;
import  java.util.Enumeration;

public class FromNsRoot extends NServer {
  String myname;
  int myport;
  int callSerial;
  CallableCache callableCache;

  boolean lookup = true;

  MetaServerReference metaServer;
  NinfServerStruct    cproxy;
  ServerInfo          myself;
  String              agent;


  static NinfLog dbg = new NinfLog("FromNsRoot");

  FromNsRoot(String myname, int myport) throws NinfException{
    this.myname = myname;
    this.myport = myport;
    this.metaServer = FromNsAdapter.conf.metaServer;
    this.cproxy     = FromNsAdapter.conf.cproxy;   
    this.agent      = FromNsAdapter.conf.netsolveAgent;   
    this.lookup = FromNsAdapter.conf.lookup;
    NinfServerConnection.lookup = FromNsAdapter.conf.lookup;
    MetaServerConnection.lookup = FromNsAdapter.conf.lookup;
    setupMySelf();
    callableCache   = new ProblemStubCache(metaServer);
  }

  void setupMySelf() throws NinfException {
    InetAddress localaddr;
    try {
      localaddr = InetAddress.getLocalHost();
    } catch (UnknownHostException e){
      throw new ConfigureException("cannot get localhost address.");
    }
    String tmpmyname = localaddr.getHostName();
    dbg.println("myname is " + tmpmyname);
    myself = new ServerInfo();
    myself.name = myname;
    
    byte tmpIp[] = localaddr.getAddress();
    
    myself.ip_addr = tmpIp;
    myself.number_proc = 1;
  }

  Problem[] getProblems(){
    Enumeration tmp =  callableCache.stubCallables.elements();
    Problem[] ans = new Problem[callableCache.stubCallables.size()];
    for (int i = 0; tmp.hasMoreElements(); i++)
      ans[i] = ((ProblemStubCallable)tmp.nextElement()).problem;
    return ans;
  }

  /* introduce myself to NetSolve Agent */
  void introduceMySelf(XDROutputStream os) throws IOException, NinfException{
    os.writeInt(GlobalDefs.I_AM_NEW);
    
    myself.writeTo(os);
    
    Problem probs[] = getProblems();

    System.out.println("sending problems");
    os.writeInt(probs.length);
    for (int j = 0; j<probs.length;j++){
      probs[j].write(os);
      System.out.println("send "+ j + " problem" );
    }
  }


  void introduceToAgent() throws NinfException{
    System.out.println("connecting to agent: "+ agent + "," + GlobalDefs.AG_PORT);
    try {
      Socket s = new Socket(agent, GlobalDefs.AG_PORT);
      XDRInputStream  is = new XDRInputStream(s.getInputStream());
      XDROutputStream os = new XDROutputStream(s.getOutputStream());
      
      System.out.println("introducing to agent");
      
      os.writeChar(GlobalDefs.DATA_XDR);
      
      introduceMySelf(os);
      
      System.out.println("waiting for agent reply");
      
      int mode = is.readChar();
      int response = is.readInt();
      System.out.println("got reply " + response);
      switch (response){
      case GlobalDefs.WRONG_PROBLEM:
	int nBadProblems = is.readInt();
	dbg.println("Following " + nBadProblems + 
		    " problem(s) have the same name in Agent, but has different arguments");
	for (int i = 0; i < nBadProblems; i++){
	  //		Problem tmp = Problem.readProblem(is);
	  dbg.println("----------------------");
	  //	System.err.println(tmp);
	  dbg.println("----------------------");
	}
	throw new ConfigurationException();
      case GlobalDefs.SV_FAILURE: /* The master has failed !!! */
	dbg.log("The master "+ agent + "failed");
	dbg.log("Sorry, impossible to check in");
	throw new ConfigurationException();
      case GlobalDefs.YOU_ARE_NEW:
	dbg.log("I successfully checked in");
	break;
      default:
	dbg.log("Unknown response from agent: " + response);
	throw new ConfigurationException();
      }
      getAllStruct(is); 
      
      
      /* Get the answer */
      /* BEGINNING OF A RECEIVE PHASE */
    } catch (IOException e){
      throw new NinfIOException(e);
    }

  }

  void getAllStruct(XDRInputStream is) throws NinfException{
    dbg.println("getting all struct");
    int nb_problem = 0;
    try {

      dbg.println("getting problems");
      nb_problem  = is.readInt();
      dbg.println("getting " + nb_problem + " problems");
      Problem problems[] = new Problem[nb_problem];
      for (int i = 0; i < nb_problem; i++)
	problems[i] = Problem.read(is);
      

      dbg.println("getting servers");
      int nb_server = is.readInt();
      System.err.println("getting " + nb_server + " servers");
      ServerInfo servers[] = new ServerInfo[nb_server];
      for (int i = 0; i < nb_server; i++)
	servers[i] = ServerInfo.readFull(is);
    } catch (IOException e){
      throw new NinfIOException();
    }
    dbg.println("got all struct");
  }


  boolean processProblemSolve(XDRInputStream is, XDROutputStream os) 
  throws IOException, NinfException{
    Problem tmpProb = Problem.readPartial(is);
    Callable callable = 
      callableCache.getStubCallable(new FunctionName(tmpProb.name));
    dbg.println("callable = " + callable);
    Problem prob = ((ProblemStubCallable)callable).problem;

    dbg.println("client problem = \n" + tmpProb);
    
    if (!tmpProb.partialEqual(prob)){
      dbg.println("problem from agent differs from client ones: abort");
      dbg.println("server prob = " + prob);
      os.writeInt(GlobalDefs.PB_REFUSED);
      os.flush();
      return true;
    } 
    os.writeChar(GlobalDefs.DATA_XDR);
    os.writeInt(GlobalDefs.PB_ACCEPTED);
    os.flush();

    int dummy = is.readChar();
    System.out.println("dummy = " + dummy);
    callable.call(null, 0, is, os);
    return true;
  }

  boolean processPongBandWidth(XDRInputStream is, XDROutputStream os) throws IOException, NinfException{
    int size = 0;
    dbg.println("processing pong bandwidth");
    while ((size = is.readInt()) > 0){
      dbg.println("size = "+ size);
      dbg.println("reading");
      int tmp[] = new int[size];
      for (int i = 0; i < size; i++)
	tmp[i] = is.readInt();

      dbg.println("writing");
      os.writeChar(GlobalDefs.DATA_XDR);
      for (int i = 0; i < size; i++)
	os.writeInt(tmp[i]);
      int dummy = is.readChar();
    }
    return false;
  }

  /** dispatch jobs according to packet code */
  public boolean dispatchRequest(XDRInputStream is, XDROutputStream os) {

    int code = 0;
    try {
      int mode = is.readChar();
      code = is.readInt();
    } catch (IOException e) {
      System.out.println("connection closed");
      //      e.printStackTrace(dbg.os);
      return false;
    }
    try {
      dbg.println("Adapter read code:" + code);
      switch (code) {
      case GlobalDefs.PROBLEM_SOLVE: 
	return processProblemSolve(is, os);

      case GlobalDefs.PONG_BANDWIDTH:
	return processPongBandWidth(is, os);
      case GlobalDefs.WHO_ARE_YOU:
      case GlobalDefs.PONG_LATENCY:
      case GlobalDefs.POLL_KILL:	
      case GlobalDefs.ARE_YOU_ALIVE:      
      case GlobalDefs.I_EXIST:
      case GlobalDefs.I_DIE:
      default:

	return false;
      }
    } catch (Exception e) {
      e.printStackTrace(dbg.os);
      return false;
    }
  }
  public void serviceRequest() {
    XDRInputStream is = new XDRInputStream(clientInput);
    XDROutputStream os = new XDROutputStream(clientOutput);
    
    while (dispatchRequest(is, os))
      ;
  }

  void start() throws NinfException{
    introduceToAgent();
    startServer(myport);
    dbg.log("[" +myport+"] start ..");
  }

}
