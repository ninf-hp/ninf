package ninf.cproxy.aggregate;
import ninf.basic.*;
import ninf.client.*;
import ninf.cproxy.*;


import java.util.Vector;
import java.io.IOException;

public class NinfWriteBackThread extends NinfThread {
  XDROutputStream os;
  NinfStub stub;
  CallContext context;
  NinfLog dbg = new NinfLog(this);
  CompoundCallable comp;

  public NinfWriteBackThread(XDROutputStream s, NinfStub st, 
			     CallContext context, CompoundCallable comp){
    stub = st;
    os = s;
    this.context = context;
    this.comp = comp;
  }

  void sendDummyInformation(NinfPacketOutputStream pos) throws NinfException{
    pos.writeDouble(comp.foreTime);
    pos.writeDouble(comp.compTime);
    pos.writeDouble(comp.backTime);
    pos.writeString("CProxy on "+ CProxy.conf.myhostname);
    pos.writeInt(CProxy.conf.port);
  }


  public void runSub(){
    try{
      dbg.println("NinfWriteBackThread Starts");
      if (succeeded){
	dbg.println("transaction endded successfully");	
	NinfPacketOutputStream pos = new NinfPacketOutputStream(os, false);
	stub.serverSend(context, pos);
	sendDummyInformation(pos);
	pos.flush();
      }else {
	dbg.println("transaction failed");	
	NinfPacketOutputStream pos =
	  new NinfPacketOutputStream(os, NinfPktHeader.NINF_PKT_ERROR, 
				     NinfError.CANTEXECUTESTUB, 0);
	pos.writeInt(NinfConstant.NINF_ACK_ERROR);
	pos.flush();
      } 
      comp.finished();
    } catch (Exception e){
      dbg.println("A " + e +" occured in NinfWriteBackThread");
    }
  }
}
