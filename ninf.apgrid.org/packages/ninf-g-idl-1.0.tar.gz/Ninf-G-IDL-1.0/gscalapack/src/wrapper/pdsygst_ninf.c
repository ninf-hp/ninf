#define _WRAPPER_
/* $Id: pdsygst_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define DOUBLE
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n
#define ROW_b ldb
#define COL_b n
void  pdsygst_ninf(	 int ibtype,
		 char uplo,
		 int n,
		 double global_a[],
		 int lda,
		 double global_b[],
		 int ldb,
		 double *scale,
		 int *info
)
/* "pdsygst reduces a real symmetric-definite generalized eigenproblem to standard form." */
/* OPTIONS */
{
	int maxldd;

	int maxlda;
	double *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
	int row_loca, col_loca;

	int maxldb;
	double *locb=NULL;
	int descb[DESCLEN];
	int desc_gb[DESCLEN];
	int row_locb, col_locb;

	double lscale[1];

	INITIALIZE();

	SCALAR( "int", ibtype);
	SCALAR( "char", uplo);
	SCALAR( "int", n);
	SCALAR("int",lda);
	SCALAR("int",ldb);

	ROW( a);
	COL( a);
	ROW( b);
	COL( b);
	MAXLDD( maxldd, a );
	maxlda = maxldd;
	maxldb = maxldd;

	trMATRIX( uplo, "double", a, ROW_a, COL_a);
	trDISTRIBUTE( uplo, "double", a, ROW_a, COL_a);
	MATRIX( "double", b, ROW_b, COL_b);
	DISTRIBUTE( "double", b, ROW_b, COL_b);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pdsygst)( &ibtype, &uplo, &n,
			       loca, &one, &one, desca,
			       locb, &one, &one, descb,
			       lscale,
			       &linfo);

	GATHER( "double", a, ROW_a, COL_a);

	RETRIEVE("double", lscale, 1);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
	  *info = linfo;
	  *scale = lscale[0];
	} else {
		
	}

	FREE_MATRIX(a);
	FREE_MATRIX(b);
}

