#include <stdio.h>
#include "ninf_macros.h"
#include "id_set.h"


id_set * new_id_set(){
  id_set * tmp;
  tmp = (id_set *) malloc(sizeof(id_set));
  if (tmp == NULL)
    return NULL;
  tmp->content = (int *)malloc(sizeof(int) * ID_SET_SIZE);
  if (tmp->content == NULL)
    return NULL;
  tmp->length = 0;
  return tmp;
}

void free_id_set(id_set * set){
  free(set->content);
  free(set);
}

void clear_id_set(id_set * set){
  set->length = 0;
}

int id_set_add(id_set * set, int id){
  if (set == NULL) return FALSE;
  if (set->length >= ID_SET_SIZE)
    return FALSE;              /* index out of range */  
  set->content[(set->length)++] = id;
  return TRUE;
}

int id_set_rm(id_set * set, int index){
  int i;
  if (set == NULL) return FALSE;
  if (index >= set->length)
    return FALSE;              /* index out of range */

  for (i = index; i < set->length; i++){
    set->content[i] = set->content[i+1];
  }
  (set->length)--;
  return TRUE;
}

int id_set_get_id(id_set * set, int index){
  if (set == NULL) return -1;  
  if (index >= set->length)
    return -1;              /* index out of range */
  return set->content[index];
}

int * id_set_content(id_set * set){
  return set->content;
}
int id_set_length(id_set * set){
  return set->length;
}

void id_set_dump(id_set * set, FILE * fd){
  int i;
  for (i = 0; i < id_set_length(set); i++)
    fprintf(fd, "%d ", id_set_get_id(set, i));
  fprintf(fd,  "\n");
}
