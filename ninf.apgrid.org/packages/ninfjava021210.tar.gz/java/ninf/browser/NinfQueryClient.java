package ninf.browser;

import ninf.client.*;
import ninf.basic.NinfException;
import ninf.basic.NinfIOException;

class NinfQueryClient extends NinfClient {
    public NinfQueryClient(String host,int port) throws NinfIOException {
	super(host,port);
    }
    public NinfStub [] query(String key) throws NinfException {
	connectServer();
	NinfStub [] stubs = con.query(key);
	disconnect();
	return stubs;
    }
    public int [] getIndexes(String key) throws NinfException {
	connectServer();
	int [] indexes = con.getIndexes(key);
	disconnect();
	return indexes;
    }
	
    public NinfStub getStub(int index) throws NinfException {
	connectServer();
	NinfStub stub = con.getStub(index);
	disconnect();
	return stub;
    }
}
