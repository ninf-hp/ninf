#ifndef __GET_LOAD__
#define __GET_LOAD__

struct load {
  double loadAverage;
  double user, system, idle;
};

void get_load(struct load * l);

#endif /* __GET_LOAD__ */

