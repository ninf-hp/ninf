#define _WRAPPER_
/* $Id: pdptsv_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define _DISTRIBUTE_1D_
#define DOUBLE
#include <gscalapack.h>
#define ROW_b ldb
#define COL_b nrhs

static	int worklen(int n, int nrhs){
	  int ret=1;
          ret = 3*n+12+max((10+2*min(100,nrhs))+4*nrhs, 8);
	  if NEED_BUFF ret= (12*npcol + 3*blocsize)  +max((10+2*min(100,nrhs))*npcol+4*nrhs, 8*npcol);
	  return ret;
}

void  pdptsv_ninf(	 int n,
		 int nrhs,
		 double global_d[],
		 double global_e[],
		 double global_b[],
		 int ldb,
		 int *info
)
/* "pdptsv solves a system of linear equations A * X = B where A is an N-by-N real tridiagonal symmetric positive definite distributed matrix." */
/* OPTIONS */
{
    extern void FortranCall(pdptsv)( int*, int*,
                              double*, double*, int*, int*,
                              double*, int*, int*,
                              double*, int*, int*);

	int maxldd;

	double *locb=NULL;
	int maxldb;
	int row_locb;
	int col_locb;
	int descb[DESCLEN];
	int desc_gb[DESCLEN];

	int desc_gtdd[DESCLEN];
	int desctdd[DESCLEN];
	double *locd=NULL;
	double *loce=NULL;

	double *locwork=NULL;
	int llocwork;


	INITIALIZE();

	SCALAR( "int", n);
	SCALAR( "int", nrhs);
	SCALAR("int", ldb);
	SIZE(n);

	ROW(b);
	COL(b);
	MAXLDD(maxldd, b);
	maxldb=maxldd;

	/* TDMATRIX(dl,d,du, n )  determines tridiagonal matrix */

	tdMATRIX( "double", e, d, e, n);
	MATRIX("double", b, ROW_b, COL_b);
	tdDISTRIBUTE( "double", e, d, e, n);
	DISTRIBUTE( "double", b, ROW_b, COL_b);

	llocwork = worklen(n, nrhs);
	WORK( locwork, llocwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pdptsv)( &n, &nrhs,
                              locd, loce, &one, desctdd,
                              locb, &one, descb,
                              locwork, &llocwork, &linfo);

	tdGATHER( "double", e, d, e, n);
	GATHER("double", b, ROW_b, COL_b);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
	  *info = linfo;
	} else {
		
	}
	FREE_MATRIX(d);
	FREE_MATRIX(e);
	FREE_MATRIX(b);
        FREE(locwork);
}

