#ifndef _NINF_Q_PROTOCOL_H
#define _NINF_Q_PROTOCOL_H

/********************* for req_stub_index_list **********************/
#define MATCH_PARTIAL           0       /* partial match */
#define MATCH_EXACT             1       /* exact match   */

#endif /* _NINF_Q_PROTOCOL_H */

