package bricks.util;
import bricks.environment.*;
import bricks.scheduling.*;
import java.util.*;
import java.io.*;

public class SimulationSet {

    public RouteService routeService = new RouteService();

    public LogicalPacket logicalPacket = new LogicalPacket();
    protected Hashtable hashtableOfObj = new Hashtable();
    protected Hashtable hashtableOfNetworkMonitor = new Hashtable();
    protected Hashtable hashtableOfServerMonitor = new Hashtable();
    protected Hashtable hashtableOfResourceDB = new Hashtable();
    protected Hashtable hashtableOfMetaPredictor = new Hashtable();
    protected Hashtable hashtableOfScheduler = new Hashtable();
    protected Hashtable hashtableOfReplicaManager = new Hashtable();
    protected Vector hostList = new Vector();
    protected Vector networkList = new Vector();
    protected Hashtable forwardNodeList = new Hashtable();
    //protected Hashtable dataFragmentIDs = new Hashtable();
    //static protected int dataFragmentID = 0;

    public PrintWriter requestLogWriter;
    public PrintWriter serverLogWriter;
    public PrintWriter diskLogWriter;
    public PrintWriter networkLogWriter;
    public PrintWriter serverMonitorLogWriter;
    public PrintWriter networkMonitorLogWriter;
    public PrintWriter replicaManagerLogWriter;

    public SimulationSet(OutputStream osOfRequestLog) {
	requestLogWriter = BricksUtil.getWriter(osOfRequestLog);
	requestLogWriter.println(
            "# Job_ID Input_data_size Output_data_size Comp_size Source Destination");
	requestLogWriter.println(
	    "# Time_start Duration_send Duration_exec Duration_recv Duration_total");
	//requestLogWriter.println(
	//    "# (Time_deadline Time_estimated_finish Time_deadline_factor)");
    }

    // for debug
    public SimulationSet(InputStream isOfSimulationSet) {
	initOfDebug(isOfSimulationSet);
    }

/************************* public method *************************/
    public void setNetworkLog(OutputStream os) {
	networkLogWriter = BricksUtil.getWriter(os);
	networkLogWriter.println("# Network_ID Time Queue_length");
    }

    public void setServerLog(OutputStream os) {
	serverLogWriter = BricksUtil.getWriter(os);
	serverLogWriter.println("# Server_ID Time Queue_length");
    }

    public void setDiskLog(OutputStream os) {
	diskLogWriter = BricksUtil.getWriter(os);
	diskLogWriter.println("# Disk_ID Host_ID Size_available Size_total Num_data");
    }

    public void setNetworkMonitorLog(OutputStream os) {
	networkMonitorLogWriter = BricksUtil.getWriter(os);
	networkMonitorLogWriter.println(
	    "# NetworkMonitor_ID [Source - Destination] Time_probe Throughput Latency"
	);
    }

    public void setServerMonitorLog(OutputStream os) {
	serverMonitorLogWriter = BricksUtil.getWriter(os);
	serverMonitorLogWriter.println(
	    "# ServerMonitor_ID Host_ID Time_probe Duration_tracking Load_avg CPU_utilization"
	);
    }

    public void setReplicaManagerLog(OutputStream os) {
	replicaManagerLogWriter = BricksUtil.getWriter(os);
    }

    public void init(InputStream is) throws BricksParseException {
	try {
	    SimulationDebug.println("initComponents() in SimulationSet.init()");
	    initComponents(is);
	} catch (BricksParseException e) {
	    throw e;
	}

	SimulationDebug.println("initLinks() in SimulationSet.init()");
	//System.out.println(toStringOfHashtableOfObj());
	initLinks();

	/* initRouteService */
	SimulationDebug.println("init routes in SimulationSet.init()");
	SimulationDebug.println("init host...");
	routeService.initRoutes(hosts());

	SimulationDebug.println("init ResourceDBs in SimulationSet.init()");
	initResourceDBs();

	SimulationDebug.println("init Monitors in SimulationSet.init()");
	initMonitors();

	SimulationDebug.println("init Schedulers in SimulationSet.init()");
	initSchedulers();
	//System.out.println(toInitString());

	SimulationDebug.println("init ReplicaManagers in SimulationSet.init()");
	initReplicaManagers();
    }

    public void finish() {
	Enumeration e = hashtableOfResourceDB.elements();
	while (e.hasMoreElements()) {
	    ResourceDB db = (ResourceDB)e.nextElement();
	    db.finish();
	}
	e = hostList.elements();
	while (e.hasMoreElements()) {
	    Host host = (Host)e.nextElement();
	    host.finish();
	}
	requestLogWriter.close();
	if (serverMonitorLogWriter != null)
	    serverMonitorLogWriter.close();
	if (networkMonitorLogWriter != null)
	    networkMonitorLogWriter.close();
	if (replicaManagerLogWriter != null)
	    replicaManagerLogWriter.close();
	if (serverLogWriter != null)
	    serverLogWriter.close();
	if (networkLogWriter != null)
	    networkLogWriter.close();
	if (diskLogWriter != null)
	    diskLogWriter.close();
    }

    public void register(ForwardNode node) {
	forwardNodeList.put(node.key, node);
    }

    public void register(String key, Host host) {
	hashtableOfObj.put(key, host);
	hostList.addElement(host);
    }

    public void register(String key, Network node) {
	hashtableOfObj.put(key, node);
	networkList.addElement(node);
    }

    public void register(String key, NetworkMonitor networkMonitor) {
	hashtableOfObj.put(key, networkMonitor);
	hashtableOfNetworkMonitor.put(key, networkMonitor);
    }

    public void register(String key, ServerMonitor serverMonitor) {
	hashtableOfObj.put(key, serverMonitor);
	hashtableOfServerMonitor.put(key, serverMonitor);
    }

    public void register(String key, ReplicaManager replicaManager) {
	hashtableOfObj.put(key, replicaManager);
	hashtableOfReplicaManager.put(key, replicaManager);
    }

    public void register(String key, Scheduler scheduler) {
	hashtableOfScheduler.put(key, scheduler);
    }

    public void register(String key, MetaPredictor metaPredictor) {
	hashtableOfMetaPredictor.put(key, metaPredictor);
    }

    public void register(String key, ResourceDB db) {
	hashtableOfResourceDB.put(key, db);
    }

    public Node getNode(String key) {

	//SimulationDebug.println("SimulationSet: getNode( " + key + " )");
	//SimulationDebug.println(hashtableOfObj);

	Node node = (Node)hashtableOfObj.get(key);
	if (node == null) {
	    SimulationDebug.println(forwardNodeList);
	    node = (Node)forwardNodeList.get(key);
	}
	//SimulationDebug.println("SimulationSet: return " + node);
	return node;
    }

    public Host getHost(String key) {
	return (Host)hashtableOfObj.get(key);
    }

    public NetworkMonitor getNetworkMonitor(String key) {
	return (NetworkMonitor)hashtableOfNetworkMonitor.get(key);
    }

    public ServerMonitor getServerMonitor(String key) {
	return (ServerMonitor)hashtableOfServerMonitor.get(key);
    }

    public ReplicaManager getReplicaManager(String key) {
	return (ReplicaManager)hashtableOfReplicaManager.get(key);
    }

    public Scheduler getScheduler(String key) {
	return (Scheduler)hashtableOfScheduler.get(key);
    }

    public ResourceDB getResourceDB(String key) {
	return (ResourceDB)hashtableOfResourceDB.get(key);
    }

    public MetaPredictor getMetaPredictor(String key) {
	return (MetaPredictor)hashtableOfMetaPredictor.get(key);
    }

    public int numNodes() {
	return hashtableOfObj.size() - hashtableOfNetworkMonitor.size()
	    - hashtableOfServerMonitor.size() + forwardNodeList.size()
	    - hashtableOfReplicaManager.size();
    }

    public int numHosts() {
	return hostList.size();
    }

    public int numObjs() {
	return hashtableOfObj.size();
    }

    public Enumeration objs() {
	return hashtableOfObj.elements();
    }

    public Enumeration networks() {
	return networkList.elements();
    }

    public Enumeration hosts() {
	return hostList.elements();
    }

    public Enumeration forwardNodes() {
	return forwardNodeList.elements();
    }

    public Enumeration networkMonitors() {
	return hashtableOfNetworkMonitor.elements();
    }

    public Enumeration serverMonitors() {
	return hashtableOfServerMonitor.elements();
    }

    public Enumeration replicaManagers() {
	return hashtableOfReplicaManager.elements();
    }

    public Enumeration schedulers() {
	return hashtableOfScheduler.elements();
    }

    public Enumeration metaPredictors() {
	return hashtableOfMetaPredictor.elements();
    }

    public Enumeration resourceDBs() {
	return hashtableOfResourceDB.elements();
    }

    public Vector getHostList() {
	return (Vector)hostList.clone();
    }

    public Host getHost(int index) {
	return (Host)hostList.elementAt(index);
    }

    /******************** for RouteService ********************/
    /** getRoute returns clone of the route */
    public Vector getRoute(Node source, Node destination) {
	return getRoute(new NodePair(source, destination));
    }

    /** getRoute returns clone of the route */
    public Vector getRoute(NodePair pair) {
	return routeService.get(pair);
    }

    /** getRouteForLoad returns clone of the route */
    public Vector getRouteForLoad(Host source, Host destination) {
	Vector v;
	if (source.equals(destination)) {
	    v = new Vector();
	    v.add(source);
	    Disk disk = source.getDisk();
	    if (disk != null)
		v.add(disk);
	    v.add(source);
	} else {
	    v = getRoute(source, destination);
	    Host host = (Host)v.firstElement();
	    Disk disk = host.getDisk();
	    if (disk != null)
		v.insertElementAt(disk, 1);
	    host = (Host)v.lastElement();
	    disk = host.getDisk();
	    if (disk != null) {
		v.insertElementAt(disk, v.size() - 1);
	    }
	}
	return v;
    }

    /** getRouteForStore returns clone of the route */
    public Vector getRouteForStore(Host source, Host destination) {
	Vector v;
	if (source.equals(destination)) {
	    v = new Vector();
	    v.add(source);
	    Disk disk = source.getDisk();
	    if (disk != null)
		v.add(disk);
	    v.add(source);
	} else {
	    v = getRoute(source, destination);
	    Host host = (Host)v.firstElement();
	    Disk disk = host.getDisk();
	    if (disk != null)
		v.insertElementAt(disk, 1);
	    host = (Host)v.lastElement();
	    disk = host.getDisk();
	    if (disk != null) {
		v.insertElementAt(disk, v.size() - 1);
	    }
	}
	return v;
    }

    public int numRoutes() {
	return routeService.size();
    }

    public Enumeration routes() {
	return routeService.keys();
    }

    public String toOriginalString(double currentTime) {
	String str = "[SimulationSet] Num of Node = " + numNodes() + "\n";
	Enumeration e = hosts();
	while (e.hasMoreElements()) {
	    Node node = (Node)e.nextElement();
	    str += node.toOriginalString(currentTime);
	}
	e = networks();
	while (e.hasMoreElements()) {
	    Node node = (Node)e.nextElement();
	    str += node.toOriginalString(currentTime);
	}
	return str;
    }

    // for PassiveReplicaManager
    public void replicate(
	double currentTime, Host dataDestination, DataFragment fragment
    ) {
	Enumeration e = replicaManagers();
	((ReplicaManager)e.nextElement()).replicate(
	    currentTime, dataDestination, fragment
        );
    }

    /******************** for DataReference ********************/
    /*
    public String generatesDataID(DataFragment d) {
	String id = (new Integer(dataFragmentID)).toString();
	dataFragmentIDs.put(id, d);
	dataFragmentID++;
	return id;
    }

    public DataFragment getDataFragment(String id) {
	return (DataFragment)dataFragmentIDs.get(id);
    }
    */

    /************************* private method *************************/
    private void initComponents(InputStream inputStreamOfSimulationSet) 
	 throws BricksParseException 
    {

	ComponentFactory componentFactory = new ComponentFactory(this);
	BufferedReader br = new BufferedReader(
	    new InputStreamReader(inputStreamOfSimulationSet)
	);

	String line = null;
	String head = null;
	// packet line
	try {
	    while ((line = br.readLine()) != null) {
		StringTokenizer st = new StringTokenizer(line);
		if (!st.hasMoreElements())
		    continue;
		head = st.nextToken(" \t()");
		if(!comment(head))
		    break;
	    }
	    line = readOneInfomation(line, br);
	    //serverLogWriter.println(line);
	    logicalPacket.set(head, line);

	    // creates component
	    while ((line = br.readLine()) != null) {
		StringTokenizer st = new StringTokenizer(line);
		if (!st.hasMoreElements())
		    continue;
		head = st.nextToken(" \t()");

		if(comment(head))
		    continue;
		line = readOneInfomation(line, br);

		SimulationDebug.println("first word is [" + head + "]");
		SimulationDebug.println("first line is [" + line + "]");

		//serverLogWriter.println(line);
		componentFactory.create(head, line);
	    }

	} catch (IOException e) {
	    throw new BricksParseException("line: " + line);

	} catch (BricksParseException e) {
	    e.addMessage("line: " + line);
	    throw e;
	}
    }

    private String readOneInfomation(String line, BufferedReader br) 
	throws IOException 
    {
	String tmp;
	try {
	    while ((tmp = tailCheck(line)) != null) {
		String nextLine;
		while ((nextLine = br.readLine()) != null) {
		    StringTokenizer st = new StringTokenizer(nextLine);
		    if (!st.hasMoreElements()) {
			line = tmp;
			break;
		    }
		    if (comment(st.nextToken(" \t"))) {
			continue;
		    } else {
			line = tmp + " " + nextLine;
			break;
		    }
		}
		if (nextLine == null) {
		    line = tmp;
		    break;
		}
	    }
	} catch (IOException e) {
	    e.printStackTrace();
	    throw e;
	}
	return line;
    }

    private boolean comment(String str) {
	if (str.charAt(0) == '#') {
	    return true;
	} else {
	    return false;
	}
    }

    private String tailCheck(String str) {
	char[] line = str.toCharArray();

	int index = str.length() - 1;
	while (index > 0) {
	    //Character c = new Character(line[index]);
	    if ((line[index] == ' ') || (line[index] == '\t')) {
		index--;
		continue;
	    }
	    if (line[index] == '\\') {
                return str.substring(0, index);
	    } else {
                return null;
	    }
        }
        return null;
    }

    private void initLinks() {
	Enumeration e = hosts();
	while (e.hasMoreElements()) {
	    Host host = (Host)e.nextElement();
	    Vector list = new Vector();
	    host.tracePath(list);
	}
    }

    private void initMonitors() {
	Enumeration e = networkMonitors();
	while (e.hasMoreElements())
	    ((NetworkMonitor)e.nextElement()).init(this);
	e = serverMonitors();
	while (e.hasMoreElements())
	    ((ServerMonitor)e.nextElement()).init(this);
    }

    private void initReplicaManagers() {
	Enumeration e = replicaManagers();
	while (e.hasMoreElements())
	    ((ReplicaManager)e.nextElement()).init(this);
    }

    private void initResourceDBs() {
	Enumeration e = resourceDBs();
	while (e.hasMoreElements()) {
	    ResourceDB resourceDB = (ResourceDB)e.nextElement();
	    resourceDB.init(this);
	}
    }

    private void initSchedulers() {
	Enumeration e = schedulers();
	while (e.hasMoreElements()) {
	    Scheduler scheduler = (Scheduler)e.nextElement();
	    scheduler.init(this);
	}
    }

    // debug
    private String toStringOfHashtableOfObj() {
	String str = "hashtableOfObj : ";
	Enumeration e = objs();
	while (e.hasMoreElements()) {
	    Node node = (Node)e.nextElement();
	    str += node + ", ";
	}
	return str;
    }

    private String toInitString() {
	String str = "\n[SimulationSet] Num of Node = " + numNodes() + "\n";
	str += "  [packet] " + logicalPacket.packetSize + "\n";
	    //", " + interarrivalTimeOfPacket + "\n";
	Enumeration e = objs();
	while (e.hasMoreElements()) {
	    Obj obj = (Obj)e.nextElement();
	    str += obj.toInitString();
	}
	return str;
    }

    // for debug
    private void initOfDebug(InputStream is) {
	try {
	    initComponents(is);
	} catch (BricksParseException e) {
	    BricksUtil.abort("debug error");
	}
	initLinks();
	initSchedulers();
    }

/****************************** debug ******************************/
    public static void main(String[] argv) {
	String fileName = "system2.dat";
	try {
	    FileInputStream fis = new FileInputStream(fileName);
	    SimulationSet simulationSet = new SimulationSet(fis);
	} catch (FileNotFoundException fnfe) {
	    fnfe.printStackTrace();
	}
    }
}
