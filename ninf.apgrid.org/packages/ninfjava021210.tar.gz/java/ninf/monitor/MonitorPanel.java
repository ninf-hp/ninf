package ninf.monitor;
import java.awt.*;
import ninf.basic.*;
import ninf.common.*;

public class MonitorPanel extends Panel {
  Frame frame;
  TextField host, port;
  TextArea logWindow;
  StubPanel stubPanel;
  ServerListPanel serverListPanel;
  Button connect;
  Button disconnect;
  Button dispose;
  Choice schedulerChoice;
  Choice predictorChoice;
  Monitor monitor;

  Font font = new Font("Helvetica", Font.BOLD, 12);

  String schedulers[] = {
    "", "RoundRobinScheduler",
    "LoadOnlyScheduler",       
    "LoadThroughputScheduler",
    "ThrottleScheduler",
    "Throttle2Scheduler",
    "Throttle3Scheduler"
  };

  String predictors[] = {
    "", 
    "LoadUpPredictor",
    "LoadBlockPredictor LoadUpPredictor",
    "ThroughputPredictor LoadUpPredictor",
  };

  void initSchedulerChoice(){
    schedulerChoice = new Choice();
    for (int i = 0; i < schedulers.length; i++){
      schedulerChoice.addItem(schedulers[i]);
    }
  }

  void initPredictorChoice(){
    predictorChoice = new Choice();
    for (int i = 0; i < predictors.length; i++){
      predictorChoice.addItem(predictors[i]);
    }
  }
  
  public MonitorPanel(String hostName, String portName){
    monitor = new Monitor(this);
    this.setFont(font);
    Panel buttonPanel = new Panel();
    connect = new Button("Connect");
    buttonPanel.add(connect);
    disconnect = new Button("Disconnect");
    buttonPanel.add(disconnect);
    dispose = new Button("Dispose");
    buttonPanel.add(dispose);
    initSchedulerChoice();
    initPredictorChoice();

    Panel textPanel = new Panel();
    if (hostName == null)
      host = new TextField("", 20);
    else
      host = new TextField(hostName, 20);
    if (portName == null)
      port = new TextField("", 20);
    else
      port = new TextField(portName, 20);
    
    textPanel.setLayout(new GridLayout(5,1));
    { 
      Panel tmpPanel = new Panel();
      tmpPanel.add(new Label("Host"));
      tmpPanel.add(host);
      textPanel.add(tmpPanel);
    }
    { 
      Panel tmpPanel = new Panel();
      tmpPanel.add(new Label("Port"));
      tmpPanel.add(port);
      textPanel.add(tmpPanel);
    }
    textPanel.add(buttonPanel);
    { 
      Panel tmpPanel = new Panel();
      tmpPanel.add(schedulerChoice);
      textPanel.add(tmpPanel);
    }
    { 
      Panel tmpPanel = new Panel();
      tmpPanel.add(predictorChoice);
      textPanel.add(tmpPanel);
    }

    serverListPanel = new ServerListPanel(this.monitor);

    Panel tmpPanel0 = new Panel();
    tmpPanel0.setLayout(new BorderLayout());
    tmpPanel0.add("West", textPanel);
    tmpPanel0.add("Center", serverListPanel);
    
    stubPanel = new StubPanel(monitor);

    // this.setLayout(new GridLayout(2,1));
    // this.add(tmpPanel0);
    // this.add(stubPanel);
    
    logWindow = new TextArea(80, 25);
    logWindow.setEditable(false);
    logWindow.setFont(new Font("Helvetica", Font.BOLD, 8));
    logWindow.setFont(font);
    logWindow.setBackground(Color.white);
    
    double ratio[] = {0.3, 0.5, 0.2};
    this.setLayout(new RatioLayout(RatioLayout.VERTICAL, ratio));
    this.add(tmpPanel0);
    this.add(stubPanel);
    this.add(addLabel("Schduler Log", logWindow));
  }  

  Panel addLabel(String str, Component comp){
    Panel tmp = new Panel();
    tmp.setLayout(new BorderLayout());
    Label label = new Label(str, Label.CENTER);
    label.setBackground(Color.darkGray);
    label.setForeground(Color.white);
    tmp.add("Center", comp);
    tmp.add("North", label);
    return tmp;
  }


  /** Method to display self on a Window */
  public void show(){
    frame = new Frame("Scheduling Module Monitor");
    frame.add("Center", this);
    frame.resize(600, 600);
    frame.show();
  }

  public void dispose(){
    if (monitor.connected())
      print("disconnect first.");
    else
      if (frame != null){
	frame.dispose();
	frame = null;
      }
  }

  void correctInfo(){
    String s = monitor.getScheduler();
    if (s != null)
      schedulerChoice.select(s);
    s = monitor.getPredictors();
    if (s != null)
      predictorChoice.select(s);
  }

  void connect(){
    print("connecting ...");
    if (monitor.connect(host.getText(), port.getText())){
      correctInfo();
      println("  connected");
    } else
      println("  refused");	
  }

  void disconnect(){
      println("disconnect");
      schedulerChoice.select("");
      predictorChoice.select("");
      stubPanel.clearDescription();
      monitor.disconnect();
      repaint();
  }

  public boolean action(Event evt, Object arg){
    if (evt.target == connect){         /* accept button pressed */
      connect();
      return true;
    } else if (evt.target == disconnect){  
      disconnect();
      return true;
    } else if (evt.target == dispose){  
      dispose();
      return true;
    } else if (evt.target == schedulerChoice){  
      println("select "+arg);
      if (!(monitor.selectScheduler((String)arg))){
	schedulerChoice.select("");
	println("selection failed "+arg);
      }
      return true;
    } else if (evt.target == predictorChoice){  
      println("select "+arg);
      if (!(monitor.selectPredictor((String)arg))){
	predictorChoice.select("");
	println("selection failed "+arg);
      }
      return true;
    } else {
      return false;
    }
  }

  public void print(Object o){
    logWindow.appendText(""+ o);
  }
  public void println(Object o){
    logWindow.appendText(""+ o + "\n");
  }

}

