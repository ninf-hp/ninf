package ninf.netsolve;
import java.net.Socket;
import java.io.IOException;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.util.Vector;
import ninf.client.BufferObject;

public class MyStream {
  private int encoding;

  public Socket s = null;
  public DataInputStream server_in;
  public DataOutputStream server_out; 

  public void init_recv(int enc) {
    if((enc != GlobalDefs.DATA_RAW) && (enc != GlobalDefs.DATA_XDR))
    {
      System.err.println("MyStream:init_recv() Warning: " + 
          "Invalid encoding ("+enc+"), using XDR.");
      encoding = GlobalDefs.DATA_XDR;
    }
    else
      encoding = enc;
  }
      
  public byte[] read_IPaddr() throws java.io.IOException {
    int [] b = new int [4];
    byte [] c = new byte [16];
    int i;

    /*
    if(encoding == GlobalDefs.DATA_XDR) {

      server_in.readFully(c,0,16);

      return(((0xFF & c[3]) << 24) | 
             ((0xFF & c[7]) << 16) | 
             ((0xFF & c[11]) << 8) |
              (0xFF & c[15]));
    } else {
      return(server_in.readInt());
    }
    */
      server_in.readFully(c,0,16);
    byte ans[] = new byte[4];
    ans [0] = c[3];
    ans [1] = c[7];
    ans [2] = c[11];
    ans [3] = c[15];
    return ans;

  }

  public void write_IPaddr(byte addr[]) throws java.io.IOException {
    /*
    if(encoding == GlobalDefs.DATA_XDR) {
      server_out.writeInt( (addr >> 24) & 0xFF);
      server_out.writeInt( (addr >> 16) & 0xFF);
      server_out.writeInt( (addr >>  8) & 0xFF);
      server_out.writeInt( addr & 0xFF);
    } else {
      server_out.writeInt(addr);
    }
    */
    server_out.writeInt(((int)addr[0]) & 0xFF);
    server_out.writeInt(((int)addr[1]) & 0xFF);
    server_out.writeInt(((int)addr[2]) & 0xFF);
    server_out.writeInt(((int)addr[3]) & 0xFF);

  }

  public void write_string(String str) throws java.io.IOException {  
    int i, pad, length;

    if(encoding == GlobalDefs.DATA_XDR) {
      length = str.length();
      pad = (4 * (length/4 + 1) - length) % 4;

      System.out.println("Writing string in XDR mode....");
      System.out.println("length = " +length+ " pad = " + pad);
      System.out.println(str);
      server_out.writeInt(str.length());
      server_out.writeBytes(str);
      for(i=0;i<pad;i++)
        server_out.writeByte(0);
    } else {
      System.out.println("Writing string in RAW mode....");
      System.out.println(str);
      server_out.writeBytes(str);
      server_out.writeByte(0);     //terminate the string
    }
  }

  public String get_string() throws java.io.IOException {  
    StringBuffer temp;
    byte [] temp2;
    String str;
    int i,length, pad=0;
    byte resp;

    if(encoding == GlobalDefs.DATA_XDR) {
      length = this.server_in.readInt();
      pad = (4 * (length/4 + 1) - length) % 4;
   System.out.println("len = " + length);
      temp2 = new byte[length];
      server_in.readFully(temp2,0,length);

      str = new String(temp2,0);

      for(i=0;i<pad;i++)
        server_in.readByte();

      return(str);
    } else {

      // not the best way to write this, but the simplest

      temp= new StringBuffer(200);
      while( (resp = server_in.readByte()) != 0 )
        temp.append((char)resp);
      return(temp.toString());
    }
  }
    
  public void shut_down() throws java.io.IOException {
    server_in = null;
    server_out = null;
    s.close();
  }

  public void write_scalar(BufferObject bo)   throws java.io.IOException {
    server_out.write(bo.data);
  }

  public void write_vector(BufferObject bo, int m)   throws java.io.IOException {
    System.out.println("sending m = " + m);
    this.server_out.writeInt(m);     // first send m (num elements)
    server_out.write(bo.data);
  }

  public void write_matrix(BufferObject bo, int m, int n)   throws java.io.IOException {
    System.out.println("sending m = " + m);
    this.server_out.writeInt(m);     // first send m (num elements)
    System.out.println("sending n = " + n);
    this.server_out.writeInt(n);     // first send n (num elements)
    server_out.write(bo.data);
  }

  public void write_scalar(Vector [] v, int i, int data_type) 
   throws java.io.IOException {
    int j;

/*
    if(encoding == GlobalDefs.DATA_XDR) {
      this.server_out.writeInt(1);   // if XDR, send as array of length 1
    }
*/

    switch(data_type) {
      case NetSolveObject.NETSOLVE_I:

        for(j=0;j < v[i].size();j++)
          if(((int [])v[i].elementAt(j)).length > 0) {
            this.server_out.writeInt(
              ((int [])v[i].elementAt(j))[0]);
            System.out.println("sending int "+
              ((int [])v[i].elementAt(j))[0]);
            break;
          }
        break;
      case NetSolveObject.NETSOLVE_S:

        for(j=0;j < v[i].size();j++)
          if(((float [])v[i].elementAt(j)).length > 0) {
            this.server_out.writeFloat(
              ((float [])v[i].elementAt(j))[0]);
            System.out.println("sending float "+
              ((float [])v[i].elementAt(j))[0]);
            break;
          }
        break;
      case NetSolveObject.NETSOLVE_D:

        for(j=0;j < v[i].size();j++)
          if(((double [])v[i].elementAt(j)).length > 0) {
            this.server_out.writeDouble(
              ((double [])v[i].elementAt(j))[0]);
	    //            System.out.println("sending double "+
	    //              ((double [])v[i].elementAt(j))[0]);
            break;
          }
        break;
      case NetSolveObject.NETSOLVE_C:

        for(j=0;j < v[i].size();j++)
          if(((float [])v[i].elementAt(j)).length > 0) {
            // send the real part
            this.server_out.writeFloat(
              ((float [])v[i].elementAt(j))[0]);
            System.out.println("sending float "+
              ((float [])v[i].elementAt(j))[0]);

            // send the imaginary part
            this.server_out.writeFloat(
              ((float [])v[i].elementAt(j))[1]);
            System.out.println("sending float "+
              ((float [])v[i].elementAt(j))[1]);
            break;
          }
        break;
      case NetSolveObject.NETSOLVE_Z:

        for(j=0;j < v[i].size();j++)
          if(((double [])v[i].elementAt(j)).length > 0) {
            // write the real part
            this.server_out.writeDouble(
              ((double [])v[i].elementAt(j))[0]);
            System.out.println("sending double "+
              ((double [])v[i].elementAt(j))[0]);

            // write the imaginary part
            this.server_out.writeDouble(
              ((double [])v[i].elementAt(j))[1]);
            System.out.println("sending double "+
              ((double [])v[i].elementAt(j))[1]);
            break;
          }
        break;
      case NetSolveObject.NETSOLVE_CHAR:

        for(j=0;j < v[i].size();j++)
          if(((char [])v[i].elementAt(j)).length > 0) {
            if(encoding == GlobalDefs.DATA_XDR) {
              this.server_out.writeInt( (int)
                ((char [])v[i].elementAt(j))[0]);
              System.out.println("sending XDR encoded char "+
                ((char [])v[i].elementAt(j))[0]);
            } else {
              this.server_out.writeByte(
                ((char [])v[i].elementAt(j))[0]);
              System.out.println("sending char "+
                ((char [])v[i].elementAt(j))[0]);
            }
            break;
          }
        break;
      case NetSolveObject.NETSOLVE_EXTERNAL:
        System.err.println("Warning: MyStream.write_scalar() reached "
            + "UPF case");
        // this case shouldn't be reached
        // do nothing... upf sent already
        break;
    }
  }

  public void write_vector(Vector [] v, int i, int data_type, int m) 
   throws java.io.IOException {
    int j,k;

System.out.println("sending m = " + m);
    this.server_out.writeInt(m);     // first send m (num elements)
 
/*
    if(encoding == GlobalDefs.DATA_XDR) {
      System.out.println("writing XDR vector, length = " + m);
      this.server_out.writeInt(m);   // if XDR, send length again
    }
*/

    switch(data_type) {
      case NetSolveObject.NETSOLVE_I:
        for(j=0;j<v[i].size();j++) {
          for(k=0;k< ((int [])v[i].elementAt(j)).length;k++) {
            System.out.println( "sending int: " +
              ((int [])v[i].elementAt(j))[k]);
            this.server_out.writeInt(
              ((int [])v[i].elementAt(j))[k]);
          }
        }
        break;
      case NetSolveObject.NETSOLVE_S:
        for(j=0;j<v[i].size();j++) {
          for(k=0;k< ((float [])v[i].elementAt(j)).length;k++) {
            System.out.println( "sending float: " +
              ((float [])v[i].elementAt(j))[k]);
            this.server_out.writeFloat(
              ((float [])v[i].elementAt(j))[k]);
          }
        }
        break;
      case NetSolveObject.NETSOLVE_D:
        for(j=0;j<v[i].size();j++) {
          for(k=0;k< ((double [])v[i].elementAt(j)).length;k++) {
            System.out.println( "sending double: " +
              ((double [])v[i].elementAt(j))[k]);
            this.server_out.writeDouble(
              ((double [])v[i].elementAt(j))[k]);
          }
        }
        break;
      case NetSolveObject.NETSOLVE_C:
        for(j=0;j<v[i].size();j++) {
          for(k=0;k< ((float [])v[i].elementAt(j)).length;k+=2) {
            // send the real part
            System.out.println( "sending float: " +
              ((float [])v[i].elementAt(j))[k]);
            this.server_out.writeFloat(
              ((float [])v[i].elementAt(j))[k]);
     
            // send the imaginary part
            System.out.println( "sending float: " +
              ((float [])v[i].elementAt(j))[k+1]);
            this.server_out.writeFloat(
              ((float [])v[i].elementAt(j))[k+1]);
          }
        }
        break;
      case NetSolveObject.NETSOLVE_Z:
        for(j=0;j<v[i].size();j++) {
          for(k=0;k< ((double [])v[i].elementAt(j)).length;k+=2) {
            // send the real part
            System.out.println( "sending double: " +
              ((double [])v[i].elementAt(j))[k]);
            this.server_out.writeDouble(
              ((double [])v[i].elementAt(j))[k]);

            // send the imaginary part
            System.out.println( "sending double: " +
              ((double [])v[i].elementAt(j))[k+1]);
            this.server_out.writeDouble(
              ((double [])v[i].elementAt(j))[k+1]);
          }
        }
        break;
      case NetSolveObject.NETSOLVE_CHAR:
        for(j=0;j<v[i].size();j++) {
          for(k=0;k< ((char [])v[i].elementAt(j)).length;k++) {
            if(encoding == GlobalDefs.DATA_XDR) {
              System.out.println( "sending XDR-encoded char: " +
                ((char [])v[i].elementAt(j))[k]);
              this.server_out.writeInt( (int)
                ((char [])v[i].elementAt(j))[k]);
            } else {
              System.out.println( "sending char: " +
                ((char [])v[i].elementAt(j))[k]);
              this.server_out.writeByte(
                ((char [])v[i].elementAt(j))[k]);
            }
          }
        }
        break;
      case NetSolveObject.NETSOLVE_EXTERNAL:
        System.err.println("Warning: MyStream.write_vector() reached "
            + "UPF case");
        // this case should never be reached
        break;
    }
  }

  public void write_matrix(Vector [] v, int i, int data_type, int m, int n) 
   throws java.io.IOException {
    int j,k;

    // first, send m and n
    System.out.println("sending m = " + m);
    this.server_out.writeInt(m);             // send m
    System.out.println("sending n = " + n);
    this.server_out.writeInt(n);             // send n

    // then, if XDR, send m*n
/*
    if(encoding == GlobalDefs.DATA_XDR) {
      System.out.println("Sending XDR-encoded matrix, m*n = "+ (m*n));
      this.server_out.writeInt(m*n);         // send length
    }
*/

    switch(data_type) {
      case NetSolveObject.NETSOLVE_I:
	for(j=0;j< n ; j++) {
	  for(k=0;k< m;k++) {
            this.server_out.writeInt(
              ((int [])v[i].elementAt(j))[k]);
            System.out.println("sending int "+
              ((int [])v[i].elementAt(j))[k]);
          }
	}
        break;
      case NetSolveObject.NETSOLVE_S:
	for(j=0;j< n ; j++) {
	  for(k=0;k< m;k++){
            this.server_out.writeFloat(
              ((float [])v[i].elementAt(j))[k]);
            System.out.println("sending float "+
              ((float [])v[i].elementAt(j))[k]);
          }
	}
        break;
      case NetSolveObject.NETSOLVE_D:
	for(j=0;j< n; j++){
	  for(k=0;k< m;k++) {
            this.server_out.writeDouble(
              ((double [])v[i].elementAt(j))[k]);
	    //	    System.out.println("sending double "+
	    //			       ((double [])v[i].elementAt(j))[k]);
          }
	}
        break;
      case NetSolveObject.NETSOLVE_C:
	for(j=0;j< n; j++) {
	  for(k=0;k< m * 2;k+=2){
            // send the real part
            this.server_out.writeFloat(
              ((float [])v[i].elementAt(j))[k]);
            System.out.println("sending float "+
              ((float [])v[i].elementAt(j))[k]);

            // send the imaginary part
            this.server_out.writeFloat(
              ((float [])v[i].elementAt(j))[k+1]);
            System.out.println("sending float "+
              ((float [])v[i].elementAt(j))[k+1]);
          }
	}
        break;
      case NetSolveObject.NETSOLVE_Z:
	for(j=0;j< n; j++) {
	  for(k=0;k< m * 2;k+=2){
            // send the real part
            this.server_out.writeDouble(
              ((double [])v[i].elementAt(j))[k]);
            System.out.println("sending double "+
              ((double [])v[i].elementAt(j))[k]);

            // send the imaginary part
            this.server_out.writeDouble(
              ((double [])v[i].elementAt(j))[k+1]);
            System.out.println("sending double "+
              ((double [])v[i].elementAt(j))[k+1]);
          }
	}
        break;
      case NetSolveObject.NETSOLVE_CHAR:
	for(j=0;j< n; j++) {
	  for(k=0;k< m;k++){
            if(encoding == GlobalDefs.DATA_XDR) {
              this.server_out.writeInt( (int)
                ((char [])v[i].elementAt(j))[k]);
              System.out.println("sending XDR-encoded char "+
                ((char [])v[i].elementAt(j))[k]);
            } else {
              this.server_out.writeByte(
                ((char [])v[i].elementAt(j))[k]);
              System.out.println("sending char "+
                ((char [])v[i].elementAt(j))[k]);
            }
          }
	}
        break;
      case NetSolveObject.NETSOLVE_EXTERNAL:
        System.err.println("Warning: MyStream.write_matrix() reached "
            + "UPF case");
        // this case should never be reached
        break;
    }
  }

  public void read_scalar(Vector vec, int data_type)
   throws java.io.IOException {
  
/*
    if(encoding == GlobalDefs.DATA_XDR) {
      this.server_in.readInt();   // if XDR, read array length
    }
*/

    switch(data_type) {
      case NetSolveObject.NETSOLVE_I:
        vec.addElement(new DataObject(this.server_in.readInt()));
        break;
      case NetSolveObject.NETSOLVE_S:
        vec.addElement(new DataObject(this.server_in.readFloat()));
        break;
      case NetSolveObject.NETSOLVE_D:
        vec.addElement(new DataObject(this.server_in.readDouble()));
        break;
      case NetSolveObject.NETSOLVE_C:
        float [] x = new float[2];

        x[0] = this.server_in.readFloat();
        x[1] = this.server_in.readFloat();

        vec.addElement(x);
        break;
      case NetSolveObject.NETSOLVE_Z:
        double [] y = new double[2];
        double temp;

System.out.println("reading double precision COMPLEX scalar...");
temp = this.server_in.readDouble();
y[0] = temp;
System.out.println(temp);
temp = this.server_in.readDouble();
y[1] = temp;
System.out.println(temp);


/*
        y[0] = this.server_in.readDouble();
        y[1] = this.server_in.readDouble();
*/

        vec.addElement(y);
        break;
      case NetSolveObject.NETSOLVE_CHAR:
        if(encoding == GlobalDefs.DATA_XDR)
          vec.addElement(new DataObject((char)this.server_in.readInt()));
        else
          vec.addElement(new DataObject((char)this.server_in.readByte()));
        break;
      case NetSolveObject.NETSOLVE_EXTERNAL:
        System.err.println("Warning: MyStream.read_scalar() reached "
            + "UPF case");
        // this case should never be reached
        break;
    }
  }

  public void read_scalar_bo(Vector vec, int data_type)
   throws java.io.IOException {
     byte buf[];
     int sizes[] = new int[0];
     switch(data_type) {
     case NetSolveObject.NETSOLVE_I:
       buf = new byte[4];
       server_in.readFully(buf);

       int tmp = (new DataInputStream(new java.io.ByteArrayInputStream(buf))).readInt();
       System.out.println("readed scalar integer = " + tmp);

       vec.addElement(new BufferObject(buf, sizes));
        break;
     case NetSolveObject.NETSOLVE_S:
       buf = new byte[4];
       server_in.readFully(buf);
       vec.addElement(new BufferObject(buf, sizes));
       break;
     case NetSolveObject.NETSOLVE_D:
       buf = new byte[8];
       server_in.readFully(buf);
       vec.addElement(new BufferObject(buf, sizes));
       break;
     case NetSolveObject.NETSOLVE_CHAR:
       buf = new byte[4];
       server_in.readFully(buf);
       vec.addElement(new BufferObject(buf, sizes));
       break;
     case NetSolveObject.NETSOLVE_C:
       buf = new byte[8];
       server_in.readFully(buf);
       vec.addElement(new BufferObject(buf, sizes));
       break;
     case NetSolveObject.NETSOLVE_Z:
       buf = new byte[16];
       server_in.readFully(buf);
       vec.addElement(new BufferObject(buf, sizes));
       break;
     default:
       System.out.println("readscalar default : unknown type");
     }
  }

  public void read_vector_bo(Vector vec, int data_type)
   throws java.io.IOException {
     int m = this.server_in.readInt();
     System.out.println("vector is size " + m);
     int sizes[] = new int[1];
     sizes[0] = m;
     byte buf[];
     switch(data_type) {
     case NetSolveObject.NETSOLVE_I:
       buf = new byte[4 * m];
       server_in.readFully(buf);
       vec.addElement(new BufferObject(buf, sizes));
        break;
     case NetSolveObject.NETSOLVE_S:
       buf = new byte[4 * m];
       server_in.readFully(buf);
       vec.addElement(new BufferObject(buf, sizes));
       break;
     case NetSolveObject.NETSOLVE_D:
       buf = new byte[8 * m];
       server_in.readFully(buf);
       vec.addElement(new BufferObject(buf, sizes));
       break;
     case NetSolveObject.NETSOLVE_CHAR:
       buf = new byte[4 * m];
       server_in.readFully(buf);
       vec.addElement(new BufferObject(buf, sizes));
       break;
     case NetSolveObject.NETSOLVE_C:
       buf = new byte[8 * m];
       server_in.readFully(buf);
       vec.addElement(new BufferObject(buf, sizes));
       break;
     case NetSolveObject.NETSOLVE_Z:

       buf = new byte[16 * m];
       server_in.readFully(buf);
       //DataInputStream dis = (new DataInputStream(new java.io.ByteArrayInputStream(buf)));
      //       for (int i = 0; i < m; i++){
       //	 System.out.println("readed vector double " + i +" =  " + dis.readDouble() + "," + dis.readDouble());
       //}
       System.out.println("readed vector double");
       for (int i = 0; i < m * 16; i++){
	 System.out.print( ninf.basic.FormatString.format("%02x ", new Integer(0xff & buf[i])));
       }
	System.out.println("");
       vec.addElement(new BufferObject(buf, sizes));
       break;
     default:
       System.out.println("readvec default : unknown type");
     }
  }

  public void read_matrix_bo(Vector vec, int data_type)
   throws java.io.IOException {
     int m = this.server_in.readInt();
     System.out.println("vector is size " + m);
     int n = this.server_in.readInt();
     System.out.println("n = " + n );
     int sizes[] = new int[2];
     sizes[0] = m;     sizes[1] = n;
     byte buf[];
     switch(data_type) {
     case NetSolveObject.NETSOLVE_I:
       buf = new byte[4 * m * n];
       server_in.readFully(buf);
       vec.addElement(new BufferObject(buf, sizes));
        break;
     case NetSolveObject.NETSOLVE_S:
       buf = new byte[4 * m * n];
       server_in.readFully(buf);
       vec.addElement(new BufferObject(buf, sizes));
       break;
     case NetSolveObject.NETSOLVE_D:
       buf = new byte[8 * m * n];
       server_in.readFully(buf);
       vec.addElement(new BufferObject(buf, sizes));
       break;
     case NetSolveObject.NETSOLVE_CHAR:
       buf = new byte[4 * m * n];
       server_in.readFully(buf);
       vec.addElement(new BufferObject(buf, sizes));
       break;
     case NetSolveObject.NETSOLVE_C:
       buf = new byte[8 * m * n];
       server_in.readFully(buf);
       vec.addElement(new BufferObject(buf, sizes));
       break;
     case NetSolveObject.NETSOLVE_Z:
       buf = new byte[16 * m * n];
       server_in.readFully(buf);
       vec.addElement(new BufferObject(buf, sizes));
       break;
     default:
       System.out.println("readvec default : unknown type");
     }
  }

  public void read_vector(Vector vec, int data_type)
   throws java.io.IOException {
    int j,m,len=0;

    m = this.server_in.readInt();
System.out.println("vector is size " + m);

/*
    if(encoding == GlobalDefs.DATA_XDR) {
      System.out.println("Receiving an XDR-encoded vector.");
      len = this.server_in.readInt();
      System.out.println("length is " + len);
    }
*/

    switch(data_type) {
      case NetSolveObject.NETSOLVE_I: {
        int [] x = new int[m];
        for(j=0;j<m;j++)
          x[j] = this.server_in.readInt();

        vec.addElement(new DataObject(m, x));
        }
        break;
      case NetSolveObject.NETSOLVE_S: {
        float [] x = new float[m];
        for(j=0;j<m;j++)
          x[j] = this.server_in.readFloat();

        vec.addElement(new DataObject(m, x));
        }
        break;
      case NetSolveObject.NETSOLVE_D: {
        double [] x = new double[m];
        for(j=0;j<m;j++)
          x[j] = this.server_in.readDouble();

        vec.addElement(new DataObject(m, x));
        }
        break;
      case NetSolveObject.NETSOLVE_C: {
        float [] x = new float[m*2];
        for(j=0;j<m*2;j+=2) {
          x[j] = this.server_in.readFloat();
          x[j+1] = this.server_in.readFloat();
        }

        vec.addElement(x);
        }
        break;
      case NetSolveObject.NETSOLVE_Z: {
        double [] x = new double[m*2];
        for(j=0;j<m*2;j+=2) {
          x[j] = this.server_in.readDouble();
          x[j+1] = this.server_in.readDouble();
System.out.println(x[j] + " " + x[j+1]);
        }

        vec.addElement(x);
        }
        break;
      case NetSolveObject.NETSOLVE_CHAR: {
        char [] x = new char[m];
        for(j=0;j<m;j++)
          if(encoding == GlobalDefs.DATA_XDR)
            x[j] = (char)this.server_in.readInt();
          else 
            x[j] = (char)this.server_in.readByte();

        vec.addElement(new DataObject(m,x));
        }
        break;
      case NetSolveObject.NETSOLVE_EXTERNAL:
        System.err.println("Warning: MyStream.read_vector() reached "
            + "UPF case");
        // this case should never be reached
        break;
    }
  }

  public void read_matrix(Vector vec, int data_type)
   throws java.io.IOException {
    int j,k,m,n,len=0;

System.out.println("#### In read_matrix");
    m = this.server_in.readInt();
System.out.println("m = " + m );
    n = this.server_in.readInt();
System.out.println("n = " + n );

/*
    if(encoding == GlobalDefs.DATA_XDR) {
      System.out.println("Receiving an XDR-encoded matrix.");
      len = this.server_in.readInt();
      System.out.println("length is " + len);
    }
*/

    switch(data_type) {
      case NetSolveObject.NETSOLVE_I: {
        int [] z = new int[m * n];

        for(j=0;j<m;j++)
          for(k=0;k<n;k++)
            z[j*n + k] = this.server_in.readInt();

        vec.addElement(new DataObject(m, n, z));
        }
        break;
      case NetSolveObject.NETSOLVE_S: {
        float [] z = new float[m * n];

        for(j=0;j<m;j++)
          for(k=0;k<n;k++)
            z[j * n + k] = this.server_in.readFloat();

        vec.addElement(new DataObject(m, n, z));
        }
        break;
      case NetSolveObject.NETSOLVE_D: {
        double [] z = new double[m * n];

        for(j=0;j<m;j++)
          for(k=0;k<n;k++)
            z[j * n + k] = this.server_in.readDouble();

        vec.addElement(new DataObject(m, n, z));
        }
        break;
      case NetSolveObject.NETSOLVE_C: {
        float [][] z = new float[n][m*2];

        for(j=0;j<m*2;j+=2)
          for(k=0;k<n;k++) {
            z[k][j] = this.server_in.readFloat();
            z[k][j+1] = this.server_in.readFloat();
          }

        vec.addElement(z);
        }
        break;
      case NetSolveObject.NETSOLVE_Z: {
        double [][] z = new double[n][m*2];

        for(j=0;j<m*2;j+=2)
          for(k=0;k<n;k++) {
            z[k][j] = this.server_in.readDouble();
            z[k][j+1] = this.server_in.readDouble();
          }

        vec.addElement(z);
        }
        break;
      case NetSolveObject.NETSOLVE_CHAR: {
        char [] z = new char[m * n];

        for(j=0;j<m;j++)
          for(k=0;k<n;k++)
            if(encoding == GlobalDefs.DATA_XDR)
              z[j * n + k] = (char) this.server_in.readInt();
            else
              z[j * n + k] = (char) this.server_in.readByte();

        vec.addElement(new DataObject(m, n, z));
        }
        break;
      case NetSolveObject.NETSOLVE_EXTERNAL:
        System.err.println("Warning: MyStream.read_matrix() reached "
            + "UPF case");
        // this case should never be reached
        break;
    }
  }

  MyStream(String hostname, int port, int data_format) 
   throws java.io.IOException {
     System.err.println("MyStream Connecting to: |" + hostname  +"| at "+ port);
     /* ad hoc patch */
     if (hostname.equals("etlsolon"))
       hostname += ".etl.go.jp";

     s = new Socket(hostname,port);
     server_in = new DataInputStream(s.getInputStream());
     server_out = new DataOutputStream(s.getOutputStream());

     if((data_format != GlobalDefs.DATA_RAW) &&
            (data_format != GlobalDefs.DATA_XDR)) {
       System.err.println("MyStream warning: Invalid data format, " +
            "using XDR.");
       encoding = GlobalDefs.DATA_XDR;
     }
     else
       encoding = data_format;

     this.server_out.writeChar(encoding);    // send encoding

     return;
  }
}
