package ninf.scheduler;
import ninf.basic.*;
import ninf.client.*;
import ninf.cproxy.aggregate.*;
import java.util.Vector;
import java.util.Hashtable;
import java.util.Enumeration;

public class FlowPath implements Cloneable{

  Vector funcNodes;
  Vector dataNodes;

  public FlowPath(){
    funcNodes = new Vector();
    dataNodes = new Vector();
  }

  public void addFuncNode(FuncNode func){
    funcNodes.addElement(func);
  }

  public void addDataNode(DataNode data){
    dataNodes.addElement(data);
  }
  
  public long order(){
    long sum = 0;
    for (int i = 1; i < funcNodes.size() - 1; i++){
       sum += ((FuncNode)funcNodes.elementAt(i)).order;
    }
    return sum;
  }

  public boolean allocated(){
    for (int i = 0; i < funcNodes.size(); i++){
      if (((FuncNode)funcNodes.elementAt(i)).serverIndex == null)
	return false;
    }
    return true;
  }

  private int start(int init){
    for (int i = init; i < funcNodes.size(); i++){
      if (((FuncNode)funcNodes.elementAt(i)).serverIndex == null)
	return i;
    }
    return -1;
  }
  private int end(int init){
    for (int i = init; i < funcNodes.size(); i++){
      if (((FuncNode)funcNodes.elementAt(i)).serverIndex != null)
	return i;
    }
    return -1;
  }

  public Vector getSubPath(){
    if (allocated())
      return new Vector();
    int start = 0;
    int end   = 0;
    Vector v = new Vector();
    while (true){
      if ((start = start(end)) < 0)
	break;
      if ((end   = end  (start)) < 0)
	break;
      FlowPath tmp = new FlowPath();
      int i;
      for (i = start - 1; i < end; i++){
	tmp.addFuncNode((FuncNode)funcNodes.elementAt(i));
	tmp.addDataNode((DataNode)dataNodes.elementAt(i));
      }
      tmp.addFuncNode((FuncNode)funcNodes.elementAt(i));
      v.addElement(tmp);
    }
    return v;
  }

  public void locate(NinfServerStruct serverStruct){
    for (int i = 1; i < funcNodes.size() - 1; i++)
      ((FuncNode)funcNodes.elementAt(i)).locate(serverStruct);
  }
  

  public Vector getCommonServers(){
    Hashtable h = new Hashtable();
    int size = funcNodes.size() - 2;
    for (int i = 1; i < funcNodes.size() - 1; i++){
      FuncNode tmp = ((FuncNode)funcNodes.elementAt(i));
      for (int j = 0; j < tmp.serverIndexes.length; j++){
	NinfServerStruct server = tmp.serverIndexes[j].server;
	Integer val = (Integer)h.get(server);
	if (val == null)
	  val = new Integer(1);
	else
	  val = new Integer(1 + val.intValue());
	h.put(server, val);
      }
    }
    Vector v = new Vector();
    Enumeration enum = h.keys();
    while (enum.hasMoreElements()){
      NinfServerStruct server = (NinfServerStruct)enum.nextElement();
      Integer val = (Integer)h.get(server);
      if (val.intValue() == size)
	v.addElement(server);
    }
    return v;
  }

  public Object clone(){
    FlowPath tmp = new FlowPath();
    tmp.funcNodes = (Vector)funcNodes.clone();
    tmp.dataNodes = (Vector)dataNodes.clone();
    return tmp;
  }

  public String toString(){
    String tmp = "flow:";
    int i;
    for (i = 0; i < funcNodes.size() - 1; i++){
      tmp += " " + funcNodes.elementAt(i);
      tmp += " " + dataNodes.elementAt(i);
    }
    tmp += " " + funcNodes.elementAt(i);      
    return tmp;
  }

}
