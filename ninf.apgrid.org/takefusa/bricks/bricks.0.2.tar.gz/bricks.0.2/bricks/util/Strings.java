package bricks.util;

public abstract class Strings {
    abstract public String nextString();
    public String nextString(double size) {return nextString();}
    public void init(SimulationSet owner) {;}
}
