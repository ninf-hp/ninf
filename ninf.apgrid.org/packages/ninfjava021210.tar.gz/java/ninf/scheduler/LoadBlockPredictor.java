package ninf.scheduler;

import ninf.basic.*;
import ninf.common.*;
import ninf.metaserver.*;
import ninf.client.*;

public class LoadBlockPredictor extends Predictor{
  static NinfLog dbg = new NinfLog("LoadBlockPredictor");

  public LoadBlockPredictor(){
    super();
  }
  
  public LoadInformation getLoadInformation(NinfServerStruct server)
  throws NinfException {
    LoadInformation tmp = new LoadInformation(0.0, 0.0, 0.0, 0.0);
    tmp.time = 0;
    return tmp;
  }
}
