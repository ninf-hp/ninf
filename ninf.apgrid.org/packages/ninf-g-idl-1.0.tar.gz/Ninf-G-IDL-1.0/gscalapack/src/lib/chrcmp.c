long chrcmp( char a, char b) {
  long ret=1;
  if (a==b) ret=0;
  if (a+'A'-'a'==b) ret = 0;
  if (a+'a'-'A'==b) ret = 0;
  return ret;
}
