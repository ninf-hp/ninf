package ninf.netsolve;
import java.util.Vector;
import java.util.StringTokenizer;

public class ParsedMnemonic {
  int flag;  /* 0 = none, 1 = n, 2 = m, 3 =l , 4 = working area */
  boolean isInput;
  int number;

  ParsedMnemonic(String str){
    char org[] = str.toCharArray();
    int index = 0;

    switch (org[index++]){
    case 'n':
      flag = 1;
      break;
    case 'm':
      flag = 2;
      break;
    case 'l':
      flag = 3;	
      break;
    case '?':
      flag = 4;
      return;
    default:
      flag = 0;
      index--;
    }
    switch (org[index++]){
    case 'I':
      isInput = true;
      break;
    case 'O':
      isInput = false;
      break;
    }
    number = Integer.parseInt(str.substring(index));
  }

  static ParsedMnemonic[] parseMnemonics(String strs[]){
    /*    Vector v = new Vector();
    StringTokenizer st = new StringTokenizer(str, ", ");
    while (st.hasMoreTokens())
      v.addElement(st.nextToken());*/

    ParsedMnemonic tmp[] = new ParsedMnemonic[strs.length];  
    for (int i = 0; i < strs.length; i++)
      tmp[i] = new ParsedMnemonic(strs[i]);
    return tmp;
  }
  
}
