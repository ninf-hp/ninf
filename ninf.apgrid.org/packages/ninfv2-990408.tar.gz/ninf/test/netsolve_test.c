#include <stdio.h>
#include "ninf_stub.h"

  /* (mI0,nI0,mI1) (nI1) (I0) (lI0) (I1,O0) (lI1) */
  double A[4][4] = {{1.1, 2.2, 3.3, 4.4},
                    {5.1, 6.2, 7.3, 8.4},
		    {9.1, 10.2,11.3,12.4},
		    {13.1,14.2,15.3,16.4}};
  double B[4][4] = {{1.1, 2.2, 3.3, 4.4},
                    {5.1, 6.2, 7.3, 8.4},
		    {9.1, 10.2,11.3,12.4},
		    {13.1,14.2,15.3,16.4}};

main(int argc, char ** argv){ 
  int i, j;

  Ninf_parse_arg(argc, argv);
  Ninf_call("NetSolve/linsol", 4, 4, A, 4, B, 4);
  Ninf_perror("linsol");

  for (i = 0; i < 4; i++){
    for (j = 0; j < 4; j++)
      printf("%lf ", B[i][j]);
    printf("\n");
  }
}
