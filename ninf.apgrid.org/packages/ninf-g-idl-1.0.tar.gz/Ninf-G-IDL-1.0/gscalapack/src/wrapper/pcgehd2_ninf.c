#define _WRAPPER_
/* $Id: pcgehd2_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define SCOMPLEX
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n
static	int worklen(int n, int ihi) {
	  int ret=1;
	  int iroffa, iarow;
	  int NpA0;
	  ret = 2*n;
	  if NEED_BUFF {
#define NB cbloc
#define RSRS_a 0
            iroffa = 0;
            iarow = FortranCall(indxg2p)( 1, NB, myprow, RSRS_a, npcol );
            NpA0 = Cnumroc( ihi+iroffa, NB, myprow, iarow, nprow );
            ret =  NB + max( NpA0, NB );
	  }
	  return ret;
}

void  pcgehd2_ninf(	 int n,
		 int ilo,
		 int ihi,
		 scomplex global_a[],
		 int lda,
		 scomplex global_tau[],
		 scomplex work[],
		 int *info
)
/* "pcgehd2 reduces a complex general distributed matrix A to upper Hessenberg form H by an unitary similarity transformation: Q' * A * Q = H." */
/* OPTIONS */
{
	int maxldd;

	int maxlda;
	scomplex *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
	int row_loca, col_loca;

	scomplex *loctau=NULL;

        scomplex *locwork=NULL;
        int llocwork;

	INITIALIZE();

	SCALAR( "int", n);
	SCALAR( "int", ilo);
	SCALAR( "int", ihi);
	SCALAR( "int", lda);

	ROW( a);
	COL( a);
	MAXLDD( maxldd, a );
	maxlda = maxldd;

	MATRIX( "scomplex", a, ROW_a, COL_a);
	DISTRIBUTE( "scomplex", a, ROW_a  , COL_a);
	VECTOR("c", "scomplex", tau, n-1);

	llocwork = worklen(n, ihi);
	WORK(locwork,llocwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pcgehd2)( &n, &ilo, &ihi,
                               loca, &one, &one, desca,
                               loctau,
                               locwork, &llocwork, &linfo);

	GATHER( "scomplex", a, ROW_a  , COL_a);
        vGATHER( "c", "scomplex", tau, n-1);
	
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
	  *info = linfo;
	} else {
	}

	FREE_MATRIX(a);
	FREE_VECTOR(tau);
        FREE(locwork);
}

