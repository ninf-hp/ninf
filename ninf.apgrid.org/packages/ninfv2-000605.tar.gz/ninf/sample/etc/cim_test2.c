#include <stdio.h>
#include <stdlib.h>

#include "ninf_stub.h"
#include "ninf_cim.h"
#include "cim_test_handler.h"

#include <sys/time.h>
struct timeval tp[2];
struct timezone tzp[2];

/******************** Test Main *********************/

main(int argc, char ** argv){
  double *A, *B;
  int n;
  /*  ninf_debug_flag = 1;     */

  argc = Ninf_parse_arg(argc, argv);

  if (argc >= 2)
    n = atoi(argv[1]);
  else
    n = 10000;
  
  Ninf_set_cim_funcs(ninf_cim_init_c,
		ninf_cim_finalize_c, 
		ninf_cim_proceed_c,
		ninf_cim_get_c,
		ninf_cim_put_c,
		ninf_cim_destruct_c);
  printf("double test: size = %d\n", n);
  {
    c_pointer_handler * args[3];
    int result;
    int dim[1];
    long usec0, usec1;
    dim[0] = n;

    A = malloc(n * sizeof(double));
    B = malloc(n * sizeof(double));
    args[0] = new_c_pointer_handler(&n, 0, NULL, DT_INT);
    args[1] = new_c_pointer_handler(A, 1, dim, DT_DOUBLE);
    args[2] = new_c_pointer_handler(B, 1, dim, DT_DOUBLE);


    gettimeofday(&tp[0], &tzp[0]);
    result = Ninf_cim_main("double_test", args);
    gettimeofday(&tp[1], &tzp[1]);
    if (result != NINF_OK)
      Ninf_perror("double_test");
    usec0 = (tp[1].tv_sec - tp[0].tv_sec) * 1000000 +
      (tp[1].tv_usec - tp[0].tv_usec);

    gettimeofday(&tp[0], &tzp[0]);
    result = Ninf_call("double_test", n, A, B);
    gettimeofday(&tp[1], &tzp[1]);
    if (result != NINF_OK)
      Ninf_perror("double_test");
    usec1 = (tp[1].tv_sec - tp[0].tv_sec) * 1000000 +
	(tp[1].tv_usec - tp[0].tv_usec);

    printf("CIM:    usec = %ld\n", usec0);
    printf("NATIVE: usec = %ld\n", usec1);
    printf("diff:   usec = %ld\n", usec0 - usec1);
  }
}
