#define _WRAPPER_
/* $Id: pclarfc_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define SCOMPLEX
#include <gscalapack.h>

#define ROW_v ldv
#define COL_v col_v
#define ROW_c ldc
#define COL_c n
static	int worklen(char side, int m,int n) {
	  int ret=1;
	  int LCM,LCMP,LCMQ,IROFFC,ICOFFC,ICROW,ICCOL;
	  int IVROW, IVCOL;
	  int MpC0, NqC0;
	  ret = 2*max(m,n);
	  if NEED_BUFF {
#define IV 1
#define JV 1
#define MB_V rbloc
#define NB_V cbloc
#define RSRC_V 0
#define CSRC_V 0
	    LCM = LCM( NPROW, NPCOL );
	    LCMP = LCM / NPROW;
	    LCMQ = LCM / NPCOL;

	    IROFFC = MOD( IC-1, MB_C ); ICOFFC = MOD( JC-1, NB_C );
	    ICROW = INDXG2P( IC, MB_C, MYROW, RSRC_C, NPROW );
	    ICCOL = INDXG2P( JC, NB_C, MYCOL, CSRC_C, NPCOL );
	    MpC0 = NUMROC( M+IROFFC, MB_C, MYROW, ICROW, NPROW );
	    NqC0 = NUMROC( N+ICOFFC, NB_C, MYCOL, ICCOL, NPCOL );
	    IVROW = INDXG2P( IV, MB_V, MYROW, RSRC_V, NPROW );
	    IVCOL = INDXG2P( JV, NB_V, MYCOL, CSRC_V, NPCOL );

	    if (incv == 1) {
	      if (chrcmp(side , 'L')==0)
		if (IVCOL==ICCOL)
		  ret = NqC0;
		else
		  ret = MpC0 + MAX( 1, NqC0 );
	      else 
		ret = NqC0 + MAX( MAX( 1, MpC0 ), NUMROC( NUMROC( N+ICOFFC,NB_V,0,0,NPCOL ),NB_V,0,0,LCMQ ) );
	    } else {
	      if (chrcmp(side, 'L')==0)
		ret = MpC0 + MAX( MAX( 1, NqC0 ), NUMROC( NUMROC( M+IROFFC,MB_V,0,0,NPROW ),MB_V,0,0,LCMP ) );
	      else if (chrcmp(side , 'R')==0)
		if (IVROW == ICROW) 
		  ret = MpC0;
		else
		  ret = NqC0 + MAX( 1, MpC0 );
	    }
	  }
	  return ret;
}

#ifdef X
static int vlen(char side, int m, int n) {
	  int ret=1;
	  if (chrcmp(side,'l')==0) ret=m;
	  else ret=n;
	  return ret;
}
#endif

void  pclarfc_ninf(	 char side,
		 int m,	
		 int n,	
		 scomplex global_v[],
		 int ldv,
		 int incv,
		 scomplex tau,
		 scomplex global_c[], 
		 int ldc
)
/* "pclarfc applies a complex elementary reflector Q**H to a complex M-by-N distributed matrix C, from either the left or the right." */
/* OPTIONS */
{
	int maxldd;

	int maxldv;
	scomplex *locv=NULL;
	int descv[DESCLEN];
	int desc_gv[DESCLEN];
	int col_v;
	int row_locv, col_locv;

	int maxldc;
	scomplex *locc=NULL;
	int descc[DESCLEN];
	int desc_gc[DESCLEN];
	int row_locc, col_locc;

	scomplex *locwork=NULL;
	int llocwork;

	INITIALIZE();

	SCALAR("char",side);
	SCALAR("int",m);
	SCALAR("int",n);
	SCALAR( "scomplex", tau);
	SCALAR("int",incv);

	ROW(v);
	COL(v);
	ROW(c);
	COL(c);
	MAXLDD(maxldd,v );
	maxldv=maxldd;
	maxldc=maxldd;

	MATRIX("scomplex",v,ROW_v,COL_v );
	DISTRIBUTE("scomplex", v,ROW_v, COL_v );

	MATRIX("scomplex",c, ROW_c,COL_c );
	DISTRIBUTE("scomplex", c, ROW_c,COL_c  );

	llocwork=worklen(side,m,n);
	WORK(locwork,llocwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pclarfc)( &side, &m, &n,
                               locv, &one, &one, descv,
                               &incv,
                               tau,
                               locc, &one, &one, descc,
                               locwork);

 	GATHER("scomplex", c, ROW_c , COL_c );
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
	} else {
	}

	FREE_MATRIX(v);
	FREE_MATRIX(c);
	FREE(locwork);
}

