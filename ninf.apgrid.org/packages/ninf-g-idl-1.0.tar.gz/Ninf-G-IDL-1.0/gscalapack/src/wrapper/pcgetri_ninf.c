#define _WRAPPER_
/* $Id: pcgetri_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define SCOMPLEX
#include <gscalapack.h>

#define ROW_a  lda
#define COL_a  n
static	int worklen(int n) {
	  int ret=1;
	  ret = n*n;
	  if NEED_BUFF {
#define IA 1
#define MB_A rbloc
#define NB_A cbloc
	    ret =  LOCr(n+MOD(IA-1,MB_A))*NB_A;
	  }
	  return ret;
}

static	int iworklen(int n, int lda) {
	  int ret=1;
	  ret = n+n;
	  if NEED_BUFF {
#define LCM lcm(NPROW,NPCOL)
#define N_A n
#define JA 1
	    if ( NPROW == NPCOL) {
	      ret = LOCc( N_A + MOD(JA-1, NB_A) ) + NB_A;
	    }  else {
	      ret =  LOCc( N_A + MOD(JA-1, NB_A) ) +
		MAX( CEIL(CEIL(LOCr(ROW_a),MB_A),(LCM/NPROW)),	 NB_A );
	    }
	  }
	  return ret;
}


void  pcgetri_ninf(	 int n,
		 scomplex global_a[],
		 int lda,
		 int global_ipiv[],
		 scomplex work[],
		 int lwork,
		 int *info
)
/* "pcgetri computes the inverse of a distributed matrix using the LU factorization computed by PCGETRF. This method inverts U and then computes the inverse of Aby solving the system InvA*L = inv(U) for InvA." */
/* OPTIONS */
{
    extern void FortranCall(pcgetri)( int*,
                               scomplex*, int*, int*, int*,
                               int*,
                               scomplex*, int*,
                               int*, int*,
                               int*);
	int maxldd;

	int maxlda;
	scomplex *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
	int row_loca,col_loca;

	int *locipiv=NULL;

	scomplex *locwork=NULL;
	int llocwork;
	int *lociwork=NULL;
	int llociwork;

	INITIALIZE();

	SCALAR( "int", n);
	SCALAR( "int", lda);
	SCALAR( "int", lwork);

	ROW( a);
	COL( a);

	MAXLDD( maxldd, a );
	maxlda = maxldd;

	MATRIX( "scomplex", a, ROW_a, COL_a);
	VECTOR("r", "int" , ipiv, min(n,ROW_a));

	DISTRIBUTE( "scomplex", a, ROW_a  , COL_a);
	vDISTRIBUTE( "r", "int", ipiv, min(ROW_a,n));

        llocwork = worklen(n);
	llocwork = max(lwork,llocwork);
	WORK(locwork,llocwork);
	llociwork = iworklen(n,lda);
	IWORK(lociwork,llociwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pcgetri)( &n,
                               loca, &one, &one, desca,
                               locipiv,
                               locwork, &llocwork,
                               lociwork, &llociwork,
                               &linfo);

	GATHER( "scomplex", a, ROW_a  , COL_a);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
		*info = linfo;
	} else {
	}

	FREE_MATRIX(a);
	FREE_VECTOR(ipiv);
        FREE(locwork);
        FREE(lociwork);
	
}

