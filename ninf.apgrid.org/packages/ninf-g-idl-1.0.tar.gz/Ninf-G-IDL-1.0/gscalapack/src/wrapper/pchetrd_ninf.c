#define _WRAPPER_
/* $Id: pchetrd_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define _DISTRIBUTE_1D_
#define SCOMPLEX
#include <gscalapack.h>
#define ROW_a lda
#define COL_a n
static	int worklen(int n) {
	  int ret;
	  int IAROW;
	  int NP;
          ret = max(n *(n+1),3*n);
	  if NEED_BUFF {
#define NUMROC Cnumroc
#define NB blocsize
	    IAROW = INDXG2P( 0, NB, myprow, 0, nprow );
	    NP = NUMROC( n, NB, myprow, IAROW, nprow );
	    ret = max( NB * ( NP +1 ), 3 * NB );
	  }
	  return ret;
}

void  pchetrd_ninf(	 char uplo,
		 int n,
		 scomplex global_a[],
		 int lda,
		 float global_d[],
		 float global_e[], // uplo
		 scomplex global_tau[],
		 scomplex work[],
		 int lwork,
		 int *info
)
/* "pchetrd reduces a complex Hermitian matrix A to Hermitian tridiagonal form T by an unitary similarity transformation:\\n\\n */
/*  Q' * A * Q = T." */
/* OPTIONS */
{
	int maxldd;

	int maxlda;
	float *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];

	scomplex *locd=NULL;
	scomplex *loce=NULL;
	int desctdd[DESCLEN], desc_gtdd[DESCLEN];

	scomplex *loctau=NULL;

	int row_loca;
	int col_loca;

	scomplex *locwork=NULL;
	int llocwork;


	INITIALIZE();

	SCALAR( "char", uplo);
	SCALAR( "int", n);
	SCALAR("int", lda);
        SCALAR("int", lwork);
        
	SIZE(n);

	ROW( a);
	COL( a);
	MAXLDD( maxldd, a );
	maxlda = maxldd;

	trMATRIX( uplo, "scomplex", a, ROW_a, COL_a);
	if (chrcmp(uplo,'U')==0) tdMATRIX( "float", 0, d, e, n);
	else tdMATRIX( "float", e, d, 0, n);
	VECTOR( "c", "scomplex", tau, n);
	trDISTRIBUTE( uplo, "float", a, ROW_a, COL_a);

	llocwork = worklen(n);
	llocwork = max(lwork,llocwork);
	WORK(locwork,llocwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pchetrd)( &uplo, &n,
                               loca, &one, &one, desca,
                               locd, loce,
                               loctau,
                               locwork, &llocwork, &linfo);

	trGATHER( uplo, "float", a, ROW_a, COL_a);
	if (chrcmp(uplo,'U')==0) tdGATHER( "float", 0, d, e, n);
	else tdGATHER( "float", e, d, 0, n);
	vGATHER( "c", "scomplex", tau, n);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
            *info = linfo;
	} else {
	}

	FREE_MATRIX(a);
	FREE_MATRIX(d);
	FREE_MATRIX(e);
        
	FREE_VECTOR(tau);

        FREE(locwork);
}

