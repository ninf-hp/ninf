#define _WRAPPER_
/* $Id: pcunmhr_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define SCOMPLEX
#include <gscalapack.h>
#define ROW_a lda
#define COL_a col_a
#define ROW_c ldc
#define COL_c n
static	int worklen(char side, int m, int n, int ilo, int ihi) {
	  int ret=1;
	  int LCMQ, IROFFA, ICOFFA, IAROW, NpA0;
	  int IROFFC, ICOFFC, ICCOL, MpC0, NqC0;
	  int IAA, JAA, ICC, JCC, ICROW;
	  int MI, NI;
	  int max_m_n;
	  max_m_n = max(m,n);
	  ret = MAX( (max_m_n*(max_m_n-1))/2, (max_m_n + max_m_n)*max_m_n )
	      + max_m_n * max_m_n;
	  if NEED_BUFF {
#define ILO ilo
#define IHI ihi
	    LCMQ = LCM(nprow,npcol) / NPCOL;

	     if (chrcmp(side, 'L')==0) {
	       MI = IHI-ILO; NI = N; ICC = IC + ILO; JCC = JC;
	     } else {
	       MI = M; NI = IHI-ILO; ICC = IC; JCC = JC + ILO;
	     }

	    IROFFA = MOD( IAA-1, MB_A );
	    ICOFFA = MOD( JAA-1, NB_A );
	    IAROW = INDXG2P( IAA, MB_A, MYROW, RSRC_A, NPROW );
	    NpA0 = NUMROC( NI+IROFFA, MB_A, MYROW, IAROW, NPROW );

	    IROFFC = MOD( ICC-1, MB_C );
	    ICOFFC = MOD( JCC-1, NB_C );
	    ICROW = INDXG2P( ICC, MB_C, MYROW, RSRC_C, NPROW );
	    ICCOL = INDXG2P( JCC, NB_C, MYCOL, CSRC_C, NPCOL );
	    MpC0 = NUMROC( MI+IROFFC, MB_C, MYROW, ICROW, NPROW );
	    NqC0 = NUMROC( NI+ICOFFC, NB_C, MYCOL, ICCOL, NPCOL );

	     IAA = IA + ILO;
	     JAA = JA+ILO-1;
	     if (chrcmp(side, 'L')==0) {
	       ret = MAX( (NB_A*(NB_A-1))/2, (NqC0 + MpC0)*NB_A ) + NB_A * NB_A;
	     } else {
	       ret = MAX( (NB_A*(NB_A-1))/2, ( NqC0 + MAX( NpA0 +  NUMROC( NUMROC( NI+ICOFFC, NB_A, 0, 0, NPCOL ), NB_A, 0, 0, LCMQ ), MpC0 ) )*NB_A ) +  NB_A * NB_A;
	     }
	  }
	  return ret;
}


void  pcunmhr_ninf(	 char side,
		 char trans,
		 int m,	/*  m >= 0 */
		 int n,	/*  n >= 0 */
		 int ilo,
		 int ihi,
		 scomplex global_a[],
		 int lda,
		 scomplex global_tau[],
		 scomplex global_c[],
		 int ldc,
		 scomplex work[],
		 int lwork,
		 int *info
)
/* "pcunmhr overwrites the general complex M-by-N distributed matrix C with\\n */
/*                        SIDE = 'L'           SIDE = 'R'\\n */
/*   TRANS = 'N':         Q * C                 C  * Q   \\n */
/*   TRANS = 'C':      Q**H * C                 C  * Q**H\\n */
/* where Q is a complex unitary distributed matrix of order nq, with nq = m if SIDE = 'L' and nq = n if SIDE = 'R'. Q is defined as the product of IHI-ILO elementary reflectors, as returned by PCGEHRD:\\n  Q = H(ilo) H(ilo+1) . . . H(ihi-1)." */
/* OPTIONS */
{
  	int maxldd;

	int col_a;
	int maxlda;
	scomplex *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
	int row_loca, col_loca;

	int taulen;
	scomplex *loctau=NULL;

	int maxldc;
	scomplex *locc=NULL;
	int descc[DESCLEN];
	int desc_gc[DESCLEN];
	int row_locc, col_locc;

	scomplex *locwork=NULL;
	int llocwork;

	INITIALIZE();

	SCALAR("char",side);
	SCALAR("char",trans);
	SCALAR("int",m);
	SCALAR("int",n);
	SCALAR("int",ilo);
	SCALAR("int",ihi);
	SCALAR("int",lda);
	SCALAR("int",ldc);
	SCALAR("int",lwork);

	if (chrcmp(side,'L')==0) {
	  col_a = m;
	  taulen = m-1;
	} else {
	  col_a = n;
	  taulen = n-1;
	}

	ROW(a );
	COL(a );
	ROW(c);
	COL(c);
	MAXLDD(maxldd,a );
	maxlda=maxldd;
	maxldc=maxldd;

	MATRIX("scomplex",a,ROW_a  ,COL_c );
	DISTRIBUTE("scomplex", a,ROW_a  , COL_a );
	VECTOR( "c", "scomplex", tau, taulen);
	vDISTRIBUTE( "c", "scomplex", tau, taulen);
	MATRIX("scomplex",c, ROW_c , COL_c);
	DISTRIBUTE("scomplex", c, ROW_c ,COL_c  );

	llocwork = worklen(side, m, n, ilo, ihi);
	llocwork = max(lwork,llocwork);
	WORK(locwork,llocwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pcunmhr)( &side, &trans,
                               &m, &n, &ilo, &ihi,
                               loca, &one, &one, desca,
                               loctau,
                               locc, &one, &one, descc,
                               locwork, &llocwork, &linfo);

	GATHER("scomplex", c, ROW_c , COL_c );
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
		*info = linfo;
	} else {
	}

	FREE_MATRIX(a);
	FREE_VECTOR(tau);
	FREE_MATRIX(c);
        FREE(locwork);
	
}

