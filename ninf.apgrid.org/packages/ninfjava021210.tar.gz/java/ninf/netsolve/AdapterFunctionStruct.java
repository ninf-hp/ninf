package ninf.netsolve;
import ninf.MetaServer.*;
import ninf.client.*;


public class AdapterFunctionStruct extends NinfFunctionStruct {
  public Problem problem;

  public AdapterFunctionStruct(NinfServerStruct server, NinfStub stub, int index) throws CannotConvertException{
    super(server, stub, index);
    problem = Problem.makeUp(stub);
    System.out.println(problem);
  }

  public NinfCallable getCallable(){
    return new AdapterLatch(this, funcManager);
  }


}
