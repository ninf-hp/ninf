package ninf.cproxy;
import ninf.basic.*;
import ninf.client.*;
import ninf.cproxy.aggregate.*;
import java.util.Vector;


class ProxyScheduler{
  static final CommandRepresent acceptCommands[] = {
    new CommandRepresent("serverIndex", 3),
    new CommandRepresent("noServerAvailable", 0)
  };
  static CommandParser parser = new CommandParser(acceptCommands);

  static final CommandRepresent aggregateAcceptCommands[] = {
    new CommandRepresent("aggregateScheduled", 0),
    new CommandRepresent("noServerAvailable", 0)
  };
  static CommandParser aggregateParser 
    = new CommandParser(aggregateAcceptCommands);

  static NinfLog dbg = new NinfLog("ProxyScheduler");

  ServerTable serverTable;
  MetaServerReference metaServer;
  int port;
  String myhostname;

  ProxyScheduler(ServerTable serverTable, MetaServerReference metaServer){
    this.metaServer = metaServer;
    this.serverTable = serverTable;
    this.myhostname = CProxy.conf.myhostname;
    this.port = CProxy.conf.port;
  }

  void done(int serial) throws NinfException{
      MetaServerConnection con = metaServer.connect();
      con.send(new NinfCommand("jobDone", myhostname, ""+port, ""+serial));
      con.close();
  }

  ServerIndex schedule(NinfStub stub, CallContext context, int serial)
  throws NinfException{
      dbg.println(stub.getCallInformation(context));
      MetaServerConnection con = metaServer.connect();
      
      con.send(new NinfCommand("schedule", myhostname, ""+port, ""+serial));
      stub.getName().toCommand().send(con.os);
      stub.getCallInformation(context).toCommand().send(con.os);
      serverTable.sendServers(con);
      con.send(new NinfCommand("endschedule"));
      
      NinfCommand reply = parser.readCommand(con.is);
      if (reply.is("noServerAvailable")){
	dbg.log("Cannot find Ninf server for '" + stub.getName() + "' on metaserver");
	return null;
      }
      con.close();
      return new ServerIndex(new NinfServerStruct(reply.args[0], reply.args[1]), new Integer(reply.args[2]).intValue());

    //    return new ServerIndex(new NinfServerStruct("hpc:3020"), 0);
  }

  AggregateScheduled aggregateSchedule(FuncNode funcNodes[], 
				       DataNode dataNodes[], int serial)
    throws NinfException{
      MetaServerConnection con = metaServer.connect();
      
      con.send(new NinfCommand("aggregateSchedule", myhostname, 
			       ""+port, ""+serial));
      con.send(new NinfCommand("funcNodes", ""+funcNodes.length));
      for (int i = 0; i < funcNodes.length; i++)
	funcNodes[i].send(con.os);
      con.send(new NinfCommand("dataNodes", ""+dataNodes.length));
      for (int i = 0; i < dataNodes.length; i++)
	dataNodes[i].send(con.os);

      serverTable.sendServers(con);
      con.send(new NinfCommand("endschedule"));
      
      NinfCommand reply = aggregateParser.readCommand(con.is);
      if (reply.is("noServerAvailable")){
	dbg.log("Cannot find Ninf server for aggregatecall No." + serial);
	return null;
      }
      AggregateScheduled scheduled = new AggregateScheduled(con.is);
      con.close();
      return scheduled;
  }
}
