import java.awt.*;

public class ListTest extends Panel{
  List list1, list2;

  String items1[] = {
    "a","b","c","d","e"
  };

  String items2[] = {
    "ab","bc","cd","de","ea"
  };
  int depends1[][] = {{4, 0}, {0, 1}, {1, 2}, {2, 3}, {3, 4}};
  int depends2[][] = {{0, 1}, {1, 2}, {2, 3}, {3, 4}, {4, 0}};

  public ListTest(){
    list1 = new List();
    list2 = new List();
    for (int i = 0; i < items1.length; i++)
      list1.addItem(items1[i]);
    for (int i = 0; i < items2.length; i++)
      list2.addItem(items2[i]);

    this.add(list1);
    this.add(list2);
  }

  public boolean action(Event evt, Object arg){
    if (evt.target == list1){         /* List Item clicked */
      int selected = list1.getSelectedIndex();
      if (selected < 0 || selected >= items1.length) return true;
      for (int i = 0; i < items2.length; i++)
	list2.deselect(i);
      list2.setMultipleMode(true);
      list2.select(depends1[selected][0]);
      list2.select(depends1[selected][1]);
      list2.setMultipleMode(false);
    }
    if (evt.target == list2){         /* List Item clicked */
      int selected = list2.getSelectedIndex();
      if (selected < 0 || selected >= items2.length) return true;
      for (int i = 0; i < items1.length; i++)
	list1.deselect(i);
      list1.setMultipleMode(true);
      list1.select(depends2[selected][0]);
      list1.select(depends2[selected][1]);
      list1.setMultipleMode(false);
    }
    return false;  
  }


  public void show(){
    Frame frame = new Frame("Please Input");
    frame.add("Center", this);
    frame.resize(300, 240);
    frame.show();
  }

  public static void main(String args[]){
    (new ListTest()).show();
  }

}
