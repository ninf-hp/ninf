package bricks.scheduling;
import bricks.util.*;
import java.util.*;

public class DirectServerPredictorCreator extends PredictorCreator {

    // for bricks.tools.ShowUsage
    public DirectServerPredictorCreator(){}

    public DirectServerPredictorCreator(
	SubComponentFactory subComponentFactory
    ) {
	this.subComponentFactory = subComponentFactory;
    }

    public String usage() {
	return "DirectServerPredictor()";
    }

    public Predictor create(StringTokenizer st, MetaPredictor metaPredictor) 
	throws BricksParseException 
    {
	try {
	    String keyOfServerMonitor = st.nextToken(" \t,()");
	    return 
		new DirectServerPredictor(metaPredictor, keyOfServerMonitor);

	} catch (NoSuchElementException e) {
	    e.printStackTrace();
	    throw new BricksParseException(usage());
	}
    }
}

