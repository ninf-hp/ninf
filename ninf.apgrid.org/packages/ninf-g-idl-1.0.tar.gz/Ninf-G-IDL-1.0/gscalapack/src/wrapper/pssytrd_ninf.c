#define _WRAPPER_
/* $Id: pssytrd_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define _DISTRIBUTE_1D_
#define FLOAT
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n

static	int worklen(int n) {
	  int ret;
	  int IAROW;
	  int NP;
          
          ret = max(n*(n+1),3*n);
	  if NEED_BUFF {
#define NB blocsize
#define NUMROC Cnumroc
	    IAROW = INDXG2P( 0, NB, myprow, 0, nprow );
	    NP = NUMROC( n, NB, myprow, IAROW, nprow );
	    ret = max( NB * ( NP +1 ), 3 * NB );
	  }
          return ret;
}

void  pssytrd_ninf(	 char uplo,
		 int n,
		 float global_a[],
		 int lda,
		 float global_d[],
		 float global_e[], //uplo
		 float global_tau[],
		 float work[],
		 int lwork,
		 int *info
)
/* "pssytrd reduces a real symmetric matrix A to symmetric tridiagonal form T by an orthogonal similarity transformation:\\n  Q' * A * Q = T." */
/* OPTIONS */
{
	int maxldd;

	int maxlda;
	float *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
	int row_loca, col_loca;

	float *locd=NULL;
	float *loce=NULL;
	int desc_gtdd[DESCLEN], desctdd[DESCLEN];

	float *loctau=NULL;

	float *locwork=NULL;
	int llocwork;

	INITIALIZE();

	SCALAR( "char", uplo);
	SCALAR( "int", n);
	SCALAR("int", lda);
        SCALAR( "int",lwork);

	SIZE(n);

	ROW( a);
	COL( a);
	MAXLDD(maxldd, a);
	maxlda=maxldd;

	trMATRIX( uplo, "float", a, ROW_a, COL_a);
	trDISTRIBUTE( uplo, "float", a, ROW_a  , COL_a);

	// MATRIX <- d,e, tau
	if (chrcmp(uplo,'U')==0) tdMATRIX( "float", 0, d, e, n);
	else tdMATRIX( "float", e, d, 0, n);

	VECTOR("c", "float", tau, n);

	llocwork = worklen(n);
        llocwork = max(lwork,llocwork);
	WORK(locwork, llocwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pssytrd)( &uplo, &n,
                               loca, &one, &one, desca,
                               locd, loce,
                               loctau,
                               locwork, &llocwork, &linfo);

	trGATHER( uplo, "float", a, ROW_a  , COL_a);
	if (chrcmp(uplo,'U')==0) tdGATHER( "float", 0, d,e, n);
	else tdGATHER( "float", e, d, 0, n);
	vGATHER("c", "float", tau, n);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
		*info = linfo;
	} else {
		
	}

	FREE_MATRIX(a);
	FREE_MATRIX(d);
	FREE_MATRIX(e);
	FREE_VECTOR(tau);
	FREE(locwork);
}

