package bricks.environment;
import bricks.util.*;
import java.util.*;

public class DataFragmentsCreator extends SubComponentCreator {

    private SubComponentFactory subComponentFactory;

    // for bricks.tools.ShowUsage
    public DataFragmentsCreator(){}

    public DataFragmentsCreator(SubComponentFactory subComponentFactory) {
	this.subComponentFactory = subComponentFactory;
    }

    public String usage() {
	return "DataFragments(<int numDataFragments>, <Strings ids>, <Sequence sizes>)";
    }

    public SubComponent create(StringTokenizer st) 
	throws BricksParseException 
    {
	try {
	    int numDataFragments = 
		Integer.valueOf(st.nextToken(" \t,()")).intValue();
	    Strings ids = (Strings)subComponentFactory.create(st);
	    Sequence sizes = (Sequence)subComponentFactory.create(st);

	    return new DataFragments(numDataFragments, ids, sizes);

	} catch (NumberFormatException e) {
	    e.printStackTrace();
	    throw new BricksParseException(usage());

	} catch (NoSuchElementException e) {
	    e.printStackTrace();
	    throw new BricksParseException(usage());

	} catch (ClassCastException e) {
	    e.printStackTrace();
	    throw new BricksParseException(usage());

	} catch (BricksParseException e) {
	    e.addMessage(usage());
	    throw e;
	}
    }
}

