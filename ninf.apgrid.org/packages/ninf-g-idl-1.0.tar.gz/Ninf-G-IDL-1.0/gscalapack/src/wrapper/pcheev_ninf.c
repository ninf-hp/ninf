#define _WRAPPER_
/* $Id: pcheev_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define SCOMPLEX
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n
#define ROW_z ROW_a
#define COL_z ROW_z
static	int worklen(char jobz, int n) {
	  int ret=1;
	  int NP0,NQ0;
#define NUMROC Cnumroc
          if (chrcmp(jobz,'n')==0)
	      ret = max( n*n, 3 ) +3*n;
          if (chrcmp(jobz,'v')==0)
	      ret = 3*n*n + 3*n + n*n;
	  if NEED_BUFF {
	    NP0 = NUMROC( n, NB, 0, 0, nprow );
	    NQ0 = NUMROC( max( n, max(NB, 2) ), NB, 0, 0, npcol );
	    if (chrcmp(jobz,'n')==0)
	      ret = max( NB*( NP0+1 ), 3 ) +3*n;
	    if (chrcmp(jobz,'v')==0)
	      ret = (NP0 + NQ0 + NB)*NB + 3*n + n*n;
	  }
	  return ret;
}

static	int rworklen(char jobz, int n) {
	  int ret=1;
          if (chrcmp(jobz,'n')==0)
	      ret = 2*n+2*n-2;
          if (chrcmp(jobz,'v')==0)
	      ret = 2*n;

	  return ret;
}

void  pcheev_ninf(	 char jobz,
		 char uplo,	
		 int n,
		 scomplex global_a[],
		 int lda,
		 float w[],
		 scomplex work[],
		 int lwork,
		 float rwork[],
		 int info[]
)
/* "pcheev computes selected eigenvalues and, optionally, eigenvectors of a complex symmetric matrix A by calling the recommended sequence of ScaLAPACK routines." */
/* OPTIONS */
{
	extern void FortranCall(pcheev)( char*, char*, int*,
                              scomplex*, int*, int*, int*,
                              float*,
                              scomplex*, int*, int*, int*,
                              scomplex*, int*,
					 float*, int*,
                              int*);

	extern void FortranCall(pclacpy)( char*, int*, int*,
                               scomplex*, int*, int*, int*,
                               scomplex*, int*, int*, int*);

	int maxldd;

	scomplex *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];
	int row_loca, col_loca;
	int maxlda;

	int maxldz;
	scomplex *global_z=NULL;
	scomplex *locz=NULL;
	int descz[DESCLEN];
	int desc_gz[DESCLEN];
	int row_locz, col_locz;

	float *locw=NULL;
	
	scomplex *locwork=NULL;
	int llocwork;
	scomplex *locrwork=NULL;
	int llocrwork;

	INITIALIZE();

	SCALAR( "int", n);
	SCALAR("char",jobz);
	SCALAR("char",uplo);
	SCALAR( "int", lda);
        SCALAR( "int", lwork);

	if (mypnum==0) {
            global_z=MALLOC(sizeof(scomplex)*ROW_a*COL_a);
            assert(global_z);
        }
        locw = MALLOC(sizeof(float)*n);
        assert(locw);

	ROW(a );
	COL(a );
	ROW(z);
	COL(z);
	MAXLDD(maxldd,a );
	maxlda=maxldd;
	maxldz=maxldd;

	MATRIX( "scomplex", a, ROW_a, COL_a);
	MATRIX( "scomplex", z, ROW_z, COL_z);
	DISTRIBUTE( "scomplex", a, ROW_a, COL_a);

	llocwork = worklen( jobz, n);
	llocwork = max( lwork, llocwork);
	WORK(locwork, llocwork);

	llocrwork = rworklen(jobz, n);
	_work("float", &locrwork, llocrwork);

	if  (( mypnum != 0 ) ^ (serial==1) ) {
	 FortranCall(pcheev)( &jobz, &uplo, &n,
                              loca, &one, &one, desca,
                              locw,
                              locz, &one, &one, descz,
                              locwork, &llocwork, locrwork, &llocrwork,
                              &linfo);
	 FortranCall(pclacpy)( &uplo, &ROW_a, &COL_a,
                               locz, &one, &one, descz,
                               loca, &one, &one, desca);
	}

	GATHER("scomplex", a, ROW_a, COL_a);
	RETRIEVE( "float", locw, n);
	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
            int i;
            for(i=0;i<n;i++) w[i] = locw[i];
            *info = linfo;
            FREE(global_z);
	} else {
	}

	FREE_MATRIX(a);
	FREE_MATRIX(z);
	FREE(locw);
        FREE(locwork);
        FREE(locrwork);
}

