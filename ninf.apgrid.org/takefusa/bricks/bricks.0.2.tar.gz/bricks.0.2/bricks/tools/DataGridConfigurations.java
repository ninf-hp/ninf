package bricks.tools;
import bricks.environment.*;
import bricks.util.*;
import bricks.scheduling.*;
import java.io.*;
import java.util.*;

/**
 * DataGridConfigurations generate various configuration files for 
 * DataGrid simulations to evaluate a variety of scheduling and 
 * replication strategies.<BR>
 **/

public class DataGridConfigurations {

    public DataGridConfigurations (String[] args) {
	parseArgs(args);
    }

    /**
     * USAGE string 
     **/
    protected String usage() {
	return "java bricks.tools.DataGridConfigurations [options]\n" + 
	    "\t(-central)          [central model]\n" +
	    "\t-packet <packetSize>[logical packet size]\n" +
	    "\t-sslice <sslice>    [time slice of Server queues]\n" +
	    "\t-dslice <dslice>    [time slice of Disk queues]\n" +
	    "\t-wt <throughput>    [WAN throughput]\n" +
	    "\t-sp <t0:t1:t2>      [server performance]\n" +
	    "\t-ds <t0:t1:t2>      [disk size]\n" +
	    "\t-lio <t0:t1:t2>     [local IO throughput]\n" +
	    "\t-dataPrefix <prefix>[prefix of client data files]\n" +
	    "\t-dataSizeFileName <fileName>\n" +
	    "\t                    [file name of data size strings on T0]\n" +
	    "\t(-prefix <prefix>)  [prefix of configuration files\n" +
	    "\t                     default->stdout]\n" + 
	    "\t(-n <num>)          [number of generating topology: default=1]\n" +
	    "\t(-comment)          [output comments of configuration files]\n" +
	    "\t(-dataids <class name>)\n" +
	    "\t                    [Strings of required data ID\n" +
	    "\t                     default->RandomDataFragmentStrings]\n" +
	    "\t(-rmanager <name(:interval:score:diskrate)>) \n" +
	    "\t                    [specify ReplicaManager name\n" +
	    "\t                     default=LazyReplicaManager]\n" + 
	    "\t(-scheduler <name(:score:)>)\n" +
	    "\t                    [specify scheduler name\n" +
	    "\t                     default=GreedyReplicationScheduler]\n" + 
	    "\t(-seed <int>)       [seed for Random() for ExponentRandom]\n" +
	    "\t(-seedID <int>)     [seed for Random() for RequiredDataID]\n" +
	    "\t(-npsize <double>)  [data size for network probe: default=100.0]\n" +
	    "\t(-itnp <double>)    [interval of network probes: default=60.0]\n" +
	    "\t(-itsp <double>)    [interval of server probes: default=60.0]\n" + 
	    "\t(-tracking <double>)[trackingTime for server load: default=600.0]\n" +
	    "\t(-trackingForAccess <double>)\n" +
	    "[trackingTime for data access: default=trackingTime]\n";
    }
    

    // for input parameters
    protected boolean central = false;

    protected double packetSize = 100.0;
    protected double serverTimeSlice = 60.0;
    protected double diskTimeSlice = 1.0;
    protected double t0Perf, t1Perf, t2Perf;
    protected double t0DiskSize, t1DiskSize, t2DiskSize;
    protected double t0LocalIO, t1LocalIO, t2LocalIO;
    protected int numDataFragment = 7;

    protected int numConfigurations = 1;
    protected double wanThru;

    protected String dataSizeFileName;
    protected String dataPrefix;
    protected String dataIDs = "RandomDataFragmentStrings";

    protected String fileNamePrefix = "";

    protected boolean comment = false;
    protected boolean seedIs = false;
    protected long seed = 0;
    protected boolean seedIDIs = false;
    protected long seedID = 0;

    protected double intervalNetworkProbes = 600.0;
    protected double intervalServerProbes = 600.0;
    protected double trackingTime = 600.0;
    protected double trackingTimeForAccess = 600.0;
    protected double sizeNetworkProbe = 1.0;
    protected String replicaManager = "LazyReplicaManager";
    protected double compactness = 0.90; // All replicaManager use 0.90
    protected double rmInterEvaluationTime, rmScore, diskRate;
    protected int rmNum;

    protected String scheduler = "GreedyReplicationScheduler";
    protected double schedulingScore;

    /**
     * Random Sequences for the generation
     **/
    protected Random randomID;
    protected Random random;

    protected int rand() {
	return Math.abs(random.nextInt());
    }

    protected int randID() {
	return Math.abs(randomID.nextInt());
    }

    public void generates() {
	
	for (int no = 0; no < numConfigurations; no++) {

	    String output = "";

	    /* print packet declaration */
	    if (comment)
		output += printPacketComment();
	    output += printPacket();

	    /* print SchedulingUnit declaration */
	    if (comment)
		output += printSchedulingUnitComment();
	    output += printSchedulingUnit();

	    /* print Client, Server, ForwardNode, and Network */
	    if (comment)
		output += printGridComment();

	    if (central) // central model
		output += printCentralModelGridComponents(no);
	    else 
		output += printGridComponents(no);

	    if ((numConfigurations == 1) && (fileNamePrefix.equals(""))) {
		System.out.println(output);

	    } else { /* file out */
		try {
		    FileOutputStream fos = new FileOutputStream(
			fileNamePrefix + "_" + no
		    );
		    PrintWriter pw = BricksUtil.getWriter(fos);
		    pw.println(output);
		    pw.close();

		} catch (IOException e) {
		    e.printStackTrace();
		    throw new RuntimeException();
		}
	    }
	}
	return;
    }


    /*-------------------- protected method --------------------*/
    protected void parseArgs(String[] args) {

	if (args.length < 1)
	    BricksUtil.abort(usage());

	StringTokenizer st;
	for (int i = 0; i < args.length; i++) {
	    //System.err.println("arg = " + args[i]);

	    if (args[i].equalsIgnoreCase("-central")) {
		central = true;

	    } else if (args[i].equalsIgnoreCase("-packet")) {
		packetSize = BricksUtil.getDouble(args[++i]);

	    } else if (args[i].equalsIgnoreCase("-sslice")) {
		serverTimeSlice = BricksUtil.getDouble(args[++i]);

	    } else if (args[i].equalsIgnoreCase("-dslice")) {
		diskTimeSlice = BricksUtil.getDouble(args[++i]);

	    } else if (args[i].equalsIgnoreCase("-wt")) {
		wanThru = BricksUtil.getDouble(args[++i]);

	    } else if (args[i].equalsIgnoreCase("-sp")) {
		st = new StringTokenizer(args[++i]);
		t0Perf = BricksUtil.getDouble(st, ":");
		t1Perf = BricksUtil.getDouble(st, ":");
		t2Perf = BricksUtil.getDouble(st, ":");

	    } else if (args[i].equalsIgnoreCase("-ds")) {
		st = new StringTokenizer(args[++i]);
		t0DiskSize = BricksUtil.getDouble(st, ":");
		t1DiskSize = BricksUtil.getDouble(st, ":");
		t2DiskSize = BricksUtil.getDouble(st, ":");

	    } else if (args[i].equalsIgnoreCase("-lio")) {
		st = new StringTokenizer(args[++i]);
		t0LocalIO = BricksUtil.getDouble(st, ":");
		t1LocalIO = BricksUtil.getDouble(st, ":");
		t2LocalIO = BricksUtil.getDouble(st, ":");

	    } else if (args[i].equalsIgnoreCase("-dataprefix")) {
		dataPrefix = args[++i];

	    } else if (args[i].equalsIgnoreCase("-dataSizeFileName")) {
		dataSizeFileName = args[++i];

	    } else if (args[i].equalsIgnoreCase("-prefix")) {
		fileNamePrefix = args[++i];

	    } else if (args[i].equalsIgnoreCase("-n")) {
		numConfigurations = BricksUtil.getInt(args[++i]);

	    } else if (args[i].equalsIgnoreCase("-comment")) {
		comment = true;

	    } else if (args[i].equalsIgnoreCase("-dataids")) {
		dataIDs = args[++i];

	    } else if (args[i].equalsIgnoreCase("-rmanager")) {
		st = new StringTokenizer(args[++i]);
		replicaManager = st.nextToken(":");
		if (replicaManager.equals("PassiveReplicaManager")) {
		    if (st.hasMoreTokens()) {
			diskRate = BricksUtil.getDouble(st, ":");
			rmNum = BricksUtil.getInt(st, ":");
		    }
		} else {
		    if (st.hasMoreTokens()) {
			rmInterEvaluationTime = BricksUtil.getDouble(st, ":");
			rmScore = BricksUtil.getDouble(st, ":");
			diskRate = BricksUtil.getDouble(st, ":");
		    }
		}

	    } else if (args[i].equalsIgnoreCase("-scheduler")) {
		st = new StringTokenizer(args[++i]);
		scheduler = st.nextToken(":");
		if (st.hasMoreTokens()) {
		    schedulingScore = BricksUtil.getDouble(st, ":");
		}

	    } else if (args[i].equalsIgnoreCase("-seed")) {
		seed = BricksUtil.getLong(args[++i]);
		seedIs = true;

	    } else if (args[i].equalsIgnoreCase("-seedID")) {
		seedID = BricksUtil.getLong(args[++i]);
		seedIDIs = true;

	    } else if (args[i].equalsIgnoreCase("-npsize")) {
		sizeNetworkProbe = BricksUtil.getDouble(args[++i]);

	    } else if (args[i].equalsIgnoreCase("-itnp")) {
		intervalNetworkProbes = BricksUtil.getDouble(args[++i]);

	    } else if (args[i].equalsIgnoreCase("-itsp")) {
		intervalServerProbes = BricksUtil.getDouble(args[++i]);

	    } else if (args[i].equalsIgnoreCase("-tracking")) {
		trackingTime = BricksUtil.getDouble(args[++i]);

	    } else if (args[i].equalsIgnoreCase("-trackingForAccess")) {
		trackingTimeForAccess = BricksUtil.getDouble(args[++i]);

	    } else {
		BricksUtil.abort(args[i] + " is not in the options.\n" + usage());
	    }
	}

	/* generate random sequences */
	if (seedIs)
	    random = new Random(seed);
	else 
	    random = new Random();

	if (seedIDIs)
	    randomID = new Random(seedID);
	else 
	    randomID = new Random();
    }

    /*******************************************************************
    protected void outTrace(InputStream is, OutputStream os) {

	double stride = duration / (numPoints - 1);
	double timestamp = 0.0;

	PrintWriter pw = BricksUtil.getWriter(os);
	BufferedReader br = new BufferedReader(new InputStreamReader(is));

	String data = null;
	try {
	    while ((data = br.readLine()) != null) {
		pw.print(Format.format(timestamp, 3) + "\t");
		pw.println(data);
		timestamp = timestamp + stride;
	    } 
	    pw.close();

	} catch (IOException e) {
	    e.printStackTrace();
	    System.exit(3);
	}
    }

    /*------------------------------------------------------------*/

    protected String printPacketComment() {
	return "\n# ----- Packet declaration -----\n" + 
	    "# Packet <double logicalPacketSize>\n";
    }

    protected String printPacket() {
	return "Packet " + packetSize + "\n";
    }

    protected String printSchedulingUnitComment() {
	String output = "\n";
	try {
	    output +=
		"# ----- ResourceDB declaration -----\n" + "# " +
		((Creator)Class.forName("bricks.scheduling.ResourceDBCreator").newInstance()).usage() + "\n" + 
		"# ----- NetworkMonitor declaration -----\n" + "# " +
		((Creator)Class.forName("bricks.scheduling.NetworkMonitorCreator").newInstance()).usage() + "\n" + 
		"# ----- ServerMonitor declaration -----\n" + "# " +
		((Creator)Class.forName("bricks.scheduling.ServerMonitorCreator").newInstance()).usage() + "\n" + 
		"# ----- Precictor declaration -----\n" + "# " +
		((Creator)Class.forName("bricks.scheduling.MetaPredictorCreator").newInstance()).usage() + "\n" + 
		"# ----- ReplicaManager declaration -----\n" + "# " +
		((Creator)Class.forName("bricks.scheduling.ReplicaManagerCreator").newInstance()).usage() + "\n" +
		"# ----- Scheduler declaration -----\n" + "# " +
		((Creator)Class.forName("bricks.scheduling.SchedulerCreator").newInstance()).usage() + "\n";

	} catch (ClassNotFoundException e) {
	    e.printStackTrace();
	    System.exit(3);

	} catch (InstantiationException e) {
	    e.printStackTrace();
	    System.exit(3);

	} catch (IllegalAccessException e) {
	    e.printStackTrace();
	    System.exit(3);
	}
	return output;
    }

    protected String printSchedulingUnit() {
	String output =
	    "ResourceDB db NormalResourceDB(1000, 1000)\n" + 

	    "ServerMonitor sm NormalServerMonitor(db, Constant(" + 
	    intervalServerProbes + "), " + trackingTime + ", " +
	    trackingTimeForAccess + ")\n" + 

	    "NetworkMonitor nm RoundNetworkMonitor(db, Constant(" + 
	    intervalNetworkProbes + "), Constant(" + sizeNetworkProbe + "))\n"+

	    "Predictor pr (db)\n";

	if (replicaManager.equalsIgnoreCase("lazyreplicamanager"))
	    output += "ReplicaManager rep " + replicaManager + 
		"(db, sm, " + compactness + ")\n";
	else if (replicaManager.equalsIgnoreCase("passivereplicamanager"))
	    output += "ReplicaManager rep " + replicaManager + 
		"(db, sm, " + compactness + ", " + diskRate + 
		", " + rmNum + ")\n";

	else
	    output += "ReplicaManager rep " + replicaManager + 
		"(db, sm, Constant(" + rmInterEvaluationTime + "), " +
		compactness + ", " + rmScore + ", " + diskRate + ")\n";
	
	if (scheduler.equalsIgnoreCase("GreedyReplicationScheduler"))
	    output += "Scheduler sched " + scheduler + "(pr, rep, sm)\n";
	else if (scheduler.equalsIgnoreCase("OwnerComputesScheduler"))
	    output += "Scheduler sched " + scheduler + "(pr, rep, sm)\n";
	else
	    output += "Scheduler sched " + scheduler + 
		"(pr, rep, sm, " + schedulingScore + ")\n";
	return output;
    }

    protected String printGridComment() {
	String output = "\n";
	try {
	    output += "# ---------- Host ----------\n" + "# " + 
		((Creator)Class.forName("bricks.environment.HostCreator").newInstance()).usage() + "\n" + "# " +
		((Creator)Class.forName("bricks.environment.ClientCreator").newInstance()).usage() + "\n" + "# " +
		((Creator)Class.forName("bricks.environment.ServerCreator").newInstance()).usage() + "\n" + "# " +
		((Creator)Class.forName("bricks.environment.DiskCreator").newInstance()).usage() + "\n\n" +
		"# ---------- Node ----------\n" + "# " + 
		"# Node [name]\n" + "# " +
		((Creator)Class.forName("bricks.environment.ForwardNodeCreator").newInstance()).usage() + "\n\n" +
		"# ---------- Network ----------\n" + "# " + 
		((Creator)Class.forName("bricks.environment.ForwardNodeCreator").newInstance()).usage() + "\n\n" +
		"# ---------- Link ----------\n" + "# " + 
		((Creator)Class.forName("bricks.environment.LinkCreator").newInstance()).usage() + "\n";

	} catch (ClassNotFoundException e) {
	    e.printStackTrace();
	    System.exit(3);

	} catch (InstantiationException e) {
	    e.printStackTrace();
	    System.exit(3);

	} catch (IllegalAccessException e) {
	    e.printStackTrace();
	    System.exit(3);
	}
	return output;
    }

    protected int countLine(String fileName) {
	int numLine = 0;
	InputStream is = BricksUtil.getInputStream(fileName);
	BufferedReader br = new BufferedReader(new InputStreamReader(is));
	String line = null;
	try {
	    while ((line = br.readLine()) != null)
		numLine++;
	} catch (IOException e) {
	    e.printStackTrace();
	}
	return numLine;
    }

    /** generates Grid component configuration */
    String linkString;
    protected String printGridComponents(int no) {

	linkString = "";

	/* Client */
	String output = "\n";
	for (int i = 0; i < 4; i++) {
	    for (int j = 0; j < 4; j++) {
		String current = "0_" + i + "_" + j;
		int num = countLine(dataPrefix + "_" + no + "_send_" + current);
		output += 
		    "Host hc" + current + " db Client(c" + current
		    + " sched Requests(" +
		    "TraceFile(" + dataPrefix + "_" + no + "_send_" + current + 
		    ", " + num + "), " +
		    "TraceFile(" + dataPrefix + "_" + no + "_recv_" + current + 
		    ", " + num + "), " +
		    "TraceFile(" + dataPrefix + "_" + no + "_comp_" + current + 
		    ", " + num + "), " +
		    "TraceFile(" + dataPrefix + "_" + no + "_itvl_" + current + 
		    ", " + num + "), " +
		    dataIDs + "(" + randID() + ", db), N/A, N/A)) " +
		    "server() disk()\n";
	    }
	}

	/* Server T0 */
	output += 
	    "\nHost hs0 db client() Server(s0 QueueTimeSharing(Constant(" + 
	    t0Perf + ") " + serverTimeSlice + ") N/A) " +
	    "Disk(ds0 " +  t0DiskSize + " DataFragments(" + numDataFragment 
	    + " SerialNumberStrings(1) TraceFile(" + dataSizeFileName + " " + 
	    numDataFragment + ")) " +
	    "QueueTimeSharingForDisk(Constant(" + t0LocalIO + ")  " + 
	    diskTimeSlice + ") N/A)\n";

	/* Server T1 */
	output += "\n";
	for (int i = 0; i < 4; i++){
	    output += 
		"Host hs0_" + i + " db client() Server(s0_" + i + 
		" QueueTimeSharing(Constant(" + t1Perf + ") " + 
		serverTimeSlice + ") N/A) " +
		"Disk(ds0_" + i + " " +  t1DiskSize + " N/A " +
		"QueueTimeSharingForDisk(Constant(" + t1LocalIO + ") , " + 
		diskTimeSlice + ") N/A)\n";
	}

	/* Server T2 */
	output += "\n";
	for (int i = 0; i < 4; i++) {
	    for (int j = 0; j < 4; j++) {
		String current = "0_" + i + "_" + j;
		output +=
		    "Host hs" + current + " db client() Server(s" + current +
		    " QueueTimeSharing(Constant(" + t2Perf + ") " + 
		    serverTimeSlice + ") N/A) " +
		    "Disk(ds" + current + " " +  t2DiskSize + " N/A " +
		    "QueueTimeSharingForDisk(Constant(" + t2LocalIO + ") , " + 
		    diskTimeSlice + ") N/A)\n";
	    }
	}

	/* Node */
	output += "\nNode n0\n";
	for (int i = 0; i < 4; i++)
	    output += "Node n0_" + i + "\n";
	for (int i = 0; i < 4; i++) {
	    for (int j = 0; j < 4; j++)
		output += "Node n0_" + i + "_" + j + "\n";
	}

	/* Network */
	/* hs0-n0 */
	output += "\n" + network("n0", "hs0", true);
	
	for (int i = 0; i < 4; i++){
	    /* n0-n0_? */
	    output += network("n0", "n0_"+i, false);
	    
	    /* n0_?-hs0_? */
    	    output += network("n0_"+i, "hs0_"+i, true);

	    for (int j = 0; j < 4; j++){
		/* n0_?-n0_?_? */
		output += network("n0_"+i, "n0_"+i+"_"+j, false);

		/* n0_?_?-hs0_?_? */
		output += 
		    network("n0_"+i+"_"+j, "hs0_"+i+"_"+j, true);

		/* n0_?_?-hc0_?_? */
		output += 
		    network("n0_"+i+"_"+j, "hc0_"+i+"_"+j, true);
	    }
	}

	/* Link */
	return output + "\n" + linkString + "\n";
    }

    /** generates central model Grid component configuration */
    protected String printCentralModelGridComponents(int no) {

	linkString = "";

	/* Client */
	String output = "\n";
	int num = 2300;
	output += 
	    "Host hc0 db Client(c0, sched Requests(" +
	    "TraceFile(" + dataPrefix + "_" + no + "_send, " + num + "), " +
	    "TraceFile(" + dataPrefix + "_" + no + "_recv, " + num + "), " +
	    "TraceFile(" + dataPrefix + "_" + no + "_comp, " + num + "), " +
	    "TraceFile(" + dataPrefix + "_" + no + "_itvl, " + num + "), " +
	    dataIDs + "(" + randID() + ", db), N/A, N/A)) server() disk()\n";

	/* Server T0 */
	output += 
	    "\nHost hs0 db client() Server(s0 QueueTimeSharing(Constant(" + 
	    t0Perf + ") " + serverTimeSlice + ") N/A) " +
	    "Disk(ds0 " +  t0DiskSize + " DataFragments(" + numDataFragment 
	    + " SerialNumberStrings(1) TraceFile(" + dataSizeFileName + " " + 
	    numDataFragment + ")) " +
	    "QueueTimeSharingForDisk(Constant(" + t0LocalIO + ")  " + 
	    diskTimeSlice + ") N/A)\n";

	/* Node */
	output += "\nNode n0\n";

	/* Network */
	/* hs0-n0 */
	output += "\n" + network("n0", "hs0", true);
	output += "\n" + network("n0", "hc0", true);
	
	/* Link */
	return output + "\n" + linkString + "\n";
    }

    protected String network(
        String upper, String bottom, boolean bottomIsHost
    ) {
	String upward = bottom + "to" + upper;
	String downward = upper + "to" + bottom;

	linkString += "Link " +
	    upward + "-" + upper + ", " + 
	    upper + "-" + downward + ", " + downward + "-" + bottom + ", ";
        if (bottomIsHost)
	    linkString += 
		bottom + "-" + upward + ":ExponentRandom(" + rand() + ")\n";
	else
	    linkString += 
		bottom + "-" + upward + ")\n";

	return 
	    "Network (" + upward + " QueueFCFS(Constant(" + wanThru + 
	    ")) N/A)\n" +
	    "Network (" + downward + " QueueFCFS(Constant(" + wanThru +
	    ")) N/A)\n";
    }

    /**
     * The entry 
     */
    public static void main(String[] args) {

	DataGridConfigurations conf = new DataGridConfigurations(args);
	conf.generates();
    }
}
