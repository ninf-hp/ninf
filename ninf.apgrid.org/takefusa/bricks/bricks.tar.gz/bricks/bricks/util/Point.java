package bricks.util;

public class Point {

    public float x = (float)0.0;
    public float y = (float)0.0;

    public Point(float x, float y) {
	this.x = x;
	this.y = y;
    }
}
