#define _WRAPPER_
/* $Id: pclabrd_ninf.c,v 1.1.1.1 2005/06/03 09:11:28 naotaka Exp $ */
#define _DISTRIBUTE_1D_
#define SCOMPLEX
#include <gscalapack.h>

#define ROW_a lda
#define COL_a n
#define ROW_x ldx
#define COL_x nb
#define ROW_y ldy
#define COL_y nb
static	int worklen(int n) {
	  int ret=1;
	  int NQ;
	  int IACOL;
	  ret = n+n;
	  if NEED_BUFF {
#define NB_A blocsize
#define NB_Y blocsize
	    IACOL = INDXG2P( 1, NB_A, mypcol, 0, npcol );
	    NQ = Cnumroc( n+ NB_Y , NB_Y, mypcol, 0, npcol );
	    ret = NB_A+NQ;
	  }
	  return ret;
}

void  pclabrd_ninf(	 int m,
		 int n,
		 int nb,
		 scomplex global_a[],
		 int lda,
		 float global_d[],
		 float global_e[],
		 scomplex global_tauq[],
		 scomplex global_taup[],
		 scomplex global_x[],
		 int ldx,
		 scomplex global_y[],
		 int ldy
)
/* "pclabrd reduces the first NB rows and columns of a complex general M-by-N distributed matrix A to upper or lower bidiagonal form by an unitary transformation Q' * A * P, and returns the matrices X and Y which are needed to apply the transformation to the unreduced part of A. If M >= N,  A is reduced to upper bidiagonal form; if M < N, to lower bidiagonal form." */
/* OPTIONS */
{

  int min_m_n;

	int maxldd;

	int maxlda;
	scomplex *loca=NULL;
	int desca[DESCLEN];
	int desc_ga[DESCLEN];

	float *locd=NULL;
	float *loce=NULL;
	int desctdd[DESCLEN],desc_gtdd[DESCLEN];

	scomplex *loctauq=NULL;
	scomplex *loctaup=NULL;

	int maxldx;
	scomplex *locx=NULL;
	int descx[DESCLEN];
	int desc_gx[DESCLEN];

	int maxldy;
	scomplex *locy=NULL;
	int descy[DESCLEN];
	int desc_gy[DESCLEN];

	scomplex *locwork=NULL;
	int llocwork;

	int row_loca;
	int col_loca;
	int row_locx;
	int col_locx;
	int row_locy;
	int col_locy;

	INITIALIZE();

	SCALAR( "int", m);
	SCALAR( "int", n);
	SCALAR( "int", nb);
	SCALAR( "int", lda);
	SCALAR( "int", ldx);

	min_m_n = min(m,n);
	SIZE(min_m_n);
	
	ROW( a);
	COL( a);
	ROW( x);
	COL( x);
	ROW( y);
	COL( y);

	MAXLDD( maxldd, a );
	maxlda = maxldd;
	maxldx = maxldd;
	maxldy = maxldd;

	MATRIX( "scomplex", a, ROW_a, COL_a);
	tdMATRIX("float", e, d, e, min_m_n);
	VECTOR( "c", "scomplex", tauq, min_m_n);
	VECTOR( "r", "scomplex", taup, min_m_n);
	MATRIX( "scomplex", x, ROW_x, COL_x);
	MATRIX( "scomplex", y, ROW_y, COL_y);

	DISTRIBUTE( "scomplex", a, ROW_a  , COL_a);

	llocwork = worklen(n);
	WORK( locwork, llocwork);

	if  (( mypnum != 0 ) ^ (serial==1) )
	 FortranCall(pclabrd)( &m, &n, &nb, loca, &one, &one, desca, locd, loce, loctauq, loctaup, locx, &one, &one, descx, locy, &one, &one, descy, locwork);

	GATHER( "scomplex", a, ROW_a  , COL_a);
	tdGATHER( "float", e, d, e, min_m_n);

	vGATHER( "c", "scomplex", tauq, min_m_n);
	vGATHER( "r", "scomplex", taup, min_m_n);

	GATHER( "scomplex", x, ROW_x  , COL_x);
	GATHER( "scomplex", y, ROW_y  , COL_y);

	RETRIEVE("int", &linfo, 1);

	if( mypnum == 0 ){
	} else {
		
	}

	FREE_MATRIX(a);
	FREE_MATRIX(d);
	FREE_MATRIX(e);
	FREE_VECTOR(tauq);
	FREE_VECTOR(taup);
	FREE_MATRIX(x);
	FREE_MATRIX(y);
        FREE(locwork);
	
}

