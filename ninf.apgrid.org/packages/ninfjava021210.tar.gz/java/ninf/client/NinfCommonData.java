package ninf.client;
import ninf.basic.*;
import ninf.client.*;

public class NinfCommonData{
/*********************** NON STATIC VARIABLES ***********************/
  public ArgPosition common[];
  int mark = -1;
  static NinfLog dbg = new NinfLog("NinfCommonData");
  
/***********************  INSTANCE  CREATION  ***********************/
  public NinfCommonData (NinfPacketInputStream is) throws NinfException{
    read(is);
  }

/***********************     I/O  METHODS     ***********************/
  public void read(NinfPacketInputStream is) throws NinfException {
    int num = is.readInt();
    common = new ArgPosition[num];
    for (int i = 0; i < num; i++)
      common[i] = new ArgPosition(is);
    dbg.println(this);
  }
/***********************  NON STATIC METHODS  ***********************/
  public String toString() {
    String tmp = "Common: [ ";
    for (int i = 0; i < common.length; i++)
      tmp += common[i].toString() + " ";
    return tmp + "]";
  }

  public int[] serialize(int argNums[]){
    int tmp[] = new int[common.length];
    for (int i = 0; i < common.length; i++)
      tmp[i] = common[i].serialize(argNums);
    return tmp;
  }

  public boolean includes(ArgPosition position){
    for (int i = 0; i < common.length; i++)
      if (common[i].equals(position))
	return true;
    return false;
  }

  public int mark(){
    return mark;
  }

  public void mark(int i){
    mark = i;
  }

  public void reset(){
    mark = -1;
  }
}
